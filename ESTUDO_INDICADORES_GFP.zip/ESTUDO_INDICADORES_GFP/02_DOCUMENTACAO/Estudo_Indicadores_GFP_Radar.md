# Caderno de investigação técnica — Indicadores de transação do GFP

**Versão:** 1.0 | **Estado:** protocolo de estudo, não homologado | **Escopo:** Radar Financeiro / DB2GFP

## 1. Resumo executivo

O objetivo é entender cada atributo `IN_` de `DB2GFP.TRAN_RLZD_INST_PCT`: o que sinaliza, como o GFP o utiliza, que registros desaparecem se o utilizarmos como filtro, quanto representam e como isso afeta o Radar. Não estamos alterando a regra 7 nem tentando reproduzir integralmente o aplicativo GFP. O estudo produz evidências para decisões posteriores.

**Decisão metodológica:** estudar a população disponível e autorizada, sem filtro por MCI, por 30 dias completos (15 se desejado), sem filtrar nenhum indicador. Usar o mesmo período em todas as consultas. A janela é adequada como ponto de partida, não uma garantia de observar todos os casos raros, históricos ou futuros. Todas as extrações propostas são somente leitura e agregadas; não é necessário enviar dados pessoais nem descrições livres de transações.

### 1.1 Entregáveis esperados

- Inventário do domínio e combinações efetivamente observadas dos seis indicadores.
- Matriz de tipo, natureza, categoria atual/original e indicadores.
- Medição isolada e combinada das exclusões, em quantidade e valor absoluto registrado.
- Tesauro de categorias e grupos, com identificação do grupo 13.
- Estudos de cartão, conta corrente, divisão, IR, instituições e escopo de contas.
- Matriz de hipóteses verificadas, divergências e lacunas; proposta posterior de regras de elegibilidade por indicador, sem perda de evidência.

## 2. Fontes e limites da evidência

| Fonte | Uso | Limite |
|---|---|---|
| `db2gfp_estrutura_sysibm.json` | Estrutura física SYSIBM, gerada em 04/08/2026; tipos, chaves, nulabilidade e defaults | Não fornece registros de negócio nem plano de acesso |
| `GFP.json` | Modelo ERwin e definição conceitual dos atributos | Exemplos não são uma tabela completa das regras de atribuição |
| `tran.txt` | Seis consultas Java V7 e exemplos de consulta de complementos | Demonstra leitura/seleção, não necessariamente escrita ou execução em produção |
| `radar_todos_v1.ipynb` | Especificação do Radar e da contagem antes da reconciliação | Não prova comportamento efetivo do banco |
| `Documentacao_GFP_Regra_7_QT_MOV_CICLO.md` | Consolidação técnica anterior | Documento derivado, não substitui as fontes primárias |

Classificar cada conclusão como **documentada**, **observada nos dados**, **inferida**, ou **pendente**. Frequência e associação não revelam, por si só, a regra de atribuição de um indicador. Valores S/N são domínio documentado, não garantia de restrição física.

## 3. Universo transacional e janela de estudo

### 3.1 Parâmetros comuns

| Parâmetro | Valor adotado |
|---|---|
| Data inicial inclusiva | 2026-10-26 (exemplo de 30 dias completos até 24/11/2026) |
| Data final exclusiva | 2026-11-25 |
| Alternativa de 15 dias | 2026-11-10 a 2026-11-24, inclusive |
| Data de referência | `DT_TRAN`, data da transação, não `TS_INCL_TRAN`/`TS_ATL_TRAN` |
| Produto | `CD_PRD IN (6,9)` — conta corrente e cartão |
| Estado | `CD_EST_TRAN_INST = 0` — efetivada |
| Moeda | `CD_TIP_MOE_CRR = 'BRL'` — moeda registrada |
| Natureza | Todas, para também detectar desvios do domínio C/D |
| Indicadores | Todos os valores, sem filtro |
| Categorias / instituições | Todas no universo autorizado |

Atualizar as duas datas literais do CTE `P` em **todas** as consultas temporais antes de rodar, se a janela for diferente. As datas acima são uma escolha explícita de exemplo, não uma informação extraída da base. A condição `DT_TRAN >= DT_INI AND DT_TRAN < DT_FIM_EXCL` contém exatamente 30 (ou 15) datas-calendário; não incluir o dia incompleto. As consultas de cadastro Q01 e Q01B não têm filtro de data. Q10 amplia o escopo de produto, estado e moeda para investigar a marcação fora do recorte principal. Q08 é propositalmente restrita a originais divididos e seus derivados no escopo. Q07 utiliza a tabela de inclusão do cliente.

**Importante:** não retirar `S`, `N`, categoria zero, valores fora do domínio ou registros sem complemento. Não usar a regra 7 como filtro de extração: isso esconderia as exclusões que queremos medir. A regra será simulada na Q04. A janela de estudo não é o ciclo individual do Radar e não inclui a borda de reconciliação de ±5 dias. Não se pretende calcular `QT_MOV_CICLO` por cliente nesta fase.

### 3.2 Tabelas e granularidade

| Tabela | Chave indicada no SYSIBM | Papel |
|---|---|---|
| `TRAN_RLZD_INST_PCT` | `NR_TRAN_INST_PCT` | Registro institucional original; seis indicadores |
| `CTGR_TRAN_OPB` | `CD_CTGR_TRAN` | Cadastro de categoria, natureza, grupo, código IR |
| `GR_CTGR_TRAN` | `CD_GR_CTGR_TRAN` | Cadastro de grupos |
| `CMPT_TRAN_RLZD_CRT` | `NR_TRAN_INST_PCT` | Complemento de cartão, parcela e tipos |
| `CMPT_TRAN_RLZD_CC` | `NR_TRAN_INST_PCT` | Complemento de conta, histórico e contraparte |
| `TRAN_INCD_CLI` | `NR_TRAN_INCD_CLI` | Inclusões manuais e derivados; referência `NR_TRAN_RLZD_OGM` |
| `INF_OPB_CT_CLI` | `CD_CLI_TITR_CT`, `NR_MCA_PCT_OPB`, `NR_SEQL_CT_CLI` | Cadastro da conta e suas marcações de apresentação |

As chaves foram conferidas no catálogo fornecido. Os complementos são unidos por `NR_TRAN_INST_PCT`, como no Java. LEFT JOIN conserva transação sem complemento. Ausência de uma dimensão é informação de qualidade, não motivo automático para excluir. Se a estrutura atual diferir do catálogo, registrar a diferença e não improvisar a junção.

## 4. Inventário dos seis atributos IN_

Todos são `CHAR(1) NOT NULL` na tabela principal. Padrões do SYSIBM: CSM=S, CX=S, DVS=N, OCTR=N, IR=N; EVT sem default declarado nessa tabela (modelo ERwin documenta S). Default não equivale à regra de atribuição.

| Campo | S | N | O que exclui o predicado proposto | Evidência / referência ERwin (O_Id) |
|---|---|---|---|---|
| IN_VSLO_CSM | Visualizar no consumo | Não visualizar | `= 'S'` rejeita N e qualquer valor diferente de S | 10603; exemplo da compra em 10 parcelas e apresentação do total |
| IN_VSLO_CX | Visualizar no caixa | Não visualizar | `= 'S'` rejeita N e demais valores | 10601; exemplo de compra contestada |
| IN_VSLO_EVT | Visualizar nos eventos | Não visualizar | `= 'S'` rejeita N e demais valores | 9812; exemplo do vencimento da fatura |
| IN_DVS_LCTO | Original dividido | Não dividido | `= 'N'` rejeita originais divididos e demais valores | 10995; saque 100 dividido em 30 e 70 |
| IN_OCTR_TRAN | Ocultar | Não ocultar | `= 'N'` rejeita S e demais valores; `!= 'S'` só rejeita S no domínio não nulo | 10605; ocultação no GFP |
| IN_TRAN_IR | Marcado como dedutível | Não marcado | `= 'S'` rejeita não marcados e demais valores | 10599; exemplo de despesa médica marcada pelo cliente |

### 4.1 Consumo — IN_VSLO_CSM

É um indicador de visibilidade no Perfil de Consumo, não uma definição universal de despesa. O GFP seleciona débitos e CSM=S na listagem por categoria. O exemplo do parcelamento indica uma perspectiva de reconhecimento do consumo; não confirma como cada parcela, total de compra e pagamento de fatura é marcado em todos os produtos/instituições. Investigar C/D separadamente; comparar tipo, categoria original/atual, parcelas e tipos de lançamento. Perguntas: o que fica fora? há faturas CSM=S? créditos CSM=N correspondem a salário, pagamento, estorno ou outros? O filtro atual do Radar é assimétrico; manter créditos independentemente de CSM não torna todo crédito renda.

### 4.2 Fluxo de caixa — IN_VSLO_CX

O GFP usa CX=S na consulta de movimentação financeira com a natureza parametrizada. Não presumir equivalência com alteração de saldo. Exemplo de compra contestada consta do modelo. Investigar compras, parcelas, faturas, créditos, transferências, aplicações e resgates. Distinguir movimentação por conta de caixa consolidado do cliente. Comparar CSM=S/CX=N e CSM=N/CX=S.

### 4.3 Eventos — IN_VSLO_EVT

O GFP utiliza EVT=S para listagem geral, contagem total e agendamentos. Um evento de linha do tempo não precisa representar consumo ou alteração imediata de saldo. Investigar eventos exclusivos (CSM=N, CX=N, EVT=S), operações sem EVT e diferenças entre estado 0 e 1 (Q10). Não tratar EVT como filtro geral de validade econômica.

### 4.4 Divisão — IN_DVS_LCTO

S identifica o original dividido. A consulta V7 exclui o original (DVS=N) e incorpora transações da tabela `TRAN_INCD_CLI`, distinguindo M (manual, referência nula/zero) e D (derivado, referência não zero), além de T (institucional). O original pode ser legítimo; excluir o original sem trazer seus derivados pode omitir o movimento. Não contar original e derivados como despesas independentes. Q07 e Q08 avaliam essa transformação, mas não pretendem reconciliar todos os períodos.

### 4.5 Ocultação — IN_OCTR_TRAN

S sinaliza ocultação, não deleção lógica; o estado da transação é outro atributo. O Java retorna OCTR em diversas consultas, mas no SQL de IR usa `!= 'S'`. Não sabemos se outras camadas também ocultam. Investigar proporção e categorias afetadas, sem presumir que ocultar invalida o lançamento. Respeitar políticas de autorização, finalidade e tratamento de dados; o estudo agregado não autoriza revelar lançamentos ocultos ao usuário final.

### 4.6 Imposto de renda — IN_TRAN_IR

Trata-se de marcação tributária do cliente, não comprovação de dedutibilidade fiscal. O Java de IR filtra `CD_TRAN_IR IN (:codigoIR)`, não `IN_TRAN_IR = 'S'`. Q11 compara o indicador com o código, categoria e ocultação. Não utilizar IR como filtro global do Radar sem uma finalidade tributária específica.

## 5. Evidência do código GFP V7

| Consulta | Estado | Natureza | Indicador | DVS | Outros aspectos | Linhas tran.txt |
|---|---|---|---|---|---|---|
| LISTAR_TRANSACOES_V7 | !=9 | sem filtro | EVT=S | N | manuais/derivados; seleção de contas | 74–79, 131–135, 242–250 |
| LISTAR_TRANSACOES_CATEGORIA_V7 | !=9 | D | CSM=S | N | categoria parametrizada; manuais/derivados | 320–327, 379–385 |
| LISTAR_TRANSACOES_MOVIMENTACAO_FINANCEIRA_V7 | !=9 | parametrizada | CX=S | N | manuais/derivados; grupo 13 excluído | 569–575, 627–632, 739–748 |
| LISTAR_TRANSACOES_AGENDADAS_V7 | =1 | sem filtro | EVT=S | N | produto 6; sem união de manuais | 818–824 |
| LISTAR_TRANSACOES_IR_V7 | !=9 | D | CSM=S | N | OCTR !=S; código IR; grupo 13 excluído | 969–977, 1152 |
| CONTAR_TRANSACOES_TOTAL_V7 | !=9 | sem filtro | EVT=S | N | manuais/derivados; COUNT(*) final | 1217–1222, 1390–1397 |

DVS acima refere-se à seleção institucional. O GFP une manuais/derivados em consultas específicas; o código usa parâmetros de contas/marcas e faz junção final ao cadastro. Os filtros de grupos da movimentação e de IR rejeitam também valores nulos no predicado `!=13`. A consulta de movimentação usa a tabela de grupos; IR usa a categoria associada. O significado do grupo 13 precisa vir do cadastro (Q01B). Nenhuma dessas consultas é idêntica à regra 7; `!=9` não equivale a `=0`. Código de leitura não prova atribuição.

## 6. Combinações de visibilidade e hipóteses de estudo

| CSM | CX | EVT | Interpretação estritamente pelos indicadores |
|---|---|---|---|
| S | S | S | Marcado para as três perspectivas |
| S | S | N | Consumo e caixa, não eventos |
| S | N | S | Consumo e eventos, não caixa |
| S | N | N | Apenas consumo |
| N | S | S | Caixa e eventos, não consumo |
| N | S | N | Apenas caixa |
| N | N | S | Apenas eventos |
| N | N | N | Nenhuma das três |

Tabela teórica, não garante exibição final. Com DVS/OCTR/IR, até 64 combinações S/N. Verificar valores fora do domínio; nunca agrupá-los silenciosamente em N.

| Caso a investigar | Questão | Evidência |
|---|---|---|
| Compra à vista/parcelada e parcela | CSM seleciona total e CX parcelas? | Q03/Q05 |
| Pagamento de fatura e crédito no cartão | Há duas representações? Quais indicadores? | Q03/Q05/Q06 |
| Juros, tarifas, anuidade, IOF | São despesa financeira? Quais marcações? | Q03/Q05/Q06 |
| Estorno, contestação, devolução | São reversões? Qual perspectiva? | Q03/Q05; código de atribuição |
| Pix/TED de mesma titularidade | Existe padrão distinto de terceiros? | Q03/Q06 |
| Investimento, resgate, empréstimo, amortização | Indicadores distinguem caixa de renda/consumo? | Q01/Q03/Q06 |
| Saque e lançamento dividido | Original e derivados preservam valor? | Q07/Q08 |
| Lançamento oculto | Quais categorias seriam perdidas? | Q03/Q04/Q11 |
| IR | Indicador e código correspondem? | Q11 |
| Agendado/deletado/outra moeda | O recorte principal omite casos relevantes ao estudo? | Q10 |
| Categoria atual versus original | Mudança de categoria acompanha mudança de marcação? | Q03; não prova antes/depois |
| Marca/instituição | Os padrões são homogêneos? | Q09 |
| Conta fora da exibição | Diferença entre visibilidade da conta e transação? | Q12 |

## 7. Consultas SQL e contrato de retorno

### 7.1 Convenções

Cada consulta abaixo é independente. SQL em dialeto DB2, somente SELECT/CTE. Datas fixas, sem `WITH UR` por padrão para evitar aceitar leitura suja; a política de isolamento do ambiente continua aplicável. Nenhuma consulta foi executada ou homologada no DB2; nomes e tipos conferidos no catálogo. Não é necessário enviar plano de acesso nem métricas de processamento. O arquivo SQL acompanhante contém as mesmas consultas, na mesma ordem.

`QT_TRAN` conta registros, não eventos econômicos. `VL_TOTAL` é a soma dos valores tal como armazenados; `VL_ABS` é a soma das magnitudes, não o saldo nem o gasto líquido. Não inferir sinal por natureza; C/D são mantidos separados na matriz principal. A precisão decimal adotada é 31,2. Q00/Q02 podem somar C e D como magnitude descritiva, nunca como fluxo líquido. Q10 mantém moeda separada. Não arredondar resultados na exportação.

### Q00 — Controle do período e universo

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q00.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
)
SELECT P.DT_INI, P.DT_FIM_EXCL,
       DAYS(P.DT_FIM_EXCL) - DAYS(P.DT_INI) AS QT_DIAS,
       MIN(T.DT_TRAN) AS DT_MIN_OBS, MAX(T.DT_TRAN) AS DT_MAX_OBS,
       COUNT_BIG(T.NR_TRAN_INST_PCT) AS QT_TRAN,
       COALESCE(SUM(DECIMAL(T.VL_TRAN,31,2)),0) AS VL_TOTAL,
       COALESCE(SUM(ABS(DECIMAL(T.VL_TRAN,31,2))),0) AS VL_ABS
FROM P
LEFT JOIN DB2GFP.TRAN_RLZD_INST_PCT T ON T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
GROUP BY P.DT_INI, P.DT_FIM_EXCL;
```

**O que devolver:** Uma linha: DT_INI, DT_FIM_EXCL, QT_DIAS, DT_MIN_OBS, DT_MAX_OBS, QT_TRAN, VL_TOTAL, VL_ABS. Mesmo sem transações, devolve contagem zero.

**O que será analisado:** Registra o denominador do estudo. Comparar com os totais de Q02, Q03 e Q04; datas observadas fora do período indicam erro. A janela não comprova sincronização completa.


### Q01 — Tesauro de categorias e grupos

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q01.csv`.

**SQL:**

```sql
SELECT C.CD_CTGR_TRAN, C.TX_DCR_CTGR_TRAN,
       C.CD_NTZ_CTB_TRAN AS NTZ_CATEGORIA,
       C.IN_CTGR_PDRO_SIS, C.CD_TRAN_IR, C.CD_GR_CTGR_TRAN,
       G.TX_DCR_GR_CTGR,
       CASE WHEN G.CD_GR_CTGR_TRAN IS NULL THEN 'SEM_GRUPO'
            WHEN G.CD_GR_CTGR_TRAN = 13 THEN 'GRUPO_13'
            ELSE 'OUTRO_GRUPO' END AS SITUACAO_GRUPO
FROM DB2GFP.CTGR_TRAN_OPB C
LEFT JOIN DB2GFP.GR_CTGR_TRAN G
  ON G.CD_GR_CTGR_TRAN = C.CD_GR_CTGR_TRAN
ORDER BY C.CD_CTGR_TRAN;
```

**O que devolver:** Uma linha por categoria cadastrada; 8 colunas do SELECT. Devolver todas as categorias, mesmo sem uso na janela.

**O que será analisado:** Descobrir nomes e grupos, confrontar categoria atual e original, e separar o indicador de categoria padrão do sistema dos seis indicadores transacionais. O catálogo cadastral não precisa de filtro temporal.


### Q01B — Cadastro dos grupos — inclusive grupo 13

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q01B.csv`.

**SQL:**

```sql
SELECT CD_GR_CTGR_TRAN, TX_DCR_GR_CTGR, CD_COR_GR_CTGR
FROM DB2GFP.GR_CTGR_TRAN
ORDER BY CD_GR_CTGR_TRAN;
```

**O que devolver:** Uma linha por grupo cadastrado; todas as três colunas.

**O que será analisado:** Identificar o significado cadastrado do grupo 13, inclusive se não estiver associado a nenhuma categoria. Ausência de grupo 13 deve ser relatada.


### Q02 — Combinações reais dos seis indicadores

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q02.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
)
SELECT
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR,
        COUNT_BIG(*) AS QT_TRAN,
        SUM(DECIMAL(T.VL_TRAN,31,2)) AS VL_TOTAL,
        SUM(ABS(DECIMAL(T.VL_TRAN,31,2))) AS VL_ABS
FROM DB2GFP.TRAN_RLZD_INST_PCT T
CROSS JOIN P
WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
GROUP BY
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR;
```

**O que devolver:** Uma linha por combinação real dos seis indicadores; QT_TRAN, VL_TOTAL, VL_ABS. Até 64 combinações se o domínio for estritamente S/N.

**O que será analisado:** Identificar domínios, valores anômalos e padrões conjuntos; não confundir associação estatística com dependência causal. As oito combinações CSM/CX/EVT podem ser derivadas somando sobre DVS/OCTR/IR.


### Q03 — Matriz principal: tipo, natureza, categoria e indicadores

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q03.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
)
SELECT
        T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TIP_TRAN,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR,
        COUNT_BIG(*) AS QT_TRAN,
        SUM(DECIMAL(T.VL_TRAN,31,2)) AS VL_TOTAL,
        SUM(ABS(DECIMAL(T.VL_TRAN,31,2))) AS VL_ABS
FROM DB2GFP.TRAN_RLZD_INST_PCT T
CROSS JOIN P
WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
GROUP BY
        T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TIP_TRAN,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR;
```

**O que devolver:** Uma linha por combinação de CD_PRD, CD_NTZ_CTB_TRAN, CD_TIP_TRAN, CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL e os seis indicadores; QT_TRAN, VL_TOTAL, VL_ABS. Total de 14 colunas.

**O que será analisado:** É a extração central. Cruzar Q01 duas vezes (categoria atual e original); conservar grupos sem cadastro. Identificar tipos/categorias excluídos, comportamento diferente por natureza, divergência entre classificação atual/original e peso quantitativo/financeiro de cada combinação. Não há limite fixo de linhas: devolver o resultado integral.


### Q04 — Impacto isolado e combinado dos filtros

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q04.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
),
B AS (
    SELECT T.* FROM DB2GFP.TRAN_RLZD_INST_PCT T CROSS JOIN P
    WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
)
SELECT CD_PRD, CD_NTZ_CTB_TRAN,
       COUNT_BIG(*) AS QT_ORIGINAL,
       SUM(ABS(DECIMAL(VL_TRAN,31,2))) AS VL_ABS_ORIGINAL,
       COUNT_BIG(CASE WHEN IN_VSLO_CSM = 'S' THEN 1 END) AS QT_CSM,
       SUM(CASE WHEN IN_VSLO_CSM = 'S' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_CSM,
       COUNT_BIG(CASE WHEN IN_VSLO_CX = 'S' THEN 1 END) AS QT_CX,
       SUM(CASE WHEN IN_VSLO_CX = 'S' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_CX,
       COUNT_BIG(CASE WHEN IN_VSLO_EVT = 'S' THEN 1 END) AS QT_EVT,
       SUM(CASE WHEN IN_VSLO_EVT = 'S' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_EVT,
       COUNT_BIG(CASE WHEN IN_DVS_LCTO = 'N' THEN 1 END) AS QT_DVS,
       SUM(CASE WHEN IN_DVS_LCTO = 'N' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_DVS,
       COUNT_BIG(CASE WHEN IN_OCTR_TRAN = 'N' THEN 1 END) AS QT_OCTR,
       SUM(CASE WHEN IN_OCTR_TRAN = 'N' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_OCTR,
       COUNT_BIG(CASE WHEN IN_TRAN_IR = 'S' THEN 1 END) AS QT_IR,
       SUM(CASE WHEN IN_TRAN_IR = 'S' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_IR,
       COUNT_BIG(CASE WHEN (CD_NTZ_CTB_TRAN = 'C' OR (CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S')) THEN 1 END) AS QT_RADAR,
       SUM(CASE WHEN (CD_NTZ_CTB_TRAN = 'C' OR (CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S')) THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_RADAR,
       COUNT_BIG(CASE WHEN CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S' THEN 1 END) AS QT_CSM_D,
       SUM(CASE WHEN CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_CSM_D,
       COUNT_BIG(CASE WHEN IN_VSLO_EVT = 'S' AND IN_DVS_LCTO = 'N' THEN 1 END) AS QT_GFP_EVT_INST,
       SUM(CASE WHEN IN_VSLO_EVT = 'S' AND IN_DVS_LCTO = 'N' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_GFP_EVT_INST,
       COUNT_BIG(CASE WHEN IN_VSLO_CX = 'S' AND IN_DVS_LCTO = 'N' THEN 1 END) AS QT_GFP_CX_INST,
       SUM(CASE WHEN IN_VSLO_CX = 'S' AND IN_DVS_LCTO = 'N' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_GFP_CX_INST,
       COUNT_BIG(CASE WHEN CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S' AND IN_DVS_LCTO = 'N' THEN 1 END) AS QT_GFP_CSM_INST,
       SUM(CASE WHEN CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S' AND IN_DVS_LCTO = 'N' THEN ABS(DECIMAL(VL_TRAN,31,2)) ELSE DECIMAL(0,31,2) END) AS VL_ABS_GFP_CSM_INST
FROM B
GROUP BY CD_PRD, CD_NTZ_CTB_TRAN;
```

**O que devolver:** Uma linha por produto e natureza (tipicamente 4 se apenas C/D). 26 colunas: produto, natureza, QT_ORIGINAL, VL_ABS_ORIGINAL e pares QT_<cenário>/VL_ABS_<cenário> para CSM, CX, EVT, DVS, OCTR, IR, RADAR, CSM_D, GFP_EVT_INST, GFP_CX_INST e GFP_CSM_INST.

**O que será analisado:** Quantificar perda = original − mantido; percentual = perda/original × 100, se denominador > 0. As exclusões podem se sobrepor. Os cenários GFP_*_INST são apenas as combinações de indicadores sobre nossa base restrita, não a reprodução integral das consultas V7 (sem manuais, contas, grupo 13 etc.).


### Q05 — Cartão: compras, parcelas, faturas, tarifas e créditos

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q05.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
),
B AS (
    SELECT T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TIP_TRAN,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR,
        CASE WHEN K.NR_TRAN_INST_PCT IS NULL THEN 'N' ELSE 'S' END AS TEM_CMPT_CRT,
        K.CD_TIP_TRAN_CRT,
        K.TX_TIP_PGTO,
        K.TX_TIP_LNCD,
        K.NR_PCL_CPR,
        K.QT_PCL_CPR,
        K.TX_TIP_TARF,
        K.TX_TIP_CRD_CTRD,
        CASE WHEN K.NR_TRAN_INST_PCT IS NULL THEN 'SEM_COMPLEMENTO'
             WHEN K.DT_TRAN_FAT < T.DT_TRAN THEN 'FAT_ANTES'
             WHEN K.DT_TRAN_FAT = T.DT_TRAN THEN 'MESMA_DATA'
             WHEN K.DT_TRAN_FAT > T.DT_TRAN THEN 'FAT_DEPOIS'
             ELSE 'SEM_DATA' END AS RELACAO_DT_FAT,
        T.VL_TRAN
    FROM DB2GFP.TRAN_RLZD_INST_PCT T CROSS JOIN P
    LEFT JOIN DB2GFP.CMPT_TRAN_RLZD_CRT K
      ON K.NR_TRAN_INST_PCT = T.NR_TRAN_INST_PCT
    WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD = 9
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
)
SELECT CD_PRD, CD_NTZ_CTB_TRAN, CD_TIP_TRAN, CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT, IN_DVS_LCTO, IN_OCTR_TRAN, IN_TRAN_IR, TEM_CMPT_CRT, CD_TIP_TRAN_CRT, TX_TIP_PGTO, TX_TIP_LNCD, NR_PCL_CPR, QT_PCL_CPR, TX_TIP_TARF, TX_TIP_CRD_CTRD, RELACAO_DT_FAT,
       COUNT_BIG(*) AS QT_TRAN,
       SUM(DECIMAL(VL_TRAN,31,2)) AS VL_TOTAL,
       SUM(ABS(DECIMAL(VL_TRAN,31,2))) AS VL_ABS
FROM B
GROUP BY CD_PRD, CD_NTZ_CTB_TRAN, CD_TIP_TRAN, CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT, IN_DVS_LCTO, IN_OCTR_TRAN, IN_TRAN_IR, TEM_CMPT_CRT, CD_TIP_TRAN_CRT, TX_TIP_PGTO, TX_TIP_LNCD, NR_PCL_CPR, QT_PCL_CPR, TX_TIP_TARF, TX_TIP_CRD_CTRD, RELACAO_DT_FAT;
```

**O que devolver:** Uma linha por combinação de tipo/categoria, seis indicadores, presença de complemento, atributos de parcela/tipo de pagamento/tipo de lançamento/tarifa/crédito e relação da data de fatura com a data da transação; contagem e valores. Sem identificador de cartão ou fatura.

**O que será analisado:** Testar se CSM exclui parcelas ou pagamentos, se CX privilegia parcelas, se EVT sinaliza vencimentos, e se os padrões variam para estornos e juros. NR_PCL_CPR e QT_PCL_CPR são evidências auxiliares, não prova isolada do lançamento total. RELACAO_DT_FAT descreve a data armazenada, não presume que seja vencimento ou pagamento. Soma QT_TRAN deve corresponder ao produto 9 da Q03.


### Q06 — Conta corrente: tipos, históricos e possível mesma titularidade

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q06.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
),
B AS (
    SELECT T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TIP_TRAN,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR,
        K.CD_HST_TRAN, K.CD_SHST_TRAN,
        CASE WHEN K.NR_TRAN_INST_PCT IS NULL THEN 'SEM_COMPLEMENTO'
             WHEN K.NR_CPF_CNPJ_PGDR IS NULL OR K.NR_CPF_CNPJ_PGDR = 0
                  OR T.NR_CPF_CNPJ_TITR = 0 THEN 'SEM_DOCUMENTO_VALIDO'
             WHEN T.NR_CPF_CNPJ_TITR = K.NR_CPF_CNPJ_PGDR THEN 'DOCUMENTO_IGUAL'
             ELSE 'DOCUMENTO_DIFERENTE' END AS RELACAO_DOCUMENTO,
        T.VL_TRAN
    FROM DB2GFP.TRAN_RLZD_INST_PCT T CROSS JOIN P
    LEFT JOIN DB2GFP.CMPT_TRAN_RLZD_CC K
      ON K.NR_TRAN_INST_PCT = T.NR_TRAN_INST_PCT
    WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL' AND T.CD_PRD = 6
)
SELECT CD_PRD, CD_NTZ_CTB_TRAN, CD_TIP_TRAN, CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT, IN_DVS_LCTO, IN_OCTR_TRAN, IN_TRAN_IR, CD_HST_TRAN, CD_SHST_TRAN, RELACAO_DOCUMENTO,
       COUNT_BIG(*) AS QT_TRAN,
       SUM(DECIMAL(VL_TRAN,31,2)) AS VL_TOTAL,
       SUM(ABS(DECIMAL(VL_TRAN,31,2))) AS VL_ABS
FROM B
GROUP BY CD_PRD, CD_NTZ_CTB_TRAN, CD_TIP_TRAN, CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT, IN_DVS_LCTO, IN_OCTR_TRAN, IN_TRAN_IR, CD_HST_TRAN, CD_SHST_TRAN, RELACAO_DOCUMENTO;
```

**O que devolver:** Uma linha por produto/natureza/tipo/categoria atual e original/seis indicadores/histórico/sub-histórico/relação de documento; contagem e valores. Não retorna CPF/CNPJ.

**O que será analisado:** Investigar PIX, TED, fatura, transferências e operações com mesmo documento. A igualdade é um sinal de possível mesma titularidade; não comprova contraparte pareada nem validade do documento. O código de tran.txt não restringe a natureza, por isso manter C e D separados. Soma QT_TRAN deve corresponder ao produto 6 da Q03.


### Q07 — Lançamentos incluídos pelo cliente: manuais e derivados

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q07.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
),
B AS (
 SELECT T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TIP_TRAN,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR,
        CASE WHEN COALESCE(T.NR_TRAN_RLZD_OGM,0)=0 THEN 'MANUAL'
             ELSE 'DERIVADO' END AS ORIGEM_INCLUSAO,
        T.VL_TRAN
 FROM DB2GFP.TRAN_INCD_CLI T CROSS JOIN P
 WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
)
SELECT CD_PRD, CD_NTZ_CTB_TRAN, CD_TIP_TRAN, CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT, IN_OCTR_TRAN, IN_TRAN_IR, ORIGEM_INCLUSAO,
       COUNT_BIG(*) AS QT_TRAN,
       SUM(DECIMAL(VL_TRAN,31,2)) AS VL_TOTAL,
       SUM(ABS(DECIMAL(VL_TRAN,31,2))) AS VL_ABS
FROM B
GROUP BY CD_PRD, CD_NTZ_CTB_TRAN, CD_TIP_TRAN, CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT, IN_OCTR_TRAN, IN_TRAN_IR, ORIGEM_INCLUSAO;
```

**O que devolver:** Uma linha por origem MANUAL/DERIVADO, produto, natureza, tipo, categorias e cinco indicadores; contagem e valores.

**O que será analisado:** Compreender a representação alternativa utilizada pelo GFP. Não somar esses resultados ao universo institucional sem tratar a relação original-derivado. TRAN_INCD_CLI não contém IN_DVS_LCTO no catálogo fornecido.


### Q08 — Divisão: originais marcados e cobertura dos derivados

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q08.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
),
O AS (
 SELECT T.NR_TRAN_INST_PCT, T.CD_CLI, T.CD_PRD, T.CD_NTZ_CTB_TRAN,
        T.IN_DVS_LCTO, T.IN_VSLO_CSM, T.IN_VSLO_CX, T.IN_VSLO_EVT,
        T.VL_TRAN
 FROM DB2GFP.TRAN_RLZD_INST_PCT T CROSS JOIN P
 WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL' AND T.IN_DVS_LCTO = 'S'
),
D AS (
 SELECT T.NR_TRAN_RLZD_OGM, T.CD_CLI, T.CD_PRD, T.CD_NTZ_CTB_TRAN,
        COUNT_BIG(*) AS QT_DERIV,
        SUM(DECIMAL(T.VL_TRAN,31,2)) AS VL_DERIV
 FROM DB2GFP.TRAN_INCD_CLI T CROSS JOIN P
 WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL' AND COALESCE(T.NR_TRAN_RLZD_OGM,0) <> 0
 GROUP BY T.NR_TRAN_RLZD_OGM, T.CD_CLI, T.CD_PRD, T.CD_NTZ_CTB_TRAN
),
A AS (
 SELECT O.CD_PRD, O.CD_NTZ_CTB_TRAN, O.IN_VSLO_CSM, O.IN_VSLO_CX, O.IN_VSLO_EVT,
        O.VL_TRAN, COALESCE(D.QT_DERIV,0) AS QT_DERIV,
        COALESCE(D.VL_DERIV,0) AS VL_DERIV,
        CASE WHEN D.QT_DERIV IS NULL THEN 'SEM_DERIVADO_NO_ESCOPO'
             WHEN D.QT_DERIV = 1 THEN 'UM_DERIVADO_NO_ESCOPO'
             WHEN D.VL_DERIV = O.VL_TRAN THEN 'DOIS_OU_MAIS_VALOR_IGUAL'
             ELSE 'DOIS_OU_MAIS_VALOR_DIFERENTE' END AS SITUACAO
 FROM O LEFT JOIN D ON D.NR_TRAN_RLZD_OGM = O.NR_TRAN_INST_PCT
  AND D.CD_CLI = O.CD_CLI AND D.CD_PRD = O.CD_PRD
  AND D.CD_NTZ_CTB_TRAN = O.CD_NTZ_CTB_TRAN
)
SELECT CD_PRD, CD_NTZ_CTB_TRAN, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT, SITUACAO,
       COUNT_BIG(*) AS QT_ORIGINAIS, SUM(QT_DERIV) AS QT_DERIVADOS,
       SUM(DECIMAL(VL_TRAN,31,2)) AS VL_ORIGINAIS, SUM(VL_DERIV) AS VL_DERIVADOS
FROM A
GROUP BY CD_PRD, CD_NTZ_CTB_TRAN, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT, SITUACAO;
```

**O que devolver:** Uma linha por produto/natureza/três indicadores de visibilidade/situação de correspondência; quantidade de originais, quantidade de derivados e somas.

**O que será analisado:** Identificar o que se perde ao excluir DVS=S. Ausência de derivados no mesmo período, produto, natureza, MCI, moeda e estado não significa ausência absoluta: pode haver data diferente, exclusão lógica ou divergência de classificação. O resultado não prova reconciliação completa; exige investigação adicional se houver divergências.


### Q09 — Variação por instituição participante

**Prioridade:** Complementar recomendada.

**Arquivo esperado:** `Q09.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
)
SELECT
        T.CD_INST_PCT,
        T.NR_MCA_PCT_OPB,
        T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TIP_TRAN,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR,
        COUNT_BIG(*) AS QT_TRAN,
        SUM(DECIMAL(T.VL_TRAN,31,2)) AS VL_TOTAL,
        SUM(ABS(DECIMAL(T.VL_TRAN,31,2))) AS VL_ABS
FROM DB2GFP.TRAN_RLZD_INST_PCT T
CROSS JOIN P
WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
GROUP BY
        T.CD_INST_PCT,
        T.NR_MCA_PCT_OPB,
        T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TIP_TRAN,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR;
```

**O que devolver:** Uma linha por instituição/marca, produto, natureza, tipo, categorias e seis indicadores; contagem e valores. Marca nula deve ser preservada.

**O que será analisado:** Avaliar se o mesmo tipo/categoria tem marcação diferente entre instituições. Não presumir que uma marca representa BB sem tabela de referência ou confirmação. Se houver grupos muito pequenos, utilizar somente em ambiente autorizado ou omitir detalhes conforme normas internas.


### Q10 — Estado, moeda e produto fora do universo principal

**Prioridade:** Complementar recomendada.

**Arquivo esperado:** `Q10.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
)
SELECT T.CD_PRD, T.CD_EST_TRAN_INST, T.CD_TIP_MOE_CRR, T.CD_NTZ_CTB_TRAN,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR,
        COUNT_BIG(*) AS QT_TRAN,
        SUM(DECIMAL(T.VL_TRAN,31,2)) AS VL_TOTAL,
        SUM(ABS(DECIMAL(T.VL_TRAN,31,2))) AS VL_ABS
FROM DB2GFP.TRAN_RLZD_INST_PCT T CROSS JOIN P
WHERE T.DT_TRAN >= P.DT_INI AND T.DT_TRAN < P.DT_FIM_EXCL
GROUP BY T.CD_PRD, T.CD_EST_TRAN_INST, T.CD_TIP_MOE_CRR, T.CD_NTZ_CTB_TRAN,
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR;
```

**O que devolver:** Uma linha por produto/estado/moeda/natureza/combinação de indicadores; contagem e valores.

**O que será analisado:** Contextualizar agendamentos, deleções, outras moedas e produtos. Nunca somar valores de moedas diferentes como se fossem reais. Separar os resultados do universo principal. Filtrar produto 6/9, estado 0 e BRL na análise local deve reproduzir Q02 se a base não mudou.


### Q11 — Imposto de Renda: indicador versus código

**Prioridade:** Obrigatória.

**Arquivo esperado:** `Q11.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
)
SELECT
        T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TRAN_IR,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_TRAN_IR,
        T.IN_OCTR_TRAN,
        T.IN_VSLO_CSM,
        T.IN_DVS_LCTO,
        COUNT_BIG(*) AS QT_TRAN,
        SUM(DECIMAL(T.VL_TRAN,31,2)) AS VL_TOTAL,
        SUM(ABS(DECIMAL(T.VL_TRAN,31,2))) AS VL_ABS
FROM DB2GFP.TRAN_RLZD_INST_PCT T
CROSS JOIN P
WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
GROUP BY
        T.CD_PRD,
        T.CD_NTZ_CTB_TRAN,
        T.CD_TRAN_IR,
        T.CD_CTGR_TRAN,
        T.CD_CTGR_TRAN_OGNL,
        T.IN_TRAN_IR,
        T.IN_OCTR_TRAN,
        T.IN_VSLO_CSM,
        T.IN_DVS_LCTO;
```

**O que devolver:** Uma linha por produto/natureza/código IR/categorias e marcações; contagem e valores.

**O que será analisado:** Verificar relação observada entre IN_TRAN_IR e CD_TRAN_IR. Um código não zero não comprova elegibilidade fiscal; não presumir lista de códigos dedutíveis. Comparar ocultação e consumo com a lógica V7.


### Q12 — Contas: efeito de visibilidade e existência de cadastro

**Prioridade:** Complementar recomendada.

**Arquivo esperado:** `Q12.csv`.

**SQL:**

```sql
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
),
B AS (
 SELECT T.CD_PRD, T.CD_NTZ_CTB_TRAN, T.IN_VSLO_CSM, T.IN_VSLO_CX, T.IN_VSLO_EVT,
        CASE WHEN A.CD_CLI_TITR_CT IS NULL THEN 'SEM_CONTA_CORRESPONDENTE'
             ELSE 'COM_CONTA_CORRESPONDENTE' END AS SITUACAO_CONTA,
        A.IN_EXB_DADO_CT, A.IN_AUTZ_EXB_TRAN, T.VL_TRAN
 FROM DB2GFP.TRAN_RLZD_INST_PCT T CROSS JOIN P
 LEFT JOIN DB2GFP.INF_OPB_CT_CLI A
 ON A.CD_CLI_TITR_CT=T.CD_CLI AND A.NR_MCA_PCT_OPB=T.NR_MCA_PCT_OPB
 AND A.NR_SEQL_CT_CLI=T.NR_SEQL_CT_CLI
 WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
)
SELECT CD_PRD, CD_NTZ_CTB_TRAN, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT,
       SITUACAO_CONTA, IN_EXB_DADO_CT, IN_AUTZ_EXB_TRAN,
       COUNT_BIG(*) AS QT_TRAN, SUM(DECIMAL(VL_TRAN,31,2)) AS VL_TOTAL,
       SUM(ABS(DECIMAL(VL_TRAN,31,2))) AS VL_ABS
FROM B
GROUP BY CD_PRD, CD_NTZ_CTB_TRAN, IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT,
       SITUACAO_CONTA, IN_EXB_DADO_CT, IN_AUTZ_EXB_TRAN;
```

**O que devolver:** Uma linha por produto/natureza/visibilidade/situação do cadastro/indicadores da conta; contagem e valores.

**O que será analisado:** Separar atributos da conta dos indicadores da transação. A consulta V7 seleciona contas segundo parâmetros e faz INNER JOIN; não usar ausência cadastral nem IN_EXB_DADO_CT como prova de irrelevância econômica. IN_AUTZ_EXB_TRAN é apenas estudado, não é predicado explícito das consultas V7 examinadas. Respeitar controles de autorização existentes.

## 8. Exemplos de retorno (inteiramente fictícios)

Os valores a seguir servem exclusivamente para explicar o formato; não antecipam resultados do GFP.

**Q02 — combinações:**

| IN_VSLO_CSM | IN_VSLO_CX | IN_VSLO_EVT | IN_DVS_LCTO | IN_OCTR_TRAN | IN_TRAN_IR | QT_TRAN | VL_TOTAL | VL_ABS |
|---|---|---|---|---|---|---:|---:|---:|
| S | S | S | N | N | N | 850000 | 12000000.00 | 12000000.00 |
| N | S | S | N | N | N | 320000 | 8700000.00 | 8700000.00 |
| S | N | S | N | N | N | 150000 | 4200000.00 | 4200000.00 |

**Q03 — projeção de algumas colunas** (o CSV deve conter todas as 14 colunas):

| CD_PRD | CD_NTZ_CTB_TRAN | CD_TIP_TRAN | CD_CTGR_TRAN | CSM | CX | EVT | QT_TRAN |
|---|---|---|---|---|---|---|---:|
| 6 | D | PIX | 101 | S | S | S | 80000 |
| 6 | D | PIX | 101 | N | S | S | 30000 |
| 9 | D | TIPO_EXEMPLO | 202 | S | N | S | 15000 |

Os códigos 101/202 e TIPO_EXEMPLO são fictícios. Os nomes reais virão de Q01.

**Q04 — projeção de algumas colunas:**

| CD_PRD | CD_NTZ_CTB_TRAN | QT_ORIGINAL | QT_CSM | QT_CX | QT_EVT | QT_RADAR |
|---|---|---:|---:|---:|---:|---:|
| 6 | C | 100000 | 20000 | 95000 | 98000 | 100000 |
| 6 | D | 150000 | 90000 | 140000 | 145000 | 90000 |
| 9 | C | 30000 | 5000 | 25000 | 28000 | 30000 |
| 9 | D | 200000 | 120000 | 130000 | 180000 | 120000 |

No exemplo de débitos de cartão, CSM=S conserva 120.000 de 200.000 (60%) e exclui 80.000 (40%). Isso não significa que excluiu 40% das despesas reais; é perda de registros elegíveis no recorte. Avaliar VL_ABS em paralelo. Para créditos, a regra vigente mantém todos os registros de natureza C, mesmo CSM=N.

## 9. Pacote de respostas a devolver

**Preferência: um ZIP com todos os CSVs e um arquivo `MANIFESTO.md`.** Também aceito CSVs individuais ou uma planilha com uma aba por consulta, desde que não trunque linhas. Não é necessário enviar dados transacionais individuais, MCI, documentos pessoais, números de conta, cartão, fatura, IDs de transação ou descrições livres. Consultas Q06/Q08/Q12 usam chaves/documentos internamente para agrupar; não os projetam no resultado. Se grupos raros puderem identificar pessoas, seguir a política de compartilhamento da instituição; relatar qualquer supressão, pois ela afeta as validações.

### 9.1 Checklist

- [ ] `Q00.csv` — Controle do período e universo (Obrigatória).
- [ ] `Q01.csv` — Tesauro de categorias e grupos (Obrigatória).
- [ ] `Q01B.csv` — Cadastro dos grupos — inclusive grupo 13 (Obrigatória).
- [ ] `Q02.csv` — Combinações reais dos seis indicadores (Obrigatória).
- [ ] `Q03.csv` — Matriz principal: tipo, natureza, categoria e indicadores (Obrigatória).
- [ ] `Q04.csv` — Impacto isolado e combinado dos filtros (Obrigatória).
- [ ] `Q05.csv` — Cartão: compras, parcelas, faturas, tarifas e créditos (Obrigatória).
- [ ] `Q06.csv` — Conta corrente: tipos, históricos e possível mesma titularidade (Obrigatória).
- [ ] `Q07.csv` — Lançamentos incluídos pelo cliente: manuais e derivados (Obrigatória).
- [ ] `Q08.csv` — Divisão: originais marcados e cobertura dos derivados (Obrigatória).
- [ ] `Q09.csv` — Variação por instituição participante (Complementar recomendada).
- [ ] `Q10.csv` — Estado, moeda e produto fora do universo principal (Complementar recomendada).
- [ ] `Q11.csv` — Imposto de Renda: indicador versus código (Obrigatória).
- [ ] `Q12.csv` — Contas: efeito de visibilidade e existência de cadastro (Complementar recomendada).
- [ ] `MANIFESTO.md` — período, ambiente lógico, execução e observações.
- [ ] Se disponível e autorizado: código de atribuição/atualização dos indicadores, sem credenciais nem dados pessoais.

### 9.2 Modelo de manifesto (copiar e preencher)

```markdown
# Resultado do estudo de indicadores GFP

- Data inicial (inclusiva): YYYY-MM-DD
- Data final (exclusiva): YYYY-MM-DD
- Número de dias:
- Data/hora de execução:
- Escopo: população disponível/autorizada (descrever restrições, se houver)
- Ambiente lógico (sem credenciais):
- Filtros adicionais aplicados: nenhum / descrever
- Isolamento de leitura, se conhecido:
- Houve alterações de SQL? quais?
- Houve limites de linhas, supressão de grupos ou arredondamentos?

| Consulta | Status (OK / VAZIA / ERRO / NÃO EXECUTADA) | Linhas exportadas | Observações |
|---|---|---:|---|
| Q00 | | | |
| Q01 | | | |
| Q01B | | | |
| Q02 | | | |
| Q03 | | | |
| Q04 | | | |
| Q05 | | | |
| Q06 | | | |
| Q07 | | | |
| Q08 | | | |
| Q09 | | | |
| Q10 | | | |
| Q11 | | | |
| Q12 | | | |
```

### 9.3 Formato dos arquivos

- Cabeçalhos exatamente como retornados pelo SQL, uma linha por grupo.
- CSV UTF-8, com separador consistente (`;` ou `,`); informar o separador e o padrão decimal. Preferência por ponto decimal e sem separador de milhares.
- Preservar `NULL` como nulo (informar representação) e valores vazios como vazios quando a ferramenta permitir; não substituir tudo por zero.
- Não enviar capturas de tela como única fonte; não enviar apenas TOP N. A consulta vazia é uma evidência: enviar cabeçalho e registrar VAZIA.
- Se a ferramenta falhar, enviar erro SQLCODE/SQLSTATE e trecho da consulta sem credenciais, não inventar resultado.

## 10. Validação dos resultados recebidos

| Controle | Condição esperada | Se falhar |
|---|---|---|
| Datas | Mesmos limites em todas as consultas temporais | Reexecutar ou separar populações |
| Q00 versus Q02/Q03 | Soma QT_TRAN e somas de valores iguais | Investigar alterações entre execuções, supressões e recorte |
| Q04 versus Q03 | QT_ORIGINAL por produto/natureza igual; cada cenário reproduzível com Q03 | Verificar CASE, domínio e consistência |
| Q05/Q06 | Total cartão/conta igual ao produto 9/6 de Q03 | Verificar joins ou mudança de dados |
| Q09/Q11/Q12 | Totais iguais a Q03 se escopo integral | Verificar cadastro, agrupamento, mudanças e restrições |
| Q10 | Subconjunto produto 6/9, estado 0, BRL reproduz Q02 | Verificar recorte e temporalidade |
| Q08 | QT_ORIGINAIS total igual a Q03 com DVS=S | Verificar escopo e concorrência |
| Q07 | População distinta; não deve ser somada automaticamente à Q03 | Avaliar origem e vínculos |
| Categorias | Uma linha por chave em Q01/Q01B | Não multiplicar registros no enriquecimento |
| Cenários Q04 | 0 ≤ QT_CENARIO ≤ QT_ORIGINAL | Investigar contagem e universo |
| Valores | VL_ABS ≥ ABS(VL_TOTAL) no mesmo universo | Verificar formato, arredondamento e sinal |
| Domínios | S/N esperados, C/D esperados; preservar exceções | Investigar sem recodificar silenciosamente |

Diferenças entre consultas executadas em horários distintos podem refletir inserções/atualizações reais. O estudo não assume snapshot comum; registrar horários. Ausência de caso na janela é ausência observada, não prova de impossibilidade. Se não houver dados suficientes para uma conclusão, estender a investigação de modo dirigido; não generalizar automaticamente.

## 11. Roteiro de análise posterior

### 11.1 Perfil dos indicadores

Para cada campo: valores observados, proporção S/N/outros, quantidade, volume absoluto, produto, natureza, tipo, categoria, instituição e diferenças. Calcular `QT_EXCLUIDA = QT_ORIGINAL - QT_MANTIDA`, `PCT_EXCLUIDA = 100 * QT_EXCLUIDA / QT_ORIGINAL`, `VL_ABS_EXCLUIDO = VL_ABS_ORIGINAL - VL_ABS_MANTIDO`. Percentual de valor somente se denominador positivo. Não somar exclusões isoladas, pois podem se sobrepor. Construir matriz CSM/CX/EVT e diferenças de DVS/OCTR/IR dentro de cada combinação.

### 11.2 Enriquecimento sem perda de registros

Relacionar Q03 a Q01 por categoria atual e por categoria original; relacionar grupos Q01B. Preservar não mapeados. Exibir mudança `CD_CTGR_TRAN <> CD_CTGR_TRAN_OGNL` como diferença de classificação atual/original, não como prova de quando ou por quem ocorreu. Cruzar resultados especializados Q05/Q06 para explicar padrões. Usar Q08 para avaliar divisão, Q11 para IR e Q12 para diferenciar marcações da conta. Q09 analisa heterogeneidade institucional. Q10 distingue o recorte de estudo da tabela completa.

### 11.3 Matriz final a produzir após os dados

| Campo da matriz | Conteúdo esperado |
|---|---|
| ID_REGRA | Identificador versionável da hipótese/regra |
| Produto/natureza/tipo/categoria | Combinação observada, com original e atual |
| Indicadores observados | Distribuição real dos seis atributos |
| Evidência | Qxx, volume, frequência, exemplos anonimizados autorizados |
| Natureza econômica | Consumo, renda, transferência, dívida, investimento, ajuste, indeterminada etc. |
| O que o filtro mantém/exclui | Contagens e valores; exceções |
| Fluxo de caixa | Elegibilidade e critério temporal/valor (proposta) |
| Radar | Dimensões afetadas, elegibilidade e critério temporal/valor (proposta) |
| Reconciliação | Contraparte necessária, risco de omissão/dupla contagem |
| Confiança | Documentada / observada / inferida / pendente |
| Decisão | Manter, excluir de uma métrica, investigar, ou não aplicar filtro |
| Justificativa | Evidência, regra de atribuição se disponível, limitações |

### 11.4 Origem da atribuição — investigação de código (não é SQL obrigatório)

O arquivo `tran.txt` demonstra o consumo dos indicadores. Procurar no repositório GFP, se autorizado, ocorrências dos seis nomes físicos, atributos Java equivalentes, mapeamentos ORM, rotinas de sincronização e classificação, `INSERT`, `UPDATE`, `MERGE`, regras de parcelamento, contestação, ocultação, divisão e IR. Localizar também tabelas de regras/tesauro que possam determinar os valores e identificar mudanças por instituição/produto. Devolver trechos relevantes com nome de arquivo e contexto, sem segredos. Um padrão estatístico pode sugerir a regra, mas não substitui a lógica de escrita.

## 12. Impacto sobre a regra 7 e decisões futuras

A regra vigente é:

```sql
CD_PRD IN (6, 9)
AND CD_EST_TRAN_INST = 0
AND CD_TIP_MOE_CRR = 'BRL'
AND (CD_NTZ_CTB_TRAN = 'C'
     OR (CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S'))
```

Além disso, `DT_TRAN` deve estar entre as datas inclusivas do ciclo por MCI; cada `NR_TRAN_INST_PCT` conta uma vez. Os cinco dias externos são contexto de reconciliação, não contagem. O estudo utiliza outra janela e não calcula o resultado individual.

A identidade especificada no notebook `QT_TRANS_TOTAL = QT_MOV_CICLO - 2 * QT_PARES_EXATOS - QT_PARES_BORDA` só se mantém se contagem e pareamento forem compatíveis, sem reuso de pontas e sem exclusões adicionais não contabilizadas. Uma contraparte excluída por CSM pode impedir um pareamento. O estudo deverá indicar quais casos exigem revisão dessa dependência. Não neutralizar economicamente operações apenas por serem invisíveis e não confundir neutralização de pares com classificação econômica.

**Recomendação provisória:** preservar a base original no escopo autorizado; aplicar regras específicas por finalidade após conhecer os indicadores. Pagamento de fatura pode ser saída de caixa sem novo consumo, e ainda ser relevante para endividamento. Crédito não é sinônimo de receita e débito não é sinônimo de despesa. Não incluir/excluir automaticamente grupo 13, DVS, OCTR, IR ou indicadores de conta sem justificativa. A decisão final depende dos retornos.

## 13. Limites, premissas e conclusão

- Foram adotados 30 dias completos como janela padrão, com alternativa de 15 dias. Nenhuma consulta temporal ultrapassa 30 dias no exemplo. Cadastros não têm recorte temporal.
- O recorte principal mantém produtos 6/9, efetivação e BRL; isso pode esconder comportamentos presentes apenas fora dele. Q10 investiga essa limitação.
- As consultas são de diagnóstico, não de produção. Não foram executadas no DB2. Não há resultados reais neste documento. Exemplos são fictícios.
- O catálogo informa chaves e colunas; a análise de consultas de leitura não demonstra todas as regras de escrita, dados disponíveis nem versão em execução.
- Não foram solicitadas transações individuais. A distinção entre compra e parcela, fatura e contrapartes pode exigir evidências adicionais anonimizadas ou código de atribuição, somente depois de identificar lacunas.
- A escolha de manter somas assinadas e absolutas separadas evita interpretar valores agregados como saldo ou consumo sem validar sua semântica. Não somar moedas distintas.

O propósito é receber evidências suficientes para explicar **o que cada indicador faz, o que ele retira do universo, por que o GFP o utiliza e quando essa exclusão deve ou não ser aplicada ao Radar**. A regra de contagem deve ser consequência do entendimento das transações, não ponto de partida para eliminá-las.
