# Estudo dos indicadores transacionais do GFP — aplicabilidade ao Radar Financeiro

**Estado:** investigação aberta; nenhum filtro novo homologado.  
**Objetivo:** descobrir exatamente o que cada indicador original do GFP sinaliza, mantém e remove, e decidir se, quando e por que deve ser aplicado ao Radar Financeiro.

## 1. Escopo exclusivo

Tabela principal: `DB2GFP.TRAN_RLZD_INST_PCT`.

| Indicador | Finalidade documentada a verificar nas fontes | Condição a investigar |
|---|---|---|
| `IN_VSLO_CSM` | Visualização no perfil de consumo | `= 'S'` |
| `IN_VSLO_CX` | Visualização no fluxo de caixa | `= 'S'` |
| `IN_VSLO_EVT` | Visualização nos eventos | `= 'S'` |
| `IN_DVS_LCTO` | Divisão de lançamento | `= 'N'` |
| `IN_OCTR_TRAN` | Ocultação de transação | `= 'N'` (comparar com `<> 'S'` do GFP) |
| `IN_TRAN_IR` | Marcação para Imposto de Renda | `= 'S'` (somente diagnóstico) |

Para cada indicador, responder: definição, domínio, tipo, default, finalidade, condições de leitura no GFP, lógica de atribuição (se encontrada), quais operações recebem cada valor, quais ficam e quais saem pelo filtro, quantidade e valor afetados, diferenças entre naturezas/produtos/tipos/categorias, interações, exceções, recomendação e justificativa para o Radar. Distinguir `S`/`N` de valores inesperados. Não presumir que visibilidade implica validade econômica.

**Não faz parte do estudo:** redesenhar a arquitetura, revisar orçamento, classes essenciais/não essenciais, classificação tributária, patrimônio, matriz de categorias ou algoritmo de reconciliação. Usar essas informações somente quando necessárias para interpretar um indicador. O mapa Radar é apoio descritivo, não verdade de origem nem um filtro do estudo. Não alterar a regra `QT_MOV_CICLO` antes da conclusão.

## 2. Fontes e organização

- `01_FONTES/`: originais ERwin, SYSIBM, código Java/SQL GFP, notebook Radar e mapa de categorias fornecido na conversa. O mapa é referência auxiliar; verificar sua correspondência com o tesauro real.
- `02_DOCUMENTACAO/`: documentos anteriores, preservados para rastreabilidade. Este README prevalece em caso de divergência de escopo.
- `03_CONSULTAS/`: arquivo consolidado original e consultas separadas por ID e prioridade. Não executar duas vezes por existirem as duas apresentações.
- `04_RESULTADOS_DB2/`: destino dos CSVs e manifesto de execução.
- `05_CONCLUSOES/`: modelos para preencher após a investigação, não resultados já validados.

O `tran.txt` mostra principalmente a lógica de leitura. Para comprovar a atribuição dos indicadores, procurar também rotinas de INSERT, UPDATE, MERGE, classificação, sincronização e respectivas regras de negócio. Se encontradas, incluir em `01_FONTES/` sem modificar os originais.

## 3. Universo, período e premissas

- Preferir 30 dias completos; 15 dias são aceitáveis. A janela inicial é suficiente para iniciar a análise, não para garantir a ocorrência de todos os casos possíveis.
- Fixar a mesma data inicial inclusiva e final exclusiva nas consultas comparáveis. A janela padrão vai de `2026-10-26` a `2026-11-25`, com fim exclusivo e 30 dias completos. O notebook aplica os dois limites às CTEs `P` de todas as consultas temporais. Observar o escopo específico documentado para relacionamentos com derivados.
- População autorizada sem filtro por MCI individual. Universo principal: produtos 6 e 9, `CD_EST_TRAN_INST = 0`, `CD_TIP_MOE_CRR = 'BRL'`, `DT_TRAN` no período.
- Não aplicar previamente nenhum dos seis indicadores. Não aplicar a regra atual do Radar, reconciliação ou elegibilidade pelo mapa na extração principal.
- Categorias, grupos, tipos, complementos de CC/cartão e instituições são meios de identificação, não filtros antecipados. Preservar casos desconhecidos e valores inesperados.
- Resultados agregados; não enviar CPF, MCI, número de conta/cartão, IDs transacionais ou descrição livre. Os arquivos-fonte podem conter identificadores ou código interno: manter em ambiente autorizado, revisar antes de compartilhar.
- Q07/Q08 analisam outra tabela ou relacionamento com o original; Q10 expande o universo. Não somar seus totais ao universo principal.

## 4. Ordem de execução e retorno esperado

O [notebook de execução](ESTUDO_RADAR.ipynb) executa as consultas avulsas em sequência e exporta os resultados agregados com cabeçalhos. Os campos e a interpretação de cada consulta estão no [caderno técnico](02_DOCUMENTACAO/Estudo_Indicadores_GFP_Radar.md).

| ID | Prioridade | Resultado esperado / questão respondida |
|---|---|---|
| Q00 | Principal | Uma linha de controle do período, quantidade e valores; referência para conciliar as consultas. |
| Q01 | Apoio principal | Cadastro de categorias, natureza e grupos; identifica a natureza das operações. |
| Q01B | Apoio principal | Cadastro dos grupos, inclusive 13; esclarece o filtro de grupo do GFP. |
| Q02 | Principal | Combinações reais dos seis indicadores, quantidade e valores; inclui padrões raros. |
| Q03 | Essencial | Matriz por produto, natureza, tipo, categoria atual/original e indicadores; identifica exatamente quais classes de lançamentos ficam e saem. |
| Q04 | Essencial | Impacto isolado e combinado dos filtros; quantifica retenção e exclusão. |
| Q05 | Principal | Detalhamento de cartão: tipo, categoria, parcelamento e indicadores; diferencia compras, parcelas, pagamentos e demais representações. |
| Q06 | Principal | Detalhamento de conta corrente por tipos, históricos e possível mesma titularidade; sem expor identificadores. |
| Q07 | Principal (DVS) | Lançamentos incluídos pelo cliente, manuais e derivados; demonstra o universo relacionado à divisão. |
| Q08 | Principal (DVS) | Correspondência entre originais divididos e derivados; mede risco de perder registros ao aplicar DVS. |
| Q11 | Principal (IR) | Relação entre `IN_TRAN_IR` e `CD_TRAN_IR`, quantidade e valor; verifica o uso tributário. |
| Q09 | Complementar | Diferenças por instituição; usar se necessário para explicar divergências. |
| Q10 | Complementar | Estado, moeda e produto fora do escopo principal; usar se necessário para explicar exceções. |
| Q12 | Fora do escopo inicial | Indicadores de visualização de contas; preservado apenas por rastreabilidade. Não executar nesta etapa. |

### Executar e baixar o pacote

1. Abra o notebook na raiz do projeto no JupyterLab corporativo. Para a primeira execução, mantenha `somente_teste_reduzido = True`. A sessão carrega Spark V2, DB2 V3 e HDFS V1 nessa ordem. O modo reduzido prepara e tria os 13 SQLs, testa o log do Spark, executa uma única CTE de data e decimal em `SYSIBM.SYSDUMMY1` com isolamento READ_COMMITTED e timeout de 60 segundos, lê o horário UTC do diretório e publica `HOMOLOGACAO_GFP.zip` com um arquivo sintético. Esse pacote serve exclusivamente para a homologação técnica.
2. Para testar também a transferência nessa mesma execução, configure `baixar_zip_jupyterlab = True` e confira o alias `cluster_bbmagic` da sessão. O aceite do teste reduzido requer a mensagem de aprovação no driver e, quando o download for habilitado, a confirmação do SHA-256 no JupyterLab.
3. Após o aceite, configure `somente_teste_reduzido = False` para a extração definitiva. Confira as [13 consultas preparadas para a janela padrão](03_CONSULTAS/SQLs_preparados_30_dias.zip). O pacote de conferência contém o texto individual de Q00 a Q11, incluindo Q01B, Q09 e Q10. A Q12 consta apenas no material histórico. Se alterar a janela, consulte os SQLs que o notebook grava no ZIP da própria execução.
4. Use `destino_hdfs = None` para criar a estrutura `ESTUDO_INDICADORES_GFP/04_RESULTADOS_DB2` na home HDFS. Para um destino explícito, informe um diretório existente no mesmo filesystem HDFS da sessão. Cada execução cria um subdiretório exclusivo com permissão 700. Os arquivos são publicados pelo HDFS V1 com permissão 600 e sem sobrescrita.
5. Execute o notebook integralmente. O pacote completo contém 13 CSVs, 13 SQLs, manifesto, notebook sem saídas de execução e módulo do estudo. O caminho HDFS e o SHA-256 são impressos após a publicação. Consulte o manifesto se a execução sinalizar erro ou divergência.

Uma falha de consulta mantém o SQL da tentativa e preserva os resultados das outras consultas. Uma consulta vazia bem-sucedida produz CSV com cabeçalho. A limpeza só retira os intermediários da execução depois da publicação validada. Se a validação ou a publicação falhar, os intermediários ficam no HDFS.

### Integração e evidências

| Responsabilidade | Implementação |
|---|---|
| JDBC | O DB2 V3 abre e confirma uma conexão de leitura com `setReadOnly(True)`, autocommit e `READ_COMMITTED`. `blocos_nativos()` usa `sql_nativo()` para executar as CTEs. O estudo reutiliza a conexão e usa `diagnosticar_erro()` para registrar códigos JDBC sem a mensagem bruta. `testar_conexao()` fica disponível para diagnóstico isolado. |
| Arquivos | O HDFS V1 cria o diretório, grava texto e CSV, compacta o inventário explícito, valida tamanhos e CRC, calcula o SHA-256 e publica sem sobrescrita. A compactação já inclui a validação. O ZIP é copiado temporariamente ao disco do driver para essa etapa. |
| Estudo | O módulo prepara os SQLs, exporta os agregados, preserva decimais, confere os resultados e registra o manifesto. `PastaResultados` guarda apenas a pasta e o inventário da execução e coordena a limpeza. |

**Testes locais.** Rode `python -B -m unittest discover -s tests -v` na raiz. A suíte carrega os três gerenciadores no mesmo namespace, com JVM, HDFS e BBMagic simulados. Executa as consultas em SQLite com dados sintéticos e adaptações para funções DB2. Confere os SQLs distribuídos, os controles, os pacotes completo e parcial e o tratamento de cópia local corrompida, destino existente e recibo de outra execução.

**Sessão Spark local.** As células dos três gerenciadores foram carregadas na ordem do notebook em Apache Spark 3.5.4 `local[1]`. Passaram a normalização de DATE e TIMESTAMP na V3, o log do Spark, a conversão UTC de um FileStatus Hadoop sintético na JVM, um SELECT no Spark e a triagem dos 13 SQLs. O HDFS V1 usa o alias `HdfsDateTime` para preservar a referência compartilhada ao módulo Python `datetime`.

**Ambiente corporativo.** A equipe informou aprovação de 38 testes dos gerenciadores e de dois testes simulados de integração do estudo, cobrindo pacotes completo e parcial. Em verificações corporativas anteriores, a equipe confirmou JDBC nativo com CTE e leitura explícita, operações HDFS e download BBMagic. O teste reduzido desta revisão com a sessão e o cluster corporativos segue pendente.

**Download no JupyterLab.** A célula opcional importa um recibo de uma linha com o identificador de execução, o caminho e o SHA-256. Usa a identidade local da sessão e o cluster configurado para baixar o arquivo pelo BBMagic. A cópia fica em diretório temporário privado até a conferência do hash. A publicação local usa um hard link exclusivo, que requer suporte do filesystem da pasta do notebook. Se o kernel interromper o Run All após publicar um pacote parcial, execute somente a última célula com o download habilitado. O caminho HDFS impresso continua disponível se o cliente corporativo não oferecer a exportação do recibo ou o filesystem local recusar o link. A opção `-o` está documentada no [Sparkmagic](https://github.com/jupyter-incubator/sparkmagic/blob/master/sparkmagic/sparkmagic/kernels/kernelmagics.py).

**Pendências dos gerenciadores.** Uma falha simultânea no fechamento de recursos pode ocultar a falha primária no DB2 V3. O código do HDFS V1 tem risco semelhante se a gravação e o fechamento falharem juntos. Os gerenciadores devem tratar esses casos em suas próprias suítes. O estudo mantém o diagnóstico sanitizado e preserva os arquivos intermediários caso a publicação do ZIP falhe.

## 5. Metodologia de análise

1. **Documental:** confirmar definições, valores, defaults e exemplos em ERwin/SYSIBM. Registrar divergências.
2. **Código:** localizar os filtros efetivos e separar critérios de leitura de regras de atribuição; conferir natureza, produto, união de originais e derivados e filtros adicionais.
3. **Empírica:** observar todas as combinações e distribuições, por tipo/categoria/produto/natureza. Identificar padrões e exceções, inclusive valores fora do domínio esperado.
4. **Exclusão:** comparar universo sem filtro versus cada condição e combinações. Identificar exatamente quais classes são mantidas/removidas, quantidade, valor registrado e valor absoluto; não confundir soma de valores registrados com saldo, renda ou consumo. Exclusões podem se sobrepor.
5. **Exceções:** examinar divergências dentro de uma mesma categoria; solicitar complementos somente quando necessários. Padrão empírico não comprova causalidade nem regra de atribuição.
6. **Aplicabilidade:** decidir por indicador entre aplicar integralmente, condicionalmente, não aplicar, apenas informativo ou pendente. Especificar condição SQL e justificativa, inclusive riscos de perder possíveis contrapartes da reconciliação.

## 6. Critérios de qualidade e validação

- Conciliação de totais de Q00, Q02, Q03 e Q04 quando os universos são idênticos; verificar multiplicação por joins e distinguir totais específicos. Q00 sem dados deve ser interpretada como janela vazia, não inexistência universal de casos.
- Conferir domínio e exceções; documentar valores inesperados, categorias sem correspondência e divergência de natureza.
- Separar evidência documental (catálogo/código), empírica (DB2, período observado), inferência, hipótese e pendência. Citar arquivo/trecho/consulta e período em cada conclusão.
- Distinguir exclusão por indicador, neutralização por reconciliação e exclusão por outra condição. Não somar exclusões sobrepostas.
- Não tratar uma janela sem ocorrência como prova de inexistência da situação.
- SQLs não executados; registrar versão, isolamento e eventuais alterações. As consultas com `WITH UR` são exploratórias; homologação requer consistência de leitura adequada ao ambiente.

## 7. Entregáveis de encerramento

- Dicionário técnico dos seis indicadores com fontes e limitações.
- Matriz de combinações observadas e operações mantidas/removidas.
- Impacto quantitativo e financeiro dos filtros.
- Exceções, divergências e pendências.
- Matriz de decisão por indicador, com aplicabilidade, condição e justificativa.
- Proposta de SQL final para o Radar apenas depois de fundamentadas as decisões.

**Critério de conclusão:** saber o que cada indicador efetivamente sinaliza, o que sua aplicação mantém/remove dentro do escopo observado, como se combina com outros indicadores e por que deve ou não ser utilizado no Radar. Lacunas devem permanecer explícitas. Não avançar para revisão de regras paralelas.
