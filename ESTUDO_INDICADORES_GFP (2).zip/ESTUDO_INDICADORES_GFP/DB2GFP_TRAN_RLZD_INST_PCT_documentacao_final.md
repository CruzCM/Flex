# DB2GFP.TRAN_RLZD_INST_PCT — Documentação técnica consolidada

**Transação realizada em instituição participante**  
**Versão:** 2.0 — final | **Data de referência:** 26/11/2026  
**Plataforma:** IBM Db2 13 for z/OS | versão JDBC reportada: `DSN13018`

## 1. Identificação, finalidade e granularidade

A tabela reúne transações financeiras de contas e cartões de crédito do Banco do Brasil e de instituições participantes do Open Banking com as quais o cliente mantém relacionamento. O modelo Erwin descreve sua finalidade como a unificação dessas transações em uma estrutura destinada a disponibilizar um extrato consolidado.

A unidade de registro é a transação identificada por `NR_TRAN_INST_PCT`, e não o cliente, a conta, a categoria ou o dia. Um cliente pode possuir múltiplos registros, contas, produtos, instituições e moedas. A chave técnica não comprova unicidade de eventos financeiros externos nem ordenação cronológica.

| Propriedade | Valor |
|---|---|
| Nome qualificado | `DB2GFP.TRAN_RLZD_INST_PCT` |
| Nome lógico | Transação realizada em instituição participante |
| Objeto Erwin | `O_Id 9640` |
| Colunas físicas | 35 |
| Colunas obrigatórias (`NOT NULL`) | 25 |
| Colunas anuláveis | 10 |
| Chave primária | `NR_TRAN_INST_PCT` |
| Índices físicos identificados | 2 |
| Partições físicas | 100 |
| Chave de particionamento | `NR_PTC` |
| Volume estimado | 34.196.155.517 chaves primárias distintas |
| Clientes distintos estimados | 37.100.966 |
| Atualização das estatísticas | 07/11/2026 18:12:04.781937 |

**Escopo:** exclusivamente esta tabela. As informações físicas provêm das consultas ao catálogo do DB2 executadas em 26/11/2026; as definições semânticas provêm do modelo Erwin; os comportamentos de dados provêm de testes seletivos. Os valores estatísticos não são contagens atuais exatas.

### 1.1 Critérios de evidência

- **Físico:** característica retornada pelo catálogo do DB2.
- **Modelo:** definição de negócio ou regra descrita no Erwin, não necessariamente imposta pelo banco.
- **Observado:** resultado empírico da população consultada; não generalizado para toda a tabela.
- **Recomendação:** prática de utilização, não uma restrição da estrutura.

## 2. Organização lógica dos atributos

| Grupo | Atributos |
|---|---|
| Identificação e partição | `NR_TRAN_INST_PCT`, `NR_PTC`, `CD_CLI`, `CD_TIP_PSS`, `NR_CPF_CNPJ_TITR` |
| Instituição e conta | `NR_MCA_PCT_OPB`, `CD_INST_PCT`, `NR_AG_TITR`, `CD_CT_TITR`, `DV_CT_TITR`, `NR_SEQL_CT_CLI` |
| Produto e características financeiras | `CD_PRD`, `VL_TRAN`, `CD_TIP_MOE_CRR`, `CD_NTZ_CTB_TRAN`, `CD_EST_TRAN_INST`, `CD_TIP_TRAN` |
| Descrições | `TX_DCR_TRAN`, `TX_CMPR_DCR_TRAN`, `TX_DCR_TRAN_OGNL` |
| Temporalidade | `DT_TRAN`, `HR_TRAN`, `TS_INCL_TRAN`, `TS_ATL_TRAN` |
| Categorização | `CD_CTGR_TRAN`, `CD_CTGR_TRAN_OGNL`, `CD_HASH_AGPT_TRAN`, `CD_CLSC_MTO_CTGR` |
| Indicadores e IR | `IN_VSLO_EVT`, `IN_TRAN_IR`, `IN_VSLO_CX`, `IN_VSLO_CSM`, `IN_OCTR_TRAN`, `CD_TRAN_IR`, `IN_DVS_LCTO` |

## 3. Dicionário físico e semântico completo

As 35 colunas estão na ordem de `COLNO` retornada pelo DB2. `LENGTH` reproduz o valor do catálogo (para DECIMAL, precisão; para os tipos temporais, comprimento reportado, não tamanho textual). A escala física de `VL_TRAN` é 2; a dos timestamps é 6; as demais colunas retornaram escala 0. A cardinalidade é `COLCARDF`, uma estimativa estatística.

| Nº | Atributo | Tipo SQL | LENGTH | Aceita NULL | DEFAULT físico | Distintos est. | O_Id Erwin | Definição |
|---:|---|---|---:|:---:|---|---:|---:|---|
| 1 | `NR_TRAN_INST_PCT` | `BIGINT` | 8 | Não | Identidade (J) | 34.196.155.517 | 10550 | Identificador único da transação realizada em instituição participante. Chave primária e identidade gerada por padrão; não representa necessariamente ordem cronológica. |
| 2 | `NR_PTC` | `SMALLINT` | 2 | Não | Sem default (N) | 100 | 9815 | Número da partição física. |
| 3 | `CD_CLI` | `INTEGER` | 4 | Não | Sem default (N) | 37.100.966 | 9935 | Identificador único do cliente no BB (MCI). Primeira coluna do índice secundário. |
| 4 | `CD_TIP_PSS` | `DECIMAL(1,0)` | 1 | Não | Sem default (N) | 2 | 9676 | Tipo de pessoa perante a Receita Federal: 1 = física; 2 = jurídica. |
| 5 | `NR_CPF_CNPJ_TITR` | `DECIMAL(14,0)` | 14 | Não | Sem default (N) | 34.078.720 | 9665 | CPF ou CNPJ do titular da conta. Identificador pessoal; preservar zeros à esquerda na apresentação adequada. |
| 6 | `NR_MCA_PCT_OPB` | `DECIMAL(11,0)` | 11 | Sim | NULL (Y) | 132 | 10216 | Marca vinculada à instituição participante do Open Banking. Modelo: preenchido quando não for BB. |
| 7 | `CD_INST_PCT` | `DECIMAL(14,0)` | 14 | Não | Sem default (N) | 138 | 9666 | Código da instituição participante do Open Banking. |
| 8 | `NR_AG_TITR` | `SMALLINT` | 2 | Sim | NULL (Y) | 8.576 | 9667 | Agência do titular. Modelo admite nulo para cartão de crédito. |
| 9 | `CD_CT_TITR` | `CHAR(20)` | 20 | Sim | NULL (Y) | 6.553.600 | 9668 | Código da conta do titular, inclusive conta de instituição externa. Modelo admite nulo para cartão de crédito. |
| 10 | `DV_CT_TITR` | `CHAR(1)` | 1 | Sim | NULL (Y) | 13 | 9939 | Dígito verificador da conta do titular. Modelo admite nulo para cartão de crédito. |
| 11 | `CD_PRD` | `SMALLINT` | 2 | Não | Sem default (N) | 2 | 10121 | Código do produto. O domínio de origem no Erwin define 6 = conta corrente e 9 = cartão de crédito, entre outros produtos. Nesta amostra ocorreram apenas 6 e 9. |
| 12 | `VL_TRAN` | `DECIMAL(15,2)` | 15 | Não | Sem default (N) | 12.189.696 | 9644 | Valor da transação, de crédito ou débito; pode armazenar valor total da fatura. Na amostra, todos os valores foram positivos. |
| 13 | `CD_TIP_MOE_CRR` | `CHAR(3)` | 3 | Não | Sem default (N) | 100 | 10221 | Código da moeda; exemplos: BRL, EUR, USD. Não somar moedas distintas sem conversão definida. |
| 14 | `TX_DCR_TRAN` | `CHAR(200)` | 200 | Não | Sem default (N) | 117.440.512 | 10028 | Descrição da transação alimentada posteriormente pela instituição responsável pela conta/cartão. |
| 15 | `TX_CMPR_DCR_TRAN` | `CHAR(50)` | 50 | Sim | NULL (Y) | 1.758.440.795 | 10029 | Complemento da descrição. Modelo: preenchido quando necessário. |
| 16 | `TX_DCR_TRAN_OGNL` | `CHAR(200)` | 200 | Sim | NULL (Y) | 276.824.064 | 9643 | Descrição original oriunda do estabelecimento; modelo admite nulo. |
| 17 | `CD_NTZ_CTB_TRAN` | `CHAR(1)` | 1 | Não | Sem default (N) | 2 | 9681 | Natureza contábil: C = crédito; D = débito. |
| 18 | `DT_TRAN` | `DATE` | 4 | Não | Sem default (N) | 3.776 | 9645 | Data da realização da transação. Segunda coluna de DGFP101A; não é chave de partição. |
| 19 | `HR_TRAN` | `TIME` | 3 | Sim | NULL (Y) | 81.920 | 9824 | Hora da realização. Pode ser nula, pois a API de contas pode fornecer apenas a data. |
| 20 | `CD_CTGR_TRAN` | `INTEGER` | 4 | Não | Sem default (N) | 761.856 | 10097 | Código identificador de categoria da transação; não confundir com a categoria original. |
| 21 | `CD_CTGR_TRAN_OGNL` | `INTEGER` | 4 | Não | Sem default (N) | 79 | 10150 | Categoria originalmente inserida, descrita no modelo como imutável. |
| 22 | `CD_HASH_AGPT_TRAN` | `CHAR(32)` | 32 | Não | Sem default (N) | 406.847.488 | 10125 | Hash gerado internamente a partir de textos de categorias para recategorização em lote. |
| 23 | `CD_EST_TRAN_INST` | `SMALLINT` | 2 | Não | Sem default (N) | 3 | 10037 | Estado da transação: 0 = efetivada; 1 = lançamento futuro; 9 = deleção lógica. |
| 24 | `CD_TIP_TRAN` | `CHAR(36)` | 36 | Não | Sem default (N) | 27 | 9652 | Tipo externo de transação, sem domínio fechado no modelo. Exemplos: PIX, TED, DOC, BOLETO, SAQUE, CARTAO, RENDIMENTO. |
| 25 | `IN_VSLO_EVT` | `CHAR(1)` | 1 | Não | Sem default (N) | 2 | 9812 | Visualização em eventos do cliente: S = visualizar; N = não visualizar. O modelo indica S como padrão, mas o catálogo físico não declara default. |
| 26 | `TS_INCL_TRAN` | `TIMESTAMP(6)` | 10 | Não | Sem default (N) | 830.500.318 | 10124 | Data e hora de inclusão da transação na tabela. Não representa necessariamente a data da realização. |
| 27 | `TS_ATL_TRAN` | `TIMESTAMP(6)` | 10 | Sim | NULL (Y) | 796.935.255 | 9814 | Data e hora de atualização do registro; o modelo associa o preenchimento à atualização. Na amostra, todas as linhas tinham valor, sendo 69 iguais ao timestamp de inclusão. |
| 28 | `IN_TRAN_IR` | `CHAR(1)` | 1 | Não | 'N' (1) | 2 | 10599 | S = dedutível de IR, conforme marcação do cliente; N = não dedutível (padrão modelado). |
| 29 | `IN_VSLO_CX` | `CHAR(1)` | 1 | Não | 'S' (1) | 2 | 10601 | Visualização no fluxo de caixa: S = visualizar (padrão modelado); N = não visualizar. |
| 30 | `IN_VSLO_CSM` | `CHAR(1)` | 1 | Não | 'S' (1) | 2 | 10603 | Visualização no perfil de consumo: S = visualizar (padrão modelado); N = não visualizar. |
| 31 | `IN_OCTR_TRAN` | `CHAR(1)` | 1 | Não | 'N' (1) | 2 | 10605 | Ocultação: S = ocultar; N = exibir (padrão modelado e descrito como NOT NULL). |
| 32 | `NR_SEQL_CT_CLI` | `SMALLINT` | 2 | Sim | NULL (Y) | 84 | 10613 | Sequencial da conta do cliente na marca; preenchido quando a conta foi catalogada. |
| 33 | `CD_TRAN_IR` | `SMALLINT` | 2 | Não | 0 (Y) | 10 | 10872 | Código da classificação para declaração de IR, distinguindo sugestões e não sugestões. Default físico 0. Há divergência entre duas definições do Erwin (seção 5). |
| 34 | `IN_DVS_LCTO` | `CHAR(1)` | 1 | Não | 'N' (1) | 2 | 10995 | Indicador de divisão do lançamento em dois ou mais: S = dividido; N = não dividido. |
| 35 | `CD_CLSC_MTO_CTGR` | `CHAR(1)` | 1 | Sim | NULL (Y) | 10 | 11487 | Origem da classificação pelo motor de categoria: F = regras fixas; R = regras Redis; M = modelo de IA; C = CNAE da contraparte. Modelo admite nulo em falha do motor. T e Z também foram observados, sem significado confirmado. |

### 3.1 Interpretação de `DEFAULT` e nulidade

Os códigos foram interpretados de acordo com a referência IBM de `SYSIBM.SYSCOLUMNS`:

| Código | Significado aplicável |
|---|---|
| J | `AS IDENTITY GENERATED BY DEFAULT`; permite geração automática quando o valor não é fornecido. |
| N | Não há valor padrão definido. |
| Y | Default NULL quando `NULLS=Y`; para o `SMALLINT NOT NULL` aqui identificado, o default é zero. |
| 1 | Constante explícita em `DEFAULTVALUE`. |

A chave primária é uma identidade gerada **por padrão**, não `GENERATED ALWAYS`. As opções completas da sequência (incremento, cache, ciclo e limites) não foram consultadas; não se deve pressupor ausência de lacunas ou monotonicidade temporal. Os defaults são aplicáveis à inserção quando cabíveis; não implicam atualização automática de linhas existentes.

As 10 colunas anuláveis têm default NULL. Os cinco defaults explícitos de indicadores são `N`, `S`, `S`, `N`, `N`, respectivamente em `IN_TRAN_IR`, `IN_VSLO_CX`, `IN_VSLO_CSM`, `IN_OCTR_TRAN` e `IN_DVS_LCTO`. A coluna `CD_TRAN_IR` tem default implícito zero. `IN_VSLO_EVT` é obrigatória e **não possui default físico**, embora o Erwin descreva S como padrão de negócio.

Campos `CHAR` possuem comprimento fixo; espaços de preenchimento devem ser tratados na apresentação quando apropriado, sem confundir branco com NULL. O diagnóstico utilizou `.strip()` ao exibir valores textuais, portanto os domínios observados não certificam ausência de espaços.

## 4. Domínios funcionais e indicadores

### 4.1 Produto, estado, natureza e pessoa

| Campo | Código | Significado documentado |
|---|---|---|
| `CD_PRD` | 6 | Conta corrente |
| `CD_PRD` | 9 | Cartão de crédito |
| `CD_EST_TRAN_INST` | 0 | Transação efetivada |
| `CD_EST_TRAN_INST` | 1 | Lançamento futuro |
| `CD_EST_TRAN_INST` | 9 | Deleção lógica |
| `CD_NTZ_CTB_TRAN` | C | Crédito |
| `CD_NTZ_CTB_TRAN` | D | Débito |
| `CD_TIP_PSS` | 1 | Pessoa física |
| `CD_TIP_PSS` | 2 | Pessoa jurídica |

Os códigos de produto 6 e 9 e os três estados foram observados no teste. Para pessoa, apenas 1 ocorreu na amostra. A cardinalidade estimada de `CD_PRD` é 2, a de estado é 3 e a de pessoa é 2, mas não substitui a definição do domínio. A deleção lógica é um estado; a presença física de uma linha não comprova que o lançamento esteja ativo.

`CD_TIP_MOE_CRR` registra o código da moeda (exemplos no modelo: BRL, EUR, USD). A amostra foi integralmente BRL; a cardinalidade estimada é 100. `CD_TIP_TRAN` é um tipo de origem externa sem lista fechada no Erwin; exemplos incluem PIX, TED, DOC, BOLETO, SAQUE, CARTAO, RENDIMENTO, TRANSFERENCIA_MESMA_INSTITUICAO e FOLHA_PAGAMENTO. Não confundir tipo, categoria, produto, estado e natureza contábil.

### 4.2 Seis indicadores

| Campo | S | N | Default físico | S observado | N observado |
|---|---|---|---|---:|---:|
| `IN_VSLO_CSM` | Visualizar no perfil de consumo | Não visualizar | S | 77 | 18 |
| `IN_VSLO_CX` | Visualizar no fluxo de caixa | Não visualizar | S | 67 | 28 |
| `IN_VSLO_EVT` | Visualizar nos eventos | Não visualizar | Sem default | 93 | 2 |
| `IN_DVS_LCTO` | Lançamento dividido em pelo menos dois | Não dividido | N | 0 | 95 |
| `IN_OCTR_TRAN` | Ocultar | Exibir | N | 0 | 95 |
| `IN_TRAN_IR` | Marcada pelo cliente como dedutível de IR | Não marcada como dedutível | N | 0 | 95 |

Todos os seis campos são `CHAR(1) NOT NULL`. A cardinalidade estimada de cada um é 2; a amostra não apresentou valores fora de S/N. Os indicadores representam decisões distintas. Não inferir que ocultação, exclusão lógica, ausência de visibilidade, divisão ou marcação para IR são sinônimos. A marcação de IR não equivale a uma certificação fiscal de dedutibilidade. A presença de `IN_DVS_LCTO='S'` indica divisão, mas esta coluna isoladamente não identifica os lançamentos resultantes.

## 5. Categorização e imposto de renda

- `CD_CTGR_TRAN`: categoria da transação; identifica a classificação, não o tipo externo.
- `CD_CTGR_TRAN_OGNL`: categoria inicialmente inserida, descrita no Erwin como não mutável; isso é semântica de negócio, não uma restrição de atualização comprovada pelo catálogo.
- `CD_HASH_AGPT_TRAN`: agrupamento interno para recategorização em lote baseado em textos; não é chave primária nem garantia de unicidade.
- `CD_CLSC_MTO_CTGR`: método empregado na categorização. O Erwin admite NULL quando o motor não é acionado com sucesso.

| Código do motor | Significado no Erwin | Ocorrências na amostra |
|---|---|---:|
| F | Regras fixas da API de categorização | 53 |
| R | Regras Redis da API | 0 |
| M | Modelo de IA | 15 |
| C | CNAE da contraparte | 4 |
| T | Não definido no material consultado | 12 |
| Z | Não definido no material consultado | 11 |

### 5.1 `CD_TRAN_IR`: reconciliação do domínio

O objeto local 10872 e a definição de origem 10846 do Erwin apresentam uma diferença nos códigos de não pertencimento. Os códigos comuns são:

| Classificação | Com sugestão | Sem sugestão |
|---|---:|---:|
| Pagamentos efetuados | 1 | 101 |
| Bens e direitos | 2 | 102 |
| Dívidas e ônus reais | 3 | 103 |
| Doações efetuadas | 4 | 104 |
| Não pertence — objeto de origem 10846 | 0 | 100 |
| Não pertence — atributo local 10872 | 9 | 109 |

O tipo físico é `SMALLINT NOT NULL WITH DEFAULT` (default 0), com cardinalidade estimada 10. Todos os 95 registros da amostra apresentaram `CD_TRAN_IR=0` e `IN_TRAN_IR='N'`. Esse resultado confirma o uso de zero no recorte e é compatível com a definição de origem; não resolve por si só os códigos 9, 100 e 109 nem estabelece uma relação obrigatória entre os dois atributos de IR.

## 6. Integridade, chaves e estrutura física

### 6.1 Restrições

| Restrição | Evidência física |
|---|---|
| Chave primária | `NR_TRAN_INST_PCT`, tipo P, coluna única na posição 1 |
| Índice de suporte | `IGFP101A` |
| CHECK | Nenhuma linha retornada por `SYSIBM.SYSCHECKS` |
| Chaves estrangeiras | Nenhuma coluna retornada por `SYSIBM.SYSFOREIGNKEYS` |
| Outras restrições de unicidade | Nenhuma linha adicional retornada pela consulta de constraints |

A ausência de CHECK e FK declaradas nas consultas executadas não elimina validações de negócio. As regras de domínio descritas no modelo devem ser distinguidas das restrições físicas. A ausência de FK declarada também não implica que códigos não tenham significado ou referências lógicas.

### 6.2 Índices físicos

| Propriedade | IGFP101A | DGFP101A |
|---|---|---|
| Colunas na ordem de chave | `NR_TRAN_INST_PCT` | 1. `CD_CLI`; 2. `DT_TRAN` |
| UNIQUERULE | P — chave primária | D — admite duplicatas |
| CLUSTERING | Y | N |
| INDEXTYPE | 2 | 2 |
| NLEVELS | 4 | 5 |
| NLEAF | 47.406.461 | 87.102.875 |
| FIRSTKEYCARDF | 34.196.155.517 | 37.100.966 |
| FULLKEYCARDF | 34.196.155.517 | 8.295.885.218 |

`CLUSTERING=Y` identifica o índice de clustering, não uma garantia de ordenação física perfeita. O código `INDEXTYPE=2` não representa o número de colunas; não se inferiu a organização do espaço de índice além do que foi consultado. `DT_TRAN` integra o índice secundário, mas não é sua primeira coluna. Não há índice independente por data entre os índices retornados.

### 6.3 Modelo lógico versus estrutura implantada

Os grupos de chave identificados no Erwin são: PK (`NR_TRAN_INST_PCT`), IF1 (`CD_EST_TRAN_INST`), IF3 (`CD_TIP_PSS`), IF4 (`CD_NTZ_CTB_TRAN`), IF8 (`CD_CLI`), IF10 (`CD_PRD`), IF11 (`CD_CTGR_TRAN`), IF12 (`NR_MCA_PCT_OPB`), IF13 (`CD_TIP_MOE_CRR`), IF14 (`CD_CLI`, `NR_MCA_PCT_OPB`, `NR_SEQL_CT_CLI`), IF15 (`CD_TRAN_IR`) e IF16 (`CD_CLSC_MTO_CTGR`). São grupos modelados, não evidência de índices ou FKs implantados. Para planejamento de acesso prevalecem os dois índices físicos confirmados.

## 7. Particionamento e distribuição

| Propriedade | Resultado |
|---|---|
| Chave | `NR_PTC SMALLINT NOT NULL` |
| PARTKEY_COLSEQ | 1 |
| Partições | 100, numeradas de 1 a 100 |
| LIMITKEY | 1, 2, 3, …, 100, correspondente ao número físico de cada partição |
| Cardinalidade estimada de NR_PTC | 100 |
| Menor partição (60) | 338.916.476 registros estimados |
| Maior partição (84) | 343.951.777 registros estimados |
| Ordem de grandeza por partição | 342 milhões de registros |

A distribuição estimada é equilibrada. A organização física é por `NR_PTC`, não por `DT_TRAN`. `LIMITKEY` é limite de partição, não comprova isoladamente o domínio válido de NR_PTC.

### 7.1 Associação cliente–partição observada

Um MCI autorizado foi analisado entre 26/10/2026 e 25/11/2026 (fim exclusivo). As 95 transações estavam na partição 78. Para esse MCI, `MOD(CD_CLI,100)=78`; adicionar 1 produziria 79, valor diferente do observado.

A fórmula candidata é `CASE WHEN MOD(CD_CLI,100)=0 THEN 100 ELSE MOD(CD_CLI,100) END`. Ela coincide com o cliente testado, mas nenhum cliente terminado em 00 foi analisado. **Não utilizar essa fórmula como filtro obrigatório** sem confirmação oficial ou mapeamento validado. Um filtro incorreto de partição excluiria registros silenciosamente. Usar `NR_PTC` como filtro quando a partição pretendida for conhecida, não deduzida dessa amostra.

## 8. Valores monetários e temporalidade

### 8.1 Interpretação monetária

`VL_TRAN` é `DECIMAL(15,2) NOT NULL`. `CD_NTZ_CTB_TRAN` identifica crédito ou débito e `CD_TIP_MOE_CRR` identifica a moeda. Os 78 débitos e 17 créditos observados tinham valores positivos. Não foram encontrados valores zero, negativos ou nulos no recorte. A convenção de sinal geral não foi estabelecida pela amostra. Não assumir que um débito é armazenado com sinal negativo nem somar valores de moedas distintas sem conversão definida. Definir explicitamente se uma métrica usa valor registrado, magnitude ou saldo segundo a natureza; essas métricas não são equivalentes.

### 8.2 Quatro referências temporais

| Campo | Evento | Nulidade |
|---|---|---|
| `DT_TRAN` | Data da realização da transação | Não |
| `HR_TRAN` | Hora da realização | Sim |
| `TS_INCL_TRAN` | Inclusão do registro na tabela | Não |
| `TS_ATL_TRAN` | Atualização do registro na tabela | Sim |

Os timestamps têm escala de segundos fracionários 6. A data de realização e as datas de inclusão/atualização não são intercambiáveis. A amostra contém inclusão anterior à realização em três registros; portanto não se deve impor uma ordem temporal universal. `TS_ATL_TRAN` foi igual à inclusão em 69 registros e posterior em 26; isso é um comportamento observado, não prova de que toda inclusão seja uma atualização.

### 8.3 Cobertura e retenção

O Erwin menciona permanência nominal de 18 meses para a tabela, com migração assíncrona controlada pela aplicação (objetos de documentação 10996 e 11006). Isso é uma descrição do modelo, não garantia de corte rígido pela data da transação. O teste histórico consultou um MCI no intervalo de 730 dias, de 25/11/2024 a 25/11/2026 (fim exclusivo): 1.269 registros, data mínima 12/05/2025 e máxima 23/11/2026, em 0,044 s. A data mínima observada antecede aproximadamente 18 meses em relação ao fim do teste; não prova retenção universal, exclusão de todo registro anterior ou critério exato de migração. A cardinalidade de 3.776 datas distintas tampouco equivale à extensão temporal em dias consecutivos.

## 9. Perfil empírico de dados

**Universo:** um único MCI autorizado; 95 transações entre 26/10/2026 (inclusive) e 25/11/2026 (exclusive), sem filtros adicionais de produto, moeda ou estado. Perfil agregado em 27 grupos; duração de 0,099 s. Todos os percentuais desta seção têm denominador 95; arredondamento a duas casas decimais. O identificador do cliente não é divulgado.

### 9.1 Domínios observados

| Atributo | Valor | Quantidade | % |
|---|---|---:|---:|
| `CD_PRD` | `6` | 67 | 70,53% |
| `CD_PRD` | `9` | 28 | 29,47% |
| `CD_EST_TRAN_INST` | `0` | 70 | 73,68% |
| `CD_EST_TRAN_INST` | `9` | 24 | 25,26% |
| `CD_EST_TRAN_INST` | `1` | 1 | 1,05% |
| `CD_TIP_MOE_CRR` | `BRL` | 95 | 100,00% |
| `CD_TIP_PSS` | `1` | 95 | 100,00% |
| `CD_TIP_TRAN` | `PIX` | 28 | 29,47% |
| `CD_TIP_TRAN` | `PAGAMENTO` | 28 | 29,47% |
| `CD_TIP_TRAN` | `CARTAO` | 23 | 24,21% |
| `CD_TIP_TRAN` | `OUTROS` | 8 | 8,42% |
| `CD_TIP_TRAN` | `TED` | 4 | 4,21% |
| `CD_TIP_TRAN` | `RESGATE_APLIC_FINANCEIRA` | 2 | 2,11% |
| `CD_TIP_TRAN` | `FOLHA_PAGAMENTO` | 1 | 1,05% |
| `CD_TIP_TRAN` | `BOLETO` | 1 | 1,05% |
| `CD_NTZ_CTB_TRAN` | `D` | 78 | 82,11% |
| `CD_NTZ_CTB_TRAN` | `C` | 17 | 17,89% |
| `CD_TRAN_IR` | `0` | 95 | 100,00% |
| `CD_CLSC_MTO_CTGR` | `F` | 53 | 55,79% |
| `CD_CLSC_MTO_CTGR` | `M` | 15 | 15,79% |
| `CD_CLSC_MTO_CTGR` | `T` | 12 | 12,63% |
| `CD_CLSC_MTO_CTGR` | `Z` | 11 | 11,58% |
| `CD_CLSC_MTO_CTGR` | `C` | 4 | 4,21% |
| `NR_PTC` | `78` | 95 | 100,00% |

### 9.2 Combinações dos indicadores

| CSM | CX | EVT | DVS | OCTR | IR | Quantidade | % |
|---|---|---|---|---|---|---:|---:|
| S | S | S | N | N | N | 49 | 51,58% |
| S | N | S | N | N | N | 26 | 27,37% |
| N | S | S | N | N | N | 18 | 18,95% |
| S | N | N | N | N | N | 2 | 2,11% |

As quatro combinações cobrem as 95 transações. Não houve valores fora de S/N para os seis indicadores. Não se estabelece a inexistência de outras combinações na tabela.

### 9.3 Sinal e natureza

| Natureza | Sinal do valor | Quantidade | % |
|---|---|---:|---:|
| D | Positivo | 78 | 82,11% |
| C | Positivo | 17 | 17,89% |
| Ambas | Negativo, zero ou NULL | 0 | 0,00% |

### 9.4 Consistência temporal

| Condição | Quantidade | % |
|---|---:|---:|
| Inclusão nula | 0 | 0,00% |
| Atualização nula | 0 | 0,00% |
| Data de inclusão anterior a DT_TRAN | 3 | 3,16% |
| Data de inclusão igual a DT_TRAN | 14 | 14,74% |
| Data de inclusão posterior a DT_TRAN | 78 | 82,11% |
| Atualização anterior à inclusão | 0 | 0,00% |
| Atualização igual à inclusão | 69 | 72,63% |
| Atualização posterior à inclusão | 26 | 27,37% |

## 10. Desempenho e boas práticas de consulta

### 10.1 Evidências de desempenho

A conexão JDBC foi homologada com `setReadOnly(True)` explícito, confirmação de `isReadOnly() = True`, autocommit e isolamento `READ_COMMITTED` (2). O teste de conectividade retornou 1 em 0,08 s. A configuração somente leitura do driver não substitui os privilégios de acesso do banco.

| Acesso | Intervalo [início, fim) | Registros | Partições | Tempo |
|---|---|---:|---:|---:|
| Cliente + data, filtros de produto 6/9, estado 0, BRL | 24/11–25/11/2026 | 0 | 0 | 0,15 s |
| Mesmo recorte | 18/11–25/11/2026 | 2 | 1 | 0,06 s |
| Mesmo recorte | 26/10–25/11/2026 | 70 | 1 | 0,07 s |
| Cliente + data, sem filtros adicionais; teste de partição | 26/10–25/11/2026 | 95 | 1 | 0,07 s |
| Perfil agregado de cliente | 26/10–25/11/2026 | 95 | 1 | 0,099 s |
| Histórico de cliente | 25/11/2024–25/11/2026 | 1.269 | Não medido | 0,044 s |
| Lote com um cliente | 26/10–25/11/2026 | 95 | 1 | 0,042 s |
| Acesso global agregado por data, sem cliente/partição, filtros 6/9, estado 0 e BRL | 20/10–10/11/2026 | Sem resultado | Não medido | 7.200,16 s — falha |

O acesso global registrou SQLSTATE 08001, SQLCODE -4499, em tempo compatível com o timeout JDBC de duas horas. A causa interna e o plano não foram demonstrados. Não se compara diretamente a consulta global com a amostra: os universos e volumes são distintos. Os tempos seletivos demonstram viabilidade para o cliente testado, não uma garantia para grandes lotes. O plano de acesso não foi obtido.

### 10.2 Caminhos de acesso recomendados

| Predicado | Avaliação |
|---|---|
| `NR_TRAN_INST_PCT = ?` | Compatível com acesso pela chave primária. |
| `CD_CLI = ?` | Compatível com a primeira coluna de DGFP101A. |
| `CD_CLI = ? AND DT_TRAN >= ? AND DT_TRAN < ?` | Combinação preferencial para consulta seletiva de cliente e período; compatível com a ordem das duas chaves. |
| `CD_CLI IN (...)` com intervalo de data | Avaliar lotes controlados e medir o plano de acesso; não extrapolar o teste unitário. |
| `NR_PTC = ?` | Pode permitir eliminação de partições quando a partição é conhecida. Ainda pode abranger cerca de 342 milhões de registros. |
| Apenas `DT_TRAN` | Não é primeira coluna do índice secundário nem chave de partição. Pode exigir leitura ampla. |
| Apenas produto, moeda, estado ou timestamps | Não há índice com esses campos entre os dois identificados. |

Reduzir a janela temporal não garante uma redução proporcional de I/O. Selecionar apenas as colunas necessárias, parametrizar predicados, evitar funções nas colunas utilizadas em filtros seletivos e reaproveitar agregações compatíveis. Não forçar um filtro de partição não validado nem supor que varrer as 100 partições separadamente seja mais rápido. Não iniciar contagens censitárias ou paralelismo amplo sem avaliar custo e autorização.

### 10.3 Exemplos SQL seletivos (parâmetros JDBC)

**Contagem por cliente e intervalo:**

```sql
SELECT COUNT_BIG(*) AS QT_TRAN
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = ?
  AND DT_TRAN >= ?
  AND DT_TRAN < ?;
```

**Agregação por moeda e natureza, preservando os valores registrados:**

```sql
SELECT CD_TIP_MOE_CRR,
       CD_NTZ_CTB_TRAN,
       COUNT_BIG(*) AS QT_TRAN,
       SUM(DECIMAL(VL_TRAN,31,2)) AS VL_TOTAL_REGISTRADO
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = ?
  AND DT_TRAN >= ?
  AND DT_TRAN < ?
GROUP BY CD_TIP_MOE_CRR, CD_NTZ_CTB_TRAN;
```

**Verificar partições de um cliente sem impor a fórmula candidata:**

```sql
SELECT NR_PTC, COUNT_BIG(*) AS QT_TRAN
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = ?
  AND DT_TRAN >= ?
  AND DT_TRAN < ?
GROUP BY NR_PTC;
```

Os marcadores `?` são destinados a `PreparedStatement`, com parâmetros inteiros para o MCI e DATE para as datas. Utilizar início inclusivo e fim exclusivo; um dia é representado por duas datas consecutivas. Os exemplos são recomendações de leitura, não novos testes executados. `COUNT_BIG` evita o limite de contagem inteira de 32 bits. O valor monetário agregado permanece decimal; não converter para ponto flutuante se a exatidão financeira for necessária.

## 11. Proteção e tratamento de dados

A tabela inclui identificadores pessoais e financeiros, agência, conta, dígito verificador, descrições transacionais e atributos de perfil. Aplicar autorização e finalidade legítima, minimização de dados e controle de acesso. Não expor CPF/CNPJ, MCI ou textos em diagnósticos desnecessários. A chave técnica e o hash não devem ser tratados como anonimização. Preferir agregados adequados ao propósito e evitar saídas que permitam reidentificação. Na apresentação de CPF/CNPJ, preservar zeros à esquerda conforme o tipo de pessoa e a formatação exigida.

## 12. Registro das evidências e limites de interpretação

| Teste de catálogo ou perfil | Resultado | Tempo (s) |
|---|---|---:|
| Volume/estatísticas — primeira rodada | Consulta concluída; primeira linha não fornecida | 0,09 |
| Índices | 2 índices, 3 linhas de composição | 0,07 |
| Chave de partição | NR_PTC | 0,07 |
| Atributos/cardinalidade | 35 colunas | 0,08 |
| Partições físicas | 100 linhas | 0,09 |
| Limites | 100 linhas, limites 1 a 100 | 0,09 |
| Estrutura dos índices | 2 linhas | 0,06 |
| Definição física completa | 35 linhas | 0,071 |
| CHECK | 0 linhas | 0,086 |
| Chaves/uniqueness | 1 linha | 0,055 |
| FK | 0 linhas | 0,045 |
| Perfil | 95 transações em 27 grupos | 0,099 |
| Histórico | 1.269 transações de 1 cliente | 0,044 |
| Lote | 95 transações de 1 cliente | 0,042 |

A primeira rodada de catálogo teve duração total informada de 0,39 s; a rodada complementar de diagnóstico, 0,49 s. Os tempos são os informados pelos testes, não benchmarks reproduzidos nesta elaboração.

Esta versão consolida a estrutura técnica sem exigir novos testes. As lacunas que permanecem são pontuais: definição oficial da fórmula de NR_PTC (em especial finais 00), domínio completo do motor de categorização e de IR, cobertura/critério efetivo de retenção, plano de acesso e desempenho em grandes lotes. A saída completa de SYSTABLES (DBNAME, TSNAME e demais propriedades) e os parâmetros detalhados da identidade não foram fornecidos. Nenhuma destas lacunas impede o uso do dicionário físico; elas delimitam o que pode ser afirmado sobre regras universais e desempenho.

## 13. Fontes e rastreabilidade

1. `GFP(1).json` — modelo Erwin, objeto da entidade 9640, objetos de atributos identificados na seção 3, domínio de origem de IR 10846 e atributo local 10872; documentação de retenção 10996 e 11006.
2. Catálogo físico IBM Db2 consultado em 26/11/2026: `SYSIBM.SYSCOLUMNS`, `SYSIBM.SYSINDEXES`, `SYSIBM.SYSKEYS`, `SYSIBM.SYSTABLEPART`, `SYSIBM.SYSTABCONST`, `SYSIBM.SYSKEYCOLUSE`, `SYSIBM.SYSCHECKS`, `SYSIBM.SYSFOREIGNKEYS`.
3. Resultados de diagnóstico JDBC fornecidos em 26/11/2026: conexão, índices, partições, domínios, perfil monetário e temporal, cobertura histórica e desempenho seletivo; manifesto da consulta agregada global para evidência do erro e duração.
4. IBM Db2 13 for z/OS — [SYSCOLUMNS](https://www.ibm.com/docs/en/db2-for-zos/13.0.0?topic=tables-syscolumns), [Default values for table columns](https://www.ibm.com/docs/en/db2-for-zos/13.0.0?topic=columns-default-values-table), [SYSINDEXES](https://www.ibm.com/docs/en/db2-for-zos/13.0.0?topic=tables-sysindexes) e [Types of indexes](https://www.ibm.com/docs/en/db2-for-zos/13.0.0?topic=ii-types-indexes). Referências utilizadas para interpretar metadados, não para inferir regras locais.

---

**Fim da documentação técnica — versão 2.0.**
