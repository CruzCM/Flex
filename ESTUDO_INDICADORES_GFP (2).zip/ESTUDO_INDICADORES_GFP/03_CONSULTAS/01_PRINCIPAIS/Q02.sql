-- Q02 | Combinações reais dos seis indicadores | exportar Q02.csv
WITH P AS (
    SELECT DATE('2026-10-26') AS DT_INI,
           DATE('2026-11-25') AS DT_FIM_EXCL
    FROM SYSIBM.SYSDUMMY1
)
SELECT
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR,
        COUNT_BIG(*) AS QT_TRAN,
        SUM(DECIMAL(T.VL_TRAN, 31, 2)) AS VL_TOTAL,
        SUM(ABS(DECIMAL(T.VL_TRAN, 31, 2))) AS VL_ABS
FROM DB2GFP.TRAN_RLZD_INST_PCT T
CROSS JOIN P
WHERE T.DT_TRAN >= P.DT_INI
      AND T.DT_TRAN < P.DT_FIM_EXCL
      AND T.CD_PRD IN (6, 9)
      AND T.CD_EST_TRAN_INST = 0
      AND T.CD_TIP_MOE_CRR = 'BRL'
GROUP BY
        T.IN_VSLO_CSM,
        T.IN_VSLO_CX,
        T.IN_VSLO_EVT,
        T.IN_DVS_LCTO,
        T.IN_OCTR_TRAN,
        T.IN_TRAN_IR;
