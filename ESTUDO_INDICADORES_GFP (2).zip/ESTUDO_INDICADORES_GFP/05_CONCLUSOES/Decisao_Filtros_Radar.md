# Decisão dos filtros do Radar — modelo pendente

Não existe recomendação homologada neste momento. Preencher após a análise documental e empírica.

| Indicador | Finalidade | Mantém | Remove | Exceções | Decisão | Condição SQL | Justificativa e evidência |
|---|---|---|---|---|---|---|---|
| IN_VSLO_CSM | Consumo | Pendente | Pendente | Pendente | A definir | — | Pendente |
| IN_VSLO_CX | Fluxo de caixa | Pendente | Pendente | Pendente | A definir | — | Pendente |
| IN_VSLO_EVT | Eventos | Pendente | Pendente | Pendente | A definir | — | Pendente |
| IN_DVS_LCTO | Divisão | Pendente | Pendente | Pendente | A definir | — | Pendente |
| IN_OCTR_TRAN | Ocultação | Pendente | Pendente | Pendente | A definir | — | Pendente |
| IN_TRAN_IR | Imposto de Renda | Pendente | Pendente | Pendente | A definir | — | Pendente |

Decisões possíveis: aplicar integralmente, aplicar condicionalmente, não aplicar, manter apenas informativo ou decisão pendente. Explicitar população, natureza/produto quando relevante, posição na cadeia de processamento e impactos na reconciliação. Não alterar a regra 7 antes da decisão.

## SQL recomendado
Pendente de fundamentação e homologação.
