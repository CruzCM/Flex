# Análise dos indicadores — modelo pendente

Nenhum resultado DB2 recebido. Não preencher por suposição.

Para cada um dos seis indicadores, registrar:

- Definição oficial, domínio, tipo, default e divergências entre fontes.
- Condição utilizada no código GFP e demais condições da consulta.
- Evidência de atribuição do valor, se disponível; caso contrário, marcar pendente.
- Valores e combinações observados, período, universo e contagens.
- Operações mantidas e removidas, por produto, natureza, tipo e categoria.
- Quantidade, valor registrado e valor absoluto afetados.
- Exceções, limitações, interações e riscos de exclusão.
- Fontes (arquivo/trecho/consulta) e grau de evidência.
- Recomendação de aplicabilidade e justificativa para o Radar.

## IN_VSLO_CSM
Pendente.

## IN_VSLO_CX
Pendente.

## IN_VSLO_EVT
Pendente.

## IN_DVS_LCTO
Pendente.

## IN_OCTR_TRAN
Pendente.

## IN_TRAN_IR
Pendente.

## Validações cruzadas e lacunas
Pendente.
