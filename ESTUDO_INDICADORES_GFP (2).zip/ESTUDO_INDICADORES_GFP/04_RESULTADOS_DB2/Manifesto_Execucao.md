# Manifesto de execução — preencher ao extrair

- Ambiente/versão DB2 (sem credenciais):
- Data e hora da execução:
- Data inicial inclusiva:
- Data final exclusiva:
- Isolamento utilizado:
- Restrições adicionais da população autorizada, se houver:
- Formato CSV (delimitador, decimal, encoding, representação de NULL):
- Observações sobre consistência temporal entre consultas:

| Consulta | Estado (pendente, concluída, vazia, erro, não necessária) | Arquivo | Linhas exportadas | Alterações/erro/observações |
|---|---|---|---:|---|
| Q00 | Pendente | Q00.csv | | |
| Q01 | Pendente | Q01.csv | | |
| Q01B | Pendente | Q01B.csv | | |
| Q02 | Pendente | Q02.csv | | |
| Q03 | Pendente | Q03.csv | | |
| Q04 | Pendente | Q04.csv | | |
| Q05 | Pendente | Q05.csv | | |
| Q06 | Pendente | Q06.csv | | |
| Q07 | Pendente | Q07.csv | | |
| Q08 | Pendente | Q08.csv | | |
| Q11 | Pendente | Q11.csv | | |
| Q09 | Complementar | Q09.csv | | |
| Q10 | Complementar | Q10.csv | | |
| Q12 | Fora do escopo inicial | — | | |

Exportar com cabeçalhos, sem truncamento ou arredondamento de valores. Preservar nulos e valores inesperados. Não enviar identificadores pessoais. Registrar SQL efetivamente executado caso haja alteração; não confundir resultado vazio com falha de execução.
