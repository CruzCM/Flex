# Estudo GFP por população e lote

## Matriz das consultas

O universo principal U contém transações efetivadas em BRL dos produtos 6 e 9, por DT_TRAN no intervalo inclusivo/exclusivo. M representa COUNT_BIG, soma de VL_TRAN e soma de ABS(VL_TRAN), sem inversão por natureza. I representa os seis indicadores originais, inclusive combinações inesperadas.

| Consulta | Universo e dependência | Chave de agrupamento | Resultado e leitura otimizada |
|---|---|---|---|
| Q00 | U, inclusive período vazio | Período | M, dias e extremos observados. Redução da base comum, com uma linha mesmo no vazio |
| Q01 | Categorias com junção externa aos grupos | Uma linha por categoria | Cadastro e situação do grupo, uma leitura por execução |
| Q01B | Grupos | Uma linha por grupo | Cadastro, uma leitura por execução |
| Q02 | U | I | M, redução da base comum |
| Q03 | U | Produto, natureza, tipo, categorias atual e original, I | M, matriz operacional da base comum |
| Q04 | U | Produto e natureza | Quantidades e valores absolutos de 12 cenários, com condições da consulta original sobre os agregados |
| Q05 | U de cartão com complemento opcional | Chave de Q03, presença, tipo de cartão, pagamento, lançamento, parcela, tarifa, crédito e relação com data da fatura | M, SQL independente. Preserva casos sem complemento |
| Q06 | U de conta corrente com complemento opcional | Chave de Q03, histórico, sub-histórico e relação de titularidade | M, SQL independente |
| Q07 | Inclusões do cliente com período, produtos, estado e moeda de U | Produto, natureza, tipo, categorias, cinco indicadores e origem manual/derivada | M, SQL independente em TRAN_INCD_CLI |
| Q08 | Originais divididos de U e derivados elegíveis na janela, ligados por original, cliente, produto e natureza | Produto, natureza, três visibilidades e situação da divisão | Contagens e valores de originais e derivados. Junção e classificação concluídas no DB2 antes da soma entre lotes |
| Q09 | U | Chave de Q03, instituição e marca | M, redução da base comum |
| Q10 | Transações do período, todos os produtos, estados e moedas | Produto, estado, moeda, natureza e I | M por grupo, leitura independente. Controle cruza apenas o recorte de U |
| Q11 | U | Produto, natureza, código IR, categorias e indicadores IR, ocultação, consumo e divisão | M, redução da base comum |
| Q12 | Contas e visibilidade cadastral | Produto, natureza, visibilidades, situação da conta e permissões | Fora do escopo, original mantido |

A combinação compartilhada só é usada quando duas ou mais consultas elegíveis são solicitadas. As dimensões projetadas correspondem à união das chaves necessárias à seleção. Os controles entre saídas da mesma leitura medem consistência aritmética. A auditoria lê os SQLs de referência independentemente para testar a equivalência.

## Execução corporativa

1. Abra `ESTUDO_RADAR.ipynb` na raiz do projeto. Configure somente a seção de parâmetros e execute todas as células. HOMOLOGACAO é o padrão e usa uma CTE de uma linha em SYSIBM.SYSDUMMY1. O download automático vem habilitado. O aceite inclui o caminho no JupyterLab e a confirmação do SHA-256.
2. Para desenvolvimento, use AMOSTRAL. Informe `mcis_autorizados` ou `arquivo_populacao`. O arquivo é texto UTF-8 local ao JupyterLab com um MCI decimal positivo por linha, sem cabeçalho. A entrada é validada como INTEGER, deduplicada e ordenada. Com `tamanho_amostra` definido, a seleção é sem reposição e usa a semente sobre essa base ordenada. A mesma base, semente e versão de Python reproduzem a seleção. Cabe ao operador fornecer uma população apropriada e autorizada.
3. Defina início inclusivo, fim exclusivo e consultas. A janela inicial cobre 24/11/2026. Qualquer intervalo positivo é aceito se o último dia incluído já chegou no calendário da sessão. Q09 e Q10 estão disponíveis. Uma seleção apenas cadastral dispensa a sondagem transacional. O tamanho inicial de lote é 10, ajustável de 1 a 1.000. Esse teto é uma escolha operacional do estudo que limita a lista IN e comporta os dois conjuntos de parâmetros da Q08.
4. Ajuste os timeouts de transações e cadastros e o orçamento global em segundos. Todas as operações são sequenciais. A aplicação confere o saldo antes de iniciar a unidade e novamente após abrir a conexão. Ela limita o timeout ao saldo disponível. Login, fetch, HDFS e fechamento podem ultrapassar o orçamento. Consolidação e publicação continuam para preservar os resultados.
5. Em AUDITORIA, use a mesma lista, período, recortes e seleções do teste amostral. O modo executa os SQLs originais com o recorte de acesso, em conexões separadas, consolida lotes e publica também `REF_Qxx.csv`. Confere cabeçalhos e diferenças de linhas nas duas direções. PENDENTE identifica cobertura incompleta. Faça a comparação em período estável, pois READ_COMMITTED e autocommit não fornecem snapshot comum.
6. CENSITARIO requer `autorizar_censo = True`. AUDITORIA sem população exige a mesma autorização. O censo integral percorre sequencialmente segmentos disjuntos da tabela principal. Q07 roda uma vez e cadastros também. Uma lista explícita de segmentos define um recorte do censo. Em amostra, segmentos restringem o recorte autorizado dos MCIs. Q07 não aceita seleção parcial de segmentos. Q08 restringe os originais; os derivados continuam vinculados ao original pelas chaves e à janela.
7. `destino_hdfs = None` usa a home e a pasta ESTUDO_INDICADORES_GFP/04_RESULTADOS_DB2. Um destino explícito deve existir no mesmo HDFS. Guarde o identificador de retomada impresso no início. Cada tentativa escreve em pasta própria. O ZIP aparece no JupyterLab após validação local, inclusive quando nenhuma consulta produz resultado. Se desativar o download, o ZIP permanece no caminho HDFS informado.

### Privacidade e recuperação

O JupyterLab transfere a população para uma pasta HDFS privada de nome aleatório. O driver consome a entrada e remove a área de transferência. Os valores passam ao Db2 por PreparedStatement.setInt. Os textos JDBC arquivados contêm marcadores. O pacote contém apenas resultados agregados, o módulo executado e uma cópia do notebook com parâmetros públicos de homologação. Outputs, metadados livres e conteúdo de células adicionais ou modificadas fora da seção de parâmetros são omitidos. Os parâmetros efetivos permitidos constam em Execucao.json. Ao manter o notebook no repositório, atualize as assinaturas de células distribuídas no módulo quando alterar as células operacionais.

Cada par de lote e operação publica um checkpoint HDFS exclusivo depois da leitura, fechamento JDBC e validação do resultado. O ZIP interno contém apenas agregados e metadados. A assinatura do plano vincula seleção de clientes, consultas, janela, segmentos, revisão do módulo e contexto DB2. Fica na área privada de recuperação. O identificador da unidade e o CRC são conferidos durante a leitura. A consolidação começa em um novo arquivo SQLite no disco temporário privado do driver a cada tentativa e incorpora cada unidade uma única vez, em transação local. Um checkpoint inválido é sinalizado no manifesto. Preserve-o para diagnóstico antes de iniciar uma execução nova.

Para retomar, informe o identificador em `retomar_execucao`, com o mesmo destino e recorte. Pode ajustar orçamento e timeouts. As unidades já publicadas são recuperadas sem consulta ao Db2. Uma operação interrompida antes de publicar seu checkpoint é refeita na retomada. Resultados de momentos diferentes podem refletir alterações de origem. Para uma nova observação integral da janela, use um identificador novo deixando a retomada como None.

O HDFS V1 valida inventário, tamanho, CRC e SHA-256 e publica sem sobrescrita. Só depois são removidos os arquivos avulsos da tentativa. Os checkpoints permanecem disponíveis para recuperação conforme a política corporativa de retenção. Falhas funcionais retornam um recibo de publicação e permitem o download. Se o HDFS estiver indisponível para publicação, os intermediários que chegaram a ele continuam disponíveis. A cópia local exige BBMagic autenticado, exportação de um recibo por Sparkmagic e suporte a hard links na pasta do JupyterLab.

### Leitura e interpretação das métricas

Execucao.json vincula cada tentativa de SQL ao lote, arquivo e estado. Registra horário UTC, duração, tempo acumulado, etapas de erro, SQLSTATE e SQLCODE quando fornecidos pelo JCC, linhas e bytes serializados dos agregados. O total inclui o custo de transferência e persistência do checkpoint. Os bytes serializados são uma aproximação de volume de dados da aplicação. Métricas de páginas, CPU, GETPAGE e tráfego JDBC exigem instrumentação corporativa.

Para população amostral, COBERTURA mede clientes distintos e transações na tabela principal no período e nos segmentos selecionados, antes dos filtros de produto, estado e moeda. O estudo soma essas contagens de clientes apenas entre lotes disjuntos. O manifesto distingue presença desconhecida, ausência confirmada, clientes processados, clientes em lotes com falha e pendentes. Um cadastro isolado deixa a presença transacional desconhecida. Cada CSV parcial cobre apenas os lotes bem-sucedidos da respectiva operação. Não compare totais parciais como se tivessem cobertura integral. Os resultados amostrais descrevem os MCIs fornecidos.

### Evidência física e escolhas de implementação

O catálogo consolidado informa aproximadamente 34,2 bilhões de linhas, 37,1 milhões de clientes, 35 colunas e 100 partições de aproximadamente 342 milhões de registros. IGFP101A começa pelo identificador da transação. DGFP101A tem CD_CLI INTEGER seguido de DT_TRAN DATE. A equipe observou falha da antiga Q00 por data após cerca de 7.200 segundos. Os tempos entre 0,044 e 0,15 s observados para um único MCI abrangem cargas diferentes. O custo para lotes maiores precisa ser medido. [Documentação técnica da tabela](../DB2GFP_TRAN_RLZD_INST_PCT_documentacao_final.md)

Os SQLs amostrais restringem as tabelas transacionais por lista de MCIs e intervalo semiaberto, sem transformar as colunas indexadas. A Q00 independente recebe o recorte no ON do LEFT JOIN para preservar a linha de controle no vazio. O índice efetivamente escolhido depende do otimizador. COUNT_BIG conta no Db2, e Decimal consolida valores exatos no driver. [Predicados indexáveis no Db2 13](https://www.ibm.com/docs/en/db2-for-zos/13.0.0?topic=efficiently-summary-predicate-processing) · [COUNT_BIG no Db2 13](https://www.ibm.com/docs/en/db2-for-zos/13.0.0?topic=functions-count-big)

Os LIMITKEY documentados são 1 a 100. Os segmentos do estudo usam NR_PTC <= 1, igualdade de 2 a 99 e NR_PTC >= 100 para cobrir toda chave SMALLINT não nula sem sobreposição. Igualdade a um valor observado e poda física de partição são fatos distintos. O índice e os limites da tabela principal não foram atribuídos à tabela de inclusões. Verifique separadamente os planos de Q07 e Q08. A opção `experimentar_formula_particao` executa um controle adicional por lote, confrontando a população irrestrita com o filtro candidato. Conta também todas as linhas que contrariam a fórmula individual. Os CSVs do estudo continuam usando o universo de referência mesmo quando o experimento diverge.

A base compartilhada transfere contagens, somas registradas, somas absolutas e, quando necessário, extremos da data. O driver reagrupa em disco na granularidade de cada saída. Nulls continuam distintos de strings vazias e da representação de nulo usada pelo CSV. Os cenários Q04 reutilizam os CASE do SQL original com multiplicidade. Q05, Q06 e Q08 concluem suas junções no servidor antes de somar lotes. Q10 conserva moeda e estado no agrupamento. O estudo evita depender de materialização de CTEs ou de paralelismo JDBC. Uma base com muitas combinações pode aumentar tráfego e uso de disco. Meça antes de ampliar a população.

## Roteiro de homologação de desempenho

Execute primeiro HOMOLOGACAO. Em cada etapa seguinte, use AMOSTRAL com seleção autorizada, depois AUDITORIA para o mesmo recorte e com orçamento suficiente para as leituras independentes. Registre modo, amostra, janela, tamanho de lote, quantidade de consultas JDBC, segundos por operação/lote, tempo total, bytes e linhas de saída, transações e cobertura de clientes, falhas, timeouts e equivalência de cada CSV. Quando disponíveis, associe aos SQLs arquivados o plano de acesso e as métricas de leitura do Db2 por meios autorizados. O estudo não cria objetos de EXPLAIN.

| Etapa | MCIs | Dias | Critério antes do avanço |
|---|---:|---:|---|
| 1 | 1 | 1 | Validar casos vazios, tipos e pacote local |
| 2 | 10 | 1 | Confirmar marcadores, equivalência e caminho de acesso |
| 3 | 100 | 1 | Comparar tamanhos de lote e custo de Q07/Q08 |
| 4 | 1.000 | 1 | Validar orçamento, espaço temporário e retomada |
| 5 | 1.000 | 3 | Medir impacto do aumento da janela |
| 6 | 1.000 | 7 | Confirmar custo e equivalência com o período maior |
| 7 | Ampliada | Conforme medição | Obter aceite de carga para o novo recorte |

Uma divergência requer confrontar a cobertura e a estabilidade da origem antes de qualquer decisão sobre o Radar. O censo depende de avaliação própria de carga mesmo após uma amostra rápida. A seleção inicial de um dia e os timeouts são configuráveis.

## Arquivos para atualização

No ambiente de execução que já contém o projeto anterior, substituir `ESTUDO_RADAR.ipynb` e `src/utils/estudo_indicadores_gfp.py`. Adicionar `03_CONSULTAS/03_OTIMIZADAS/Base_compartilhada.sql` e `03_CONSULTAS/03_OTIMIZADAS/Cobertura.sql`. As 13 consultas originais devem continuar nas pastas 01_PRINCIPAIS e 02_COMPLEMENTARES. Os gerenciadores corporativos são os mesmos. O ZIP histórico de SQLs de 30 dias não é entrada da execução.

Para distribuir também a validação e a documentação, atualizar `README.md`, `tests/test_periodo_estudo.py` e o caderno `02_DOCUMENTACAO/Estudo_Indicadores_GFP_Radar.md`. Adicionar `tests/test_estudo_otimizado.py`, este guia e `02_DOCUMENTACAO/Validacao_Estudo_Otimizado.md`.

O arquivo adicional `03_CONSULTAS/03_OTIMIZADAS/Plano_amostral_1_cliente.sql` apresenta o plano JDBC completo de um lote com um cliente e as 13 saídas. É material de conferência. Os dois modelos SQL mencionados acima são as únicas novas dependências SQL de execução.

