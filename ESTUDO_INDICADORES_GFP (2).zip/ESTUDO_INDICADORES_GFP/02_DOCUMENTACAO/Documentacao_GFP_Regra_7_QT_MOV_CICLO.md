# GFP — documentação técnica da base transacional e da regra 7 do Radar Financeiro

**Versão:** 1.0 · **Data:** 25/11/2026 · **Status:** análise documental; regra em avaliação, sem alteração do ETL.

## 1. Resumo executivo

A tabela `DB2GFP.TRAN_RLZD_INST_PCT` unifica transações de contas e cartões do BB e das instituições participantes do Open Banking. Ela contém registros de diferentes perspectivas de apresentação: eventos, consumo e fluxo de caixa. A regra 7 do Radar seleciona transações efetivadas em BRL dos produtos 6 e 9, aceita todos os créditos e somente débitos visíveis no perfil de consumo. Conta identificadores transacionais dentro do ciclo, antes de reconciliar pares.

A descoberta central do código Java V7 em `tran.txt` é que **o GFP usa filtros distintos para cada finalidade**. A consulta de movimentação financeira utiliza `IN_VSLO_CX = 'S'` para a natureza solicitada, a de consumo usa `IN_VSLO_CSM = 'S'` e débito, e a de listagem geral/contagem usa `IN_VSLO_EVT = 'S'`. Nenhuma delas coincide integralmente com a regra 7.

A regra vigente mede **volume de lançamentos elegíveis ao Radar, não toda a movimentação financeira, nem quantidade de eventos econômicos únicos, nem renda ou despesa líquida**. O código confirma que a aplicação trata lançamentos divididos e manuais em outra tabela. Excluir originais divididos sem trazer seus derivados pode perder operações legítimas. A consulta de movimentação também exclui o grupo de categorias 13, cujo significado não está demonstrado pelos arquivos fornecidos.

**Recomendação:** manter a regra original como referência de homologação; investigar as combinações reais dos indicadores, categorias e representações de cartão antes de decidir qual universo usar. Não importar filtros de interface automaticamente. A contagem, os pares e os agregados precisam compartilhar um universo coerente.

## 2. Fontes, escopo e rastreabilidade

| Fonte | Evidência fornecida | Limitação |
|---|---|---|
| `GFP.json` | Modelo ERwin: finalidade de entidades, atributos e exemplos de domínio; referências por `O_Id` | Modelo documental; não comprova distribuição ou regra de preenchimento em produção |
| `db2gfp_estrutura_sysibm.json` | Snapshot do schema DB2GFP, gerado em 04/08/2026 às 14:08:35, fonte SYSIBM: tipos, comprimentos, escala, nulidade e `KEYSEQ` | Não contém dados transacionais nem todos os índices, constraints ou planos de acesso; DDL exportado não é suficiente para reconstituir todos os objetos físicos |
| `tran.txt` | SQL exploratório e classe Java `ListaTransacoesT_V7`, com seis `@NamedNativeQuery` | Não comprova implantação, parâmetros reais, filtros posteriores do serviço nem resultados em produção |
| `radar_todos_v1.ipynb` | Especificação do Radar, seções 5–9 e 12; células de qualificação e planejamento | Seções 7 a 11 são planejadas, não implementadas nesse arquivo; escrita inicial desativada por padrão |

As referências de linha de `tran.txt` são 1-based. Os números de células do notebook neste documento são índices 0-based. Os objetos ERwin são identificados por `O_Id`. Não foi consultado o DB2, e os notebooks Individual, V4 e DDL citados pelo notebook não foram fornecidos para esta revisão. O documento não reproduz os identificadores pessoais usados nos exemplos SQL do arquivo.

**Níveis de evidência:** fato documental = diretamente verificável nas fontes; inferência = consequência lógica dos filtros/relacionamentos; proposta = recomendação não homologada. Exemplos numéricos são ilustrativos.

## 3. Arquitetura e granularidade

```mermaid
flowchart TD
 T[TRAN_RLZD_INST_PCT: transação institucional] --> CC[CMPT_TRAN_RLZD_CC: complemento CC]
 T --> CRT[CMPT_TRAN_RLZD_CRT: complemento cartão]
 T --> M[TRAN_INCD_CLI: derivados e inclusões manuais]
 T --> A[INF_OPB_CT_CLI: conta do cliente]
 T --> C[CTGR_TRAN_OPB: categoria atual]
 C --> G[GR_CTGR_TRAN: grupo]
 T --> R[Regra 7: seleção por MCI e ciclo]
 R --> P[Regra 8: reconciliação]
 P --> F[Regra 9: agregados]
```

O diagrama representa caminhos de associação observados no código/modelo, não certificação de todas as FKs físicas. O Radar vigente lê a tabela principal diretamente; os demais relacionamentos são referências para investigação, não joins obrigatórios da regra 7.

### 3.1 Tabela principal

O ERwin (`O_Id 9640`) descreve a entidade **Transação Realizada em Instituição Participante**, destinada a unificar transações financeiras de contas e cartões de clientes do BB e de instituições Open Banking para apresentação em extrato conjunto.

O catálogo físico indica `D1GFP01.S1GFP101`, 35 colunas, `NR_TRAN_INST_PCT` BIGINT NOT NULL e `KEYSEQ=1` como único componente indicado da chave primária. `CD_CLI` é o cliente; `NR_PTC` é a partição, não componente dessa chave. A verificação operacional de unicidade continua necessária após leituras e joins. O notebook usa `(CD_CLI, NR_TRAN_INST_PCT)` como chave lógica de controle no Spark.

Uma linha é um registro transacional. Um pagamento de fatura, as compras que compõem a fatura, parcelas, créditos de estorno, transferências entre contas e eventuais representações sintéticas podem constituir registros distintos; `COUNT(DISTINCT NR_TRAN_INST_PCT)` não os consolida em um único evento econômico. A presença efetiva desses tipos e suas marcações requer observação da base.

### 3.2 Domínios e semântica dos campos relevantes

| Campo | Definição / domínio documentado | Evidência ERwin (`O_Id`) |
|---|---|---|
| `CD_PRD` | 6 conta corrente, 9 cartão de crédito; outros produtos existem (p.ex. 3 poupança) | 11098, 11133, 4415 |
| `CD_EST_TRAN_INST` | 0 efetivada, 1 lançamento futuro, 9 deleção lógica | 10037, 10030, 11110 |
| `CD_TIP_MOE_CRR` | BRL real, EUR euro, USD dólar americano | 10143, 10140 |
| `CD_NTZ_CTB_TRAN` | C crédito; D débito | 3588, 3594, 11139 |
| `DT_TRAN` | Data em que a transação foi realizada | 9645 |
| `VL_TRAN` | Valor da transação; pode representar débito, crédito ou valor total da fatura | 9644 |
| `HR_TRAN` | Hora de realização; pode faltar, pois a API de contas pode retornar apenas a data | 9824 |
| `TS_INCL_TRAN` | Momento de inclusão do registro na tabela | 10124 |
| `TS_ATL_TRAN` | Atualização do registro, preenchido quando há atualização | 9814 |
| `CD_TIP_TRAN` | Tipo de transação de origem externa, sem domínio fechado no modelo; exemplos PIX, TED, DOC, BOLETO, SAQUE, CARTAO, RENDIMENTO | 9652 |
| `CD_CTGR_TRAN_OGNL` | Categoria originalmente inserida no GFP; o modelo afirma que não muda | 10150 |
| `CD_CTGR_TRAN` | Categoria usada nas consultas V7 para descrição/grupo; distinta da original usada na seção 9 do Radar | Código V7, linhas 243–246; notebook célula 39 |
| `CD_HASH_AGPT_TRAN` | Hash interno para agrupamento e recategorização em lote; não é chave de operação econômica | 10125 |
| `NR_CPF_CNPJ_TITR` | CPF/CNPJ do titular da conta | 9665 |
| `CD_INST_PCT` | Código da instituição participante | 9666 |
| `NR_MCA_PCT_OPB` | Marca participante; usada para associar contas e distinguir instituições no Radar; pode ser nula | SYSIBM; notebook células 35–38 |

**Data da transação não é data de sincronização.** O notebook deriva o ciclo a partir da última inclusão por MCI, mas testa a elegibilidade do movimento por `DT_TRAN`. Uma transação antiga sincronizada recentemente só entra no ciclo se sua data de realização estiver dentro dele. Estado 0 não prova que uma operação não será estornada posteriormente; estornos também podem aparecer como registros separados.

### 3.3 Indicadores de perspectiva

| Indicador | Valores documentados | Finalidade | Exemplo documentado |
|---|---|---|---|
| `IN_VSLO_CSM` | S visualizar (padrão do modelo); N não visualizar | Perfil de consumo | Compra parcelada em 10 vezes: apresentação do lançamento total da compra |
| `IN_VSLO_CX` | S visualizar (padrão do modelo); N não visualizar | Fluxo de caixa | Compra contestada por não ter sido feita pelo cliente não aparece no fluxo |
| `IN_VSLO_EVT` | S visualizar (padrão do modelo); N não visualizar | Eventos/linha do tempo | Vencimento da fatura do cartão aparece como evento |
| `IN_OCTR_TRAN` | N exibir (padrão); S ocultar | Ocultação no GFP | Não equivale a deleção lógica |
| `IN_DVS_LCTO` | N não dividido; S dividido | Indica que o lançamento original foi dividido em pelo menos dois | Saque de 100 dividido em 30 e 70 |
| `IN_TRAN_IR` | S dedutível; N não dedutível (padrão) | Marcação para IR pelo cliente | Gasto médico |

Referências ERwin: 10603 (consumo), 10601 (caixa), 9812 (eventos), 10605 (ocultação), 10995 (divisão), 10599 (IR).

Os indicadores acima são `CHAR(1) NOT NULL` na tabela principal. O fato de o modelo documentar S/N não comprova que não existam valores fora do domínio na base. Não são mutuamente exclusivos, nem substituem o estado da transação. A visibilidade de uma compra parcelada não demonstra, por si só, o padrão de todas as parcelas e faturas; o exemplo é apenas evidência da existência de visões distintas. O valor armazenado em BRL não prova que a moeda original da compra era BRL; o complemento do cartão contém valor original na moeda do movimento.

## 4. Código do GFP V7: inventário de consultas

A classe `br.com.bb.gfp.models.ListaTransacoesV7.ListaTransacoesT_V7` contém seis consultas nativas. As linhas 1402–1407 declaram seus nomes; o final da classe expõe os métodos correspondentes. A análise a seguir reproduz as condições relevantes, sem afirmar que a consulta está em produção.

| Consulta | Início em `tran.txt` | Filtro sobre a tabela institucional (além de MCI e intervalo) | Manual/derivado |
|---|---:|---|---|
| `LISTAR_TRANSACOES_V7` | 41 | Estado ≠ 9; EVT=S; DVS=N | Sim, estado ≠ 9, EVT=S |
| `LISTAR_TRANSACOES_CATEGORIA_V7` | 288 | Estado ≠ 9; categoria parametrizada (0 = todas); CSM=S; DVS=N; natureza D | Sim, mesmos filtros sem DVS |
| `LISTAR_TRANSACOES_MOVIMENTACAO_FINANCEIRA_V7` | 537 | Estado ≠ 9; CX=S; DVS=N; natureza parametrizada | Sim, mesmos filtros sem DVS |
| `LISTAR_TRANSACOES_AGENDADAS_V7` | 783 | Estado=1; EVT=S; DVS=N; produto=6 | Não |
| `LISTAR_TRANSACOES_IR_V7` | 937 | Código IR na lista; estado ≠ 9; ocultação ≠ S; CSM=S; DVS=N; natureza D | Sim, mesmos filtros sem DVS |
| `CONTAR_TRANSACOES_TOTAL_V7` | 1184 | Estado ≠ 9; EVT=S; DVS=N | Sim, estado ≠ 9, EVT=S |

**Todas as seis** usam MCI e intervalo inclusivo de `DT_TRAN`. As cinco consultas que abrangem mais de um produto separam o cartão (`CD_PRD = 9`) dos demais (`CD_PRD != 9`) para enriquecer o cartão, e não para restringir o universo a produtos 6 e 9. Nenhuma das seis possui predicado explícito sobre `CD_TIP_MOE_CRR` no SQL fornecido. Não deduzir que outras camadas não aplicam restrições.

### 4.1 Listagem geral e contagem total

```sql
-- Seleção inicial das consultas geral e contagem
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = :mci
  AND CD_EST_TRAN_INST != 9
  AND DT_TRAN BETWEEN :dataIni AND :dataFim
  AND IN_VSLO_EVT = 'S'
  AND IN_DVS_LCTO = 'N'
```

Fonte: linhas 74–79 e 1217–1222. A consulta de contagem une transações institucionais e manuais/derivadas, seleciona contas e finalmente executa `SELECT COUNT(*) FROM TRAN_INF_OPB` (linha 1395), com `resultClass = Integer.class` (1396). Não usa `COUNT(DISTINCT ...)`, não é a contagem bruta de registros de uma única tabela e não equivale a `QT_MOV_CICLO`. A listagem geral limita cada retorno a 10.000 linhas após `ROWN > :cont1` (280–281); a contagem não possui esse limite. O estado ≠ 9 admite o estado futuro 1 e quaisquer outros estados não 9 eventualmente presentes.

### 4.2 Perfil de consumo por categoria

```sql
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = :mci
  AND CD_EST_TRAN_INST != 9
  AND (:categoria = 0 OR CD_CTGR_TRAN = :categoria)
  AND DT_TRAN BETWEEN :dataIni AND :dataFim
  AND IN_VSLO_CSM = 'S'
  AND IN_DVS_LCTO = 'N'
  AND CD_NTZ_CTB_TRAN = 'D'
```

Fonte: 320–327. É evidência direta de que o GFP usa CSM para a visão de gastos por categoria. A condição de débito não está condicionada ao produto. A regra 7 aproveita parte dessa semântica, mas não reproduz a visão por categoria e acrescenta créditos sem CSM, produto, BRL e efetivação.

### 4.3 Movimentação financeira

```sql
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = :mci
  AND CD_EST_TRAN_INST != 9
  AND DT_TRAN BETWEEN :dataIni AND :dataFim
  AND IN_VSLO_CX = 'S'
  AND IN_DVS_LCTO = 'N'
  AND CD_NTZ_CTB_TRAN = :natureza
```

Fonte: 569–575. Aplica CX independentemente de a natureza solicitada ser C ou D. A seleção de lançamentos manuais/derivados também usa CX e natureza (627–632). No final, há exclusão por grupo 13 (748; seção 7 deste documento). A consulta de movimentação não é prova de que o Radar deva adotar CX: a função do Radar pode ser analisar consumo e orçamento, não apenas o fluxo de caixa apresentado no app.

### 4.4 Agendadas

Fonte: 818–824. Estado=1, EVT=S, DVS=N, produto=6. Confirma no código a separação dos lançamentos futuros. O Radar atual usa estado=0 e, portanto, não conta esses lançamentos.

### 4.5 Imposto de renda

Fonte: 969–977, 1029–1036 e 1152. Usa `CD_TRAN_IR IN (:codigoIR)`, `IN_OCTR_TRAN != 'S'`, CSM=S e débito, além de DVS=N na tabela institucional. Exclui `B.CD_GR_CTGR_TRAN = 13` (por predicado `!= 13`, também rejeitando NULL). O campo `IN_TRAN_IR` existe, porém não é o predicado explícito de IR nessa consulta.

### 4.6 Fluxo comum de composição

1. `SELR_CT_BB`: seleciona contas em `INF_OPB_CT_CLI` por MCI, com parâmetros de marca e exibição. A consulta geral e a contagem permitem `:usarTodosOsBancos = 'S'` ou `:usarMarcasDaRequisicao = 'S'` ou `IN_EXB_DADO_CT = 'S'`; as outras quatro usam as duas últimas condições.
2. `SELR_TRAN`: seleciona a tabela institucional conforme a funcionalidade.
3. `TRAN_INF_CRT`: enriquece produto 9 com `LEFT JOIN CMPT_TRAN_RLZD_CRT` pelo ID transacional, usando `VALUE` para valores padrão de parcela/cartão. Ausência de complemento não é motivo de exclusão nessa etapa.
4. `SELR_TRAN_MNL`: seleciona `TRAN_INCD_CLI` (exceto agendadas), atribui origem M/D e projeta o identificador manual para a coluna comum.
5. `TRAN_MNL`: `UNION ALL` do cartão, demais produtos e registros manuais/derivados.
6. `CT_BB`: filtra conta do BB por marca, agência, conta e sequencial de conta. `UNIAO_REGS`: acrescenta as marcas selecionadas conforme parâmetros; na consulta de agendadas o fluxo equivalente usa `CT_BB_OTR` sem união manual.
7. `TRAN_INF_OPB`: associa categorias/grupos por LEFT JOIN e contas por INNER JOIN usando MCI + marca + sequencial de conta; usa `ROW_NUMBER` para paginação (data, ID, hora; agendadas ordenadas crescentemente). As consultas de movimentação e IR excluem grupo 13.
8. Saída de listagem ou `COUNT(*)`. O código normaliza hora ausente para meia-noite e campos de texto/descrição ausentes para valores padrão; esses valores não representam evidência de horário real ou de categoria real.

**Riscos de transpor a consulta para o Radar:** o INNER JOIN pode excluir transações sem conta correspondente (incluindo marca/sequencial nulos). O `UNION ALL` preserva duplicatas; a seleção de marcas pode sobrepor o ramo BB se os parâmetros admitirem a marca BB no segundo ramo. `COUNT(*)` mede linhas resultantes, não IDs únicos. Os parâmetros reais não estão disponíveis; não afirmar que a sobreposição ocorre em produção. IDs manuais e institucionais vêm de colunas de tabelas distintas; não assumir unicidade global após união sem considerar a origem.

## 5. Lançamentos manuais e divididos

O ERwin (`O_Id 11014`, entidade `TRAN_INCD_CLI`) documenta intervenções do cliente no aplicativo: inclusões manuais e divisão de um lançamento original em múltiplos registros. A transação manual não está na tabela institucional; o original dividido continua nela, sinalizado em `IN_DVS_LCTO`, e seus derivados ficam na tabela de inclusão.

```text
Original: saque de R$ 100 (TRAN_RLZD_INST_PCT, IN_DVS_LCTO=S)
  ├─ derivado: alimentação R$ 30 (TRAN_INCD_CLI)
  └─ derivado: pagamento de conta R$ 70 (TRAN_INCD_CLI)
```

O código distingue origem:

```sql
-- Tabela institucional: constante 'T' AS IN_TRAN_INCL
-- Tabela de inclusão:
CASE IFNULL(NR_TRAN_RLZD_OGM, 0)
    WHEN 0 THEN 'M'
    ELSE 'D'
END AS IN_TRAN_INCL
```

Fonte: 565, 620–623 e 627–632. T = transação institucional; M = inclusão manual (referência nula ou zero); D = derivado (referência não zero). `NR_TRAN_RLZD_OGM` é BIGINT anulável; aponta para o lançamento original conforme o modelo e a lógica da aplicação.

| Estratégia | Contagem ilustrativa do saque | Consequência |
|---|---:|---|
| Original apenas | 1 | Preserva o registro da instituição |
| Excluir original e não incluir derivados | 0 | Perde o movimento |
| Substituir original pelos dois derivados elegíveis | 2 | Representa a visão categorizada, não a granularidade da operação original |
| Somar original e dois derivados | 3 | Superposição de representações; soma poderia duplicar R$ 100 |

Não se deve acrescentar `IN_DVS_LCTO = 'N'` isoladamente à regra 7. O GFP o faz porque incorpora outra fonte. A regra atual não inclui `TRAN_INCD_CLI`; logo, manter originais divididos é a opção coerente com a granularidade institucional, enquanto essa finalidade prevalecer. Uma mudança para o modelo de apresentação exigiria redefinição da chave, tratamento de origem, critérios para manuais e derivados e reconciliação.

## 6. Complementos e identificação de operações

### 6.1 Conta corrente — `CMPT_TRAN_RLZD_CC`

O início de `tran.txt` (linhas 1–15) exemplifica um join pelo ID, filtro produto 6, tipo PIX e igualdade entre CPF/CNPJ do titular e da contraparte. Versão sem identificador real:

```sql
SELECT A.NR_TRAN_INST_PCT, A.DT_TRAN, A.CD_NTZ_CTB_TRAN, A.VL_TRAN
FROM DB2GFP.TRAN_RLZD_INST_PCT A
JOIN DB2GFP.CMPT_TRAN_RLZD_CC B
  ON A.NR_TRAN_INST_PCT = B.NR_TRAN_INST_PCT
WHERE A.CD_CLI = :mci
  AND A.CD_PRD = 6
  AND A.CD_TIP_TRAN = 'PIX'
  AND A.NR_CPF_CNPJ_TITR = B.NR_CPF_CNPJ_PGDR
ORDER BY A.DT_TRAN DESC;
```

O comentário chama a consulta de Pix enviados para o mesmo CPF, mas o SQL não exige débito, estado efetivado, BRL ou período. Logo, a igualdade de documentos é evidência potencial de mesma titularidade, não prova de envio nem de par entre bancos. O complemento admite dados nulos da contraparte; confirmar a qualidade de preenchimento, tipo da pessoa, direção e instituição. Não considerar igualdade de documentos inválidos/zero como comprovação. Não é filtro da regra 7 vigente.

Outros campos úteis: identificador de transação na instituição (`CD_IDFR_TRAN_INST`), conta (`CD_IDFR_CT`), dados de contraparte, documento (`NR_DOC`), histórico/sub-histórico (`CD_HST_TRAN`, `CD_SHST_TRAN`), sequência e lote (`CD_SEQL_TRAN`, `NR_LT_TRAN`), código de transferência e data contábil (`CD_TRAN_CTA`, `DT_CTB_TRAN`). A data contábil não substitui automaticamente `DT_TRAN`.

### 6.2 Cartão — `CMPT_TRAN_RLZD_CRT`

Campos relevantes: `NR_PCL_CPR` (número da parcela), `QT_PCL_CPR` (quantidade), `CD_IDFR_CRT` (identificador do cartão), `NR_FAT_CRT` (identificador de fatura), `DT_TRAN_FAT` (data da transação de fatura conforme nomenclatura), `VL_OGNL_MOE_MVT` (valor original na moeda do movimento), `TX_TIP_PGTO`, `TX_TIP_LNCD` e `CD_TIP_TRAN_CRT`. Verificar seus domínios e dados reais antes de construir filtros. O código V7 utiliza principalmente os dois campos de parcela e o identificador de cartão (94–96, 103–105; repetidos nas outras consultas).

Os complementos de CC e cartão apresentam `NR_TRAN_INST_PCT` como chave indicada por `KEYSEQ=1`, o que é compatível com associação de até um complemento por ID em cada tabela, não garantia de que todos os registros têm complemento. O Radar pode enriquecer diagnósticos por LEFT JOIN sem excluir a origem.

### 6.3 Contas e marcas — `INF_OPB_CT_CLI`

Chave indicada: `(CD_CLI_TITR_CT, NR_MCA_PCT_OPB, NR_SEQL_CT_CLI)`. A associação usada no código combina essas três dimensões; apenas sequencial ou apenas MCI seria insuficiente para identificação da conta. A marca BB adotada pelo notebook é `999999999` na etapa de qualificação, mas a regra 7 não restringe a marca ao BB. `IN_EXB_DADO_CT` é filtro de exibição de dados de conta no código V7; não é critério de efetivação nem filtro atual do Radar. Não confundir seleção de conta BB para determinar ciclo com seleção de movimentos de todas as marcas do MCI.

## 7. Categorias e grupo 13

A associação observada no código é:

```sql
LEFT JOIN DB2GFP.CTGR_TRAN_OPB B
  ON B.CD_CTGR_TRAN = A.CD_CTGR_TRAN
LEFT JOIN DB2GFP.GR_CTGR_TRAN C
  ON C.CD_GR_CTGR_TRAN = B.CD_GR_CTGR_TRAN
-- na movimentação financeira:
WHERE C.CD_GR_CTGR_TRAN != 13
-- no IR, o filtro é sobre B:
-- WHERE B.CD_GR_CTGR_TRAN != 13
```

Fontes: 739–748 e 1143–1152. As duas exclusões rejeitam NULL por lógica ternária SQL, mas há diferença: na movimentação a ausência de registro correspondente na tabela de grupos exclui a linha; no IR, se a categoria tem um grupo diferente de 13, a linha pode permanecer mesmo sem cadastro correspondente em `GR_CTGR_TRAN`. A regra 7 não restringe categorias; a seção 9 usa categoria **original** e mapa próprio do Radar. A consulta V7 usa a categoria **atual**. Não aplicar indiscriminadamente o grupo 13 ou presumir seu significado.

```sql
SELECT CD_GR_CTGR_TRAN, TX_DCR_GR_CTGR
FROM DB2GFP.GR_CTGR_TRAN
WHERE CD_GR_CTGR_TRAN = 13;

SELECT CD_CTGR_TRAN, TX_DCR_CTGR_TRAN, CD_NTZ_CTB_TRAN
FROM DB2GFP.CTGR_TRAN_OPB
WHERE CD_GR_CTGR_TRAN = 13
ORDER BY CD_CTGR_TRAN;
```

Estas consultas são propostas de investigação; não foram executadas.

## 8. Contrato vigente da regra 7

Fonte: `radar_todos_v1.ipynb`, células 32–35 (seção 7), 36 (escrita), 42 (conferência).

| Critério | Condição |
|---|---|
| Participação | `FLAG_PARTICIPA_RADAR = 'true'`, datas preenchidas e válidas |
| Cliente | `A.CD_CLI = CD_CLI_REF` |
| Produto | `CD_PRD IN (6, 9)` |
| Estado | `CD_EST_TRAN_INST = 0` |
| Moeda | `CD_TIP_MOE_CRR = 'BRL'` |
| Natureza e visibilidade | `(CD_NTZ_CTB_TRAN = 'C' OR (CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S'))` |
| Período | `DT_TRAN BETWEEN DT_INI_REF AND DT_FIM_REF` |
| Granularidade | ID transacional distinto por cliente, antes de neutralização |
| Saída | `QT_MOV_CICLO BIGINT`, por `DT_EXEA` e `CD_CLI_REF` |

```sql
-- Equivalente conceitual para um MCI participante (não é a implementação em lote)
SELECT COUNT_BIG(DISTINCT NR_TRAN_INST_PCT) AS QT_MOV_CICLO
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = :mci
  AND CD_PRD IN (6, 9)
  AND CD_EST_TRAN_INST = 0
  AND CD_TIP_MOE_CRR = 'BRL'
  AND (CD_NTZ_CTB_TRAN = 'C'
       OR (CD_NTZ_CTB_TRAN = 'D' AND IN_VSLO_CSM = 'S'))
  AND DT_TRAN BETWEEN :dataIni AND :dataFim;
```

A chave física e a contagem distinta tornam o resultado equivalente a `COUNT_BIG(*)` na leitura direta se a chave indicada for efetivamente respeitada. Em processamento distribuído, validar a unicidade antes de contar e de parear. Os parâmetros são marcadores a adaptar ao cliente DB2/Spark.

### 8.1 Interpretação da assimetria

| Natureza | CSM | Entra? (outros critérios atendidos) |
|---|---|---|
| C | S | Sim |
| C | N | Sim |
| D | S | Sim |
| D | N | Não |
| Outra | qualquer | Não |

A visibilidade de eventos, fluxo de caixa, ocultação e divisão não influencia diretamente o predicado vigente. A regra não exige categoria válida, marca preenchida, existência de complemento, conta habilitada para exibição nem autorização de exibição. Não confundir a ausência desses filtros com uma avaliação jurídica/operacional sobre consentimento: essa questão não foi analisada pelos arquivos.

### 8.2 O que o indicador entrega e o que não entrega

Entrega uma quantidade bruta de registros institucionais elegíveis ao universo analítico do Radar, independentemente de sua posterior neutralização. Não garante ausência de registros BRL quando zero, operação econômica única, consumo efetivo, receitas ou despesas líquidas, alteração patrimonial, ausência de estornos, ausência de representações múltiplas ou cobertura de todas as instituições do cliente. Não é soma de valores.

Exemplo: salário ou Pix recebido em BRL entra se atender aos demais critérios mesmo com CSM=N; Pix enviado, pagamento de fatura e compra entram se forem débitos com CSM=S; parcela com CSM=N não entra. Esses exemplos são condicionais, não afirmações sobre como o GFP marca esses tipos na prática. Um cliente com dez transações elegíveis posteriormente neutralizadas permanece com QT_MOV_CICLO=10. Um cliente com débitos em BRL todos CSM=N terá zero, mesmo tendo movimentação registrada.

**Redação proposta (sem alterar critérios):** “A contagem distingue um ciclo sem lançamentos elegíveis para o Radar de outro em que os lançamentos elegíveis foram posteriormente neutralizados.”

### 8.3 Ciclo e contexto externo

A seção 5 calcula datas dos ciclos fechados a partir da última inclusão e do dia do ciclo. A seção 7 usa `tabela_inicial` na mesma sessão Spark, preserva a base de qualificação e exige uma janela por MCI. A leitura cobre `DT_INI_REF - 5 dias` até `DT_FIM_REF + 5 dias`, unindo intervalos sobrepostos/contíguos e aplicando as datas de cada cliente no Spark. Os mesmos filtros transacionais valem para o contexto. Apenas registros internos (`IN_JANELA='S'`) incrementam QT_MOV_CICLO; os externos (`'N'`) servem para localizar contrapartes.

O planejamento prevê leitura por `DT_TRAN` e `NR_PTC`, inicialmente com quatro partições JDBC, retenção dos campos ID, cliente, data, natureza, valor, marca, categoria original e posição no ciclo. A partição não é unidade de negócio. Cache reutilizado na reconciliação e liberado após materialização dos movimentos efetivos. Não há medição de desempenho nem implementação dessa leitura no arquivo fornecido.

### 8.4 Zero, nulo e escrita

| Situação | QT_MOV_CICLO |
|---|---:|
| Não participante | NULL |
| Participante avaliado sem registros elegíveis internos | 0 |
| Participante com 5 registros internos elegíveis | 5 |
| Participante apenas com registros externos | 0 |
| Participante com 10 registros elegíveis todos neutralizados | 10 |
| Público participante vazio | NULL na base de qualificação |
| Etapa ainda não executada/falhou | Não publicar zero como se tivesse avaliado; preservar estado não avaliado conforme contrato de carga |

A última linha é recomendação de integridade operacional, não regra implementada. Data inválida ou ausente em participante deve ser tratada como inconsistência de qualificação, não convertida silenciosamente em zero. A contagem é gravada junto com os dois indicadores de pares na seção 8. A principal `SBX_A2A13E2.ANL_RADAR_FNC_CLI` mantém uma linha por execução (`DT_EXEA`) e cliente (`CD_CLI_REF`). O notebook prevê evolução para partição por execução e escrita limitada à execução; o DDL ampliado ainda é proposta.

## 9. Comparação das perspectivas

| Critério | Radar 7 | Geral/contagem GFP | Consumo GFP | Movimentação GFP | Agendadas GFP | IR GFP |
|---|---|---|---|---|---|---|
| Produto | 6,9 | Sem restrição explícita a 6,9 | Idem | Idem | 6 | Sem restrição explícita a 6,9 |
| Estado | 0 | ≠9 | ≠9 | ≠9 | 1 | ≠9 |
| BRL | Sim | Não explícito | Não explícito | Não explícito | Não explícito | Não explícito |
| Natureza | C ou D | Sem restrição | D | Parâmetro | Sem restrição | D |
| EVT | Não | S | Não | Não | S | Não |
| CSM | S só em D | Não | S | Não | Não | S |
| CX | Não | Não | Não | S | Não | Não |
| DVS na origem institucional | Não | N | N | N | N | N |
| Ocultação | Não | Retorna indicador | Retorna indicador | Retorna indicador | Retorna indicador | ≠S |
| Manuais/derivados | Não | Sim | Sim | Sim | Não | Sim |
| Conta/marca de exibição | Não na regra 7 | Sim | Sim | Sim | Sim | Sim |
| Categoria específica | Não | Não | Parametrizada | Não | Não | Código IR |
| Grupo 13 | Não | Não | Não | Exclui via C | Não | Exclui via B |
| Granularidade | ID institucional | Linha do resultado | Linha do resultado | Linha do resultado | Linha do resultado | Linha do resultado |

“Não” significa ausência do predicado explícito no SQL analisado, não ausência de possíveis filtros em outras camadas.

| Objetivo alternativo | Predicado de visibilidade sugerido mantendo os demais filtros fixos | Observação |
|---|---|---|
| A — registro institucional efetivado | C ou D, sem visibilidade | Mais amplo que Radar, não equivale a toda realidade financeira fora da base |
| B — regra vigente | C ou (D e CSM=S) | Assimetria consumo/crédito |
| C — fluxo de caixa | C ou D, CX=S | Simétrico; não reproduz todos os joins e exclusões da consulta GFP |
| D — eventos | C ou D, EVT=S | Simétrico; não reproduz a contagem total do GFP |
| E — consumo estrito | D e CSM=S | Não mede entradas |

A visão A é superconjunto de B, C, D e E para a base fixa. E é subconjunto de B. B, C e D não têm relação de inclusão garantida entre si. Não escolher pela quantidade maior/menor, mas pela finalidade definida para os agregados do Radar.

## 10. Dependência com a reconciliação (somente interface com a regra 7)

A seção 8 busca pares de crédito/débito do mesmo cliente, mesmo valor, marcas preenchidas e diferentes. Pares exatos têm mesma data; pares de borda têm uma ponta interna e outra externa com diferença de 1 a 5 dias. A especificação exige uso de cada ID no máximo uma vez e desempate determinístico. Pares externos exatos não incrementam os indicadores internos, mas podem consumir contrapartes do contexto. Pareamento por valor/data/marca é uma heurística: não prova identidade de transferência. A investigação de contraparte da seção 6.1 pode ajudar a validar casos, sem mudar a regra existente.

A seção 12 define a identidade:

```text
QT_TRANS_TOTAL = QT_MOV_CICLO − 2 × QT_PARES_EXATOS − QT_PARES_BORDA
```

Exemplo: 10 registros internos, 3 pares internos e 2 de borda deixam 2 registros efetivos. Consequências: contagens não negativas; `2 × QT_PARES_EXATOS + QT_PARES_BORDA <= QT_MOV_CICLO`; nenhuma ponta reutilizada. A identidade exige que os agregados e a reconciliação operem sobre o mesmo universo, sem perda adicional de linhas por joins. A categoria original usada na seção 9 deve classificar sem alterar indevidamente a contagem total. Aplicar filtros diferentes para a contagem e as pontas reconciliáveis pode quebrar a identidade ou impedir neutralizações.

Exemplo de risco: um crédito interno elegível e seu débito contraparte com CSM=N não formam par na regra atual; o crédito pode permanecer. Isso é consequência lógica da seleção, não prova de frequência na base. A mudança de visibilidade de um único registro pode alterar tanto a contagem bruta quanto a quantidade de pares e o resultado líquido.

## 11. Plano de diagnóstico e SQLs de homologação

As consultas a seguir são propostas de leitura, não foram executadas. Utilizar MCIs de teste autorizados e períodos curtos inicialmente; parametrizar datas e MCI conforme a ferramenta de acesso. Evitar exportar CPF, números de conta, descrições sensíveis ou dados individuais desnecessários. Não há estimativa de tempo sem plano de acesso e volume.

### 11.1 Distribuição dos indicadores e valores

```sql
SELECT CD_PRD, CD_NTZ_CTB_TRAN, IN_VSLO_CSM, IN_VSLO_CX,
       IN_VSLO_EVT, IN_DVS_LCTO, IN_OCTR_TRAN,
       COUNT_BIG(*) AS QT_TRAN,
       SUM(CAST(VL_TRAN AS DECIMAL(25,2))) AS VL_TOTAL
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = :mci
  AND CD_PRD IN (6,9)
  AND CD_EST_TRAN_INST = 0
  AND CD_TIP_MOE_CRR = 'BRL'
  AND DT_TRAN BETWEEN :dataIni AND :dataFim
GROUP BY CD_PRD, CD_NTZ_CTB_TRAN, IN_VSLO_CSM, IN_VSLO_CX,
         IN_VSLO_EVT, IN_DVS_LCTO, IN_OCTR_TRAN
ORDER BY CD_PRD, CD_NTZ_CTB_TRAN, QT_TRAN DESC;
```

Investigar combinações, inclusive créditos invisíveis, débitos invisíveis no consumo mas visíveis em caixa, operações divididas e ocultas. Os valores são totais de registros por natureza, não receitas/despesas consolidadas.

### 11.2 Comparação quantitativa dos universos com uma leitura

```sql
WITH BASE AS (
  SELECT CD_NTZ_CTB_TRAN AS NTZ, IN_VSLO_CSM AS CSM,
         IN_VSLO_CX AS CX, IN_VSLO_EVT AS EVT,
         IN_DVS_LCTO AS DVS, IN_OCTR_TRAN AS OCTR
  FROM DB2GFP.TRAN_RLZD_INST_PCT
  WHERE CD_CLI = :mci
    AND CD_PRD IN (6,9)
    AND CD_EST_TRAN_INST = 0
    AND CD_TIP_MOE_CRR = 'BRL'
    AND CD_NTZ_CTB_TRAN IN ('C','D')
    AND DT_TRAN BETWEEN :dataIni AND :dataFim
)
SELECT COUNT_BIG(*) AS QT_BASE_CD,
       COUNT_BIG(CASE WHEN NTZ='C' OR (NTZ='D' AND CSM='S') THEN 1 END) AS QT_RADAR_ATUAL,
       COUNT_BIG(CASE WHEN CX='S' THEN 1 END) AS QT_CAIXA,
       COUNT_BIG(CASE WHEN EVT='S' THEN 1 END) AS QT_EVENTOS,
       COUNT_BIG(CASE WHEN NTZ='D' AND CSM='S' THEN 1 END) AS QT_CONSUMO,
       COUNT_BIG(CASE WHEN NTZ='D' AND CSM<>'S' THEN 1 END) AS QT_DEB_FORA_RADAR,
       COUNT_BIG(CASE WHEN NTZ='C' AND CX<>'S' THEN 1 END) AS QT_CRED_FORA_CAIXA,
       COUNT_BIG(CASE WHEN DVS='S' THEN 1 END) AS QT_ORIGINAIS_DIVIDIDOS,
       COUNT_BIG(CASE WHEN OCTR='S' THEN 1 END) AS QT_OCULTOS
FROM BASE;
```

Essas alternativas isolam a visibilidade sob a mesma base física; não reproduzem as consultas V7 completas. `COUNT_BIG(CASE...)` conta somente expressões não nulas e retorna 0 para conjunto vazio. Validar resultados por MCI e natureza, bem como os valores correspondentes.

### 11.3 Diagnóstico por tipo, categoria e produto

```sql
SELECT CD_PRD, CD_TIP_TRAN, CD_NTZ_CTB_TRAN,
       CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL,
       IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT,
       COUNT_BIG(*) AS QT,
       SUM(CAST(VL_TRAN AS DECIMAL(25,2))) AS VL
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = :mci
  AND CD_PRD IN (6,9)
  AND CD_EST_TRAN_INST = 0
  AND CD_TIP_MOE_CRR = 'BRL'
  AND DT_TRAN BETWEEN :dataIni AND :dataFim
GROUP BY CD_PRD, CD_TIP_TRAN, CD_NTZ_CTB_TRAN,
         CD_CTGR_TRAN, CD_CTGR_TRAN_OGNL,
         IN_VSLO_CSM, IN_VSLO_CX, IN_VSLO_EVT
ORDER BY QT DESC;
```

O objetivo é identificar tipos e categorias responsáveis pelas diferenças, sem depender exclusivamente da descrição textual. Confrontar categoria atual e original, inclusive a distribuição do grupo 13.

### 11.4 Diagnóstico de parcelas de cartão

```sql
SELECT A.CD_NTZ_CTB_TRAN, A.IN_VSLO_CSM, A.IN_VSLO_CX, A.IN_VSLO_EVT,
       B.NR_PCL_CPR, B.QT_PCL_CPR,
       COUNT_BIG(*) AS QT,
       SUM(CAST(A.VL_TRAN AS DECIMAL(25,2))) AS VL
FROM DB2GFP.TRAN_RLZD_INST_PCT A
LEFT JOIN DB2GFP.CMPT_TRAN_RLZD_CRT B
  ON B.NR_TRAN_INST_PCT = A.NR_TRAN_INST_PCT
WHERE A.CD_CLI = :mci AND A.CD_PRD = 9
  AND A.CD_EST_TRAN_INST = 0 AND A.CD_TIP_MOE_CRR = 'BRL'
  AND A.DT_TRAN BETWEEN :dataIni AND :dataFim
GROUP BY A.CD_NTZ_CTB_TRAN, A.IN_VSLO_CSM, A.IN_VSLO_CX, A.IN_VSLO_EVT,
         B.NR_PCL_CPR, B.QT_PCL_CPR;
```

Verificar compra à vista, parcelada, valor total de compra, parcela, fatura e estorno, inclusive ausência do complemento. Não deduzir representação econômica apenas por `QT_PCL_CPR`/`NR_PCL_CPR`.

### 11.5 Relação entre originais divididos e derivados

```sql
SELECT A.NR_TRAN_INST_PCT, A.VL_TRAN AS VL_ORIGINAL,
       COUNT_BIG(B.NR_TRAN_INCD_CLI) AS QT_DERIVADOS,
       SUM(CAST(B.VL_TRAN AS DECIMAL(25,2))) AS VL_DERIVADOS
FROM DB2GFP.TRAN_RLZD_INST_PCT A
LEFT JOIN DB2GFP.TRAN_INCD_CLI B
  ON B.NR_TRAN_RLZD_OGM = A.NR_TRAN_INST_PCT
 AND B.CD_CLI = A.CD_CLI
WHERE A.CD_CLI = :mci AND A.IN_DVS_LCTO = 'S'
  AND A.CD_PRD IN (6,9) AND A.CD_EST_TRAN_INST = 0
  AND A.CD_TIP_MOE_CRR = 'BRL'
  AND A.DT_TRAN BETWEEN :dataIni AND :dataFim
GROUP BY A.NR_TRAN_INST_PCT, A.VL_TRAN;
```

Consulta diagnóstica inicial: não filtra derivados por estado, moeda ou natureza propositalmente, para identificar todas as relações. Uma conferência monetária de equivalência precisa examinar essas dimensões, datas e valores antes de comparar somas.

### 11.6 Verificar unicidade e cobertura de conta

```sql
SELECT CD_CLI, NR_TRAN_INST_PCT, COUNT_BIG(*) AS QT
FROM DB2GFP.TRAN_RLZD_INST_PCT
WHERE CD_CLI = :mci AND DT_TRAN BETWEEN :dataIni AND :dataFim
GROUP BY CD_CLI, NR_TRAN_INST_PCT
HAVING COUNT_BIG(*) > 1;

SELECT COUNT_BIG(*) AS QT_BASE,
       COUNT_BIG(CASE WHEN B.CD_CLI_TITR_CT IS NULL THEN 1 END) AS QT_SEM_CONTA,
       COUNT_BIG(CASE WHEN B.IN_EXB_DADO_CT = 'N' THEN 1 END) AS QT_CONTA_NAO_EXIBIDA
FROM DB2GFP.TRAN_RLZD_INST_PCT A
LEFT JOIN DB2GFP.INF_OPB_CT_CLI B
  ON B.CD_CLI_TITR_CT = A.CD_CLI
 AND B.NR_MCA_PCT_OPB = A.NR_MCA_PCT_OPB
 AND B.NR_SEQL_CT_CLI = A.NR_SEQL_CT_CLI
WHERE A.CD_CLI = :mci AND A.CD_PRD IN (6,9)
  AND A.CD_EST_TRAN_INST = 0 AND A.CD_TIP_MOE_CRR = 'BRL'
  AND A.DT_TRAN BETWEEN :dataIni AND :dataFim;
```

Além da chave física, testar a unicidade após associação ao público, união de intervalos de leitura, complementos e reconciliação. Comparar diferença de cobertura com a perspectiva de exibição do GFP sem importar filtros automaticamente.

### 11.7 Matriz de casos de homologação

| Caso sintético | Resultado esperado da regra vigente |
|---|---|
| Crédito CSM=N, BRL, estado 0, produto 6, interno | Conta 1 |
| Débito CSM=S, demais filtros válidos | Conta 1 |
| Débito CSM=N, CX=S, demais filtros válidos | Conta 0 |
| Crédito CX=N, EVT=N, demais filtros válidos | Conta 1 |
| Débito CSM=S, CX=N, EVT=N | Conta 1 |
| Estado 1 ou 9 | Não conta |
| Produto 3 ou outro fora de 6/9 | Não conta |
| Moeda EUR/USD | Não conta |
| Natureza não C/D | Não conta |
| Data igual a início ou fim | Conta se elegível |
| Data até cinco dias fora | Não conta; pode servir ao contexto se elegível |
| Data a seis dias ou mais da borda | Não participa da busca de contexto |
| Original dividido DVS=S | Conta se elegível; derivados não são fonte |
| Ocultação=S | Conta se elegível |
| Categoria/grupo 13 | Conta se elegível |
| Marca nula | Conta se elegível; não pode formar par pela regra 8 |
| Sem conta correspondente no cadastro | Conta se elegível; regra 7 não exige join |
| Dois registros distintos de mesma data e valor | Contam 2, até reconciliação posterior |
| Repetição do mesmo ID após leitura | Contar uma vez e investigar duplicação |
| Participante sem movimentos | Zero |
| Não participante | Nulo |
| Par exato de dois movimentos internos | QT_MOV_CICLO=2; QT_PARES_EXATOS=1; QT_TRANS_TOTAL=0 |
| Par de borda com uma ponta interna | QT_MOV_CICLO=1; QT_PARES_BORDA=1; QT_TRANS_TOTAL=0 |
| Crédito elegível e contraparte D CSM=N | Crédito conta; débito não entra no universo para parear |

## 12. Decisões recomendadas e pendências

| Item | Situação | Encaminhamento |
|---|---|---|
| Produto 6/9, BRL, estado 0, data inclusiva | Fundamentados no escopo vigente e no catálogo | Manter como referência |
| CSM somente em débito | Confirmado como filtro da regra; sem prova de adequação integral ao Radar | Homologar diferenças em relação a CX e EVT |
| Divisão de lançamento | Código e modelo comprovam tratamento com outra fonte | Não excluir originais sem definir substituição |
| Ocultação de transação | Campo documentado; IR filtra, demais retornam indicador | Não impor como critério geral sem decisão de negócio |
| Grupo 13 | Exclusão no código de movimentação e IR confirmada | Consultar descrição e composição; avaliar categoria atual vs original |
| Cartão/fatura/parcelas | Complemento e exemplo de consumo conhecidos | Examinar registros reais e medir superposição de representações |
| Pix mesma titularidade | Comparação de documentos apresentada | Verificar sentido, qualidade, instituição e complementaridade; não presumir que a igualdade identifica par completo |
| Ausência de conta/marca | Filtro de apresentação no V7 confirmado | Quantificar, não excluir automaticamente |
| Regra 7–9 | Planejamento documental | Implementar somente depois de definir universo e testes |
| Desempenho | Catálogo e desenho de partições disponíveis; sem plano de acesso | Homologar com volume e planos reais |

**Questão decisória:** o Radar pretende medir registros bancários observados, consumo econômico, fluxo de caixa ou um universo próprio para seu orçamento reconciliado? A escolha precisa ser explícita. Uma comparação de quantidade de registros sozinha não responde qual é a regra correta.

**Conclusão:** `tran.txt` é evidência funcional importante porque demonstra como o GFP utiliza o catálogo. O Radar não deve simplesmente copiar a tela ou a consulta V7; deve escolher a perspectiva financeira adequada e manter um contrato de contagem auditável. A análise sustenta a revisão da descrição de QT_MOV_CICLO, mas não autoriza mudar seus filtros sem homologação. Nenhum dos quatro arquivos de origem foi modificado.

---

# Apêndice A — Dicionário físico completo das sete tabelas relevantes

Dados extraídos diretamente do snapshot SYSIBM. `KEYSEQ` indica posição na chave; “—” significa zero no catálogo. Tipos CHAR/DECIMAL têm comprimentos e escala expressos; para TIMESTAMP, a escala de 6 é a do catálogo. `NULLS=Y` permite nulo. Não inferir default de negócio apenas a partir de `DEFAULT=Y` e `DEFAULTVALUE` vazio do snapshot. O apêndice não é uma reconstrução do DDL físico completo.

## A.1 `DB2GFP.TRAN_RLZD_INST_PCT`

Database: `D1GFP01` · Tablespace: `S1GFP101` · Colunas: 35 · Última alteração catalogada: 2024-02-08 01:54:55.637800.

ERwin: TRANSAÇÃO REALIZADA EM INSTITUIÇÃO PARTICIPANTE (`O_Id 9640`).

| Campo | Tipo | Nulo | KEYSEQ | Nome lógico ERwin (quando localizado) |
|---|---|---|---|---|
| `NR_TRAN_INST_PCT` | BIGINT | Não | 1 | Número de Transação Realizada em Instituição Participante |
| `NR_PTC` | SMALLINT | Não | — | Número da Partição |
| `CD_CLI` | INTEGER | Não | — | Código do Cliente da Transação |
| `CD_TIP_PSS` | DECIMAL(1,0) | Não | — | — |
| `NR_CPF_CNPJ_TITR` | DECIMAL(14,0) | Não | — | Número do CPF ou CNPJ do Titular |
| `NR_MCA_PCT_OPB` | DECIMAL(11,0) | Sim | — | — |
| `CD_INST_PCT` | DECIMAL(14,0) | Não | — | Código da Instituição Participante |
| `NR_AG_TITR` | SMALLINT | Sim | — | Número da Agência do Titular |
| `CD_CT_TITR` | CHAR(20) | Sim | — | Código da Conta do Titular |
| `DV_CT_TITR` | CHAR(1) | Sim | — | Dígito Verificador da Conta do Titular |
| `CD_PRD` | SMALLINT | Não | — | — |
| `VL_TRAN` | DECIMAL(15,2) | Não | — | Valor da Transação |
| `CD_TIP_MOE_CRR` | CHAR(3) | Não | — | — |
| `TX_DCR_TRAN` | CHAR(200) | Não | — | Texto da Descrição da Transação |
| `TX_CMPR_DCR_TRAN` | CHAR(50) | Sim | — | Texto Complementar da Descrição da Transação |
| `TX_DCR_TRAN_OGNL` | CHAR(200) | Sim | — | Texto Descrição da Transação Original |
| `CD_NTZ_CTB_TRAN` | CHAR(1) | Não | — | — |
| `DT_TRAN` | DATE | Não | — | Data da Transação |
| `HR_TRAN` | TIME | Sim | — | Horário da Transação |
| `CD_CTGR_TRAN` | INTEGER | Não | — | — |
| `CD_CTGR_TRAN_OGNL` | INTEGER | Não | — | Código da Categoria da Transação Original |
| `CD_HASH_AGPT_TRAN` | CHAR(32) | Não | — | Código Hash de Agrupamento da Transação |
| `CD_EST_TRAN_INST` | SMALLINT | Não | — | — |
| `CD_TIP_TRAN` | CHAR(36) | Não | — | Código do Tipo de Transação |
| `IN_VSLO_EVT` | CHAR(1) | Não | — | Indicador de Visualização de Evento |
| `TS_INCL_TRAN` | TIMESTAMP(6) | Não | — | Timestamp de Inclusão da Transação |
| `TS_ATL_TRAN` | TIMESTAMP(6) | Sim | — | Timestamp de Atualização da Transação |
| `IN_TRAN_IR` | CHAR(1) | Não | — | Indicador de Transação com Imposto de Renda |
| `IN_VSLO_CX` | CHAR(1) | Não | — | Indicador de Visualização de Fluxo de Caixa |
| `IN_VSLO_CSM` | CHAR(1) | Não | — | Indicador de Visualização no Perfil de Consumo |
| `IN_OCTR_TRAN` | CHAR(1) | Não | — | Indicador de Ocultar Transação |
| `NR_SEQL_CT_CLI` | SMALLINT | Sim | — | — |
| `CD_TRAN_IR` | SMALLINT | Não | — | — |
| `IN_DVS_LCTO` | CHAR(1) | Não | — | Indicador de Divisão de Lançamento |
| `CD_CLSC_MTO_CTGR` | CHAR(1) | Sim | — | — |

## A.2 `DB2GFP.TRAN_INCD_CLI`

Database: `D1GFP01` · Tablespace: `S1GFP120` · Colunas: 33 · Última alteração catalogada: 2024-02-08 01:12:28.550375.

ERwin: TRANSAÇÃO INCLUIDA PELO CLIENTE (`O_Id 11014`).

| Campo | Tipo | Nulo | KEYSEQ | Nome lógico ERwin (quando localizado) |
|---|---|---|---|---|
| `NR_TRAN_INCD_CLI` | BIGINT | Não | 1 | Número de Transação Incluida pelo Cliente |
| `CD_CLI` | INTEGER | Não | — | Código do Cliente da Transação |
| `CD_TIP_PSS` | DECIMAL(1,0) | Não | — | — |
| `NR_CPF_CNPJ_TITR` | DECIMAL(14,0) | Não | — | Número do CPF ou CNPJ do Titular |
| `NR_MCA_PCT_OPB` | DECIMAL(11,0) | Sim | — | — |
| `CD_INST_PCT` | DECIMAL(14,0) | Não | — | Código da Instituição Participante |
| `NR_AG_TITR` | SMALLINT | Sim | — | Número da Agência do Titular |
| `CD_CT_TITR` | CHAR(20) | Sim | — | Código da Conta do Titular |
| `DV_CT_TITR` | CHAR(1) | Sim | — | Dígito Verificador da Conta do Titular |
| `CD_PRD` | SMALLINT | Não | — | Código Produto da Transação |
| `VL_TRAN` | DECIMAL(15,2) | Não | — | Valor da Transação |
| `CD_TIP_MOE_CRR` | CHAR(3) | Não | — | — |
| `TX_DCR_TRAN` | CHAR(200) | Não | — | Texto da Descrição da Transação |
| `TX_CMPR_DCR_TRAN` | CHAR(50) | Sim | — | Texto Complementar da Descrição da Transação |
| `TX_DCR_TRAN_OGNL` | CHAR(200) | Sim | — | Texto Descrição da Transação Original |
| `CD_NTZ_CTB_TRAN` | CHAR(1) | Não | — | Código da Natureza Contábil da Transação |
| `DT_TRAN` | DATE | Não | — | Data da Transação |
| `HR_TRAN` | TIME | Sim | — | Horário da Transação |
| `CD_CTGR_TRAN` | INTEGER | Não | — | — |
| `CD_CTGR_TRAN_OGNL` | INTEGER | Não | — | Código da Categoria da Transação Original |
| `CD_HASH_AGPT_TRAN` | CHAR(32) | Não | — | Código Hash de Agrupamento da Transação |
| `CD_EST_TRAN_INST` | SMALLINT | Não | — | — |
| `CD_TIP_TRAN` | CHAR(36) | Não | — | Código do Tipo de Transação |
| `IN_VSLO_EVT` | CHAR(1) | Não | — | Indicador de Visualização de Evento |
| `TS_INCL_TRAN` | TIMESTAMP(6) | Não | — | Timestamp de Inclusão da Transação |
| `TS_ATL_TRAN` | TIMESTAMP(6) | Sim | — | Timestamp de Atualização da Transação |
| `IN_TRAN_IR` | CHAR(1) | Não | — | Indicador de Transação com Imposto de Renda |
| `IN_VSLO_CX` | CHAR(1) | Não | — | Indicador de Visualização de Fluxo de Caixa |
| `IN_VSLO_CSM` | CHAR(1) | Não | — | Indicador de Visualização no Perfil de Consumo |
| `IN_OCTR_TRAN` | CHAR(1) | Não | — | Indicador de Ocultar Transação |
| `NR_SEQL_CT_CLI` | SMALLINT | Sim | — | — |
| `CD_TRAN_IR` | SMALLINT | Não | — | — |
| `NR_TRAN_RLZD_OGM` | BIGINT | Sim | — | Número de Transação Realizada Origem |

## A.3 `DB2GFP.CMPT_TRAN_RLZD_CC`

Database: `D1GFP01` · Tablespace: `S1GFP108` · Colunas: 23 · Última alteração catalogada: 2025-10-25 01:50:19.420865.

ERwin: COMPLEMENTO DA TRANSAÇÃO REALIZADA EM CONTA CORRENTE (`O_Id 10041`).

| Campo | Tipo | Nulo | KEYSEQ | Nome lógico ERwin (quando localizado) |
|---|---|---|---|---|
| `NR_TRAN_INST_PCT` | BIGINT | Não | 1 | — |
| `NR_PTC` | SMALLINT | Não | — | Número da Partição |
| `NM_TRAN_INST` | CHAR(60) | Não | — | Nome da Transação em Instituição Participante |
| `CD_IDFR_TRAN_INST` | CHAR(100) | Sim | — | Codigo Identificador da Transação na Instituição Participante |
| `CD_IDFR_CT` | CHAR(100) | Sim | — | Código Identificador da Conta |
| `NR_CPF_CNPJ_PGDR` | DECIMAL(14,0) | Sim | — | Número do CPF CNPJ do Pagador ou Beneficiário |
| `CD_TIP_PGDR_BNFC` | DECIMAL(1,0) | Sim | — | Código do Tipo de Pessoa do Pagador ou Beneficiário |
| `CD_CPSO_PGDR_BNFC` | SMALLINT | Sim | — | Código COMPE do Pagador ou Beneficiário |
| `NR_AG_PGDR_BNFC` | SMALLINT | Sim | — | Número da Agência do Pagador ou Beneficiário |
| `CD_CT_PGDR_BNFC` | CHAR(20) | Sim | — | Código da Conta do Pagador ou Beneficiário |
| `DV_CT_PGDR_BNFC` | CHAR(1) | Sim | — | Dígito Verificador da Conta do Pagador ou beneficiario |
| `NR_DOC` | DECIMAL(15,0) | Sim | — | Número do Documento |
| `CD_HST_TRAN` | INTEGER | Sim | — | Código Histórico da Transação |
| `CD_SHST_TRAN` | INTEGER | Sim | — | Codigo do Sub Historico da Transação |
| `CD_SEQL_TRAN` | INTEGER | Sim | — | Código Sequencial da Transação |
| `NR_LT_TRAN` | INTEGER | Sim | — | Número do Lote da Transação |
| `CD_TRAN_CTA` | CHAR(44) | Sim | — | Código da Transação de Contestação |
| `DT_CTB_TRAN` | DATE | Sim | — | Data Contabil da Transação |
| `CD_CLI` | INTEGER | Não | — | Código do Cliente da Transação |
| `NR_MCA_PCT_OPB` | DECIMAL(11,0) | Sim | — | Numero da Marca Participante do Openbanking |
| `NR_SEQL_CT_CLI` | SMALLINT | Sim | — | Numero Sequencial da Conta do Cliente |
| `CD_CLSC_ATVD_ECNC` | INTEGER | Sim | — | — |
| `CD_CTGR_CML` | CHAR(4) | Sim | — | Código da Categoria Comercial |

## A.4 `DB2GFP.CMPT_TRAN_RLZD_CRT`

Database: `D1GFP01` · Tablespace: `S1GFP110` · Colunas: 22 · Última alteração catalogada: 2022-07-17 19:24:05.770859.

ERwin: COMPLEMENTO DA TRANSAÇÃO REALIZADA EM CARTÃO DE CREDITO (`O_Id 10421`).

| Campo | Tipo | Nulo | KEYSEQ | Nome lógico ERwin (quando localizado) |
|---|---|---|---|---|
| `NR_TRAN_INST_PCT` | BIGINT | Não | 1 | — |
| `NR_PTC` | SMALLINT | Não | — | Número da Partição |
| `CD_IDFR_TRAN_INST` | CHAR(100) | Sim | — | Código Identificador da Transação na Instituição Participante |
| `CD_IDFR_CRT` | CHAR(100) | Não | — | Código Identificador do Cartão |
| `CD_CLI_TITR_CT` | INTEGER | Sim | — | — |
| `NR_MCA_PCT_OPB` | DECIMAL(11,0) | Sim | — | — |
| `NR_SEQL_CT_CLI` | SMALLINT | Sim | — | — |
| `NR_FAT_CRT` | INTEGER | Sim | — | — |
| `TX_TIP_PGTO` | CHAR(100) | Não | — | Texto Tipo de Pagamento |
| `TX_PCL_CPR` | CHAR(50) | Não | — | Texto da Parcela da Compra |
| `QT_PCL_CPR` | SMALLINT | Não | — | Quantidade Total de Parcelas da Compra |
| `VL_OGNL_MOE_MVT` | DECIMAL(15,2) | Não | — | Valor Original da Moeda Movimento |
| `DT_TRAN_FAT` | DATE | Não | — | Data da Transação na Fatura |
| `CD_CTGR_CML` | CHAR(4) | Não | — | Código da Categoria Comercial |
| `TX_CMPR_TIP_TRAN` | CHAR(140) | Não | — | Texto Complementar Tipo Transação |
| `TX_TIP_TARF` | CHAR(100) | Sim | — | Texto Tipo de Tarifa |
| `TX_CMPR_TIP_TARF` | CHAR(140) | Sim | — | Texto Complementar Tipo de Tarifa |
| `TX_TIP_CRD_CTRD` | CHAR(100) | Sim | — | Texto Tipo Crédito Contratado |
| `TX_CMPR_TIP_CRD` | CHAR(50) | Sim | — | Texto Complementar Tipo Crédito Contratado |
| `NR_PCL_CPR` | SMALLINT | Não | — | Numero da Parcela da Compra |
| `CD_TIP_TRAN_CRT` | INTEGER | Sim | — | Codigo do Tipo de Transação de Cartão |
| `TX_TIP_LNCD` | CHAR(100) | Sim | — | Texto de Tipo de Linha de Credito |

## A.5 `DB2GFP.INF_OPB_CT_CLI`

Database: `D1GFP01` · Tablespace: `S1GFP102` · Colunas: 26 · Última alteração catalogada: 2025-03-27 20:46:17.704609.

ERwin: INFORMAÇÃO DO OPENBANKING DA CONTA DO CLIENTE (`O_Id 10002`).

| Campo | Tipo | Nulo | KEYSEQ | Nome lógico ERwin (quando localizado) |
|---|---|---|---|---|
| `CD_CLI_TITR_CT` | INTEGER | Não | 1 | Código do Cliente Titular da Conta |
| `NR_MCA_PCT_OPB` | DECIMAL(11,0) | Não | 2 | — |
| `NR_SEQL_CT_CLI` | SMALLINT | Não | 3 | Numero Sequencial da Conta do Cliente |
| `CD_CPF_CNPJ_TITR` | DECIMAL(14,0) | Não | — | Código do CPF ou CNPJ do Titular |
| `CD_INST_PCT` | DECIMAL(14,0) | Não | — | Código de Identificação da Instituição Participante do OpenBanking |
| `CD_CPSO_INST_PCT` | SMALLINT | Sim | — | Código Compe da Instituição Participante |
| `CD_TIP_PSS` | DECIMAL(1,0) | Não | — | — |
| `CD_IDFR_CT` | CHAR(100) | Não | — | Código Identificador da Conta |
| `CD_AG_DTTR_CT` | SMALLINT | Sim | — | Código da Agência Detentora da Conta |
| `CD_CT_TITR` | CHAR(20) | Sim | — | Código da Conta do Titular |
| `DV_CT_TITR` | CHAR(1) | Sim | — | Dígito Verificador da Conta do Titular |
| `CD_TIP_CT_OPB` | SMALLINT | Sim | — | Código do Tipo de Conta de Origem do OpenBanking |
| `CD_PRD` | SMALLINT | Sim | — | — |
| `CD_MDLD_PRD` | SMALLINT | Sim | — | — |
| `TS_ATL_INF` | TIMESTAMP(6) | Não | — | Timestamp de Atualização da Informação |
| `IN_AUTZ_EXB_TRAN` | CHAR(1) | Não | — | Indicador de Autorização de Exibição de Transação |
| `TS_ULT_ATL_TRAN` | TIMESTAMP(6) | Sim | — | Timestamp da Ultima Atualização da Transação |
| `NM_IDFC_CT` | CHAR(50) | Sim | — | Nome de Identificação da Conta |
| `TX_TIP_CT_CRT` | CHAR(27) | Sim | — | Texto do Tipo da Conta Cartão |
| `TX_CMPR_TIP_CT_CRT` | CHAR(50) | Sim | — | Texto Complementar do Tipo Conta Cartão |
| `TX_BND_CT_CRT` | CHAR(18) | Sim | — | Texto da Bandeira da Conta Cartão |
| `TX_CMPR_BND_CT_CRT` | CHAR(50) | Sim | — | Texto Complementar da Bandeira da Conta Cartão |
| `NR_IDFR_PLST_CT` | SMALLINT | Sim | — | Número Identificador do Plastico da Conta Cartão |
| `IN_EXB_DADO_CT` | CHAR(1) | Não | — | Indicador de Exibição dos Dados da Conta |
| `NR_SEQL_AUTZ_OPB` | INTEGER | Sim | — | Número Sequencial Autorização OpenBanking |
| `CD_EST_RCS_OPB` | SMALLINT | Sim | — | Código do Estado do Recurso OpenBanking |

## A.6 `DB2GFP.CTGR_TRAN_OPB`

Database: `D1GFP01` · Tablespace: `S1GFP105` · Colunas: 6 · Última alteração catalogada: 2023-01-26 11:15:03.898192.

ERwin: CATEGORIA DA TRANSAÇÃO  DO OPENBANKING (`O_Id 10074`).

| Campo | Tipo | Nulo | KEYSEQ | Nome lógico ERwin (quando localizado) |
|---|---|---|---|---|
| `CD_CTGR_TRAN` | INTEGER | Não | 1 | Código da Categoria da Transação do OpenBanking |
| `CD_GR_CTGR_TRAN` | SMALLINT | Não | — | — |
| `CD_NTZ_CTB_TRAN` | CHAR(1) | Não | — | — |
| `IN_CTGR_PDRO_SIS` | CHAR(1) | Não | — | Indicador de Categoria Padrao do Sistema |
| `TX_DCR_CTGR_TRAN` | CHAR(60) | Não | — | Texto Descrição da Categoria da Transação |
| `CD_TRAN_IR` | SMALLINT | Não | — | — |

## A.7 `DB2GFP.GR_CTGR_TRAN`

Database: `D1GFP01` · Tablespace: `S1GFP029` · Colunas: 3 · Última alteração catalogada: 2025-05-22 17:20:29.425961.

ERwin: GRUPO DE CATEGORIA DE TRANSAÇÃO (`O_Id 3496`).

| Campo | Tipo | Nulo | KEYSEQ | Nome lógico ERwin (quando localizado) |
|---|---|---|---|---|
| `CD_GR_CTGR_TRAN` | SMALLINT | Não | 1 | CODIGO DO GRUPO DE CATEGORIA DE TRANSAÇÃO |
| `TX_DCR_GR_CTGR` | CHAR(60) | Não | — | TEXTO DESCRICAO DO GRUPO DE CATEGORIA DE TRANSAÇÃO |
| `CD_COR_GR_CTGR` | CHAR(7) | Não | — | CÓDIGO DA COR DO GRUPO DE CATEGORIA DE TRANSAÇÃO |

# Apêndice B — Referências rápidas para verificação

| Assunto | Localização |
|---|---|
| Definição da tabela principal | GFP.json, O_Id 9640 |
| Definição de inclusão manual e divisão | GFP.json, O_Id 11014 e 10995 |
| Visibilidade consumo, caixa, eventos | GFP.json, O_Id 10603, 10601, 9812 |
| Ocultação e IR | GFP.json, O_Id 10605, 10599 |
| Data, valor, horário, categoria original | GFP.json, O_Id 9645, 9644, 9824, 10150 |
| Chaves e tipos físicos | db2gfp_estrutura_sysibm.json, `tabelas`, entradas com nomes do apêndice A |
| Pix de mesma titularidade, complementos | tran.txt, linhas 1–25 |
| Listagem geral | tran.txt, 41–282; seleção 74–79 |
| Categorias | tran.txt, 288–531; seleção 320–327 |
| Movimentação financeira | tran.txt, 537–778; seleção 569–575; grupo 739–748 |
| Agendadas | tran.txt, 783–935; seleção 818–824 |
| IR | tran.txt, 937–1182; seleção 969–977; grupo 1152 |
| Contagem total | tran.txt, 1184–1396; seleção 1217–1222; COUNT(*) 1395 |
| Regra 7 e janela | radar_todos_v1.ipynb, células 32–35 |
| Reconciliação e agregados | radar_todos_v1.ipynb, células 36–39 |
| Identidade e escrita | radar_todos_v1.ipynb, célula 42 |

**Fim da documentação.**
