"""Configuração técnica mínima do painel."""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

from dotenv import load_dotenv


@dataclass(frozen=True)
class Configuracao:
    db2_user: str | None
    db2_pass: str | None
    moeda_padrao: str
    incluir_plotly_offline: bool
    fetchsize_db2: int


def _bool_env(nome: str, padrao: bool) -> bool:
    valor = os.getenv(nome)
    if valor is None:
        return padrao
    return valor.strip().lower() in {"1", "true", "sim", "s", "yes", "y"}


def carregar_configuracao(env_path: str | Path = "desenv.env") -> Configuracao:
    load_dotenv(Path(env_path), override=False)
    moeda = os.getenv("DASHBOARD_MOEDA_PADRAO", "BRL").strip().upper()
    if len(moeda) != 3 or not moeda.isalpha():
        raise ValueError("DASHBOARD_MOEDA_PADRAO deve conter três letras.")
    fetchsize = int(os.getenv("DB2_FETCHSIZE", "10000"))
    if fetchsize <= 0:
        raise ValueError("DB2_FETCHSIZE deve ser maior que zero.")
    return Configuracao(
        db2_user=os.getenv("DB2_USER"),
        db2_pass=os.getenv("DB2_PASS"),
        moeda_padrao=moeda,
        incluir_plotly_offline=_bool_env("DASHBOARD_PLOTLY_OFFLINE", True),
        fetchsize_db2=fetchsize,
    )


__all__ = ["Configuracao", "carregar_configuracao"]
