# Jornada Financeira do Cliente

Aplicação analítica executada dentro do Jupyter para responder, no mesmo período:

1. **De onde o dinheiro provavelmente veio?**
2. **Quais entradas parecem externas, recorrentes ou salário provável?**
3. **Quais créditos podem ser apenas circulação entre contas?**
4. **Qual papel cada instituição exerce na vida financeira observada?**
5. **O que foi observado depois dos recebimentos recorrentes?**
6. **Quais conclusões são fatos, cálculos, hipóteses ou casos inconclusivos?**

A categorização é recebida das fontes e preservada. O projeto não corrige categorias. Ela aparece apenas como evidência auxiliar e como rótulo para descrever as saídas observadas.

## Navegação

- **Jornada do dinheiro** — síntese integrada de origem, circulação e uso.
- **Origem e renda** — entradas externas prováveis, fontes recorrentes, salário provável, dias e valores típicos.
- **Circulação e bancos** — pares candidatos, rotas, papéis bancários e principalidade por função.
- **Uso do dinheiro** — movimentos observados depois dos recebimentos, em janelas e ciclos.
- **Evidências e qualidade** — duplicidades, ambiguidades, reconciliação, movimentações e limitações.

## Estrutura

```text
jornada_financeira_cliente/
├── src/
│   ├── app.py          # entrada pública e orquestração
│   ├── config.py       # credenciais e parâmetros técnicos
│   ├── fontes.py       # schemas, tabelas, colunas e chaves
│   ├── modelos.py      # contratos e estados
│   ├── regras.py       # decisões analíticas versionadas
│   ├── dados.py        # conexão bbmagic e SQL restrito
│   ├── qualidade.py    # grão e duplicidades
│   ├── circulacao.py   # pareamento entre contas
│   ├── renda.py        # origem, recorrência e salário provável
│   ├── jornada.py      # papéis bancários e pós-recebimento
│   ├── analise.py      # integração e payload
│   ├── visual.py       # HTML, CSS, JavaScript e Plotly
│   ├── validacoes.py   # ambiente, fontes, pipeline e execução
│   └── tests/
├── requirements.txt
├── desenv.env
├── rotina-principal.ipynb
└── todas_validacoes.ipynb
```

## Configuração

Preencha apenas as credenciais corporativas no `desenv.env`:

```env
DB2_USER=
DB2_PASS=
```

O identificador do cliente não deve ser gravado no arquivo. A biblioteca `bbmagic` precisa existir no ambiente corporativo autorizado.

## Execução visual

O notebook usa entrada oculta para o identificador restrito. A chamada programática é:

```python
from src.app import fluxo_dashboard

resultado = fluxo_dashboard(
    cd_cli=codigo_restrito,
    periodo_inicio="2026-01-01",
    periodo_fim="2026-07-31",
    moeda="BRL",
    instituicoes=None,
    tela_inicial="jornada_dinheiro",
    exibir=True,
)
```

O período, a moeda e o filtro de instituições permeiam todas as análises. Não existe janela separada para Radar.

## Pipeline sem HTML

```python
from src.app import executar_pipeline

pipeline = executar_pipeline(
    cd_cli=codigo_restrito,
    periodo_inicio="2026-01-01",
    periodo_fim="2026-07-31",
)
```

Essa é a mesma rota usada pela interface e pelo notebook de validação.

## Leitura analítica das entradas

Cada crédito pode receber uma interpretação independente da categoria recebida:

- entrada externa provável;
- salário provável;
- renda recorrente provável;
- movimentação interna provável;
- crédito contratado provável;
- resgate de investimento provável;
- devolução ou ajuste provável;
- duplicidade provável;
- entrada inconclusiva.

### Salário provável

O motor considera, de forma versionada e auditável:

- ausência de par interno forte;
- recorrência em meses do período;
- concentração dos dias de recebimento;
- estabilidade do valor;
- consistência da conta receptora;
- assinatura protegida da origem;
- descrição e categoria recebida como evidências auxiliares;
- evidências contrárias de crédito, resgate ou ajuste.

O resultado nunca é apresentado como salário confirmado, renda oficial ou vínculo empregatício comprovado.

## Circulação entre contas

O motor inicial trata pares um para um. Um candidato exige:

- mesmo valor em centavos;
- mesma moeda;
- naturezas opostas;
- contas diferentes;
- datas com até três dias de distância.

Descrição compatível, contraparte, titular compatível e recorrência aumentam a evidência. Conflitos permanecem ambíguos. Nenhum candidato automático é confirmado.

A base observada nunca é alterada. A leitura estimada neutraliza apenas pares fortes, únicos e não revisados.

## Principalidade bancária

O projeto não força um único banco principal. Ele calcula papéis distintos:

- recebimento de renda;
- distribuição entre contas;
- pagamentos e uso cotidiano;
- reserva e investimento;
- crédito e custos financeiros;
- conta de passagem;
- uso ocasional.

Uma instituição central provável só aparece quando domina mais de um papel relevante no período.

## Uso após recebimento

Os ciclos começam em uma fonte recorrente provável e terminam no próximo recebimento ou no fim do período. São exibidas janelas cumulativas:

- mesmo dia;
- até 3 dias;
- até 7 dias;
- até 15 dias.

O acompanhamento inclui a conta receptora e contas alcançadas por transferências internas fortes nos primeiros dias. A sequência temporal não é apresentada como causalidade: o dinheiro é fungível.

## Duplicidades

O módulo de qualidade separa:

- duplicidade física pela chave original do evento;
- duplicidade econômica forte na mesma conta, data, hora, valor, natureza, moeda e descrição;
- duplicidade provável sem horário idêntico.

A leitura estimada neutraliza apenas repetições físicas ou econômicas fortes posteriores à primeira ocorrência. Sinais prováveis permanecem apenas destacados.

## Fontes físicas

Todos os nomes físicos estão centralizados em `fontes.py`:

- `DB2GFP.TRAN_RLZD_INST_PCT`
- `DB2GFP.INF_OPB_CT_CLI`
- `DB2GFP.CMPT_TRAN_RLZD_CC`
- `DB2GFP.CTGR_TRAN_OPB`
- `DB2GFP.GR_CTGR_TRAN`
- `DB2SMI.CLI_SGM`
- `DB2D1D.DVS_GRDR_FNCO_PF`

As consultas transacionais exigem cliente, data inicial, data final exclusiva, moeda e estado. Não há `SELECT *`, filtro fixo de partição nem varredura populacional da tabela coração.

## Notebook `todas_validacoes.ipynb`

Valida quatro camadas:

1. **Ambiente** — Python, dependências, arquivos e sintaxe.
2. **Fontes** — conexão, tabelas, permissões e contrato de colunas.
3. **Pipeline** — SQL seguro, regras e execução sem HTML.
4. **Execução** — duplicidades, circulação, fontes de renda, principalidade, ciclos e reconciliação.

A saída usa prints controlados, DataFrames e um ZIP sanitizado:

```text
saida_validacoes/validacao_<id_aleatorio>.zip
```

O identificador restrito:

- permanece somente em memória;
- não aparece em prints;
- não aparece em DataFrames exibidos;
- não entra em CSV, JSON, TXT ou nome de arquivo;
- não é transformado em hash exportável;
- bloqueia a exportação caso seja encontrado.

## Testes

```bash
python -m compileall src
pytest -q
```

Os testes cobrem SQL restrito, categorias preservadas, IDs únicos, duplicidades, circulação, salário provável, categoria conflitante com circulação, principalidade, ciclos, HTML, payload público e não exposição do identificador.

## Limitações assumidas

- salário e renda externa são hipóteses técnicas;
- circulação automática não comprova titularidade;
- categorias não são corrigidas;
- não há persistência de revisão humana nesta versão;
- o motor não concilia uma saída para várias entradas, várias saídas para uma entrada ou tarifas;
- compras e pagamentos de fatura não são conciliados contratualmente;
- o painel não representa saldo, patrimônio, renda oficial, vínculo empregatício ou dívida total.
