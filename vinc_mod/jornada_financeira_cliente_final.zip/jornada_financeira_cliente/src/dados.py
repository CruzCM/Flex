"""Acesso ao Db2 com consultas estritamente limitadas ao cliente e período."""
from __future__ import annotations

from datetime import date, timedelta
from time import perf_counter
from typing import Any, Iterable

import pandas as pd

from .config import Configuracao
from .fontes import (
    COLUNAS_CATEGORIAS,
    COLUNAS_COMPLEMENTOS_CONTA,
    COLUNAS_CONTAS,
    COLUNAS_GRUPOS,
    COLUNAS_TRANSACOES,
    FONTES,
    colunas_com_alias,
    tabela,
)
from .modelos import ConsultaPainel
from .regras import DATA_CORTE_PERFIL_RENDA


class ErroDados(RuntimeError):
    """Erro seguro de conexão, consulta ou conversão."""


_CACHE_CATALOGOS: dict[int, dict[str, pd.DataFrame]] = {}


def criar_cliente_db2(config: Configuracao) -> Any:
    if not config.db2_user or not config.db2_pass:
        raise ErroDados("Configure DB2_USER e DB2_PASS no arquivo desenv.env.")
    try:
        from bbmagic import Db2
    except ImportError as exc:
        raise ErroDados(
            "A biblioteca corporativa bbmagic não está disponível neste ambiente."
        ) from exc
    return Db2(user=config.db2_user, password=config.db2_pass)


def _para_pandas(resultado: Any) -> pd.DataFrame:
    if resultado is None:
        return pd.DataFrame()
    if isinstance(resultado, pd.DataFrame):
        frame = resultado.copy()
    elif hasattr(resultado, "toPandas"):
        frame = resultado.toPandas()
    else:
        try:
            frame = pd.DataFrame(resultado)
        except Exception as exc:
            raise ErroDados("O retorno do Db2 não pôde ser convertido para DataFrame.") from exc
    frame.columns = [str(coluna).upper() for coluna in frame.columns]
    return frame


def executar_select(cliente_db2: Any, sql: str, fetchsize: int) -> pd.DataFrame:
    try:
        resultado = cliente_db2.run_select(sql, fetchsize=fetchsize)
    except Exception as exc:
        # A mensagem original do driver pode conter SQL e parâmetros restritos.
        # O detalhe permanece encadeado apenas para depuração local autorizada;
        # a mensagem pública nunca replica o texto retornado pelo driver.
        raise ErroDados(f"Falha na consulta Db2 ({type(exc).__name__}).") from exc
    return _para_pandas(resultado)


def _validar_consulta(consulta: ConsultaPainel) -> None:
    if consulta.cd_cli <= 0:
        raise ValueError("cd_cli deve ser um inteiro positivo.")
    if consulta.periodo_inicio > consulta.periodo_fim:
        raise ValueError("periodo_inicio não pode ser posterior a periodo_fim.")
    if len(consulta.moeda) != 3 or not consulta.moeda.isalpha():
        raise ValueError("moeda deve conter três letras.")


def _filtros_transacao(consulta: ConsultaPainel, alias: str = "t") -> list[str]:
    _validar_consulta(consulta)
    fim_exclusivo = consulta.periodo_fim + timedelta(days=1)
    filtros = [
        f"{alias}.CD_CLI = {int(consulta.cd_cli)}",
        f"{alias}.DT_TRAN >= DATE('{consulta.periodo_inicio.isoformat()}')",
        f"{alias}.DT_TRAN < DATE('{fim_exclusivo.isoformat()}')",
        f"{alias}.CD_EST_TRAN_INST = 0",
        f"{alias}.CD_TIP_MOE_CRR = '{consulta.moeda}'",
    ]
    if consulta.instituicoes:
        valores = ", ".join(str(int(valor)) for valor in consulta.instituicoes)
        filtros.append(f"{alias}.CD_INST_PCT IN ({valores})")
    return filtros


def montar_sql_transacoes(consulta: ConsultaPainel) -> str:
    filtros = _filtros_transacao(consulta, "t")
    return f"""
        SELECT
            {colunas_com_alias(COLUNAS_TRANSACOES, 't')}
        FROM {tabela('transacoes')} t
        WHERE {' AND '.join(filtros)}
        ORDER BY t.DT_TRAN, t.HR_TRAN, t.NR_TRAN_INST_PCT
    """.strip()


def montar_sql_contas(consulta: ConsultaPainel) -> str:
    _validar_consulta(consulta)
    filtros = [f"c.CD_CLI_TITR_CT = {int(consulta.cd_cli)}"]
    if consulta.instituicoes:
        valores = ", ".join(str(int(valor)) for valor in consulta.instituicoes)
        filtros.append(f"c.CD_INST_PCT IN ({valores})")
    return f"""
        SELECT
            {colunas_com_alias(COLUNAS_CONTAS, 'c')}
        FROM {tabela('contas')} c
        WHERE {' AND '.join(filtros)}
    """.strip()


def montar_sql_complementos_conta(consulta: ConsultaPainel) -> str:
    """Carrega somente complementos ligados às transações do recorte.

    O EXISTS evita varrer complementos de outros clientes/períodos e também
    preserva registros cuja data contábil esteja nula.
    """
    filtros_t = _filtros_transacao(consulta, "t")
    return f"""
        SELECT
            {colunas_com_alias(COLUNAS_COMPLEMENTOS_CONTA, 'c')}
        FROM {tabela('complementos_conta')} c
        WHERE c.CD_CLI = {int(consulta.cd_cli)}
          AND EXISTS (
              SELECT 1
              FROM {tabela('transacoes')} t
              WHERE t.NR_PTC = c.NR_PTC
                AND t.NR_TRAN_INST_PCT = c.NR_TRAN_INST_PCT
                AND {' AND '.join(filtros_t)}
          )
    """.strip()


def montar_sql_categorias() -> str:
    return f"SELECT {', '.join(COLUNAS_CATEGORIAS)} FROM {tabela('categorias')}"


def montar_sql_grupos() -> str:
    return f"SELECT {', '.join(COLUNAS_GRUPOS)} FROM {tabela('grupos')}"


def montar_sql_perfil_renda(consulta: ConsultaPainel) -> str:
    return f"""
        SELECT CD_CLI, CD_PRFL, DT_REF_PERFIL_RENDA
        FROM (
            SELECT
                p.CD_CLI,
                p.CD_SGM_CLI AS CD_PRFL,
                p.DT_ENQ_CLI_SGM AS DT_REF_PERFIL_RENDA,
                ROW_NUMBER() OVER (
                    PARTITION BY p.CD_CLI
                    ORDER BY p.DT_ENQ_CLI_SGM DESC
                ) AS NR_ORDEM
            FROM {tabela('perfil_renda')} p
            WHERE p.CD_CLI = {int(consulta.cd_cli)}
              AND p.CD_CRIT_SGM_CLI = 2
              AND p.DT_ENQ_CLI_SGM > DATE('{DATA_CORTE_PERFIL_RENDA}')
              AND p.DT_ENQ_CLI_SGM <= DATE('{consulta.periodo_fim.isoformat()}')
        ) x
        WHERE NR_ORDEM = 1
    """.strip()


def montar_sql_perfil_financeiro(consulta: ConsultaPainel) -> str:
    return f"""
        SELECT CD_CLI, CD_MAC_PRFL_CLI, CD_MIC_PRFL_CLI, DT_REF_PERFIL_FINANCEIRO
        FROM (
            SELECT
                p.CD_CLI,
                p.CD_MAC_PRFL_CLI,
                p.CD_MIC_PRFL_CLI,
                p.DT_REF AS DT_REF_PERFIL_FINANCEIRO,
                ROW_NUMBER() OVER (
                    PARTITION BY p.CD_CLI
                    ORDER BY p.DT_REF DESC,
                             p.CD_MAC_PRFL_CLI DESC,
                             p.CD_MIC_PRFL_CLI DESC
                ) AS NR_ORDEM
            FROM {tabela('perfil_financeiro')} p
            WHERE p.CD_CLI = {int(consulta.cd_cli)}
              AND p.DT_REF <= DATE('{consulta.periodo_fim.isoformat()}')
        ) x
        WHERE NR_ORDEM = 1
    """.strip()


def _consultar_fonte(
    *,
    cliente_db2: Any,
    chave: str,
    sql: str,
    fetchsize: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    inicio = perf_counter()
    try:
        frame = executar_select(cliente_db2, sql, fetchsize)
        estado = "CARREGADA"
        erro = None
    except ErroDados as exc:
        if FONTES[chave].obrigatoria:
            raise
        frame = pd.DataFrame()
        estado = "INDISPONIVEL"
        erro = str(exc)
    tempo_ms = round((perf_counter() - inicio) * 1000, 2)
    return frame, {
        "tabela": FONTES[chave].nome_completo,
        "finalidade": FONTES[chave].finalidade,
        "obrigatoria": FONTES[chave].obrigatoria,
        "estado": estado,
        "linhas_retornadas": int(len(frame)),
        "tempo_ms": tempo_ms,
        "erro": erro,
    }


def _carregar_catalogos(cliente_db2: Any, fetchsize: int) -> tuple[dict[str, pd.DataFrame], dict[str, Any]]:
    cache_key = id(cliente_db2)
    if cache_key in _CACHE_CATALOGOS:
        frames = {chave: frame.copy() for chave, frame in _CACHE_CATALOGOS[cache_key].items()}
        meta = {
            chave: {
                "tabela": FONTES[chave].nome_completo,
                "finalidade": FONTES[chave].finalidade,
                "obrigatoria": True,
                "estado": "CACHE_SESSAO",
                "linhas_retornadas": int(len(frame)),
                "tempo_ms": 0.0,
                "erro": None,
            }
            for chave, frame in frames.items()
        }
        return frames, meta
    frames: dict[str, pd.DataFrame] = {}
    meta: dict[str, Any] = {}
    for chave, sql in (("categorias", montar_sql_categorias()), ("grupos", montar_sql_grupos())):
        frames[chave], meta[chave] = _consultar_fonte(
            cliente_db2=cliente_db2, chave=chave, sql=sql, fetchsize=fetchsize
        )
    _CACHE_CATALOGOS[cache_key] = {chave: frame.copy() for chave, frame in frames.items()}
    return frames, meta


def limpar_cache_catalogos() -> None:
    _CACHE_CATALOGOS.clear()


def carregar_dados(
    consulta: ConsultaPainel,
    config: Configuracao,
    *,
    cliente_db2: Any | None = None,
) -> dict[str, Any]:
    _validar_consulta(consulta)
    cliente = cliente_db2 or criar_cliente_db2(config)
    frames, metadados = _carregar_catalogos(cliente, config.fetchsize_db2)
    consultas = {
        "transacoes": montar_sql_transacoes(consulta),
        "contas": montar_sql_contas(consulta),
        "complementos_conta": montar_sql_complementos_conta(consulta),
        "perfil_renda": montar_sql_perfil_renda(consulta),
        "perfil_financeiro": montar_sql_perfil_financeiro(consulta),
    }
    for chave, sql in consultas.items():
        frames[chave], metadados[chave] = _consultar_fonte(
            cliente_db2=cliente,
            chave=chave,
            sql=sql,
            fetchsize=config.fetchsize_db2,
        )
    return {"frames": frames, "fontes": metadados}


__all__ = [
    "ErroDados", "criar_cliente_db2", "executar_select", "montar_sql_transacoes",
    "montar_sql_contas", "montar_sql_complementos_conta", "montar_sql_categorias",
    "montar_sql_grupos", "montar_sql_perfil_renda", "montar_sql_perfil_financeiro",
    "carregar_dados", "limpar_cache_catalogos",
]
