"""Validação completa e sanitizada do ambiente, fontes, pipeline e execução.

O identificador restrito do cliente é usado somente em memória para consultar o
Db2. Ele não pode aparecer em prints, DataFrames exibidos, arquivos exportados,
nomes de arquivo, mensagens públicas de erro ou metadados do relatório.
"""
from __future__ import annotations

import ast
from contextlib import redirect_stdout
from datetime import datetime
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import re
import sys
import time
from typing import Any, Iterable
from uuid import uuid4
import zipfile

import pandas as pd
from IPython.display import display

from .app import criar_consulta, executar_pipeline
from .config import carregar_configuracao
from .dados import (
    criar_cliente_db2, executar_select, montar_sql_complementos_conta,
    montar_sql_contas, montar_sql_perfil_financeiro, montar_sql_perfil_renda,
    montar_sql_transacoes,
)
from .fontes import COLUNAS_POR_FONTE, FONTES, TABELAS_SISTEMA, TIPOS_CRITICOS_POR_FONTE
from .regras import (
    BLOCOS, MAPA_CLASSIFICACAO, REGISTRO_REGRAS, REGISTRO_REGRAS_JORNADA,
    VERSAO_MACROCLASSIFICACAO, VERSAO_REGRAS_ANALISE, VERSAO_REGRAS_CIRCULACAO,
    VERSAO_REGRAS_JORNADA, VERSAO_REGRAS_QUALIDADE, VERSAO_REGRAS_RENDA,
)

COLUNAS_RESTRITAS = {
    "CD_CLI", "CD_CLI_TITR_CT", "CLIENTE", "CLIENTE_CODIGO", "CPF", "CNPJ",
    "CD_CPF_CNPJ_TITR", "NR_CPF_CNPJ_PGDR", "DOCUMENTO", "CONTRAPARTE_DOCUMENTO",
    "CONTA_NUMERO_NORMALIZADO", "CONTA_IDENTIFICADOR_EXTERNO", "PARTICAO",
    "NUMERO_TRANSACAO", "ID_EVENTO_FISICO",
}


def _id_execucao() -> str:
    return uuid4().hex[:12]


def _segredo(valor: Any) -> str:
    texto = str(valor).strip()
    if not texto or not texto.isdigit():
        raise ValueError("Identificador restrito inválido.")
    return texto


def _substituir_segredo(texto: str, segredo: str) -> str:
    if segredo:
        texto = texto.replace(segredo, "[IDENTIFICADOR_RESTRITO_REMOVIDO]")
    return texto


def _coluna_restrita(nome: Any) -> bool:
    valor = str(nome).upper()
    return valor in COLUNAS_RESTRITAS or any(x in valor for x in ("CPF", "CNPJ", "CD_CLI", "DOCUMENTO"))


def _sanitizar(objeto: Any, segredo: str) -> Any:
    if isinstance(objeto, pd.DataFrame):
        frame = objeto.copy()
        frame = frame.drop(columns=[c for c in frame.columns if _coluna_restrita(c)], errors="ignore")
        for coluna in frame.columns:
            if frame[coluna].dtype == object:
                frame[coluna] = frame[coluna].map(lambda x: _substituir_segredo(str(x), segredo) if x is not None else x)
        return frame
    if isinstance(objeto, dict):
        return {
            str(k): _sanitizar(v, segredo)
            for k, v in objeto.items()
            if not _coluna_restrita(k)
        }
    if isinstance(objeto, (list, tuple, set)):
        return [_sanitizar(v, segredo) for v in objeto]
    if isinstance(objeto, str):
        return _substituir_segredo(objeto, segredo)
    if isinstance(objeto, (pd.Timestamp, datetime)):
        return objeto.isoformat()
    if hasattr(objeto, "item"):
        try:
            return objeto.item()
        except Exception:
            pass
    return objeto


def _garantir_sem_segredo(objeto: Any, segredo: str) -> None:
    if not segredo:
        return
    if isinstance(objeto, pd.DataFrame):
        texto = objeto.to_csv(index=False)
    else:
        texto = json.dumps(_json_seguro(objeto), ensure_ascii=False, default=str)
    if segredo in texto:
        raise RuntimeError("A exportação foi bloqueada por conter identificador restrito.")


def _json_seguro(objeto: Any) -> Any:
    if isinstance(objeto, pd.DataFrame):
        return objeto.to_dict(orient="records")
    if isinstance(objeto, dict):
        return {str(k): _json_seguro(v) for k, v in objeto.items()}
    if isinstance(objeto, (list, tuple, set)):
        return [_json_seguro(v) for v in objeto]
    if isinstance(objeto, (pd.Timestamp, datetime)):
        return objeto.isoformat()
    if pd.isna(objeto) if not isinstance(objeto, (str, bytes, dict, list, tuple, set)) else False:
        return None
    if hasattr(objeto, "item"):
        try:
            return objeto.item()
        except Exception:
            pass
    return objeto


def _registro(status: str, codigo: str, validacao: str, esperado: Any, encontrado: Any, impacto: str, camada: str) -> dict[str, Any]:
    return {
        "status": status, "codigo": codigo, "camada": camada,
        "validacao": validacao, "esperado": esperado, "encontrado": encontrado,
        "impacto": impacto,
    }


def _estado(registros: Iterable[dict[str, Any]], prefixo: str) -> str:
    itens = list(registros)
    if any(x["status"] == "FAIL" for x in itens):
        return f"{prefixo}_REPROVADO"
    if any(x["status"] == "WARN" for x in itens):
        return f"{prefixo}_APROVADO_COM_RESSALVAS"
    return f"{prefixo}_APROVADO"


def _versao(nome: str) -> str | None:
    try:
        return importlib.metadata.version(nome)
    except importlib.metadata.PackageNotFoundError:
        return None


def _validar_ambiente(raiz: Path, cliente_db2: Any | None, config: Any) -> tuple[dict[str, pd.DataFrame], list[dict[str, Any]]]:
    registros: list[dict[str, Any]] = []
    pacotes = []
    requeridos = ["pandas", "plotly", "python-dotenv", "ipython", "nbformat", "pytest"]
    for pacote in requeridos:
        versao = _versao(pacote)
        status = "PASS" if versao else "FAIL"
        pacotes.append({"pacote": pacote, "versao": versao, "estado": status})
        registros.append(_registro(status, f"ENV_PKG_{pacote}", f"Pacote {pacote} disponível", "instalado", versao or "ausente", "Execução do projeto", "AMBIENTE"))
    estrutura = []
    obrigatorios = [
        "src/app.py", "src/analise.py", "src/qualidade.py", "src/circulacao.py",
        "src/renda.py", "src/jornada.py", "src/visual.py", "src/validacoes.py",
        "src/fontes.py", "src/regras.py", "rotina-principal.ipynb", "todas_validacoes.ipynb",
        "requirements.txt", "desenv.env",
    ]
    for rel in obrigatorios:
        existe = (raiz / rel).exists()
        estrutura.append({"arquivo": rel, "existe": existe})
        registros.append(_registro("PASS" if existe else "FAIL", "ENV_FILE", f"Arquivo {rel}", True, existe, "Estrutura executável", "AMBIENTE"))
    sintaxe = []
    for arquivo in sorted((raiz / "src").glob("*.py")):
        try:
            ast.parse(arquivo.read_text(encoding="utf-8"))
            estado = "PASS"; detalhe = "sintaxe válida"
        except SyntaxError as exc:
            estado = "FAIL"; detalhe = f"linha {exc.lineno}"
        sintaxe.append({"arquivo": arquivo.name, "estado": estado, "detalhe": detalhe})
        registros.append(_registro(estado, "ENV_AST", f"Sintaxe {arquivo.name}", "válida", detalhe, "Importação do módulo", "AMBIENTE"))
    credenciais = bool(config.db2_user and config.db2_pass) or cliente_db2 is not None
    registros.append(_registro("PASS" if credenciais else "FAIL", "ENV_DB2_CRED", "Credenciais ou cliente Db2 disponível", True, credenciais, "Conectividade", "AMBIENTE"))
    ambiente = pd.DataFrame([{
        "python": platform.python_version(), "plataforma": platform.platform(),
        "raiz": str(raiz), "credenciais_configuradas": bool(config.db2_user and config.db2_pass),
        "cliente_db2_fornecido": cliente_db2 is not None,
    }])
    return {
        "ambiente": ambiente,
        "pacotes": pd.DataFrame(pacotes),
        "estrutura": pd.DataFrame(estrutura),
        "sintaxe": pd.DataFrame(sintaxe),
    }, registros


def _sql_metadados() -> str:
    pares = ", ".join(f"('{f.schema}', '{f.tabela}')" for f in FONTES.values())
    return f"""
        SELECT TABSCHEMA, TABNAME, COLNAME, TYPENAME, LENGTH, SCALE, NULLS, COLNO
        FROM {TABELAS_SISTEMA['catalogo_colunas']}
        WHERE (TABSCHEMA, TABNAME) IN ({pares})
        ORDER BY TABSCHEMA, TABNAME, COLNO
    """.strip()


def _familia_tipo(tipo: Any) -> str:
    t = str(tipo or "").upper()
    if any(x in t for x in ("CHAR", "CLOB", "GRAPHIC")): return "CHARACTER"
    if any(x in t for x in ("DECIMAL", "INTEGER", "BIGINT", "SMALLINT", "DOUBLE", "REAL", "NUMERIC")): return "NUMERIC"
    if "TIMESTAMP" in t: return "TIMESTAMP"
    if t == "DATE": return "DATE"
    return t or "DESCONHECIDO"


def _validar_banco(cliente: Any, fetchsize: int) -> tuple[dict[str, pd.DataFrame], list[dict[str, Any]]]:
    registros: list[dict[str, Any]] = []
    inicio = time.perf_counter()
    try:
        teste = executar_select(cliente, f"SELECT 1 AS OK FROM {TABELAS_SISTEMA['dummy']}", fetchsize)
        conexao_ok = not teste.empty
        erro = None
    except Exception as exc:
        conexao_ok = False; erro = type(exc).__name__
    tempo = round((time.perf_counter() - inicio) * 1000, 2)
    registros.append(_registro("PASS" if conexao_ok else "FAIL", "DB2_CONN", "Conectividade Db2", True, conexao_ok, erro or "Acesso às fontes", "FONTES"))
    conexao = pd.DataFrame([{"conectado": conexao_ok, "tempo_ms": tempo, "erro_tipo": erro}])
    if not conexao_ok:
        return {"conexao": conexao, "fontes_ambiente": pd.DataFrame(), "contrato_colunas": pd.DataFrame()}, registros
    try:
        meta = executar_select(cliente, _sql_metadados(), fetchsize)
    except Exception as exc:
        registros.append(_registro("WARN", "DB2_META", "Catálogo de colunas acessível", True, False, type(exc).__name__, "FONTES"))
        return {"conexao": conexao, "fontes_ambiente": pd.DataFrame(), "contrato_colunas": pd.DataFrame()}, registros
    meta.columns = [str(c).upper() for c in meta.columns]
    fontes_rows=[]; contrato=[]
    for chave, fonte in FONTES.items():
        recorte = meta[(meta["TABSCHEMA"].astype(str).str.upper()==fonte.schema.upper()) & (meta["TABNAME"].astype(str).str.upper()==fonte.tabela.upper())]
        existe = not recorte.empty
        fontes_rows.append({"fonte": chave, "tabela": fonte.nome_completo, "existe_no_catalogo": existe, "colunas_encontradas": int(len(recorte)), "obrigatoria": fonte.obrigatoria})
        status = "PASS" if existe else ("FAIL" if fonte.obrigatoria else "WARN")
        registros.append(_registro(status, "DB2_TABLE", f"Fonte {chave} existe", True, existe, fonte.finalidade, "FONTES"))
        encontradas = {str(x).upper(): row for x, row in zip(recorte.get("COLNAME", []), recorte.to_dict("records"))}
        for coluna in COLUNAS_POR_FONTE[chave]:
            row = encontradas.get(coluna.upper())
            presente = row is not None
            esperado_tipo = TIPOS_CRITICOS_POR_FONTE.get(chave, {}).get(coluna)
            encontrado_tipo = _familia_tipo(row.get("TYPENAME")) if row else None
            tipo_ok = presente and (esperado_tipo is None or encontrado_tipo in {esperado_tipo, "TIMESTAMP" if esperado_tipo=="DATE" else esperado_tipo})
            contrato.append({
                "fonte": chave, "coluna": coluna, "presente": presente,
                "tipo_esperado": esperado_tipo, "tipo_encontrado": encontrado_tipo,
                "tipo_compativel": tipo_ok if esperado_tipo else None,
            })
            if not presente:
                registros.append(_registro("FAIL" if fonte.obrigatoria else "WARN", "DB2_COLUMN", f"{chave}.{coluna}", True, False, "Contrato da fonte", "FONTES"))
            elif esperado_tipo and not tipo_ok:
                registros.append(_registro("FAIL", "DB2_TYPE", f"Tipo {chave}.{coluna}", esperado_tipo, encontrado_tipo, "Conversão e cálculo", "FONTES"))
    return {"conexao": conexao, "fontes_ambiente": pd.DataFrame(fontes_rows), "contrato_colunas": pd.DataFrame(contrato)}, registros


def _validar_sql(consulta: Any) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    sqls = {
        "transacoes": montar_sql_transacoes(consulta),
        "contas": montar_sql_contas(consulta),
        "complementos": montar_sql_complementos_conta(consulta),
        "perfil_renda": montar_sql_perfil_renda(consulta),
        "perfil_financeiro": montar_sql_perfil_financeiro(consulta),
    }
    rows=[]; registros=[]
    for nome, sql in sqls.items():
        upper=sql.upper()
        checks={
            "sem_select_star": "SELECT *" not in upper,
            "sem_particao_fixa": "NR_PTC BETWEEN" not in upper,
            "cliente_restrito": ("CD_CLI =" in upper or "CD_CLI_TITR_CT =" in upper),
        }
        if nome in {"transacoes","complementos"}:
            checks["periodo_inicio"]="DT_TRAN >=" in upper
            checks["periodo_fim_exclusivo"]="DT_TRAN <" in upper
            checks["moeda"]="CD_TIP_MOE_CRR" in upper
        for check, ok in checks.items():
            rows.append({"consulta":nome,"validacao":check,"aprovada":ok})
            registros.append(_registro("PASS" if ok else "FAIL", "SQL_SAFE", f"{nome}: {check}", True, ok, "Segurança e desempenho", "PIPELINE"))
    return pd.DataFrame(rows), registros


def _perfil_frames(frames: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame]:
    resumo=[]; colunas=[]
    for nome, frame in frames.items():
        df=frame if isinstance(frame,pd.DataFrame) else pd.DataFrame()
        resumo.append({"fonte":nome,"linhas":len(df),"colunas":len(df.columns),"duplicadas_exatas":int(df.duplicated().sum()) if not df.empty else 0})
        for col in df.columns:
            serie=df[col]
            colunas.append({"fonte":nome,"coluna":str(col),"tipo":str(serie.dtype),"nulos":int(serie.isna().sum()),"percentual_nulos":round(float(serie.isna().mean()*100),2),"distintos":int(serie.nunique(dropna=True))})
    return pd.DataFrame(resumo), pd.DataFrame(colunas)


def _tabelas_execucao(pipeline: dict[str, Any], segredo: str, limite: int) -> dict[str, pd.DataFrame]:
    payload=_sanitizar(pipeline["payload"],segredo)
    frames=_sanitizar(pipeline["frames"],segredo)
    resumo_frames, qualidade_colunas=_perfil_frames(frames)
    qualidade=payload["evidencias_qualidade"]["qualidade"]
    fontes=pd.DataFrame([{"fonte":k,**v} for k,v in payload.get("fontes",{}).items()])
    dup=pd.DataFrame(qualidade.get("grupos",[]))
    pares=pd.DataFrame(payload["circulacao_bancos"].get("pares",[]))
    rotas=pd.DataFrame(payload["circulacao_bancos"].get("rotas",[]))
    bancos=pd.DataFrame(payload["circulacao_bancos"].get("instituicoes",[]))
    fontes_renda=pd.DataFrame(payload["origem_renda"].get("fontes",[]))
    entradas=pd.DataFrame(payload["origem_renda"].get("entradas",[]))
    janelas=pd.DataFrame(payload["uso_dinheiro"].get("ciclos",{}).get("resumo_janelas",[]))
    movimentos=pd.DataFrame(payload.get("movimentacoes",[])).head(limite)
    resumo_exec=pd.DataFrame(payload["jornada_dinheiro"].get("resumo_executivo",[]))
    regras=pd.DataFrame([
        {"regra":k,**v} for k,v in {**REGISTRO_REGRAS,**REGISTRO_REGRAS_JORNADA}.items()
    ])
    return {
        "carga_fontes":fontes,"frames":resumo_frames,"qualidade_colunas":qualidade_colunas,
        "duplicidades":dup,"pares_circulacao":pares,"rotas":rotas,"papeis_bancarios":bancos,
        "fontes_renda":fontes_renda,"entradas":entradas,"janelas_pos_recebimento":janelas,
        "movimentacoes_amostra":movimentos,"resumo_executivo":resumo_exec,"regras":regras,
    }


def _validar_execucao(pipeline: dict[str, Any]) -> list[dict[str, Any]]:
    p=pipeline["payload"]; regs=[]
    meta=p["meta"]
    regs.append(_registro("PASS" if meta["periodo"]["inicio"] and meta["periodo"]["fim"] else "FAIL","RUN_PERIOD","Período global presente",True,meta["periodo"],"Todas as análises","EXECUCAO"))
    regs.append(_registro("PASS" if p["evidencias_qualidade"]["qualidade"]["resumo"]["movimentacoes_observadas"]==p["cobertura"]["movimentacoes"] else "FAIL","RUN_GRAIN","Movimentações reconciliam com cobertura",p["cobertura"]["movimentacoes"],p["evidencias_qualidade"]["qualidade"]["resumo"]["movimentacoes_observadas"],"Integridade","EXECUCAO"))
    q=p["evidencias_qualidade"]["qualidade"]["resumo"]
    regs.append(_registro("WARN" if q["duplicidades_provaveis"] else "PASS","RUN_DUP","Duplicidades prováveis",0,q["duplicidades_provaveis"],"Revisão da base estimada","EXECUCAO"))
    c=p["circulacao_bancos"]["resumo"]
    regs.append(_registro("WARN" if c["quantidade_pares_ambiguos"] else "PASS","RUN_CIRC_AMB","Pares ambíguos",0,c["quantidade_pares_ambiguos"],"Circulação inconclusiva","EXECUCAO"))
    r=p["origem_renda"]["resumo"]
    total_componentes=(r["entradas_externas_estimadas"]+r["circulacao_interna_provavel"]+r["duplicidades_neutralizadas"]+r["entradas_inconclusivas"]+r["outras_entradas_especificas"])
    tolerancia=0.02
    regs.append(_registro("PASS" if abs(total_componentes-r["entradas_observadas"])<=tolerancia else "FAIL","RUN_INCOME_REC","Componentes das entradas reconciliam",r["entradas_observadas"],round(total_componentes,2),"Origem e renda","EXECUCAO"))
    principal=p["origem_renda"].get("fonte_principal")
    regs.append(_registro("INFO" if principal else "WARN","RUN_INCOME_SOURCE","Fonte recorrente principal", "quando houver evidência", principal.get("classificacao") if principal else "não identificada","Leitura de renda","EXECUCAO"))
    regs.append(_registro("PASS" if "cliente_codigo" not in json.dumps(_json_seguro(p),ensure_ascii=False).lower() else "FAIL","RUN_PRIVACY","Payload sem identificador do cliente",True,"verificado","Segurança","EXECUCAO"))
    return regs


def _resumo_texto(relatorio: dict[str, Any]) -> str:
    validacoes=relatorio["tabelas"]["validacoes"]
    contagem=validacoes["status"].value_counts().to_dict() if not validacoes.empty else {}
    linhas=["VALIDAÇÃO DA JORNADA FINANCEIRA",f"Execução: {relatorio['id_execucao']}",f"Período: {relatorio['contexto']['periodo_inicio']} a {relatorio['contexto']['periodo_fim']}",f"Moeda: {relatorio['contexto']['moeda']}",""]
    for chave in ("estado_ambiente","estado_fontes","estado_pipeline","estado_execucao"):
        linhas.append(f"{chave}: {relatorio[chave]}")
    linhas.extend(["",f"PASS: {contagem.get('PASS',0)}",f"WARN: {contagem.get('WARN',0)}",f"FAIL: {contagem.get('FAIL',0)}",f"INFO: {contagem.get('INFO',0)}"])
    return "\n".join(linhas)


def exibir_relatorio_validacao(relatorio: dict[str, Any], *, limite_linhas: int=100) -> None:
    print("="*72)
    print("VALIDAÇÃO DA JORNADA FINANCEIRA DO CLIENTE")
    print("="*72)
    print(f"Execução: {relatorio['id_execucao']}")
    print(f"Período: {relatorio['contexto']['periodo_inicio']} a {relatorio['contexto']['periodo_fim']}")
    print(f"Moeda: {relatorio['contexto']['moeda']}")
    print(f"Ambiente: {relatorio['estado_ambiente']}")
    print(f"Fontes: {relatorio['estado_fontes']}")
    print(f"Pipeline: {relatorio['estado_pipeline']}")
    print(f"Execução: {relatorio['estado_execucao']}")
    for nome, frame in relatorio["tabelas"].items():
        if not isinstance(frame,pd.DataFrame) or frame.empty: continue
        print("\n"+"-"*72); print(nome.replace("_"," ").upper()); print("-"*72)
        display(frame.head(limite_linhas))
    if relatorio.get("pacote_exportado"):
        print(f"\nPacote sanitizado: {relatorio['pacote_exportado']}")


def exportar_diagnostico(relatorio: dict[str, Any], *, pasta_saida: str|Path="saida_validacoes", segredo: str="") -> Path:
    destino=Path(pasta_saida); destino.mkdir(parents=True,exist_ok=True)
    id_exec=relatorio["id_execucao"]
    pasta=destino/f"validacao_{id_exec}"
    if pasta.exists():
        for p in pasta.iterdir(): p.unlink()
    else: pasta.mkdir()
    for nome, frame in relatorio["tabelas"].items():
        if isinstance(frame,pd.DataFrame):
            seguro=_sanitizar(frame,segredo); _garantir_sem_segredo(seguro,segredo)
            seguro.to_csv(pasta/f"{nome}.csv",index=False,encoding="utf-8")
    resumo=_resumo_texto(relatorio); _garantir_sem_segredo(resumo,segredo)
    (pasta/"resumo.txt").write_text(resumo,encoding="utf-8")
    diagnostico={
        "id_execucao":id_exec,"contexto":relatorio["contexto"],
        "estados":{k:relatorio[k] for k in ("estado_ambiente","estado_fontes","estado_pipeline","estado_execucao")},
    }
    diagnostico=_sanitizar(diagnostico,segredo); _garantir_sem_segredo(diagnostico,segredo)
    (pasta/"diagnostico.json").write_text(json.dumps(diagnostico,ensure_ascii=False,indent=2),encoding="utf-8")
    zip_path=destino/f"validacao_{id_exec}.zip"
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as zf:
        for arquivo in sorted(pasta.iterdir()): zf.write(arquivo,arquivo.name)
    dados=zip_path.read_bytes()
    if segredo.encode() in dados:
        zip_path.unlink(missing_ok=True)
        raise RuntimeError("Pacote bloqueado por conter identificador restrito.")
    return zip_path


def executar_todas_validacoes(
    cd_cli: int|str,
    periodo_inicio: str,
    periodo_fim: str,
    *, moeda: str|None=None,
    instituicoes: Iterable[int]|None=None,
    env_path: str|Path="desenv.env",
    cliente_db2: Any|None=None,
    verificar_banco: bool=True,
    exibir: bool=True,
    exportar: bool=True,
    pasta_saida: str|Path="saida_validacoes",
    limite_amostra: int=100,
) -> dict[str, Any]:
    segredo=_segredo(cd_cli)
    raiz=Path(__file__).resolve().parents[1]
    config=carregar_configuracao(env_path)
    consulta=criar_consulta(
        cd_cli=int(segredo),periodo_inicio=periodo_inicio,periodo_fim=periodo_fim,
        moeda=moeda or config.moeda_padrao,instituicoes=instituicoes,tela_inicial="jornada_dinheiro",
    )
    tabelas, registros=_validar_ambiente(raiz,cliente_db2,config)
    estado_ambiente=_estado([x for x in registros if x["camada"]=="AMBIENTE"],"AMBIENTE")
    cliente=cliente_db2
    if verificar_banco:
        try:
            cliente=cliente or criar_cliente_db2(config)
            tab_banco,reg_banco=_validar_banco(cliente,config.fetchsize_db2)
        except Exception as exc:
            tab_banco={"conexao":pd.DataFrame([{"conectado":False,"erro_tipo":type(exc).__name__}]),"fontes_ambiente":pd.DataFrame(),"contrato_colunas":pd.DataFrame()}
            reg_banco=[_registro("FAIL","DB2_CONN","Conectividade Db2",True,False,type(exc).__name__,"FONTES")]
        tabelas.update(tab_banco); registros.extend(reg_banco)
    estado_fontes=_estado([x for x in registros if x["camada"]=="FONTES"],"FONTES")
    sql_tab,sql_regs=_validar_sql(consulta); tabelas["seguranca_sql"]=sql_tab; registros.extend(sql_regs)
    # O pipeline é executado com stdout capturado, impedindo vazamentos por prints acidentais.
    buffer=io.StringIO()
    try:
        with redirect_stdout(buffer):
            pipeline=executar_pipeline(
                cd_cli=int(segredo),periodo_inicio=periodo_inicio,periodo_fim=periodo_fim,
                moeda=moeda,instituicoes=instituicoes,tela_inicial="jornada_dinheiro",
                env_path=env_path,cliente_db2=cliente,
            )
        capturado=_substituir_segredo(buffer.getvalue(),segredo)
        if capturado.strip():
            registros.append(_registro("WARN","PIPE_STDOUT","Pipeline sem prints", "silêncio", "saída capturada e suprimida", "Privacidade", "PIPELINE"))
        tabelas.update(_tabelas_execucao(pipeline,segredo,limite_amostra))
        exec_regs=_validar_execucao(pipeline); registros.extend(exec_regs)
    except Exception as exc:
        pipeline=None
        registros.append(_registro("FAIL","PIPE_RUN","Execução do pipeline",True,False,type(exc).__name__,"Pipeline analítico","PIPELINE"))
    estado_pipeline=_estado([x for x in registros if x["camada"]=="PIPELINE"],"PIPELINE")
    estado_execucao=_estado([x for x in registros if x["camada"]=="EXECUCAO"],"EXECUCAO")
    tabelas["validacoes"]=pd.DataFrame(_sanitizar(registros,segredo))
    relatorio={
        "id_execucao":_id_execucao(),
        "contexto":{"periodo_inicio":periodo_inicio,"periodo_fim":periodo_fim,"moeda":consulta.moeda,"instituicoes":list(consulta.instituicoes)},
        "estado_ambiente":estado_ambiente,"estado_fontes":estado_fontes,
        "estado_pipeline":estado_pipeline,"estado_execucao":estado_execucao,
        "tabelas":_sanitizar(tabelas,segredo),"pacote_exportado":None,
    }
    _garantir_sem_segredo(relatorio,segredo)
    if exportar:
        caminho=exportar_diagnostico(relatorio,pasta_saida=pasta_saida,segredo=segredo)
        relatorio["pacote_exportado"]=str(caminho)
    if exibir:
        exibir_relatorio_validacao(relatorio,limite_linhas=limite_amostra)
    # Não devolve consulta ou frames internos com o identificador restrito.
    segredo=""
    return relatorio


__all__=["executar_todas_validacoes","exibir_relatorio_validacao","exportar_diagnostico"]
