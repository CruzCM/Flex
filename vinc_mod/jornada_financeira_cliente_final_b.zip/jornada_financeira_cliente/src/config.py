"""Configuração técnica da integração com o Db2 via bbmagic."""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

from dotenv import load_dotenv


MODOS_CREDENCIAL_VALIDOS = {"auto", "cofre", "env"}


@dataclass(frozen=True)
class Configuracao:
    db2_user: str | None
    db2_pass: str | None
    db2_credential_mode: str
    db2_host: str
    db2_port: int
    db2_database: str
    db2_trust_env: bool
    db2_pconnect: bool
    moeda_padrao: str
    incluir_plotly_offline: bool
    chunksize_db2: int

    @property
    def fetchsize_db2(self) -> int:
        """Compatibilidade temporária com versões anteriores do projeto."""
        return self.chunksize_db2


def _bool_env(nome: str, padrao: bool) -> bool:
    valor = os.getenv(nome)
    if valor is None:
        return padrao
    return valor.strip().lower() in {"1", "true", "sim", "s", "yes", "y"}


def _inteiro_positivo(nome: str, padrao: str) -> int:
    try:
        valor = int(os.getenv(nome, padrao))
    except ValueError as exc:
        raise ValueError(f"{nome} deve ser um número inteiro.") from exc
    if valor <= 0:
        raise ValueError(f"{nome} deve ser maior que zero.")
    return valor


def carregar_configuracao(env_path: str | Path = "desenv.env") -> Configuracao:
    load_dotenv(Path(env_path), override=False)

    moeda = os.getenv("DASHBOARD_MOEDA_PADRAO", "BRL").strip().upper()
    if len(moeda) != 3 or not moeda.isalpha():
        raise ValueError("DASHBOARD_MOEDA_PADRAO deve conter três letras.")

    modo = os.getenv("DB2_CREDENTIAL_MODE", "auto").strip().lower()
    if modo not in MODOS_CREDENCIAL_VALIDOS:
        opcoes = ", ".join(sorted(MODOS_CREDENCIAL_VALIDOS))
        raise ValueError(f"DB2_CREDENTIAL_MODE deve ser um de: {opcoes}.")

    # DB2_FETCHSIZE é aceito somente para compatibilidade com o ZIP anterior.
    chunksize_texto = os.getenv("DB2_CHUNKSIZE") or os.getenv("DB2_FETCHSIZE") or "10000"
    try:
        chunksize = int(chunksize_texto)
    except ValueError as exc:
        raise ValueError("DB2_CHUNKSIZE deve ser um número inteiro.") from exc
    if chunksize <= 0:
        raise ValueError("DB2_CHUNKSIZE deve ser maior que zero.")

    return Configuracao(
        db2_user=(os.getenv("DB2_USER") or "").strip() or None,
        db2_pass=os.getenv("DB2_PASS") or None,
        db2_credential_mode=modo,
        db2_host=os.getenv("DB2_HOST", "gwdb2.bb.com.br").strip(),
        db2_port=_inteiro_positivo("DB2_PORT", "50100"),
        db2_database=os.getenv("DB2_DATABASE", "BDB2P04").strip(),
        db2_trust_env=_bool_env("DB2_TRUST_ENV", True),
        db2_pconnect=_bool_env("DB2_PCONNECT", True),
        moeda_padrao=moeda,
        incluir_plotly_offline=_bool_env("DASHBOARD_PLOTLY_OFFLINE", True),
        chunksize_db2=chunksize,
    )


__all__ = ["Configuracao", "MODOS_CREDENCIAL_VALIDOS", "carregar_configuracao"]
