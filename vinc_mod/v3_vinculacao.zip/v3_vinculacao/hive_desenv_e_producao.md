================================================================================

TABELA: hive_t2i.CTL_OPRL_RCM

================================================================================

nr_idfr_proj                                       bigint

nr_idfr_rcm                                        bigint

nr_vrs_vldd_rcm                                    smallint

cd_est_rcm                                         smallint

cd_est_vrs_rcm                                     smallint

in_reg_atu                                         string

in_exea_pnd                                        string

ts_inc_reg                                         timestamp

nm_rcm_pdro                                        string

tx_dcr_rcm                                         string

nr_idfr_avs_seld                                   bigint

nr_idfr_pbco                                       bigint

nr_idfr_sgt                                        bigint

tx_tit_pdro_avs                                    string

tx_stit_pdro_avs                                   string

tx_acmt_pdro_avs                                   string

tx_prpt_prm_hdr_api                                string

nm_db_ogm                                          string

nm_tab_ogm                                         string

cd_tip_ecp_ogm                                     smallint

cd_fma_ref_ogm                                     string

ts_fim_reg                                         timestamp

nm_col_ecp_ogm                                     string

ts_ult_dt_obsd_ogm                                 timestamp

ts_ult_dt_prcd_ogm                                 timestamp

qt_dado_ogm                                        bigint
 
================================================================================

TABELA: sbx_t2i2016.CTL_OPRL_RCM

================================================================================

NR_IDFR_PROJ                                       bigint

NR_IDFR_RCM                                        bigint

NR_VRS_VLDD_RCM                                    smallint

CD_EST_RCM                                         smallint

CD_EST_VRS_RCM                                     smallint

IN_REG_ATU                                         string

IN_EXEA_PND                                        string

TS_INC_REG                                         timestamp

NM_RCM_PDRO                                        string

TX_DCR_RCM                                         string

NR_IDFR_AVS_SELD                                   bigint

NR_IDFR_PBCO                                       bigint

NR_IDFR_SGT                                        bigint

TX_TIT_PDRO_AVS                                    string

TX_STIT_PDRO_AVS                                   string

TX_ACMT_PDRO_AVS                                   string

TX_PRPT_PRM_HDR_API                                string

NM_DB_OGM                                          string

NM_TAB_OGM                                         string

CD_TIP_ECP_OGM                                     smallint

CD_FMA_REF_OGM                                     string

TS_FIM_REG                                         timestamp

NM_COL_ECP_OGM                                     string

TS_ULT_DT_OBSD_OGM                                 timestamp

TS_ULT_DT_PRCD_OGM                                 timestamp

QT_DADO_OGM                                        bigint
 


========================================================================================================================

AMBIENTE: hive_t2i

========================================================================================================================
 
------------------------------------------------------------------------------------------------------------------------

TABELA: hive_t2i.CTL_OPRL_RCM

------------------------------------------------------------------------------------------------------------------------

root

|-- nr_idfr_proj: long (nullable = true)

|-- nr_idfr_rcm: long (nullable = true)

|-- nr_vrs_vldd_rcm: short (nullable = true)

|-- cd_est_rcm: short (nullable = true)

|-- cd_est_vrs_rcm: short (nullable = true)

|-- in_reg_atu: string (nullable = true)

|-- in_exea_pnd: string (nullable = true)

|-- ts_inc_reg: timestamp (nullable = true)

|-- nm_rcm_pdro: string (nullable = true)

|-- tx_dcr_rcm: string (nullable = true)

|-- nr_idfr_avs_seld: long (nullable = true)

|-- nr_idfr_pbco: long (nullable = true)

|-- nr_idfr_sgt: long (nullable = true)

|-- tx_tit_pdro_avs: string (nullable = true)

|-- tx_stit_pdro_avs: string (nullable = true)

|-- tx_acmt_pdro_avs: string (nullable = true)

|-- tx_prpt_prm_hdr_api: string (nullable = true)

|-- nm_db_ogm: string (nullable = true)

|-- nm_tab_ogm: string (nullable = true)

|-- cd_tip_ecp_ogm: short (nullable = true)

|-- cd_fma_ref_ogm: string (nullable = true)

|-- ts_fim_reg: timestamp (nullable = true)

|-- nm_col_ecp_ogm: string (nullable = true)

|-- ts_ult_dt_obsd_ogm: timestamp (nullable = true)

|-- ts_ult_dt_prcd_ogm: timestamp (nullable = true)

|-- qt_dado_ogm: long (nullable = true)
 
 
------------------------------------------------------------------------------------------------------------------------

TABELA: hive_t2i.RCM_FNC_CLI

------------------------------------------------------------------------------------------------------------------------

root

|-- cd_idfr_avs: string (nullable = true)

|-- cd_cli: integer (nullable = true)

|-- dt_avs_fnc_cli: date (nullable = true)

|-- nr_idfr_proj: long (nullable = true)

|-- nr_idfr_rcm: long (nullable = true)

|-- nr_vrs_vldd_rcm: short (nullable = true)

|-- nr_idfr_avs_seld: long (nullable = true)

|-- nr_idfr_pbco: long (nullable = true)

|-- nr_idfr_sgt: long (nullable = true)

|-- cd_est_vrs_rcm: short (nullable = true)

|-- tx_tit_pdro_avs: string (nullable = true)

|-- tx_stit_pdro_avs: string (nullable = true)

|-- tx_acmt_pdro_avs: string (nullable = true)

|-- tx_prm_hdr_api_avs: string (nullable = true)

|-- pc_nvl_cnfa_avs: decimal(4,2) (nullable = true)

|-- nm_db_ogm: string (nullable = true)

|-- nm_tab_ogm: string (nullable = true)

|-- cd_tip_ecp_ogm: short (nullable = true)

|-- cd_fma_ref_ogm: string (nullable = true)

|-- nm_col_ecp_ogm: string (nullable = true)

|-- ts_ult_dt_prcd_ogm: timestamp (nullable = true)

|-- qt_dado_ogm: long (nullable = true)
 
 
------------------------------------------------------------------------------------------------------------------------

TABELA: hive_t2i.RCM_FNC_CLI_EVTL

------------------------------------------------------------------------------------------------------------------------

root

|-- cd_idfr_avs: string (nullable = true)

|-- cd_cli: integer (nullable = true)

|-- dt_avs_fnc_cli: date (nullable = true)

|-- nr_idfr_proj: long (nullable = true)

|-- nr_idfr_rcm: long (nullable = true)

|-- nr_vrs_vldd_rcm: short (nullable = true)

|-- nr_idfr_avs_seld: long (nullable = true)

|-- nr_idfr_pbco: long (nullable = true)

|-- nr_idfr_sgt: long (nullable = true)

|-- cd_est_vrs_rcm: short (nullable = true)

|-- tx_tit_pdro_avs: string (nullable = true)

|-- tx_stit_pdro_avs: string (nullable = true)

|-- tx_acmt_pdro_avs: string (nullable = true)

|-- tx_prm_hdr_api_avs: string (nullable = true)

|-- pc_nvl_cnfa_avs: decimal(4,2) (nullable = true)

|-- nm_db_ogm: string (nullable = true)

|-- nm_tab_ogm: string (nullable = true)

|-- cd_tip_ecp_ogm: short (nullable = true)

|-- cd_fma_ref_ogm: string (nullable = true)

|-- nm_col_ecp_ogm: string (nullable = true)

|-- ts_ult_dt_prcd_ogm: timestamp (nullable = true)

|-- qt_dado_ogm: long (nullable = true)
 
 
------------------------------------------------------------------------------------------------------------------------

TABELA: hive_t2i.ANDO_RCM_FNC_CLI

------------------------------------------------------------------------------------------------------------------------

root

|-- cd_idfr_avs: string (nullable = true)

|-- da_cd_cli: string (nullable = true)

|-- dt_avs_fnc_cli: date (nullable = true)

|-- nr_idfr_proj: long (nullable = true)

|-- nr_idfr_rcm: long (nullable = true)

|-- nr_vrs_vldd_rcm: short (nullable = true)

|-- nr_idfr_avs_seld: long (nullable = true)

|-- nr_idfr_pbco: long (nullable = true)

|-- nr_idfr_sgt: long (nullable = true)

|-- cd_est_vrs_rcm: short (nullable = true)

|-- tx_tit_pdro_avs: string (nullable = true)

|-- tx_stit_pdro_avs: string (nullable = true)

|-- tx_acmt_pdro_avs: string (nullable = true)

|-- tx_prm_hdr_api_avs: string (nullable = true)

|-- pc_nvl_cnfa_avs: decimal(4,2) (nullable = true)

|-- nm_db_ogm: string (nullable = true)

|-- nm_tab_ogm: string (nullable = true)

|-- cd_tip_ecp_ogm: short (nullable = true)

|-- cd_fma_ref_ogm: string (nullable = true)

|-- nm_col_ecp_ogm: string (nullable = true)

|-- ts_ult_dt_prcd_ogm: timestamp (nullable = true)

|-- qt_dado_ogm: long (nullable = true)
 
 
------------------------------------------------------------------------------------------------------------------------

TABELA: hive_t2i.ANDO_RCM_FNC_CLI_EVTL

------------------------------------------------------------------------------------------------------------------------

root

|-- cd_idfr_avs: string (nullable = true)

|-- da_cd_cli: string (nullable = true)

|-- dt_avs_fnc_cli: date (nullable = true)

|-- nr_idfr_proj: long (nullable = true)

|-- nr_idfr_rcm: long (nullable = true)

|-- nr_vrs_vldd_rcm: short (nullable = true)

|-- nr_idfr_avs_seld: long (nullable = true)

|-- nr_idfr_pbco: long (nullable = true)

|-- nr_idfr_sgt: long (nullable = true)

|-- cd_est_vrs_rcm: short (nullable = true)

|-- tx_tit_pdro_avs: string (nullable = true)

|-- tx_stit_pdro_avs: string (nullable = true)

|-- tx_acmt_pdro_avs: string (nullable = true)

|-- tx_prm_hdr_api_avs: string (nullable = true)

|-- pc_nvl_cnfa_avs: decimal(4,2) (nullable = true)

|-- nm_db_ogm: string (nullable = true)

|-- nm_tab_ogm: string (nullable = true)

|-- cd_tip_ecp_ogm: short (nullable = true)

|-- cd_fma_ref_ogm: string (nullable = true)

|-- nm_col_ecp_ogm: string (nullable = true)

|-- ts_ult_dt_prcd_ogm: timestamp (nullable = true)

|-- qt_dado_ogm: long (nullable = true)
 
 
========================================================================================================================

AMBIENTE: sbx_t2i2016

========================================================================================================================
 
------------------------------------------------------------------------------------------------------------------------

TABELA: sbx_t2i2016.CTL_OPRL_RCM

------------------------------------------------------------------------------------------------------------------------

root

|-- NR_IDFR_PROJ: long (nullable = true)

|-- NR_IDFR_RCM: long (nullable = true)

|-- NR_VRS_VLDD_RCM: short (nullable = true)

|-- CD_EST_RCM: short (nullable = true)

|-- CD_EST_VRS_RCM: short (nullable = true)

|-- IN_REG_ATU: string (nullable = true)

|-- IN_EXEA_PND: string (nullable = true)

|-- TS_INC_REG: timestamp (nullable = true)

|-- NM_RCM_PDRO: string (nullable = true)

|-- TX_DCR_RCM: string (nullable = true)

|-- NR_IDFR_AVS_SELD: long (nullable = true)

|-- NR_IDFR_PBCO: long (nullable = true)

|-- NR_IDFR_SGT: long (nullable = true)

|-- TX_TIT_PDRO_AVS: string (nullable = true)

|-- TX_STIT_PDRO_AVS: string (nullable = true)

|-- TX_ACMT_PDRO_AVS: string (nullable = true)

|-- TX_PRPT_PRM_HDR_API: string (nullable = true)

|-- NM_DB_OGM: string (nullable = true)

|-- NM_TAB_OGM: string (nullable = true)

|-- CD_TIP_ECP_OGM: short (nullable = true)

|-- CD_FMA_REF_OGM: string (nullable = true)

|-- TS_FIM_REG: timestamp (nullable = true)

|-- NM_COL_ECP_OGM: string (nullable = true)

|-- TS_ULT_DT_OBSD_OGM: timestamp (nullable = true)

|-- TS_ULT_DT_PRCD_OGM: timestamp (nullable = true)

|-- QT_DADO_OGM: long (nullable = true)
 
 
------------------------------------------------------------------------------------------------------------------------

TABELA: sbx_t2i2016.RCM_FNC_CLI

------------------------------------------------------------------------------------------------------------------------

root

|-- CD_IDFR_AVS: string (nullable = true)

|-- CD_CLI: integer (nullable = true)

|-- DT_AVS_FNC_CLI: date (nullable = true)

|-- NR_IDFR_PROJ: long (nullable = true)

|-- NR_IDFR_RCM: long (nullable = true)

|-- NR_VRS_VLDD_RCM: short (nullable = true)

|-- NR_IDFR_AVS_SELD: long (nullable = true)

|-- NR_IDFR_PBCO: long (nullable = true)

|-- NR_IDFR_SGT: long (nullable = true)

|-- CD_EST_VRS_RCM: short (nullable = true)

|-- TX_TIT_PDRO_AVS: string (nullable = true)

|-- TX_STIT_PDRO_AVS: string (nullable = true)

|-- TX_ACMT_PDRO_AVS: string (nullable = true)

|-- TX_PRM_HDR_API_AVS: string (nullable = true)

|-- PC_NVL_CNFA_AVS: decimal(4,2) (nullable = true)

|-- NM_DB_OGM: string (nullable = true)

|-- NM_TAB_OGM: string (nullable = true)

|-- CD_TIP_ECP_OGM: short (nullable = true)

|-- CD_FMA_REF_OGM: string (nullable = true)

|-- NM_COL_ECP_OGM: string (nullable = true)

|-- TS_ULT_DT_PRCD_OGM: timestamp (nullable = true)

|-- QT_DADO_OGM: long (nullable = true)
 
 
------------------------------------------------------------------------------------------------------------------------

TABELA: sbx_t2i2016.RCM_FNC_CLI_EVTL

------------------------------------------------------------------------------------------------------------------------

root

|-- CD_IDFR_AVS: string (nullable = true)

|-- CD_CLI: integer (nullable = true)

|-- DT_AVS_FNC_CLI: date (nullable = true)

|-- NR_IDFR_PROJ: long (nullable = true)

|-- NR_IDFR_RCM: long (nullable = true)

|-- NR_VRS_VLDD_RCM: short (nullable = true)

|-- NR_IDFR_AVS_SELD: long (nullable = true)

|-- NR_IDFR_PBCO: long (nullable = true)

|-- NR_IDFR_SGT: long (nullable = true)

|-- CD_EST_VRS_RCM: short (nullable = true)

|-- TX_TIT_PDRO_AVS: string (nullable = true)

|-- TX_STIT_PDRO_AVS: string (nullable = true)

|-- TX_ACMT_PDRO_AVS: string (nullable = true)

|-- TX_PRM_HDR_API_AVS: string (nullable = true)

|-- PC_NVL_CNFA_AVS: decimal(4,2) (nullable = true)

|-- NM_DB_OGM: string (nullable = true)

|-- NM_TAB_OGM: string (nullable = true)

|-- CD_TIP_ECP_OGM: short (nullable = true)

|-- CD_FMA_REF_OGM: string (nullable = true)

|-- NM_COL_ECP_OGM: string (nullable = true)

|-- TS_ULT_DT_PRCD_OGM: timestamp (nullable = true)

|-- QT_DADO_OGM: long (nullable = true)
 
 
------------------------------------------------------------------------------------------------------------------------

TABELA: sbx_t2i2016.ANDO_RCM_FNC_CLI

------------------------------------------------------------------------------------------------------------------------

root

|-- CD_IDFR_AVS: string (nullable = true)

|-- DA_CD_CLI: string (nullable = true)

|-- DT_AVS_FNC_CLI: date (nullable = true)

|-- NR_IDFR_PROJ: long (nullable = true)

|-- NR_IDFR_RCM: long (nullable = true)

|-- NR_VRS_VLDD_RCM: short (nullable = true)

|-- NR_IDFR_AVS_SELD: long (nullable = true)

|-- NR_IDFR_PBCO: long (nullable = true)

|-- NR_IDFR_SGT: long (nullable = true)

|-- CD_EST_VRS_RCM: short (nullable = true)

|-- TX_TIT_PDRO_AVS: string (nullable = true)

|-- TX_STIT_PDRO_AVS: string (nullable = true)

|-- TX_ACMT_PDRO_AVS: string (nullable = true)

|-- TX_PRM_HDR_API_AVS: string (nullable = true)

|-- PC_NVL_CNFA_AVS: decimal(4,2) (nullable = true)

|-- NM_DB_OGM: string (nullable = true)

|-- NM_TAB_OGM: string (nullable = true)

|-- CD_TIP_ECP_OGM: short (nullable = true)

|-- CD_FMA_REF_OGM: string (nullable = true)

|-- NM_COL_ECP_OGM: string (nullable = true)

|-- TS_ULT_DT_PRCD_OGM: timestamp (nullable = true)

|-- QT_DADO_OGM: long (nullable = true)
 
 
------------------------------------------------------------------------------------------------------------------------

TABELA: sbx_t2i2016.ANDO_RCM_FNC_CLI_EVTL

------------------------------------------------------------------------------------------------------------------------

root

|-- CD_IDFR_AVS: string (nullable = true)

|-- DA_CD_CLI: string (nullable = true)

|-- DT_AVS_FNC_CLI: date (nullable = true)

|-- NR_IDFR_PROJ: long (nullable = true)

|-- NR_IDFR_RCM: long (nullable = true)

|-- NR_VRS_VLDD_RCM: short (nullable = true)

|-- NR_IDFR_AVS_SELD: long (nullable = true)

|-- NR_IDFR_PBCO: long (nullable = true)

|-- NR_IDFR_SGT: long (nullable = true)

|-- CD_EST_VRS_RCM: short (nullable = true)

|-- TX_TIT_PDRO_AVS: string (nullable = true)

|-- TX_STIT_PDRO_AVS: string (nullable = true)

|-- TX_ACMT_PDRO_AVS: string (nullable = true)

|-- TX_PRM_HDR_API_AVS: string (nullable = true)

|-- PC_NVL_CNFA_AVS: decimal(4,2) (nullable = true)

|-- NM_DB_OGM: string (nullable = true)

|-- NM_TAB_OGM: string (nullable = true)

|-- CD_TIP_ECP_OGM: short (nullable = true)

|-- CD_FMA_REF_OGM: string (nullable = true)

|-- NM_COL_ECP_OGM: string (nullable = true)

|-- TS_ULT_DT_PRCD_OGM: timestamp (nullable = true)

|-- QT_DADO_OGM: long (nullable = true)
 