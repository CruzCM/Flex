<html>
  <img src="https://analytics.fontes.intranet.bb.com.br/uploads/-/system/appearance/header_logo/1/bancodobrasil.png" alt="Banco do Brasil" width="200">
  <img src="https://analytics.fontes.intranet.bb.com.br/t99/f0502726/modelo_do_alan/raw/master/_img/uan.png" alt="UAN" width="200">
</html>

# Processo de ETL - Vinculação de Recomendação de Clientes

## Bloco Institucional e Metadados

| Assunto                     | Vinculação de Recomendação de Clientes |
|-----------------------------|----------------------------------------|
| Área/Unidade                | UAN                                   |
| Responsáveis                | F6745399                      |
| Número de demanda/GAIA      | 2026000896                      |
| Datas relevantes            | Criação: 2026-06-22                   |
| Status                      | Ativo                      |

---

## Sumário

- [Processo de ETL - Vinculação de Recomendação de Clientes](#processo-de-etl---vinculação-de-recomendação-de-clientes)
  - [Bloco Institucional e Metadados](#bloco-institucional-e-metadados)
  - [Sumário](#sumário)
  - [1. Introdução ](#1-introdução-)
    - [Objetivo ](#objetivo-)
    - [Resultado esperado ](#resultado-esperado-)
    - [Motivação ](#motivação-)
    - [Definição e segmentação do público-alvo ](#definição-e-segmentação-do-público-alvo-)
  - [2. Base de Dados ](#2-base-de-dados-)
    - [Fontes de dados ](#fontes-de-dados-)
    - [Inventário de tabelas ](#inventário-de-tabelas-)
  - [3. Metodologia ](#3-metodologia-)
    - [Tecnologias utilizadas ](#tecnologias-utilizadas-)
    - [Tratamentos realizados ](#tratamentos-realizados-)
    - [Premissas ](#premissas-)
  - [4. Resultados ](#4-resultados-)
    - [Tabelas finais ](#tabelas-finais-)
  - [Observações Finais](#observações-finais)

---

## 1. Introdução <a name="introducao"></a>

### Objetivo <a name="objetivo"></a>
Automatizar o processo de vinculação de recomendações de clientes, utilizando dados provenientes de diferentes fontes (Hive, Oracle e DB2) para gerar insights e alimentar tabelas finais no ambiente Hive e Oracle.

### Resultado esperado <a name="resultado-esperado"></a>
- Geração de tabelas finais com recomendações vinculadas a clientes.
- Publicação dos dados processados nos ambientes Hive e Oracle.
- Garantia de integridade e consistência dos dados.

### Motivação <a name="motivacao"></a>
O projeto visa otimizar o processo de vinculação de recomendações de clientes, garantindo maior eficiência e precisão na análise de dados e na tomada de decisão.

### Definição e segmentação do público-alvo <a name="publico-alvo"></a>
- Analistas de dados e desenvolvedores da UAN.
- Gestores responsáveis pela tomada de decisão baseada em dados de recomendação.
- Equipes de TI envolvidas na manutenção e operação do pipeline de ETL.

---

## 2. Base de Dados <a name="base-de-dados"></a>

### Fontes de dados <a name="fontes-de-dados"></a>
O projeto utiliza as seguintes fontes de dados:
- **Hive**: Tabelas de controle e recomendação.
- **Oracle**: Tabelas de recomendação e clientes.
- **DB2**: Tabelas de origem para validação e enriquecimento de dados.

### Inventário de tabelas <a name="inventario-de-tabelas"></a>
As tabelas identificadas no projeto e os arquivos onde são referenciadas são:

| Tabela                          | Arquivos Referenciados                          |
|---------------------------------|------------------------------------------------|
| HIVE_T2I.CTL_OPRL_RCM        | rotina-principal.ipynb |
| HIVE_T2I.RCM_FNC_CLI         | rotina-principal.ipynb |
| HIVE_T2I.RCM_FNC_CLI_EVTL    | rotina-principal.ipynb |

---

## 3. Metodologia <a name="metodologia"></a>

### Tecnologias utilizadas <a name="tecnologias-utilizadas"></a>
- **Python**: Para desenvolvimento do pipeline de ETL.
- **Spark**: Para processamento distribuído de dados.
- **Hive**: Armazenamento e consulta de dados processados.
- **Oracle**: Armazenamento de dados finais.
- **DB2**: Fonte de dados para validação e enriquecimento.

### Tratamentos realizados <a name="tratamentos-realizados"></a>
- **Sincronização**: Classificação e enriquecimento de dados provenientes do Oracle.
- **Verificação de origem**: Validação e religação de execuções pendentes com base em mudanças na origem dos dados.
- **Vinculação**: Geração de snapshots de clientes e vinculação de recomendações.
- **Publicação**: Escrita de dados processados nos ambientes Hive e Oracle.

### Premissas <a name="premissas"></a>
- As tabelas de origem devem estar acessíveis e com permissões adequadas.
- O ambiente Spark deve estar configurado corretamente para acesso ao Hive, Oracle e DB2.
- As tabelas de destino no Hive e Oracle devem ter esquemas compatíveis com os contratos definidos.

---

## 4. Resultados <a name="resultados"></a>

### Tabelas finais <a name="tabelas-finais"></a>
As tabelas finais geradas pelo processo de ETL são:

| Tabela                          | Ambiente | Campos Principais |
|---------------------------------|----------|-------------------|
| CTL_OPRL_RCM                    | Hive     | NR_IDFR_PROJ, NR_IDFR_RCM, NR_VRS_VLDD_RCM, CD_EST_RCM, IN_REG_ATU |
| RCM_FNC_CLI                     | Hive     | CD_IDFR_AVS, CD_CLI, DT_AVS_FNC_CLI, NR_IDFR_PROJ, NR_IDFR_RCM |
| RCM_FNC_CLI_EVTL                | Hive     | CD_IDFR_AVS, CD_CLI, DT_AVS_FNC_CLI, NR_IDFR_PROJ, NR_IDFR_RCM |
| AVS_FNC_CLI                     | Oracle   | PC_NVL_CNFA_AVS, CD_IDFR_AVS, DT_AVS_FNC_CLI, TX_TIT_AVS_FNC_CLI |

---

## Observações Finais

- O projeto foi desenvolvido com base em boas práticas de ETL, garantindo a integridade e consistência dos dados.
- Caso sejam identificados problemas de acesso às tabelas ou inconsistências nos dados, recomenda-se revisar as permissões e os contratos de dados.
- Para mais informações, consulte os notebooks e arquivos de código disponíveis na estrutura do projeto.

---