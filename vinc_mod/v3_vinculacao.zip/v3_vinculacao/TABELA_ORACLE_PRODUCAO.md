# DDL Oracle de referência para modelagem

**Projeto:** não informado explicitamente no DDL Oracle.

**Objetivo:** documentação de referência da modelagem Oracle das estruturas recebidas no arquivo `TABELA_ORACLE.md`.

**Base de referência:** DDL Oracle com comandos `CREATE TABLE`, `PRIMARY KEY`, `FOREIGN KEY`, `CHECK`, `DEFAULT` e comentários `COMMENT ON TABLE` / `COMMENT ON COLUMN`.

> ⚠️ **Critério de preenchimento**
>
> Esta documentação usa somente as informações presentes no DDL Oracle recebido. Campos como formato de armazenamento, compressão, localização física, periodicidade, classificação de segurança, origem, retenção, LGPD e ModelAI permanecem como `não informado no DDL Oracle` quando não aparecem na fonte.

> 🧾 **Critério de comentários dos atributos**
>
> A descrição de cada campo foi extraída do respectivo `COMMENT ON COLUMN`. Quando o DDL não informa nome lógico formal, unique individual ou metadados físicos, a documentação registra explicitamente a ausência da informação.

---

# Índice

- [1. Tabela `AVS_FNC_CLI`](#avs_fnc_cli)
- [2. Tabela `VSLO_AVS_FNC_CLI`](#vslo_avs_fnc_cli)
- [3. Tabela `REG_CRIC_IA`](#reg_cric_ia)
- [4. Tabela `PMPT_TCN`](#pmpt_tcn)
- [5. Tabela `PBCO_CADD`](#pbco_cadd)
- [6. Tabela `SGT_CADD`](#sgt_cadd)
- [7. Tabela `TND_CGTV_TCN`](#tnd_cgtv_tcn)
- [8. Tabela `CNR_TCN`](#cnr_tcn)
- [9. Tabela `APSC_TCN`](#apsc_tcn)
- [10. Tabela `AVS_SELD`](#avs_seld)
- [11. Tabela `PROJ_CADD`](#proj_cadd)
- [12. Tabela `RCM_VLDD`](#rcm_vldd)
- [13. Tabela `RCM_VRS`](#rcm_vrs)
- [Resumo visual das tabelas](#resumo-visual-das-tabelas)
- [Resumo dos relacionamentos declarados](#resumo-dos-relacionamentos-declarados)
- [Resumo dos campos com nulidade permitida](#resumo-dos-campos-com-nulidade-permitida)

---

<a id="avs_fnc_cli"></a>

# 1. Tabela `AVS_FNC_CLI`

## 1.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `AVS_FNC_CLI` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `CD_CLI_AVS`, `CD_IDFR_AVS` |
| **Quantidade de campos** | 7 |
| **Quantidade de campos com `NULL`** | 1 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 1.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
*****************************************************


Tratamento de Exceção - SSA 2025002902

Utilização de Texto com dado concatenado - coluna TX_PRM_HDR_API_AVS

***********************************
******************







Representa os alertas (insight) que serão enviados aos clientes com base nas suas preferências e produtos relacionadas a API Minhas Finanças utilizando Inteligência Artificial (IA) para efetuar as recomendações. 

Os insight serão criados eterão seu nível de confiança da recomendação avaliado antes do envio ao cliente.

Tem o objetivo armazenar os resultados apurados pelos alertas (insight) a nivel de granularidade de cliente. 
Ela será consumida pela API Minhas Finanças, permitindo o acesso externo às informações vinculadas aos clientes.
```

**#PK declarada no DDL:** `CD_CLI_AVS`, `CD_IDFR_AVS`

## 1.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 1.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `PC_NVL_CNFA_AVS` | `NUMBER(4,2)` | `Não` | `Não (0%)` | — |
| 2 | `CD_IDFR_AVS` | `VARCHAR2(36 CHAR)` | `Sim` | `Não (0%)` | — |
| 3 | `DT_AVS_FNC_CLI` | `DATE` | `Não` | `Não (0%)` | — |
| 4 | `TX_TIT_AVS_FNC_CLI` | `VARCHAR2(64 CHAR)` | `Não` | `Não (0%)` | — |
| 5 | `TX_AVS_FNC_CLI` | `VARCHAR2(255 CHAR)` | `Não` | `Não (0%)` | — |
| 6 | `TX_PRM_HDR_API_AVS` | `VARCHAR2(1000 CHAR)` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |
| 7 | `CD_CLI_AVS` | `NUMBER(11)` | `Sim` | `Não (0%)` | — |

## 1.5 Campos obrigatórios

### `PC_NVL_CNFA_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `PC_NVL_CNFA_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(4,2)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Percentual do  nivel de confiança do insight que admite números de 0 a 99.
```

---

### `CD_IDFR_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_IDFR_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(36 CHAR)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Código identificador único do alerta (insight) que será enviado ao cliente com base nas suas preferências e produtos relacionadas a API Minhas Finanças utilizando Inteligência Artificial (IA) para efetuar as recomendações. 

Será gerada um código utilizando o padrão UUID:
0196ee29-aa59-75f9-84d8-31ef01ddfc65
```

---

### `DT_AVS_FNC_CLI`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `DT_AVS_FNC_CLI` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `DATE` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data que o alerta foi disponibilizado para o cliente
```

---

### `TX_TIT_AVS_FNC_CLI`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_TIT_AVS_FNC_CLI` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(64 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Título do alerta exibido para o cliente

Exemplo:
Consentimento Open Finance
```

---

### `TX_AVS_FNC_CLI`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_AVS_FNC_CLI` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(255 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto do alerta exibido para o cliente

Exemplos:
"Com a Agenda Financeira, você gerencia os pagamentos pendentes e ainda organiza suas finanças"
```

---

### `CD_CLI_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_CLI_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Código do Cliente que recebe o alerta de finanças
```

---

## 1.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `TX_PRM_HDR_API_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_PRM_HDR_API_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(1000 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: Será preenchido apenas em alguns alertas não terão uma indicação de parametro do header, como o caso dos alertas apenas textuais. |

Comentário do DDL Oracle:

```text
***********************************
Tratamento de Exceção - SSA 2025002902
Utilização de Texto com dado concatenado
***********************************

Texto de formato variável que contem parâmetros de acionamento da API para reutilização dos insights/alertas. Essa informação atrelada ao cliente e ao UIDD do Insight, será resgatada em outro local para a API ativar o insight correto. 
Os parâmetros irão variar dependendo do tipo de insight/alerta.
 



O primeiro tipo de insight é direcionado para Limite Especial, que são os clientes que utilizam muito o o ccheque especial
 e o segundo tipo direcionado ao Open Finance, que são os clientes que não possuem consentimento no open finance porém são fortes candidatos e/ou seria interessante para o Banco, que aderissem ao uso do OPF.
 


 Exemplos: 

variação 1: tela/CreditoNovo/listarLinhas 

variação 2: {"detailed":"true","opr":"kodiak", "partnerName":"openbank","serviceName":"jrd-csnt-rcpt","entryPoint":"menu"}



Regra de nulidade: Será preenchido apenas em alguns alertas não terão uma indicação de parametro do header, como o caso dos alertas apenas textuais.
```

---

## 1.7 DDL estrutural da tabela

```sql
CREATE TABLE AVS_FNC_CLI
(
	PC_NVL_CNFA_AVS      NUMBER(4,2)  NOT NULL ,
	CD_IDFR_AVS          VARCHAR2(36 CHAR)  NOT NULL ,
	DT_AVS_FNC_CLI       DATE  NOT NULL ,
	TX_TIT_AVS_FNC_CLI   VARCHAR2(64 CHAR)  NOT NULL ,
	TX_AVS_FNC_CLI       VARCHAR2(255 CHAR)  NOT NULL ,
	TX_PRM_HDR_API_AVS   VARCHAR2(1000 CHAR)  NULL ,
	CD_CLI_AVS           NUMBER(11)  NOT NULL ,
 PRIMARY KEY (CD_CLI_AVS,CD_IDFR_AVS)
);
```

---

<a id="vslo_avs_fnc_cli"></a>

# 2. Tabela `VSLO_AVS_FNC_CLI`

## 2.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `VSLO_AVS_FNC_CLI` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `CD_CLI_AVS`, `CD_IDFR_AVS_VSLO` |
| **Quantidade de campos** | 5 |
| **Quantidade de campos com `NULL`** | 1 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 2.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
Guarda informações de apresentação e visualização do insight por parte dos clientes no Minhas Finanças		
```

**#PK declarada no DDL:** `CD_CLI_AVS`, `CD_IDFR_AVS_VSLO`

## 2.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 2.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `CD_CLI_AVS` | `NUMBER(11)` | `Sim` | `Não (0%)` | — |
| 2 | `CD_IDFR_AVS_VSLO` | `VARCHAR2(36 CHAR)` | `Sim` | `Não (0%)` | — |
| 3 | `QT_VSLO_AVS` | `NUMBER(2)` | `Não` | `Não (0%)` | — |
| 4 | `IN_ACMT_LINK` | `CHAR(1 CHAR)` | `Não` | `Não (0%)` | default 'N' |
| 5 | `DT_ULT_INRO_AVS` | `DATE` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |

## 2.5 Campos obrigatórios

### `CD_CLI_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_CLI_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Código do Cliente que visualiza o alerta de finanças
```

---

### `CD_IDFR_AVS_VSLO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_IDFR_AVS_VSLO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(36 CHAR)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Código identificador único do alerta (insight) que é visualizado pelo cliente no aplicativos do Minhas Finanças utilizando Inteligência Artificial (IA). 

Será gerada um código utilizando o padrão UUID:
0196ee29-aa59-75f9-84d8-31ef01ddfc65
```

---

### `QT_VSLO_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `QT_VSLO_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(2)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Quantidade de vezes que o cliente acionou esse aviso

Exemplo:
1
4
```

---

### `IN_ACMT_LINK`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `IN_ACMT_LINK` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CHAR(1 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Valor padrão | `'N'` |

Comentário do DDL Oracle:

```text
Indica se o cliente clicou no aviso, isto é, se acessou o deep link.

S - Sim, houve o acionamento do Link
N - Não, não  houve o acionamento do Link.

Default: N
```

---

## 2.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `DT_ULT_INRO_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `DT_ULT_INRO_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `DATE` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de Nulidade: Será nulo se o cliente ainda não interagiu com o insight. |

Comentário do DDL Oracle:

```text
Data que o alerta foi acessado pela última vez pelo cliente



Regra de Nulidade: Será nulo se o cliente ainda não interagiu com o insight.
```

---

## 2.7 DDL estrutural da tabela

```sql
CREATE TABLE VSLO_AVS_FNC_CLI
(
	CD_CLI_AVS           NUMBER(11)  NOT NULL ,
	CD_IDFR_AVS_VSLO     VARCHAR2(36 CHAR)  NOT NULL ,
	QT_VSLO_AVS          NUMBER(2)  NOT NULL ,
	IN_ACMT_LINK         CHAR(1 CHAR)  DEFAULT 'N'  NOT NULL ,
	DT_ULT_INRO_AVS      DATE  NULL ,
 PRIMARY KEY (CD_CLI_AVS,CD_IDFR_AVS_VSLO)
);
```

---

<a id="reg_cric_ia"></a>

# 3. Tabela `REG_CRIC_IA`

## 3.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `REG_CRIC_IA` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_REG` |
| **Quantidade de campos** | 5 |
| **Quantidade de campos com `NULL`** | 0 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 3.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
************************************
Tratamento de Exceção - SSA 2026000581
Utilização de JSON
************************************


Tabela que armazena as criações geradas nas interações do usuário com a  Inteligência Artificial. Ele armazena informações de identificação, o conteúdo completo da criação em formato estruturado, quem foi o usuário responsável e a data e hora em que a criação ocorreu.
 
Exemplo:
Código da Criação Externa:0196ee29-aa59-75f9-84d8-31ef01ddfc65
Json da criação Detalhada: Você é um especialista em transformar textos revisados em textos persuasivos orientados à ação (pt-BR), aplicando rigorosamente a estrutura de persuasão indicada na CENARIO_INTENCAO, adequando linguagem e abordagem ao CENARIO_DESCRICAO, sem alterar fatos ou o sentido do TEXTO_REVISADO.
 
[PRINCÍPIOS]
- Preserve integralmente significado, intenção, tom e objetivo comunicativo do TEXTO_REVISADO.
- Não invente dados, números, garantias, depoimentos, resultados, comparações ou promessas não contidas no TEXTO_REVISADO.
- Execute exatamente a estrutura/forma de condução indicada na CENARIO_INTENCAO; não escolha outra.
- Ajuste vocabulário, ritmo e nível de formalidade ao CENARIO_DESCRICAO, sem hiperbolizar nem pressionar artificialmente.
- Se houver lacuna para cumprir a estrutura pedida, use apenas: (a) paráfrase, (b) reordenação, ou (c) consequência explicitamente afirmada no TEXTO_REVISADO. É proibido completar com extrapolações (“provável”, “comum”, “tipicamente”, “em geral”).
- Se CENARIO_INTENCAO não trouxer uma estrutura explícita (etapas, ordem, modelo ou esqueleto), use obrigatoriamente o PADRÃO DE ESTRUTURA MÍNIMA definido abaixo, respeitando o objetivo comunicacional declarado.
 
[HIERARQUIA]
1) FORMATO DE SAÍDA
2) RESTRIÇÕES
3) CENARIO_INTENCAO (objetivo + estrutura)
4) CENARIO_DESCRICAO (contexto de uso)
5) TEXTO_REVISADO
 
[PROCESSO OBRIGATÓRIO: SEQUÊNCIA INTERNA]
1) Ler o TEXTO_REVISADO e identificar limites semânticos e valor central.
2) Extrair núcleo: público, problema, solução, mecanismo (se houver) e benefício final descrito.
3) Ler o CENARIO_DESCRICAO e calibrar voz, nível de formalidade, extensão e ritmo.
4) Interpretar a CENARIO_INTENCAO: objetivo, estrutura e função de cada etapa. Se não houver estrutura explícita, ativar o PADRÃO DE ESTRUTURA MÍNIMA
5) Mapear o conteúdo em unidades de significado e preparar redistribuição.
6) Redistribuir o conteúdo nas etapas da estrutura aplicável, sem distorcer sentido.
7) Ajustar linguagem conforme a função de cada etapa definida pela estrutura solicitada, mantendo naturalidade.
8) Conectar características/mecanismos a consequências práticas apenas quando explicitamente afirmadas no TEXTO_REVISADO.
9) Construir fechamento com próximo passo como consequência lógica, sem imposição ou pressão artificial.
10) Revisar por clareza imediata, coerência interna, fidelidade factual e facilidade de decisão.
 
[PADRÃO DE ESTRUTURA MÍNIMA]
- Aplique esta ordem fixa, ajustando o conteúdo apenas com base no TEXTO_REVISADO:
1) Abertura contextual alinhada ao CENARIO_DESCRICAO (1–2 frases).
2) Valor central do TEXTO_REVISADO (o que é/oferece) + para quem (se identificável no texto).
3) Problema/necessidade que o texto resolve (somente se estiver no TEXTO_REVISADO; caso não esteja, omitir).
4) Solução/mecanismo/como funciona (somente o que estiver no TEXTO_REVISADO).
5) Benefícios/resultados (somente os explicitamente afirmados no TEXTO_REVISADO).
6) Próximo passo orientado à ação: apenas ações compatíveis e explicitamente sugeridas no TEXTO_REVISADO; se não houver, fechamento neutro (“saiba mais”, “consulte”, “considere”) sem instrução operacional específica.
 
```

**#PK declarada no DDL:** `NR_IDFR_REG`

## 3.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 3.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_REG` | `NUMBER(11)` | `Sim` | `Não (0%)` | identidade |
| 2 | `CD_CRIC_EXNO` | `VARCHAR2(36 CHAR)` | `Não` | `Não (0%)` | — |
| 3 | `JS_CRIC_DETD` | `CLOB CHAR` | `Não` | `Não (0%)` | CHECK IS JSON |
| 4 | `TS_CRIC_REG` | `TIMESTAMP` | `Não` | `Não (0%)` | — |
| 5 | `CD_USU_RSP_ATL` | `VARCHAR2(8 CHAR)` | `Não` | `Não (0%)` | — |

## 3.5 Campos obrigatórios

### `NR_IDFR_REG`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_REG` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Geração automática | `Sim` — `GENERATED ALWAYS AS IDENTITY` |

Comentário do DDL Oracle:

```text
Identificador numerico unico do registro. Valor sequencial gerado automaticamente.
```

---

### `CD_CRIC_EXNO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_CRIC_EXNO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(36 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Codigo identificador único que identifica a geração realizada pelo pipeline.


Será gerada um código utilizando o padrão UUID:
0196ee29-aa59-75f9-84d8-31ef01ddfc65
```

---

### `JS_CRIC_DETD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `JS_CRIC_DETD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Restrição JSON | `CHECK (JS_CRIC_DETD IS JSON)` |

Comentário do DDL Oracle:

```text
************************************
Tratamento de Exceção - SSA 2026000581
Utilização de JSON
************************************

Payload acumulado da geração, contendo todo o conteúdo produzido pelo pipeline de IA. 
Armazenado em formato JSON, inclui parâmetros, entradas, saídas e metadados. Cada geração pode reunir diversos payloads relacionados, consolidando todas as informações necessárias.
```

---

### `TS_CRIC_REG`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TS_CRIC_REG` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `TIMESTAMP` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data e hora do registro da criacao.
```

---

### `CD_USU_RSP_ATL`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_USU_RSP_ATL` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(8 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
CONCEITO: Código da pessoa autorizada ao uso de recursos computacionais.
EXEMPLOS: C1234567, F8901234

Codigo da matricula do usuario responsavel pela criacao.
```

---

## 3.6 Campos com nulidade permitida pelo DDL

Não há campos `NULL` declarados no DDL Oracle para esta tabela.

## 3.7 DDL estrutural da tabela

```sql
CREATE TABLE REG_CRIC_IA
(
	NR_IDFR_REG          NUMBER(11)  GENERATED ALWAYS 
	AS IDENTITY ( 
		START WITH 1
		INCREMENT BY 1
		NOCYCLE 
		CACHE 50)  NOT NULL ,
	CD_CRIC_EXNO         VARCHAR2(36 CHAR)  NOT NULL ,
	JS_CRIC_DETD         CLOB CHAR  NOT NULL  CHECK (JS_CRIC_DETD IS JSON),
	TS_CRIC_REG          TIMESTAMP  NOT NULL ,
	CD_USU_RSP_ATL       VARCHAR2(8 CHAR)  NOT NULL ,
 PRIMARY KEY (NR_IDFR_REG)
);
```

---

<a id="pmpt_tcn"></a>

# 4. Tabela `PMPT_TCN`

## 4.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `PMPT_TCN` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_PMPT_IDFR` |
| **Quantidade de campos** | 8 |
| **Quantidade de campos com `NULL`** | 1 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 4.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
Tabela que armazena os textos de comando (prompts) usados para gerar conteúdos. Esse registro permite saber para que cada prompt serve, acompanhar suas versões ao longo do tempo e identificar em qual etapa do processo ele é utilizado. Funciona como um repositório organizado de textos, garantindo padronização, controle e rastreabilidade do uso desses prompts. Conceito Prompt é um texto que orienta a Inteligência Artificial sobre o que fazer e como gerar um conteúdo.
 
 
Exemplo:
 
nome do prompt Padrão: Revisor de textos
 
codigo da etapa posicional: 1
 
numero da versão atual: 0
 
texto da função Operacional do prompt: Revisar textos com precisão, corrigindo gramática, clareza, coesão e estilo, sem alterar o sentido original.
 
texto da Diretrizes orientadoras do prompt: [TEXTO_BASE]<<< {PH_BASE_BB} >>> [LIMITE_DE_CARACTERES]<<<{PH_LIMITE_CARACTER_TEXTO}
 
texto do padrão definido do prompt:- Apresente somente o texto final revisado.
- Não utilize títulos, comentários, marcações, explicações, observações adicionais ou destaque de alterações.
- Quebras de linha podem ser ajustadas apenas para legibilidade.
- Não crie listas novas; se existirem no texto original, preserve a estrutura.
- Entregue exclusivamente o que foi solicitado.
 
quantidade de variáveis totais:1
```

**#PK declarada no DDL:** `NR_PMPT_IDFR`

## 4.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 4.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_PMPT_IDFR` | `NUMBER(11)` | `Sim` | `Não (0%)` | identidade |
| 2 | `NM_PMPT_PDRO` | `VARCHAR2(100 CHAR)` | `Não` | `Não (0%)` | — |
| 3 | `NR_ETP_PSCL` | `NUMBER(3)` | `Não` | `Não (0%)` | — |
| 4 | `NR_VRS_ATU` | `NUMBER(3)` | `Não` | `Não (0%)` | — |
| 5 | `TX_FUC_OPRL_PMPT` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 6 | `TX_DTZ_ORTR_PMPT` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 7 | `TX_PDRO_DFND_PMPT` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 8 | `QT_VRV_TTL` | `NUMBER(3)` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |

## 4.5 Campos obrigatórios

### `NR_PMPT_IDFR`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_PMPT_IDFR` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Geração automática | `Sim` — `GENERATED ALWAYS AS IDENTITY` |

Comentário do DDL Oracle:

```text
Identificador numérico único do prompt técnico para controle, referência e rastreabilidade.
```

---

### `NM_PMPT_PDRO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_PMPT_PDRO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(100 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome técnico que identifica o prompt no pipeline de IA, permitindo catalogação, padronização e reuso.
```

---

### `NR_ETP_PSCL`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_ETP_PSCL` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(3)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
É a etapa do pipeline em que o prompt é aplicado, determinando sua posição/uso no fluxo.
```

---

### `NR_VRS_ATU`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_VRS_ATU` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(3)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Número sequencial da versão do prompt, habilitando controle evolutivo e rastreabilidade.
```

---

### `TX_FUC_OPRL_PMPT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_FUC_OPRL_PMPT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição textual detalhada da função exercida pelo prompt, contextualizando seu propósito operacional no pipeline.Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_DTZ_ORTR_PMPT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DTZ_ORTR_PMPT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Conjunto de regras e orientações operacionais para uso do prompt (requisitos, limites e expectativas de execução).Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_PDRO_DFND_PMPT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_PDRO_DFND_PMPT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto base reutilizável associado ao prompt, utilizado como conteúdo de criação para orientar a geração de respostas.Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

## 4.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `QT_VRV_TTL`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `QT_VRV_TTL` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(3)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: só deve ser preenchido quando o prompt técnico incluir alguma variável para checagem técnica. |

Comentário do DDL Oracle:

```text
Quantidade de parâmetros configuráveis no prompt.
Indica quantas variáveis podem ser ajustadas no prompt técnico.


Regra de nulidade: só deve ser preenchido quando o prompt técnico incluir alguma variável para checagem técnica.
```

---

## 4.7 DDL estrutural da tabela

```sql
CREATE TABLE PMPT_TCN
(
	NR_PMPT_IDFR         NUMBER(11)  GENERATED ALWAYS 
	AS IDENTITY ( 
		START WITH 1
		INCREMENT BY 1
		NOCYCLE 
		CACHE 50)  NOT NULL ,
	NM_PMPT_PDRO         VARCHAR2(100 CHAR)  NOT NULL ,
	NR_ETP_PSCL          NUMBER(3)  NOT NULL ,
	NR_VRS_ATU           NUMBER(3)  NOT NULL ,
	TX_FUC_OPRL_PMPT     CLOB CHAR  NOT NULL ,
	TX_DTZ_ORTR_PMPT     CLOB CHAR  NOT NULL ,
	TX_PDRO_DFND_PMPT    CLOB CHAR  NOT NULL ,
	QT_VRV_TTL           NUMBER(3)  NULL ,
 PRIMARY KEY (NR_PMPT_IDFR)
);
```

---

<a id="pbco_cadd"></a>

# 5. Tabela `PBCO_CADD`

## 5.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `PBCO_CADD` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_PBCO` |
| **Quantidade de campos** | 14 |
| **Quantidade de campos com `NULL`** | 3 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 5.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
 Tabela que reúne informações sobre públicos utilizados nas recomendações que serão geradas, permitindo sua reutilização. Contém dados de identificação e descrição do público, incluindo suas principais características e necessidades (racionais e emocionais). Também registra regras de texto que devem ou não ser utilizadas nas comunicações, além da origem do público, quando houver vínculo com outro caso ou tabela externa. O cadastro mantém ainda o status atual e as informações de criação, como usuário responsável e data/hora do registro.
 


Exemplo:

 
Nome do Público: CDC 

Texto da Descrição detalhada do público: Pessoas que usam limite especial e querem pagar menos juros.

Texto da Necessidade Racional: Ter parcelas fixas e juros menores.

Texto da Necessidade emoção: Alívio e confiança para organizar as contas.

Texto do termo Obrigatório do público: organização, juros menores

texto do termo não permitidos do público: garantia, desconto

Nome do banco de dados: HIVE

Código do tipo de tabela:2
 
Nome da tabela no banco de dados:xxxx_cdc

Nome da coluna na tabela:cd_xxx


 
obs.: 
os atributos a seguir realmente devem ser Null, poque na regra do funcionamento da solução, esses campos não devem ser de preenchimento obrigatório:
-
> Texto do termo Obrigatório do público
-
> Texto do termo não permitidos do público
-
> Nome da coluna no banco de dados.

 Regra de nulidade: no caso de tipo de tabela ser: de Tabela com publico único não precisa ser preenchido.
 
```

**#PK declarada no DDL:** `NR_IDFR_PBCO`

## 5.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 5.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_PBCO` | `NUMBER(11)` | `Sim` | `Não (0%)` | identidade |
| 2 | `NM_PBCO_PDRO` | `VARCHAR2(500 CHAR)` | `Não` | `Não (0%)` | — |
| 3 | `TX_DCR_DETD_PBCO` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 4 | `TX_NCDD_RCNL_PBCO` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 5 | `TX_NCDD_EMOC_PBCO` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 6 | `TX_TRM_OBG_PBCO` | `CLOB CHAR` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |
| 7 | `TX_TRM_N_PMT_PBCO` | `CLOB CHAR` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |
| 8 | `NM_DB` | `VARCHAR2(100 CHAR)` | `Não` | `Não (0%)` | — |
| 9 | `NM_TAB_DB` | `VARCHAR2(100 CHAR)` | `Não` | `Não (0%)` | — |
| 10 | `NM_COL_TAB` | `VARCHAR2(100 CHAR)` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |
| 11 | `TS_CAD` | `TIMESTAMP` | `Não` | `Não (0%)` | — |
| 12 | `CD_EST_PBCO` | `NUMBER(1)` | `Não` | `Não (0%)` | — |
| 13 | `CD_TIP_TAB` | `NUMBER(1)` | `Não` | `Não (0%)` | — |
| 14 | `CD_USU_RSP_CAD` | `VARCHAR2(8 CHAR)` | `Não` | `Não (0%)` | — |

## 5.5 Campos obrigatórios

### `NR_IDFR_PBCO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_PBCO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Geração automática | `Sim` — `GENERATED ALWAYS AS IDENTITY` |

Comentário do DDL Oracle:

```text
Identificador numérico único do cadastro de público.
```

---

### `NM_PBCO_PDRO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_PBCO_PDRO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(500 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome pelo qual o público é identificado.
```

---

### `TX_DCR_DETD_PBCO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DCR_DETD_PBCO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição textual do público. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_NCDD_RCNL_PBCO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_NCDD_RCNL_PBCO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Necessidade racional associada ao público.
 Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_NCDD_EMOC_PBCO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_NCDD_EMOC_PBCO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Necessidade emocional associada ao público.
 Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `NM_DB`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_DB` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(100 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome da base de dados externa considerada para o público.
```

---

### `NM_TAB_DB`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_TAB_DB` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(100 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome da tabela (na base externa) considerada para o público.
```

---

### `TS_CAD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TS_CAD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `TIMESTAMP` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data e hora de criação do registro de público.
```

---

### `CD_EST_PBCO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_EST_PBCO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(1)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Estados que podem ocorrer: 
1=ATIVO, 
2=INATIVO, 
3=IMUTAVEL
```

---

### `CD_TIP_TAB`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_TIP_TAB` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(1)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Codigo do Tipo Tabela

1 - Tabela com publico único

2 - Tabela multi-publico
```

---

### `CD_USU_RSP_CAD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_USU_RSP_CAD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(8 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
CONCEITO: Código da pessoa autorizada ao uso de recursos computacionais.
EXEMPLOS: C1234567, F8901234
```

---

## 5.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `TX_TRM_OBG_PBCO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_TRM_OBG_PBCO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial utilize termos obrigatórios. |

Comentário do DDL Oracle:

```text
Conjunto de termos/expressões obrigatórias.Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).


Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial utilize termos obrigatórios.
```

---

### `TX_TRM_N_PMT_PBCO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_TRM_N_PMT_PBCO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial não utilize algum conjunto de termos/expressões. |

Comentário do DDL Oracle:

```text
Conjunto de termos/expressões não permitadas.
 Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).


Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial não utilize algum conjunto de termos/expressões.
```

---

### `NM_COL_TAB`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_COL_TAB` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(100 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: será preenchido apenas se o publico estiver em uma tabela com "multi-publico" |

Comentário do DDL Oracle:

```text
Nome da coluna da tabela (na base externa) considerada para fazer a vinculação com o público.


Regra de nulidade: será preenchido apenas se o publico estiver em uma tabela com "multi-publico"
```

---

## 5.7 DDL estrutural da tabela

```sql
CREATE TABLE PBCO_CADD
(
	NR_IDFR_PBCO         NUMBER(11)  GENERATED ALWAYS 
	AS IDENTITY ( 
		START WITH 1
		INCREMENT BY 1
		NOCYCLE 
		CACHE 50)  NOT NULL ,
	NM_PBCO_PDRO         VARCHAR2(500 CHAR)  NOT NULL ,
	TX_DCR_DETD_PBCO     CLOB CHAR  NOT NULL ,
	TX_NCDD_RCNL_PBCO    CLOB CHAR  NOT NULL ,
	TX_NCDD_EMOC_PBCO    CLOB CHAR  NOT NULL ,
	TX_TRM_OBG_PBCO      CLOB CHAR  NULL ,
	TX_TRM_N_PMT_PBCO    CLOB CHAR  NULL ,
	NM_DB                VARCHAR2(100 CHAR)  NOT NULL ,
	NM_TAB_DB            VARCHAR2(100 CHAR)  NOT NULL ,
	NM_COL_TAB           VARCHAR2(100 CHAR)  NULL ,
	TS_CAD               TIMESTAMP  NOT NULL ,
	CD_EST_PBCO          NUMBER(1)  NOT NULL ,
	CD_TIP_TAB           NUMBER(1)  NOT NULL ,
	CD_USU_RSP_CAD       VARCHAR2(8 CHAR)  NOT NULL ,
 PRIMARY KEY (NR_IDFR_PBCO)
);
```

---

<a id="sgt_cadd"></a>

# 6. Tabela `SGT_CADD`

## 6.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `SGT_CADD` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_SGT` |
| **Quantidade de campos** | 11 |
| **Quantidade de campos com `NULL`** | 3 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 6.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
Tabela que armazena as sugestões que podem ser reaproveitadas na criação de recomendações. Cada sugestão pode ser associada a públicos já cadastrados e contém informações básicas de identificação, como nome e descrição, além dos principais benefícios que comunica, tanto racionais quanto emocionais. O registro também define orientações sobre quais termos devem ou não ser usados nos textos e indica se a sugestão está ativa ou não no sistema.
 
 
Texto do Registro Externo da sugestão:
*Regra de nulidade: será preenchido apenas se a sugestão cadastrada estiver vinculada a algum produto do banco. 
O cadastro é feito ativamente pelo usuário.
Exemplo:
 
Texto do Registro Externo da sugestão:10
Nome da Sugestão Padrão:
Texto da Descrição Detalhada da sugestão: Comprar um imóvel sem pesar no orçamento.
Leitura e marcação
- Identificar tema e intenção do texto (informar, orientar, anunciar, responder).
- Identificar promessas explícitas e o que o texto afirma como valor/benefício.
- Identificar fatos sensíveis: nomes, números, datas, valores, condições, políticas, prazos, limitações, links/URLs, e-mails e @handles.
- Identificar tom atual (frio, neutro, autoritário, técnico, promocional etc.).
- Fixar tudo o que não pode mudar.
 
Texto do beneficio Racional da sugestão: Satisfação por fazer um bom negócio.<<<{{PH_CENARIO_DESCRICAO}}>>> 
Texto do Beneficio Emoção da sugestão:Motivação e segurança ao ver as metas avançarem.<<<{{PH_CENARIO_FUNCAO}}>>>
 
Texto do Termo Obrigatórios da sugestão: economia
Texto do termo Não Permitido da sugestão: garantia, futuro, prometo.
Código do Estado da sugestão:1
```

**#PK declarada no DDL:** `NR_IDFR_SGT`

## 6.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 6.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_SGT` | `NUMBER(11)` | `Sim` | `Não (0%)` | identidade |
| 2 | `TX_REG_EXNO_SGT` | `VARCHAR2(100 CHAR)` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |
| 3 | `NM_SGT_PDRO` | `VARCHAR2(500 CHAR)` | `Não` | `Não (0%)` | — |
| 4 | `TX_DCR_DETD_SGT` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 5 | `TX_BNF_RCNL_SGT` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 6 | `TX_BNF_EMOC_SGT` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 7 | `TX_TRM_OBG_SGT` | `CLOB CHAR` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |
| 8 | `TX_TRM_N_PMT_SGT` | `CLOB CHAR` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |
| 9 | `TS_CAD_SGT` | `TIMESTAMP` | `Não` | `Não (0%)` | — |
| 10 | `CD_EST_SGT` | `NUMBER(1)` | `Não` | `Não (0%)` | — |
| 11 | `CD_USU_RSP_CAD_SGT` | `VARCHAR2(8 CHAR)` | `Não` | `Não (0%)` | — |

## 6.5 Campos obrigatórios

### `NR_IDFR_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Geração automática | `Sim` — `GENERATED ALWAYS AS IDENTITY` |

Comentário do DDL Oracle:

```text
Indentificador numérico único do cadastro de sugestão.
```

---

### `NM_SGT_PDRO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_SGT_PDRO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(500 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome negocial da sugestão para identificação e reutilização.
```

---

### `TX_DCR_DETD_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DCR_DETD_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição textual da sugestão, detalhando seu conteúdo e contexto. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_BNF_RCNL_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_BNF_RCNL_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Benefício racional associado à sugestão. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_BNF_EMOC_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_BNF_EMOC_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Benefício emocional associado à sugestão. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TS_CAD_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TS_CAD_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `TIMESTAMP` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data e hora do cadastro de sugestão.
```

---

### `CD_EST_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_EST_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(1)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Estados que podem ocorrer: 
1=ATIVO, 
2=INATIVO, 
3=IMUTAVEL
```

---

### `CD_USU_RSP_CAD_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_USU_RSP_CAD_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(8 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
CONCEITO: Código da pessoa autorizada ao uso de recursos computacionais.
EXEMPLOS: C1234567, F8901234

Identificador (matrícula) do usuário responsável pelo cadastro da sugestão.
```

---

## 6.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `TX_REG_EXNO_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_REG_EXNO_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(100 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: será preenchido apenas se a sugestão cadastrada estiver vinculada a algum produto do banco. O cadastro é feito ativamente pelo usuário. |

Comentário do DDL Oracle:

```text
Identificador externo da sugestão, quando existir.


Regra de nulidade: será preenchido apenas se a sugestão cadastrada estiver vinculada a algum produto do banco. O cadastro é feito ativamente pelo usuário.
```

---

### `TX_TRM_OBG_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_TRM_OBG_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial utilize termos obrigatórios. |

Comentário do DDL Oracle:

```text
Conjunto de termos/expressões obrigatórias.
Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).

Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial utilize termos obrigatórios.
```

---

### `TX_TRM_N_PMT_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_TRM_N_PMT_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial não utilize algum conjunto de termos/expressões. |

Comentário do DDL Oracle:

```text
Conjunto de termos/expressões não permitadas. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).

Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial não utilize algum conjunto de termos/expressões.
```

---

## 6.7 DDL estrutural da tabela

```sql
CREATE TABLE SGT_CADD
(
	NR_IDFR_SGT          NUMBER(11)  GENERATED ALWAYS 
	AS IDENTITY ( 
		START WITH 1
		INCREMENT BY 1
		NOCYCLE 
		CACHE 50)  NOT NULL ,
	TX_REG_EXNO_SGT      VARCHAR2(100 CHAR)  NULL ,
	NM_SGT_PDRO          VARCHAR2(500 CHAR)  NOT NULL ,
	TX_DCR_DETD_SGT      CLOB CHAR  NOT NULL ,
	TX_BNF_RCNL_SGT      CLOB CHAR  NOT NULL ,
	TX_BNF_EMOC_SGT      CLOB CHAR  NOT NULL ,
	TX_TRM_OBG_SGT       CLOB CHAR  NULL ,
	TX_TRM_N_PMT_SGT     CLOB CHAR  NULL ,
	TS_CAD_SGT           TIMESTAMP  NOT NULL ,
	CD_EST_SGT           NUMBER(1)  NOT NULL ,
	CD_USU_RSP_CAD_SGT   VARCHAR2(8 CHAR)  NOT NULL ,
 PRIMARY KEY (NR_IDFR_SGT)
);
```

---

<a id="tnd_cgtv_tcn"></a>

# 7. Tabela `TND_CGTV_TCN`

## 7.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `TND_CGTV_TCN` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_TND` |
| **Quantidade de campos** | 5 |
| **Quantidade de campos com `NULL`** | 1 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 7.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
Tabela que armazena tendências de raciocínio utilizadas para organizar e concluir conteúdos de forma clara e coerente. Essas tendências orientam como a mensagem deve evoluir, por exemplo, como encerrar um texto, reforçar um benefício ou conduzir o leitor a uma ação. O cadastro é utilizado exclusivamente para fins técnicos, apoiando o processamento e a geração de conteúdos pelo sistema.
Conceito de Tendência cognitiva é um padrão de pensamento que orienta como uma mensagem deve ser construída para fazer sentido, gerar entendimento e levar a uma conclusão natural. Ela define a forma como as ideias se conectam, como um benefício é reforçado ou como o conteúdo é encerrado, ajudando a tornar a comunicação mais clara, coerente e persuasiva.
 
 
Exemplo:
Nome  da Tendencia Padrão: Congruência Final
 
Texto da Função Operacional da tendencia:
 Intenção: fechar com coerência e sensação de conclusão.
 Função: retomar o benefício e terminar com ação lógica.
 
Texto da Descrição Detalhada da tendencia: Retome o benefício inicial no final, mantenha tom e termos consistentes e avance sempre por causa e efeito. Destaque a prova principal, evite ideias novas, integre benefício, prova e ação e finalize com a chamada para ação como conclusão lógica.Palavras-chaves: coerência, fechamento, retomada, causa-e-efeito, prova, conclusão, CTA
 
Atributo Texto da Recuperação Padrão da tendencia é NULL.Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica da tendencia.
 
```

**#PK declarada no DDL:** `NR_IDFR_TND`

## 7.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 7.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_TND` | `NUMBER(11)` | `Sim` | `Não (0%)` | identidade |
| 2 | `NM_TND_PDRO` | `VARCHAR2(500 CHAR)` | `Não` | `Não (0%)` | — |
| 3 | `TX_DCR_DETD_TND` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 4 | `TX_FUC_OPRL_TND` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 5 | `TX_RCPO_PDRO_TND` | `CLOB CHAR` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |

## 7.5 Campos obrigatórios

### `NR_IDFR_TND`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_TND` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Geração automática | `Sim` — `GENERATED ALWAYS AS IDENTITY` |

Comentário do DDL Oracle:

```text
Identificador único do registro da tendência cognitiva.
```

---

### `NM_TND_PDRO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_TND_PDRO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(500 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome técnico da tendência cognitiva para identificação e referência no pipeline.
```

---

### `TX_DCR_DETD_TND`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DCR_DETD_TND` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto que explica a função da tendência dentro do pipeline de IA.Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_FUC_OPRL_TND`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_FUC_OPRL_TND` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição conceitual detalhada da tendência cognitiva utilizado no pipeline de IA.Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

## 7.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `TX_RCPO_PDRO_TND`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_RCPO_PDRO_TND` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto |

Comentário do DDL Oracle:

```text
Texto auxiliar para recuperar o contexto da tendencia cognitiva. Serve como referência para a IA interpretar e gerar conteúdos quando esse recurso estiver disponível no agente.



Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto
```

---

## 7.7 DDL estrutural da tabela

```sql
CREATE TABLE TND_CGTV_TCN
(
	NR_IDFR_TND          NUMBER(11)  GENERATED ALWAYS 
	AS IDENTITY ( 
		START WITH 1
		INCREMENT BY 1
		NOCYCLE 
		CACHE 50)  NOT NULL ,
	NM_TND_PDRO          VARCHAR2(500 CHAR)  NOT NULL ,
	TX_DCR_DETD_TND      CLOB CHAR  NOT NULL ,
	TX_FUC_OPRL_TND      CLOB CHAR  NOT NULL ,
	TX_RCPO_PDRO_TND     CLOB CHAR  NULL ,
 PRIMARY KEY (NR_IDFR_TND)
);
```

---

<a id="cnr_tcn"></a>

# 8. Tabela `CNR_TCN`

## 8.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `CNR_TCN` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_CNR` |
| **Quantidade de campos** | 5 |
| **Quantidade de campos com `NULL`** | 1 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 8.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
Tabela que armazena cenários usados durante o processamento e a geração de conteúdos. Guarda textos organizados que descrevem cenários já resolvidos e que podem ser reutilizados, incluindo sua função, uma breve descrição e o texto utilizado para recuperação.
Conceito de cenário: De forma geral, cenário é uma situação simulada ou narrativa que descreve: um contexto, um público, um problema ou necessidade
e uma evolução esperada de comportamento. 
Ele é usado para facilitar o entendimento, ajudar na tomada de decisão ou demonstrar como algo funciona na prática. Em marketing, vendas, comunicação ou UX, o cenário ajuda a mostrar como o cliente pensa e age ao longo de uma jornada.
 
Exemplo:
Nome do Cenario padrão:AIDA
Texto da Função Operacional do cenario: Intenção: guiar o leitor até a ação. Função: prender atenção ? manter interesse ? criar desejo ? pedir a ação.
 
Texto de Descrição detalhada do cenario:
 Estruture o texto em quatro etapas contínuas: Atenção, Interesse, Desejo e Ação. 

Comece capturando a Atenção com uma frase clara que interrompa o padrão de leitura e destaque um ponto relevante ou inesperado. Em seguida, desenvolva o Interesse aprofundando a relevância prática do tema e validando o problema. Avance para o Desejo apresentando o benefício central de forma concreta e tangível. Finalize com a Ação, conduzindo o leitor ao próximo passo como consequência lógica do raciocínio construído, com uma chamada clara e sem imposição.
Palavras-chaves: atenção, interesse, desejo, ação, funil, conversão, CTA.
 
Texto de Recuperação padrão do cenário: 
Intenção: guiar a ação. Função: prender atenção ? manter interesse ? criar desejo ? pedir a ação.
Estruture o texto em quatro etapas contínuas: Atenção, Interesse, Desejo e Ação. Comece capturando a Atenção com uma frase clara que interrompa o padrão de leitura e destaque um ponto relevante ou inesperado. Em seguida, desenvolva o Interesse aprofundando a relevância prática do tema e validando o problema. Avance para o Desejo apresentando o benefício central de forma concreta e tangível. Finalize com a Ação, conduzindo o leitor ao próximo passo como consequência lógica do raciocínio construído, com uma chamada clara e sem imposição.
Palavras-chaves: atenção, interesse, desejo, ação, funil, conversão, CTA
 
 
OBS.: Texto de Recuperação padrão do cenário, esse campo precisa ser NULL mesmo.

Definição do atributo: Texto auxiliar para armazenação do contexto do cenário recuperado dentro da API.
Serve como referência para a interpretação e geração conteúdos quando esse recurso estiver disponível.
 
Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto.
```

**#PK declarada no DDL:** `NR_IDFR_CNR`

## 8.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 8.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_CNR` | `NUMBER(11)` | `Sim` | `Não (0%)` | identidade |
| 2 | `NM_CNR_PDRO` | `VARCHAR2(500 CHAR)` | `Não` | `Não (0%)` | — |
| 3 | `TX_FUC_OPRL_CNR` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 4 | `TX_DCR_DETD_CNR` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 5 | `TX_RCPO_PDRO_CNR` | `CLOB CHAR` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |

## 8.5 Campos obrigatórios

### `NR_IDFR_CNR`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_CNR` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Geração automática | `Sim` — `GENERATED ALWAYS AS IDENTITY` |

Comentário do DDL Oracle:

```text
Código numérico único que identifica o cenário.
```

---

### `NM_CNR_PDRO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_CNR_PDRO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(500 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome tecnico utilizado para identificar o cenario no pipeline.
```

---

### `TX_FUC_OPRL_CNR`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_FUC_OPRL_CNR` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto que descreve a funcao do cenario no pipeline de IA. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_DCR_DETD_CNR`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DCR_DETD_CNR` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição conceitual detalhada do cenario utilizado no pipeline de IA. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

## 8.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `TX_RCPO_PDRO_CNR`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_RCPO_PDRO_CNR` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto |

Comentário do DDL Oracle:

```text
Texto auxiliar para recuperar o contexto do cenário.
Serve como referência para a IA interpretar e gerar conteúdos quando esse recurso estiver disponível no agente.




Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto
```

---

## 8.7 DDL estrutural da tabela

```sql
CREATE TABLE CNR_TCN
(
	NR_IDFR_CNR          NUMBER(11)  GENERATED ALWAYS 
	AS IDENTITY ( 
		START WITH 1
		INCREMENT BY 1
		NOCYCLE 
		CACHE 50)  NOT NULL ,
	NM_CNR_PDRO          VARCHAR2(500 CHAR)  NOT NULL ,
	TX_FUC_OPRL_CNR      CLOB CHAR  NOT NULL ,
	TX_DCR_DETD_CNR      CLOB CHAR  NOT NULL ,
	TX_RCPO_PDRO_CNR     CLOB CHAR  NULL ,
 PRIMARY KEY (NR_IDFR_CNR)
);
```

---

<a id="apsc_tcn"></a>

# 9. Tabela `APSC_TCN`

## 9.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `APSC_TCN` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_APSC` |
| **Quantidade de campos** | 5 |
| **Quantidade de campos com `NULL`** | 1 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 9.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
 Tabela que armazena apresentações utilizadas para  o processamento e a geração de conteúdos. Contém textos organizados que representam conteúdos já prontos e que podem ser reutilizados, incluindo a finalidade da apresentação, uma descrição e o conteúdo usado para recuperação.
Conceito de Apresentação é: um modelo de conteúdo estruturado que orienta como uma mensagem deve ser construída para comunicar uma ideia de forma clara e objetiva. Ela define o objetivo da mensagem, descreve como os elementos principais devem se relacionar (como público, problema, solução e resultado) e fornece um texto base reutilizável, que pode ser adaptado conforme o contexto. A apresentação serve como referência para garantir consistência, clareza e alinhamento na comunicação.
 
Exemplo:
 
Nome da apresentação padrão: Estratégica
 
Texto da função operacional da apresentação: Intenção: deixar claro “por que vale a pena”.Função: juntar público, problema, solução e resultado.
 
Texto da descrição detalhada da apresentação: Para {pub_desc}, que enfrenta {pub_func} e busca {pub_emoc}, {prod_desc} entrega {prod_func} e gera {prod_emoc}, apoiando {pub_emoc}. Palavras-chaves valor, clareza, alinhamento, impacto, narrativa
 
Texto da Recuperação Padrão da apresentação:
Estratégica
Intenção: deixar claro “por que vale a pena”.Função: juntar público, problema, solução e resultado.Para {pub_desc}, que enfrenta {pub_func} e busca {pub_emoc}, {prod_desc} entrega {prod_func} e gera {prod_emoc}, apoiando {pub_emoc}. Palavras-chaves valor, clareza, alinhamento, impacto, narrativa, descritivo.                                                                   OBS.

 Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto da apresentação.
 
```

**#PK declarada no DDL:** `NR_IDFR_APSC`

## 9.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 9.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_APSC` | `NUMBER(11)` | `Sim` | `Não (0%)` | identidade |
| 2 | `NM_APSC_PDRO` | `VARCHAR2(500 CHAR)` | `Não` | `Não (0%)` | — |
| 3 | `TX_FUC_OPRL_APSC` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 4 | `TX_DCR_DETD_APSC` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 5 | `TX_RCPO_PDRO_APSC` | `CLOB CHAR` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |

## 9.5 Campos obrigatórios

### `NR_IDFR_APSC`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_APSC` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Geração automática | `Sim` — `GENERATED ALWAYS AS IDENTITY` |

Comentário do DDL Oracle:

```text
Identificador numérico único da apresentação.
```

---

### `NM_APSC_PDRO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_APSC_PDRO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(500 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome técnico da apresentação usado para referência e identificação no pipeline.
```

---

### `TX_FUC_OPRL_APSC`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_FUC_OPRL_APSC` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto explicando a função da apresentação no pipeline de IA. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

### `TX_DCR_DETD_APSC`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DCR_DETD_APSC` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição conceitual detalhada da apresentação utilizado no pipeline de IA. Utilizado como referência para processamento, interpretação e geração de conteúdos pela inteligência artificial (IA).
```

---

## 9.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `TX_RCPO_PDRO_APSC`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_RCPO_PDRO_APSC` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto |

Comentário do DDL Oracle:

```text
Texto auxiliar para recuperar o contexto da apresentação. Serve como referência para a IA interpretar e gerar conteúdos quando esse recurso estiver disponível no agente.


Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto
```

---

## 9.7 DDL estrutural da tabela

```sql
CREATE TABLE APSC_TCN
(
	NR_IDFR_APSC         NUMBER(11)  GENERATED ALWAYS 
	AS IDENTITY ( 
		START WITH 1
		INCREMENT BY 1
		NOCYCLE 
		CACHE 10)  NOT NULL ,
	NM_APSC_PDRO         VARCHAR2(500 CHAR)  NOT NULL ,
	TX_FUC_OPRL_APSC     CLOB CHAR  NOT NULL ,
	TX_DCR_DETD_APSC     CLOB CHAR  NOT NULL ,
	TX_RCPO_PDRO_APSC    CLOB CHAR  NULL ,
 PRIMARY KEY (NR_IDFR_APSC)
);
```

---

<a id="avs_seld"></a>

# 10. Tabela `AVS_SELD`

## 10.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `AVS_SELD` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_PBCO`, `NR_IDFR_SGT`, `NR_AVS_SELD` |
| **Quantidade de campos** | 14 |
| **Quantidade de campos com `NULL`** | 0 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 10.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
************************************
Tratamento de Exceção - SSA 2026000581
Utilização de JSON
************************************

Tabela que armazena os avisos escolhidos pelo usuário da aplicação. Ele armazena informações que identificam de onde o aviso veio, a qual sugestão e público ele está relacionado e como o conteúdo foi montado pela aplicação. Também registra os textos finais que serão exibidos (como título, subtítulo e chamada para ação), além de salvar todo o conteúdo completo da criação em um formato estruturado (JSON), para fins de controle e rastreabilidade.
 
Exemplo:
Numero identificador do Publico:1
Numero identificador da Sugestão:1
Numero identificador do Aviso:1
Codigo Externo da Geração:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
Código Externo do Aviso:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
Numero Identificador da Apresentação:1
Numero Identificador do Cenario:1
Numero Identificador da Tendencia:1
Texto do Titulo padrão do aviso: Aumente seu limite
Texto do subtítulo padrão do aviso:Ajuste seu crédito de forma prática, segura e sem burocracia.
Texto do acionamento padrão do aviso:Avançar - <<<{PH_TEXTO_CTA}>>>
Json do aviso padrão:[TAREFA]Gerar uma CTA mínima e coerente como continuidade natural do texto.[COPYWRITING]
<<<{PH_BASE_BB}>>>[HEADLINE]<<<{PH_TITULO}>>>[TAGLINE]<<<{PH_TEXTO}>>>[FORMATO DE SAÍDA].
```

**#PK declarada no DDL:** `NR_IDFR_PBCO`, `NR_IDFR_SGT`, `NR_AVS_SELD`

## 10.3 Relacionamentos declarados

| Coluna(s) local(is) | Tabela referenciada | Coluna(s) referenciada(s) |
| --- | --- | --- |
| `NR_IDFR_PBCO` | `PBCO_CADD` | `NR_IDFR_PBCO` |
| `NR_IDFR_TND` | `TND_CGTV_TCN` | `NR_IDFR_TND` |
| `NR_IDFR_CNR` | `CNR_TCN` | `NR_IDFR_CNR` |
| `NR_IDFR_APSC` | `APSC_TCN` | `NR_IDFR_APSC` |
| `NR_IDFR_SGT` | `SGT_CADD` | `NR_IDFR_SGT` |

## 10.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_AVS_SELD` | `NUMBER(11)` | `Sim` | `Não (0%)` | — |
| 2 | `NR_IDFR_PBCO` | `NUMBER(11)` | `Sim` | `Não (0%)` | FK |
| 3 | `NR_IDFR_SGT` | `NUMBER(11)` | `Sim` | `Não (0%)` | FK |
| 4 | `CD_EXNO_CRIC` | `VARCHAR2(36 CHAR)` | `Não` | `Não (0%)` | — |
| 5 | `CD_EXNO_AVS` | `VARCHAR2(36 CHAR)` | `Não` | `Não (0%)` | — |
| 6 | `TX_TIT_PDRO_AVS` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 7 | `TX_STIT_PDRO_AVS` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 8 | `TX_ACMT_PDRO_AVS` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 9 | `JS_AVS_PDRO` | `CLOB CHAR` | `Não` | `Não (0%)` | CHECK IS JSON |
| 10 | `TS_CAD_AVS` | `TIMESTAMP` | `Não` | `Não (0%)` | — |
| 11 | `CD_USU_RSP_CAD` | `VARCHAR2(8 CHAR)` | `Não` | `Não (0%)` | — |
| 12 | `NR_IDFR_APSC` | `NUMBER(11)` | `Não` | `Não (0%)` | FK |
| 13 | `NR_IDFR_CNR` | `NUMBER(11)` | `Não` | `Não (0%)` | FK |
| 14 | `NR_IDFR_TND` | `NUMBER(11)` | `Não` | `Não (0%)` | FK |

## 10.5 Campos obrigatórios

### `NR_AVS_SELD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_AVS_SELD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Identificador numérico único do registro de aviso selecionado.
```

---

### `NR_IDFR_PBCO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_PBCO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Foreign Key | `NR_IDFR_PBCO` → `PBCO_CADD` (`NR_IDFR_PBCO`) |

Comentário do DDL Oracle:

```text
Identificador numérico único do cadastro de público.
```

---

### `NR_IDFR_SGT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_SGT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Foreign Key | `NR_IDFR_SGT` → `SGT_CADD` (`NR_IDFR_SGT`) |

Comentário do DDL Oracle:

```text
Indentificador numérico único do cadastro de sugestão.
```

---

### `CD_EXNO_CRIC`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_EXNO_CRIC` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(36 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Identificador externo, no formato UUID, da geração. Código utilizando o padrão UUID: 0196ee29-aa59-75f9-84d8-31ef01ddfc65
```

---

### `CD_EXNO_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_EXNO_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(36 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Identificador externo, no formato UUID, que representa um aviso específico associado à geração. Código utilizando o padrão UUID: 0196ee29-aa59-75f9-84d8-31ef01ddfc65
```

---

### `TX_TIT_PDRO_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_TIT_PDRO_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto final do título do aviso criado pela inteligencia artificial (IA).
```

---

### `TX_STIT_PDRO_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_STIT_PDRO_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto final do do aviso criado pela inteligencia artificial (IA).
```

---

### `TX_ACMT_PDRO_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_ACMT_PDRO_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto final do CTA criado pela inteligencia artificial (IA).
```

---

### `JS_AVS_PDRO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `JS_AVS_PDRO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Restrição JSON | `CHECK (JS_AVS_PDRO IS JSON)` |

Comentário do DDL Oracle:

```text
************************************
Tratamento de Exceção - SSA 2026000581
Utilização de JSON
************************************


Payload completo do aviso em formato JSON. 
```

---

### `TS_CAD_AVS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TS_CAD_AVS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `TIMESTAMP` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data e hora em que o aviso foi selecionado.
```

---

### `CD_USU_RSP_CAD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_USU_RSP_CAD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(8 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
CONCEITO: Código da pessoa autorizada ao uso de recursos computacionais.
EXEMPLOS: C1234567, F8901234

Matricula do usuário responsável por selecionar a mensagem.
```

---

### `NR_IDFR_APSC`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_APSC` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Foreign Key | `NR_IDFR_APSC` → `APSC_TCN` (`NR_IDFR_APSC`) |

Comentário do DDL Oracle:

```text
Identificador numérico único da apresentação.
```

---

### `NR_IDFR_CNR`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_CNR` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Foreign Key | `NR_IDFR_CNR` → `CNR_TCN` (`NR_IDFR_CNR`) |

Comentário do DDL Oracle:

```text
Código numérico único que identifica o cenário.
```

---

### `NR_IDFR_TND`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_TND` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Foreign Key | `NR_IDFR_TND` → `TND_CGTV_TCN` (`NR_IDFR_TND`) |

Comentário do DDL Oracle:

```text
Identificador único do registro da tendência cognitiva.
```

---

## 10.6 Campos com nulidade permitida pelo DDL

Não há campos `NULL` declarados no DDL Oracle para esta tabela.

## 10.7 DDL estrutural da tabela

```sql
CREATE TABLE AVS_SELD
(
	NR_AVS_SELD          NUMBER(11)  NOT NULL ,
	NR_IDFR_PBCO         NUMBER(11)  NOT NULL ,
	NR_IDFR_SGT          NUMBER(11)  NOT NULL ,
	CD_EXNO_CRIC         VARCHAR2(36 CHAR)  NOT NULL ,
	CD_EXNO_AVS          VARCHAR2(36 CHAR)  NOT NULL ,
	TX_TIT_PDRO_AVS      CLOB CHAR  NOT NULL ,
	TX_STIT_PDRO_AVS     CLOB CHAR  NOT NULL ,
	TX_ACMT_PDRO_AVS     CLOB CHAR  NOT NULL ,
	JS_AVS_PDRO          CLOB CHAR  NOT NULL  CHECK (JS_AVS_PDRO IS JSON),
	TS_CAD_AVS           TIMESTAMP  NOT NULL ,
	CD_USU_RSP_CAD       VARCHAR2(8 CHAR)  NOT NULL ,
	NR_IDFR_APSC         NUMBER(11)  NOT NULL ,
	NR_IDFR_CNR          NUMBER(11)  NOT NULL ,
	NR_IDFR_TND          NUMBER(11)  NOT NULL ,
 PRIMARY KEY (NR_IDFR_PBCO,NR_IDFR_SGT,NR_AVS_SELD),
FOREIGN KEY (NR_IDFR_PBCO) REFERENCES PBCO_CADD (NR_IDFR_PBCO),
FOREIGN KEY (NR_IDFR_TND) REFERENCES TND_CGTV_TCN (NR_IDFR_TND),
FOREIGN KEY (NR_IDFR_CNR) REFERENCES CNR_TCN (NR_IDFR_CNR),
FOREIGN KEY (NR_IDFR_APSC) REFERENCES APSC_TCN (NR_IDFR_APSC),
FOREIGN KEY (NR_IDFR_SGT) REFERENCES SGT_CADD (NR_IDFR_SGT)
);
```

---

<a id="proj_cadd"></a>

# 11. Tabela `PROJ_CADD`

## 11.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `PROJ_CADD` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_PROJ` |
| **Quantidade de campos** | 6 |
| **Quantidade de campos com `NULL`** | 0 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 11.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
Cadastro negocial do projeto onde as recomendações são criadas, contendo identificação e descrição. 
Mantém também estado do cadastro e informações de criação.
```

**#PK declarada no DDL:** `NR_IDFR_PROJ`

## 11.3 Relacionamentos declarados

Não há `FOREIGN KEY` declarada no DDL Oracle para esta tabela.

## 11.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_PROJ` | `NUMBER(11)` | `Sim` | `Não (0%)` | identidade |
| 2 | `NM_PROJ_CMT` | `VARCHAR2(500 CHAR)` | `Não` | `Não (0%)` | — |
| 3 | `TX_DCR_DETD` | `VARCHAR2(750 CHAR)` | `Não` | `Não (0%)` | — |
| 4 | `TS_CAD` | `TIMESTAMP` | `Não` | `Não (0%)` | — |
| 5 | `CD_EST_PROJ` | `NUMBER(1)` | `Não` | `Não (0%)` | — |
| 6 | `CD_USU_RSP_CAD_PROJ` | `VARCHAR2(8 CHAR)` | `Não` | `Não (0%)` | — |

## 11.5 Campos obrigatórios

### `NR_IDFR_PROJ`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_PROJ` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Geração automática | `Sim` — `GENERATED ALWAYS AS IDENTITY` |

Comentário do DDL Oracle:

```text
Identificador numérico único do cadastro do projeto.
```

---

### `NM_PROJ_CMT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_PROJ_CMT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(500 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome pelo qual o projeto é identificado.
```

---

### `TX_DCR_DETD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DCR_DETD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(750 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição textual do projeto.
```

---

### `TS_CAD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TS_CAD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `TIMESTAMP` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data e hora de criação do registro do projeto.
```

---

### `CD_EST_PROJ`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_EST_PROJ` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(1)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Código que representa o estado do projeto.
Exemplo: 1 - Ativo; 2 - Inativo ; 3 - Arquivado
```

---

### `CD_USU_RSP_CAD_PROJ`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_USU_RSP_CAD_PROJ` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(8 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
CONCEITO: Código da pessoa autorizada ao uso de recursos computacionais.
EXEMPLOS: C1234567, F8901234

Identificador (matrícula) do usuário responsável pelo cadastro dp Projeto.
Exemplo "F000000"
```

---

## 11.6 Campos com nulidade permitida pelo DDL

Não há campos `NULL` declarados no DDL Oracle para esta tabela.

## 11.7 DDL estrutural da tabela

```sql
CREATE TABLE PROJ_CADD
(
	NR_IDFR_PROJ         NUMBER(11)  GENERATED ALWAYS 
	AS IDENTITY ( 
		START WITH 1
		INCREMENT BY 1
		NOCYCLE 
		CACHE 50)  NOT NULL ,
	NM_PROJ_CMT          VARCHAR2(500 CHAR)  NOT NULL ,
	TX_DCR_DETD          VARCHAR2(750 CHAR)  NOT NULL ,
	TS_CAD               TIMESTAMP  NOT NULL ,
	CD_EST_PROJ          NUMBER(1)  NOT NULL ,
	CD_USU_RSP_CAD_PROJ  VARCHAR2(8 CHAR)  NOT NULL ,
 PRIMARY KEY (NR_IDFR_PROJ)
);
```

---

<a id="rcm_vldd"></a>

# 12. Tabela `RCM_VLDD`

## 12.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `RCM_VLDD` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_RCM`, `NR_IDFR_PROJ` |
| **Quantidade de campos** | 9 |
| **Quantidade de campos com `NULL`** | 0 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 12.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
Tabela que registra as recomendações validadas feitas  ao longo do tempo . Cada registro representa uma recomendação específica, informando seu período de validade, sua situação atual (por exemplo, ativa ou encerrada) e, quando houver, a versão que foi aprovada. Essa recomendação é o ponto central de controle, a partir do qual são acompanhadas todas as versões e alterações realizadas.
 
Exemplo:
Nome da Recomendação Padrão: CDC
Código do Estado da recomendação: 3
Texto Descrição Detalhada: Recomendação que focará em  Utilizar limite especial e pagar menos juros.Parcelas fixas. Juros menores.
Numero valido da versão:1
Numero da Priorização Selecionada:1
```

**#PK declarada no DDL:** `NR_IDFR_RCM`, `NR_IDFR_PROJ`

## 12.3 Relacionamentos declarados

| Coluna(s) local(is) | Tabela referenciada | Coluna(s) referenciada(s) |
| --- | --- | --- |
| `NR_IDFR_PROJ` | `PROJ_CADD` | `NR_IDFR_PROJ` |

## 12.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_RCM` | `NUMBER(11)` | `Sim` | `Não (0%)` | — |
| 2 | `NR_IDFR_PROJ` | `NUMBER(11)` | `Sim` | `Não (0%)` | FK |
| 3 | `NR_VLDO_VRS` | `NUMBER(3)` | `Não` | `Não (0%)` | — |
| 4 | `NR_VRS_PRPT` | `NUMBER(3)` | `Não` | `Não (0%)` | — |
| 5 | `NR_PRI_SELD` | `NUMBER(3)` | `Não` | `Não (0%)` | — |
| 6 | `TS_ULT_ATL` | `TIMESTAMP` | `Não` | `Não (0%)` | — |
| 7 | `NM_RCM_PDRO` | `VARCHAR2(500 CHAR)` | `Não` | `Não (0%)` | — |
| 8 | `TX_DCR_DETD` | `VARCHAR2(750 CHAR)` | `Não` | `Não (0%)` | — |
| 9 | `CD_EST_RCM` | `NUMBER(1)` | `Não` | `Não (0%)` | — |

## 12.5 Campos obrigatórios

### `NR_IDFR_RCM`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_RCM` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Identificador numérico único da recomendação
```

---

### `NR_IDFR_PROJ`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_PROJ` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Foreign Key | `NR_IDFR_PROJ` → `PROJ_CADD` (`NR_IDFR_PROJ`) |

Comentário do DDL Oracle:

```text
Identificador do projeto associado.
```

---

### `NR_VLDO_VRS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_VLDO_VRS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(3)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Número da versão aprovada (referência). 

“Número da versão aprovada.
 Domínio: 
> 0 = número de versão aprovada válida.”
```

---

### `NR_VRS_PRPT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_VRS_PRPT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(3)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Número da versão proposta (pendente). 

“Número da versão proposta.
 Domínio: 
> 0 = número de versão proposta válida.”
```

---

### `NR_PRI_SELD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_PRI_SELD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(3)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Define a ordem de exibição das recomendações onde números menores representam maior prioridade. Permite organizar quais recomendações são priorizadas na exibição.
```

---

### `TS_ULT_ATL`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TS_ULT_ATL` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `TIMESTAMP` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data e hora da ultima atualização
```

---

### `NM_RCM_PDRO`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NM_RCM_PDRO` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(500 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Nome da recomendação
```

---

### `TX_DCR_DETD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DCR_DETD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(750 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição da recomendação
```

---

### `CD_EST_RCM`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_EST_RCM` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(1)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Identifica o estado da recomendação.
1 = EM_PREPARACAO
2 = AGUARDANDO_VIGENCIA
3 = VIGENTE
4 = EXPIRADA
5 = FINALIZADA
```

---

## 12.6 Campos com nulidade permitida pelo DDL

Não há campos `NULL` declarados no DDL Oracle para esta tabela.

## 12.7 DDL estrutural da tabela

```sql
CREATE TABLE RCM_VLDD
(
	NR_IDFR_RCM          NUMBER(11)  NOT NULL ,
	NR_IDFR_PROJ         NUMBER(11)  NOT NULL ,
	NR_VLDO_VRS          NUMBER(3)  NOT NULL ,
	NR_VRS_PRPT          NUMBER(3)  NOT NULL ,
	NR_PRI_SELD          NUMBER(3)  NOT NULL ,
	TS_ULT_ATL           TIMESTAMP  NOT NULL ,
	NM_RCM_PDRO          VARCHAR2(500 CHAR)  NOT NULL ,
	TX_DCR_DETD          VARCHAR2(750 CHAR)  NOT NULL ,
	CD_EST_RCM           NUMBER(1)  NOT NULL ,
 PRIMARY KEY (NR_IDFR_RCM,NR_IDFR_PROJ),
FOREIGN KEY (NR_IDFR_PROJ) REFERENCES PROJ_CADD (NR_IDFR_PROJ)
);
```

---

<a id="rcm_vrs"></a>

# 13. Tabela `RCM_VRS`

## 13.1 Identificação da tabela

| Item | Definição |
| --- | --- |
| **Nome físico** | `RCM_VRS` |
| **Tipo de estrutura** | `CREATE TABLE` Oracle |
| **Natureza** | Não informada explicitamente no DDL Oracle. |
| **Formato** | Não informado no DDL Oracle. |
| **Compressão** | Não informado no DDL Oracle. |
| **Localização física** | Não informada no DDL Oracle. |
| **Chave primária declarada** | `NR_IDFR_RCM`, `NR_IDFR_PROJ`, `NR_VRS_PRPT` |
| **Quantidade de campos** | 12 |
| **Quantidade de campos com `NULL`** | 1 |
| **Periodicidade** | Não informada no DDL Oracle. |
| **Classificação de segurança** | Não informada no DDL Oracle. |
| **Origem** | Não informada no DDL Oracle. |
| **Tempo de retenção** | Não informado no DDL Oracle. |
| **LGPD** | Não informada no DDL Oracle. |
| **ModelAI** | Não informado no DDL Oracle. |

## 13.2 Definição da entidade

Comentário da tabela conforme DDL Oracle:

```text
Tabela que registra cada versão de uma recomendação ao longo do seu processo de avaliação. Cada versão mostra em que etapa a recomendação está, desde as análises intermediárias até a decisão final, que pode ser aprovação ou reprovação. Também indica qual aviso foi utilizado na composição do conteúdo daquela versão, permitindo acompanhar o histórico e as mudanças realizadas.
 
Exemplo:
 
Numero da Versão Proposta:1
Numero do Aviso Selecionado:1
Código do Estado da Recomendação da Versão:1
Texto Descrição Detalhada da recomendação:
Data Proposta de Inicio da Recomendação:xx-xx-xxxx
Data Proposta final da Recomendação: xx-xx-xxxx
Texto proposta do Parametro do Header da API:{"detailed":"true","opr":"kodiak", "partnerName":"openbank","serviceName":"jrd-csnt-rcpt","entryPoint":"menu"}
Texto do motivo da Avaliação: Não aprovado, necessidade de criar uma nova versão alterando a composição textual.
 
```

**#PK declarada no DDL:** `NR_IDFR_RCM`, `NR_IDFR_PROJ`, `NR_VRS_PRPT`

## 13.3 Relacionamentos declarados

| Coluna(s) local(is) | Tabela referenciada | Coluna(s) referenciada(s) |
| --- | --- | --- |
| `NR_IDFR_RCM`, `NR_IDFR_PROJ` | `RCM_VLDD` | `NR_IDFR_RCM`, `NR_IDFR_PROJ` |

## 13.4 Resumo dos campos

| Ordem | Campo | Tipo Oracle | Chave primária | Aceita nulo | Observação declarada |
| ---: | --- | --- | --- | --- | --- |
| 1 | `NR_IDFR_RCM` | `NUMBER(11)` | `Sim` | `Não (0%)` | FK |
| 2 | `NR_VRS_PRPT` | `NUMBER(3)` | `Sim` | `Não (0%)` | — |
| 3 | `NR_AVS_SELD` | `NUMBER(11)` | `Não` | `Não (0%)` | — |
| 4 | `TX_DCR_DETD` | `VARCHAR2(750 CHAR)` | `Não` | `Não (0%)` | — |
| 5 | `DT_PRPT_INC_RCM` | `DATE` | `Não` | `Não (0%)` | — |
| 6 | `DT_PRPT_FIM_RCM` | `DATE` | `Não` | `Não (0%)` | — |
| 7 | `TX_PRPT_PRM_HDR_API` | `CLOB CHAR` | `Não` | `Não (0%)` | — |
| 8 | `TX_MTV_AVLC` | `VARCHAR2(1000 CHAR)` | `Não` | `Sim (percentual não informado no DDL Oracle)` | — |
| 9 | `TS_ULT_ALT` | `TIMESTAMP` | `Não` | `Não (0%)` | — |
| 10 | `NR_IDFR_PROJ` | `NUMBER(11)` | `Sim` | `Não (0%)` | FK |
| 11 | `CD_USU_RSP_CAD` | `VARCHAR2(8 CHAR)` | `Não` | `Não (0%)` | — |
| 12 | `CD_EST_RCM_VRS` | `NUMBER(1)` | `Não` | `Não (0%)` | — |

## 13.5 Campos obrigatórios

### `NR_IDFR_RCM`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_RCM` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Foreign Key | `NR_IDFR_RCM, NR_IDFR_PROJ` → `RCM_VLDD` (`NR_IDFR_RCM, NR_IDFR_PROJ`) |

Comentário do DDL Oracle:

```text
Identificador numérico único da recomendação
```

---

### `NR_VRS_PRPT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_VRS_PRPT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(3)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Número da versão proposta dentro da recomendação. 
```

---

### `NR_AVS_SELD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_AVS_SELD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Identificador numérico único do registro de aviso selecionado.
```

---

### `TX_DCR_DETD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_DCR_DETD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(750 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Descrição da recomendação
```

---

### `DT_PRPT_INC_RCM`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `DT_PRPT_INC_RCM` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `DATE` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data proposta de inicio da recomendação
```

---

### `DT_PRPT_FIM_RCM`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `DT_PRPT_FIM_RCM` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `DATE` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Data proposta de fim da recomendação
```

---

### `TX_PRPT_PRM_HDR_API`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_PRPT_PRM_HDR_API` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `CLOB CHAR` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Texto de formato variável que contem parâmetros de acionamento da API para reutilização dos insights/alertas. Essa informação atrelada ao cliente e ao UIDD do Insight, será resgatada em outro local para a API ativar o insight correto. 
Os parâmetros irão variar dependendo do tipo de insight/alerta.
O primeiro tipo de insight é direcionado para Limite Especial, que são os clientes que utilizam muito o o ccheque especial
 e o segundo tipo direcionado ao Open Finance, que são os clientes que não possuem consentimento no open finance porém são fortes candidatos e/ou seria interessante para o Banco, que aderissem ao uso do OPF.
Exemplos: 
variação 1: tela/CreditoNovo/listarLinhas 
variação 2: {"detailed":"true","opr":"kodiak", "partnerName":"openbank","serviceName":"jrd-csnt-rcpt","entryPoint":"menu"}
```

---

### `TS_ULT_ALT`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TS_ULT_ALT` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `TIMESTAMP` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Timestamp de CRIAÇÃO/SUBMISSÃO da versão.
```

---

### `NR_IDFR_PROJ`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `NR_IDFR_PROJ` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(11)` |
| Chave primária lógica | `Sim` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Foreign Key | `NR_IDFR_RCM, NR_IDFR_PROJ` → `RCM_VLDD` (`NR_IDFR_RCM, NR_IDFR_PROJ`) |

Comentário do DDL Oracle:

```text
Identificador do projeto associado.
```

---

### `CD_USU_RSP_CAD`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_USU_RSP_CAD` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(8 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
CONCEITO: Código da pessoa autorizada ao uso de recursos computacionais.
EXEMPLOS: C1234567, F8901234

Usuário responsável por CRIAR/SUBMETER a versão.
```

---

### `CD_EST_RCM_VRS`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `CD_EST_RCM_VRS` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `NUMBER(1)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Não (0%)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |

Comentário do DDL Oracle:

```text
Estado da versão: 
1=AGUARDANDO_APROVACAO, 
2=APROVADO, 
3=REPROVADO.
```

---

## 13.6 Campos com nulidade permitida pelo DDL

> A nulidade foi extraída do próprio DDL Oracle (`NULL`). O percentual de nulo aceitável não foi informado na fonte.

### `TX_MTV_AVLC`

| Propriedade | Valor |
| --- | --- |
| Nome físico | `TX_MTV_AVLC` |
| Nome lógico | Não informado explicitamente no DDL Oracle. |
| Tipo Oracle | `VARCHAR2(1000 CHAR)` |
| Chave primária lógica | `Não` |
| Aceita nulo | `Sim (percentual não informado no DDL Oracle)` |
| Unique individual | Não informado explicitamente no DDL Oracle. |
| Regra de nulidade declarada | Regra de nulidade: Será preenchido apenas se o avaliador desejar informar o motivo. |

Comentário do DDL Oracle:

```text
Motivo da aprovação ou da reprovação.



Regra de nulidade: Será preenchido apenas se o avaliador desejar informar o motivo.
```

---

## 13.7 DDL estrutural da tabela

```sql
CREATE TABLE RCM_VRS
(
	NR_IDFR_RCM          NUMBER(11)  NOT NULL ,
	NR_VRS_PRPT          NUMBER(3)  NOT NULL ,
	NR_AVS_SELD          NUMBER(11)  NOT NULL ,
	TX_DCR_DETD          VARCHAR2(750 CHAR)  NOT NULL ,
	DT_PRPT_INC_RCM      DATE  NOT NULL ,
	DT_PRPT_FIM_RCM      DATE  NOT NULL ,
	TX_PRPT_PRM_HDR_API  CLOB CHAR  NOT NULL ,
	TX_MTV_AVLC          VARCHAR2(1000 CHAR)  NULL ,
	TS_ULT_ALT           TIMESTAMP  NOT NULL ,
	NR_IDFR_PROJ         NUMBER(11)  NOT NULL ,
	CD_USU_RSP_CAD       VARCHAR2(8 CHAR)  NOT NULL ,
	CD_EST_RCM_VRS       NUMBER(1)  NOT NULL ,
 PRIMARY KEY (NR_IDFR_RCM,NR_IDFR_PROJ,NR_VRS_PRPT),
FOREIGN KEY (NR_IDFR_RCM, NR_IDFR_PROJ) REFERENCES RCM_VLDD (NR_IDFR_RCM, NR_IDFR_PROJ)
);
```

---

<a id="resumo-visual-das-tabelas"></a>

# Resumo visual das tabelas

| Tabela | Campos | Chave primária declarada | Campos `NULL` | Foreign Keys |
| --- | ---: | --- | ---: | ---: |
| `AVS_FNC_CLI` | 7 | `CD_CLI_AVS`, `CD_IDFR_AVS` | 1 | 0 |
| `VSLO_AVS_FNC_CLI` | 5 | `CD_CLI_AVS`, `CD_IDFR_AVS_VSLO` | 1 | 0 |
| `REG_CRIC_IA` | 5 | `NR_IDFR_REG` | 0 | 0 |
| `PMPT_TCN` | 8 | `NR_PMPT_IDFR` | 1 | 0 |
| `PBCO_CADD` | 14 | `NR_IDFR_PBCO` | 3 | 0 |
| `SGT_CADD` | 11 | `NR_IDFR_SGT` | 3 | 0 |
| `TND_CGTV_TCN` | 5 | `NR_IDFR_TND` | 1 | 0 |
| `CNR_TCN` | 5 | `NR_IDFR_CNR` | 1 | 0 |
| `APSC_TCN` | 5 | `NR_IDFR_APSC` | 1 | 0 |
| `AVS_SELD` | 14 | `NR_IDFR_PBCO`, `NR_IDFR_SGT`, `NR_AVS_SELD` | 0 | 5 |
| `PROJ_CADD` | 6 | `NR_IDFR_PROJ` | 0 | 0 |
| `RCM_VLDD` | 9 | `NR_IDFR_RCM`, `NR_IDFR_PROJ` | 0 | 1 |
| `RCM_VRS` | 12 | `NR_IDFR_RCM`, `NR_IDFR_PROJ`, `NR_VRS_PRPT` | 1 | 1 |

---

<a id="resumo-dos-relacionamentos-declarados"></a>

# Resumo dos relacionamentos declarados

| Tabela local | Coluna(s) local(is) | Tabela referenciada | Coluna(s) referenciada(s) |
| --- | --- | --- | --- |
| `AVS_SELD` | `NR_IDFR_PBCO` | `PBCO_CADD` | `NR_IDFR_PBCO` |
| `AVS_SELD` | `NR_IDFR_TND` | `TND_CGTV_TCN` | `NR_IDFR_TND` |
| `AVS_SELD` | `NR_IDFR_CNR` | `CNR_TCN` | `NR_IDFR_CNR` |
| `AVS_SELD` | `NR_IDFR_APSC` | `APSC_TCN` | `NR_IDFR_APSC` |
| `AVS_SELD` | `NR_IDFR_SGT` | `SGT_CADD` | `NR_IDFR_SGT` |
| `RCM_VLDD` | `NR_IDFR_PROJ` | `PROJ_CADD` | `NR_IDFR_PROJ` |
| `RCM_VRS` | `NR_IDFR_RCM`, `NR_IDFR_PROJ` | `RCM_VLDD` | `NR_IDFR_RCM`, `NR_IDFR_PROJ` |

---

<a id="resumo-dos-campos-com-nulidade-permitida"></a>

# Resumo dos campos com nulidade permitida

| Tabela | Campo | Tipo Oracle | Regra de nulidade declarada |
| --- | --- | --- | --- |
| `AVS_FNC_CLI` | `TX_PRM_HDR_API_AVS` | `VARCHAR2(1000 CHAR)` | Regra de nulidade: Será preenchido apenas em alguns alertas não terão uma indicação de parametro do header, como o caso dos alertas apenas textuais. |
| `VSLO_AVS_FNC_CLI` | `DT_ULT_INRO_AVS` | `DATE` | Regra de Nulidade: Será nulo se o cliente ainda não interagiu com o insight. |
| `PMPT_TCN` | `QT_VRV_TTL` | `NUMBER(3)` | Regra de nulidade: só deve ser preenchido quando o prompt técnico incluir alguma variável para checagem técnica. |
| `PBCO_CADD` | `TX_TRM_OBG_PBCO` | `CLOB CHAR` | Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial utilize termos obrigatórios. |
| `PBCO_CADD` | `TX_TRM_N_PMT_PBCO` | `CLOB CHAR` | Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial não utilize algum conjunto de termos/expressões. |
| `PBCO_CADD` | `NM_COL_TAB` | `VARCHAR2(100 CHAR)` | Regra de nulidade: será preenchido apenas se o publico estiver em uma tabela com "multi-publico" |
| `SGT_CADD` | `TX_REG_EXNO_SGT` | `VARCHAR2(100 CHAR)` | Regra de nulidade: será preenchido apenas se a sugestão cadastrada estiver vinculada a algum produto do banco. O cadastro é feito ativamente pelo usuário. |
| `SGT_CADD` | `TX_TRM_OBG_SGT` | `CLOB CHAR` | Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial utilize termos obrigatórios. |
| `SGT_CADD` | `TX_TRM_N_PMT_SGT` | `CLOB CHAR` | Regra de nulidade: será preenchido apenas se a sugestão exigir que a inteligência artificial não utilize algum conjunto de termos/expressões. |
| `TND_CGTV_TCN` | `TX_RCPO_PDRO_TND` | `CLOB CHAR` | Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto |
| `CNR_TCN` | `TX_RCPO_PDRO_CNR` | `CLOB CHAR` | Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto |
| `APSC_TCN` | `TX_RCPO_PDRO_APSC` | `CLOB CHAR` | Regra de nulidade: só deve ser preenchido quando o usuário quiser que o agente faça uma recuperação específica de contexto |
| `RCM_VRS` | `TX_MTV_AVLC` | `VARCHAR2(1000 CHAR)` | Regra de nulidade: Será preenchido apenas se o avaliador desejar informar o motivo. |

---

# Observações finais

- O documento não atribui formato físico, compressão, localização, periodicidade, classificação, retenção, LGPD ou ModelAI porque esses dados não aparecem no DDL Oracle recebido.
- A coluna `Unique individual` foi mantida como não informada explicitamente porque o DDL recebido declara `PRIMARY KEY`, mas não declara restrições `UNIQUE` individuais separadas.
- Os textos de comentário foram preservados a partir dos comandos `COMMENT ON TABLE` e `COMMENT ON COLUMN` disponíveis na fonte.