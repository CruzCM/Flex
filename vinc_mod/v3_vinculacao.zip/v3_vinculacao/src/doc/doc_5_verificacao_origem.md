## Verificação de mudanças nas origens (`5_verificacao_origem.ipynb`)

### Entrada

A verificação de mudanças nas origens (5_verificacao_origem.ipynb) identifica campanhas vigentes que precisam ser processadas novamente porque sua origem foi alterada ou porque ainda não existe uma referência anterior aplicável.

A etapa recebe a tabela de controle atualizada pela sincronização (`df_ctl_oprl_rcm`) e observa somente campanhas vigentes, atuais, abertas e sem execução pendente.

Seu objetivo é decidir se cada campanha deve continuar desligada ou ser religada para novo processamento.

A etapa recebe:

* tabela de controle atualizada pela sincronização (`df_ctl_oprl_rcm`);
* cliente DB2 utilizado quando a origem estiver nesse ambiente (`cliente_db2`).

Os metadados necessários para localizar cada origem já estão registrados na tabela de controle operacional (`CTL_OPRL_RCM`).

A origem pode estar no Hive ou no DB2.

---

### Execução

A rotina valida a estrutura e a consistência operacional da tabela de controle recebida (`df_ctl_oprl_rcm`).

Se a tabela de controle estiver inválida, então a execução é interrompida.

Em seguida, a rotina identifica quais campanhas precisam ter suas origens observadas novamente.

Esta etapa não publica tabelas e não processa clientes.

Ela somente decide se uma campanha deve ser religada para a vinculação.

---

#### Campanhas observadas pela etapa

A rotina observa somente campanhas que atendem simultaneamente às seguintes condições:

```text id="iurk8g"
linha atual
    → IN_REG_ATU = S

recomendação vigente
    → CD_EST_RCM = 3

execução pendente desligada
    → IN_EXEA_PND = N

linha ainda não encerrada
    → TS_FIM_REG = nulo
```

Campanhas já marcadas para processamento (`IN_EXEA_PND = S`) não precisam ser religadas novamente.

Linhas históricas, campanhas não vigentes e linhas já encerradas também não participam da observação.

---

#### Escopo observado na origem

Antes de comparar a origem, a rotina aplica o escopo configurado para a campanha.

A origem pode representar:

* a tabela inteira ou um público único (`CD_TIP_ECP_OGM = 1`);
* um subconjunto identificado por uma coluna de escopo (`CD_TIP_ECP_OGM = 2`).

A comparação considera somente o escopo configurado para a campanha.

---

#### Formas de referência da origem

A rotina pode identificar mudanças por data ou por quantidade.

A forma de comparação é escolhida antes da análise da referência anterior:

```text id="72ozzb"
referência por data
    → somente quando CD_FMA_REF_OGM = D
      e existe data observável na origem.

referência por quantidade
    → em qualquer outro caso.
```

A ausência de referência anterior não escolhe a forma de comparação.

Ela apenas força o religamento depois que a forma aplicável já foi definida.

##### Referência por data

Quando a campanha estiver configurada para referência por data (`CD_FMA_REF_OGM = D`) e a origem disponibilizar uma data observável, então a rotina compara:

```text id="si0lnj"
última data processada
    → TS_ULT_DT_PRCD_OGM

data mais recente observada na origem
```

Se a última data processada ainda não existir ou se a origem possuir uma data mais recente, então a campanha deve ser religada.

Se a data permanecer igual ou não avançar, então não existe mudança aplicável.

##### Referência por quantidade

Quando a campanha estiver configurada para referência por quantidade (`CD_FMA_REF_OGM = Q`) ou quando a origem não disponibilizar uma data utilizável, então a rotina compara:

```text id="39ngyh"
quantidade anteriormente processada
    → QT_DADO_OGM

quantidade atual da origem
```

Se a quantidade anteriormente processada ainda não existir ou se a quantidade atual for diferente, então a campanha deve ser religada.

Se a quantidade permanecer igual, então não existe mudança aplicável.

---

#### Cenário 1 — Campanha fora da observação

Se uma campanha não atender às condições de observação, então sua linha será preservada sem alteração.

Esse cenário inclui:

* linha histórica (`IN_REG_ATU = N`);
* recomendação não vigente (`CD_EST_RCM != 3`);
* campanha já marcada para processamento (`IN_EXEA_PND = S`);
* linha já encerrada (`TS_FIM_REG` preenchido).

Nenhuma decisão adicional é aplicada a essas linhas.

---

#### Cenário 2 — Origem sem mudança

Se a origem puder ser observada com segurança e não existir mudança relevante, então a campanha continuará com a execução pendente desligada:

```text id="m5jspm"
IN_EXEA_PND = N
```

Nenhum novo processamento será necessário.

---

#### Cenário 3 — Origem alterada

Se a origem possuir uma mudança relevante ou ainda não existir uma referência anterior aplicável, então a rotina religa a campanha para novo processamento:

```text id="1piju6"
IN_EXEA_PND = S
```

A campanha seguirá para a vinculação (`6_vinculacao.ipynb`), onde será avaliada para geração de um novo snapshot de clientes.

---

#### Cenário 4 — Origem não observada com segurança

Se a origem não puder ser lida, filtrada ou analisada com segurança, então a rotina preserva a linha sem alteração.

Nenhuma decisão automática será aplicada à campanha.

A falha é pontual: a rotina registra o motivo e continua observando as demais campanhas.

---

#### Falhas críticas da etapa

Se a tabela de controle recebida estiver inválida (`df_ctl_oprl_rcm`), então a execução é interrompida.

Depois de analisar as origens, a rotina valida novamente a estrutura e a consistência operacional da tabela de controle atualizada.

Se a tabela resultante estiver inválida, então a execução também é interrompida.

---

### Resultado

Ao final, a verificação entrega:

* tabela de controle atualizada (`df_ctl_oprl_rcm`);
* estatísticas da verificação das origens (`stats`).

As estatísticas registram:

* quantidade de campanhas observadas (`qtd_observadas`);
* quantidade de campanhas religadas (`qtd_religadas`);
* quantidade de campanhas mantidas sem mudança (`qtd_sem_mudanca`);
* quantidade de campanhas cuja origem não pôde ser observada com segurança (`qtd_falha_fonte`).

A tabela entregue preserva as linhas que não exigem alteração e religa para novo processamento somente as campanhas cujas origens mudaram ou ainda não possuem uma referência anterior aplicável.

Se a verificação terminar com sucesso, então a tabela de controle atualizada (`df_ctl_oprl_rcm`) segue para a vinculação (`6_vinculacao.ipynb`).
