## Preparação do controle operacional (`3_preparacao_controle.ipynb`)

### Entrada

A preparação do controle operacional (`3_preparacao_controle.ipynb`) define qual conteúdo confiável será utilizado como ponto de partida da execução.

Seu objetivo é garantir que a rotina sempre inicie a partir de um estado operacional consistente, preservando a continuidade do processamento mesmo após falhas inesperadas.

A etapa recebe:

* banco Hive de trabalho (`database`);
* caminho HDFS de apoio (`path_save_hdfs`);
* indicação de primeira carga (`primeira_carga`).

A etapa utiliza a tabela oficial de controle (`CTL_OPRL_RCM`) e a foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`).

A foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`) preserva o último estado operacional conhecido antes do início de um novo ciclo de processamento.

Em condições normais, a execução deve utilizar a tabela oficial de controle (`CTL_OPRL_RCM`) como fonte da verdade. O uso da foto segura não representa o fluxo esperado da operação. Sua existência indica que uma execução anterior não concluiu completamente o ciclo previsto e que foi necessário manter uma cópia protegida do estado operacional para evitar perda de rastreabilidade ou interrupção definitiva do processo.

Por esse motivo, quando a rotina identifica e utiliza a foto segura (`temp_backup_CTL_OPRL_RCM`), a execução pode continuar automaticamente, mas o evento deve ser tratado como um alerta operacional. A recuperação automática existe para impedir a parada do processo, porém a causa que levou ao uso da foto segura deve ser analisada posteriormente pela equipe responsável.

---

### Execução

A rotina valida a estrutura e a consistência operacional da tabela de controle.

Em seguida, verifica se a execução representa uma primeira carga (`primeira_carga=True`) ou uma execução normal (`primeira_carga=False`).

---

#### Cenário 1 — Primeira carga

Se a execução for uma primeira carga (`primeira_carga=True`), então a rotina lê a tabela oficial de controle (`CTL_OPRL_RCM`).

A primeira carga exige uma tabela oficial existente, válida e vazia (`CTL_OPRL_RCM`).

Se a tabela oficial não existir, estiver inacessível, estiver inválida ou possuir registros, então a execução é interrompida.

Se a tabela oficial estiver válida e vazia, então a rotina remove temporários antigos quando eles existirem:

* foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`);
* materialização técnica da tabela de controle final (`temp_lineage_CTL_OPRL_RCM`).

Se a remoção de qualquer temporário falhar, então a execução é interrompida.

Se todas as validações forem concluídas com sucesso, então a rotina entrega a tabela oficial vazia como tabela de controle de entrada (`df_ctl_oprl_rcm`).

A inicialização do primeiro estado operacional ocorrerá na sincronização Oracle x Hive (`4_sincronizacao.ipynb`).

---

#### Cenário 2 — Execução normal com foto segura existente

Se a execução for normal (`primeira_carga=False`) e existir uma foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`), então a rotina considera que houve uma falha operacional anterior.

A existência da foto segura deve ser registrada nos logs como erro operacional, mesmo quando a recuperação automática puder continuar.

A rotina valida a estrutura e a consistência operacional da foto segura (`temp_backup_CTL_OPRL_RCM`).

Se a foto segura estiver válida e preenchida, então ela será utilizada como fonte da verdade da recuperação automática e como tabela de controle de entrada (`df_ctl_oprl_rcm`).

O uso da foto segura também deve ser registrado nos logs como erro operacional.

Nesse cenário:

* a foto segura não é apagada;
* a foto segura não é sobrescrita;
* a foto segura não é recriada;
* a tabela oficial de controle (`CTL_OPRL_RCM`) não substitui automaticamente a foto segura;
* o fluxo continua a partir do último estado operacional preservado.

A foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`) é removida somente após a publicação Hive concluída.

Se a foto segura não puder ser lida, estiver inválida ou estiver vazia, então a rotina registra um erro crítico e interrompe a recuperação automática.

Nesse caso, a tabela oficial de controle (`CTL_OPRL_RCM`) é lida somente para classificar a gravidade da falha.

A tabela oficial nunca é utilizada automaticamente como alternativa à foto segura inválida.

Se a foto segura estiver inválida e a tabela oficial estiver válida, mas vazia, então não existe fonte da verdade recuperável.

Para iniciar novamente do zero, a próxima execução deve utilizar explicitamente a primeira carga (`primeira_carga=True`). Essa decisão assume a perda do histórico operacional anterior.

Se a foto segura estiver inválida e a tabela oficial estiver preenchida, inválida ou inacessível, então a execução também é interrompida para análise operacional.

---

#### Cenário 3 — Execução normal sem foto segura

Se a execução for normal (`primeira_carga=False`) e não existir uma foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`), então a rotina lê a tabela oficial de controle (`CTL_OPRL_RCM`).

A execução normal exige uma tabela oficial existente, válida e preenchida.

Se a tabela oficial não existir, estiver inacessível ou estiver inválida, então a execução é interrompida.

Se a tabela oficial estiver válida, mas vazia, então a execução também é interrompida.

Nesse caso, não existe estado operacional anterior disponível para continuidade automática.

Para iniciar novamente do zero, a execução deve utilizar explicitamente a primeira carga (`primeira_carga=True`).

Se a tabela oficial estiver válida e preenchida, então a rotina cria uma nova foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`) antes de continuar.

Se a criação da foto segura falhar, então a execução é interrompida.

Se todas as validações forem concluídas com sucesso, então a rotina utiliza a tabela oficial como tabela de controle de entrada (`df_ctl_oprl_rcm`).

---

### Resultado

Ao final, a preparação entrega:

* tabela de controle validada para continuidade do fluxo (`df_ctl_oprl_rcm`);
* estatísticas da preparação (`stats`).

A tabela de controle entregue (`df_ctl_oprl_rcm`) pode ter vindo de três fontes:

* tabela oficial vazia em primeira carga (`CTL_OPRL_RCM`);
* foto segura utilizada em recuperação automática (`temp_backup_CTL_OPRL_RCM`);
* tabela oficial válida e preenchida em execução normal sem foto segura anterior (`CTL_OPRL_RCM`).

Se a preparação terminar com sucesso, então a tabela de controle validada (`df_ctl_oprl_rcm`) segue para a sincronização Oracle x Hive (`4_sincronizacao.ipynb`).