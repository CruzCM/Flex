## Vinculação de clientes às recomendações (`6_vinculacao.ipynb`)

### Entrada

A vinculação de clientes às recomendações (`6_vinculacao.ipynb`) gera a visão de clientes associados às campanhas que precisam ser processadas.

A etapa recebe a tabela de controle atualizada pela verificação das origens (`df_ctl_oprl_rcm`) e identifica quais campanhas permanecem pendentes de vinculação.

Seu objetivo é gerar um novo snapshot de clientes para cada campanha aplicável, atualizar sua situação no controle operacional e preparar os objetos que seguirão para a publicação Hive.

A etapa recebe:

* tabela de controle atualizada pela verificação das origens (`df_ctl_oprl_rcm`);
* banco Hive de trabalho (`database`);
* cliente DB2 utilizado quando a origem estiver nesse ambiente (`cliente_db2`);
* data operacional (`hoje`).

A etapa também lê a visão histórica/eventual de clientes vinculados (`RCM_FNC_CLI_EVTL`).

Os metadados necessários para localizar e restringir cada origem já estão registrados na tabela de controle operacional (`CTL_OPRL_RCM`).

---

### Execução

A rotina valida inicialmente a estrutura e a consistência operacional da tabela de controle recebida (`df_ctl_oprl_rcm`).

Também valida a estrutura da visão histórica/eventual de clientes vinculados (`RCM_FNC_CLI_EVTL`).

Em seguida, identifica quais campanhas precisam gerar um novo snapshot de clientes.

Esta etapa prepara os dados em memória.

A publicação física ocorrerá em etapa posterior.

---

#### Campanhas processadas pela etapa

A rotina processa somente campanhas que atendem simultaneamente às seguintes condições:

```text
linha atual
    → IN_REG_ATU = S

recomendação vigente
    → CD_EST_RCM = 3

linha ainda não encerrada
    → TS_FIM_REG = nulo

execução pendente ligada
    → IN_EXEA_PND = S
```

Campanhas que não atendem a essas condições são preservadas sem alteração.

---

#### Cenário 1 — Campanha fora do processamento

Se uma campanha não estiver vigente, não representar uma linha atual, já estiver encerrada ou não possuir execução pendente, então sua linha será preservada sem alteração.

Esse cenário inclui:

* linha histórica (`IN_REG_ATU = N`);
* recomendação não vigente (`CD_EST_RCM != 3`);
* linha já encerrada (`TS_FIM_REG` preenchido);
* campanha sem execução pendente (`IN_EXEA_PND = N`).

Nenhum novo snapshot será gerado para essas linhas.

---

#### Cenário 2 — Campanha pendente processada com sucesso

Se uma campanha estiver apta ao processamento, então a rotina lê sua origem e aplica o escopo configurado.

A origem pode estar no Hive ou no DB2.

O escopo pode representar:

* a origem inteira ou um público único (`CD_TIP_ECP_OGM = 1`);
* um subconjunto identificado por uma coluna de escopo (`CD_TIP_ECP_OGM = 2`).

Em seguida, a rotina identifica os clientes válidos da origem utilizando as colunas candidatas definidas no contrato (`COLUNAS_CLIENTE_ORIGEM`).

A forma de referência processada depende da configuração da campanha:

```text
referência por data
    → CD_FMA_REF_OGM = D
      e existe data observável na origem.

referência por quantidade
    → CD_FMA_REF_OGM != D.
```

Se a campanha estiver configurada para referência por data (`CD_FMA_REF_OGM = D`), então a origem precisa disponibilizar uma data utilizável.

Se a campanha estiver configurada para referência por quantidade, então a rotina considera a quantidade de registros observados na origem.

Quando a origem puder ser processada com segurança e possuir clientes válidos, a rotina gera um novo snapshot.

Cada snapshot recebe a data operacional da execução (`DT_AVS_FNC_CLI = hoje`).

Atualmente, o identificador do aviso (`CD_IDFR_AVS`) recebe somente o número da recomendação convertido para texto:

```text
CD_IDFR_AVS = CAST(NR_IDFR_RCM AS STRING)
```

Essa é uma regra temporária. Embora `NR_IDFR_PROJ` permaneça disponível nas tabelas Hive e no controle operacional, ele não compõe o valor atualmente publicado em `AVS_FNC_CLI.CD_IDFR_AVS`.

A tabela Oracle `AVS_FNC_CLI` não possui uma coluna própria para identificar o projeto. Por esse motivo, a regra planejada para o identificador é retornar à composição:

```text
CD_IDFR_AVS = CAST(NR_IDFR_PROJ AS STRING) + "_" + CAST(NR_IDFR_RCM AS STRING)
```

O identificador composto foi definido para preservar, no próprio valor entregue à `AVS_FNC_CLI`, a associação entre projeto e recomendação. Enquanto a regra temporária estiver vigente, o projeto não poderá ser inferido somente a partir de `CD_IDFR_AVS` no Oracle.

O retorno à regra composta deve permanecer no radar técnico e ser realizado de forma coordenada com os consumidores do identificador.

Nenhuma das duas fórmulas inclui a versão validada da recomendação.

Por esse motivo, uma nova versão da mesma recomendação atualiza a foto corrente do mesmo aviso.

Depois de gerar o snapshot, a rotina desliga a execução pendente:

```text
IN_EXEA_PND = N
```

A rotina também atualiza a referência processada na tabela de controle.

Quando a referência for por data:

```text
TS_ULT_DT_OBSD_OGM = data observada na origem
TS_ULT_DT_PRCD_OGM = data processada com sucesso
QT_DADO_OGM = nulo
```

Quando a referência for por quantidade:

```text
TS_ULT_DT_OBSD_OGM = nulo
TS_ULT_DT_PRCD_OGM = nulo
QT_DADO_OGM = quantidade processada com sucesso
```

---

#### Cenário 3 — Campanha mantida pendente por falha pontual

Se uma campanha não puder ser processada com segurança, então ela permanecerá pendente para uma nova tentativa:

```text
IN_EXEA_PND = S
```

Nenhum novo snapshot será gerado para essa campanha.

A falha é pontual: a rotina registra o motivo e continua processando as demais campanhas.

Esse cenário inclui situações como:

* origem inacessível;
* origem com tipo desconhecido;
* metadados obrigatórios ausentes;
* escopo inválido;
* coluna de escopo inexistente;
* referência por data indefinida;
* ausência de uma coluna de cliente aceita;
* origem sem clientes válidos (`nenhum_cliente_valido`).

---

#### Preparação segura do lote histórico/eventual

Depois de processar as campanhas pendentes, a rotina prepara o lote que poderá ser acrescentado à visão histórica/eventual de clientes vinculados (`RCM_FNC_CLI_EVTL`).

A chave histórica é formada por:

```text
CD_IDFR_AVS
CD_CLI
DT_AVS_FNC_CLI
```

Antes da publicação Hive, a rotina compara os novos snapshots com o histórico existente.

Se um registro com a mesma chave histórica e o mesmo conteúdo já existir, então ele será retirado do lote preparado para append.

Se a mesma chave histórica já existir com conteúdo diferente, então a execução será interrompida para evitar divergência no histórico.

A geração de novos snapshots não implica necessariamente novos registros no lote preparado para append.

Em uma reexecução idempotente na mesma data operacional (`hoje`), o lote preparado para append pode ficar vazio.

---

#### Remontagem da visão corrente de clientes vinculados

A rotina também remonta a visão corrente de clientes vinculados (`RCM_FNC_CLI`).

A visão corrente considera somente campanhas atuais, vigentes e ainda não encerradas.

Para cada campanha aplicável, a rotina utiliza a última foto histórica disponível ou o novo snapshot gerado durante a execução.

Se uma campanha gerar um novo snapshot com sucesso, então esse snapshot substituirá integralmente sua foto anterior na visão corrente.

A substituição ocorre para o conjunto completo de clientes da campanha.

Não existe atualização parcial por cliente.

Se uma campanha permanecer pendente por falha pontual e já possuir histórico anterior, então a visão corrente preservará sua última foto histórica aplicável.

Se a primeira tentativa de vinculação falhar antes da geração do snapshot, então a campanha permanecerá pendente e ainda não aparecerá na visão corrente.

Campanhas que deixaram de estar atuais, vigentes ou abertas não permanecerão na visão corrente remontada.

---

#### Falhas críticas da etapa

Algumas falhas impedem a continuidade de toda a vinculação.

Se a tabela de controle recebida estiver inválida (`df_ctl_oprl_rcm`), então a execução será interrompida.

Se a visão histórica/eventual recebida estiver inválida (`RCM_FNC_CLI_EVTL`), então a execução também será interrompida.

Depois de processar as campanhas, a rotina valida novamente a estrutura e a consistência operacional da tabela de controle atualizada.

Se a tabela resultante estiver inválida, então a execução será interrompida.

A rotina também interrompe a execução quando identificar:

* duplicidade no lote histórico/eventual preparado;
* duplicidade no histórico existente;
* mesma chave histórica com conteúdo divergente;
* estrutura inválida na visão corrente remontada;
* duplicidade na visão corrente remontada;
* chave nula na visão corrente remontada.

---

### Resultado

Ao final, a vinculação entrega:

* tabela de controle atualizada (`df_ctl_oprl_rcm`);
* lote histórico/eventual preparado para append (`df_rcm_fnc_cli_evtl_append`);
* visão corrente remontada de clientes vinculados (`df_rcm_fnc_cli_final`);
* estatísticas da vinculação (`stats`).

As estatísticas registram:

* quantidade de campanhas pendentes encontradas (`qtd_pendentes`);
* quantidade de campanhas processadas com sucesso (`qtd_processadas_sucesso`);
* quantidade de campanhas mantidas pendentes por falha pontual (`qtd_falha_pontual`);
* quantidade de registros presentes nos novos snapshots gerados (`qtd_snapshot_novo`);
* quantidade de registros presentes na visão corrente remontada (`qtd_rcm_fnc_cli_final`).

A quantidade de registros presentes nos novos snapshots (`qtd_snapshot_novo`) não representa necessariamente a quantidade de registros que será acrescentada ao histórico.

Registros idênticos já existentes são retirados do lote histórico/eventual antes da publicação.

Se a vinculação terminar com sucesso, então a tabela de controle atualizada (`df_ctl_oprl_rcm`), o lote histórico/eventual preparado para append (`df_rcm_fnc_cli_evtl_append`) e a visão corrente remontada (`df_rcm_fnc_cli_final`) seguem para a publicação Hive (`7_publicar_hive.ipynb`).
