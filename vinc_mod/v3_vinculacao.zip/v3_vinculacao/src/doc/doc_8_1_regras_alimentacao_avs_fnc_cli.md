# Contrato negocial e técnico da alimentação da `AVS_FNC_CLI`

## 1. Objetivo

Este documento descreve, em detalhe, as regras que determinam o conteúdo publicado na tabela Oracle `AVS_FNC_CLI`.

A `AVS_FNC_CLI` é a entrega final consumida pela API Minhas Finanças. Ela representa a visão corrente de avisos disponibilizados aos clientes e deve permanecer materialmente equivalente à visão corrente oficial publicada no Hive (`RCM_FNC_CLI`).

Este documento complementa o [documento operacional da publicação Oracle](doc_8_publicar_oracle.md). O documento operacional explica a execução da etapa; este documento explica o conteúdo entregue, a origem de cada atributo e todas as transformações aplicadas antes da gravação.

As regras aqui descritas refletem o código atualmente executado. Elas não substituem o DDL físico recebido e não representam uma proposta de alteração.

---

## 2. Escopo

Este documento cobre:

* quais campanhas e clientes podem chegar à `AVS_FNC_CLI`;
* como a visão corrente é formada no Hive;
* a origem de cada atributo Oracle;
* conversões de tipo;
* normalização de strings;
* aplicação de `TRIM`;
* aplicação de `SUBSTRING`;
* nulidade;
* limites físicos;
* chave e duplicidade;
* comparação material entre Hive e Oracle;
* limpeza e recarga da tabela;
* validação posterior à carga;
* regra temporária de `CD_IDFR_AVS`;
* riscos e limitações conhecidos.

Não faz parte deste documento:

* consumo da tabela pela API;
* visualizações ou cliques;
* regras da `VSLO_AVS_FNC_CLI`;
* proposta de painel;
* alteração do contrato físico Oracle.

---

## 3. Papel da tabela na entrega

A `AVS_FNC_CLI` não é uma tabela histórica. Ela contém somente a população corrente que deve estar disponível para consumo.

Sua granularidade é:

```text
um cliente
    ×
um identificador de aviso
```

A chave física Oracle é:

```text
CD_CLI_AVS
CD_IDFR_AVS
```

Consequências:

* o mesmo aviso pode ser entregue a vários clientes;
* o mesmo cliente pode receber vários avisos;
* o mesmo cliente não pode possuir duas linhas com o mesmo `CD_IDFR_AVS`;
* campanhas encerradas deixam de aparecer na visão corrente;
* uma publicação com diferença material substitui o conteúdo integral da tabela;
* não existe atualização Oracle isolada por campanha ou por cliente.

---

## 4. Fluxo completo até a `AVS_FNC_CLI`

```text
Oracle de cadastro
    RCM_VLDD
    RCM_VRS
    AVS_SELD
    PBCO_CADD
    SGT_CADD
        │
        ▼
Sincronização e controle operacional
    CTL_OPRL_RCM
        │
        ▼
Leitura da origem e vinculação dos clientes
        │
        ├── novo snapshot da campanha
        │
        └── última foto histórica aplicável
        ▼
Visão histórica/eventual
    RCM_FNC_CLI_EVTL
        │
        ▼
Visão corrente oficial
    RCM_FNC_CLI
        │
        ▼
Preparação para o contrato Oracle
        │
        ▼
Comparação material
    Hive preparado × AVS_FNC_CLI atual
        │
        ├── sem diferença: Oracle preservado
        │
        └── com diferença: DELETE + append
        ▼
AVS_FNC_CLI
```

Em execução física (`executar=True`), a publicação Oracle relê a tabela Hive `RCM_FNC_CLI` já publicada. O DataFrame em memória não é usado como fonte física da carga produtiva.

Em simulação (`executar=False`), a preparação usa `df_rcm_fnc_cli_final`, compara o resultado com o Oracle atual e não executa escrita.

---

## 5. Formação da população corrente

### 5.1 Campanhas elegíveis

A visão corrente considera somente linhas do controle que atendem simultaneamente:

```text
IN_REG_ATU = "S"
CD_EST_RCM = 3
TS_FIM_REG IS NULL
```

Isso significa:

* a linha deve representar o estado atual da recomendação;
* a recomendação deve estar vigente;
* o registro não pode estar encerrado.

`IN_EXEA_PND` controla a necessidade de gerar um novo snapshot, mas não é, isoladamente, um critério para excluir uma campanha da visão corrente.

### 5.2 Novo snapshot

Quando uma recomendação pendente é processada com sucesso:

* a origem configurada é lida;
* o escopo da campanha é aplicado;
* os clientes válidos são resolvidos;
* é gerado um snapshot completo da campanha;
* o snapshot novo substitui integralmente a foto anterior dessa campanha na visão corrente.

Não existe atualização parcial de clientes dentro de uma campanha.

#### 5.2.1 Seleção da tecnologia de origem

`NM_DB_OGM` determina como a origem dinâmica é lida:

| Prefixo normalizado de `NM_DB_OGM` | Tecnologia | Leitura |
| --- | --- | --- |
| `hive_` ou `sbx_` | Hive | `SELECT *` na tabela qualificada |
| `db2` | DB2 | Consulta JDBC das colunas candidatas existentes |
| qualquer outro | Desconhecida | A campanha não consegue prosseguir |

A classificação aplica `strip()` e comparação em minúsculas ao nome do database.

Para DB2, o código consulta o catálogo para descobrir quais colunas candidatas existem e monta a seleção somente com elas. Para Hive dinâmico, os nomes físicos são preservados na leitura e resolvidos posteriormente sem diferenciação entre maiúsculas e minúsculas.

#### 5.2.2 Aplicação do escopo

O escopo é aplicado antes da resolução dos clientes:

```text
CD_TIP_ECP_OGM = 1
    → utilizar a origem inteira

CD_TIP_ECP_OGM = 2
    → localizar NM_COL_ECP_OGM sem diferenciar caixa
    → converter a coluna para o tipo contratual de NR_IDFR_PBCO
    → manter somente valor = NR_IDFR_PBCO da campanha
```

Para o escopo `2`, tanto `NM_COL_ECP_OGM` quanto `NR_IDFR_PBCO` são obrigatórios. Tipo de escopo inválido, coluna inexistente ou metadado obrigatório ausente impede o snapshot daquela recomendação.

Somente depois desse filtro o pipeline procura, normaliza e deduplica a coluna de cliente.

### 5.3 Uso da última foto histórica

Para uma campanha vigente que não produziu snapshot novo na execução, a visão corrente reutiliza a última data disponível na `RCM_FNC_CLI_EVTL`.

Se ocorrer uma falha pontual e já existir histórico anterior, a última foto aplicável permanece na visão corrente.

Se a primeira tentativa de uma campanha falhar antes da criação de qualquer snapshot, essa campanha ainda não terá clientes para publicar na `AVS_FNC_CLI`.

### 5.4 Encerramento

Quando a recomendação deixa de ser atual, vigente ou aberta, seu identificador deixa de compor a visão corrente.

Na próxima publicação Oracle com diferença material, todas as linhas correspondentes a essa campanha deixam de existir na `AVS_FNC_CLI`.

---

## 6. Contrato físico resumido

| Ordem | Coluna Oracle | Tipo físico Oracle | Tipo Spark do contrato | Nulidade física | Chave |
| ---: | --- | --- | --- | --- | --- |
| 1 | `PC_NVL_CNFA_AVS` | `NUMBER(4,2)` | `DECIMAL(4,2)` | Obrigatória | Não |
| 2 | `CD_IDFR_AVS` | `VARCHAR2(36 CHAR)` | `STRING` | Obrigatória | Sim |
| 3 | `DT_AVS_FNC_CLI` | `DATE` | `DATE` | Obrigatória | Não |
| 4 | `TX_TIT_AVS_FNC_CLI` | `VARCHAR2(64 CHAR)` | `STRING` | Obrigatória | Não |
| 5 | `TX_AVS_FNC_CLI` | `VARCHAR2(255 CHAR)` | `STRING` | Obrigatória | Não |
| 6 | `TX_PRM_HDR_API_AVS` | `VARCHAR2(1000 CHAR)` | `STRING` | Opcional | Não |
| 7 | `CD_CLI_AVS` | `NUMBER(11)` | `BIGINT` | Obrigatória | Sim |

A projeção final mantém somente essas sete colunas, nessa ordem.

---

## 7. Mapeamento completo Hive → Oracle

| Coluna Oracle | Coluna da visão Hive | Origem negocial | Transformação imediatamente anterior ao contrato Oracle |
| --- | --- | --- | --- |
| `PC_NVL_CNFA_AVS` | `PC_NVL_CNFA_AVS` | Valor oficial fixo do pipeline | `CAST` para `DECIMAL(4,2)` |
| `CD_IDFR_AVS` | `CD_IDFR_AVS` | Identificador calculado para a recomendação | `CAST` para `STRING` e `TRIM` |
| `DT_AVS_FNC_CLI` | `DT_AVS_FNC_CLI` | Data operacional do snapshot | `CAST` para `DATE` |
| `TX_TIT_AVS_FNC_CLI` | `TX_TIT_PDRO_AVS` | Título do aviso selecionado | `TRIM`, `CAST` para `STRING` e `SUBSTRING(1, 64)` |
| `TX_AVS_FNC_CLI` | `TX_STIT_PDRO_AVS` | Subtítulo do aviso selecionado | `TRIM`, `CAST` para `STRING` e `SUBSTRING(1, 255)` |
| `TX_PRM_HDR_API_AVS` | `TX_PRM_HDR_API_AVS` | Parâmetro de header da versão validada | `TRIM`, `CAST` para `STRING` e `SUBSTRING(1, 1000)` |
| `CD_CLI_AVS` | `CD_CLI` | Cliente resolvido na origem da campanha | `CAST` para `BIGINT` |

### 7.1 Ciclo de tipos de cada atributo

O tipo físico do destino não é o único tipo relevante. Alguns valores passam por contratos intermediários mais restritivos antes de chegar ao Oracle.

| Atributo | Origem anterior ao snapshot | Contrato Hive | Preparação Spark para Oracle | Destino físico |
| --- | --- | --- | --- | --- |
| `PC_NVL_CNFA_AVS` | Constante Python `Decimal("99.00")` | `DECIMAL(4,2)` | `CAST AS DECIMAL(4,2)` | `NUMBER(4,2)` |
| `CD_IDFR_AVS` | `NR_IDFR_RCM`, tratado como identificador numérico | `STRING` | `TRIM(CAST(... AS STRING))` | `VARCHAR2(36 CHAR)` |
| `DT_AVS_FNC_CLI` | Texto operacional `hoje`, interpretado com formato `%Y-%m-%d` | `DATE` | `CAST AS DATE` | `DATE` |
| `TX_TIT_AVS_FNC_CLI` | `AVS_SELD.TX_TIT_PDRO_AVS`, fisicamente `CLOB CHAR` | `STRING` | `TRIM` + `SUBSTRING(1,64)` | `VARCHAR2(64 CHAR)` |
| `TX_AVS_FNC_CLI` | `AVS_SELD.TX_STIT_PDRO_AVS`, fisicamente `CLOB CHAR` | `STRING` | `TRIM` + `SUBSTRING(1,255)` | `VARCHAR2(255 CHAR)` |
| `TX_PRM_HDR_API_AVS` | `RCM_VRS.TX_PRPT_PRM_HDR_API`, fisicamente `CLOB CHAR` | `STRING`, anulável | `TRIM` + `SUBSTRING(1,1000)` | `VARCHAR2(1000 CHAR)` |
| `CD_CLI_AVS` | Coluna dinâmica da origem da campanha | `INT` em `CD_CLI` | `CAST AS BIGINT` | `NUMBER(11)` |

### 7.2 Consequência dos contratos intermediários

O destino Oracle não amplia um valor que já foi descartado ou alterado em uma etapa anterior.

Exemplos:

* um título `CLOB` pode conter mais de 64 caracteres, mas somente os primeiros 64 chegam ao destino;
* um header `CLOB` pode conter mais de 1000 caracteres, mas somente os primeiros 1000 chegam ao destino;
* um código de cliente pode caber em `NUMBER(11)`, mas ainda precisa caber no `INT` usado no Hive antes de ser convertido para `BIGINT`;
* a comparação e as validações Oracle observam os valores já convertidos, aparados e, no caso dos textos, truncados.

Não existe conversão direta da linha bruta da origem para os tipos físicos da `AVS_FNC_CLI`.

---

## 8. Regra detalhada de cada atributo

### 8.1 `PC_NVL_CNFA_AVS`

#### Finalidade

Representa o percentual de confiança atribuído ao aviso.

#### Origem efetiva

O valor não é calculado individualmente por cliente ou recomendação. O pipeline utiliza o valor oficial fixo:

```text
99.00
```

Esse valor é definido no contrato como:

```python
VALOR_OFICIAL_PC_NVL_CNFA_AVS = Decimal("99.00")
```

#### Formação no Hive

Durante a geração do snapshot:

```text
PC_NVL_CNFA_AVS = 99.00
```

#### Preparação Oracle

```text
CAST(PC_NVL_CNFA_AVS AS DECIMAL(4,2))
```

#### Validações

* não pode ser nulo;
* deve estar entre `0.00` e `99.99`, conforme o limite implementado;
* qualquer valor fora da faixa bloqueia a carga.

#### Observação

O DDL descreve semanticamente valores de 0 a 99. A implementação valida a capacidade física de `DECIMAL(4,2)`, até `99.99`. O valor produzido atualmente é sempre `99.00`.

---

### 8.2 `CD_IDFR_AVS`

#### Finalidade

Identifica o aviso dentro da chave entregue à `AVS_FNC_CLI`.

#### Tipo

Mesmo quando contém somente algarismos, o valor é armazenado como texto:

```text
Hive:   STRING
Oracle: VARCHAR2(36 CHAR)
```

#### Regra temporária vigente

Atualmente:

```text
CD_IDFR_AVS = CAST(NR_IDFR_RCM AS STRING)
```

Exemplo:

```text
NR_IDFR_PROJ = 10
NR_IDFR_RCM  = 25
CD_IDFR_AVS  = "25"
```

`NR_IDFR_PROJ` não compõe o identificador atualmente publicado.

#### Regra planejada

A regra planejada é retornar à composição:

```text
CD_IDFR_AVS =
    CAST(NR_IDFR_PROJ AS STRING)
    + "_"
    + CAST(NR_IDFR_RCM AS STRING)
```

Exemplo:

```text
NR_IDFR_PROJ = 10
NR_IDFR_RCM  = 25
CD_IDFR_AVS  = "10_25"
```

Essa composição preserva o projeto no próprio identificador, pois a `AVS_FNC_CLI` não possui uma coluna específica para `NR_IDFR_PROJ`.

#### Versão

`NR_VRS_VLDD_RCM` não compõe o identificador na regra atual nem na regra planejada.

Uma nova versão validada da mesma recomendação atualiza a foto corrente associada ao mesmo aviso.

#### Preparação Oracle

```text
TRIM(CAST(CD_IDFR_AVS AS STRING))
```

Na projeção final do contrato, strings são novamente convertidas para `STRING` e normalizadas com `TRIM`.

#### Validações

* não pode ser nulo;
* não pode ser string vazia;
* não pode ultrapassar 36 caracteres;
* não sofre `SUBSTRING`;
* compõe a chave juntamente com `CD_CLI_AVS`;
* duplicidade após a normalização bloqueia a carga.

#### Limitação temporária

A regra atual pressupõe que `NR_IDFR_RCM`, sozinho, seja suficiente para distinguir avisos entre projetos.

Se o mesmo número de recomendação puder existir em projetos diferentes:

* o projeto não poderá ser inferido a partir do Oracle;
* identificadores de projetos diferentes poderão colidir;
* a chave `CD_IDFR_AVS + CD_CLI_AVS` poderá bloquear duplicidades;
* a visão histórica poderá tratar campanhas diferentes como o mesmo aviso.

O retorno ao identificador composto deve permanecer no radar técnico e ser coordenado com todos os consumidores de `CD_IDFR_AVS`.

---

### 8.3 `DT_AVS_FNC_CLI`

#### Finalidade

Representa a data operacional associada ao snapshot do aviso para o cliente.

#### Origem

Na geração do snapshot:

```text
DT_AVS_FNC_CLI = hoje
```

`hoje` é a data oficial recebida pela rotina.

Na criação do snapshot, o valor é interpretado explicitamente como:

```python
datetime.strptime(hoje, "%Y-%m-%d").date()
```

Portanto, a representação esperada nessa fronteira é `AAAA-MM-DD`. O resultado já entra no snapshot como data, sem componente de horário.

#### O que a data não representa

Essa coluna não é:

* timestamp de inserção Oracle;
* data da publicação física;
* data de visualização;
* data de clique;
* data da última interação.

#### Preparação Oracle

```text
CAST(DT_AVS_FNC_CLI AS DATE)
```

#### Validações

* não pode ser nula;
* participa da chave histórica da `RCM_FNC_CLI_EVTL`;
* não participa da chave da `AVS_FNC_CLI`.

Na comparação material, o contrato trata essa coluna como `DATE`; componente de horário não faz parte do contrato Spark utilizado na comparação.

---

### 8.4 `TX_TIT_AVS_FNC_CLI`

#### Finalidade

É o título do aviso entregue para apresentação ao cliente.

#### Origem

```text
AVS_SELD.TX_TIT_PDRO_AVS
    ↓
CTL_OPRL_RCM.TX_TIT_PDRO_AVS
    ↓
RCM_FNC_CLI.TX_TIT_PDRO_AVS
    ↓
AVS_FNC_CLI.TX_TIT_AVS_FNC_CLI
```

O aviso selecionado está associado à versão validada da recomendação.

#### Preparação Oracle

```text
SUBSTRING(
    TRIM(CAST(TX_TIT_PDRO_AVS AS STRING)),
    1,
    64
)
```

#### Validações

* não pode ser nulo;
* após a transformação, não pode ultrapassar 64 caracteres;
* não compõe a chave.

#### Comportamento de excedente

O `SUBSTRING` é aplicado antes da validação de comprimento.

Portanto, um título com mais de 64 caracteres:

* não é publicado integralmente;
* é cortado nos primeiros 64 caracteres;
* não gera, pelo fluxo atual, erro de limite baseado no tamanho original.

Esse comportamento é uma normalização silenciosa anterior à carga.

#### String vazia

Não existe validação explícita de string vazia para o título. A validação existente verifica nulidade, não conteúdo vazio após `TRIM`.

---

### 8.5 `TX_AVS_FNC_CLI`

#### Finalidade

É o texto principal armazenado na coluna de texto do aviso na tabela final.

#### Origem efetiva

```text
AVS_SELD.TX_STIT_PDRO_AVS
    ↓
CTL_OPRL_RCM.TX_STIT_PDRO_AVS
    ↓
RCM_FNC_CLI.TX_STIT_PDRO_AVS
    ↓
AVS_FNC_CLI.TX_AVS_FNC_CLI
```

O conteúdo publicado nessa coluna vem do subtítulo padrão do aviso selecionado.

#### Preparação Oracle

```text
SUBSTRING(
    TRIM(CAST(TX_STIT_PDRO_AVS AS STRING)),
    1,
    255
)
```

#### Validações

* não pode ser nulo;
* após a transformação, não pode ultrapassar 255 caracteres;
* não compõe a chave.

#### Comportamento de excedente

Assim como o título, o texto é cortado antes da validação de tamanho.

Um valor acima de 255 caracteres é publicado somente com os primeiros 255 caracteres e não gera erro baseado no comprimento original.

#### String vazia

Não existe validação explícita de string vazia para `TX_AVS_FNC_CLI`. A validação existente verifica nulidade.

---

### 8.6 `TX_PRM_HDR_API_AVS`

#### Finalidade

Armazena o parâmetro de header utilizado pela API quando a recomendação possuir esse tipo de acionamento.

#### Origem

```text
RCM_VRS.TX_PRPT_PRM_HDR_API
    ↓
CTL_OPRL_RCM.TX_PRPT_PRM_HDR_API
    ↓
RCM_FNC_CLI.TX_PRM_HDR_API_AVS
    ↓
AVS_FNC_CLI.TX_PRM_HDR_API_AVS
```

O valor pertence à versão validada usada para gerar o snapshot.

#### Nulidade

É o único atributo opcional da `AVS_FNC_CLI`.

Quando não houver parâmetro aplicável:

```text
TX_PRM_HDR_API_AVS = NULL
```

#### Preparação Oracle

```text
SUBSTRING(
    TRIM(CAST(TX_PRM_HDR_API_AVS AS STRING)),
    1,
    1000
)
```

Se a entrada for nula, o resultado permanece nulo.

#### Comportamento de excedente

O valor é cortado nos primeiros 1000 caracteres antes da validação de tamanho.

Consequentemente, o tamanho original acima do limite não bloqueia a carga pelo fluxo atual.

---

### 8.7 `CD_CLI_AVS`

#### Finalidade

Identifica o cliente que receberá o aviso.

#### Origem

O cliente é resolvido na origem dinâmica configurada para a campanha.

Antes da criação do snapshot, o fluxo:

* procura, sem diferenciar maiúsculas de minúsculas, a primeira coluna aceita entre `cd_cli`, `mci` e `cdcli`;
* converte o valor bruto para `STRING` e aplica `TRIM`;
* elimina valores nulos e vazios;
* converte para o tipo interno `INT` definido no contrato Hive;
* elimina resultados de conversão nulos;
* aplica `DISTINCT`.

Se nenhuma das três alternativas existir, a recomendação não produz snapshot.

A expressão lógica usada é equivalente a:

```sql
WITH normalizado AS (
    SELECT TRIM(CAST(<coluna_cliente> AS STRING)) AS _cd_cli_raw
),
convertido AS (
    SELECT CAST(_cd_cli_raw AS INT) AS CD_CLI
    FROM normalizado
    WHERE _cd_cli_raw IS NOT NULL
      AND _cd_cli_raw <> ''
)
SELECT DISTINCT CD_CLI
FROM convertido
WHERE CD_CLI IS NOT NULL
```

Na visão Hive, o atributo se chama:

```text
CD_CLI
```

Na entrega Oracle:

```text
CD_CLI → CD_CLI_AVS
```

O ciclo completo de tipos é:

```text
tipo desconhecido da origem
    → STRING aparada
    → INT no Hive
    → BIGINT no DataFrame Oracle
    → NUMBER(11) no Oracle
```

#### Preparação Oracle

```text
CAST(CD_CLI AS BIGINT)
```

#### Validações

* não pode ser nulo;
* não pode possuir mais de 11 dígitos na representação textual;
* compõe a chave com `CD_IDFR_AVS`;
* duplicidade bloqueia a carga.

#### Limites da validação

Na publicação Oracle não existe uma validação adicional de sinal positivo. A validação específica dessa etapa considera nulidade, conversão, duplicidade e quantidade de dígitos.

O `INT` intermediário é um ponto mais restritivo que o destino `NUMBER(11)`. Assim, nem todo número de até 11 dígitos que caberia fisicamente no Oracle consegue atravessar o pipeline atual.

`INT` no contrato Spark é inteiro assinado de 32 bits:

```text
mínimo = -2.147.483.648
máximo =  2.147.483.647
```

Para identificadores negociais positivos, o maior valor representável nesse ponto é `2.147.483.647`, mesmo que `NUMBER(11)` aceite mais dígitos.

O comportamento de um `CAST` inválido ou fora da faixa do `INT` depende da configuração Spark da sessão:

* quando o `CAST` devolve `NULL`, a linha é removida pelo filtro posterior;
* quando a sessão está configurada para lançar erro de conversão, a leitura da campanha falha.

Não há configuração explícita de `spark.sql.ansi.enabled` neste projeto. Por isso, a rotina não deve assumir silenciosamente um dos dois comportamentos ao diagnosticar um código de cliente rejeitado.

---

## 9. Campos presentes no Hive e não publicados no Oracle

A visão Hive contém atributos adicionais para controle, rastreabilidade e diagnóstico.

Entre eles:

```text
NR_IDFR_PROJ
NR_IDFR_RCM
NR_VRS_VLDD_RCM
NR_IDFR_AVS_SELD
NR_IDFR_PBCO
NR_IDFR_SGT
CD_EST_VRS_RCM
TX_ACMT_PDRO_AVS
NM_DB_OGM
NM_TAB_OGM
CD_TIP_ECP_OGM
CD_FMA_REF_OGM
NM_COL_ECP_OGM
TS_ULT_DT_PRCD_OGM
QT_DADO_OGM
```

Durante a preparação Oracle, `NR_IDFR_PROJ`, `NR_IDFR_RCM`, `NR_VRS_VLDD_RCM` e `CD_CLI` são mantidos temporariamente para rastrear falhas por recomendação e cliente.

Ao final, `projetar_contrato_oracle` descarta todas as colunas que não pertencem ao contrato físico da `AVS_FNC_CLI`.

### 9.1 Texto de acionamento

`TX_ACMT_PDRO_AVS` é preservado no Hive, mas não possui mapeamento para a `AVS_FNC_CLI`.

Na entrega atual:

```text
TX_TIT_PDRO_AVS  → TX_TIT_AVS_FNC_CLI
TX_STIT_PDRO_AVS → TX_AVS_FNC_CLI
TX_ACMT_PDRO_AVS → não publicado na AVS_FNC_CLI
```

### 9.2 Projeto, recomendação e versão

`AVS_FNC_CLI` não possui colunas próprias para:

```text
NR_IDFR_PROJ
NR_IDFR_RCM
NR_VRS_VLDD_RCM
```

Atualmente, somente `NR_IDFR_RCM` é transportado indiretamente dentro de `CD_IDFR_AVS`.

Projeto e versão não podem ser recuperados de forma completa usando somente a linha Oracle publicada.

---

## 10. Ordem exata da preparação Oracle

As regras são aplicadas na seguinte ordem:

### Passo 1 — Escolha da fonte

```text
executar=True
    → reler database.RCM_FNC_CLI já publicado

executar=False
    → usar df_rcm_fnc_cli_final em memória
```

### Passo 2 — Seleção de contexto e atributos

O DataFrame de preparação mantém:

* projeto;
* recomendação;
* versão;
* cliente;
* sete atributos do contrato Oracle.

Os campos de contexto apoiam os diagnósticos, mas não são gravados.

### Passo 3 — Conversões explícitas

São aplicados:

* `CAST` numérico;
* `CAST` de data;
* `CAST` para string;
* `TRIM` dos textos;
* `SUBSTRING` dos três textos com limite físico.

### Passo 4 — Validação de nulidade

São obrigatórios:

```text
PC_NVL_CNFA_AVS
CD_IDFR_AVS
DT_AVS_FNC_CLI
TX_TIT_AVS_FNC_CLI
TX_AVS_FNC_CLI
CD_CLI_AVS
```

É opcional:

```text
TX_PRM_HDR_API_AVS
```

### Passo 5 — Validação de duplicidade

A chave validada é:

```text
CD_CLI_AVS
CD_IDFR_AVS
```

A validação ocorre após `TRIM` e conversões. Valores que se tornarem iguais após a normalização serão considerados duplicados.

### Passo 6 — Validações físicas adicionais

São avaliados:

* `CD_IDFR_AVS` vazio;
* `CD_IDFR_AVS` acima de 36 caracteres;
* faixa de `PC_NVL_CNFA_AVS`;
* quantidade de dígitos de `CD_CLI_AVS`;
* comprimentos dos textos já transformados.

### Passo 7 — Projeção final

A projeção:

* resolve nomes de colunas sem diferenciar maiúsculas de minúsculas;
* normaliza os nomes para o contrato canônico;
* converte cada coluna para o tipo Spark definido;
* aplica `TRIM` novamente em todas as strings;
* elimina campos que não pertencem à `AVS_FNC_CLI`;
* entrega exatamente sete colunas na ordem do contrato.

---

## 11. `TRIM`, `SUBSTRING` e `CAST`

### 11.1 `TRIM`

O `TRIM` remove espaços no início e no fim de:

```text
CD_IDFR_AVS
TX_TIT_AVS_FNC_CLI
TX_AVS_FNC_CLI
TX_PRM_HDR_API_AVS
```

Espaços internos são preservados.

O conteúdo textual publicado pode, portanto, ser diferente do conteúdo bruto de origem mesmo quando não houver truncamento.

### 11.2 `SUBSTRING`

O corte é aplicado somente a:

```text
TX_TIT_AVS_FNC_CLI → 64 caracteres
TX_AVS_FNC_CLI     → 255 caracteres
TX_PRM_HDR_API_AVS → 1000 caracteres
```

Não é aplicado `SUBSTRING` a:

```text
CD_IDFR_AVS
```

Um identificador acima do limite bloqueia a carga.

### 11.3 `CAST`

Os `CAST` garantem comparação e escrita nos tipos definidos pelo contrato:

```text
PC_NVL_CNFA_AVS    → DECIMAL(4,2)
CD_IDFR_AVS        → STRING
DT_AVS_FNC_CLI     → DATE
textos             → STRING
CD_CLI_AVS         → BIGINT
```

Uma conversão inválida que resulte em nulo será identificada pela validação de nulidade quando o campo for obrigatório.

Essa afirmação vale para a preparação Oracle. Na resolução anterior dos clientes, conversões de `CD_CLI` que resultem em nulo são filtradas antes da criação do snapshot e, portanto, não chegam à validação de nulidade Oracle.

### 11.4 Semântica de caracteres e strings vazias

Os três limites de texto do destino foram declarados em caracteres:

```text
VARCHAR2(64 CHAR)
VARCHAR2(255 CHAR)
VARCHAR2(1000 CHAR)
```

O `SUBSTRING` Spark também opera sobre a sequência textual, não sobre uma quantidade de bytes definida pelo pipeline. Não existe corte manual por byte.

O identificador também usa semântica `VARCHAR2(36 CHAR)`, mas não recebe `SUBSTRING`: excedente é bloqueante.

Após `TRIM`, título e texto podem se tornar `""`. O DataFrame preparado não possui uma validação explícita equivalente a:

```text
campo <> ""
```

No Oracle, string de comprimento zero é tratada como nula em colunas textuais. Como título e texto são `NOT NULL`, um valor vazio pode se manifestar somente na escrita JDBC, em vez de ser classificado antecipadamente como erro de contrato pelo validador atual.

### 11.5 Precisão numérica

`PC_NVL_CNFA_AVS` é convertido para `DECIMAL(4,2)` antes da validação de faixa. A validação observa o resultado dessa conversão, não um valor bruto anterior.

`CD_CLI_AVS` é convertido para `BIGINT` para a preparação e comparação Spark, mas a origem já foi reduzida ao `INT` do contrato Hive. A validação de 11 dígitos protege o limite declarado do Oracle, porém não elimina a restrição anterior do `INT`.

---

## 12. Matriz de validações

| Validação | Coluna ou conjunto | Momento | Resultado |
| --- | --- | --- | --- |
| Coluna obrigatória nula | Todos, exceto `TX_PRM_HDR_API_AVS` | Depois das conversões | Bloqueia |
| Chave duplicada | `CD_CLI_AVS`, `CD_IDFR_AVS` | Depois da normalização | Bloqueia |
| Identificador vazio | `CD_IDFR_AVS = ""` | Depois do `TRIM` | Bloqueia |
| Identificador maior que 36 | `CD_IDFR_AVS` | Antes da projeção final | Bloqueia |
| Confiança fora da faixa | `PC_NVL_CNFA_AVS` | Depois do `CAST` | Bloqueia |
| Cliente com mais de 11 dígitos | `CD_CLI_AVS` | Depois do `CAST` | Bloqueia |
| Título maior que 64 | `TX_TIT_AVS_FNC_CLI` | Depois do `SUBSTRING(1,64)` | O original já foi cortado |
| Texto maior que 255 | `TX_AVS_FNC_CLI` | Depois do `SUBSTRING(1,255)` | O original já foi cortado |
| Header maior que 1000 | `TX_PRM_HDR_API_AVS` | Depois do `SUBSTRING(1,1000)` | O original já foi cortado |
| DataFrame vazio | Conjunto preparado | Somente com `executar=True` | Bloqueia |
| Diferença pós-carga | Todas as sete colunas | Depois do reload | Bloqueia |

Principais códigos:

| Código | Significado |
| --- | --- |
| `CONTRATO_NULO_OBRIGATORIO` | Campo obrigatório nulo |
| `CONTRATO_CHAVE_DUPLICADA` | Duplicidade na chave Oracle |
| `ORACLE_LIMITE_FISICO_EXCEDIDO` | Valor preparado fora de limite bloqueante |
| `ORACLE_PUBLICACAO_BLOQUEADA_HIVE` | Hive ainda não confirmado |
| `ORACLE_CARGA_VAZIA` | Carga física preparada sem registros |
| `ORACLE_LEITURA_FALHOU` | Falha ao consultar Oracle |
| `ORACLE_COMANDO_FALHOU` | Falha durante comando de limpeza |
| `ORACLE_ESCRITA_FALHOU` | Falha durante o append JDBC |
| `ORACLE_POS_CARGA_DIVERGENTE` | Oracle final diferente do Hive preparado |

---

## 13. Comparação material

Antes de decidir pela recarga, a rotina lê do Oracle exatamente:

```text
PC_NVL_CNFA_AVS
CD_IDFR_AVS
DT_AVS_FNC_CLI
TX_TIT_AVS_FNC_CLI
TX_AVS_FNC_CLI
TX_PRM_HDR_API_AVS
CD_CLI_AVS
```

O conteúdo lido é projetado novamente pelo contrato Oracle.

Consequências:

* strings do Oracle também são comparadas após `TRIM`;
* números são comparados após conversão para o tipo Spark do contrato;
* a data é comparada como `DATE`;
* a ordem física das linhas não importa;
* quantidade de ocorrências importa.

A equivalência é verificada nos dois sentidos:

```text
Hive preparado EXCEPT ALL Oracle
Oracle EXCEPT ALL Hive preparado
```

Somente quando os dois resultados estão vazios os DataFrames são considerados materialmente equivalentes.

Qualquer diferença em qualquer uma das sete colunas pode provocar reload integral.

---

## 14. Modos de execução

### 14.1 Execução física

```text
executar=True
```

Regras:

* exige `hive_publicado=True`;
* relê `RCM_FNC_CLI` do Hive;
* bloqueia carga vazia;
* compara com o Oracle;
* executa reload somente se houver diferença;
* relê e valida o Oracle após o reload.

### 14.2 Simulação

```text
executar=False
```

Regras:

* usa o DataFrame final em memória;
* prepara e valida os atributos;
* lê o Oracle atual;
* calcula a diferença material;
* não executa `DELETE`;
* não executa append;
* não bloqueia por DataFrame vazio usando `ORACLE_CARGA_VAZIA`.

---

## 15. Regra de recarga

### 15.1 Quando não há diferença

```text
SEM_DIFERENCA_MATERIAL
```

O Oracle é preservado. Nenhum `DELETE` e nenhum append são executados.

### 15.2 Quando há diferença em simulação

```text
DRY_RUN_COM_DIFERENCA_MATERIAL
```

A rotina informa que a recarga seria necessária, mas não altera o Oracle.

### 15.3 Quando há diferença em execução física

```text
CARGA_EXECUTADA_DELETE_APPEND
```

A recarga usa:

```text
use_truncate=False
batchsize=5000
num_partitions=1
```

#### Limpeza

A tabela é esvaziada em lotes:

```sql
DELETE FROM <OWNER>.AVS_FNC_CLI
WHERE ROWNUM <= 5000
```

O processo:

1. consulta a quantidade restante;
2. executa um lote de `DELETE`;
3. confirma o comando;
4. repete até a tabela ficar vazia.

Não é utilizado `TRUNCATE`.

#### Append

Depois da limpeza:

* o DataFrame é reduzido para uma partição;
* a escrita ocorre por JDBC;
* o modo é `append`;
* o lote JDBC é de 5000 registros.

### 15.4 Ausência de atomicidade

Limpeza e escrita não formam uma única transação de ponta a ponta.

Durante uma recarga:

* a tabela pode ficar temporariamente vazia;
* uma falha pode ocorrer depois de parte ou de toda a limpeza;
* uma falha no append pode deixar a tabela vazia ou parcialmente carregada;
* uma nova tentativa exige avaliação operacional.

---

## 16. Validação posterior à carga

Depois do append, a rotina:

1. relê a `AVS_FNC_CLI`;
2. projeta o conteúdo pelo mesmo contrato;
3. repete a comparação material nos dois sentidos.

Quando existe divergência, o diagnóstico distingue:

* linha presente no Hive e ausente no Oracle;
* campo com valor diferente;
* linha extra no Oracle.

Para linhas originadas no Hive, o diagnóstico recupera:

```text
NR_IDFR_PROJ
NR_IDFR_RCM
NR_VRS_VLDD_RCM
CD_IDFR_AVS
CD_CLI
CD_CLI_AVS
campo
valor_hive
valor_oracle
tipo_divergencia
```

Se a divergência persistir, a rotina lança:

```text
ORACLE_POS_CARGA_DIVERGENTE
```

A publicação só é considerada concluída quando o Oracle pós-carga é materialmente equivalente ao Hive preparado.

---

## 17. Cenários negociais da entrega

| Situação da campanha | Existência de histórico | Resultado na visão corrente | Resultado esperado na `AVS_FNC_CLI` |
| --- | --- | --- | --- |
| Vigente, atual e processada com sucesso | Com ou sem histórico | Novo snapshot completo | Clientes do novo snapshot |
| Vigente e sem nova execução necessária | Com histórico | Última foto preservada | Clientes da última foto |
| Vigente com falha pontual | Com histórico | Última foto preservada | Clientes da última foto |
| Vigente com falha na primeira vinculação | Sem histórico | Sem foto disponível | Campanha ainda ausente |
| Expirada | Qualquer | Excluída da visão corrente | Linhas removidas no próximo reload |
| Finalizada | Qualquer | Excluída da visão corrente | Linhas removidas no próximo reload |
| Registro não atual | Qualquer | Excluído da visão corrente | Linhas não publicadas |
| Registro encerrado | Qualquer | Excluído da visão corrente | Linhas não publicadas |

---

## 18. Garantias após uma publicação bem-sucedida

Uma publicação Oracle concluída garante:

* as sete colunas estão no contrato esperado;
* os campos obrigatórios não estão nulos no DataFrame preparado;
* a chave `CD_CLI_AVS + CD_IDFR_AVS` não está duplicada;
* identificadores não estão vazios nem acima do limite;
* o nível de confiança está dentro da faixa implementada;
* o código do cliente respeita o limite de dígitos implementado;
* o Oracle é materialmente equivalente ao Hive preparado;
* campanhas ausentes da visão corrente não permanecem na tabela após reload;
* a entrega representa uma foto corrente, não um histórico.

---

## 19. Comportamentos e limitações que precisam permanecer visíveis

### 19.1 Identificador temporário

`CD_IDFR_AVS` contém atualmente somente `NR_IDFR_RCM` como texto. O projeto não é publicado em coluna própria.

### 19.2 Truncamento silencioso

Título, texto e parâmetro de header são cortados antes da validação de comprimento. O conteúdo publicado pode ser menor que o conteúdo de origem sem que a carga seja interrompida.

### 19.3 Strings vazias

Existe validação específica de vazio para `CD_IDFR_AVS`.

Não existe validação equivalente, na preparação Oracle, para título ou texto compostos apenas por espaços. Após `TRIM`, esses valores podem se tornar strings vazias.

### 19.4 Confiança fixa

O percentual de confiança não é calculado por recomendação. O valor atual é sempre `99.00`.

### 19.5 Texto de acionamento não publicado

`TX_ACMT_PDRO_AVS` permanece no Hive, mas não é entregue à `AVS_FNC_CLI`.

### 19.6 Ausência de projeto e versão

Projeto e versão permanecem disponíveis para rastreabilidade no Hive, mas não existem como atributos físicos da `AVS_FNC_CLI`.

### 19.7 Recarga não atômica

O processo de `DELETE + append` admite uma janela temporária de tabela vazia ou parcialmente carregada.

### 19.8 Capacidade intermediária do cliente

`CD_CLI_AVS` é `NUMBER(11)` no Oracle, mas `CD_CLI` é `INT` nas tabelas Hive corrente e histórica. O contrato intermediário, e não o DDL final, determina quais códigos conseguem chegar à publicação.

Esse ponto deve ser reavaliado se o domínio real de clientes utilizar valores fora da faixa do `INT`.

### 19.9 Conversão rejeitada antes do Oracle

Clientes cujo valor não possa ser convertido para o tipo interno podem ser eliminados ainda em `resolver_clientes_origem`, antes de qualquer validação da `AVS_FNC_CLI`.

Essa eliminação ocorre antes do snapshot e reduz a população da campanha. Ela não deve ser confundida com rejeição JDBC ou com divergência pós-carga.

---

## 20. Exemplo completo

### 20.1 Contexto Hive

```text
NR_IDFR_PROJ          = 10
NR_IDFR_RCM           = 25
NR_VRS_VLDD_RCM       = 3
CD_CLI                = 12345678901
DT_AVS_FNC_CLI        = 2026-07-30
TX_TIT_PDRO_AVS       = "  Consórcio para você  "
TX_STIT_PDRO_AVS      = "  Conheça as opções disponíveis  "
TX_PRM_HDR_API_AVS    = NULL
PC_NVL_CNFA_AVS       = 99.00
```

### 20.2 Identificador atual

```text
CD_IDFR_AVS = "25"
```

### 20.3 Linha preparada para Oracle

```text
PC_NVL_CNFA_AVS     = 99.00
CD_IDFR_AVS         = "25"
DT_AVS_FNC_CLI      = 2026-07-30
TX_TIT_AVS_FNC_CLI  = "Consórcio para você"
TX_AVS_FNC_CLI      = "Conheça as opções disponíveis"
TX_PRM_HDR_API_AVS  = NULL
CD_CLI_AVS          = 12345678901
```

### 20.4 Campos de contexto descartados

```text
NR_IDFR_PROJ
NR_IDFR_RCM
NR_VRS_VLDD_RCM
```

Esses campos apoiam a rastreabilidade da preparação, mas não fazem parte do registro gravado na `AVS_FNC_CLI`.

---

## 21. Checklist especializado da publicação

Antes de autorizar a carga:

* confirmar que a publicação Hive terminou com sucesso;
* confirmar que `RCM_FNC_CLI` representa a visão corrente esperada;
* confirmar que a quantidade preparada é maior que zero;
* conferir quantidade de clientes por `CD_IDFR_AVS`;
* conferir se o identificador segue a regra temporária vigente;
* verificar risco de repetição de `NR_IDFR_RCM` entre projetos;
* verificar nulos obrigatórios;
* verificar duplicidade por cliente e aviso;
* verificar comprimentos originais dos textos, pois o código os corta;
* confirmar que o header pode ser nulo quando não aplicável;
* confirmar que o valor de confiança esperado é `99.00`;
* conferir a diferença material antes da recarga;
* reconhecer que `DELETE + append` não é atômico.

Depois da carga:

* conferir `qtd_oracle_depois`;
* confirmar `carga_executada=True`;
* confirmar `motivo=CARGA_EXECUTADA_DELETE_APPEND`;
* confirmar ausência de `ORACLE_POS_CARGA_DIVERGENTE`;
* comparar a quantidade final com `qtd_hive_preparado`;
* analisar imediatamente qualquer falha de escrita ou divergência.

---

## 22. Fontes de verdade utilizadas

Este documento foi construído a partir de:

* [`2_contrato.ipynb`](../jobs/2_contrato.ipynb): tipos, limites, mapeamentos e valor oficial de confiança;
* [`4_sincronizacao.ipynb`](../jobs/4_sincronizacao.ipynb): seleção da versão, aviso e metadados;
* [`6_vinculacao.ipynb`](../jobs/6_vinculacao.ipynb): geração do snapshot e formação da visão corrente;
* [`7_publicar_hive.ipynb`](../jobs/7_publicar_hive.ipynb): confirmação da visão Hive oficial;
* [`8_publicar_oracle.ipynb`](../jobs/8_publicar_oracle.ipynb): preparação, comparação e publicação Oracle;
* [`1_utils.ipynb`](../jobs/1_utils.ipynb): projeção por contrato, validações e comparação material;
* [`gerenciador_sessao_spark_remoto.ipynb`](../utils/gerenciador_sessao_spark_remoto.ipynb): limpeza e escrita JDBC;
* [`TABELA_ORACLE_PRODUCAO.md`](../../TABELA_ORACLE_PRODUCAO.md): DDL físico de referência.
