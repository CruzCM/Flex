## Encerramento da execução Hive (`9_encerrar_execucao.ipynb`)

### Entrada

O encerramento da execução Hive (`9_encerrar_execucao.ipynb`) finaliza a parte Hive do fluxo depois da publicação das tabelas oficiais.

A etapa recebe o resultado da publicação Hive e decide se os temporários de controle operacional podem ser removidos com segurança.

Seu objetivo é preservar rastreabilidade quando a publicação Hive não foi concluída e limpar os temporários técnicos quando a publicação Hive terminou com sucesso.

A etapa recebe:

* caminho HDFS de apoio (`path_save_hdfs`);
* efeito físico habilitado (`executar=True`);
* indicador de publicação Hive concluída (`publicacao_hive_concluida`);
* estatísticas consolidadas das etapas anteriores (`stats`);
* contexto operacional da execução (`contexto`).

A etapa atua sobre os seguintes temporários da tabela de controle:

* foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`);
* materialização técnica da tabela de controle final (`temp_lineage_CTL_OPRL_RCM`).

---

### Execução

A rotina resolve os caminhos HDFS dos temporários de controle a partir do caminho HDFS de apoio (`path_save_hdfs`).

Em seguida, avalia se a publicação Hive foi concluída com sucesso.

A decisão principal da etapa é simples:

```text
Hive publicado com sucesso
    → remove os temporários técnicos de controle

Hive não publicado com sucesso
    → preserva os temporários técnicos de controle
```

A remoção dos temporários é tratada como encerramento seguro da parte Hive do fluxo.

Se um temporário já não existir, a limpeza desse temporário será considerada concluída.

---

#### Cenário 1 — Publicação Hive não concluída

Se a publicação Hive não tiver sido concluída com sucesso (`publicacao_hive_concluida=False`), então a rotina preserva os temporários de controle.

Nesse cenário, a limpeza não será considerada concluída:

```text
limpeza_temporarios_ok = False
```

A preservação dos temporários permite análise operacional posterior e evita remover evidências ou pontos de recuperação quando a publicação Hive não terminou corretamente.

---

#### Cenário 2 — Publicação Hive concluída e temporários removidos

Se a publicação Hive tiver sido concluída com sucesso (`publicacao_hive_concluida=True`), então a rotina tenta remover os temporários de controle.

A rotina remove ou confirma a inexistência dos seguintes caminhos:

* foto segura da tabela de controle (`temp_backup_CTL_OPRL_RCM`);
* materialização técnica da tabela de controle final (`temp_lineage_CTL_OPRL_RCM`).

Se os dois temporários forem removidos ou já estiverem inexistentes, então a limpeza será considerada concluída:

```text
limpeza_temporarios_ok = True
```

Esse é o encerramento esperado da parte Hive do fluxo.

---

#### Cenário 3 — Falha na limpeza dos temporários

Se a publicação Hive tiver sido concluída, mas a rotina não conseguir remover algum temporário de controle, então a limpeza será considerada não concluída:

```text
limpeza_temporarios_ok = False
```

Nesse cenário, a rotina registra a falha e retorna o resultado consolidado da execução Hive.

A falha de limpeza não apaga o resultado da publicação Hive já realizada.

Porém, ela impede que a execução seja tratada como encerrada com segurança.

A rotina principal utiliza esse resultado para bloquear a publicação Oracle quando a limpeza HDFS não for concluída.

---

#### Falhas críticas da etapa

Algumas falhas impedem o encerramento correto da etapa.

Se o caminho HDFS de apoio (`path_save_hdfs`) estiver vazio ou inválido, então a rotina não consegue resolver os caminhos dos temporários de controle.

Se ocorrer uma falha inesperada antes da formação do resultado de encerramento, então a execução será interrompida pela rotina principal.

Falhas durante a remoção física dos temporários são registradas no resultado da etapa por meio do indicador de limpeza:

```text
limpeza_temporarios_ok = False
```

---

### Resultado

Ao final, o encerramento da execução Hive entrega um resultado consolidado da parte Hive do fluxo (`resultado_fluxo_hive`).

Esse resultado preserva o contexto operacional recebido e acrescenta:

* estatísticas consolidadas das etapas anteriores (`stats`);
* indicador de limpeza dos temporários (`limpeza_temporarios_ok`).

Se a publicação Hive não tiver sido concluída, então:

```text
limpeza_temporarios_ok = False
```

Se a publicação Hive tiver sido concluída e os temporários forem removidos ou já estiverem inexistentes, então:

```text
limpeza_temporarios_ok = True
```

Se a publicação Hive tiver sido concluída, mas algum temporário não puder ser removido, então:

```text
limpeza_temporarios_ok = False
```

O indicador de limpeza dos temporários (`limpeza_temporarios_ok`) é utilizado pela rotina principal para decidir se a publicação Oracle poderá seguir.

Se a limpeza HDFS não for concluída, então a publicação Oracle será bloqueada por segurança.
