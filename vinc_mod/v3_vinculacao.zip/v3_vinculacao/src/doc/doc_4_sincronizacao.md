## Sincronização Oracle x Hive (`4_sincronizacao.ipynb`)

### Entrada

A sincronização Oracle x Hive (`4_sincronizacao.ipynb`) atualiza o controle operacional das campanhas acompanhadas pelo fluxo.

Cada campanha é representada por uma recomendação cadastrada no Oracle.

A etapa recebe a tabela de controle validada pela preparação (`df_ctl_oprl_rcm`) e compara seu conteúdo com o estado atual das recomendações no Oracle.

Seu objetivo é decidir quais campanhas podem entrar no controle, quais continuam válidas, quais devem ser encerradas, quais precisam assumir uma versão diferente e quais devem ser bloqueadas para evitar uma alteração insegura.

A etapa recebe:

* tabela de controle validada pela preparação (`df_ctl_oprl_rcm`);
* schema Oracle (`oracle_schema`);
* cliente de acesso Oracle (`cliente_oracle`);
* cliente DB2 utilizado para leitura das origens (`cliente_db2`);
* data operacional (`hoje`), carregada da variável de ambiente (`HOJE`).

Para identificar o estado atual das campanhas, a etapa consulta:

* recomendações validadas (`RCM_VLDD`);
* versões das recomendações (`RCM_VRS`);
* avisos selecionados (`AVS_SELD`);
* públicos cadastrados (`PBCO_CADD`).

---

### Execução

#### Como uma campanha entra no controle

Uma campanha entra no controle operacional quando sua recomendação está vigente no Oracle e possui uma versão validada apta ao processamento.

A abertura somente acontece quando a rotina consegue confirmar com segurança:

* a consistência do estado da recomendação;
* a existência da versão validada aprovada;
* a existência de um único aviso selecionado aplicável;
* a presença dos dados necessários do aviso e do público;
* a identificação da origem utilizada para localizar clientes elegíveis;
* a leitura da origem;
* a aplicação do escopo do público;
* a identificação da forma de referência da origem.

Se essas condições forem atendidas, então a rotina abre uma linha atual para a campanha e a marca para processamento:

```text id="6c1vvs"
IN_REG_ATU = S
IN_EXEA_PND = S
TS_INC_REG = hoje
TS_FIM_REG = nulo
```

Se a recomendação ainda não estiver vigente, então nenhuma linha será aberta.

Se os dados não permitirem uma abertura segura, então a campanha será bloqueada nesta execução e o motivo será registrado.

A mesma regra se aplica quando a campanha nunca entrou no controle e quando já existe histórico anterior, mas nenhuma linha atual permanece aberta.

---

#### Tipos de linha da tabela de controle

A tabela de controle operacional (`CTL_OPRL_RCM`) registra o ciclo de vida das campanhas por meio de dois tipos de linha:

* linha atual (`IN_REG_ATU = S`);
* linha histórica (`IN_REG_ATU = N`).

A linha atual representa a situação operacional vigente da campanha.

Cada recomendação pode possuir, no máximo, uma linha atual.

A linha histórica preserva uma situação anterior já encerrada.

Quando uma campanha termina ou assume uma versão validada diferente, sua linha atual é encerrada e passa a compor o histórico:

```text id="yqdgny"
IN_REG_ATU = N
TS_FIM_REG = hoje
```

Linhas históricas não são reabertas, removidas ou recalculadas.

---

#### Regras de consistência do Oracle

Antes de atualizar o controle, a rotina classifica o estado de cada recomendação no Oracle.

Uma recomendação somente pode seguir pelo fluxo automático quando seus dados permitirem uma decisão segura.

A rotina bloqueia a recomendação quando identificar inconsistências como:

* estado da recomendação fora do domínio esperado;
* estado da versão fora do domínio esperado;
* versão proposta inexistente;
* versão proposta igual a zero;
* versão validada superior à versão proposta;
* versão validada informada sem uma versão aprovada correspondente.

O bloqueio afeta somente a recomendação inconsistente.

As demais continuam sendo sincronizadas.

---

#### Ciclo de vida operacional da campanha

Após validar os dados gerais, a rotina compara o controle existente com o estado atual do Oracle.

A decisão depende da situação encontrada.

| Situação encontrada                                              | Decisão operacional                            |
| ---------------------------------------------------------------- | ---------------------------------------------- |
| Linha histórica já encerrada                                     | Preserva o histórico sem alteração.            |
| Linha atual sem recomendação correspondente no Oracle            | Encerra a linha atual.                         |
| Linha atual com recomendação inconsistente no Oracle             | Preserva a linha atual e bloqueia a alteração. |
| Linha atual com recomendação expirada ou finalizada              | Encerra a linha atual.                         |
| Linha atual com recomendação ainda não vigente                   | Mantém a linha atual sem alteração.            |
| Linha atual com recomendação vigente e mesma versão validada     | Mantém a linha atual sem alteração.            |
| Linha atual com recomendação vigente e versão validada diferente | Tenta substituir a linha atual com segurança.  |
| Recomendação vigente sem linha atual                             | Tenta abrir uma linha atual com segurança.     |
| Recomendação não vigente sem linha atual                         | Não abre uma linha nesta execução.             |
| Recomendação inconsistente sem linha atual                       | Bloqueia a abertura.                           |

---

#### Cenário 1 — Linha histórica preservada

Se uma linha já estiver encerrada (`IN_REG_ATU = N`), então ela será preservada sem alteração.

Esse comportamento mantém a rastreabilidade das situações anteriores da campanha.

---

#### Cenário 2 — Campanha encerrada

Se uma campanha possuir linha atual (`IN_REG_ATU = S`), mas sua recomendação não existir mais no snapshot Oracle, então a rotina encerra a linha atual.

A mesma decisão é aplicada quando a recomendação estiver expirada ou finalizada.

A linha passa a representar histórico:

```text id="keq78j"
IN_REG_ATU = N
TS_FIM_REG = hoje
```

Nenhuma nova linha é criada.

---

#### Cenário 3 — Campanha mantida sem alteração

Se uma campanha possuir linha atual e sua recomendação ainda não estiver vigente, então a rotina mantém o estado existente sem alteração.

Se a recomendação estiver vigente, mas a versão validada continuar sendo a mesma (`NR_VRS_VLDD_RCM`), então a linha atual também será mantida.

Nesse cenário, não existe mudança operacional aplicável.

---

#### Cenário 4 — Campanha com versão validada diferente

Se uma campanha possuir linha atual, continuar vigente e apresentar uma versão validada diferente da versão registrada na tabela de controle, então a rotina tenta preparar uma substituição segura.

Antes de substituir a linha atual, a rotina valida novamente os dados necessários do aviso, do público e da origem.

Se a substituição puder ser realizada com segurança, então a rotina:

* encerra a linha atual anterior;
* preserva essa linha como histórico;
* abre uma nova linha atual;
* marca a nova linha para processamento.

A linha anterior passa a representar histórico:

```text id="jyhb2u"
IN_REG_ATU = N
TS_FIM_REG = hoje
```

A nova linha passa a representar o estado operacional vigente:

```text id="nf6gik"
IN_REG_ATU = S
IN_EXEA_PND = S
TS_INC_REG = hoje
TS_FIM_REG = nulo
```

Se a substituição não puder ser preparada com segurança, então a rotina preserva a linha atual anterior e bloqueia a alteração.

O motivo do bloqueio será registrado.

---

#### Cenário 5 — Campanha aberta no controle

Se uma recomendação estiver vigente e não possuir linha atual na tabela de controle, então a rotina tenta abrir um novo estado operacional.

Se a abertura puder ser preparada com segurança, então a rotina cria uma linha atual e a marca para processamento:

```text id="saipku"
IN_REG_ATU = S
IN_EXEA_PND = S
TS_INC_REG = hoje
TS_FIM_REG = nulo
```

Se a recomendação ainda não estiver vigente, então nenhuma linha será criada.

Se a abertura não puder ser preparada com segurança, então a rotina bloqueia a campanha nesta execução e registra o motivo.

---

#### Cenário 6 — Campanha bloqueada

Se os dados de uma recomendação não permitirem uma decisão segura, então a rotina bloqueia somente essa campanha.

Quando já existir uma linha atual, ela será preservada sem alteração.

Quando não existir linha atual, nenhuma linha será criada.

O bloqueio pontual evita que uma inconsistência isolada interrompa o processamento das demais campanhas.

---

#### Falhas críticas da etapa

Algumas falhas impedem a continuidade de toda a sincronização.

Se a tabela de controle recebida estiver inválida (`df_ctl_oprl_rcm`), então a execução será interrompida.

Se o snapshot Oracle não puder ser lido ou validado com segurança, então a execução também será interrompida.

Depois de aplicar todas as decisões, a rotina valida novamente a estrutura e a consistência operacional da tabela de controle atualizada.

Se a tabela resultante estiver inválida, então a execução será interrompida.

---

### Resultado

Ao final, a sincronização entrega:

* tabela de controle atualizada (`df_ctl_oprl_rcm`);
* estatísticas da sincronização (`stats`).

A tabela entregue preserva o histórico anterior e incorpora as decisões aplicáveis a cada campanha:

* campanhas abertas para processamento;
* campanhas mantidas sem alteração;
* campanhas encerradas;
* versões anteriores encerradas e substituídas;
* campanhas inconsistentes bloqueadas pontualmente.

A sincronização altera somente a versão lógica da tabela de controle em memória.

A publicação física ocorrerá em etapa posterior.

Se a sincronização terminar com sucesso, então a tabela de controle atualizada (`df_ctl_oprl_rcm`) segue para a verificação das origens (`5_verificacao_origem.ipynb`).