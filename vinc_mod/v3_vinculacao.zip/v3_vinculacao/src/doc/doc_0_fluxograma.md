# Fluxograma Negocial — Fluxo Operacional de Recomendações e Avisos por Cliente

## Objetivo

Este documento apresenta o fluxograma negocial completo do fluxo operacional de recomendações e avisos por cliente.

O objetivo é mostrar, de forma operacional e rastreável:

* como a rotina escolhe a fonte confiável do controle;
* como sincroniza o controle Hive com o estado cadastral do Oracle;
* como identifica mudanças nas origens;
* como vincula clientes às recomendações;
* como publica os resultados no Hive;
* como encerra a execução Hive com segurança;
* como publica a visão corrente no Oracle, quando permitido.

A documentação não descreve o código linha por linha.

O foco é mostrar:

```text
o que cada etapa decide
quando a rotina segue
quando preserva estado
quando bloqueia apenas uma campanha
quando interrompe toda a execução
quando publica fisicamente os dados
```

---

# 1. Nomenclatura oficial usada neste fluxograma

## 1.1 Tabelas Hive

| Papel no fluxo                                  | Nome físico        |
| ----------------------------------------------- | ------------------ |
| Tabela oficial de controle operacional          | `CTL_OPRL_RCM`     |
| Visão corrente de clientes vinculados           | `RCM_FNC_CLI`      |
| Visão histórica/eventual de clientes vinculados | `RCM_FNC_CLI_EVTL` |

## 1.2 Tabelas Oracle usadas na sincronização

| Papel no fluxo            | Nome físico |
| ------------------------- | ----------- |
| Recomendações validadas   | `RCM_VLDD`  |
| Versões das recomendações | `RCM_VRS`   |
| Avisos selecionados       | `AVS_SELD`  |
| Públicos cadastrados      | `PBCO_CADD` |

## 1.3 Tabela Oracle publicada para consumo

| Papel no fluxo                                | Nome físico   |
| --------------------------------------------- | ------------- |
| Avisos ativos por cliente consumidos pela API | `AVS_FNC_CLI` |

## 1.4 Temporários HDFS operacionais

| Temporário                  | Papel no fluxo                                     | Regra de uso                                                                                                          |
| --------------------------- | -------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| `temp_backup_CTL_OPRL_RCM`  | Foto segura da tabela de controle                  | Preserva o último estado operacional conhecido antes do ciclo de processamento.                                       |
| `temp_lineage_CTL_OPRL_RCM` | Materialização técnica da tabela de controle final | Quebra a linhagem Spark antes das escritas Hive finais e serve de origem validada para o overwrite final do controle. |

Regras principais:

* a foto segura (`temp_backup_CTL_OPRL_RCM`) é usada para recuperação automática quando uma execução anterior não encerrou corretamente;
* a materialização técnica (`temp_lineage_CTL_OPRL_RCM`) não é uma tabela de negócio;
* a materialização técnica é criada antes das escritas Hive finais;
* o overwrite final da tabela oficial de controle (`CTL_OPRL_RCM`) usa a materialização técnica validada;
* os temporários são removidos somente no encerramento Hive, quando a publicação Hive foi concluída com sucesso;
* se a limpeza HDFS falhar, a publicação Oracle é bloqueada por segurança.

## 1.5 Indicadores principais

| Conceito operacional             | Nome técnico         |
| -------------------------------- | -------------------- |
| Linha atual                      | `IN_REG_ATU = S`     |
| Linha histórica                  | `IN_REG_ATU = N`     |
| Execução pendente ligada         | `IN_EXEA_PND = S`    |
| Execução pendente desligada      | `IN_EXEA_PND = N`    |
| Recomendação vigente             | `CD_EST_RCM = 3`     |
| Início do registro               | `TS_INC_REG`         |
| Fim do registro                  | `TS_FIM_REG`         |
| Última data observada na origem  | `TS_ULT_DT_OBSD_OGM` |
| Última data processada da origem | `TS_ULT_DT_PRCD_OGM` |
| Quantidade de dados da origem    | `QT_DADO_OGM`        |
| Tipo de escopo da origem         | `CD_TIP_ECP_OGM`     |
| Forma de referência da origem    | `CD_FMA_REF_OGM`     |

---

# 2. Visão macro do fluxo

```text
┌──────────────────────────────────────┐
│ INÍCIO DA ROTINA                     │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ 3. PREPARAÇÃO DO CONTROLE            │
│ Define a fonte confiável do ciclo    │
│ CTL_OPRL_RCM ou temp_backup          │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ 4. SINCRONIZAÇÃO ORACLE x HIVE       │
│ Atualiza o controle lógico           │
│ conforme estado atual do Oracle      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ 5. VERIFICAÇÃO DAS ORIGENS           │
│ Observa mudanças em campanhas        │
│ vigentes, atuais, abertas e sem      │
│ execução pendente                    │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ 6. VINCULAÇÃO DE CLIENTES            │
│ Gera snapshots das campanhas         │
│ pendentes e remonta a visão corrente │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ 7. PUBLICAÇÃO HIVE                   │
│ Publica RCM_FNC_CLI,                │
│ RCM_FNC_CLI_EVTL e CTL_OPRL_RCM      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ 9. ENCERRAMENTO HIVE/HDFS            │
│ Remove temporários quando a          │
│ publicação Hive concluiu             │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ 8. PUBLICAÇÃO ORACLE                 │
│ Atualiza AVS_FNC_CLI quando a        │
│ execução Hive foi encerrada com      │
│ segurança                            │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ FIM DA ROTINA                        │
└──────────────────────────────────────┘
```

---

# 3. Preparação do controle operacional

## 3.1 Objetivo operacional

A preparação define qual conteúdo confiável será usado como ponto de partida da execução.

Ela decide se o fluxo deve iniciar a partir de:

* tabela oficial vazia, em primeira carga (`CTL_OPRL_RCM`);
* foto segura de uma execução anterior (`temp_backup_CTL_OPRL_RCM`);
* tabela oficial preenchida, em execução normal (`CTL_OPRL_RCM`).

---

## 3.2 Fluxo macro da preparação

```text
┌──────────────────────────────────────┐
│ INÍCIO DA PREPARAÇÃO                 │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VERIFICA TIPO DE EXECUÇÃO            │
│ primeira_carga                       │
└──────────────────┬───────────────────┘
                   │
      ┌────────────┴────────────┐
      │                         │
      ▼                         ▼
┌───────────────┐        ┌─────────────────────┐
│ PRIMEIRA      │        │ EXECUÇÃO NORMAL      │
│ CARGA         │        │ primeira_carga=False │
└───────┬───────┘        └──────────┬──────────┘
        │                           │
        ▼                           ▼
┌──────────────────────┐   ┌──────────────────────┐
│ EXIGE CTL_OPRL_RCM   │   │ VERIFICA SE EXISTE   │
│ VÁLIDA E VAZIA       │   │ temp_backup           │
└───────┬──────────────┘   └──────────┬───────────┘
        │                             │
        ▼                             ▼
┌──────────────────────┐      ┌──────────────────────┐
│ REMOVE TEMPORÁRIOS   │      │ SE EXISTE BACKUP     │
│ ANTIGOS              │      │ VALIDA E USA BACKUP  │
└───────┬──────────────┘      └──────────┬───────────┘
        │                                │
        │                                ▼
        │                       ┌──────────────────────┐
        │                       │ SE NÃO EXISTE BACKUP │
        │                       │ USA CTL_OFICIAL      │
        │                       │ VÁLIDA E PREENCHIDA  │
        │                       └──────────┬───────────┘
        │                                  │
        ▼                                  ▼
┌──────────────────────────────────────────────┐
│ ENTREGA df_ctl_oprl_rcm                      │
│ fonte confiável do ciclo                     │
└──────────────────────────────────────────────┘
```

---

## 3.3 Primeira carga

```text
┌──────────────────────────────────────┐
│ primeira_carga = True                │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ LÊ CTL_OPRL_RCM                      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ CTL_OPRL_RCM EXISTE, É VÁLIDA        │
│ E ESTÁ VAZIA?                        │
└───────┬───────────────────────┬──────┘
        │ Sim                   │ Não
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ REMOVE TEMPORÁRIOS   │   │ INTERROMPE EXECUÇÃO  │
│ ANTIGOS              │   └──────────────────────┘
└──────────┬───────────┘
           │
           ▼
┌──────────────────────────────────────┐
│ ENTREGA CTL_OPRL_RCM VAZIA           │
│ COMO df_ctl_oprl_rcm                 │
└──────────────────────────────────────┘
```

Regras:

* primeira carga exige tabela oficial existente, válida e vazia;
* se a tabela oficial possuir registros, a execução é interrompida;
* temporários antigos são removidos antes da continuidade;
* o primeiro estado operacional será criado na sincronização Oracle x Hive.

---

## 3.4 Execução normal com foto segura

```text
┌──────────────────────────────────────┐
│ primeira_carga = False               │
│ temp_backup_CTL_OPRL_RCM EXISTE      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VALIDA temp_backup_CTL_OPRL_RCM      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ FOTO SEGURA VÁLIDA E PREENCHIDA?     │
└───────┬───────────────────────┬──────┘
        │ Sim                   │ Não
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ USA FOTO SEGURA      │   │ INTERROMPE EXECUÇÃO  │
│ COMO FONTE DA        │   │ PARA ANÁLISE         │
│ VERDADE              │   └──────────────────────┘
└──────────┬───────────┘
           │
           ▼
┌──────────────────────────────────────┐
│ ENTREGA BACKUP COMO                  │
│ df_ctl_oprl_rcm                      │
└──────────────────────────────────────┘
```

Regras:

* a foto segura indica que uma execução anterior não encerrou completamente;
* a foto segura válida prevalece sobre a tabela oficial;
* a tabela oficial não substitui automaticamente uma foto segura existente;
* a foto segura será removida somente após publicação Hive concluída.

---

## 3.5 Execução normal sem foto segura

```text
┌──────────────────────────────────────┐
│ primeira_carga = False               │
│ temp_backup_CTL_OPRL_RCM NÃO EXISTE  │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ LÊ CTL_OPRL_RCM                      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ CTL_OPRL_RCM VÁLIDA E PREENCHIDA?    │
└───────┬───────────────────────┬──────┘
        │ Sim                   │ Não
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ CRIA NOVA FOTO       │   │ INTERROMPE EXECUÇÃO  │
│ SEGURA               │   └──────────────────────┘
│ temp_backup          │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────────────────────┐
│ ENTREGA CTL_OPRL_RCM COMO            │
│ df_ctl_oprl_rcm                      │
└──────────────────────────────────────┘
```

---

# 4. Sincronização Oracle x Hive

## 4.1 Objetivo operacional

A sincronização compara a tabela de controle operacional (`CTL_OPRL_RCM`) com o estado atual das recomendações no Oracle.

Ela decide se cada campanha deve ser:

* preservada;
* mantida sem alteração;
* encerrada;
* substituída por nova versão;
* aberta no controle;
* bloqueada por inconsistência pontual.

---

## 4.2 Fluxo macro da sincronização

```text
┌──────────────────────────────────────┐
│ RECEBE df_ctl_oprl_rcm               │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VALIDA CONTROLE RECEBIDO             │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ LÊ SNAPSHOT ORACLE                   │
│ RCM_VLDD + RCM_VRS +                 │
│ AVS_SELD + PBCO_CADD                 │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ CLASSIFICA ESTADO DE CADA            │
│ RECOMENDAÇÃO                         │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ COMPARA CONTROLE HIVE x ORACLE       │
└──────────────────┬───────────────────┘
                   │
      ┌────────────┼───────────────┬───────────────┬───────────────┐
      │            │               │               │               │
      ▼            ▼               ▼               ▼               ▼
┌──────────┐ ┌──────────┐ ┌────────────┐ ┌──────────────┐ ┌──────────────┐
│ PRESERVA │ │ MANTÉM   │ │ ENCERRA    │ │ SUBSTITUI    │ │ ABRE OU      │
│ HISTÓRICO│ │ ATUAL    │ │ ATUAL      │ │ VERSÃO       │ │ BLOQUEIA     │
└────┬─────┘ └────┬─────┘ └─────┬──────┘ └──────┬───────┘ └──────┬───────┘
     │            │             │                │                │
     └────────────┴─────────────┴────────────────┴────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────┐
│ VALIDA CONTROLE ATUALIZADO           │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ ENTREGA df_ctl_oprl_rcm              │
│ PARA VERIFICAÇÃO DE ORIGEM           │
└──────────────────────────────────────┘
```

---

## 4.3 Decisões da sincronização

| Situação encontrada                                   | Decisão operacional                  |
| ----------------------------------------------------- | ------------------------------------ |
| Linha histórica já encerrada                          | Preserva sem alteração.              |
| Linha atual sem recomendação correspondente no Oracle | Encerra a linha atual.               |
| Linha atual com recomendação expirada ou finalizada   | Encerra a linha atual.               |
| Linha atual com recomendação ainda não vigente        | Mantém sem alteração.                |
| Linha atual com mesma versão validada                 | Mantém sem alteração.                |
| Linha atual com versão validada diferente             | Tenta substituir com segurança.      |
| Recomendação vigente sem linha atual                  | Tenta abrir nova linha atual.        |
| Recomendação inconsistente                            | Bloqueia somente a campanha afetada. |

---

## 4.4 Encerramento de campanha

```text
┌──────────────────────────────────────┐
│ LINHA ATUAL EXISTE                   │
│ IN_REG_ATU = S                       │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ RECOMENDAÇÃO AUSENTE, EXPIRADA       │
│ OU FINALIZADA NO ORACLE              │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ ENCERRA LINHA ATUAL                  │
│ IN_REG_ATU = N                       │
│ TS_FIM_REG = hoje                    │
└──────────────────────────────────────┘
```

---

## 4.5 Substituição de versão

```text
┌──────────────────────────────────────┐
│ LINHA ATUAL EXISTE                   │
│ RECOMENDAÇÃO CONTINUA VIGENTE        │
│ VERSÃO VALIDADA MUDOU                │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VALIDA AVISO, PÚBLICO E ORIGEM       │
│ PARA NOVA VERSÃO                     │
└───────┬───────────────────────┬──────┘
        │ Seguro                │ Inseguro
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ ENCERRA LINHA ATUAL  │   │ PRESERVA LINHA ATUAL │
│ E ABRE NOVA LINHA    │   │ E BLOQUEIA ALTERAÇÃO │
│ PENDENTE             │   └──────────────────────┘
└──────────────────────┘
```

---

## 4.6 Abertura de nova campanha

```text
┌──────────────────────────────────────┐
│ RECOMENDAÇÃO VIGENTE NO ORACLE       │
│ SEM LINHA ATUAL NO CONTROLE          │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VALIDA DADOS NECESSÁRIOS             │
│ AVISO + PÚBLICO + ORIGEM             │
└───────┬───────────────────────┬──────┘
        │ Seguro                │ Inseguro
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ ABRE LINHA ATUAL     │   │ BLOQUEIA ABERTURA    │
│ IN_EXEA_PND = S      │   │ NESTA EXECUÇÃO       │
└──────────────────────┘   └──────────────────────┘
```

---

# 5. Verificação de mudanças nas origens

## 5.1 Objetivo operacional

A verificação de origem observa campanhas vigentes, atuais, abertas e sem execução pendente.

Ela decide se uma campanha deve permanecer desligada ou ser religada para novo processamento.

---

## 5.2 Fluxo macro da verificação

```text
┌──────────────────────────────────────┐
│ RECEBE CONTROLE ATUALIZADO           │
│ df_ctl_oprl_rcm                      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VALIDA CONTROLE RECEBIDO             │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ SELECIONA CAMPANHAS OBSERVÁVEIS      │
│ IN_REG_ATU = S                       │
│ CD_EST_RCM = 3                       │
│ IN_EXEA_PND = N                      │
│ TS_FIM_REG = nulo                    │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ LÊ ORIGEM E APLICA ESCOPO            │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ COMPARA REFERÊNCIA                   │
│ DATA OU QUANTIDADE                   │
└───────┬───────────────────────┬──────┘
        │ Mudou ou faltou ref.  │ Não mudou
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ RELIGA CAMPANHA      │   │ MANTÉM DESLIGADA     │
│ IN_EXEA_PND = S      │   │ IN_EXEA_PND = N      │
└──────────┬───────────┘   └──────────┬───────────┘
           │                          │
           └────────────┬─────────────┘
                        ▼
┌──────────────────────────────────────┐
│ VALIDA CONTROLE ATUALIZADO           │
└──────────────────────────────────────┘
```

---

## 5.3 Campanha fora da observação

```text
┌──────────────────────────────────────┐
│ CAMPANHA NÃO ATENDE AOS FILTROS      │
│ DE OBSERVAÇÃO                        │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PRESERVA LINHA SEM ALTERAÇÃO         │
└──────────────────────────────────────┘
```

Inclui:

* linha histórica (`IN_REG_ATU = N`);
* recomendação não vigente (`CD_EST_RCM != 3`);
* campanha já pendente (`IN_EXEA_PND = S`);
* linha já encerrada (`TS_FIM_REG` preenchido).

---

## 5.4 Origem com mudança

```text
┌──────────────────────────────────────┐
│ ORIGEM OBSERVADA COM SEGURANÇA       │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ EXISTE MUDANÇA RELEVANTE             │
│ OU NÃO EXISTE REFERÊNCIA ANTERIOR    │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ RELIGA CAMPANHA                      │
│ IN_EXEA_PND = S                      │
└──────────────────────────────────────┘
```

---

## 5.5 Origem sem mudança

```text
┌──────────────────────────────────────┐
│ ORIGEM OBSERVADA COM SEGURANÇA       │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ NÃO EXISTE MUDANÇA APLICÁVEL         │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ CAMPANHA PERMANECE DESLIGADA         │
│ IN_EXEA_PND = N                      │
└──────────────────────────────────────┘
```

---

## 5.6 Origem não observada com segurança

```text
┌──────────────────────────────────────┐
│ ORIGEM NÃO PÔDE SER LIDA, FILTRADA   │
│ OU ANALISADA COM SEGURANÇA           │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PRESERVA CAMPANHA SEM ALTERAÇÃO      │
│ FALHA PONTUAL                        │
└──────────────────────────────────────┘
```

Regras:

* a falha afeta somente a campanha;
* as demais campanhas continuam sendo observadas;
* nenhuma decisão automática é aplicada à campanha afetada.

---

# 6. Vinculação de clientes às recomendações

## 6.1 Objetivo operacional

A vinculação processa campanhas atuais, vigentes, abertas e com execução pendente.

Ela gera novos snapshots de clientes, atualiza o controle operacional, prepara o lote histórico/eventual e remonta a visão corrente.

---

## 6.2 Fluxo macro da vinculação

```text
┌──────────────────────────────────────┐
│ RECEBE CONTROLE ATUALIZADO           │
│ df_ctl_oprl_rcm                      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VALIDA CONTROLE E HISTÓRICO          │
│ RCM_FNC_CLI_EVTL                     │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ SELECIONA CAMPANHAS PENDENTES        │
│ IN_REG_ATU = S                       │
│ CD_EST_RCM = 3                       │
│ TS_FIM_REG = nulo                    │
│ IN_EXEA_PND = S                      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ LÊ ORIGEM, APLICA ESCOPO             │
│ E IDENTIFICA CLIENTES VÁLIDOS        │
└───────┬───────────────────────┬──────┘
        │ Sucesso               │ Falha pontual
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ GERA SNAPSHOT        │   │ MANTÉM CAMPANHA      │
│ DESLIGA PENDÊNCIA    │   │ PENDENTE             │
│ IN_EXEA_PND = N      │   │ IN_EXEA_PND = S      │
└──────────┬───────────┘   └──────────┬───────────┘
           │                          │
           └────────────┬─────────────┘
                        ▼
┌──────────────────────────────────────┐
│ PREPARA LOTE HISTÓRICO/EVENTUAL      │
│ df_rcm_fnc_cli_evtl_append           │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ REMONTA VISÃO CORRENTE               │
│ df_rcm_fnc_cli_final                 │
└──────────────────────────────────────┘
```

---

## 6.3 Campanha processada com sucesso

```text
┌──────────────────────────────────────┐
│ CAMPANHA PENDENTE APTA               │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ ORIGEM LIDA COM SEGURANÇA            │
│ ESCOPO APLICADO                      │
│ CLIENTES VÁLIDOS IDENTIFICADOS       │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ GERA NOVO SNAPSHOT                   │
│ DT_AVS_FNC_CLI = hoje                │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ ATUALIZA CONTROLE                    │
│ IN_EXEA_PND = N                      │
│ REFERÊNCIA PROCESSADA ATUALIZADA     │
└──────────────────────────────────────┘
```

Regras:

* o snapshot representa o conjunto completo de clientes da campanha;
* não existe atualização parcial por cliente;
* uma nova versão da mesma recomendação atualiza a foto corrente do mesmo aviso;
* temporariamente, o identificador do aviso (`CD_IDFR_AVS`) recebe somente `NR_IDFR_RCM` convertido para texto;
* a regra planejada é retornar à composição `NR_IDFR_PROJ + "_" + NR_IDFR_RCM`, pois a `AVS_FNC_CLI` não possui uma coluna própria para o projeto;
* a versão validada não compõe o identificador em nenhuma das duas regras.

---

## 6.4 Campanha mantida pendente por falha pontual

```text
┌──────────────────────────────────────┐
│ CAMPANHA PENDENTE NÃO PÔDE SER       │
│ PROCESSADA COM SEGURANÇA             │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ MANTÉM EXECUÇÃO PENDENTE             │
│ IN_EXEA_PND = S                      │
│ NÃO GERA SNAPSHOT                    │
└──────────────────────────────────────┘
```

Inclui:

* origem inacessível;
* metadados obrigatórios ausentes;
* escopo inválido;
* coluna de escopo inexistente;
* referência por data indefinida;
* ausência de coluna de cliente aceita;
* origem sem clientes válidos (`nenhum_cliente_valido`).

---

## 6.5 Preparação idempotente do histórico

```text
┌──────────────────────────────────────┐
│ NOVOS SNAPSHOTS GERADOS              │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ COMPARA COM HISTÓRICO EXISTENTE      │
│ RCM_FNC_CLI_EVTL                     │
└───────┬───────────────────────┬──────┘
        │ Registro idêntico     │ Mesma chave divergente
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ RETIRA DO LOTE       │   │ INTERROMPE EXECUÇÃO  │
│ DE APPEND            │   │ PARA EVITAR          │
│                      │   │ DIVERGÊNCIA          │
└──────────┬───────────┘   └──────────────────────┘
           │
           ▼
┌──────────────────────────────────────┐
│ ENTREGA LOTE PREPARADO               │
│ df_rcm_fnc_cli_evtl_append           │
└──────────────────────────────────────┘
```

Chave histórica:

```text
CD_IDFR_AVS
CD_CLI
DT_AVS_FNC_CLI
```

Regras:

* snapshot gerado não significa necessariamente append físico;
* em reexecução idempotente na mesma data, o lote de append pode ficar vazio;
* a publicação Hive apenas escreve o lote já preparado.

---

## 6.6 Remontagem da visão corrente

```text
┌──────────────────────────────────────┐
│ HISTÓRICO EXISTENTE +                │
│ NOVOS SNAPSHOTS                      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ SELECIONA ÚLTIMA FOTO APLICÁVEL      │
│ POR CAMPANHA                         │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ MONTA VISÃO CORRENTE                 │
│ RCM_FNC_CLI                          │
└──────────────────────────────────────┘
```

Regras:

* se houver novo snapshot com sucesso, ele substitui integralmente a foto anterior na visão corrente;
* se a campanha falhar e já houver histórico, a última foto histórica aplicável permanece na visão corrente;
* se a primeira tentativa falhar, a campanha não aparece na visão corrente;
* campanhas que não estejam atuais, vigentes e abertas não permanecem na visão corrente.

---

# 7. Publicação Hive

## 7.1 Objetivo operacional

A publicação Hive grava fisicamente os objetos finais preparados pela vinculação.

Ela publica:

* visão corrente de clientes vinculados (`RCM_FNC_CLI`);
* visão histórica/eventual de clientes vinculados (`RCM_FNC_CLI_EVTL`);
* tabela oficial de controle operacional (`CTL_OPRL_RCM`).

---

## 7.2 Fluxo macro da publicação Hive

```text
┌──────────────────────────────────────┐
│ RECEBE OBJETOS FINAIS DA VINCULAÇÃO  │
│ df_rcm_fnc_cli_final                 │
│ df_rcm_fnc_cli_evtl_append           │
│ df_ctl_oprl_rcm_final                │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PROJETA E VALIDA CONTRATOS HIVE      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VALIDA TABELAS HIVE DE DESTINO       │
│ EXISTÊNCIA + SCHEMA                  │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ MATERIALIZA CONTROLE FINAL           │
│ temp_lineage_CTL_OPRL_RCM            │
│ ANTES DAS ESCRITAS HIVE FINAIS       │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PUBLICA RCM_FNC_CLI                  │
│ overwrite                            │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PUBLICA RCM_FNC_CLI_EVTL             │
│ append somente se houver lote        │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PUBLICA CTL_OPRL_RCM                 │
│ overwrite a partir da temp_lineage   │
└──────────────────────────────────────┘
```

---

## 7.3 Validação antes da publicação

```text
┌──────────────────────────────────────┐
│ OBJETOS FINAIS RECEBIDOS             │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ EXISTE DUPLICIDADE, SCHEMA INVÁLIDO  │
│ OU DESTINO INCOMPATÍVEL?             │
└───────┬───────────────────────┬──────┘
        │ Sim                   │ Não
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ INTERROMPE EXECUÇÃO  │   │ SEGUE PARA           │
│ ANTES DA PUBLICAÇÃO  │   │ MATERIALIZAÇÃO       │
└──────────────────────┘   └──────────────────────┘
```

---

## 7.4 Materialização técnica antes das escritas finais

```text
┌──────────────────────────────────────┐
│ REMOVE temp_lineage ANTERIOR         │
│ QUANDO EXISTIR                       │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ GRAVA df_ctl_oprl_rcm_final EM       │
│ temp_lineage_CTL_OPRL_RCM            │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ RELÊ temp_lineage_CTL_OPRL_RCM       │
│ E VALIDA SCHEMA + CONTAGEM           │
└───────┬───────────────────────┬──────┘
        │ Válida                │ Inválida
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ SEGUE PARA ESCRITAS  │   │ INTERROMPE EXECUÇÃO  │
│ HIVE FINAIS          │   └──────────────────────┘
└──────────────────────┘
```

Regras:

* a `temp_lineage_CTL_OPRL_RCM` nasce antes das escritas Hive finais;
* ela não é uma tabela de negócio;
* ela protege o overwrite final da `CTL_OPRL_RCM`;
* o controle oficial é publicado a partir da `temp_lineage` validada.

---

## 7.5 Lote histórico/eventual vazio

```text
┌──────────────────────────────────────┐
│ df_rcm_fnc_cli_evtl_append VAZIO     │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ DISPENSA APPEND EM RCM_FNC_CLI_EVTL  │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PUBLICA RCM_FNC_CLI                  │
│ PUBLICA CTL_OPRL_RCM                 │
└──────────────────────────────────────┘
```

---

## 7.6 Lote histórico/eventual preenchido

```text
┌──────────────────────────────────────┐
│ df_rcm_fnc_cli_evtl_append           │
│ POSSUI REGISTROS                     │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ EXECUTA APPEND EM RCM_FNC_CLI_EVTL   │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PUBLICA RCM_FNC_CLI                  │
│ PUBLICA CTL_OPRL_RCM                 │
└──────────────────────────────────────┘
```

Regras:

* a publicação Hive não recalcula idempotência;
* ela escreve o lote preparado pela vinculação;
* a escrita Hive não deve ser tratada como transação única entre todas as tabelas.

---

# 8. Encerramento Hive/HDFS

## 8.1 Objetivo operacional

O encerramento Hive/HDFS remove os temporários de controle quando a publicação Hive foi concluída com sucesso.

Ele preserva temporários quando a publicação Hive não foi concluída ou quando a limpeza falha.

---

## 8.2 Fluxo macro do encerramento

```text
┌──────────────────────────────────────┐
│ RECEBE INDICADOR DE PUBLICAÇÃO HIVE  │
│ publicacao_hive_concluida            │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PUBLICAÇÃO HIVE CONCLUÍDA?           │
└───────┬───────────────────────┬──────┘
        │ Sim                   │ Não
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ REMOVE TEMPORÁRIOS   │   │ PRESERVA TEMPORÁRIOS │
│ HDFS DE CONTROLE     │   │ limpeza = False      │
└──────────┬───────────┘   └──────────┬───────────┘
           │                          │
           ▼                          │
┌──────────────────────┐              │
│ LIMPEZA CONCLUÍDA?   │              │
└───────┬───────┬──────┘              │
        │ Sim   │ Não                 │
        ▼       ▼                     ▼
┌────────────┐ ┌────────────┐   ┌───────────────┐
│ limpeza =  │ │ limpeza =  │   │ ORACLE        │
│ True       │ │ False      │   │ BLOQUEADO     │
└─────┬──────┘ └─────┬──────┘   └───────────────┘
      │              │
      ▼              ▼
┌──────────────────────────────────────┐
│ DECISÃO DA ROTINA PRINCIPAL          │
│ Oracle segue somente se limpeza=True │
└──────────────────────────────────────┘
```

---

## 8.3 Publicação Hive não concluída

```text
┌──────────────────────────────────────┐
│ publicacao_hive_concluida = False    │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PRESERVA TEMPORÁRIOS                 │
│ temp_backup_CTL_OPRL_RCM             │
│ temp_lineage_CTL_OPRL_RCM            │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ limpeza_temporarios_ok = False       │
│ PUBLICAÇÃO ORACLE BLOQUEADA          │
└──────────────────────────────────────┘
```

---

## 8.4 Publicação Hive concluída e limpeza bem-sucedida

```text
┌──────────────────────────────────────┐
│ publicacao_hive_concluida = True     │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ REMOVE OU CONFIRMA INEXISTÊNCIA DOS  │
│ TEMPORÁRIOS DE CONTROLE              │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ limpeza_temporarios_ok = True        │
│ PUBLICAÇÃO ORACLE PODE SEGUIR        │
└──────────────────────────────────────┘
```

---

## 8.5 Falha na limpeza

```text
┌──────────────────────────────────────┐
│ publicacao_hive_concluida = True     │
│ MAS A LIMPEZA FALHA                  │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ limpeza_temporarios_ok = False       │
│ PUBLICAÇÃO ORACLE BLOQUEADA          │
└──────────────────────────────────────┘
```

Regras:

* falha de limpeza não desfaz a publicação Hive;
* falha de limpeza impede que a execução seja tratada como encerrada com segurança;
* a rotina principal bloqueia a publicação Oracle quando a limpeza HDFS não é concluída.

---

# 9. Publicação Oracle

## 9.1 Objetivo operacional

A publicação Oracle atualiza a tabela Oracle consumida pela API (`AVS_FNC_CLI`) com a visão corrente publicada no Hive (`RCM_FNC_CLI`).

A publicação Oracle só pode seguir quando:

```text
hive_publicado = True
limpeza_temporarios_ok = True
```

---

## 9.2 Fluxo macro da publicação Oracle

```text
┌──────────────────────────────────────┐
│ RECEBE RESULTADO DA EXECUÇÃO HIVE    │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ HIVE PUBLICADO E LIMPEZA CONCLUÍDA?  │
└───────┬───────────────────────┬──────┘
        │ Sim                   │ Não
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ LÊ RCM_FNC_CLI       │   │ BLOQUEIA PUBLICAÇÃO  │
│ PUBLICADA NO HIVE    │   │ ORACLE               │
└──────────┬───────────┘   └──────────────────────┘
           │
           ▼
┌──────────────────────────────────────┐
│ PREPARA DADOS PARA AVS_FNC_CLI       │
│ CONTRATO ORACLE                      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ VALIDA DADOS PREPARADOS              │
│ OBRIGATÓRIOS + CHAVE + LIMITES       │
└───────┬───────────────────────┬──────┘
        │ Válidos               │ Inválidos
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ COMPARA HIVE         │   │ INTERROMPE EXECUÇÃO  │
│ PREPARADO x ORACLE   │   └──────────────────────┘
└──────────┬───────────┘
           │
           ▼
┌──────────────────────────────────────┐
│ EXISTE DIFERENÇA MATERIAL?           │
└───────┬───────────────────────┬──────┘
        │ Sim                   │ Não
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ EXECUTA RELOAD       │   │ PRESERVA ORACLE      │
│ DELETE + append      │   │ SEM RELOAD           │
└──────────┬───────────┘   └──────────┬───────────┘
           │                          │
           ▼                          ▼
┌──────────────────────┐       ┌───────────────────┐
│ RELÊ ORACLE E        │       │ FINALIZA SEM      │
│ COMPARA PÓS-CARGA    │       │ CARGA FÍSICA      │
└───────┬───────┬──────┘       └───────────────────┘
        │ OK    │ Diverge
        ▼       ▼
┌────────────┐ ┌──────────────────────┐
│ FINALIZA   │ │ INTERROMPE EXECUÇÃO  │
│ COM ORACLE │ │ DIVERGÊNCIA PÓS      │
│ PUBLICADO  │ │ CARGA                │
└────────────┘ └──────────────────────┘
```

---

## 9.3 Publicação Oracle bloqueada

```text
┌──────────────────────────────────────┐
│ HIVE NÃO PUBLICADO OU                │
│ LIMPEZA HDFS NÃO CONCLUÍDA           │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ BLOQUEIA PUBLICAÇÃO ORACLE           │
│ NENHUMA CARGA FÍSICA É EXECUTADA     │
└──────────────────────────────────────┘
```

Regras:

* Oracle não deve receber conteúdo que ainda não foi confirmado como oficial no Hive;
* Oracle não segue se o encerramento HDFS não foi concluído com segurança.

---

## 9.4 Oracle sem diferença material

```text
┌──────────────────────────────────────┐
│ HIVE PREPARADO E ORACLE ATUAL        │
│ SÃO MATERIALMENTE EQUIVALENTES       │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PRESERVA ORACLE SEM RELOAD           │
│ DELETE + append NÃO EXECUTADO        │
└──────────────────────────────────────┘
```

---

## 9.5 Oracle com diferença material

```text
┌──────────────────────────────────────┐
│ EXISTE DIFERENÇA MATERIAL            │
│ ENTRE HIVE E ORACLE                  │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ EXECUTA RELOAD ORACLE                │
│ DELETE + append                      │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ RELÊ ORACLE APÓS CARGA               │
│ E COMPARA COM HIVE PREPARADO         │
└───────┬───────────────────────┬──────┘
        │ Equivalente           │ Divergente
        ▼                       ▼
┌──────────────────────┐   ┌──────────────────────┐
│ PUBLICAÇÃO ORACLE    │   │ INTERROMPE EXECUÇÃO  │
│ CONCLUÍDA            │   │ FALHA CRÍTICA        │
└──────────────────────┘   └──────────────────────┘
```

Regras:

* a carga Oracle usa a visão corrente já publicada no Hive (`RCM_FNC_CLI`);
* a operação é `DELETE + append`;
* a operação não deve ser tratada como transação única de ponta a ponta;
* se houver divergência pós-carga, a execução é interrompida para análise operacional.

---

# 10. Pontos de interrupção do fluxo

A execução é interrompida quando ocorrer falha crítica.

Principais exemplos:

| Etapa                  | Situação crítica                                                                                     |
| ---------------------- | ---------------------------------------------------------------------------------------------------- |
| Preparação             | Fonte confiável inexistente, inválida ou vazia fora da primeira carga.                               |
| Sincronização          | Controle inválido ou snapshot Oracle global inválido.                                                |
| Verificação de origem  | Controle recebido ou resultante inválido.                                                            |
| Vinculação             | Histórico inválido, duplicidade, divergência por chave histórica ou visão corrente inválida.         |
| Publicação Hive        | Entradas inválidas, destinos Hive incompatíveis, falha na `temp_lineage` ou falha física de escrita. |
| Encerramento Hive/HDFS | Limpeza não concluída bloqueia Oracle, mas não desfaz Hive.                                          |
| Publicação Oracle      | Dados inválidos, falha no reload ou divergência material após carga.                                 |

---

# 11. Falhas pontuais

Falhas pontuais afetam apenas uma campanha e não interrompem todo o fluxo.

| Etapa                 | Exemplo                                    | Tratamento                                          |
| --------------------- | ------------------------------------------ | --------------------------------------------------- |
| Sincronização         | Recomendação inconsistente no Oracle       | Bloqueia a campanha e preserva o restante do fluxo. |
| Verificação de origem | Origem não observada com segurança         | Preserva a campanha sem alteração.                  |
| Vinculação            | Origem inacessível ou sem clientes válidos | Mantém a campanha pendente (`IN_EXEA_PND = S`).     |

---

# 12. Resultado final esperado

## 12.1 Quando Hive conclui e Oracle não é necessário

```text
┌──────────────────────────────────────┐
│ HIVE PUBLICADO                       │
│ TEMPORÁRIOS LIMPOS                   │
│ ORACLE JÁ EQUIVALENTE                │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ FIM COM ORACLE PRESERVADO            │
│ SEM RELOAD                           │
└──────────────────────────────────────┘
```

## 12.2 Quando Hive conclui e Oracle é atualizado

```text
┌──────────────────────────────────────┐
│ HIVE PUBLICADO                       │
│ TEMPORÁRIOS LIMPOS                   │
│ ORACLE COM DIFERENÇA MATERIAL        │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ RELOAD ORACLE EXECUTADO              │
│ AVS_FNC_CLI EQUIVALENTE AO HIVE      │
└──────────────────────────────────────┘
```

## 12.3 Quando Oracle é bloqueado

```text
┌──────────────────────────────────────┐
│ HIVE NÃO PUBLICADO                   │
│ OU LIMPEZA HDFS NÃO CONCLUÍDA        │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ PUBLICAÇÃO ORACLE BLOQUEADA          │
│ POR SEGURANÇA                        │
└──────────────────────────────────────┘
```

## 12.4 Quando a execução é interrompida

```text
┌──────────────────────────────────────┐
│ FALHA CRÍTICA EM ALGUMA ETAPA        │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ EXECUÇÃO INTERROMPIDA                │
│ REQUER ANÁLISE OPERACIONAL           │
└──────────────────────────────────────┘
```
