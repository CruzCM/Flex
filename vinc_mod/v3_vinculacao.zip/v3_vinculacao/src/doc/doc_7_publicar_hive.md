## Publicação Hive (`7_publicar_hive.ipynb`)

### Entrada

A publicação Hive (`7_publicar_hive.ipynb`) grava fisicamente no Hive os objetos finais preparados pela vinculação.

A etapa recebe os dados já validados e preparados pela vinculação de clientes às recomendações (`6_vinculacao.ipynb`).

Seu objetivo é publicar a visão corrente de clientes vinculados, acrescentar novos registros à visão histórica/eventual quando houver lote aplicável e atualizar a tabela oficial de controle operacional.

A etapa recebe:

* visão corrente remontada de clientes vinculados (`df_rcm_fnc_cli_final`);
* lote histórico/eventual preparado para append (`df_rcm_fnc_cli_evtl_append`);
* tabela de controle final (`df_ctl_oprl_rcm_final`);
* banco Hive de trabalho (`database`);
* caminho HDFS de apoio (`path_save_hdfs`);
* efeito físico habilitado (`executar=True`).

A etapa publica as seguintes tabelas Hive:

* visão corrente de clientes vinculados (`RCM_FNC_CLI`);
* visão histórica/eventual de clientes vinculados (`RCM_FNC_CLI_EVTL`);
* tabela oficial de controle operacional (`CTL_OPRL_RCM`).

---

### Execução

A rotina projeta os objetos recebidos para o contrato Hive esperado de cada tabela.

Em seguida, valida se os dados preparados podem ser publicados com segurança.

A rotina verifica:

* duplicidade na visão corrente de clientes vinculados (`RCM_FNC_CLI`);
* duplicidade no lote histórico/eventual preparado para append (`RCM_FNC_CLI_EVTL`);
* estrutura e consistência operacional da tabela de controle (`CTL_OPRL_RCM`);
* existência das tabelas Hive de destino;
* compatibilidade entre o schema físico das tabelas Hive e o contrato esperado.

Se qualquer validação falhar, então a execução será interrompida antes da publicação física.

Antes das escritas Hive finais, a rotina materializa a tabela de controle final em uma área técnica (`temp_lineage_CTL_OPRL_RCM`) e relê esse conteúdo para quebrar a linhagem da execução Spark.

Essa materialização será usada posteriormente no overwrite final da tabela oficial de controle operacional (`CTL_OPRL_RCM`).

A publicação segue uma ordem segura:

```text
temp_lineage_CTL_OPRL_RCM
    → materialização técnica da tabela de controle final

RCM_FNC_CLI
    → overwrite da visão corrente

RCM_FNC_CLI_EVTL
    → append do lote histórico/eventual, quando houver registros

CTL_OPRL_RCM
    → overwrite final da tabela oficial de controle a partir da materialização técnica validada
```

A publicação física das tabelas Hive não deve ser tratada como uma transação única entre todas as tabelas.

Se ocorrer falha física durante a publicação, então a execução deve ser analisada operacionalmente antes de qualquer nova tentativa.

---

#### Cenário 1 — Entradas ou destinos inválidos

Se a visão corrente de clientes vinculados (`df_rcm_fnc_cli_final`) possuir duplicidade pela chave da tabela, então a publicação será interrompida.

Se o lote histórico/eventual preparado para append (`df_rcm_fnc_cli_evtl_append`) possuir duplicidade pela chave da tabela, então a publicação também será interrompida.

Se a tabela de controle final (`df_ctl_oprl_rcm_final`) estiver inválida, então a execução será interrompida.

Se alguma tabela Hive de destino não existir no banco Hive de trabalho (`database`), então a execução será interrompida.

Se alguma tabela Hive de destino existir, mas possuir schema incompatível com o contrato esperado, então a execução será interrompida.

Nenhuma publicação física segura deve continuar quando as entradas ou os destinos não estiverem compatíveis com o contrato.

---

#### Cenário 2 — Materialização técnica do controle antes da publicação

Antes das escritas Hive finais, a rotina remove a materialização técnica anterior da tabela de controle final (`temp_lineage_CTL_OPRL_RCM`), quando ela existir.

Se a materialização técnica anterior não puder ser removida com segurança, então a execução será interrompida.

Depois disso, a rotina grava a tabela de controle final em uma nova materialização técnica (`temp_lineage_CTL_OPRL_RCM`) e lê novamente esse conteúdo.

Se a leitura da materialização técnica não preservar a estrutura esperada da tabela de controle, então a execução será interrompida.

Se a quantidade de registros lida da materialização técnica for diferente da quantidade de registros da tabela de controle final, então a execução também será interrompida.

Somente depois dessa validação a rotina segue para as escritas Hive finais.

A materialização técnica não é uma tabela de negócio.

Ela existe para proteger a publicação final da tabela oficial de controle operacional (`CTL_OPRL_RCM`) contra riscos de linhagem da execução Spark.

---

#### Cenário 3 — Publicação com lote histórico/eventual vazio

Se o lote histórico/eventual preparado para append (`df_rcm_fnc_cli_evtl_append`) estiver vazio, então a rotina dispensa o append na visão histórica/eventual (`RCM_FNC_CLI_EVTL`).

Nesse cenário, a rotina ainda publica a visão corrente de clientes vinculados (`RCM_FNC_CLI`) por overwrite.

A rotina também publica a tabela oficial de controle operacional (`CTL_OPRL_RCM`) por overwrite final, usando a materialização técnica validada (`temp_lineage_CTL_OPRL_RCM`).

A ausência de registros no lote histórico/eventual não impede a publicação da visão corrente nem da tabela de controle.

Esse cenário pode ocorrer quando a vinculação não gerar novos registros históricos aplicáveis ou quando uma reexecução idempotente já encontrar os registros históricos existentes.

---

#### Cenário 4 — Publicação com lote histórico/eventual preenchido

Se o lote histórico/eventual preparado para append (`df_rcm_fnc_cli_evtl_append`) possuir registros, então a rotina acrescenta esses registros à visão histórica/eventual de clientes vinculados (`RCM_FNC_CLI_EVTL`).

Esse append depende da preparação idempotente realizada na vinculação (`6_vinculacao.ipynb`).

A publicação Hive não recalcula a idempotência do histórico.

Ela recebe o lote já preparado e apenas executa a escrita física.

Nesse cenário, a rotina também publica a visão corrente de clientes vinculados (`RCM_FNC_CLI`) por overwrite.

A rotina também publica a tabela oficial de controle operacional (`CTL_OPRL_RCM`) por overwrite final, usando a materialização técnica validada (`temp_lineage_CTL_OPRL_RCM`).

---

#### Falhas críticas da etapa

Algumas falhas impedem a continuidade de toda a publicação Hive.

A execução será interrompida quando ocorrer qualquer uma das situações abaixo:

* duplicidade na visão corrente de clientes vinculados (`RCM_FNC_CLI`);
* duplicidade no lote histórico/eventual preparado para append (`RCM_FNC_CLI_EVTL`);
* estrutura inválida na tabela de controle final (`df_ctl_oprl_rcm_final`);
* tabela Hive de destino inexistente;
* schema físico da tabela Hive incompatível com o contrato esperado;
* falha ao remover a materialização técnica anterior (`temp_lineage_CTL_OPRL_RCM`);
* estrutura inválida ao reler a materialização técnica da tabela de controle;
* divergência de quantidade entre a tabela de controle final e a materialização técnica relida;
* falha física de escrita no Hive ou no HDFS.

---

### Resultado

Ao final, a publicação Hive entrega:

* indicador de publicação Hive concluída (`hive_publicado`);
* estatísticas da publicação (`stats`).

As estatísticas registram:

* quantidade de registros publicados na visão corrente de clientes vinculados (`qtd_rcm_fnc_cli`);
* quantidade de registros acrescentados à visão histórica/eventual (`qtd_evtl_append`);
* indicação de publicação da tabela de controle operacional (`ctl_publicado`).

Se a publicação terminar com sucesso, então:

```text
hive_publicado = True
ctl_publicado = True
```

A visão corrente de clientes vinculados (`RCM_FNC_CLI`) estará publicada por overwrite.

A visão histórica/eventual de clientes vinculados (`RCM_FNC_CLI_EVTL`) terá recebido append somente quando o lote histórico/eventual possuir registros.

A tabela oficial de controle operacional (`CTL_OPRL_RCM`) estará publicada por overwrite final a partir da materialização técnica validada (`temp_lineage_CTL_OPRL_RCM`).

Se a publicação Hive terminar com sucesso, então o fluxo segue para o encerramento da execução Hive (`9_encerrar_execucao.ipynb`).

O indicador de publicação Hive concluída (`hive_publicado`) também será utilizado pela publicação Oracle (`8_publicar_oracle.ipynb`), quando essa etapa for chamada.
