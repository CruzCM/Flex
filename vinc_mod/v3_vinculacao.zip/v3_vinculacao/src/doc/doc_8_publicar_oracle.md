## Publicação Oracle (`8_publicar_oracle.ipynb`)

### Entrada

A publicação Oracle (`8_publicar_oracle.ipynb`) atualiza a tabela Oracle consumida pela API com a visão corrente de clientes vinculados.

A etapa depende da publicação Hive concluída com sucesso.

Seu objetivo é manter a tabela Oracle de avisos ativos por cliente (`AVS_FNC_CLI`) materialmente equivalente à visão corrente publicada no Hive (`RCM_FNC_CLI`).

A etapa recebe:

* visão corrente remontada de clientes vinculados (`df_rcm_fnc_cli_final`);
* banco Hive de trabalho (`database`);
* schema Oracle (`oracle_schema`);
* cliente de acesso Oracle (`cliente_oracle`);
* efeito físico habilitado (`executar=True`);
* indicador de publicação Hive concluída (`hive_publicado`);
* indicação de detalhamento por recomendação (`detalhar_recomendacao`).

Em produção, a rotina utiliza como origem a visão corrente já publicada no Hive (`RCM_FNC_CLI`).

A visão corrente em memória (`df_rcm_fnc_cli_final`) é recebida pela função, mas a carga produtiva parte da tabela Hive publicada.

---

### Execução

A rotina valida inicialmente se a publicação Hive foi concluída com sucesso (`hive_publicado=True`).

Se o Hive não tiver sido publicado, então a publicação Oracle será bloqueada.

Depois disso, a rotina lê a visão corrente de clientes vinculados no Hive (`RCM_FNC_CLI`) e prepara os dados no contrato esperado pela tabela Oracle (`AVS_FNC_CLI`).

Durante essa preparação, a rotina valida:

* campos obrigatórios para publicação Oracle;
* duplicidade pela chave Oracle;
* limites físicos dos textos e identificadores;
* faixa permitida para o nível de confiança;
* tamanho máximo do código de cliente;
* compatibilidade com o contrato Oracle.

A chave da tabela Oracle é formada por:

```text
CD_CLI_AVS
CD_IDFR_AVS
```

Depois de preparar os dados, a rotina lê o estado atual da tabela Oracle (`AVS_FNC_CLI`) e compara esse conteúdo com o conjunto preparado a partir do Hive.

A decisão de carga depende da existência de diferença material entre Hive e Oracle.

A carga Oracle, quando necessária, é feita por reload:

```text
DELETE + append
```

Essa operação não deve ser tratada como transação única de ponta a ponta.

Se ocorrer falha durante a carga Oracle, então a execução deve ser analisada operacionalmente antes de qualquer nova tentativa.

---

#### Cenário 1 — Publicação Oracle bloqueada

Se a publicação Hive não tiver sido concluída com sucesso (`hive_publicado=False`), então a publicação Oracle será bloqueada.

Nesse cenário, nenhuma leitura comparativa nem carga física no Oracle deve seguir.

Esse bloqueio evita publicar no Oracle um conteúdo que ainda não foi confirmado como estado oficial no Hive.

---

#### Cenário 2 — Dados preparados para Oracle inválidos

Se a visão corrente publicada no Hive (`RCM_FNC_CLI`) não puder ser preparada com segurança para o contrato Oracle, então a publicação será interrompida.

Esse cenário inclui:

* dados obrigatórios ausentes;
* identificador do aviso vazio (`CD_IDFR_AVS`);
* duplicidade pela chave Oracle;
* textos acima do limite físico Oracle;
* parâmetro de API acima do limite físico Oracle;
* nível de confiança fora da faixa permitida (`PC_NVL_CNFA_AVS`);
* código de cliente acima do limite físico (`CD_CLI_AVS`);
* DataFrame preparado vazio.

Nenhuma carga Oracle será executada quando o conteúdo preparado estiver inválido.

---

#### Cenário 3 — Oracle sem diferença material

Se a comparação indicar que a tabela Oracle (`AVS_FNC_CLI`) já está materialmente equivalente à visão corrente publicada no Hive (`RCM_FNC_CLI`), então a rotina preserva o Oracle sem executar reload.

Nesse cenário:

```text
DELETE + append
    → não executado
```

A ausência de diferença material evita uma carga física desnecessária.

A rotina apenas registra as estatísticas da comparação.

---

#### Cenário 4 — Oracle com diferença material

Se a comparação indicar diferença material entre Hive e Oracle, então a rotina executa a carga Oracle por reload.

Nesse cenário, a rotina substitui fisicamente o conteúdo da tabela Oracle (`AVS_FNC_CLI`) pelo conjunto preparado a partir da visão corrente publicada no Hive (`RCM_FNC_CLI`).

A operação aplicada é:

```text
DELETE + append
```

Após a carga, a rotina lê novamente a tabela Oracle (`AVS_FNC_CLI`) e compara o resultado carregado com o conteúdo preparado a partir do Hive.

Se o Oracle pós-carga estiver materialmente equivalente ao Hive preparado, então a publicação Oracle será considerada concluída.

---

#### Cenário 5 — Divergência após a carga Oracle

Se, após o reload, o conteúdo da tabela Oracle (`AVS_FNC_CLI`) ainda divergir do conteúdo preparado a partir do Hive, então a execução será interrompida.

Nesse cenário, a rotina registra as divergências encontradas para apoiar a análise operacional.

A divergência pós-carga é uma falha crítica.

O Oracle pode ter sido parcialmente alterado antes da falha, porque a operação de reload não é tratada como transação única de ponta a ponta.

---

#### Falhas críticas da etapa

Algumas falhas impedem a continuidade de toda a publicação Oracle.

A execução será interrompida quando ocorrer qualquer uma das situações abaixo:

* publicação Hive não concluída (`hive_publicado=False`);
* schema Oracle inválido (`oracle_schema`);
* falha na leitura da visão corrente publicada no Hive (`RCM_FNC_CLI`);
* dados preparados para Oracle inválidos;
* DataFrame preparado vazio;
* falha na leitura da tabela Oracle atual (`AVS_FNC_CLI`);
* falha física durante o reload Oracle;
* divergência material entre Hive preparado e Oracle pós-carga.

---

### Resultado

Ao final, a publicação Oracle entrega:

* estatísticas da publicação (`stats`).

As estatísticas registram:

* quantidade de registros preparados a partir do Hive (`qtd_hive_preparado`);
* quantidade de registros existentes no Oracle antes da decisão (`qtd_oracle_antes`);
* quantidade de registros existentes no Oracle após a carga, quando houver carga (`qtd_oracle_depois`);
* indicação de existência de diferença material (`tem_diferenca_material`);
* indicação de carga executada (`carga_executada`);
* motivo da decisão tomada (`motivo`).

Quando não houver diferença material, a tabela Oracle (`AVS_FNC_CLI`) será preservada sem reload.

Quando houver diferença material e a carga terminar com sucesso, a tabela Oracle (`AVS_FNC_CLI`) ficará materialmente equivalente à visão corrente publicada no Hive (`RCM_FNC_CLI`).

O resultado da publicação Oracle é consolidado no resultado final da rotina principal.
