# BBMagic Help Completo

## Versão

`3.1.4`

## Índice

1. Pacote `bbmagic`
2. Módulo `bbmagic.checks`
3. Módulo `bbmagic.common`
4. Módulo `bbmagic.db2`
5. Módulo `bbmagic.environment`
6. Módulo `bbmagic.exceptions`
7. Módulo `bbmagic.file_config`
8. Módulo `bbmagic.gitlab_config`
9. Módulo `bbmagic.hdfs`
10. Módulo `bbmagic.http_config`
11. Módulo `bbmagic.kinit`
12. Módulo `bbmagic.livyapi`
13. Módulo `bbmagic.log`
14. Módulo `bbmagic.lookup`
15. Classe `Db2` — módulo `bbmagic.db2`
16. Classe `FileConfig` — módulo `bbmagic.file_config`
17. Classe `GitLabConfig` — módulo `bbmagic.gitlab_config`
18. Classe `HttpConfig` — módulo `bbmagic.http_config`
19. Classe `Kinit` — módulo `bbmagic.kinit`
20. Classe `Hdfs` — módulo `bbmagic.hdfs`
21. Classe `Spark` — módulo `bbmagic.spark`
22. Classe `MetaDataHive` — módulo `bbmagic.sumary`
23. Classe `TeamsNotify` — módulo `bbmagic.teams_notify`
24. Classe `SAS` — módulo `bbmagic.sas.sas`
25. Classe `AuthInfo` — módulo `bbmagic.sas.authinfo`
26. Classe `AuthKey` — módulo `bbmagic.sas.authinfo`
27. Objeto `Db2` — módulo `bbmagic.db2`
28. Método `query` — módulo `bbmagic.db2`
29. Método `show_schemas` — módulo `bbmagic.db2`
30. Método `show_tables` — módulo `bbmagic.db2`
31. Método `describe` — módulo `bbmagic.db2`
32. Método `syscolumns` — módulo `bbmagic.db2`
33. Método `systabstats` — módulo `bbmagic.db2`
34. Objeto `Hdfs` — módulo `bbmagic.hdfs`
35. Método `upload` — módulo `hdfs.client`
36. Método `download` — módulo `hdfs.client`
37. Método `list` — módulo `hdfs.client`
38. Método `delete` — módulo `hdfs.client`
39. Método `rename` — módulo `hdfs.client`
40. Método `status` — módulo `hdfs.client`
41. Método `read` — módulo `hdfs.client`
42. Método `write` — módulo `hdfs.client`
43. Método `walk` — módulo `hdfs.client`
44. Objeto `Spark` — módulo `bbmagic.spark`
45. Método `connect` — módulo `bbmagic.spark`
46. Método `close` — módulo `bbmagic.spark`
47. Método `send_to_spark` — módulo `bbmagic.spark`
48. Método `get_from_spark` — módulo `bbmagic.spark`
49. Método `config_db2` — módulo `bbmagic.spark`
50. Método `config_jars` — módulo `bbmagic.spark`
51. Classe `FileConfig` — módulo `bbmagic.file_config`
52. Classe `GitLabConfig` — módulo `bbmagic.gitlab_config`
53. Classe `HttpConfig` — módulo `bbmagic.http_config`
54. Classe `MetaDataHive` — módulo `bbmagic.sumary`
55. Método `status_db` — módulo `bbmagic.sumary`
56. Método `status_table` — módulo `bbmagic.sumary`
57. Classe `AuthInfo` — módulo `bbmagic.sas.authinfo`
58. Classe `AuthKey` — módulo `bbmagic.sas.authinfo`
59. Classe `Db2` — módulo `bbmagic.db2`
60. Classe `FileConfig` — módulo `bbmagic.file_config`
61. Classe `GitLabConfig` — módulo `bbmagic.gitlab_config`
62. Classe `Hdfs` — módulo `bbmagic.hdfs`
63. Classe `HttpConfig` — módulo `bbmagic.http_config`
64. Classe `Kinit` — módulo `bbmagic.kinit`
65. Classe `MetaDataHive` — módulo `bbmagic.sumary`
66. Classe `SAS` — módulo `bbmagic.sas.sas`
67. Classe `Spark` — módulo `bbmagic.spark`
68. Classe `TeamsNotify` — módulo `bbmagic.teams_notify`
69. Módulo `bbmagic.checks`
70. Módulo `bbmagic.common`
71. Módulo `bbmagic.db2`
72. Módulo `bbmagic.environment`
73. Módulo `bbmagic.exceptions`
74. Módulo `bbmagic.file_config`
75. Função `get_ambiente` — módulo `bbmagic.common`
76. Módulo `bbmagic.gitlab_config`
77. Módulo `bbmagic.hdfs`
78. Módulo `bbmagic.http_config`
79. Módulo `bbmagic.kinit`
80. Módulo `bbmagic.livyapi`
81. Módulo `bbmagic.log`
82. Função `log_project` — módulo `bbmagic.log`
83. Módulo `bbmagic.lookup`
84. Pacote `bbmagic.sas`
85. Módulo `bbmagic.sigla_api`
86. Módulo `bbmagic.spark`
87. Módulo `bbmagic.sumary`
88. Classe `suppress` — módulo `contextlib`
89. Módulo `bbmagic.teams_notify`
90. Pacote `bbmagic.utils`
91. Módulo `bbmagic.version`
92. Pacote `bbmagic.utils`
93. Classe `Hdfs` — módulo `bbmagic.hdfs`
94. Classe `Spark` — módulo `bbmagic.spark`
95. Classe `Db2` — módulo `bbmagic.db2`

---

## Pacote `bbmagic`

### NAME

`bbmagic - Ferramentas`

### PACKAGE CONTENTS

- `checks`
- `common`
- `db2`
- `environment`
- `exceptions`
- `file_config`
- `gitlab_config`
- `hdfs`
- `http_config`
- `kinit`
- `livyapi`
- `log`
- `lookup`
- `publicador_modelo`
- `sas (package)`
- `sigla_api`
- `spark`
- `sumary`
- `teams_notify`
- `utils (package)`
- `version`

### CLASSES

#### Hierarquia

```text
    builtins.object
        bbmagic.db2.Db2
        bbmagic.file_config.FileConfig
            bbmagic.gitlab_config.GitLabConfig
            bbmagic.http_config.HttpConfig
        bbmagic.kinit.Kinit
        bbmagic.sas.authinfo.AuthInfo
        bbmagic.sas.authinfo.AuthKey
        bbmagic.sas.sas.SAS
        bbmagic.spark.Spark
        bbmagic.sumary.MetaDataHive
        bbmagic.teams_notify.TeamsNotify
    hdfs.ext.kerberos.KerberosClient(hdfs.client.Client)
        bbmagic.hdfs.Hdfs
```

#### Classe `AuthInfo`

```text
    class AuthInfo(builtins.object)
     |  Methods defined here:
     |  
     |  __init__(self)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __len__(self) -> int
     |  
     |  add_key(self, name: str, user: str, password: Optional[str] = None) -> None
     |  
     |  parse(self) -> list
     |  
     |  remove_key(self, name: str) -> None
     |  
     |  write(self) -> None
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  path
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `AuthKey`

```text
    class AuthKey(builtins.object)
     |  AuthKey(name: str, user: str, password: Optional[str] = None) -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self, name: str, user: str, password: Optional[str] = None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __str__(self) -> str
     |      Return str(self).
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `Db2`

```text
    class Db2(builtins.object)
     |  Db2(user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
     |  
     |  Cria uma conexão ao DB2
     |  
     |  Methods defined here:
     |  
     |  __init__(self, user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  connect(self) -> ibm_db_dbi.Connection
     |      Cria a conexão JDBC com o servidor DB2.
     |  
     |  describe(self, schema: str, table: str) -> IPython.core.display.HTML
     |      Gera um relatório consolidado com os metadados da tabela existentes no catálogo
     |      do DB2.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um objeto HTML com o relatório para exibição no Jupyter Notebook.
     |      :rtype: IPython.core.display.HTML
     |  
     |  get_cofre_credentials(self, project_id: str) -> dict
     |      Recupera credenciais do cofre com base no project_id do projeto
     |  
     |  query(self, sql: str, params: Optional[list] = None, chunksize: Optional[int] = 2500) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
     |      Retorna um DataFrame contendo o resultado da execução da query SQL.
     |      
     |      :param sql: query SQL para execução
     |      :param params: lista de parâmetros para utilização na query
     |      :param chunksize: Se especificado, retorna um iterador onde chunksize é a quantidade
     |                        de linhas incluídas em cada chunk
     |      
     |      :return: Daframe ou Iterator[DataFrame]
     |      
     |      Exemplos de Uso::
     |      
     |          >>> for chunk in db2.query("SELECT * FROM db2mci.cliente LIMIT 10000"):
     |          ...     print(len(chunk))
     |          2500
     |          2500
     |          2500
     |          2500
     |      
     |      Sem utilização de chunks
     |      
     |          >>> df = db2.query("SELECT cod FROM db2mci.cliente LIMIT 100", chunksize=None)
     |  
     |  set_conn_param(self, param_name, param_value: Union[str, int, NoneType]) -> Union[str, int]
     |  
     |  show_schemas(self) -> pandas.core.frame.DataFrame
     |      Lista todos os schemas no database
     |      
     |      :return: Retorna um Pandas DataFrame contendo uma linha para cada schema encontrado.
     |      :rtype: pandas.core.api.DataFrame
     |      
     |      Exemplo de uso::
     |      
     |          >>> db2.show_schemas()
     |  
     |  show_tables(self, schema: str) -> pandas.core.frame.DataFrame
     |      Lista todas as tabelas e views de um schema.
     |      
     |      :param schema: nome do schema
     |      
     |      :return: Retorna um Pandas DataFrame contendo uma linha para cada tabela do schema
     |               e as informações *schema*, *name* e *type* nas respectivas colunas.
     |      :rtype: pandas.core.api.DataFrame
     |      
     |      Exemplo de uso::
     |      
     |          >>> db2.show_tables("DB2MCI")
     |  
     |  syscolumns(self, schema: str, table: str) -> pandas.core.frame.DataFrame
     |      Retorna metadados das colunas de uma tabela.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um Pandas DataFrame contendo as informações sobre as colunas da
     |               tabela de acordo com o catálogo syscat.syscolumns
     |      :rtype: pandas.core.api.DataFrame
     |  
     |  systabstats(self, schema: str, table: str) -> pandas.core.frame.DataFrame
     |      Retorna metadados de uma tabela.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um Pandas DataFrame contendo as informações sobre a tabela
     |               existentes no catálogo syscat.systabstats
     |      :rtype: pandas.core.api.DataFrame
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  url
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  envs = {'database': 'DB2_DATABASE', 'host': 'DB2_HOST', 'password': 'D...
     |  
     |  jars_path = '/projeto/libs/lib/python3.9/site-packages/bbmagic/jars/db...
```

#### Classe `FileConfig`

```text
    class FileConfig(builtins.object)
     |  FileConfig(path) -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self, path) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `GitLabConfig`

```text
    class GitLabConfig(bbmagic.file_config.FileConfig)
     |  Method resolution order:
     |      GitLabConfig
     |      bbmagic.file_config.FileConfig
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from bbmagic.file_config.FileConfig:
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from bbmagic.file_config.FileConfig:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `Hdfs`

```text
    class Hdfs(hdfs.ext.kerberos.KerberosClient)
     |  Hdfs(username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
     |  
     |  Permite acesso ao HDFS com autenticação via kerberos.
     |  
     |  :param username: matrícula ou caminho para arquivo keytab
     |  :param \*\*kwargs: Argumentos adicionais passados para a classe HTTPKerberosAuth.
     |  
     |  Method resolution order:
     |      Hdfs
     |      hdfs.ext.kerberos.KerberosClient
     |      hdfs.client.Client
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  set_no_proxy(self) -> None
     |      Garante que a variável no_proxy está configurada para ignorar o domínio
     |      da API web da BBMagic
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from hdfs.client.Client:
     |  
     |  __repr__(self)
     |      Return repr(self).
     |  
     |  acl_status(self, hdfs_path, strict=True)
     |      Get AclStatus_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _AclStatus: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Get_ACL_Status
     |  
     |  allow_snapshot(self, hdfs_path)
     |      Allow snapshots for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist or does points to a normal file, an
     |        :class:`HdfsError` will be raised.  No-op if snapshotting is
     |        already allowed.
     |  
     |  checksum(self, hdfs_path)
     |      Get a remote file's checksum.
     |      
     |      :param hdfs_path: Remote path. Must point to a file.
     |  
     |  content(self, hdfs_path, strict=True)
     |      Get ContentSummary_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _ContentSummary: CS_
     |      .. _CS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#ContentSummary
     |  
     |  create_snapshot(self, hdfs_path, snapshotname=None)
     |      Create snapshot for a remote folder where it was allowed.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist, doesn't allow to create snapshot or points to a
     |        normal file, an :class:`HdfsError` will be raised.
     |      :param snapshotname snapshot name; if absent, name is generated
     |        by the server.
     |      
     |      Returns a path to created snapshot.
     |  
     |  delete(self, hdfs_path, recursive=False, skip_trash=True)
     |      Remove a file or directory from HDFS.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param recursive: Recursively delete files and directories. By default,
     |        this method will raise an :class:`HdfsError` if trying to delete a
     |        non-empty directory.
     |      :param skip_trash: When false, the deleted path will be moved to an
     |        appropriate trash folder rather than deleted. This requires Hadoop 2.9+
     |      
     |      This function returns `True` if the deletion was successful and `False` if
     |      no file or directory previously existed at `hdfs_path`.
     |  
     |  delete_snapshot(self, hdfs_path, snapshotname)
     |      Remove snapshot for a remote folder where it was allowed.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param snapshotname snapshot name; if it does not exist, an
     |        :class:`HdfsError` will be raised.
     |  
     |  disallow_snapshot(self, hdfs_path)
     |      Disallow snapshots for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist, points to a normal file or there are some
     |        snapshots, an :class:`HdfsError` will be raised.
     |      
     |      No-op if snapshotting is disallowed/never allowed.
     |  
     |  download(self, hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs)
     |      Download a file or folder from HDFS and save it locally.
     |      
     |      :param hdfs_path: Path on HDFS of the file or folder to download. If a
     |        folder, all the files under it will be downloaded.
     |      :param local_path: Local path. If it already exists and is a directory,
     |        the files will be downloaded inside of it.
     |      :param overwrite: Overwrite any existing file or directory.
     |      :param n_threads: Number of threads to use for parallelization. A value of
     |        `0` (or negative) uses as many threads as there are files.
     |      :param temp_dir: Directory under which the files will first be downloaded
     |        when `overwrite=True` and the final destination path already exists. Once
     |        the download successfully completes, it will be swapped in.
     |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`read`. If no
     |        `chunk_size` argument is passed, a default value of 64 kB will be used.
     |        If a `progress` argument is passed and threading is used, care must be
     |        taken to ensure correct behavior.
     |      
     |      On success, this method returns the local download path.
     |  
     |  list(self, hdfs_path, status=False)
     |      Return names of files contained in a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory. If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param status: Also return each file's corresponding FileStatus_.
     |  
     |  makedirs(self, hdfs_path, permission=None)
     |      Create a remote directory, recursively if necessary.
     |      
     |      :param hdfs_path: Remote path. Intermediate directories will be created
     |        appropriately.
     |      :param permission: Octal permission to set on the newly created directory.
     |        These permissions will only be set on directories that do not already
     |        exist.
     |      
     |      This function currently has no return value as WebHDFS doesn't return a
     |      meaningful flag.
     |  
     |  parts(self, hdfs_path, parts=None, status=False)
     |      Returns a dictionary of part-files corresponding to a path.
     |      
     |      :param hdfs_path: Remote path. This directory should contain at most one
     |        part file per partition (otherwise one will be picked arbitrarily).
     |      :param parts: List of part-files numbers or total number of part-files to
     |        select. If a number, that many partitions will be chosen at random. By
     |        default all part-files are returned. If `parts` is a list and one of the
     |        parts is not found or too many samples are demanded, an
     |        :class:`~hdfs.util.HdfsError` is raised.
     |      :param status: Also return each file's corresponding FileStatus_.
     |  
     |  read(self, hdfs_path, offset=0, length=None, buffer_size=None, encoding=None, chunk_size=0, delimiter=None, progress=None)
     |      Read a file from HDFS.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param offset: Starting byte position.
     |      :param length: Number of bytes to be processed. `None` will read the entire
     |        file.
     |      :param buffer_size: Size of the buffer in bytes used for transferring the
     |        data. Defaults the the value set in the HDFS configuration.
     |      :param encoding: Encoding used to decode the request. By default the raw
     |        data is returned. This is mostly helpful in python 3, for example to
     |        deserialize JSON data (as the decoder expects unicode).
     |      :param chunk_size: If set to a positive number, the context manager will
     |        return a generator yielding every `chunk_size` bytes instead of a
     |        file-like object (unless `delimiter` is also set, see below).
     |      :param delimiter: If set, the context manager will return a generator
     |        yielding each time the delimiter is encountered. This parameter requires
     |        the `encoding` to be specified.
     |      :param progress: Callback function to track progress, called every
     |        `chunk_size` bytes (not available if the chunk size isn't specified). It
     |        will be passed two arguments, the path to the file being uploaded and the
     |        number of bytes transferred so far. On completion, it will be called once
     |        with `-1` as second argument.
     |      
     |      This method must be called using a `with` block:
     |      
     |      .. code-block:: python
     |      
     |        with client.read('foo') as reader:
     |          content = reader.read()
     |      
     |      This ensures that connections are always properly closed.
     |      
     |      .. note::
     |      
     |        The raw file-like object returned by this method (when called without an
     |        encoding, chunk size, or delimiter) can have a very different performance
     |        profile than local files. In particular, line-oriented methods are often
     |        slower. The recommended workaround is to specify an encoding when
     |        possible or read the entire file before splitting it.
     |  
     |  remove_acl(self, hdfs_path)
     |      RemoveAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      
     |      .. _RemoveAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL
     |  
     |  remove_acl_entries(self, hdfs_path, acl_spec)
     |      RemoveAclEntries_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      :param acl_spec: String representation of an ACL spec. Must be a valid
     |        string with entries for user, group and other. For example:
     |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
     |      
     |      .. _RemoveAclEntries: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL_Entries
     |  
     |  remove_default_acl(self, hdfs_path)
     |      RemoveDefaultAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      
     |      .. _RemoveDefaultAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_Default_ACL
     |  
     |  rename(self, hdfs_src_path, hdfs_dst_path)
     |      Move a file or folder.
     |      
     |      :param hdfs_src_path: Source path.
     |      :param hdfs_dst_path: Destination path. If the path already exists and is
     |        a directory, the source will be moved into it. If the path exists and is
     |        a file, or if a parent destination directory is missing, this method will
     |        raise an :class:`HdfsError`.
     |  
     |  rename_snapshot(self, hdfs_path, oldsnapshotname, snapshotname)
     |      Rename snapshot for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param oldsnapshotname snapshot name; if it does not exist,
     |        an :class:`HdfsError` will be raised.
     |      :param snapshotname new snapshot name; if it does already exist,
     |        an :class:`HdfsError` will be raised.
     |  
     |  resolve(self, hdfs_path)
     |      Return absolute, normalized path, with special markers expanded.
     |      
     |      :param hdfs_path: Remote path.
     |      
     |      Currently supported markers:
     |      
     |      * `'#LATEST'`: this marker gets expanded to the most recently updated file
     |        or folder. They can be combined using the `'{N}'` suffix. For example,
     |        `'foo/#LATEST{2}'` is equivalent to `'foo/#LATEST/#LATEST'`.
     |  
     |  set_acl(self, hdfs_path, acl_spec, clear=True)
     |      SetAcl_ or ModifyAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      :param acl_spec: String representation of an ACL spec. Must be a valid
     |        string with entries for user, group and other. For example:
     |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
     |      :param clear: Clear existing ACL entries. If set to false, all existing ACL
     |        entries that are not specified in this call are retained without changes,
     |        behaving like ModifyAcl_. For example: `"user:foo:rwx"`.
     |      
     |      .. _SetAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Set_ACL
     |      .. _ModifyAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Modify_ACL_Entries
     |  
     |  set_owner(self, hdfs_path, owner=None, group=None)
     |      Change the owner of file.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param owner: Optional, new owner for file.
     |      :param group: Optional, new group for file.
     |      
     |      At least one of `owner` and `group` must be specified.
     |  
     |  set_permission(self, hdfs_path, permission)
     |      Change the permissions of file.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param permission: New octal permissions string of file.
     |  
     |  set_replication(self, hdfs_path, replication)
     |      Set file replication.
     |      
     |      :param hdfs_path: Path to an existing remote file. An :class:`HdfsError`
     |        will be raised if the path doesn't exist or points to a directory.
     |      :param replication: Replication factor.
     |  
     |  set_times(self, hdfs_path, access_time=None, modification_time=None)
     |      Change remote timestamps.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param access_time: Timestamp of last file access.
     |      :param modification_time: Timestamps of last file access.
     |  
     |  status(self, hdfs_path, strict=True)
     |      Get FileStatus_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _FileStatus: FS_
     |      .. _FS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#FileStatus
     |  
     |  upload(self, hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs)
     |      Upload a file or directory to HDFS.
     |      
     |      :param hdfs_path: Target HDFS path. If it already exists and is a
     |        directory, files will be uploaded inside.
     |      :param local_path: Local path to file or folder. If a folder, all the files
     |        inside of it will be uploaded (note that this implies that folders empty
     |        of files will not be created remotely).
     |      :param n_threads: Number of threads to use for parallelization. A value of
     |        `0` (or negative) uses as many threads as there are files.
     |      :param temp_dir: Directory under which the files will first be uploaded
     |        when `overwrite=True` and the final remote path already exists. Once the
     |        upload successfully completes, it will be swapped in.
     |      :param chunk_size: Interval in bytes by which the files will be uploaded.
     |      :param progress: Callback function to track progress, called every
     |        `chunk_size` bytes. It will be passed two arguments, the path to the
     |        file being uploaded and the number of bytes transferred so far. On
     |        completion, it will be called once with `-1` as second argument.
     |      :param cleanup: Delete any uploaded files if an error occurs during the
     |        upload.
     |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`write`. In
     |        particular, set `overwrite` to overwrite any existing file or directory.
     |      
     |      On success, this method returns the remote upload path.
     |  
     |  walk(self, hdfs_path, depth=0, status=False, ignore_missing=False, allow_dir_changes=False)
     |      Depth-first walk of remote filesystem.
     |      
     |      :param hdfs_path: Starting path. If the path doesn't exist, an
     |        :class:`HdfsError` will be raised. If it points to a file, the returned
     |        generator will be empty.
     |      :param depth: Maximum depth to explore. `0` for no limit.
     |      :param status: Also return each file or folder's corresponding FileStatus_.
     |      :param ignore_missing: Ignore missing nested folders rather than raise an
     |        exception. This can be useful when the tree is modified during a walk.
     |      :param allow_dir_changes: Allow changes to the directories' list to affect
     |        the walk. For example clearing it by setting `dirs[:] = []` would prevent
     |        the walk from entering any nested directories. This option can only be set
     |        when `status` is false.
     |      
     |      This method returns a generator yielding tuples `(path, dirs, files)`
     |      where `path` is the absolute path to the current directory, `dirs` is the
     |      list of directory names it contains, and `files` is the list of file names
     |      it contains.
     |  
     |  write(self, hdfs_path, data=None, overwrite=False, permission=None, blocksize=None, replication=None, buffersize=None, append=False, encoding=None)
     |      Create a file on HDFS.
     |      
     |      :param hdfs_path: Path where to create file. The necessary directories will
     |        be created appropriately.
     |      :param data: Contents of file to write. Can be a string, a generator or a
     |        file object. The last two options will allow streaming upload (i.e.
     |        without having to load the entire contents into memory). If `None`, this
     |        method will return a file-like object and should be called using a `with`
     |        block (see below for examples).
     |      :param overwrite: Overwrite any existing file or directory.
     |      :param permission: Octal permission to set on the newly created file.
     |        Leading zeros may be omitted.
     |      :param blocksize: Block size of the file.
     |      :param replication: Number of replications of the file.
     |      :param buffersize: Size of upload buffer.
     |      :param append: Append to a file rather than create a new one.
     |      :param encoding: Encoding used to serialize data written.
     |      
     |      Sample usages:
     |      
     |      .. code-block:: python
     |      
     |        from json import dump, dumps
     |      
     |        records = [
     |          {'name': 'foo', 'weight': 1},
     |          {'name': 'bar', 'weight': 2},
     |        ]
     |      
     |        # As a context manager:
     |        with client.write('data/records.jsonl', encoding='utf-8') as writer:
     |          dump(records, writer)
     |      
     |        # Or, passing in a generator directly:
     |        client.write('data/records.jsonl', data=dumps(records), encoding='utf-8')
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from hdfs.client.Client:
     |  
     |  from_options(options, class_name='Client') from hdfs.client._ClientType
     |      Load client from options.
     |      
     |      :param options: Options dictionary.
     |      :param class_name: Client class name. Defaults to the base :class:`Client`
     |        class.
     |      
     |      This method provides a single entry point to instantiate any registered
     |      :class:`Client` subclass. To register a subclass, simply load its
     |      containing module. If using the CLI, you can use the `autoload.modules` and
     |      `autoload.paths` options.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from hdfs.client.Client:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes inherited from hdfs.client.Client:
     |  
     |  __registry__ = {'Client': <class 'hdfs.client.Client'>, 'Hdfs': <class...
```

#### Classe `HttpConfig`

```text
    class HttpConfig(bbmagic.file_config.FileConfig)
     |  HttpConfig(set_no_proxy: bool = True)
     |  
     |  Method resolution order:
     |      HttpConfig
     |      bbmagic.file_config.FileConfig
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, set_no_proxy: bool = True)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  set_no_proxy(self) -> None
     |      Garante que a variável no_proxy está configurada para ignorar o domínio
     |      da API web da BBMagic
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from bbmagic.file_config.FileConfig:
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from bbmagic.file_config.FileConfig:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `Kinit`

```text
    class Kinit(builtins.object)
     |  Kinit(username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
     |  
     |  Autentica o usuário no Kerberos utilizando kinit.
     |  
     |  :param username: matrícula ou caminho para arquivo keytab
     |  :param conf_file: caminho para o arquivo krb5.conf. Caso não seja informado será
     |                      utilizada configuração do arquivo temporátio gerado pelo pacote
     |  :param hdp: Paramêtro deprecado, mantido para retrocompatibilidade de código apenas.
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get_ticket(self) -> str
     |      Autentica no Kerberos utilizando Kinit.
     |      
     |      Verifica se o usuário já possui um ticket kerberos válido. Caso não encontre
     |      realiza a autenticação com kinit. O parâmetro informado pode ser a matrícula
     |      do usuário ou uma keytab.
     |      
     |      Caso a matrícula seja informada, um prompt será exibido para que a senha SISBB
     |      seja informada.
     |      
     |      Caso o caminho para uma keytab seja informada, utiliza o arquivo. Caso seja informado
     |      o nome de uma keytab sem a extensão ".keytab" assume existe o arquivo "username.keytab"
     |      no diretório de execução do script.
     |      
     |      Retorna o nome do usuário utilizado na autenticação.
     |  
     |  get_username(self, username: Optional[str]) -> str
     |  
     |  is_matricula(self, string: str) -> bool
     |  
     |  raise_keytab_on_modelagem(self) -> None
     |  
     |  run_kinit_cmd(self, kinit_cmd: list, password: Optional[str]) -> int
     |  
     |  user_has_ticket(self) -> bool
     |      Verifica se há um ticket válido no cache de credenciais do Kerberos.
     |      
     |      Verifica as credenciais no cache padrão ou no caminho indicado na
     |      variável de ambiente KRB5CCNAME.
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  ambiente
     |  
     |  bypass_disallow_keytab
     |  
     |  encoding
     |  
     |  krb5_conf
     |  
     |  refuse_keytab
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  BACKOFF_LIMIT = 3600
```

#### Classe `MetaDataHive`

```text
    class MetaDataHive(builtins.object)
     |  MetaDataHive() -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get_token(self) -> Optional[str]
     |  
     |  get_url(self) -> Optional[str]
     |  
     |  status_db(self, db: str, list: Optional[bool] = False) -> Optional[pandas.core.frame.DataFrame]
     |  
     |  status_table(self, nome_db: Optional[str] = None, nome_tabela: Optional[str] = None) -> Optional[pandas.core.frame.DataFrame]
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `SAS`

```text
    class SAS(builtins.object)
     |  SAS(username: str = '', host: str = 'sasanl03.intranet.bb.com.br', port: int = 8591, appserver: str = 'SASApp_ANL03 - Workspace Server', authkey: str = '', libnames: Optional[List[dict]] = None, timeout: int = 30) -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: str = '', host: str = 'sasanl03.intranet.bb.com.br', port: int = 8591, appserver: str = 'SASApp_ANL03 - Workspace Server', authkey: str = '', libnames: Optional[List[dict]] = None, timeout: int = 30) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  config_authinfo(self, name: str = 'bbmagic') -> None
     |  
     |  create_libnames(self) -> None
     |  
     |  query(self, sql: str, chunksize: Optional[int] = 2500, verbose: bool = False) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `Spark`

```text
    class Spark(builtins.object)
     |  Spark(session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
     |  
     |  Cria uma sessão Spark.
     |  
     |  :param session_name: nome da sessão que será exibido na Web UI do Spark
     |  :param username: caminho para arquivo .keytab ou matrícula sem o dígito do usuário
     |  :param python: versão do Python da sessão Spark (2 ou 3)
     |  :param language: linguagem utilizada na sessão Spark ('python' ou 'scala')
     |  :param auth: modo de autenticação no Livy
     |  :param timeout: tempo máximo até que a sessão Spark seja criada
     |  :param db2: configura a sessão Spark para conexão JDBC ao DB2
     |  :param spark_conf: dicionário de parâmetros adicionais para configuração da sessão Spark.
     |                     Esse parâmetro tem prioridade sobre a padrão do BBMagic
     |  :param jars: lista de paths de arquivos .jar localizados no HDFS que serão utilizados na
     |               sessão. Ex: ['hdfs:///user/jars/database.jar']
     |  :param env: dicionário utilizado para definição de variáveis de ambiente na sessão Spark
     |  :param debug: exibe mais informações sobre a sessão Spark
     |  :param driver_memory: Quantidade de memória alocada para o driver da sessão Spark seguida
     |                        pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
     |                        (Ex.: '512m', '4g').
     |  :param driver_cores: Quantidade de cores alocados para o driver da sessão Spark
     |  :param num_executors: Quantidade de executores alocados para a sessão Spark.
     |  :param executor_memory: Quantidade de memória alocada cada executor da sessão Spark seguida
     |                          pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
     |                          (Ex.: '512m', '4g').
     |  :param executor_cores: Quantidade de cores alocados para cada executor da sessão Spark
     |  :param spark_version: Identifica a versao do Spark que ira receber a conexao - 2 ou 3
     |  
     |  Methods defined here:
     |  
     |  __del__(self) -> None
     |      Garante que a sessão Livy é encerrada assim que o Python finalize
     |  
     |  __init__(self, session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  close(self) -> None
     |      Encerra a sessão Spark
     |  
     |  config_db2(self) -> None
     |  
     |  config_jars(self) -> None
     |      Adiciona os jars para utilização de bibliotecas de machine learning distribuidas nas sessões spark 3
     |  
     |  config_sparkmagic(self) -> None
     |  
     |  config_virtualenv(self, virtualenv: Optional[str], overwrite: bool = False) -> Optional[str]
     |  
     |  connect(self) -> None
     |  
     |  enforce_dynamic_allocation(self, config: Optional[Dict[str, str]]) -> Optional[dict]
     |  
     |  get_from_spark(self, var_name: str)
     |      Importa o conteúdo de uma variável da sessão Spark para a sessão local.
     |      
     |      
     |      :param var_name: nome da variável que será importada.
     |      
     |      :return: Retorna o valor da variável
     |  
     |  send_to_spark(self, var) -> None
     |      Envia uma variável local para a sessão Spark.
     |      
     |      A variável será definida com mesmo nome na sessão Spark e o valor
     |      será transmitido utilizando pickle.
     |      
     |      :param var: variável que será enviada para a sessão Spark.
     |      
     |      :return: None
     |  
     |  ----------------------------------------------------------------------
     |  Class methods defined here:
     |  
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  ambiente
     |  
     |  bbmagic_session_id
     |  
     |  
     |  default_env
     |  
     |  force_dynammic_allocation
     |  
     |  livy_conn
     |  
     |  livy_session_id
     |  
     |  livy_url
     |  
     |  livy_version
     |  
     |  pickle_protocol
     |  
     |  spark_session_name
     |  
     |  spark_version
     |  
     |  user
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `TeamsNotify`

```text
    class TeamsNotify(builtins.object)
     |  TeamsNotify(webhook: str)
     |  
     |  Methods defined here:
     |  
     |  __init__(self, webhook: str)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  error(self, title, text, model='', situation='', other_details='', color='E81123')
     |  
     |  info(self, title, text, model='', situation='', other_details='', color='008000')
     |  
     |  post_msg(self, title, text, model, situation, other_details, color=None)
     |  
     |  post_msg_workflows(self, title: str, text: str, model: str = '', situation: str = '', other_details: str = '', type: str = '') -> dict
     |      Função que envia mensagens por meio dos fluxos Workflows no Microsoft Teams
     |  
     |  warning(self, title, text, model='', situation='', other_details='', color='FFFF00')
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    __all__ = ['HttpConfig', 'FileConfig', 'GitLabConfig', 'AuthInfo', 'Au...
```

### VERSION

`3.1.4`

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/__init__.py`

---

## Módulo `bbmagic.checks`

### NAME

`bbmagic.checks`

### FUNCTIONS

#### Função `check_configure_venv`

```text
    check_configure_venv(info)
```

#### Função `check_pre_run_cell`

```text
    check_pre_run_cell(info)
```

#### Função `check_saveastable`

```text
    check_saveastable(info)
        Emite um warning se o usuário estiver utilizando saveAsTable em uma sessão Spark
```

#### Função `register_checks`

```text
    register_checks(checks: dict) -> None
```

### DATA

```text
    spark_checks = {'pre_run_cell': <function check_pre_run_cell>}
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/checks.py`

---

## Módulo `bbmagic.common`

### NAME

`bbmagic.common`

### CLASSES

#### Hierarquia

```text
    builtins.RuntimeWarning(builtins.Warning)
        BoasPraticasWarning
```

#### Classe `BoasPraticasWarning`

```text
    class BoasPraticasWarning(builtins.RuntimeWarning)
     |  Method resolution order:
     |      BoasPraticasWarning
     |      builtins.RuntimeWarning
     |      builtins.Warning
     |      builtins.Exception
     |      builtins.BaseException
     |      builtins.object
     |  
     |  Data descriptors defined here:
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.RuntimeWarning:
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from builtins.RuntimeWarning:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.BaseException:
     |  
     |  __delattr__(self, name, /)
     |      Implement delattr(self, name).
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __reduce__(...)
     |      Helper for pickle.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __setattr__(self, name, value, /)
     |      Implement setattr(self, name, value).
     |  
     |  __setstate__(...)
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  with_traceback(...)
     |      Exception.with_traceback(tb) --
     |      set self.__traceback__ to tb and return self.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from builtins.BaseException:
     |  
     |  __cause__
     |      exception cause
     |  
     |  __context__
     |      exception context
     |  
     |  __dict__
     |  
     |  __suppress_context__
     |  
     |  __traceback__
     |  
     |  args
```

### FUNCTIONS

#### Função `create_virtualenv`

```text
    create_virtualenv(requirements: Union[List[str], str] = None, path: Optional[str] = None, create_zip: bool = False, zip_path: str = '.', zip_name: str = 'virtualenv') -> virtualenvapi.manage.VirtualEnvironment
        Cria um virtualenv.
        
        requirements: Caminho para um arquivo texto contendo os requirements ou uma lista
        de pacotes para instalação.
        path: Caminho onde será criado o virtualenv. Quando o path for igual a None será
        o virtualenv será criado em um diretório temporário que será excluído ao fim da
        execução da função. Este comportamento é útil quando deseja-se apenas obter um
        arquivo .zip referente ao ambiente virtual.
        create_zip: Indica se deverá ser criado um arquivo .zip com o conteúdo do ambiente
        virtual criado.
        zip_path: Caminho onde deverá ser criado o arquivo .zip.
        zip_name: Nome do arquivo .zip sem a extensão.
```

#### Função `get_ambiente`

```text
    get_ambiente() -> str
```

#### Função `get_bbmagic_spark_version`

```text
    get_bbmagic_spark_version(default: Optional[int] = None) -> int
```

#### Função `get_cloud`

```text
    get_cloud() -> str
```

#### Função `get_environment`

```text
    get_environment() -> str
```

#### Função `get_project_id`

```text
    get_project_id(raise_not_found: bool = False) -> Optional[str]
        Retorna o id do projeto da Plataforma Analítica
```

### DATA

```text
    List = typing.List
        A generic version of list.
    
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
    
    Union = typing.Union
        Union type; Union[X, Y] means either X or Y.
        
        To define a union, use e.g. Union[int, str].  Details:
        - The arguments must be types and there must be at least one.
        - None as an argument is a special case and is replaced by
          type(None).
        - Unions of unions are flattened, e.g.::
        
            Union[Union[int, str], float] == Union[int, str, float]
        
        - Unions of a single argument vanish, e.g.::
        
            Union[int] == int  # The constructor actually returns int
        
        - Redundant arguments are skipped, e.g.::
        
            Union[int, str, int] == Union[int, str]
        
        - When comparing unions, the argument order is ignored, e.g.::
        
            Union[int, str] == Union[str, int]
        
        - You cannot subclass or instantiate a union.
        - You can use Optional[X] as a shorthand for Union[X, None].
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/common.py`

---

## Módulo `bbmagic.db2`

### NAME

`bbmagic.db2`

### DESCRIPTION

```text
    Módulo para acesso aos dados no DB2
    -----------------------------------
```

### CLASSES

#### Hierarquia

```text
    builtins.object
        Db2
    builtins.tuple(builtins.object)
        DB2Server
```

#### Classe `DB2Server`

```text
    class DB2Server(builtins.tuple)
     |  DB2Server(host, port, database)
     |  
     |  DB2Server(host, port, database)
     |  
     |  Method resolution order:
     |      DB2Server
     |      builtins.tuple
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __getnewargs__(self)
     |      Return self as a plain tuple.  Used by copy and pickle.
     |  
     |  __repr__(self)
     |      Return a nicely formatted representation string
     |  
     |  _asdict(self)
     |      Return a new dict which maps field names to their values.
     |  
     |  _replace(self, /, **kwds)
     |      Return a new DB2Server object replacing specified fields with new values
     |  
     |  ----------------------------------------------------------------------
     |  Class methods defined here:
     |  
     |  _make(iterable) from builtins.type
     |      Make a new DB2Server object from a sequence or iterable
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  __new__(_cls, host, port, database)
     |      Create new instance of DB2Server(host, port, database)
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  host
     |      Alias for field number 0
     |  
     |  port
     |      Alias for field number 1
     |  
     |  database
     |      Alias for field number 2
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  _field_defaults = {}
     |  
     |  _fields = ('host', 'port', 'database')
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.tuple:
     |  
     |  __add__(self, value, /)
     |      Return self+value.
     |  
     |  __contains__(self, key, /)
     |      Return key in self.
     |  
     |  __eq__(self, value, /)
     |      Return self==value.
     |  
     |  __ge__(self, value, /)
     |      Return self>=value.
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __getitem__(self, key, /)
     |      Return self[key].
     |  
     |  __gt__(self, value, /)
     |      Return self>value.
     |  
     |  __hash__(self, /)
     |      Return hash(self).
     |  
     |  __iter__(self, /)
     |      Implement iter(self).
     |  
     |  __le__(self, value, /)
     |      Return self<=value.
     |  
     |  __len__(self, /)
     |      Return len(self).
     |  
     |  __lt__(self, value, /)
     |      Return self<value.
     |  
     |  __mul__(self, value, /)
     |      Return self*value.
     |  
     |  __ne__(self, value, /)
     |      Return self!=value.
     |  
     |  __rmul__(self, value, /)
     |      Return value*self.
     |  
     |  count(self, value, /)
     |      Return number of occurrences of value.
     |  
     |  index(self, value, start=0, stop=9223372036854775807, /)
     |      Return first index of value.
     |      
     |      Raises ValueError if the value is not present.
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from builtins.tuple:
     |  
     |  __class_getitem__(...) from builtins.type
     |      See PEP 585
```

#### Classe `Db2`

```text
    class Db2(builtins.object)
     |  Db2(user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
     |  
     |  Cria uma conexão ao DB2
     |  
     |  Methods defined here:
     |  
     |  __init__(self, user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  connect(self) -> ibm_db_dbi.Connection
     |      Cria a conexão JDBC com o servidor DB2.
     |  
     |  describe(self, schema: str, table: str) -> IPython.core.display.HTML
     |      Gera um relatório consolidado com os metadados da tabela existentes no catálogo
     |      do DB2.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um objeto HTML com o relatório para exibição no Jupyter Notebook.
     |      :rtype: IPython.core.display.HTML
     |  
     |  get_cofre_credentials(self, project_id: str) -> dict
     |      Recupera credenciais do cofre com base no project_id do projeto
     |  
     |  query(self, sql: str, params: Optional[list] = None, chunksize: Optional[int] = 2500) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
     |      Retorna um DataFrame contendo o resultado da execução da query SQL.
     |      
     |      :param sql: query SQL para execução
     |      :param params: lista de parâmetros para utilização na query
     |      :param chunksize: Se especificado, retorna um iterador onde chunksize é a quantidade
     |                        de linhas incluídas em cada chunk
     |      
     |      :return: Daframe ou Iterator[DataFrame]
     |      
     |      Exemplos de Uso::
     |      
     |          >>> for chunk in db2.query("SELECT * FROM db2mci.cliente LIMIT 10000"):
     |          ...     print(len(chunk))
     |          2500
     |          2500
     |          2500
     |          2500
     |      
     |      Sem utilização de chunks
     |      
     |          >>> df = db2.query("SELECT cod FROM db2mci.cliente LIMIT 100", chunksize=None)
     |  
     |  set_conn_param(self, param_name, param_value: Union[str, int, NoneType]) -> Union[str, int]
     |  
     |  show_schemas(self) -> pandas.core.frame.DataFrame
     |      Lista todos os schemas no database
     |      
     |      :return: Retorna um Pandas DataFrame contendo uma linha para cada schema encontrado.
     |      :rtype: pandas.core.api.DataFrame
     |      
     |      Exemplo de uso::
     |      
     |          >>> db2.show_schemas()
     |  
     |  show_tables(self, schema: str) -> pandas.core.frame.DataFrame
     |      Lista todas as tabelas e views de um schema.
     |      
     |      :param schema: nome do schema
     |      
     |      :return: Retorna um Pandas DataFrame contendo uma linha para cada tabela do schema
     |               e as informações *schema*, *name* e *type* nas respectivas colunas.
     |      :rtype: pandas.core.api.DataFrame
     |      
     |      Exemplo de uso::
     |      
     |          >>> db2.show_tables("DB2MCI")
     |  
     |  syscolumns(self, schema: str, table: str) -> pandas.core.frame.DataFrame
     |      Retorna metadados das colunas de uma tabela.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um Pandas DataFrame contendo as informações sobre as colunas da
     |               tabela de acordo com o catálogo syscat.syscolumns
     |      :rtype: pandas.core.api.DataFrame
     |  
     |  systabstats(self, schema: str, table: str) -> pandas.core.frame.DataFrame
     |      Retorna metadados de uma tabela.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um Pandas DataFrame contendo as informações sobre a tabela
     |               existentes no catálogo syscat.systabstats
     |      :rtype: pandas.core.api.DataFrame
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  url
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  envs = {'database': 'DB2_DATABASE', 'host': 'DB2_HOST', 'password': 'D...
     |  
     |  jars_path = '/projeto/libs/lib/python3.9/site-packages/bbmagic/jars/db...
```

### DATA

```text
    DB2_BACKOFF_LIMIT = 3600
    Iterator = typing.Iterator
        A generic version of collections.abc.Iterator.
    
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
    
    Union = typing.Union
        Union type; Union[X, Y] means either X or Y.
        
        To define a union, use e.g. Union[int, str].  Details:
        - The arguments must be types and there must be at least one.
        - None as an argument is a special case and is replaced by
          type(None).
        - Unions of unions are flattened, e.g.::
        
            Union[Union[int, str], float] == Union[int, str, float]
        
        - Unions of a single argument vanish, e.g.::
        
            Union[int] == int  # The constructor actually returns int
        
        - Redundant arguments are skipped, e.g.::
        
            Union[int, str, int] == Union[int, str]
        
        - When comparing unions, the argument order is ignored, e.g.::
        
            Union[int, str] == Union[str, int]
        
        - You cannot subclass or instantiate a union.
        - You can use Optional[X] as a shorthand for Union[X, None].
    
    db2_desenv = DB2Server(host='dsdb2d01.plexdes.bb.com.br', port=446, da...
    db2_homologa = DB2Server(host='bdb2h01.plexhom.bb.com.br', port=446, d...
    db2_prod = DB2Server(host='gwdb2.bb.com.br', port=50100, database='BDB...
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/db2.py`

---

## Módulo `bbmagic.environment`

### NAME

`bbmagic.environment`

### CLASSES

#### Hierarquia

```text
    builtins.object
        Environment
```

#### Classe `Environment`

```text
    class Environment(builtins.object)
     |  Methods defined here:
     |  
     |  get(self) -> str
     |  
     |  is_modeling(self) -> bool
     |  
     |  is_prodution(self) -> bool
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/environment.py`

---

## Módulo `bbmagic.exceptions`

### NAME

`bbmagic.exceptions`

### CLASSES

#### Hierarquia

```text
    builtins.Exception(builtins.BaseException)
        KinitError
        PublicadorError
```

#### Classe `KinitError`

```text
    class KinitError(builtins.Exception)
     |  Erro exibido quando há falha na autenticação com o kinit
     |  
     |  Method resolution order:
     |      KinitError
     |      builtins.Exception
     |      builtins.BaseException
     |      builtins.object
     |  
     |  Data descriptors defined here:
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.Exception:
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from builtins.Exception:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.BaseException:
     |  
     |  __delattr__(self, name, /)
     |      Implement delattr(self, name).
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __reduce__(...)
     |      Helper for pickle.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __setattr__(self, name, value, /)
     |      Implement setattr(self, name, value).
     |  
     |  __setstate__(...)
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  with_traceback(...)
     |      Exception.with_traceback(tb) --
     |      set self.__traceback__ to tb and return self.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from builtins.BaseException:
     |  
     |  __cause__
     |      exception cause
     |  
     |  __context__
     |      exception context
     |  
     |  __dict__
     |  
     |  __suppress_context__
     |  
     |  __traceback__
     |  
     |  args
```

#### Classe `PublicadorError`

```text
    class PublicadorError(builtins.Exception)
     |  Erro exibido quando há falha ao salvar um modelo no Artifactory
     |  
     |  Method resolution order:
     |      PublicadorError
     |      builtins.Exception
     |      builtins.BaseException
     |      builtins.object
     |  
     |  Data descriptors defined here:
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.Exception:
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from builtins.Exception:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.BaseException:
     |  
     |  __delattr__(self, name, /)
     |      Implement delattr(self, name).
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __reduce__(...)
     |      Helper for pickle.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __setattr__(self, name, value, /)
     |      Implement setattr(self, name, value).
     |  
     |  __setstate__(...)
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  with_traceback(...)
     |      Exception.with_traceback(tb) --
     |      set self.__traceback__ to tb and return self.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from builtins.BaseException:
     |  
     |  __cause__
     |      exception cause
     |  
     |  __context__
     |      exception context
     |  
     |  __dict__
     |  
     |  __suppress_context__
     |  
     |  __traceback__
     |  
     |  args
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/exceptions.py`

---

## Módulo `bbmagic.file_config`

### NAME

`bbmagic.file_config`

### CLASSES

#### Hierarquia

```text
    builtins.object
        FileConfig
```

#### Classe `FileConfig`

```text
    class FileConfig(builtins.object)
     |  FileConfig(path) -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self, path) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    BBMAGIC_VERSION = '3.1.4'
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/file_config.py`

---

## Módulo `bbmagic.gitlab_config`

### NAME

`bbmagic.gitlab_config`

### CLASSES

#### Hierarquia

```text
    bbmagic.file_config.FileConfig(builtins.object)
        GitLabConfig
```

#### Classe `GitLabConfig`

```text
    class GitLabConfig(bbmagic.file_config.FileConfig)
     |  Method resolution order:
     |      GitLabConfig
     |      bbmagic.file_config.FileConfig
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from bbmagic.file_config.FileConfig:
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from bbmagic.file_config.FileConfig:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    BBMAGIC_VERSION = '3.1.4'
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/gitlab_config.py`

---

## Módulo `bbmagic.hdfs`

### NAME

`bbmagic.hdfs`

### DESCRIPTION

```text
    Implementa funcionalidades de leitura e escrita no HDFS utiliando a API
    WebHDFS_. Caso exista, o valor contido na variável de ambiente BBMAGIC_HDFS_URL
    será utilizado para a conexão.
    
    A classe Hdfs é um wrapper criado sobre o pacote HdfsCli_, para facilitar
    
    .. _WebHDFS: http://hadoop.apache.org/docs/current/hadoop-project-dist/hadoop-hdfs/WebHDFS.html
    .. _HdfsCli: https://hdfscli.readthedocs.io/en/latest/index.html
    __ HdfsCli_
    
    Conectando-se ao HDFS
    ---------------------
    
    .. code-block:: python
    
       from bbmagic import Hdfs
    
       hdfs = Hdfs("F9999999")
    
    Lendo e escrevendo arquivos
    ---------------------------
    
    Lendo arquivos no HDFS
    ======================
    
    O método `read()` implementa a funcionalidade para leiutura de arquivos do HDFS. Deve ser utilizado
    em um bloco `with` para garantir que a conexão e transferência seja encerrada corretamente. Para
    baixar um arquivo diretamento para o disco deve-se utilizar o método `download()`
    
    .. code-block:: python
    
       from bbmagic import Hdfs
    
       hdfs = Hdfs('test.keytab')
    
       # carregando um arquivo em memória
       hdfs_file = 'dataset.csv'
       with hdfs.read(hdfs_file) as reader:
           dados = reader.read()
    
    Se o argumento chunksize for informado, o método retornará um iterador tornando possível trabalhar
    com arquivos de tamanho superior à memória disponível na máquina.
    
    .. code-block:: python
    
       # lendo um arquivo em chunks
       with hdfs.read('features', chunk_size=8096) as reader:
           for chunk in reader:
               pass
    
    Da mesma forma, se o argumento `delimiter` for informado o método retornará um iterador com chunks
    gerados a cada seperador encontrado no arquivo.
    
    .. code-block:: python
    
       # lendo um arquivo csv linha a linha
       with hdfs.read('dataset.csv', encoding='utf-8', delimiter='\n') as reader:
           for line in reader:
               pass
    
    Baixando um arquivo diretamento para o disco local:
    
    .. code-block:: python
    
        hdfs.download('arquivo-hdfs.csv', 'arquivo-local.csv')
    
    
    Escrevendo arquivos no HDFS
    ===========================
    
    Para escrever arquivos no HDFS utiliza-se o método `write` para dados em memória ou
    `upload` para enviar um arquivo existente no disco.
    
    .. code-block:: python
    
       # escrevendo partes de um arquivo local no HDFS
       with open('arquivolocal.txt') as reader, hdfs.write('datasetfinal.txt') as writer:
           for line in reader:
               if line.startswith('-'):
                   writer.write(line)
    
    De forma mais suscinta, pode-se passar um iterador para o método `write`:
    
    .. code-block:: python
    
        from json import dumps
    
        hdfs.write('/dados/dominio/modelo.json', dumps(modelo))
    
    
    Para fazer o upload de um arquivo existente no diso:
    
    .. code-block:: python
    
        destino_hdfs = 'dados/meuprojeto/dataset.csv'
        origem_arquivo = 'output/dataset.csv'
    
        # envia o arquivo dataset.csv sobresrevendo os dados no HDFS caso já existam
        hdfs.upload(destino_hdfs, origem_aquivo, overwrite=True)
    
    
    Explorando o sistema de arquivos do HDFS
    ----------------------------------------
    
    .. code-block:: python
    
        # Obtendo informações sobre o conteúdo de um arquivo ou diretório.
        content = hdfs.content('meusdados')
    
        # Listando todos arquivos em um diretório
        fnames = hdfs.list('meusdados')
    
        # Obtendo informações sobre o status de um arquivo ou diretório
        status = hdfs.status('meusdados/features.csv')
    
        # Renomeando ('movendo') um arquivo.
        hdfs.rename('meusdados/features.csv', 'features-amostra.csv')
    
        # Deletando um arquivo ou pastas
        hdfs.delete('meusdados', recursive=True)
    
    |
```

### CLASSES

#### Hierarquia

```text
    hdfs.ext.kerberos.KerberosClient(hdfs.client.Client)
        Hdfs
```

#### Classe `Hdfs`

```text
    class Hdfs(hdfs.ext.kerberos.KerberosClient)
     |  Hdfs(username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
     |  
     |  Permite acesso ao HDFS com autenticação via kerberos.
     |  
     |  :param username: matrícula ou caminho para arquivo keytab
     |  :param \*\*kwargs: Argumentos adicionais passados para a classe HTTPKerberosAuth.
     |  
     |  Method resolution order:
     |      Hdfs
     |      hdfs.ext.kerberos.KerberosClient
     |      hdfs.client.Client
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  set_no_proxy(self) -> None
     |      Garante que a variável no_proxy está configurada para ignorar o domínio
     |      da API web da BBMagic
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from hdfs.client.Client:
     |  
     |  __repr__(self)
     |      Return repr(self).
     |  
     |  acl_status(self, hdfs_path, strict=True)
     |      Get AclStatus_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _AclStatus: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Get_ACL_Status
     |  
     |  allow_snapshot(self, hdfs_path)
     |      Allow snapshots for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist or does points to a normal file, an
     |        :class:`HdfsError` will be raised.  No-op if snapshotting is
     |        already allowed.
     |  
     |  checksum(self, hdfs_path)
     |      Get a remote file's checksum.
     |      
     |      :param hdfs_path: Remote path. Must point to a file.
     |  
     |  content(self, hdfs_path, strict=True)
     |      Get ContentSummary_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _ContentSummary: CS_
     |      .. _CS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#ContentSummary
     |  
     |  create_snapshot(self, hdfs_path, snapshotname=None)
     |      Create snapshot for a remote folder where it was allowed.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist, doesn't allow to create snapshot or points to a
     |        normal file, an :class:`HdfsError` will be raised.
     |      :param snapshotname snapshot name; if absent, name is generated
     |        by the server.
     |      
     |      Returns a path to created snapshot.
     |  
     |  delete(self, hdfs_path, recursive=False, skip_trash=True)
     |      Remove a file or directory from HDFS.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param recursive: Recursively delete files and directories. By default,
     |        this method will raise an :class:`HdfsError` if trying to delete a
     |        non-empty directory.
     |      :param skip_trash: When false, the deleted path will be moved to an
     |        appropriate trash folder rather than deleted. This requires Hadoop 2.9+
     |      
     |      This function returns `True` if the deletion was successful and `False` if
     |      no file or directory previously existed at `hdfs_path`.
     |  
     |  delete_snapshot(self, hdfs_path, snapshotname)
     |      Remove snapshot for a remote folder where it was allowed.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param snapshotname snapshot name; if it does not exist, an
     |        :class:`HdfsError` will be raised.
     |  
     |  disallow_snapshot(self, hdfs_path)
     |      Disallow snapshots for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist, points to a normal file or there are some
     |        snapshots, an :class:`HdfsError` will be raised.
     |      
     |      No-op if snapshotting is disallowed/never allowed.
     |  
     |  download(self, hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs)
     |      Download a file or folder from HDFS and save it locally.
     |      
     |      :param hdfs_path: Path on HDFS of the file or folder to download. If a
     |        folder, all the files under it will be downloaded.
     |      :param local_path: Local path. If it already exists and is a directory,
     |        the files will be downloaded inside of it.
     |      :param overwrite: Overwrite any existing file or directory.
     |      :param n_threads: Number of threads to use for parallelization. A value of
     |        `0` (or negative) uses as many threads as there are files.
     |      :param temp_dir: Directory under which the files will first be downloaded
     |        when `overwrite=True` and the final destination path already exists. Once
     |        the download successfully completes, it will be swapped in.
     |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`read`. If no
     |        `chunk_size` argument is passed, a default value of 64 kB will be used.
     |        If a `progress` argument is passed and threading is used, care must be
     |        taken to ensure correct behavior.
     |      
     |      On success, this method returns the local download path.
     |  
     |  list(self, hdfs_path, status=False)
     |      Return names of files contained in a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory. If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param status: Also return each file's corresponding FileStatus_.
     |  
     |  makedirs(self, hdfs_path, permission=None)
     |      Create a remote directory, recursively if necessary.
     |      
     |      :param hdfs_path: Remote path. Intermediate directories will be created
     |        appropriately.
     |      :param permission: Octal permission to set on the newly created directory.
     |        These permissions will only be set on directories that do not already
     |        exist.
     |      
     |      This function currently has no return value as WebHDFS doesn't return a
     |      meaningful flag.
     |  
     |  parts(self, hdfs_path, parts=None, status=False)
     |      Returns a dictionary of part-files corresponding to a path.
     |      
     |      :param hdfs_path: Remote path. This directory should contain at most one
     |        part file per partition (otherwise one will be picked arbitrarily).
     |      :param parts: List of part-files numbers or total number of part-files to
     |        select. If a number, that many partitions will be chosen at random. By
     |        default all part-files are returned. If `parts` is a list and one of the
     |        parts is not found or too many samples are demanded, an
     |        :class:`~hdfs.util.HdfsError` is raised.
     |      :param status: Also return each file's corresponding FileStatus_.
     |  
     |  read(self, hdfs_path, offset=0, length=None, buffer_size=None, encoding=None, chunk_size=0, delimiter=None, progress=None)
     |      Read a file from HDFS.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param offset: Starting byte position.
     |      :param length: Number of bytes to be processed. `None` will read the entire
     |        file.
     |      :param buffer_size: Size of the buffer in bytes used for transferring the
     |        data. Defaults the the value set in the HDFS configuration.
     |      :param encoding: Encoding used to decode the request. By default the raw
     |        data is returned. This is mostly helpful in python 3, for example to
     |        deserialize JSON data (as the decoder expects unicode).
     |      :param chunk_size: If set to a positive number, the context manager will
     |        return a generator yielding every `chunk_size` bytes instead of a
     |        file-like object (unless `delimiter` is also set, see below).
     |      :param delimiter: If set, the context manager will return a generator
     |        yielding each time the delimiter is encountered. This parameter requires
     |        the `encoding` to be specified.
     |      :param progress: Callback function to track progress, called every
     |        `chunk_size` bytes (not available if the chunk size isn't specified). It
     |        will be passed two arguments, the path to the file being uploaded and the
     |        number of bytes transferred so far. On completion, it will be called once
     |        with `-1` as second argument.
     |      
     |      This method must be called using a `with` block:
     |      
     |      .. code-block:: python
     |      
     |        with client.read('foo') as reader:
     |          content = reader.read()
     |      
     |      This ensures that connections are always properly closed.
     |      
     |      .. note::
     |      
     |        The raw file-like object returned by this method (when called without an
     |        encoding, chunk size, or delimiter) can have a very different performance
     |        profile than local files. In particular, line-oriented methods are often
     |        slower. The recommended workaround is to specify an encoding when
     |        possible or read the entire file before splitting it.
     |  
     |  remove_acl(self, hdfs_path)
     |      RemoveAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      
     |      .. _RemoveAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL
     |  
     |  remove_acl_entries(self, hdfs_path, acl_spec)
     |      RemoveAclEntries_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      :param acl_spec: String representation of an ACL spec. Must be a valid
     |        string with entries for user, group and other. For example:
     |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
     |      
     |      .. _RemoveAclEntries: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL_Entries
     |  
     |  remove_default_acl(self, hdfs_path)
     |      RemoveDefaultAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      
     |      .. _RemoveDefaultAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_Default_ACL
     |  
     |  rename(self, hdfs_src_path, hdfs_dst_path)
     |      Move a file or folder.
     |      
     |      :param hdfs_src_path: Source path.
     |      :param hdfs_dst_path: Destination path. If the path already exists and is
     |        a directory, the source will be moved into it. If the path exists and is
     |        a file, or if a parent destination directory is missing, this method will
     |        raise an :class:`HdfsError`.
     |  
     |  rename_snapshot(self, hdfs_path, oldsnapshotname, snapshotname)
     |      Rename snapshot for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param oldsnapshotname snapshot name; if it does not exist,
     |        an :class:`HdfsError` will be raised.
     |      :param snapshotname new snapshot name; if it does already exist,
     |        an :class:`HdfsError` will be raised.
     |  
     |  resolve(self, hdfs_path)
     |      Return absolute, normalized path, with special markers expanded.
     |      
     |      :param hdfs_path: Remote path.
     |      
     |      Currently supported markers:
     |      
     |      * `'#LATEST'`: this marker gets expanded to the most recently updated file
     |        or folder. They can be combined using the `'{N}'` suffix. For example,
     |        `'foo/#LATEST{2}'` is equivalent to `'foo/#LATEST/#LATEST'`.
     |  
     |  set_acl(self, hdfs_path, acl_spec, clear=True)
     |      SetAcl_ or ModifyAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      :param acl_spec: String representation of an ACL spec. Must be a valid
     |        string with entries for user, group and other. For example:
     |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
     |      :param clear: Clear existing ACL entries. If set to false, all existing ACL
     |        entries that are not specified in this call are retained without changes,
     |        behaving like ModifyAcl_. For example: `"user:foo:rwx"`.
     |      
     |      .. _SetAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Set_ACL
     |      .. _ModifyAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Modify_ACL_Entries
     |  
     |  set_owner(self, hdfs_path, owner=None, group=None)
     |      Change the owner of file.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param owner: Optional, new owner for file.
     |      :param group: Optional, new group for file.
     |      
     |      At least one of `owner` and `group` must be specified.
     |  
     |  set_permission(self, hdfs_path, permission)
     |      Change the permissions of file.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param permission: New octal permissions string of file.
     |  
     |  set_replication(self, hdfs_path, replication)
     |      Set file replication.
     |      
     |      :param hdfs_path: Path to an existing remote file. An :class:`HdfsError`
     |        will be raised if the path doesn't exist or points to a directory.
     |      :param replication: Replication factor.
     |  
     |  set_times(self, hdfs_path, access_time=None, modification_time=None)
     |      Change remote timestamps.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param access_time: Timestamp of last file access.
     |      :param modification_time: Timestamps of last file access.
     |  
     |  status(self, hdfs_path, strict=True)
     |      Get FileStatus_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _FileStatus: FS_
     |      .. _FS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#FileStatus
     |  
     |  upload(self, hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs)
     |      Upload a file or directory to HDFS.
     |      
     |      :param hdfs_path: Target HDFS path. If it already exists and is a
     |        directory, files will be uploaded inside.
     |      :param local_path: Local path to file or folder. If a folder, all the files
     |        inside of it will be uploaded (note that this implies that folders empty
     |        of files will not be created remotely).
     |      :param n_threads: Number of threads to use for parallelization. A value of
     |        `0` (or negative) uses as many threads as there are files.
     |      :param temp_dir: Directory under which the files will first be uploaded
     |        when `overwrite=True` and the final remote path already exists. Once the
     |        upload successfully completes, it will be swapped in.
     |      :param chunk_size: Interval in bytes by which the files will be uploaded.
     |      :param progress: Callback function to track progress, called every
     |        `chunk_size` bytes. It will be passed two arguments, the path to the
     |        file being uploaded and the number of bytes transferred so far. On
     |        completion, it will be called once with `-1` as second argument.
     |      :param cleanup: Delete any uploaded files if an error occurs during the
     |        upload.
     |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`write`. In
     |        particular, set `overwrite` to overwrite any existing file or directory.
     |      
     |      On success, this method returns the remote upload path.
     |  
     |  walk(self, hdfs_path, depth=0, status=False, ignore_missing=False, allow_dir_changes=False)
     |      Depth-first walk of remote filesystem.
     |      
     |      :param hdfs_path: Starting path. If the path doesn't exist, an
     |        :class:`HdfsError` will be raised. If it points to a file, the returned
     |        generator will be empty.
     |      :param depth: Maximum depth to explore. `0` for no limit.
     |      :param status: Also return each file or folder's corresponding FileStatus_.
     |      :param ignore_missing: Ignore missing nested folders rather than raise an
     |        exception. This can be useful when the tree is modified during a walk.
     |      :param allow_dir_changes: Allow changes to the directories' list to affect
     |        the walk. For example clearing it by setting `dirs[:] = []` would prevent
     |        the walk from entering any nested directories. This option can only be set
     |        when `status` is false.
     |      
     |      This method returns a generator yielding tuples `(path, dirs, files)`
     |      where `path` is the absolute path to the current directory, `dirs` is the
     |      list of directory names it contains, and `files` is the list of file names
     |      it contains.
     |  
     |  write(self, hdfs_path, data=None, overwrite=False, permission=None, blocksize=None, replication=None, buffersize=None, append=False, encoding=None)
     |      Create a file on HDFS.
     |      
     |      :param hdfs_path: Path where to create file. The necessary directories will
     |        be created appropriately.
     |      :param data: Contents of file to write. Can be a string, a generator or a
     |        file object. The last two options will allow streaming upload (i.e.
     |        without having to load the entire contents into memory). If `None`, this
     |        method will return a file-like object and should be called using a `with`
     |        block (see below for examples).
     |      :param overwrite: Overwrite any existing file or directory.
     |      :param permission: Octal permission to set on the newly created file.
     |        Leading zeros may be omitted.
     |      :param blocksize: Block size of the file.
     |      :param replication: Number of replications of the file.
     |      :param buffersize: Size of upload buffer.
     |      :param append: Append to a file rather than create a new one.
     |      :param encoding: Encoding used to serialize data written.
     |      
     |      Sample usages:
     |      
     |      .. code-block:: python
     |      
     |        from json import dump, dumps
     |      
     |        records = [
     |          {'name': 'foo', 'weight': 1},
     |          {'name': 'bar', 'weight': 2},
     |        ]
     |      
     |        # As a context manager:
     |        with client.write('data/records.jsonl', encoding='utf-8') as writer:
     |          dump(records, writer)
     |      
     |        # Or, passing in a generator directly:
     |        client.write('data/records.jsonl', data=dumps(records), encoding='utf-8')
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from hdfs.client.Client:
     |  
     |  from_options(options, class_name='Client') from hdfs.client._ClientType
     |      Load client from options.
     |      
     |      :param options: Options dictionary.
     |      :param class_name: Client class name. Defaults to the base :class:`Client`
     |        class.
     |      
     |      This method provides a single entry point to instantiate any registered
     |      :class:`Client` subclass. To register a subclass, simply load its
     |      containing module. If using the CLI, you can use the `autoload.modules` and
     |      `autoload.paths` options.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from hdfs.client.Client:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes inherited from hdfs.client.Client:
     |  
     |  __registry__ = {'Client': <class 'hdfs.client.Client'>, 'Hdfs': <class...
```

### DATA

```text
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/hdfs.py`

---

## Módulo `bbmagic.http_config`

### NAME

`bbmagic.http_config`

### CLASSES

#### Hierarquia

```text
    bbmagic.file_config.FileConfig(builtins.object)
        HttpConfig
```

#### Classe `HttpConfig`

```text
    class HttpConfig(bbmagic.file_config.FileConfig)
     |  HttpConfig(set_no_proxy: bool = True)
     |  
     |  Method resolution order:
     |      HttpConfig
     |      bbmagic.file_config.FileConfig
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, set_no_proxy: bool = True)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  set_no_proxy(self) -> None
     |      Garante que a variável no_proxy está configurada para ignorar o domínio
     |      da API web da BBMagic
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from bbmagic.file_config.FileConfig:
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from bbmagic.file_config.FileConfig:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    BBMAGIC_VERSION = '3.1.4'
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/http_config.py`

---

## Módulo `bbmagic.kinit`

### NAME

`bbmagic.kinit`

### DESCRIPTION

```text
    Módulo responsável pela autenticação Kerberos para utilização com as ferramentas
    de Big Data.
    
    Toda os parâmetros necessários para configuração da conexão com o Kerberos estão contidos
    nos arquivos .conf na pasta krb5 deste pacote. O arquivos são utilizados para parametrizar
    a variável de ambiente KRB5_CONFIG.
    
    Caso exista a variável de ambiente BBMAGIC_KRB5_CONFIG o conteúdo será utilizado para a
    configuração de um arquivo .conf que na pasta krb5 deste pacote que será utilizado no proceso
    de autenticação.
    
    A existência da variável de ambiente BBMAGIC_ALLOW_KEYTAB permitirá que o usuário se autentique
    utilizando um arquivo de keytab no ambiente de modelagem. Esse comportamento é desabilitado por
    padrão para permitir o melhor gerenciamento dos recursos do Big Data no nível da chave do
    usuário.
    
    Para a realizar a autenticação é realizada uma chamada da aplicação de linha de
    comando `kinit` utilizando um subprocesso.
    
    |
```

### CLASSES

#### Hierarquia

```text
    builtins.object
        Kinit
```

#### Classe `Kinit`

```text
    class Kinit(builtins.object)
     |  Kinit(username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
     |  
     |  Autentica o usuário no Kerberos utilizando kinit.
     |  
     |  :param username: matrícula ou caminho para arquivo keytab
     |  :param conf_file: caminho para o arquivo krb5.conf. Caso não seja informado será
     |                      utilizada configuração do arquivo temporátio gerado pelo pacote
     |  :param hdp: Paramêtro deprecado, mantido para retrocompatibilidade de código apenas.
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get_ticket(self) -> str
     |      Autentica no Kerberos utilizando Kinit.
     |      
     |      Verifica se o usuário já possui um ticket kerberos válido. Caso não encontre
     |      realiza a autenticação com kinit. O parâmetro informado pode ser a matrícula
     |      do usuário ou uma keytab.
     |      
     |      Caso a matrícula seja informada, um prompt será exibido para que a senha SISBB
     |      seja informada.
     |      
     |      Caso o caminho para uma keytab seja informada, utiliza o arquivo. Caso seja informado
     |      o nome de uma keytab sem a extensão ".keytab" assume existe o arquivo "username.keytab"
     |      no diretório de execução do script.
     |      
     |      Retorna o nome do usuário utilizado na autenticação.
     |  
     |  get_username(self, username: Optional[str]) -> str
     |  
     |  is_matricula(self, string: str) -> bool
     |  
     |  raise_keytab_on_modelagem(self) -> None
     |  
     |  run_kinit_cmd(self, kinit_cmd: list, password: Optional[str]) -> int
     |  
     |  user_has_ticket(self) -> bool
     |      Verifica se há um ticket válido no cache de credenciais do Kerberos.
     |      
     |      Verifica as credenciais no cache padrão ou no caminho indicado na
     |      variável de ambiente KRB5CCNAME.
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  ambiente
     |  
     |  bypass_disallow_keytab
     |  
     |  encoding
     |  
     |  krb5_conf
     |  
     |  refuse_keytab
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  BACKOFF_LIMIT = 3600
```

### DATA

```text
    ENV_KRB5_CONF = '/projeto/libs/lib/python3.9/site-packages/bbmagic/krb...
    HDP31_KRB5_CONF = '/projeto/libs/lib/python3.9/site-packages/bbmagic/k...
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/kinit.py`

---

## Módulo `bbmagic.livyapi`

### NAME

`bbmagic.livyapi`

### CLASSES

#### Hierarquia

```text
    livy.client.LivyClient(builtins.object)
        LivyApi
```

#### Classe `LivyApi`

```text
    class LivyApi(livy.client.LivyClient)
     |  LivyApi(username: str, spark_version: int = 3, config: Optional[bbmagic.file_config.FileConfig] = None, python: int = None) -> None
     |  
     |  Method resolution order:
     |      LivyApi
     |      livy.client.LivyClient
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: str, spark_version: int = 3, config: Optional[bbmagic.file_config.FileConfig] = None, python: int = None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from livy.client.LivyClient:
     |  
     |  close(self) -> None
     |      Close the underlying requests session, if managed by this class.
     |  
     |  create_batch(self, file: str, class_name: str = None, args: List[str] = None, proxy_user: str = None, jars: List[str] = None, py_files: List[str] = None, files: List[str] = None, driver_memory: str = None, driver_cores: int = None, executor_memory: str = None, executor_cores: int = None, num_executors: int = None, archives: List[str] = None, queue: str = None, name: str = None, spark_conf: Dict[str, Any] = None) -> livy.models.Batch
     |      Create a new batch in Livy.
     |      
     |      The py_files, files, jars and archives arguments are lists of URLs,
     |      e.g. ["s3://bucket/object", "hdfs://path/to/file", ...] and must be
     |      reachable by the Spark driver process.  If the provided URL has no
     |      scheme, it's considered to be relative to the default file system
     |      configured in the Livy server.
     |      
     |      URLs in the py_files argument are copied to a temporary staging area
     |      and inserted into Python's sys.path ahead of the standard library
     |      paths.  This allows you to import .py, .zip and .egg files in Python.
     |      
     |      URLs for jars, py_files, files and archives arguments are all copied
     |      
     |      The driver_memory and executor_memory arguments have the same format
     |      as JVM memory strings with a size unit suffix ("k", "m", "g" or "t")
     |      (e.g. 512m, 2g).
     |      
     |      See https://spark.apache.org/docs/latest/configuration.html for more
     |      information on Spark configuration properties.
     |      
     |      :param file: File containing the application to execute.
     |      :param class_name: Application Java/Spark main class.
     |      :param args: An array of strings to be passed to the Spark app.
     |      :param proxy_user: User to impersonate when starting the session.
     |      :param jars: URLs of jars to be used in this session.
     |      :param py_files: URLs of Python files to be used in this session.
     |      :param files: URLs of files to be used in this session.
     |      :param driver_memory: Amount of memory to use for the driver process
     |          (e.g. '512m').
     |      :param driver_cores: Number of cores to use for the driver process.
     |      :param executor_memory: Amount of memory to use per executor process
     |          (e.g. '512m').
     |      :param executor_cores: Number of cores to use for each executor.
     |      :param num_executors: Number of executors to launch for this session.
     |      :param archives: URLs of archives to be used in this session.
     |      :param queue: The name of the YARN queue to which submitted.
     |      :param name: The name of this session.
     |      :param spark_conf: Spark configuration properties.
     |  
     |  create_session(self, kind: livy.models.SessionKind, proxy_user: str = None, jars: List[str] = None, py_files: List[str] = None, files: List[str] = None, driver_memory: str = None, driver_cores: int = None, executor_memory: str = None, executor_cores: int = None, num_executors: int = None, archives: List[str] = None, queue: str = None, name: str = None, spark_conf: Dict[str, Any] = None, heartbeat_timeout: int = None) -> livy.models.Session
     |      Create a new session in Livy.
     |      
     |      The py_files, files, jars and archives arguments are lists of URLs,
     |      e.g. ["s3://bucket/object", "hdfs://path/to/file", ...] and must be
     |      reachable by the Spark driver process.  If the provided URL has no
     |      scheme, it's considered to be relative to the default file system
     |      configured in the Livy server.
     |      
     |      URLs in the py_files argument are copied to a temporary staging area
     |      and inserted into Python's sys.path ahead of the standard library
     |      paths.  This allows you to import .py, .zip and .egg files in Python.
     |      
     |      URLs for jars, py_files, files and archives arguments are all copied
     |      
     |      The driver_memory and executor_memory arguments have the same format
     |      as JVM memory strings with a size unit suffix ("k", "m", "g" or "t")
     |      (e.g. 512m, 2g).
     |      
     |      See https://spark.apache.org/docs/latest/configuration.html for more
     |      information on Spark configuration properties.
     |      
     |      :param kind: The kind of session to create.
     |      :param proxy_user: User to impersonate when starting the session.
     |      :param jars: URLs of jars to be used in this session.
     |      :param py_files: URLs of Python files to be used in this session.
     |      :param files: URLs of files to be used in this session.
     |      :param driver_memory: Amount of memory to use for the driver process
     |          (e.g. '512m').
     |      :param driver_cores: Number of cores to use for the driver process.
     |      :param executor_memory: Amount of memory to use per executor process
     |          (e.g. '512m').
     |      :param executor_cores: Number of cores to use for each executor.
     |      :param num_executors: Number of executors to launch for this session.
     |      :param archives: URLs of archives to be used in this session.
     |      :param queue: The name of the YARN queue to which submitted.
     |      :param name: The name of this session.
     |      :param spark_conf: Spark configuration properties.
     |      :param heartbeat_timeout: Optional Timeout in seconds to which session
     |          be automatically orphaned if no heartbeat is received.
     |  
     |  create_statement(self, session_id: int, code: str, kind: livy.models.StatementKind = None) -> livy.models.Statement
     |      Run a statement in a session.
     |      
     |      :param session_id: The ID of the session.
     |      :param code: The code to execute.
     |      :param kind: The kind of code to execute.
     |  
     |  delete_batch(self, batch_id: int) -> None
     |      Kill a batch session.
     |      
     |      :param batch_id: The ID of the session.
     |  
     |  delete_session(self, session_id: int) -> None
     |      Kill a session.
     |      
     |      :param session_id: The ID of the session.
     |  
     |  get_batch(self, batch_id: int) -> Optional[livy.models.Batch]
     |      Get information about a batch.
     |      
     |      :param batch_id: The ID of the batch.
     |  
     |  get_batch_log(self, batch_id: int, from_: int = None, size: int = None) -> Optional[livy.models.BatchLog]
     |      Get logs for a batch.
     |      
     |      :param batch_id: The ID of the batch.
     |      :param from_: The line number to start getting logs from.
     |      :param size: The number of lines of logs to get.
     |  
     |  get_session(self, session_id: int) -> Optional[livy.models.Session]
     |      Get information about a session.
     |      
     |      :param session_id: The ID of the session.
     |  
     |  get_statement(self, session_id: int, statement_id: int) -> livy.models.Statement
     |      Get information about a statement in a session.
     |      
     |      :param session_id: The ID of the session.
     |      :param statement_id: The ID of the statement.
     |  
     |  legacy_server(self) -> bool
     |      Determine if the server is running a legacy version.
     |      
     |      Legacy versions support different session kinds than newer versions of
     |      Livy.
     |  
     |  list_batches(self) -> List[livy.models.Batch]
     |      List all the active batches in Livy.
     |  
     |  list_sessions(self) -> List[livy.models.Session]
     |      List all the active sessions in Livy.
     |  
     |  list_statements(self, session_id: int) -> List[livy.models.Statement]
     |      Get all the statements in a session.
     |      
     |      :param session_id: The ID of the session.
     |  
     |  server_version(self) -> livy.models.Version
     |      Get the version of Livy running on the server.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from livy.client.LivyClient:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/livyapi.py`

---

## Módulo `bbmagic.log`

### NAME

`bbmagic.log`

### FUNCTIONS

#### Função `get_start_session`

```text
    get_start_session(session)
```

#### Função `log_project`

```text
    log_project(spark_bbmagic=None)
```

### VERSION

`3.1.4`

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/log.py`

---

## Módulo `bbmagic.lookup`

### NAME

`bbmagic.lookup`

### CLASSES

#### Hierarquia

```text
    builtins.object
        Lookup
```

#### Classe `Lookup`

```text
    class Lookup(builtins.object)
     |  Methods defined here:
     |  
     |  
     |  sigla(self) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/lookup.py`

---

## Classe `Db2` — módulo `bbmagic.db2`

### Conteúdo

```text
class Db2(builtins.object)
 |  Db2(user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
 |  
 |  Cria uma conexão ao DB2
 |  
 |  Methods defined here:
 |  
 |  __init__(self, user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  connect(self) -> ibm_db_dbi.Connection
 |      Cria a conexão JDBC com o servidor DB2.
 |  
 |  describe(self, schema: str, table: str) -> IPython.core.display.HTML
 |      Gera um relatório consolidado com os metadados da tabela existentes no catálogo
 |      do DB2.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um objeto HTML com o relatório para exibição no Jupyter Notebook.
 |      :rtype: IPython.core.display.HTML
 |  
 |  get_cofre_credentials(self, project_id: str) -> dict
 |      Recupera credenciais do cofre com base no project_id do projeto
 |  
 |  query(self, sql: str, params: Optional[list] = None, chunksize: Optional[int] = 2500) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
 |      Retorna um DataFrame contendo o resultado da execução da query SQL.
 |      
 |      :param sql: query SQL para execução
 |      :param params: lista de parâmetros para utilização na query
 |      :param chunksize: Se especificado, retorna um iterador onde chunksize é a quantidade
 |                        de linhas incluídas em cada chunk
 |      
 |      :return: Daframe ou Iterator[DataFrame]
 |      
 |      Exemplos de Uso::
 |      
 |          >>> for chunk in db2.query("SELECT * FROM db2mci.cliente LIMIT 10000"):
 |          ...     print(len(chunk))
 |          2500
 |          2500
 |          2500
 |          2500
 |      
 |      Sem utilização de chunks
 |      
 |          >>> df = db2.query("SELECT cod FROM db2mci.cliente LIMIT 100", chunksize=None)
 |  
 |  set_conn_param(self, param_name, param_value: Union[str, int, NoneType]) -> Union[str, int]
 |  
 |  show_schemas(self) -> pandas.core.frame.DataFrame
 |      Lista todos os schemas no database
 |      
 |      :return: Retorna um Pandas DataFrame contendo uma linha para cada schema encontrado.
 |      :rtype: pandas.core.api.DataFrame
 |      
 |      Exemplo de uso::
 |      
 |          >>> db2.show_schemas()
 |  
 |  show_tables(self, schema: str) -> pandas.core.frame.DataFrame
 |      Lista todas as tabelas e views de um schema.
 |      
 |      :param schema: nome do schema
 |      
 |      :return: Retorna um Pandas DataFrame contendo uma linha para cada tabela do schema
 |               e as informações *schema*, *name* e *type* nas respectivas colunas.
 |      :rtype: pandas.core.api.DataFrame
 |      
 |      Exemplo de uso::
 |      
 |          >>> db2.show_tables("DB2MCI")
 |  
 |  syscolumns(self, schema: str, table: str) -> pandas.core.frame.DataFrame
 |      Retorna metadados das colunas de uma tabela.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um Pandas DataFrame contendo as informações sobre as colunas da
 |               tabela de acordo com o catálogo syscat.syscolumns
 |      :rtype: pandas.core.api.DataFrame
 |  
 |  systabstats(self, schema: str, table: str) -> pandas.core.frame.DataFrame
 |      Retorna metadados de uma tabela.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um Pandas DataFrame contendo as informações sobre a tabela
 |               existentes no catálogo syscat.systabstats
 |      :rtype: pandas.core.api.DataFrame
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  url
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  envs = {'database': 'DB2_DATABASE', 'host': 'DB2_HOST', 'password': 'D...
 |  
 |  jars_path = '/projeto/libs/lib/python3.9/site-packages/bbmagic/jars/db...
```

---

## Classe `FileConfig` — módulo `bbmagic.file_config`

### Conteúdo

```text
class FileConfig(builtins.object)
 |  FileConfig(path) -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self, path) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `GitLabConfig` — módulo `bbmagic.gitlab_config`

### Conteúdo

```text
class GitLabConfig(bbmagic.file_config.FileConfig)
 |  Method resolution order:
 |      GitLabConfig
 |      bbmagic.file_config.FileConfig
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from bbmagic.file_config.FileConfig:
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from bbmagic.file_config.FileConfig:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `HttpConfig` — módulo `bbmagic.http_config`

### Conteúdo

```text
class HttpConfig(bbmagic.file_config.FileConfig)
 |  HttpConfig(set_no_proxy: bool = True)
 |  
 |  Method resolution order:
 |      HttpConfig
 |      bbmagic.file_config.FileConfig
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self, set_no_proxy: bool = True)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  set_no_proxy(self) -> None
 |      Garante que a variável no_proxy está configurada para ignorar o domínio
 |      da API web da BBMagic
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from bbmagic.file_config.FileConfig:
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from bbmagic.file_config.FileConfig:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `Kinit` — módulo `bbmagic.kinit`

### Conteúdo

```text
class Kinit(builtins.object)
 |  Kinit(username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
 |  
 |  Autentica o usuário no Kerberos utilizando kinit.
 |  
 |  :param username: matrícula ou caminho para arquivo keytab
 |  :param conf_file: caminho para o arquivo krb5.conf. Caso não seja informado será
 |                      utilizada configuração do arquivo temporátio gerado pelo pacote
 |  :param hdp: Paramêtro deprecado, mantido para retrocompatibilidade de código apenas.
 |  
 |  Methods defined here:
 |  
 |  __init__(self, username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  get_ticket(self) -> str
 |      Autentica no Kerberos utilizando Kinit.
 |      
 |      Verifica se o usuário já possui um ticket kerberos válido. Caso não encontre
 |      realiza a autenticação com kinit. O parâmetro informado pode ser a matrícula
 |      do usuário ou uma keytab.
 |      
 |      Caso a matrícula seja informada, um prompt será exibido para que a senha SISBB
 |      seja informada.
 |      
 |      Caso o caminho para uma keytab seja informada, utiliza o arquivo. Caso seja informado
 |      o nome de uma keytab sem a extensão ".keytab" assume existe o arquivo "username.keytab"
 |      no diretório de execução do script.
 |      
 |      Retorna o nome do usuário utilizado na autenticação.
 |  
 |  get_username(self, username: Optional[str]) -> str
 |  
 |  is_matricula(self, string: str) -> bool
 |  
 |  raise_keytab_on_modelagem(self) -> None
 |  
 |  run_kinit_cmd(self, kinit_cmd: list, password: Optional[str]) -> int
 |  
 |  user_has_ticket(self) -> bool
 |      Verifica se há um ticket válido no cache de credenciais do Kerberos.
 |      
 |      Verifica as credenciais no cache padrão ou no caminho indicado na
 |      variável de ambiente KRB5CCNAME.
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  ambiente
 |  
 |  bypass_disallow_keytab
 |  
 |  encoding
 |  
 |  krb5_conf
 |  
 |  refuse_keytab
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  BACKOFF_LIMIT = 3600
```

---

## Classe `Hdfs` — módulo `bbmagic.hdfs`

### Conteúdo

```text
class Hdfs(hdfs.ext.kerberos.KerberosClient)
 |  Hdfs(username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
 |  
 |  Permite acesso ao HDFS com autenticação via kerberos.
 |  
 |  :param username: matrícula ou caminho para arquivo keytab
 |  :param \*\*kwargs: Argumentos adicionais passados para a classe HTTPKerberosAuth.
 |  
 |  Method resolution order:
 |      Hdfs
 |      hdfs.ext.kerberos.KerberosClient
 |      hdfs.client.Client
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self, username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  set_no_proxy(self) -> None
 |      Garante que a variável no_proxy está configurada para ignorar o domínio
 |      da API web da BBMagic
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from hdfs.client.Client:
 |  
 |  __repr__(self)
 |      Return repr(self).
 |  
 |  acl_status(self, hdfs_path, strict=True)
 |      Get AclStatus_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _AclStatus: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Get_ACL_Status
 |  
 |  allow_snapshot(self, hdfs_path)
 |      Allow snapshots for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist or does points to a normal file, an
 |        :class:`HdfsError` will be raised.  No-op if snapshotting is
 |        already allowed.
 |  
 |  checksum(self, hdfs_path)
 |      Get a remote file's checksum.
 |      
 |      :param hdfs_path: Remote path. Must point to a file.
 |  
 |  content(self, hdfs_path, strict=True)
 |      Get ContentSummary_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _ContentSummary: CS_
 |      .. _CS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#ContentSummary
 |  
 |  create_snapshot(self, hdfs_path, snapshotname=None)
 |      Create snapshot for a remote folder where it was allowed.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist, doesn't allow to create snapshot or points to a
 |        normal file, an :class:`HdfsError` will be raised.
 |      :param snapshotname snapshot name; if absent, name is generated
 |        by the server.
 |      
 |      Returns a path to created snapshot.
 |  
 |  delete(self, hdfs_path, recursive=False, skip_trash=True)
 |      Remove a file or directory from HDFS.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param recursive: Recursively delete files and directories. By default,
 |        this method will raise an :class:`HdfsError` if trying to delete a
 |        non-empty directory.
 |      :param skip_trash: When false, the deleted path will be moved to an
 |        appropriate trash folder rather than deleted. This requires Hadoop 2.9+
 |      
 |      This function returns `True` if the deletion was successful and `False` if
 |      no file or directory previously existed at `hdfs_path`.
 |  
 |  delete_snapshot(self, hdfs_path, snapshotname)
 |      Remove snapshot for a remote folder where it was allowed.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param snapshotname snapshot name; if it does not exist, an
 |        :class:`HdfsError` will be raised.
 |  
 |  disallow_snapshot(self, hdfs_path)
 |      Disallow snapshots for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist, points to a normal file or there are some
 |        snapshots, an :class:`HdfsError` will be raised.
 |      
 |      No-op if snapshotting is disallowed/never allowed.
 |  
 |  download(self, hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs)
 |      Download a file or folder from HDFS and save it locally.
 |      
 |      :param hdfs_path: Path on HDFS of the file or folder to download. If a
 |        folder, all the files under it will be downloaded.
 |      :param local_path: Local path. If it already exists and is a directory,
 |        the files will be downloaded inside of it.
 |      :param overwrite: Overwrite any existing file or directory.
 |      :param n_threads: Number of threads to use for parallelization. A value of
 |        `0` (or negative) uses as many threads as there are files.
 |      :param temp_dir: Directory under which the files will first be downloaded
 |        when `overwrite=True` and the final destination path already exists. Once
 |        the download successfully completes, it will be swapped in.
 |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`read`. If no
 |        `chunk_size` argument is passed, a default value of 64 kB will be used.
 |        If a `progress` argument is passed and threading is used, care must be
 |        taken to ensure correct behavior.
 |      
 |      On success, this method returns the local download path.
 |  
 |  list(self, hdfs_path, status=False)
 |      Return names of files contained in a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory. If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param status: Also return each file's corresponding FileStatus_.
 |  
 |  makedirs(self, hdfs_path, permission=None)
 |      Create a remote directory, recursively if necessary.
 |      
 |      :param hdfs_path: Remote path. Intermediate directories will be created
 |        appropriately.
 |      :param permission: Octal permission to set on the newly created directory.
 |        These permissions will only be set on directories that do not already
 |        exist.
 |      
 |      This function currently has no return value as WebHDFS doesn't return a
 |      meaningful flag.
 |  
 |  parts(self, hdfs_path, parts=None, status=False)
 |      Returns a dictionary of part-files corresponding to a path.
 |      
 |      :param hdfs_path: Remote path. This directory should contain at most one
 |        part file per partition (otherwise one will be picked arbitrarily).
 |      :param parts: List of part-files numbers or total number of part-files to
 |        select. If a number, that many partitions will be chosen at random. By
 |        default all part-files are returned. If `parts` is a list and one of the
 |        parts is not found or too many samples are demanded, an
 |        :class:`~hdfs.util.HdfsError` is raised.
 |      :param status: Also return each file's corresponding FileStatus_.
 |  
 |  read(self, hdfs_path, offset=0, length=None, buffer_size=None, encoding=None, chunk_size=0, delimiter=None, progress=None)
 |      Read a file from HDFS.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param offset: Starting byte position.
 |      :param length: Number of bytes to be processed. `None` will read the entire
 |        file.
 |      :param buffer_size: Size of the buffer in bytes used for transferring the
 |        data. Defaults the the value set in the HDFS configuration.
 |      :param encoding: Encoding used to decode the request. By default the raw
 |        data is returned. This is mostly helpful in python 3, for example to
 |        deserialize JSON data (as the decoder expects unicode).
 |      :param chunk_size: If set to a positive number, the context manager will
 |        return a generator yielding every `chunk_size` bytes instead of a
 |        file-like object (unless `delimiter` is also set, see below).
 |      :param delimiter: If set, the context manager will return a generator
 |        yielding each time the delimiter is encountered. This parameter requires
 |        the `encoding` to be specified.
 |      :param progress: Callback function to track progress, called every
 |        `chunk_size` bytes (not available if the chunk size isn't specified). It
 |        will be passed two arguments, the path to the file being uploaded and the
 |        number of bytes transferred so far. On completion, it will be called once
 |        with `-1` as second argument.
 |      
 |      This method must be called using a `with` block:
 |      
 |      .. code-block:: python
 |      
 |        with client.read('foo') as reader:
 |          content = reader.read()
 |      
 |      This ensures that connections are always properly closed.
 |      
 |      .. note::
 |      
 |        The raw file-like object returned by this method (when called without an
 |        encoding, chunk size, or delimiter) can have a very different performance
 |        profile than local files. In particular, line-oriented methods are often
 |        slower. The recommended workaround is to specify an encoding when
 |        possible or read the entire file before splitting it.
 |  
 |  remove_acl(self, hdfs_path)
 |      RemoveAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      
 |      .. _RemoveAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL
 |  
 |  remove_acl_entries(self, hdfs_path, acl_spec)
 |      RemoveAclEntries_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      :param acl_spec: String representation of an ACL spec. Must be a valid
 |        string with entries for user, group and other. For example:
 |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
 |      
 |      .. _RemoveAclEntries: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL_Entries
 |  
 |  remove_default_acl(self, hdfs_path)
 |      RemoveDefaultAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      
 |      .. _RemoveDefaultAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_Default_ACL
 |  
 |  rename(self, hdfs_src_path, hdfs_dst_path)
 |      Move a file or folder.
 |      
 |      :param hdfs_src_path: Source path.
 |      :param hdfs_dst_path: Destination path. If the path already exists and is
 |        a directory, the source will be moved into it. If the path exists and is
 |        a file, or if a parent destination directory is missing, this method will
 |        raise an :class:`HdfsError`.
 |  
 |  rename_snapshot(self, hdfs_path, oldsnapshotname, snapshotname)
 |      Rename snapshot for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param oldsnapshotname snapshot name; if it does not exist,
 |        an :class:`HdfsError` will be raised.
 |      :param snapshotname new snapshot name; if it does already exist,
 |        an :class:`HdfsError` will be raised.
 |  
 |  resolve(self, hdfs_path)
 |      Return absolute, normalized path, with special markers expanded.
 |      
 |      :param hdfs_path: Remote path.
 |      
 |      Currently supported markers:
 |      
 |      * `'#LATEST'`: this marker gets expanded to the most recently updated file
 |        or folder. They can be combined using the `'{N}'` suffix. For example,
 |        `'foo/#LATEST{2}'` is equivalent to `'foo/#LATEST/#LATEST'`.
 |  
 |  set_acl(self, hdfs_path, acl_spec, clear=True)
 |      SetAcl_ or ModifyAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      :param acl_spec: String representation of an ACL spec. Must be a valid
 |        string with entries for user, group and other. For example:
 |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
 |      :param clear: Clear existing ACL entries. If set to false, all existing ACL
 |        entries that are not specified in this call are retained without changes,
 |        behaving like ModifyAcl_. For example: `"user:foo:rwx"`.
 |      
 |      .. _SetAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Set_ACL
 |      .. _ModifyAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Modify_ACL_Entries
 |  
 |  set_owner(self, hdfs_path, owner=None, group=None)
 |      Change the owner of file.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param owner: Optional, new owner for file.
 |      :param group: Optional, new group for file.
 |      
 |      At least one of `owner` and `group` must be specified.
 |  
 |  set_permission(self, hdfs_path, permission)
 |      Change the permissions of file.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param permission: New octal permissions string of file.
 |  
 |  set_replication(self, hdfs_path, replication)
 |      Set file replication.
 |      
 |      :param hdfs_path: Path to an existing remote file. An :class:`HdfsError`
 |        will be raised if the path doesn't exist or points to a directory.
 |      :param replication: Replication factor.
 |  
 |  set_times(self, hdfs_path, access_time=None, modification_time=None)
 |      Change remote timestamps.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param access_time: Timestamp of last file access.
 |      :param modification_time: Timestamps of last file access.
 |  
 |  status(self, hdfs_path, strict=True)
 |      Get FileStatus_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _FileStatus: FS_
 |      .. _FS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#FileStatus
 |  
 |  upload(self, hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs)
 |      Upload a file or directory to HDFS.
 |      
 |      :param hdfs_path: Target HDFS path. If it already exists and is a
 |        directory, files will be uploaded inside.
 |      :param local_path: Local path to file or folder. If a folder, all the files
 |        inside of it will be uploaded (note that this implies that folders empty
 |        of files will not be created remotely).
 |      :param n_threads: Number of threads to use for parallelization. A value of
 |        `0` (or negative) uses as many threads as there are files.
 |      :param temp_dir: Directory under which the files will first be uploaded
 |        when `overwrite=True` and the final remote path already exists. Once the
 |        upload successfully completes, it will be swapped in.
 |      :param chunk_size: Interval in bytes by which the files will be uploaded.
 |      :param progress: Callback function to track progress, called every
 |        `chunk_size` bytes. It will be passed two arguments, the path to the
 |        file being uploaded and the number of bytes transferred so far. On
 |        completion, it will be called once with `-1` as second argument.
 |      :param cleanup: Delete any uploaded files if an error occurs during the
 |        upload.
 |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`write`. In
 |        particular, set `overwrite` to overwrite any existing file or directory.
 |      
 |      On success, this method returns the remote upload path.
 |  
 |  walk(self, hdfs_path, depth=0, status=False, ignore_missing=False, allow_dir_changes=False)
 |      Depth-first walk of remote filesystem.
 |      
 |      :param hdfs_path: Starting path. If the path doesn't exist, an
 |        :class:`HdfsError` will be raised. If it points to a file, the returned
 |        generator will be empty.
 |      :param depth: Maximum depth to explore. `0` for no limit.
 |      :param status: Also return each file or folder's corresponding FileStatus_.
 |      :param ignore_missing: Ignore missing nested folders rather than raise an
 |        exception. This can be useful when the tree is modified during a walk.
 |      :param allow_dir_changes: Allow changes to the directories' list to affect
 |        the walk. For example clearing it by setting `dirs[:] = []` would prevent
 |        the walk from entering any nested directories. This option can only be set
 |        when `status` is false.
 |      
 |      This method returns a generator yielding tuples `(path, dirs, files)`
 |      where `path` is the absolute path to the current directory, `dirs` is the
 |      list of directory names it contains, and `files` is the list of file names
 |      it contains.
 |  
 |  write(self, hdfs_path, data=None, overwrite=False, permission=None, blocksize=None, replication=None, buffersize=None, append=False, encoding=None)
 |      Create a file on HDFS.
 |      
 |      :param hdfs_path: Path where to create file. The necessary directories will
 |        be created appropriately.
 |      :param data: Contents of file to write. Can be a string, a generator or a
 |        file object. The last two options will allow streaming upload (i.e.
 |        without having to load the entire contents into memory). If `None`, this
 |        method will return a file-like object and should be called using a `with`
 |        block (see below for examples).
 |      :param overwrite: Overwrite any existing file or directory.
 |      :param permission: Octal permission to set on the newly created file.
 |        Leading zeros may be omitted.
 |      :param blocksize: Block size of the file.
 |      :param replication: Number of replications of the file.
 |      :param buffersize: Size of upload buffer.
 |      :param append: Append to a file rather than create a new one.
 |      :param encoding: Encoding used to serialize data written.
 |      
 |      Sample usages:
 |      
 |      .. code-block:: python
 |      
 |        from json import dump, dumps
 |      
 |        records = [
 |          {'name': 'foo', 'weight': 1},
 |          {'name': 'bar', 'weight': 2},
 |        ]
 |      
 |        # As a context manager:
 |        with client.write('data/records.jsonl', encoding='utf-8') as writer:
 |          dump(records, writer)
 |      
 |        # Or, passing in a generator directly:
 |        client.write('data/records.jsonl', data=dumps(records), encoding='utf-8')
 |  
 |  ----------------------------------------------------------------------
 |  Class methods inherited from hdfs.client.Client:
 |  
 |  from_options(options, class_name='Client') from hdfs.client._ClientType
 |      Load client from options.
 |      
 |      :param options: Options dictionary.
 |      :param class_name: Client class name. Defaults to the base :class:`Client`
 |        class.
 |      
 |      This method provides a single entry point to instantiate any registered
 |      :class:`Client` subclass. To register a subclass, simply load its
 |      containing module. If using the CLI, you can use the `autoload.modules` and
 |      `autoload.paths` options.
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from hdfs.client.Client:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes inherited from hdfs.client.Client:
 |  
 |  __registry__ = {'Client': <class 'hdfs.client.Client'>, 'Hdfs': <class...
```

---

## Classe `Spark` — módulo `bbmagic.spark`

### Conteúdo

```text
class Spark(builtins.object)
 |  Spark(session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
 |  
 |  Cria uma sessão Spark.
 |  
 |  :param session_name: nome da sessão que será exibido na Web UI do Spark
 |  :param username: caminho para arquivo .keytab ou matrícula sem o dígito do usuário
 |  :param python: versão do Python da sessão Spark (2 ou 3)
 |  :param language: linguagem utilizada na sessão Spark ('python' ou 'scala')
 |  :param auth: modo de autenticação no Livy
 |  :param timeout: tempo máximo até que a sessão Spark seja criada
 |  :param db2: configura a sessão Spark para conexão JDBC ao DB2
 |  :param spark_conf: dicionário de parâmetros adicionais para configuração da sessão Spark.
 |                     Esse parâmetro tem prioridade sobre a padrão do BBMagic
 |  :param jars: lista de paths de arquivos .jar localizados no HDFS que serão utilizados na
 |               sessão. Ex: ['hdfs:///user/jars/database.jar']
 |  :param env: dicionário utilizado para definição de variáveis de ambiente na sessão Spark
 |  :param debug: exibe mais informações sobre a sessão Spark
 |  :param driver_memory: Quantidade de memória alocada para o driver da sessão Spark seguida
 |                        pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
 |                        (Ex.: '512m', '4g').
 |  :param driver_cores: Quantidade de cores alocados para o driver da sessão Spark
 |  :param num_executors: Quantidade de executores alocados para a sessão Spark.
 |  :param executor_memory: Quantidade de memória alocada cada executor da sessão Spark seguida
 |                          pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
 |                          (Ex.: '512m', '4g').
 |  :param executor_cores: Quantidade de cores alocados para cada executor da sessão Spark
 |  :param spark_version: Identifica a versao do Spark que ira receber a conexao - 2 ou 3
 |  
 |  Methods defined here:
 |  
 |  __del__(self) -> None
 |      Garante que a sessão Livy é encerrada assim que o Python finalize
 |  
 |  __init__(self, session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  close(self) -> None
 |      Encerra a sessão Spark
 |  
 |  config_db2(self) -> None
 |  
 |  config_jars(self) -> None
 |      Adiciona os jars para utilização de bibliotecas de machine learning distribuidas nas sessões spark 3
 |  
 |  config_sparkmagic(self) -> None
 |  
 |  config_virtualenv(self, virtualenv: Optional[str], overwrite: bool = False) -> Optional[str]
 |  
 |  connect(self) -> None
 |  
 |  enforce_dynamic_allocation(self, config: Optional[Dict[str, str]]) -> Optional[dict]
 |  
 |  get_from_spark(self, var_name: str)
 |      Importa o conteúdo de uma variável da sessão Spark para a sessão local.
 |      
 |      
 |      :param var_name: nome da variável que será importada.
 |      
 |      :return: Retorna o valor da variável
 |  
 |  send_to_spark(self, var) -> None
 |      Envia uma variável local para a sessão Spark.
 |      
 |      A variável será definida com mesmo nome na sessão Spark e o valor
 |      será transmitido utilizando pickle.
 |      
 |      :param var: variável que será enviada para a sessão Spark.
 |      
 |      :return: None
 |  
 |  ----------------------------------------------------------------------
 |  Class methods defined here:
 |  
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  ambiente
 |  
 |  bbmagic_session_id
 |  
 |  
 |  default_env
 |  
 |  force_dynammic_allocation
 |  
 |  livy_conn
 |  
 |  livy_session_id
 |  
 |  livy_url
 |  
 |  livy_version
 |  
 |  pickle_protocol
 |  
 |  spark_session_name
 |  
 |  spark_version
 |  
 |  user
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `MetaDataHive` — módulo `bbmagic.sumary`

### Conteúdo

```text
class MetaDataHive(builtins.object)
 |  MetaDataHive() -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  get_token(self) -> Optional[str]
 |  
 |  get_url(self) -> Optional[str]
 |  
 |  status_db(self, db: str, list: Optional[bool] = False) -> Optional[pandas.core.frame.DataFrame]
 |  
 |  status_table(self, nome_db: Optional[str] = None, nome_tabela: Optional[str] = None) -> Optional[pandas.core.frame.DataFrame]
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `TeamsNotify` — módulo `bbmagic.teams_notify`

### Conteúdo

```text
class TeamsNotify(builtins.object)
 |  TeamsNotify(webhook: str)
 |  
 |  Methods defined here:
 |  
 |  __init__(self, webhook: str)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  error(self, title, text, model='', situation='', other_details='', color='E81123')
 |  
 |  info(self, title, text, model='', situation='', other_details='', color='008000')
 |  
 |  post_msg(self, title, text, model, situation, other_details, color=None)
 |  
 |  post_msg_workflows(self, title: str, text: str, model: str = '', situation: str = '', other_details: str = '', type: str = '') -> dict
 |      Função que envia mensagens por meio dos fluxos Workflows no Microsoft Teams
 |  
 |  warning(self, title, text, model='', situation='', other_details='', color='FFFF00')
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `SAS` — módulo `bbmagic.sas.sas`

### Conteúdo

```text
class SAS(builtins.object)
 |  SAS(username: str = '', host: str = 'sasanl03.intranet.bb.com.br', port: int = 8591, appserver: str = 'SASApp_ANL03 - Workspace Server', authkey: str = '', libnames: Optional[List[dict]] = None, timeout: int = 30) -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self, username: str = '', host: str = 'sasanl03.intranet.bb.com.br', port: int = 8591, appserver: str = 'SASApp_ANL03 - Workspace Server', authkey: str = '', libnames: Optional[List[dict]] = None, timeout: int = 30) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  config_authinfo(self, name: str = 'bbmagic') -> None
 |  
 |  create_libnames(self) -> None
 |  
 |  query(self, sql: str, chunksize: Optional[int] = 2500, verbose: bool = False) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `AuthInfo` — módulo `bbmagic.sas.authinfo`

### Conteúdo

```text
class AuthInfo(builtins.object)
 |  Methods defined here:
 |  
 |  __init__(self)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  __len__(self) -> int
 |  
 |  add_key(self, name: str, user: str, password: Optional[str] = None) -> None
 |  
 |  parse(self) -> list
 |  
 |  remove_key(self, name: str) -> None
 |  
 |  write(self) -> None
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  path
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `AuthKey` — módulo `bbmagic.sas.authinfo`

### Conteúdo

```text
class AuthKey(builtins.object)
 |  AuthKey(name: str, user: str, password: Optional[str] = None) -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self, name: str, user: str, password: Optional[str] = None) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  __str__(self) -> str
 |      Return str(self).
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Objeto `Db2` — módulo `bbmagic.db2`

### Conteúdo

```text
class Db2(builtins.object)
 |  Db2(user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
 |  
 |  Cria uma conexão ao DB2
 |  
 |  Methods defined here:
 |  
 |  __init__(self, user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  connect(self) -> ibm_db_dbi.Connection
 |      Cria a conexão JDBC com o servidor DB2.
 |  
 |  describe(self, schema: str, table: str) -> IPython.core.display.HTML
 |      Gera um relatório consolidado com os metadados da tabela existentes no catálogo
 |      do DB2.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um objeto HTML com o relatório para exibição no Jupyter Notebook.
 |      :rtype: IPython.core.display.HTML
 |  
 |  get_cofre_credentials(self, project_id: str) -> dict
 |      Recupera credenciais do cofre com base no project_id do projeto
 |  
 |  query(self, sql: str, params: Optional[list] = None, chunksize: Optional[int] = 2500) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
 |      Retorna um DataFrame contendo o resultado da execução da query SQL.
 |      
 |      :param sql: query SQL para execução
 |      :param params: lista de parâmetros para utilização na query
 |      :param chunksize: Se especificado, retorna um iterador onde chunksize é a quantidade
 |                        de linhas incluídas em cada chunk
 |      
 |      :return: Daframe ou Iterator[DataFrame]
 |      
 |      Exemplos de Uso::
 |      
 |          >>> for chunk in db2.query("SELECT * FROM db2mci.cliente LIMIT 10000"):
 |          ...     print(len(chunk))
 |          2500
 |          2500
 |          2500
 |          2500
 |      
 |      Sem utilização de chunks
 |      
 |          >>> df = db2.query("SELECT cod FROM db2mci.cliente LIMIT 100", chunksize=None)
 |  
 |  set_conn_param(self, param_name, param_value: Union[str, int, NoneType]) -> Union[str, int]
 |  
 |  show_schemas(self) -> pandas.core.frame.DataFrame
 |      Lista todos os schemas no database
 |      
 |      :return: Retorna um Pandas DataFrame contendo uma linha para cada schema encontrado.
 |      :rtype: pandas.core.api.DataFrame
 |      
 |      Exemplo de uso::
 |      
 |          >>> db2.show_schemas()
 |  
 |  show_tables(self, schema: str) -> pandas.core.frame.DataFrame
 |      Lista todas as tabelas e views de um schema.
 |      
 |      :param schema: nome do schema
 |      
 |      :return: Retorna um Pandas DataFrame contendo uma linha para cada tabela do schema
 |               e as informações *schema*, *name* e *type* nas respectivas colunas.
 |      :rtype: pandas.core.api.DataFrame
 |      
 |      Exemplo de uso::
 |      
 |          >>> db2.show_tables("DB2MCI")
 |  
 |  syscolumns(self, schema: str, table: str) -> pandas.core.frame.DataFrame
 |      Retorna metadados das colunas de uma tabela.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um Pandas DataFrame contendo as informações sobre as colunas da
 |               tabela de acordo com o catálogo syscat.syscolumns
 |      :rtype: pandas.core.api.DataFrame
 |  
 |  systabstats(self, schema: str, table: str) -> pandas.core.frame.DataFrame
 |      Retorna metadados de uma tabela.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um Pandas DataFrame contendo as informações sobre a tabela
 |               existentes no catálogo syscat.systabstats
 |      :rtype: pandas.core.api.DataFrame
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  url
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  envs = {'database': 'DB2_DATABASE', 'host': 'DB2_HOST', 'password': 'D...
 |  
 |  jars_path = '/projeto/libs/lib/python3.9/site-packages/bbmagic/jars/db...
```

---

## Método `query` — módulo `bbmagic.db2`

### Conteúdo

```text
query(sql: str, params: Optional[list] = None, chunksize: Optional[int] = 2500) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]] method of bbmagic.db2.Db2 instance
    Retorna um DataFrame contendo o resultado da execução da query SQL.
    
    :param sql: query SQL para execução
    :param params: lista de parâmetros para utilização na query
    :param chunksize: Se especificado, retorna um iterador onde chunksize é a quantidade
                      de linhas incluídas em cada chunk
    
    :return: Daframe ou Iterator[DataFrame]
    
    Exemplos de Uso::
    
        >>> for chunk in db2.query("SELECT * FROM db2mci.cliente LIMIT 10000"):
        ...     print(len(chunk))
        2500
        2500
        2500
        2500
    
    Sem utilização de chunks
    
        >>> df = db2.query("SELECT cod FROM db2mci.cliente LIMIT 100", chunksize=None)
```

---

## Método `show_schemas` — módulo `bbmagic.db2`

### Conteúdo

```text
show_schemas() -> pandas.core.frame.DataFrame method of bbmagic.db2.Db2 instance
    Lista todos os schemas no database
    
    :return: Retorna um Pandas DataFrame contendo uma linha para cada schema encontrado.
    :rtype: pandas.core.api.DataFrame
    
    Exemplo de uso::
    
        >>> db2.show_schemas()
```

---

## Método `show_tables` — módulo `bbmagic.db2`

### Conteúdo

```text
show_tables(schema: str) -> pandas.core.frame.DataFrame method of bbmagic.db2.Db2 instance
    Lista todas as tabelas e views de um schema.
    
    :param schema: nome do schema
    
    :return: Retorna um Pandas DataFrame contendo uma linha para cada tabela do schema
             e as informações *schema*, *name* e *type* nas respectivas colunas.
    :rtype: pandas.core.api.DataFrame
    
    Exemplo de uso::
    
        >>> db2.show_tables("DB2MCI")
```

---

## Método `describe` — módulo `bbmagic.db2`

### Conteúdo

```text
describe(schema: str, table: str) -> IPython.core.display.HTML method of bbmagic.db2.Db2 instance
    Gera um relatório consolidado com os metadados da tabela existentes no catálogo
    do DB2.
    
    :param schema: nome do schema
    :param table: nome da tabela
    
    :return: Retorna um objeto HTML com o relatório para exibição no Jupyter Notebook.
    :rtype: IPython.core.display.HTML
```

---

## Método `syscolumns` — módulo `bbmagic.db2`

### Conteúdo

```text
syscolumns(schema: str, table: str) -> pandas.core.frame.DataFrame method of bbmagic.db2.Db2 instance
    Retorna metadados das colunas de uma tabela.
    
    :param schema: nome do schema
    :param table: nome da tabela
    
    :return: Retorna um Pandas DataFrame contendo as informações sobre as colunas da
             tabela de acordo com o catálogo syscat.syscolumns
    :rtype: pandas.core.api.DataFrame
```

---

## Método `systabstats` — módulo `bbmagic.db2`

### Conteúdo

```text
systabstats(schema: str, table: str) -> pandas.core.frame.DataFrame method of bbmagic.db2.Db2 instance
    Retorna metadados de uma tabela.
    
    :param schema: nome do schema
    :param table: nome da tabela
    
    :return: Retorna um Pandas DataFrame contendo as informações sobre a tabela
             existentes no catálogo syscat.systabstats
    :rtype: pandas.core.api.DataFrame
```

---

## Objeto `Hdfs` — módulo `bbmagic.hdfs`

### Conteúdo

```text
class Hdfs(hdfs.ext.kerberos.KerberosClient)
 |  Hdfs(username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
 |  
 |  Permite acesso ao HDFS com autenticação via kerberos.
 |  
 |  :param username: matrícula ou caminho para arquivo keytab
 |  :param \*\*kwargs: Argumentos adicionais passados para a classe HTTPKerberosAuth.
 |  
 |  Method resolution order:
 |      Hdfs
 |      hdfs.ext.kerberos.KerberosClient
 |      hdfs.client.Client
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self, username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  set_no_proxy(self) -> None
 |      Garante que a variável no_proxy está configurada para ignorar o domínio
 |      da API web da BBMagic
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from hdfs.client.Client:
 |  
 |  __repr__(self)
 |      Return repr(self).
 |  
 |  acl_status(self, hdfs_path, strict=True)
 |      Get AclStatus_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _AclStatus: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Get_ACL_Status
 |  
 |  allow_snapshot(self, hdfs_path)
 |      Allow snapshots for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist or does points to a normal file, an
 |        :class:`HdfsError` will be raised.  No-op if snapshotting is
 |        already allowed.
 |  
 |  checksum(self, hdfs_path)
 |      Get a remote file's checksum.
 |      
 |      :param hdfs_path: Remote path. Must point to a file.
 |  
 |  content(self, hdfs_path, strict=True)
 |      Get ContentSummary_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _ContentSummary: CS_
 |      .. _CS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#ContentSummary
 |  
 |  create_snapshot(self, hdfs_path, snapshotname=None)
 |      Create snapshot for a remote folder where it was allowed.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist, doesn't allow to create snapshot or points to a
 |        normal file, an :class:`HdfsError` will be raised.
 |      :param snapshotname snapshot name; if absent, name is generated
 |        by the server.
 |      
 |      Returns a path to created snapshot.
 |  
 |  delete(self, hdfs_path, recursive=False, skip_trash=True)
 |      Remove a file or directory from HDFS.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param recursive: Recursively delete files and directories. By default,
 |        this method will raise an :class:`HdfsError` if trying to delete a
 |        non-empty directory.
 |      :param skip_trash: When false, the deleted path will be moved to an
 |        appropriate trash folder rather than deleted. This requires Hadoop 2.9+
 |      
 |      This function returns `True` if the deletion was successful and `False` if
 |      no file or directory previously existed at `hdfs_path`.
 |  
 |  delete_snapshot(self, hdfs_path, snapshotname)
 |      Remove snapshot for a remote folder where it was allowed.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param snapshotname snapshot name; if it does not exist, an
 |        :class:`HdfsError` will be raised.
 |  
 |  disallow_snapshot(self, hdfs_path)
 |      Disallow snapshots for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist, points to a normal file or there are some
 |        snapshots, an :class:`HdfsError` will be raised.
 |      
 |      No-op if snapshotting is disallowed/never allowed.
 |  
 |  download(self, hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs)
 |      Download a file or folder from HDFS and save it locally.
 |      
 |      :param hdfs_path: Path on HDFS of the file or folder to download. If a
 |        folder, all the files under it will be downloaded.
 |      :param local_path: Local path. If it already exists and is a directory,
 |        the files will be downloaded inside of it.
 |      :param overwrite: Overwrite any existing file or directory.
 |      :param n_threads: Number of threads to use for parallelization. A value of
 |        `0` (or negative) uses as many threads as there are files.
 |      :param temp_dir: Directory under which the files will first be downloaded
 |        when `overwrite=True` and the final destination path already exists. Once
 |        the download successfully completes, it will be swapped in.
 |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`read`. If no
 |        `chunk_size` argument is passed, a default value of 64 kB will be used.
 |        If a `progress` argument is passed and threading is used, care must be
 |        taken to ensure correct behavior.
 |      
 |      On success, this method returns the local download path.
 |  
 |  list(self, hdfs_path, status=False)
 |      Return names of files contained in a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory. If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param status: Also return each file's corresponding FileStatus_.
 |  
 |  makedirs(self, hdfs_path, permission=None)
 |      Create a remote directory, recursively if necessary.
 |      
 |      :param hdfs_path: Remote path. Intermediate directories will be created
 |        appropriately.
 |      :param permission: Octal permission to set on the newly created directory.
 |        These permissions will only be set on directories that do not already
 |        exist.
 |      
 |      This function currently has no return value as WebHDFS doesn't return a
 |      meaningful flag.
 |  
 |  parts(self, hdfs_path, parts=None, status=False)
 |      Returns a dictionary of part-files corresponding to a path.
 |      
 |      :param hdfs_path: Remote path. This directory should contain at most one
 |        part file per partition (otherwise one will be picked arbitrarily).
 |      :param parts: List of part-files numbers or total number of part-files to
 |        select. If a number, that many partitions will be chosen at random. By
 |        default all part-files are returned. If `parts` is a list and one of the
 |        parts is not found or too many samples are demanded, an
 |        :class:`~hdfs.util.HdfsError` is raised.
 |      :param status: Also return each file's corresponding FileStatus_.
 |  
 |  read(self, hdfs_path, offset=0, length=None, buffer_size=None, encoding=None, chunk_size=0, delimiter=None, progress=None)
 |      Read a file from HDFS.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param offset: Starting byte position.
 |      :param length: Number of bytes to be processed. `None` will read the entire
 |        file.
 |      :param buffer_size: Size of the buffer in bytes used for transferring the
 |        data. Defaults the the value set in the HDFS configuration.
 |      :param encoding: Encoding used to decode the request. By default the raw
 |        data is returned. This is mostly helpful in python 3, for example to
 |        deserialize JSON data (as the decoder expects unicode).
 |      :param chunk_size: If set to a positive number, the context manager will
 |        return a generator yielding every `chunk_size` bytes instead of a
 |        file-like object (unless `delimiter` is also set, see below).
 |      :param delimiter: If set, the context manager will return a generator
 |        yielding each time the delimiter is encountered. This parameter requires
 |        the `encoding` to be specified.
 |      :param progress: Callback function to track progress, called every
 |        `chunk_size` bytes (not available if the chunk size isn't specified). It
 |        will be passed two arguments, the path to the file being uploaded and the
 |        number of bytes transferred so far. On completion, it will be called once
 |        with `-1` as second argument.
 |      
 |      This method must be called using a `with` block:
 |      
 |      .. code-block:: python
 |      
 |        with client.read('foo') as reader:
 |          content = reader.read()
 |      
 |      This ensures that connections are always properly closed.
 |      
 |      .. note::
 |      
 |        The raw file-like object returned by this method (when called without an
 |        encoding, chunk size, or delimiter) can have a very different performance
 |        profile than local files. In particular, line-oriented methods are often
 |        slower. The recommended workaround is to specify an encoding when
 |        possible or read the entire file before splitting it.
 |  
 |  remove_acl(self, hdfs_path)
 |      RemoveAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      
 |      .. _RemoveAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL
 |  
 |  remove_acl_entries(self, hdfs_path, acl_spec)
 |      RemoveAclEntries_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      :param acl_spec: String representation of an ACL spec. Must be a valid
 |        string with entries for user, group and other. For example:
 |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
 |      
 |      .. _RemoveAclEntries: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL_Entries
 |  
 |  remove_default_acl(self, hdfs_path)
 |      RemoveDefaultAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      
 |      .. _RemoveDefaultAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_Default_ACL
 |  
 |  rename(self, hdfs_src_path, hdfs_dst_path)
 |      Move a file or folder.
 |      
 |      :param hdfs_src_path: Source path.
 |      :param hdfs_dst_path: Destination path. If the path already exists and is
 |        a directory, the source will be moved into it. If the path exists and is
 |        a file, or if a parent destination directory is missing, this method will
 |        raise an :class:`HdfsError`.
 |  
 |  rename_snapshot(self, hdfs_path, oldsnapshotname, snapshotname)
 |      Rename snapshot for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param oldsnapshotname snapshot name; if it does not exist,
 |        an :class:`HdfsError` will be raised.
 |      :param snapshotname new snapshot name; if it does already exist,
 |        an :class:`HdfsError` will be raised.
 |  
 |  resolve(self, hdfs_path)
 |      Return absolute, normalized path, with special markers expanded.
 |      
 |      :param hdfs_path: Remote path.
 |      
 |      Currently supported markers:
 |      
 |      * `'#LATEST'`: this marker gets expanded to the most recently updated file
 |        or folder. They can be combined using the `'{N}'` suffix. For example,
 |        `'foo/#LATEST{2}'` is equivalent to `'foo/#LATEST/#LATEST'`.
 |  
 |  set_acl(self, hdfs_path, acl_spec, clear=True)
 |      SetAcl_ or ModifyAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      :param acl_spec: String representation of an ACL spec. Must be a valid
 |        string with entries for user, group and other. For example:
 |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
 |      :param clear: Clear existing ACL entries. If set to false, all existing ACL
 |        entries that are not specified in this call are retained without changes,
 |        behaving like ModifyAcl_. For example: `"user:foo:rwx"`.
 |      
 |      .. _SetAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Set_ACL
 |      .. _ModifyAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Modify_ACL_Entries
 |  
 |  set_owner(self, hdfs_path, owner=None, group=None)
 |      Change the owner of file.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param owner: Optional, new owner for file.
 |      :param group: Optional, new group for file.
 |      
 |      At least one of `owner` and `group` must be specified.
 |  
 |  set_permission(self, hdfs_path, permission)
 |      Change the permissions of file.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param permission: New octal permissions string of file.
 |  
 |  set_replication(self, hdfs_path, replication)
 |      Set file replication.
 |      
 |      :param hdfs_path: Path to an existing remote file. An :class:`HdfsError`
 |        will be raised if the path doesn't exist or points to a directory.
 |      :param replication: Replication factor.
 |  
 |  set_times(self, hdfs_path, access_time=None, modification_time=None)
 |      Change remote timestamps.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param access_time: Timestamp of last file access.
 |      :param modification_time: Timestamps of last file access.
 |  
 |  status(self, hdfs_path, strict=True)
 |      Get FileStatus_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _FileStatus: FS_
 |      .. _FS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#FileStatus
 |  
 |  upload(self, hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs)
 |      Upload a file or directory to HDFS.
 |      
 |      :param hdfs_path: Target HDFS path. If it already exists and is a
 |        directory, files will be uploaded inside.
 |      :param local_path: Local path to file or folder. If a folder, all the files
 |        inside of it will be uploaded (note that this implies that folders empty
 |        of files will not be created remotely).
 |      :param n_threads: Number of threads to use for parallelization. A value of
 |        `0` (or negative) uses as many threads as there are files.
 |      :param temp_dir: Directory under which the files will first be uploaded
 |        when `overwrite=True` and the final remote path already exists. Once the
 |        upload successfully completes, it will be swapped in.
 |      :param chunk_size: Interval in bytes by which the files will be uploaded.
 |      :param progress: Callback function to track progress, called every
 |        `chunk_size` bytes. It will be passed two arguments, the path to the
 |        file being uploaded and the number of bytes transferred so far. On
 |        completion, it will be called once with `-1` as second argument.
 |      :param cleanup: Delete any uploaded files if an error occurs during the
 |        upload.
 |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`write`. In
 |        particular, set `overwrite` to overwrite any existing file or directory.
 |      
 |      On success, this method returns the remote upload path.
 |  
 |  walk(self, hdfs_path, depth=0, status=False, ignore_missing=False, allow_dir_changes=False)
 |      Depth-first walk of remote filesystem.
 |      
 |      :param hdfs_path: Starting path. If the path doesn't exist, an
 |        :class:`HdfsError` will be raised. If it points to a file, the returned
 |        generator will be empty.
 |      :param depth: Maximum depth to explore. `0` for no limit.
 |      :param status: Also return each file or folder's corresponding FileStatus_.
 |      :param ignore_missing: Ignore missing nested folders rather than raise an
 |        exception. This can be useful when the tree is modified during a walk.
 |      :param allow_dir_changes: Allow changes to the directories' list to affect
 |        the walk. For example clearing it by setting `dirs[:] = []` would prevent
 |        the walk from entering any nested directories. This option can only be set
 |        when `status` is false.
 |      
 |      This method returns a generator yielding tuples `(path, dirs, files)`
 |      where `path` is the absolute path to the current directory, `dirs` is the
 |      list of directory names it contains, and `files` is the list of file names
 |      it contains.
 |  
 |  write(self, hdfs_path, data=None, overwrite=False, permission=None, blocksize=None, replication=None, buffersize=None, append=False, encoding=None)
 |      Create a file on HDFS.
 |      
 |      :param hdfs_path: Path where to create file. The necessary directories will
 |        be created appropriately.
 |      :param data: Contents of file to write. Can be a string, a generator or a
 |        file object. The last two options will allow streaming upload (i.e.
 |        without having to load the entire contents into memory). If `None`, this
 |        method will return a file-like object and should be called using a `with`
 |        block (see below for examples).
 |      :param overwrite: Overwrite any existing file or directory.
 |      :param permission: Octal permission to set on the newly created file.
 |        Leading zeros may be omitted.
 |      :param blocksize: Block size of the file.
 |      :param replication: Number of replications of the file.
 |      :param buffersize: Size of upload buffer.
 |      :param append: Append to a file rather than create a new one.
 |      :param encoding: Encoding used to serialize data written.
 |      
 |      Sample usages:
 |      
 |      .. code-block:: python
 |      
 |        from json import dump, dumps
 |      
 |        records = [
 |          {'name': 'foo', 'weight': 1},
 |          {'name': 'bar', 'weight': 2},
 |        ]
 |      
 |        # As a context manager:
 |        with client.write('data/records.jsonl', encoding='utf-8') as writer:
 |          dump(records, writer)
 |      
 |        # Or, passing in a generator directly:
 |        client.write('data/records.jsonl', data=dumps(records), encoding='utf-8')
 |  
 |  ----------------------------------------------------------------------
 |  Class methods inherited from hdfs.client.Client:
 |  
 |  from_options(options, class_name='Client') from hdfs.client._ClientType
 |      Load client from options.
 |      
 |      :param options: Options dictionary.
 |      :param class_name: Client class name. Defaults to the base :class:`Client`
 |        class.
 |      
 |      This method provides a single entry point to instantiate any registered
 |      :class:`Client` subclass. To register a subclass, simply load its
 |      containing module. If using the CLI, you can use the `autoload.modules` and
 |      `autoload.paths` options.
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from hdfs.client.Client:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes inherited from hdfs.client.Client:
 |  
 |  __registry__ = {'Client': <class 'hdfs.client.Client'>, 'Hdfs': <class...
```

---

## Método `upload` — módulo `hdfs.client`

### Conteúdo

```text
upload(hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs) method of bbmagic.hdfs.Hdfs instance
    Upload a file or directory to HDFS.
    
    :param hdfs_path: Target HDFS path. If it already exists and is a
      directory, files will be uploaded inside.
    :param local_path: Local path to file or folder. If a folder, all the files
      inside of it will be uploaded (note that this implies that folders empty
      of files will not be created remotely).
    :param n_threads: Number of threads to use for parallelization. A value of
      `0` (or negative) uses as many threads as there are files.
    :param temp_dir: Directory under which the files will first be uploaded
      when `overwrite=True` and the final remote path already exists. Once the
      upload successfully completes, it will be swapped in.
    :param chunk_size: Interval in bytes by which the files will be uploaded.
    :param progress: Callback function to track progress, called every
      `chunk_size` bytes. It will be passed two arguments, the path to the
      file being uploaded and the number of bytes transferred so far. On
      completion, it will be called once with `-1` as second argument.
    :param cleanup: Delete any uploaded files if an error occurs during the
      upload.
    :param \*\*kwargs: Keyword arguments forwarded to :meth:`write`. In
      particular, set `overwrite` to overwrite any existing file or directory.
    
    On success, this method returns the remote upload path.
```

---

## Método `download` — módulo `hdfs.client`

### Conteúdo

```text
download(hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs) method of bbmagic.hdfs.Hdfs instance
    Download a file or folder from HDFS and save it locally.
    
    :param hdfs_path: Path on HDFS of the file or folder to download. If a
      folder, all the files under it will be downloaded.
    :param local_path: Local path. If it already exists and is a directory,
      the files will be downloaded inside of it.
    :param overwrite: Overwrite any existing file or directory.
    :param n_threads: Number of threads to use for parallelization. A value of
      `0` (or negative) uses as many threads as there are files.
    :param temp_dir: Directory under which the files will first be downloaded
      when `overwrite=True` and the final destination path already exists. Once
      the download successfully completes, it will be swapped in.
    :param \*\*kwargs: Keyword arguments forwarded to :meth:`read`. If no
      `chunk_size` argument is passed, a default value of 64 kB will be used.
      If a `progress` argument is passed and threading is used, care must be
      taken to ensure correct behavior.
    
    On success, this method returns the local download path.
```

---

## Método `list` — módulo `hdfs.client`

### Conteúdo

```text
list(hdfs_path, status=False) method of bbmagic.hdfs.Hdfs instance
    Return names of files contained in a remote folder.
    
    :param hdfs_path: Remote path to a directory. If `hdfs_path` doesn't exist
      or points to a normal file, an :class:`HdfsError` will be raised.
    :param status: Also return each file's corresponding FileStatus_.
```

---

## Método `delete` — módulo `hdfs.client`

### Conteúdo

```text
delete(hdfs_path, recursive=False, skip_trash=True) method of bbmagic.hdfs.Hdfs instance
    Remove a file or directory from HDFS.
    
    :param hdfs_path: HDFS path.
    :param recursive: Recursively delete files and directories. By default,
      this method will raise an :class:`HdfsError` if trying to delete a
      non-empty directory.
    :param skip_trash: When false, the deleted path will be moved to an
      appropriate trash folder rather than deleted. This requires Hadoop 2.9+
    
    This function returns `True` if the deletion was successful and `False` if
    no file or directory previously existed at `hdfs_path`.
```

---

## Método `rename` — módulo `hdfs.client`

### Conteúdo

```text
rename(hdfs_src_path, hdfs_dst_path) method of bbmagic.hdfs.Hdfs instance
    Move a file or folder.
    
    :param hdfs_src_path: Source path.
    :param hdfs_dst_path: Destination path. If the path already exists and is
      a directory, the source will be moved into it. If the path exists and is
      a file, or if a parent destination directory is missing, this method will
      raise an :class:`HdfsError`.
```

---

## Método `status` — módulo `hdfs.client`

### Conteúdo

```text
status(hdfs_path, strict=True) method of bbmagic.hdfs.Hdfs instance
    Get FileStatus_ for a file or folder on HDFS.
    
    :param hdfs_path: Remote path.
    :param strict: If `False`, return `None` rather than raise an exception if
      the path doesn't exist.
    
    .. _FileStatus: FS_
    .. _FS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#FileStatus
```

---

## Método `read` — módulo `hdfs.client`

### Conteúdo

```text
read(hdfs_path, offset=0, length=None, buffer_size=None, encoding=None, chunk_size=0, delimiter=None, progress=None) method of bbmagic.hdfs.Hdfs instance
    Read a file from HDFS.
    
    :param hdfs_path: HDFS path.
    :param offset: Starting byte position.
    :param length: Number of bytes to be processed. `None` will read the entire
      file.
    :param buffer_size: Size of the buffer in bytes used for transferring the
      data. Defaults the the value set in the HDFS configuration.
    :param encoding: Encoding used to decode the request. By default the raw
      data is returned. This is mostly helpful in python 3, for example to
      deserialize JSON data (as the decoder expects unicode).
    :param chunk_size: If set to a positive number, the context manager will
      return a generator yielding every `chunk_size` bytes instead of a
      file-like object (unless `delimiter` is also set, see below).
    :param delimiter: If set, the context manager will return a generator
      yielding each time the delimiter is encountered. This parameter requires
      the `encoding` to be specified.
    :param progress: Callback function to track progress, called every
      `chunk_size` bytes (not available if the chunk size isn't specified). It
      will be passed two arguments, the path to the file being uploaded and the
      number of bytes transferred so far. On completion, it will be called once
      with `-1` as second argument.
    
    This method must be called using a `with` block:
    
    .. code-block:: python
    
      with client.read('foo') as reader:
        content = reader.read()
    
    This ensures that connections are always properly closed.
    
    .. note::
    
      The raw file-like object returned by this method (when called without an
      encoding, chunk size, or delimiter) can have a very different performance
      profile than local files. In particular, line-oriented methods are often
      slower. The recommended workaround is to specify an encoding when
      possible or read the entire file before splitting it.
```

---

## Método `write` — módulo `hdfs.client`

### Conteúdo

```text
write(hdfs_path, data=None, overwrite=False, permission=None, blocksize=None, replication=None, buffersize=None, append=False, encoding=None) method of bbmagic.hdfs.Hdfs instance
    Create a file on HDFS.
    
    :param hdfs_path: Path where to create file. The necessary directories will
      be created appropriately.
    :param data: Contents of file to write. Can be a string, a generator or a
      file object. The last two options will allow streaming upload (i.e.
      without having to load the entire contents into memory). If `None`, this
      method will return a file-like object and should be called using a `with`
      block (see below for examples).
    :param overwrite: Overwrite any existing file or directory.
    :param permission: Octal permission to set on the newly created file.
      Leading zeros may be omitted.
    :param blocksize: Block size of the file.
    :param replication: Number of replications of the file.
    :param buffersize: Size of upload buffer.
    :param append: Append to a file rather than create a new one.
    :param encoding: Encoding used to serialize data written.
    
    Sample usages:
    
    .. code-block:: python
    
      from json import dump, dumps
    
      records = [
        {'name': 'foo', 'weight': 1},
        {'name': 'bar', 'weight': 2},
      ]
    
      # As a context manager:
      with client.write('data/records.jsonl', encoding='utf-8') as writer:
        dump(records, writer)
    
      # Or, passing in a generator directly:
      client.write('data/records.jsonl', data=dumps(records), encoding='utf-8')
```

---

## Método `walk` — módulo `hdfs.client`

### Conteúdo

```text
walk(hdfs_path, depth=0, status=False, ignore_missing=False, allow_dir_changes=False) method of bbmagic.hdfs.Hdfs instance
    Depth-first walk of remote filesystem.
    
    :param hdfs_path: Starting path. If the path doesn't exist, an
      :class:`HdfsError` will be raised. If it points to a file, the returned
      generator will be empty.
    :param depth: Maximum depth to explore. `0` for no limit.
    :param status: Also return each file or folder's corresponding FileStatus_.
    :param ignore_missing: Ignore missing nested folders rather than raise an
      exception. This can be useful when the tree is modified during a walk.
    :param allow_dir_changes: Allow changes to the directories' list to affect
      the walk. For example clearing it by setting `dirs[:] = []` would prevent
      the walk from entering any nested directories. This option can only be set
      when `status` is false.
    
    This method returns a generator yielding tuples `(path, dirs, files)`
    where `path` is the absolute path to the current directory, `dirs` is the
    list of directory names it contains, and `files` is the list of file names
    it contains.


SparkSession available as 'spark'.
```

---

## Objeto `Spark` — módulo `bbmagic.spark`

### Conteúdo

```text
class Spark(builtins.object)
 |  Spark(session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
 |  
 |  Cria uma sessão Spark.
 |  
 |  :param session_name: nome da sessão que será exibido na Web UI do Spark
 |  :param username: caminho para arquivo .keytab ou matrícula sem o dígito do usuário
 |  :param python: versão do Python da sessão Spark (2 ou 3)
 |  :param language: linguagem utilizada na sessão Spark ('python' ou 'scala')
 |  :param auth: modo de autenticação no Livy
 |  :param timeout: tempo máximo até que a sessão Spark seja criada
 |  :param db2: configura a sessão Spark para conexão JDBC ao DB2
 |  :param spark_conf: dicionário de parâmetros adicionais para configuração da sessão Spark.
 |                     Esse parâmetro tem prioridade sobre a padrão do BBMagic
 |  :param jars: lista de paths de arquivos .jar localizados no HDFS que serão utilizados na
 |               sessão. Ex: ['hdfs:///user/jars/database.jar']
 |  :param env: dicionário utilizado para definição de variáveis de ambiente na sessão Spark
 |  :param debug: exibe mais informações sobre a sessão Spark
 |  :param driver_memory: Quantidade de memória alocada para o driver da sessão Spark seguida
 |                        pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
 |                        (Ex.: '512m', '4g').
 |  :param driver_cores: Quantidade de cores alocados para o driver da sessão Spark
 |  :param num_executors: Quantidade de executores alocados para a sessão Spark.
 |  :param executor_memory: Quantidade de memória alocada cada executor da sessão Spark seguida
 |                          pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
 |                          (Ex.: '512m', '4g').
 |  :param executor_cores: Quantidade de cores alocados para cada executor da sessão Spark
 |  :param spark_version: Identifica a versao do Spark que ira receber a conexao - 2 ou 3
 |  
 |  Methods defined here:
 |  
 |  __del__(self) -> None
 |      Garante que a sessão Livy é encerrada assim que o Python finalize
 |  
 |  __init__(self, session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  close(self) -> None
 |      Encerra a sessão Spark
 |  
 |  config_db2(self) -> None
 |  
 |  config_jars(self) -> None
 |      Adiciona os jars para utilização de bibliotecas de machine learning distribuidas nas sessões spark 3
 |  
 |  config_sparkmagic(self) -> None
 |  
 |  config_virtualenv(self, virtualenv: Optional[str], overwrite: bool = False) -> Optional[str]
 |  
 |  connect(self) -> None
 |  
 |  enforce_dynamic_allocation(self, config: Optional[Dict[str, str]]) -> Optional[dict]
 |  
 |  get_from_spark(self, var_name: str)
 |      Importa o conteúdo de uma variável da sessão Spark para a sessão local.
 |      
 |      
 |      :param var_name: nome da variável que será importada.
 |      
 |      :return: Retorna o valor da variável
 |  
 |  send_to_spark(self, var) -> None
 |      Envia uma variável local para a sessão Spark.
 |      
 |      A variável será definida com mesmo nome na sessão Spark e o valor
 |      será transmitido utilizando pickle.
 |      
 |      :param var: variável que será enviada para a sessão Spark.
 |      
 |      :return: None
 |  
 |  ----------------------------------------------------------------------
 |  Class methods defined here:
 |  
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  ambiente
 |  
 |  bbmagic_session_id
 |  
 |  
 |  default_env
 |  
 |  force_dynammic_allocation
 |  
 |  livy_conn
 |  
 |  livy_session_id
 |  
 |  livy_url
 |  
 |  livy_version
 |  
 |  pickle_protocol
 |  
 |  spark_session_name
 |  
 |  spark_version
 |  
 |  user
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Método `connect` — módulo `bbmagic.spark`

### Conteúdo

```text
connect() -> None method of bbmagic.spark.Spark instance
```

---

## Método `close` — módulo `bbmagic.spark`

### Conteúdo

```text
close() -> None method of bbmagic.spark.Spark instance
    Encerra a sessão Spark
```

---

## Método `send_to_spark` — módulo `bbmagic.spark`

### Conteúdo

```text
send_to_spark(var) -> None method of bbmagic.spark.Spark instance
    Envia uma variável local para a sessão Spark.
    
    A variável será definida com mesmo nome na sessão Spark e o valor
    será transmitido utilizando pickle.
    
    :param var: variável que será enviada para a sessão Spark.
    
    :return: None
```

---

## Método `get_from_spark` — módulo `bbmagic.spark`

### Conteúdo

```text
get_from_spark(var_name: str) method of bbmagic.spark.Spark instance
    Importa o conteúdo de uma variável da sessão Spark para a sessão local.
    
    
    :param var_name: nome da variável que será importada.
    
    :return: Retorna o valor da variável
```

---

## Método `config_db2` — módulo `bbmagic.spark`

### Conteúdo

```text
config_db2() -> None method of bbmagic.spark.Spark instance
```

---

## Método `config_jars` — módulo `bbmagic.spark`

### Conteúdo

```text
config_jars() -> None method of bbmagic.spark.Spark instance
    Adiciona os jars para utilização de bibliotecas de machine learning distribuidas nas sessões spark 3
```

---

## Classe `FileConfig` — módulo `bbmagic.file_config`

### Conteúdo

```text
class FileConfig(builtins.object)
 |  FileConfig(path) -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self, path) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `GitLabConfig` — módulo `bbmagic.gitlab_config`

### Conteúdo

```text
class GitLabConfig(bbmagic.file_config.FileConfig)
 |  Method resolution order:
 |      GitLabConfig
 |      bbmagic.file_config.FileConfig
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from bbmagic.file_config.FileConfig:
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from bbmagic.file_config.FileConfig:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `HttpConfig` — módulo `bbmagic.http_config`

### Conteúdo

```text
class HttpConfig(bbmagic.file_config.FileConfig)
 |  HttpConfig(set_no_proxy: bool = True)
 |  
 |  Method resolution order:
 |      HttpConfig
 |      bbmagic.file_config.FileConfig
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self, set_no_proxy: bool = True)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  set_no_proxy(self) -> None
 |      Garante que a variável no_proxy está configurada para ignorar o domínio
 |      da API web da BBMagic
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from bbmagic.file_config.FileConfig:
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from bbmagic.file_config.FileConfig:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `MetaDataHive` — módulo `bbmagic.sumary`

### Conteúdo

```text
class MetaDataHive(builtins.object)
 |  MetaDataHive() -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  get_token(self) -> Optional[str]
 |  
 |  get_url(self) -> Optional[str]
 |  
 |  status_db(self, db: str, list: Optional[bool] = False) -> Optional[pandas.core.frame.DataFrame]
 |  
 |  status_table(self, nome_db: Optional[str] = None, nome_tabela: Optional[str] = None) -> Optional[pandas.core.frame.DataFrame]
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)

⇿ Connecting... | MetaDataHive.
✓ Connected | MetaDataHive.
```

---

## Método `status_db` — módulo `bbmagic.sumary`

### Conteúdo

```text
status_db(db: str, list: Optional[bool] = False) -> Optional[pandas.core.frame.DataFrame] method of bbmagic.sumary.MetaDataHive instance
```

---

## Método `status_table` — módulo `bbmagic.sumary`

### Conteúdo

```text
status_table(nome_db: Optional[str] = None, nome_tabela: Optional[str] = None) -> Optional[pandas.core.frame.DataFrame] method of bbmagic.sumary.MetaDataHive instance



==== AuthInfo ====
```

---

## Classe `AuthInfo` — módulo `bbmagic.sas.authinfo`

### Conteúdo

```text
class AuthInfo(builtins.object)
 |  Methods defined here:
 |  
 |  __init__(self)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  __len__(self) -> int
 |  
 |  add_key(self, name: str, user: str, password: Optional[str] = None) -> None
 |  
 |  parse(self) -> list
 |  
 |  remove_key(self, name: str) -> None
 |  
 |  write(self) -> None
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  path
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== AuthKey ====
```

---

## Classe `AuthKey` — módulo `bbmagic.sas.authinfo`

### Conteúdo

```text
class AuthKey(builtins.object)
 |  AuthKey(name: str, user: str, password: Optional[str] = None) -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self, name: str, user: str, password: Optional[str] = None) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  __str__(self) -> str
 |      Return str(self).
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== Db2 ====
```

---

## Classe `Db2` — módulo `bbmagic.db2`

### Conteúdo

```text
class Db2(builtins.object)
 |  Db2(user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
 |  
 |  Cria uma conexão ao DB2
 |  
 |  Methods defined here:
 |  
 |  __init__(self, user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  connect(self) -> ibm_db_dbi.Connection
 |      Cria a conexão JDBC com o servidor DB2.
 |  
 |  describe(self, schema: str, table: str) -> IPython.core.display.HTML
 |      Gera um relatório consolidado com os metadados da tabela existentes no catálogo
 |      do DB2.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um objeto HTML com o relatório para exibição no Jupyter Notebook.
 |      :rtype: IPython.core.display.HTML
 |  
 |  get_cofre_credentials(self, project_id: str) -> dict
 |      Recupera credenciais do cofre com base no project_id do projeto
 |  
 |  query(self, sql: str, params: Optional[list] = None, chunksize: Optional[int] = 2500) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
 |      Retorna um DataFrame contendo o resultado da execução da query SQL.
 |      
 |      :param sql: query SQL para execução
 |      :param params: lista de parâmetros para utilização na query
 |      :param chunksize: Se especificado, retorna um iterador onde chunksize é a quantidade
 |                        de linhas incluídas em cada chunk
 |      
 |      :return: Daframe ou Iterator[DataFrame]
 |      
 |      Exemplos de Uso::
 |      
 |          >>> for chunk in db2.query("SELECT * FROM db2mci.cliente LIMIT 10000"):
 |          ...     print(len(chunk))
 |          2500
 |          2500
 |          2500
 |          2500
 |      
 |      Sem utilização de chunks
 |      
 |          >>> df = db2.query("SELECT cod FROM db2mci.cliente LIMIT 100", chunksize=None)
 |  
 |  set_conn_param(self, param_name, param_value: Union[str, int, NoneType]) -> Union[str, int]
 |  
 |  show_schemas(self) -> pandas.core.frame.DataFrame
 |      Lista todos os schemas no database
 |      
 |      :return: Retorna um Pandas DataFrame contendo uma linha para cada schema encontrado.
 |      :rtype: pandas.core.api.DataFrame
 |      
 |      Exemplo de uso::
 |      
 |          >>> db2.show_schemas()
 |  
 |  show_tables(self, schema: str) -> pandas.core.frame.DataFrame
 |      Lista todas as tabelas e views de um schema.
 |      
 |      :param schema: nome do schema
 |      
 |      :return: Retorna um Pandas DataFrame contendo uma linha para cada tabela do schema
 |               e as informações *schema*, *name* e *type* nas respectivas colunas.
 |      :rtype: pandas.core.api.DataFrame
 |      
 |      Exemplo de uso::
 |      
 |          >>> db2.show_tables("DB2MCI")
 |  
 |  syscolumns(self, schema: str, table: str) -> pandas.core.frame.DataFrame
 |      Retorna metadados das colunas de uma tabela.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um Pandas DataFrame contendo as informações sobre as colunas da
 |               tabela de acordo com o catálogo syscat.syscolumns
 |      :rtype: pandas.core.api.DataFrame
 |  
 |  systabstats(self, schema: str, table: str) -> pandas.core.frame.DataFrame
 |      Retorna metadados de uma tabela.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um Pandas DataFrame contendo as informações sobre a tabela
 |               existentes no catálogo syscat.systabstats
 |      :rtype: pandas.core.api.DataFrame
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  url
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  envs = {'database': 'DB2_DATABASE', 'host': 'DB2_HOST', 'password': 'D...
 |  
 |  jars_path = '/projeto/libs/lib/python3.9/site-packages/bbmagic/jars/db...


==== FileConfig ====
```

---

## Classe `FileConfig` — módulo `bbmagic.file_config`

### Conteúdo

```text
class FileConfig(builtins.object)
 |  FileConfig(path) -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self, path) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== GitLabConfig ====
```

---

## Classe `GitLabConfig` — módulo `bbmagic.gitlab_config`

### Conteúdo

```text
class GitLabConfig(bbmagic.file_config.FileConfig)
 |  Method resolution order:
 |      GitLabConfig
 |      bbmagic.file_config.FileConfig
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from bbmagic.file_config.FileConfig:
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from bbmagic.file_config.FileConfig:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== Hdfs ====
```

---

## Classe `Hdfs` — módulo `bbmagic.hdfs`

### Conteúdo

```text
class Hdfs(hdfs.ext.kerberos.KerberosClient)
 |  Hdfs(username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
 |  
 |  Permite acesso ao HDFS com autenticação via kerberos.
 |  
 |  :param username: matrícula ou caminho para arquivo keytab
 |  :param \*\*kwargs: Argumentos adicionais passados para a classe HTTPKerberosAuth.
 |  
 |  Method resolution order:
 |      Hdfs
 |      hdfs.ext.kerberos.KerberosClient
 |      hdfs.client.Client
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self, username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  set_no_proxy(self) -> None
 |      Garante que a variável no_proxy está configurada para ignorar o domínio
 |      da API web da BBMagic
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from hdfs.client.Client:
 |  
 |  __repr__(self)
 |      Return repr(self).
 |  
 |  acl_status(self, hdfs_path, strict=True)
 |      Get AclStatus_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _AclStatus: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Get_ACL_Status
 |  
 |  allow_snapshot(self, hdfs_path)
 |      Allow snapshots for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist or does points to a normal file, an
 |        :class:`HdfsError` will be raised.  No-op if snapshotting is
 |        already allowed.
 |  
 |  checksum(self, hdfs_path)
 |      Get a remote file's checksum.
 |      
 |      :param hdfs_path: Remote path. Must point to a file.
 |  
 |  content(self, hdfs_path, strict=True)
 |      Get ContentSummary_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _ContentSummary: CS_
 |      .. _CS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#ContentSummary
 |  
 |  create_snapshot(self, hdfs_path, snapshotname=None)
 |      Create snapshot for a remote folder where it was allowed.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist, doesn't allow to create snapshot or points to a
 |        normal file, an :class:`HdfsError` will be raised.
 |      :param snapshotname snapshot name; if absent, name is generated
 |        by the server.
 |      
 |      Returns a path to created snapshot.
 |  
 |  delete(self, hdfs_path, recursive=False, skip_trash=True)
 |      Remove a file or directory from HDFS.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param recursive: Recursively delete files and directories. By default,
 |        this method will raise an :class:`HdfsError` if trying to delete a
 |        non-empty directory.
 |      :param skip_trash: When false, the deleted path will be moved to an
 |        appropriate trash folder rather than deleted. This requires Hadoop 2.9+
 |      
 |      This function returns `True` if the deletion was successful and `False` if
 |      no file or directory previously existed at `hdfs_path`.
 |  
 |  delete_snapshot(self, hdfs_path, snapshotname)
 |      Remove snapshot for a remote folder where it was allowed.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param snapshotname snapshot name; if it does not exist, an
 |        :class:`HdfsError` will be raised.
 |  
 |  disallow_snapshot(self, hdfs_path)
 |      Disallow snapshots for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist, points to a normal file or there are some
 |        snapshots, an :class:`HdfsError` will be raised.
 |      
 |      No-op if snapshotting is disallowed/never allowed.
 |  
 |  download(self, hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs)
 |      Download a file or folder from HDFS and save it locally.
 |      
 |      :param hdfs_path: Path on HDFS of the file or folder to download. If a
 |        folder, all the files under it will be downloaded.
 |      :param local_path: Local path. If it already exists and is a directory,
 |        the files will be downloaded inside of it.
 |      :param overwrite: Overwrite any existing file or directory.
 |      :param n_threads: Number of threads to use for parallelization. A value of
 |        `0` (or negative) uses as many threads as there are files.
 |      :param temp_dir: Directory under which the files will first be downloaded
 |        when `overwrite=True` and the final destination path already exists. Once
 |        the download successfully completes, it will be swapped in.
 |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`read`. If no
 |        `chunk_size` argument is passed, a default value of 64 kB will be used.
 |        If a `progress` argument is passed and threading is used, care must be
 |        taken to ensure correct behavior.
 |      
 |      On success, this method returns the local download path.
 |  
 |  list(self, hdfs_path, status=False)
 |      Return names of files contained in a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory. If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param status: Also return each file's corresponding FileStatus_.
 |  
 |  makedirs(self, hdfs_path, permission=None)
 |      Create a remote directory, recursively if necessary.
 |      
 |      :param hdfs_path: Remote path. Intermediate directories will be created
 |        appropriately.
 |      :param permission: Octal permission to set on the newly created directory.
 |        These permissions will only be set on directories that do not already
 |        exist.
 |      
 |      This function currently has no return value as WebHDFS doesn't return a
 |      meaningful flag.
 |  
 |  parts(self, hdfs_path, parts=None, status=False)
 |      Returns a dictionary of part-files corresponding to a path.
 |      
 |      :param hdfs_path: Remote path. This directory should contain at most one
 |        part file per partition (otherwise one will be picked arbitrarily).
 |      :param parts: List of part-files numbers or total number of part-files to
 |        select. If a number, that many partitions will be chosen at random. By
 |        default all part-files are returned. If `parts` is a list and one of the
 |        parts is not found or too many samples are demanded, an
 |        :class:`~hdfs.util.HdfsError` is raised.
 |      :param status: Also return each file's corresponding FileStatus_.
 |  
 |  read(self, hdfs_path, offset=0, length=None, buffer_size=None, encoding=None, chunk_size=0, delimiter=None, progress=None)
 |      Read a file from HDFS.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param offset: Starting byte position.
 |      :param length: Number of bytes to be processed. `None` will read the entire
 |        file.
 |      :param buffer_size: Size of the buffer in bytes used for transferring the
 |        data. Defaults the the value set in the HDFS configuration.
 |      :param encoding: Encoding used to decode the request. By default the raw
 |        data is returned. This is mostly helpful in python 3, for example to
 |        deserialize JSON data (as the decoder expects unicode).
 |      :param chunk_size: If set to a positive number, the context manager will
 |        return a generator yielding every `chunk_size` bytes instead of a
 |        file-like object (unless `delimiter` is also set, see below).
 |      :param delimiter: If set, the context manager will return a generator
 |        yielding each time the delimiter is encountered. This parameter requires
 |        the `encoding` to be specified.
 |      :param progress: Callback function to track progress, called every
 |        `chunk_size` bytes (not available if the chunk size isn't specified). It
 |        will be passed two arguments, the path to the file being uploaded and the
 |        number of bytes transferred so far. On completion, it will be called once
 |        with `-1` as second argument.
 |      
 |      This method must be called using a `with` block:
 |      
 |      .. code-block:: python
 |      
 |        with client.read('foo') as reader:
 |          content = reader.read()
 |      
 |      This ensures that connections are always properly closed.
 |      
 |      .. note::
 |      
 |        The raw file-like object returned by this method (when called without an
 |        encoding, chunk size, or delimiter) can have a very different performance
 |        profile than local files. In particular, line-oriented methods are often
 |        slower. The recommended workaround is to specify an encoding when
 |        possible or read the entire file before splitting it.
 |  
 |  remove_acl(self, hdfs_path)
 |      RemoveAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      
 |      .. _RemoveAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL
 |  
 |  remove_acl_entries(self, hdfs_path, acl_spec)
 |      RemoveAclEntries_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      :param acl_spec: String representation of an ACL spec. Must be a valid
 |        string with entries for user, group and other. For example:
 |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
 |      
 |      .. _RemoveAclEntries: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL_Entries
 |  
 |  remove_default_acl(self, hdfs_path)
 |      RemoveDefaultAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      
 |      .. _RemoveDefaultAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_Default_ACL
 |  
 |  rename(self, hdfs_src_path, hdfs_dst_path)
 |      Move a file or folder.
 |      
 |      :param hdfs_src_path: Source path.
 |      :param hdfs_dst_path: Destination path. If the path already exists and is
 |        a directory, the source will be moved into it. If the path exists and is
 |        a file, or if a parent destination directory is missing, this method will
 |        raise an :class:`HdfsError`.
 |  
 |  rename_snapshot(self, hdfs_path, oldsnapshotname, snapshotname)
 |      Rename snapshot for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param oldsnapshotname snapshot name; if it does not exist,
 |        an :class:`HdfsError` will be raised.
 |      :param snapshotname new snapshot name; if it does already exist,
 |        an :class:`HdfsError` will be raised.
 |  
 |  resolve(self, hdfs_path)
 |      Return absolute, normalized path, with special markers expanded.
 |      
 |      :param hdfs_path: Remote path.
 |      
 |      Currently supported markers:
 |      
 |      * `'#LATEST'`: this marker gets expanded to the most recently updated file
 |        or folder. They can be combined using the `'{N}'` suffix. For example,
 |        `'foo/#LATEST{2}'` is equivalent to `'foo/#LATEST/#LATEST'`.
 |  
 |  set_acl(self, hdfs_path, acl_spec, clear=True)
 |      SetAcl_ or ModifyAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      :param acl_spec: String representation of an ACL spec. Must be a valid
 |        string with entries for user, group and other. For example:
 |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
 |      :param clear: Clear existing ACL entries. If set to false, all existing ACL
 |        entries that are not specified in this call are retained without changes,
 |        behaving like ModifyAcl_. For example: `"user:foo:rwx"`.
 |      
 |      .. _SetAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Set_ACL
 |      .. _ModifyAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Modify_ACL_Entries
 |  
 |  set_owner(self, hdfs_path, owner=None, group=None)
 |      Change the owner of file.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param owner: Optional, new owner for file.
 |      :param group: Optional, new group for file.
 |      
 |      At least one of `owner` and `group` must be specified.
 |  
 |  set_permission(self, hdfs_path, permission)
 |      Change the permissions of file.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param permission: New octal permissions string of file.
 |  
 |  set_replication(self, hdfs_path, replication)
 |      Set file replication.
 |      
 |      :param hdfs_path: Path to an existing remote file. An :class:`HdfsError`
 |        will be raised if the path doesn't exist or points to a directory.
 |      :param replication: Replication factor.
 |  
 |  set_times(self, hdfs_path, access_time=None, modification_time=None)
 |      Change remote timestamps.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param access_time: Timestamp of last file access.
 |      :param modification_time: Timestamps of last file access.
 |  
 |  status(self, hdfs_path, strict=True)
 |      Get FileStatus_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _FileStatus: FS_
 |      .. _FS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#FileStatus
 |  
 |  upload(self, hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs)
 |      Upload a file or directory to HDFS.
 |      
 |      :param hdfs_path: Target HDFS path. If it already exists and is a
 |        directory, files will be uploaded inside.
 |      :param local_path: Local path to file or folder. If a folder, all the files
 |        inside of it will be uploaded (note that this implies that folders empty
 |        of files will not be created remotely).
 |      :param n_threads: Number of threads to use for parallelization. A value of
 |        `0` (or negative) uses as many threads as there are files.
 |      :param temp_dir: Directory under which the files will first be uploaded
 |        when `overwrite=True` and the final remote path already exists. Once the
 |        upload successfully completes, it will be swapped in.
 |      :param chunk_size: Interval in bytes by which the files will be uploaded.
 |      :param progress: Callback function to track progress, called every
 |        `chunk_size` bytes. It will be passed two arguments, the path to the
 |        file being uploaded and the number of bytes transferred so far. On
 |        completion, it will be called once with `-1` as second argument.
 |      :param cleanup: Delete any uploaded files if an error occurs during the
 |        upload.
 |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`write`. In
 |        particular, set `overwrite` to overwrite any existing file or directory.
 |      
 |      On success, this method returns the remote upload path.
 |  
 |  walk(self, hdfs_path, depth=0, status=False, ignore_missing=False, allow_dir_changes=False)
 |      Depth-first walk of remote filesystem.
 |      
 |      :param hdfs_path: Starting path. If the path doesn't exist, an
 |        :class:`HdfsError` will be raised. If it points to a file, the returned
 |        generator will be empty.
 |      :param depth: Maximum depth to explore. `0` for no limit.
 |      :param status: Also return each file or folder's corresponding FileStatus_.
 |      :param ignore_missing: Ignore missing nested folders rather than raise an
 |        exception. This can be useful when the tree is modified during a walk.
 |      :param allow_dir_changes: Allow changes to the directories' list to affect
 |        the walk. For example clearing it by setting `dirs[:] = []` would prevent
 |        the walk from entering any nested directories. This option can only be set
 |        when `status` is false.
 |      
 |      This method returns a generator yielding tuples `(path, dirs, files)`
 |      where `path` is the absolute path to the current directory, `dirs` is the
 |      list of directory names it contains, and `files` is the list of file names
 |      it contains.
 |  
 |  write(self, hdfs_path, data=None, overwrite=False, permission=None, blocksize=None, replication=None, buffersize=None, append=False, encoding=None)
 |      Create a file on HDFS.
 |      
 |      :param hdfs_path: Path where to create file. The necessary directories will
 |        be created appropriately.
 |      :param data: Contents of file to write. Can be a string, a generator or a
 |        file object. The last two options will allow streaming upload (i.e.
 |        without having to load the entire contents into memory). If `None`, this
 |        method will return a file-like object and should be called using a `with`
 |        block (see below for examples).
 |      :param overwrite: Overwrite any existing file or directory.
 |      :param permission: Octal permission to set on the newly created file.
 |        Leading zeros may be omitted.
 |      :param blocksize: Block size of the file.
 |      :param replication: Number of replications of the file.
 |      :param buffersize: Size of upload buffer.
 |      :param append: Append to a file rather than create a new one.
 |      :param encoding: Encoding used to serialize data written.
 |      
 |      Sample usages:
 |      
 |      .. code-block:: python
 |      
 |        from json import dump, dumps
 |      
 |        records = [
 |          {'name': 'foo', 'weight': 1},
 |          {'name': 'bar', 'weight': 2},
 |        ]
 |      
 |        # As a context manager:
 |        with client.write('data/records.jsonl', encoding='utf-8') as writer:
 |          dump(records, writer)
 |      
 |        # Or, passing in a generator directly:
 |        client.write('data/records.jsonl', data=dumps(records), encoding='utf-8')
 |  
 |  ----------------------------------------------------------------------
 |  Class methods inherited from hdfs.client.Client:
 |  
 |  from_options(options, class_name='Client') from hdfs.client._ClientType
 |      Load client from options.
 |      
 |      :param options: Options dictionary.
 |      :param class_name: Client class name. Defaults to the base :class:`Client`
 |        class.
 |      
 |      This method provides a single entry point to instantiate any registered
 |      :class:`Client` subclass. To register a subclass, simply load its
 |      containing module. If using the CLI, you can use the `autoload.modules` and
 |      `autoload.paths` options.
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from hdfs.client.Client:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes inherited from hdfs.client.Client:
 |  
 |  __registry__ = {'Client': <class 'hdfs.client.Client'>, 'Hdfs': <class...


==== HttpConfig ====
```

---

## Classe `HttpConfig` — módulo `bbmagic.http_config`

### Conteúdo

```text
class HttpConfig(bbmagic.file_config.FileConfig)
 |  HttpConfig(set_no_proxy: bool = True)
 |  
 |  Method resolution order:
 |      HttpConfig
 |      bbmagic.file_config.FileConfig
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self, set_no_proxy: bool = True)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  set_no_proxy(self) -> None
 |      Garante que a variável no_proxy está configurada para ignorar o domínio
 |      da API web da BBMagic
 |  
 |  ----------------------------------------------------------------------
 |  Static methods defined here:
 |  
 |  get_instance()
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from bbmagic.file_config.FileConfig:
 |  
 |  get(self, tag: str, key: str) -> str
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from bbmagic.file_config.FileConfig:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== Kinit ====
```

---

## Classe `Kinit` — módulo `bbmagic.kinit`

### Conteúdo

```text
class Kinit(builtins.object)
 |  Kinit(username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
 |  
 |  Autentica o usuário no Kerberos utilizando kinit.
 |  
 |  :param username: matrícula ou caminho para arquivo keytab
 |  :param conf_file: caminho para o arquivo krb5.conf. Caso não seja informado será
 |                      utilizada configuração do arquivo temporátio gerado pelo pacote
 |  :param hdp: Paramêtro deprecado, mantido para retrocompatibilidade de código apenas.
 |  
 |  Methods defined here:
 |  
 |  __init__(self, username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  get_ticket(self) -> str
 |      Autentica no Kerberos utilizando Kinit.
 |      
 |      Verifica se o usuário já possui um ticket kerberos válido. Caso não encontre
 |      realiza a autenticação com kinit. O parâmetro informado pode ser a matrícula
 |      do usuário ou uma keytab.
 |      
 |      Caso a matrícula seja informada, um prompt será exibido para que a senha SISBB
 |      seja informada.
 |      
 |      Caso o caminho para uma keytab seja informada, utiliza o arquivo. Caso seja informado
 |      o nome de uma keytab sem a extensão ".keytab" assume existe o arquivo "username.keytab"
 |      no diretório de execução do script.
 |      
 |      Retorna o nome do usuário utilizado na autenticação.
 |  
 |  get_username(self, username: Optional[str]) -> str
 |  
 |  is_matricula(self, string: str) -> bool
 |  
 |  raise_keytab_on_modelagem(self) -> None
 |  
 |  run_kinit_cmd(self, kinit_cmd: list, password: Optional[str]) -> int
 |  
 |  user_has_ticket(self) -> bool
 |      Verifica se há um ticket válido no cache de credenciais do Kerberos.
 |      
 |      Verifica as credenciais no cache padrão ou no caminho indicado na
 |      variável de ambiente KRB5CCNAME.
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  ambiente
 |  
 |  bypass_disallow_keytab
 |  
 |  encoding
 |  
 |  krb5_conf
 |  
 |  refuse_keytab
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  BACKOFF_LIMIT = 3600


==== MetaDataHive ====
```

---

## Classe `MetaDataHive` — módulo `bbmagic.sumary`

### Conteúdo

```text
class MetaDataHive(builtins.object)
 |  MetaDataHive() -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  get_token(self) -> Optional[str]
 |  
 |  get_url(self) -> Optional[str]
 |  
 |  status_db(self, db: str, list: Optional[bool] = False) -> Optional[pandas.core.frame.DataFrame]
 |  
 |  status_table(self, nome_db: Optional[str] = None, nome_tabela: Optional[str] = None) -> Optional[pandas.core.frame.DataFrame]
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== SAS ====
```

---

## Classe `SAS` — módulo `bbmagic.sas.sas`

### Conteúdo

```text
class SAS(builtins.object)
 |  SAS(username: str = '', host: str = 'sasanl03.intranet.bb.com.br', port: int = 8591, appserver: str = 'SASApp_ANL03 - Workspace Server', authkey: str = '', libnames: Optional[List[dict]] = None, timeout: int = 30) -> None
 |  
 |  Methods defined here:
 |  
 |  __init__(self, username: str = '', host: str = 'sasanl03.intranet.bb.com.br', port: int = 8591, appserver: str = 'SASApp_ANL03 - Workspace Server', authkey: str = '', libnames: Optional[List[dict]] = None, timeout: int = 30) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  config_authinfo(self, name: str = 'bbmagic') -> None
 |  
 |  create_libnames(self) -> None
 |  
 |  query(self, sql: str, chunksize: Optional[int] = 2500, verbose: bool = False) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== Spark ====
```

---

## Classe `Spark` — módulo `bbmagic.spark`

### Conteúdo

```text
class Spark(builtins.object)
 |  Spark(session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
 |  
 |  Cria uma sessão Spark.
 |  
 |  :param session_name: nome da sessão que será exibido na Web UI do Spark
 |  :param username: caminho para arquivo .keytab ou matrícula sem o dígito do usuário
 |  :param python: versão do Python da sessão Spark (2 ou 3)
 |  :param language: linguagem utilizada na sessão Spark ('python' ou 'scala')
 |  :param auth: modo de autenticação no Livy
 |  :param timeout: tempo máximo até que a sessão Spark seja criada
 |  :param db2: configura a sessão Spark para conexão JDBC ao DB2
 |  :param spark_conf: dicionário de parâmetros adicionais para configuração da sessão Spark.
 |                     Esse parâmetro tem prioridade sobre a padrão do BBMagic
 |  :param jars: lista de paths de arquivos .jar localizados no HDFS que serão utilizados na
 |               sessão. Ex: ['hdfs:///user/jars/database.jar']
 |  :param env: dicionário utilizado para definição de variáveis de ambiente na sessão Spark
 |  :param debug: exibe mais informações sobre a sessão Spark
 |  :param driver_memory: Quantidade de memória alocada para o driver da sessão Spark seguida
 |                        pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
 |                        (Ex.: '512m', '4g').
 |  :param driver_cores: Quantidade de cores alocados para o driver da sessão Spark
 |  :param num_executors: Quantidade de executores alocados para a sessão Spark.
 |  :param executor_memory: Quantidade de memória alocada cada executor da sessão Spark seguida
 |                          pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
 |                          (Ex.: '512m', '4g').
 |  :param executor_cores: Quantidade de cores alocados para cada executor da sessão Spark
 |  :param spark_version: Identifica a versao do Spark que ira receber a conexao - 2 ou 3
 |  
 |  Methods defined here:
 |  
 |  __del__(self) -> None
 |      Garante que a sessão Livy é encerrada assim que o Python finalize
 |  
 |  __init__(self, session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  close(self) -> None
 |      Encerra a sessão Spark
 |  
 |  config_db2(self) -> None
 |  
 |  config_jars(self) -> None
 |      Adiciona os jars para utilização de bibliotecas de machine learning distribuidas nas sessões spark 3
 |  
 |  config_sparkmagic(self) -> None
 |  
 |  config_virtualenv(self, virtualenv: Optional[str], overwrite: bool = False) -> Optional[str]
 |  
 |  connect(self) -> None
 |  
 |  enforce_dynamic_allocation(self, config: Optional[Dict[str, str]]) -> Optional[dict]
 |  
 |  get_from_spark(self, var_name: str)
 |      Importa o conteúdo de uma variável da sessão Spark para a sessão local.
 |      
 |      
 |      :param var_name: nome da variável que será importada.
 |      
 |      :return: Retorna o valor da variável
 |  
 |  send_to_spark(self, var) -> None
 |      Envia uma variável local para a sessão Spark.
 |      
 |      A variável será definida com mesmo nome na sessão Spark e o valor
 |      será transmitido utilizando pickle.
 |      
 |      :param var: variável que será enviada para a sessão Spark.
 |      
 |      :return: None
 |  
 |  ----------------------------------------------------------------------
 |  Class methods defined here:
 |  
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  ambiente
 |  
 |  bbmagic_session_id
 |  
 |  
 |  default_env
 |  
 |  force_dynammic_allocation
 |  
 |  livy_conn
 |  
 |  livy_session_id
 |  
 |  livy_url
 |  
 |  livy_version
 |  
 |  pickle_protocol
 |  
 |  spark_session_name
 |  
 |  spark_version
 |  
 |  user
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== TeamsNotify ====
```

---

## Classe `TeamsNotify` — módulo `bbmagic.teams_notify`

### Conteúdo

```text
class TeamsNotify(builtins.object)
 |  TeamsNotify(webhook: str)
 |  
 |  Methods defined here:
 |  
 |  __init__(self, webhook: str)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  error(self, title, text, model='', situation='', other_details='', color='E81123')
 |  
 |  info(self, title, text, model='', situation='', other_details='', color='008000')
 |  
 |  post_msg(self, title, text, model, situation, other_details, color=None)
 |  
 |  post_msg_workflows(self, title: str, text: str, model: str = '', situation: str = '', other_details: str = '', type: str = '') -> dict
 |      Função que envia mensagens por meio dos fluxos Workflows no Microsoft Teams
 |  
 |  warning(self, title, text, model='', situation='', other_details='', color='FFFF00')
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== checks ====
```

---

## Módulo `bbmagic.checks`

### NAME

`bbmagic.checks`

### FUNCTIONS

#### Função `check_configure_venv`

```text
    check_configure_venv(info)
```

#### Função `check_pre_run_cell`

```text
    check_pre_run_cell(info)
```

#### Função `check_saveastable`

```text
    check_saveastable(info)
        Emite um warning se o usuário estiver utilizando saveAsTable em uma sessão Spark
```

#### Função `register_checks`

```text
    register_checks(checks: dict) -> None
```

### DATA

```text
    spark_checks = {'pre_run_cell': <function check_pre_run_cell>}
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/checks.py



==== common ====
```

---

## Módulo `bbmagic.common`

### NAME

`bbmagic.common`

### CLASSES

#### Hierarquia

```text
    builtins.RuntimeWarning(builtins.Warning)
        BoasPraticasWarning
```

#### Classe `BoasPraticasWarning`

```text
    class BoasPraticasWarning(builtins.RuntimeWarning)
     |  Method resolution order:
     |      BoasPraticasWarning
     |      builtins.RuntimeWarning
     |      builtins.Warning
     |      builtins.Exception
     |      builtins.BaseException
     |      builtins.object
     |  
     |  Data descriptors defined here:
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.RuntimeWarning:
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from builtins.RuntimeWarning:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.BaseException:
     |  
     |  __delattr__(self, name, /)
     |      Implement delattr(self, name).
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __reduce__(...)
     |      Helper for pickle.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __setattr__(self, name, value, /)
     |      Implement setattr(self, name, value).
     |  
     |  __setstate__(...)
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  with_traceback(...)
     |      Exception.with_traceback(tb) --
     |      set self.__traceback__ to tb and return self.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from builtins.BaseException:
     |  
     |  __cause__
     |      exception cause
     |  
     |  __context__
     |      exception context
     |  
     |  __dict__
     |  
     |  __suppress_context__
     |  
     |  __traceback__
     |  
     |  args
```

### FUNCTIONS

#### Função `create_virtualenv`

```text
    create_virtualenv(requirements: Union[List[str], str] = None, path: Optional[str] = None, create_zip: bool = False, zip_path: str = '.', zip_name: str = 'virtualenv') -> virtualenvapi.manage.VirtualEnvironment
        Cria um virtualenv.
        
        requirements: Caminho para um arquivo texto contendo os requirements ou uma lista
        de pacotes para instalação.
        path: Caminho onde será criado o virtualenv. Quando o path for igual a None será
        o virtualenv será criado em um diretório temporário que será excluído ao fim da
        execução da função. Este comportamento é útil quando deseja-se apenas obter um
        arquivo .zip referente ao ambiente virtual.
        create_zip: Indica se deverá ser criado um arquivo .zip com o conteúdo do ambiente
        virtual criado.
        zip_path: Caminho onde deverá ser criado o arquivo .zip.
        zip_name: Nome do arquivo .zip sem a extensão.
```

#### Função `get_ambiente`

```text
    get_ambiente() -> str
```

#### Função `get_bbmagic_spark_version`

```text
    get_bbmagic_spark_version(default: Optional[int] = None) -> int
```

#### Função `get_cloud`

```text
    get_cloud() -> str
```

#### Função `get_environment`

```text
    get_environment() -> str
```

#### Função `get_project_id`

```text
    get_project_id(raise_not_found: bool = False) -> Optional[str]
        Retorna o id do projeto da Plataforma Analítica
```

### DATA

```text
    List = typing.List
        A generic version of list.
    
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
    
    Union = typing.Union
        Union type; Union[X, Y] means either X or Y.
        
        To define a union, use e.g. Union[int, str].  Details:
        - The arguments must be types and there must be at least one.
        - None as an argument is a special case and is replaced by
          type(None).
        - Unions of unions are flattened, e.g.::
        
            Union[Union[int, str], float] == Union[int, str, float]
        
        - Unions of a single argument vanish, e.g.::
        
            Union[int] == int  # The constructor actually returns int
        
        - Redundant arguments are skipped, e.g.::
        
            Union[int, str, int] == Union[int, str]
        
        - When comparing unions, the argument order is ignored, e.g.::
        
            Union[int, str] == Union[str, int]
        
        - You cannot subclass or instantiate a union.
        - You can use Optional[X] as a shorthand for Union[X, None].
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/common.py



==== db2 ====
```

---

## Módulo `bbmagic.db2`

### NAME

`bbmagic.db2`

### DESCRIPTION

```text
    Módulo para acesso aos dados no DB2
    -----------------------------------
```

### CLASSES

#### Hierarquia

```text
    builtins.object
        Db2
    builtins.tuple(builtins.object)
        DB2Server
```

#### Classe `DB2Server`

```text
    class DB2Server(builtins.tuple)
     |  DB2Server(host, port, database)
     |  
     |  DB2Server(host, port, database)
     |  
     |  Method resolution order:
     |      DB2Server
     |      builtins.tuple
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __getnewargs__(self)
     |      Return self as a plain tuple.  Used by copy and pickle.
     |  
     |  __repr__(self)
     |      Return a nicely formatted representation string
     |  
     |  _asdict(self)
     |      Return a new dict which maps field names to their values.
     |  
     |  _replace(self, /, **kwds)
     |      Return a new DB2Server object replacing specified fields with new values
     |  
     |  ----------------------------------------------------------------------
     |  Class methods defined here:
     |  
     |  _make(iterable) from builtins.type
     |      Make a new DB2Server object from a sequence or iterable
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  __new__(_cls, host, port, database)
     |      Create new instance of DB2Server(host, port, database)
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  host
     |      Alias for field number 0
     |  
     |  port
     |      Alias for field number 1
     |  
     |  database
     |      Alias for field number 2
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  _field_defaults = {}
     |  
     |  _fields = ('host', 'port', 'database')
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.tuple:
     |  
     |  __add__(self, value, /)
     |      Return self+value.
     |  
     |  __contains__(self, key, /)
     |      Return key in self.
     |  
     |  __eq__(self, value, /)
     |      Return self==value.
     |  
     |  __ge__(self, value, /)
     |      Return self>=value.
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __getitem__(self, key, /)
     |      Return self[key].
     |  
     |  __gt__(self, value, /)
     |      Return self>value.
     |  
     |  __hash__(self, /)
     |      Return hash(self).
     |  
     |  __iter__(self, /)
     |      Implement iter(self).
     |  
     |  __le__(self, value, /)
     |      Return self<=value.
     |  
     |  __len__(self, /)
     |      Return len(self).
     |  
     |  __lt__(self, value, /)
     |      Return self<value.
     |  
     |  __mul__(self, value, /)
     |      Return self*value.
     |  
     |  __ne__(self, value, /)
     |      Return self!=value.
     |  
     |  __rmul__(self, value, /)
     |      Return value*self.
     |  
     |  count(self, value, /)
     |      Return number of occurrences of value.
     |  
     |  index(self, value, start=0, stop=9223372036854775807, /)
     |      Return first index of value.
     |      
     |      Raises ValueError if the value is not present.
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from builtins.tuple:
     |  
     |  __class_getitem__(...) from builtins.type
     |      See PEP 585
```

#### Classe `Db2`

```text
    class Db2(builtins.object)
     |  Db2(user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
     |  
     |  Cria uma conexão ao DB2
     |  
     |  Methods defined here:
     |  
     |  __init__(self, user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  connect(self) -> ibm_db_dbi.Connection
     |      Cria a conexão JDBC com o servidor DB2.
     |  
     |  describe(self, schema: str, table: str) -> IPython.core.display.HTML
     |      Gera um relatório consolidado com os metadados da tabela existentes no catálogo
     |      do DB2.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um objeto HTML com o relatório para exibição no Jupyter Notebook.
     |      :rtype: IPython.core.display.HTML
     |  
     |  get_cofre_credentials(self, project_id: str) -> dict
     |      Recupera credenciais do cofre com base no project_id do projeto
     |  
     |  query(self, sql: str, params: Optional[list] = None, chunksize: Optional[int] = 2500) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
     |      Retorna um DataFrame contendo o resultado da execução da query SQL.
     |      
     |      :param sql: query SQL para execução
     |      :param params: lista de parâmetros para utilização na query
     |      :param chunksize: Se especificado, retorna um iterador onde chunksize é a quantidade
     |                        de linhas incluídas em cada chunk
     |      
     |      :return: Daframe ou Iterator[DataFrame]
     |      
     |      Exemplos de Uso::
     |      
     |          >>> for chunk in db2.query("SELECT * FROM db2mci.cliente LIMIT 10000"):
     |          ...     print(len(chunk))
     |          2500
     |          2500
     |          2500
     |          2500
     |      
     |      Sem utilização de chunks
     |      
     |          >>> df = db2.query("SELECT cod FROM db2mci.cliente LIMIT 100", chunksize=None)
     |  
     |  set_conn_param(self, param_name, param_value: Union[str, int, NoneType]) -> Union[str, int]
     |  
     |  show_schemas(self) -> pandas.core.frame.DataFrame
     |      Lista todos os schemas no database
     |      
     |      :return: Retorna um Pandas DataFrame contendo uma linha para cada schema encontrado.
     |      :rtype: pandas.core.api.DataFrame
     |      
     |      Exemplo de uso::
     |      
     |          >>> db2.show_schemas()
     |  
     |  show_tables(self, schema: str) -> pandas.core.frame.DataFrame
     |      Lista todas as tabelas e views de um schema.
     |      
     |      :param schema: nome do schema
     |      
     |      :return: Retorna um Pandas DataFrame contendo uma linha para cada tabela do schema
     |               e as informações *schema*, *name* e *type* nas respectivas colunas.
     |      :rtype: pandas.core.api.DataFrame
     |      
     |      Exemplo de uso::
     |      
     |          >>> db2.show_tables("DB2MCI")
     |  
     |  syscolumns(self, schema: str, table: str) -> pandas.core.frame.DataFrame
     |      Retorna metadados das colunas de uma tabela.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um Pandas DataFrame contendo as informações sobre as colunas da
     |               tabela de acordo com o catálogo syscat.syscolumns
     |      :rtype: pandas.core.api.DataFrame
     |  
     |  systabstats(self, schema: str, table: str) -> pandas.core.frame.DataFrame
     |      Retorna metadados de uma tabela.
     |      
     |      :param schema: nome do schema
     |      :param table: nome da tabela
     |      
     |      :return: Retorna um Pandas DataFrame contendo as informações sobre a tabela
     |               existentes no catálogo syscat.systabstats
     |      :rtype: pandas.core.api.DataFrame
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  url
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  envs = {'database': 'DB2_DATABASE', 'host': 'DB2_HOST', 'password': 'D...
     |  
     |  jars_path = '/projeto/libs/lib/python3.9/site-packages/bbmagic/jars/db...
```

### DATA

```text
    DB2_BACKOFF_LIMIT = 3600
    Iterator = typing.Iterator
        A generic version of collections.abc.Iterator.
    
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
    
    Union = typing.Union
        Union type; Union[X, Y] means either X or Y.
        
        To define a union, use e.g. Union[int, str].  Details:
        - The arguments must be types and there must be at least one.
        - None as an argument is a special case and is replaced by
          type(None).
        - Unions of unions are flattened, e.g.::
        
            Union[Union[int, str], float] == Union[int, str, float]
        
        - Unions of a single argument vanish, e.g.::
        
            Union[int] == int  # The constructor actually returns int
        
        - Redundant arguments are skipped, e.g.::
        
            Union[int, str, int] == Union[int, str]
        
        - When comparing unions, the argument order is ignored, e.g.::
        
            Union[int, str] == Union[str, int]
        
        - You cannot subclass or instantiate a union.
        - You can use Optional[X] as a shorthand for Union[X, None].
    
    db2_desenv = DB2Server(host='dsdb2d01.plexdes.bb.com.br', port=446, da...
    db2_homologa = DB2Server(host='bdb2h01.plexhom.bb.com.br', port=446, d...
    db2_prod = DB2Server(host='gwdb2.bb.com.br', port=50100, database='BDB...
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/db2.py



==== environment ====
```

---

## Módulo `bbmagic.environment`

### NAME

`bbmagic.environment`

### CLASSES

#### Hierarquia

```text
    builtins.object
        Environment
```

#### Classe `Environment`

```text
    class Environment(builtins.object)
     |  Methods defined here:
     |  
     |  get(self) -> str
     |  
     |  is_modeling(self) -> bool
     |  
     |  is_prodution(self) -> bool
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/environment.py



==== exceptions ====
```

---

## Módulo `bbmagic.exceptions`

### NAME

`bbmagic.exceptions`

### CLASSES

#### Hierarquia

```text
    builtins.Exception(builtins.BaseException)
        KinitError
        PublicadorError
```

#### Classe `KinitError`

```text
    class KinitError(builtins.Exception)
     |  Erro exibido quando há falha na autenticação com o kinit
     |  
     |  Method resolution order:
     |      KinitError
     |      builtins.Exception
     |      builtins.BaseException
     |      builtins.object
     |  
     |  Data descriptors defined here:
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.Exception:
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from builtins.Exception:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.BaseException:
     |  
     |  __delattr__(self, name, /)
     |      Implement delattr(self, name).
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __reduce__(...)
     |      Helper for pickle.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __setattr__(self, name, value, /)
     |      Implement setattr(self, name, value).
     |  
     |  __setstate__(...)
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  with_traceback(...)
     |      Exception.with_traceback(tb) --
     |      set self.__traceback__ to tb and return self.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from builtins.BaseException:
     |  
     |  __cause__
     |      exception cause
     |  
     |  __context__
     |      exception context
     |  
     |  __dict__
     |  
     |  __suppress_context__
     |  
     |  __traceback__
     |  
     |  args
```

#### Classe `PublicadorError`

```text
    class PublicadorError(builtins.Exception)
     |  Erro exibido quando há falha ao salvar um modelo no Artifactory
     |  
     |  Method resolution order:
     |      PublicadorError
     |      builtins.Exception
     |      builtins.BaseException
     |      builtins.object
     |  
     |  Data descriptors defined here:
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.Exception:
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from builtins.Exception:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.BaseException:
     |  
     |  __delattr__(self, name, /)
     |      Implement delattr(self, name).
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __reduce__(...)
     |      Helper for pickle.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __setattr__(self, name, value, /)
     |      Implement setattr(self, name, value).
     |  
     |  __setstate__(...)
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  with_traceback(...)
     |      Exception.with_traceback(tb) --
     |      set self.__traceback__ to tb and return self.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from builtins.BaseException:
     |  
     |  __cause__
     |      exception cause
     |  
     |  __context__
     |      exception context
     |  
     |  __dict__
     |  
     |  __suppress_context__
     |  
     |  __traceback__
     |  
     |  args
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/exceptions.py



==== file_config ====
```

---

## Módulo `bbmagic.file_config`

### NAME

`bbmagic.file_config`

### CLASSES

#### Hierarquia

```text
    builtins.object
        FileConfig
```

#### Classe `FileConfig`

```text
    class FileConfig(builtins.object)
     |  FileConfig(path) -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self, path) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    BBMAGIC_VERSION = '3.1.4'
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/file_config.py



==== get_ambiente ====
```

---

## Função `get_ambiente` — módulo `bbmagic.common`

### Conteúdo

```text
get_ambiente() -> str


==== gitlab_config ====
```

---

## Módulo `bbmagic.gitlab_config`

### NAME

`bbmagic.gitlab_config`

### CLASSES

#### Hierarquia

```text
    bbmagic.file_config.FileConfig(builtins.object)
        GitLabConfig
```

#### Classe `GitLabConfig`

```text
    class GitLabConfig(bbmagic.file_config.FileConfig)
     |  Method resolution order:
     |      GitLabConfig
     |      bbmagic.file_config.FileConfig
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from bbmagic.file_config.FileConfig:
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from bbmagic.file_config.FileConfig:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    BBMAGIC_VERSION = '3.1.4'
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/gitlab_config.py



==== hdfs ====
```

---

## Módulo `bbmagic.hdfs`

### NAME

`bbmagic.hdfs`

### DESCRIPTION

```text
    Implementa funcionalidades de leitura e escrita no HDFS utiliando a API
    WebHDFS_. Caso exista, o valor contido na variável de ambiente BBMAGIC_HDFS_URL
    será utilizado para a conexão.
    
    A classe Hdfs é um wrapper criado sobre o pacote HdfsCli_, para facilitar
    
    .. _WebHDFS: http://hadoop.apache.org/docs/current/hadoop-project-dist/hadoop-hdfs/WebHDFS.html
    .. _HdfsCli: https://hdfscli.readthedocs.io/en/latest/index.html
    __ HdfsCli_
    
    Conectando-se ao HDFS
    ---------------------
    
    .. code-block:: python
    
       from bbmagic import Hdfs
    
       hdfs = Hdfs("F9999999")
    
    Lendo e escrevendo arquivos
    ---------------------------
    
    Lendo arquivos no HDFS
    ======================
    
    O método `read()` implementa a funcionalidade para leiutura de arquivos do HDFS. Deve ser utilizado
    em um bloco `with` para garantir que a conexão e transferência seja encerrada corretamente. Para
    baixar um arquivo diretamento para o disco deve-se utilizar o método `download()`
    
    .. code-block:: python
    
       from bbmagic import Hdfs
    
       hdfs = Hdfs('test.keytab')
    
       # carregando um arquivo em memória
       hdfs_file = 'dataset.csv'
       with hdfs.read(hdfs_file) as reader:
           dados = reader.read()
    
    Se o argumento chunksize for informado, o método retornará um iterador tornando possível trabalhar
    com arquivos de tamanho superior à memória disponível na máquina.
    
    .. code-block:: python
    
       # lendo um arquivo em chunks
       with hdfs.read('features', chunk_size=8096) as reader:
           for chunk in reader:
               pass
    
    Da mesma forma, se o argumento `delimiter` for informado o método retornará um iterador com chunks
    gerados a cada seperador encontrado no arquivo.
    
    .. code-block:: python
    
       # lendo um arquivo csv linha a linha
       with hdfs.read('dataset.csv', encoding='utf-8', delimiter='\n') as reader:
           for line in reader:
               pass
    
    Baixando um arquivo diretamento para o disco local:
    
    .. code-block:: python
    
        hdfs.download('arquivo-hdfs.csv', 'arquivo-local.csv')
    
    
    Escrevendo arquivos no HDFS
    ===========================
    
    Para escrever arquivos no HDFS utiliza-se o método `write` para dados em memória ou
    `upload` para enviar um arquivo existente no disco.
    
    .. code-block:: python
    
       # escrevendo partes de um arquivo local no HDFS
       with open('arquivolocal.txt') as reader, hdfs.write('datasetfinal.txt') as writer:
           for line in reader:
               if line.startswith('-'):
                   writer.write(line)
    
    De forma mais suscinta, pode-se passar um iterador para o método `write`:
    
    .. code-block:: python
    
        from json import dumps
    
        hdfs.write('/dados/dominio/modelo.json', dumps(modelo))
    
    
    Para fazer o upload de um arquivo existente no diso:
    
    .. code-block:: python
    
        destino_hdfs = 'dados/meuprojeto/dataset.csv'
        origem_arquivo = 'output/dataset.csv'
    
        # envia o arquivo dataset.csv sobresrevendo os dados no HDFS caso já existam
        hdfs.upload(destino_hdfs, origem_aquivo, overwrite=True)
    
    
    Explorando o sistema de arquivos do HDFS
    ----------------------------------------
    
    .. code-block:: python
    
        # Obtendo informações sobre o conteúdo de um arquivo ou diretório.
        content = hdfs.content('meusdados')
    
        # Listando todos arquivos em um diretório
        fnames = hdfs.list('meusdados')
    
        # Obtendo informações sobre o status de um arquivo ou diretório
        status = hdfs.status('meusdados/features.csv')
    
        # Renomeando ('movendo') um arquivo.
        hdfs.rename('meusdados/features.csv', 'features-amostra.csv')
    
        # Deletando um arquivo ou pastas
        hdfs.delete('meusdados', recursive=True)
    
    |
```

### CLASSES

#### Hierarquia

```text
    hdfs.ext.kerberos.KerberosClient(hdfs.client.Client)
        Hdfs
```

#### Classe `Hdfs`

```text
    class Hdfs(hdfs.ext.kerberos.KerberosClient)
     |  Hdfs(username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
     |  
     |  Permite acesso ao HDFS com autenticação via kerberos.
     |  
     |  :param username: matrícula ou caminho para arquivo keytab
     |  :param \*\*kwargs: Argumentos adicionais passados para a classe HTTPKerberosAuth.
     |  
     |  Method resolution order:
     |      Hdfs
     |      hdfs.ext.kerberos.KerberosClient
     |      hdfs.client.Client
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  set_no_proxy(self) -> None
     |      Garante que a variável no_proxy está configurada para ignorar o domínio
     |      da API web da BBMagic
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from hdfs.client.Client:
     |  
     |  __repr__(self)
     |      Return repr(self).
     |  
     |  acl_status(self, hdfs_path, strict=True)
     |      Get AclStatus_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _AclStatus: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Get_ACL_Status
     |  
     |  allow_snapshot(self, hdfs_path)
     |      Allow snapshots for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist or does points to a normal file, an
     |        :class:`HdfsError` will be raised.  No-op if snapshotting is
     |        already allowed.
     |  
     |  checksum(self, hdfs_path)
     |      Get a remote file's checksum.
     |      
     |      :param hdfs_path: Remote path. Must point to a file.
     |  
     |  content(self, hdfs_path, strict=True)
     |      Get ContentSummary_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _ContentSummary: CS_
     |      .. _CS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#ContentSummary
     |  
     |  create_snapshot(self, hdfs_path, snapshotname=None)
     |      Create snapshot for a remote folder where it was allowed.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist, doesn't allow to create snapshot or points to a
     |        normal file, an :class:`HdfsError` will be raised.
     |      :param snapshotname snapshot name; if absent, name is generated
     |        by the server.
     |      
     |      Returns a path to created snapshot.
     |  
     |  delete(self, hdfs_path, recursive=False, skip_trash=True)
     |      Remove a file or directory from HDFS.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param recursive: Recursively delete files and directories. By default,
     |        this method will raise an :class:`HdfsError` if trying to delete a
     |        non-empty directory.
     |      :param skip_trash: When false, the deleted path will be moved to an
     |        appropriate trash folder rather than deleted. This requires Hadoop 2.9+
     |      
     |      This function returns `True` if the deletion was successful and `False` if
     |      no file or directory previously existed at `hdfs_path`.
     |  
     |  delete_snapshot(self, hdfs_path, snapshotname)
     |      Remove snapshot for a remote folder where it was allowed.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param snapshotname snapshot name; if it does not exist, an
     |        :class:`HdfsError` will be raised.
     |  
     |  disallow_snapshot(self, hdfs_path)
     |      Disallow snapshots for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
     |        doesn't exist, points to a normal file or there are some
     |        snapshots, an :class:`HdfsError` will be raised.
     |      
     |      No-op if snapshotting is disallowed/never allowed.
     |  
     |  download(self, hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs)
     |      Download a file or folder from HDFS and save it locally.
     |      
     |      :param hdfs_path: Path on HDFS of the file or folder to download. If a
     |        folder, all the files under it will be downloaded.
     |      :param local_path: Local path. If it already exists and is a directory,
     |        the files will be downloaded inside of it.
     |      :param overwrite: Overwrite any existing file or directory.
     |      :param n_threads: Number of threads to use for parallelization. A value of
     |        `0` (or negative) uses as many threads as there are files.
     |      :param temp_dir: Directory under which the files will first be downloaded
     |        when `overwrite=True` and the final destination path already exists. Once
     |        the download successfully completes, it will be swapped in.
     |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`read`. If no
     |        `chunk_size` argument is passed, a default value of 64 kB will be used.
     |        If a `progress` argument is passed and threading is used, care must be
     |        taken to ensure correct behavior.
     |      
     |      On success, this method returns the local download path.
     |  
     |  list(self, hdfs_path, status=False)
     |      Return names of files contained in a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory. If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param status: Also return each file's corresponding FileStatus_.
     |  
     |  makedirs(self, hdfs_path, permission=None)
     |      Create a remote directory, recursively if necessary.
     |      
     |      :param hdfs_path: Remote path. Intermediate directories will be created
     |        appropriately.
     |      :param permission: Octal permission to set on the newly created directory.
     |        These permissions will only be set on directories that do not already
     |        exist.
     |      
     |      This function currently has no return value as WebHDFS doesn't return a
     |      meaningful flag.
     |  
     |  parts(self, hdfs_path, parts=None, status=False)
     |      Returns a dictionary of part-files corresponding to a path.
     |      
     |      :param hdfs_path: Remote path. This directory should contain at most one
     |        part file per partition (otherwise one will be picked arbitrarily).
     |      :param parts: List of part-files numbers or total number of part-files to
     |        select. If a number, that many partitions will be chosen at random. By
     |        default all part-files are returned. If `parts` is a list and one of the
     |        parts is not found or too many samples are demanded, an
     |        :class:`~hdfs.util.HdfsError` is raised.
     |      :param status: Also return each file's corresponding FileStatus_.
     |  
     |  read(self, hdfs_path, offset=0, length=None, buffer_size=None, encoding=None, chunk_size=0, delimiter=None, progress=None)
     |      Read a file from HDFS.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param offset: Starting byte position.
     |      :param length: Number of bytes to be processed. `None` will read the entire
     |        file.
     |      :param buffer_size: Size of the buffer in bytes used for transferring the
     |        data. Defaults the the value set in the HDFS configuration.
     |      :param encoding: Encoding used to decode the request. By default the raw
     |        data is returned. This is mostly helpful in python 3, for example to
     |        deserialize JSON data (as the decoder expects unicode).
     |      :param chunk_size: If set to a positive number, the context manager will
     |        return a generator yielding every `chunk_size` bytes instead of a
     |        file-like object (unless `delimiter` is also set, see below).
     |      :param delimiter: If set, the context manager will return a generator
     |        yielding each time the delimiter is encountered. This parameter requires
     |        the `encoding` to be specified.
     |      :param progress: Callback function to track progress, called every
     |        `chunk_size` bytes (not available if the chunk size isn't specified). It
     |        will be passed two arguments, the path to the file being uploaded and the
     |        number of bytes transferred so far. On completion, it will be called once
     |        with `-1` as second argument.
     |      
     |      This method must be called using a `with` block:
     |      
     |      .. code-block:: python
     |      
     |        with client.read('foo') as reader:
     |          content = reader.read()
     |      
     |      This ensures that connections are always properly closed.
     |      
     |      .. note::
     |      
     |        The raw file-like object returned by this method (when called without an
     |        encoding, chunk size, or delimiter) can have a very different performance
     |        profile than local files. In particular, line-oriented methods are often
     |        slower. The recommended workaround is to specify an encoding when
     |        possible or read the entire file before splitting it.
     |  
     |  remove_acl(self, hdfs_path)
     |      RemoveAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      
     |      .. _RemoveAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL
     |  
     |  remove_acl_entries(self, hdfs_path, acl_spec)
     |      RemoveAclEntries_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      :param acl_spec: String representation of an ACL spec. Must be a valid
     |        string with entries for user, group and other. For example:
     |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
     |      
     |      .. _RemoveAclEntries: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL_Entries
     |  
     |  remove_default_acl(self, hdfs_path)
     |      RemoveDefaultAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      
     |      .. _RemoveDefaultAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_Default_ACL
     |  
     |  rename(self, hdfs_src_path, hdfs_dst_path)
     |      Move a file or folder.
     |      
     |      :param hdfs_src_path: Source path.
     |      :param hdfs_dst_path: Destination path. If the path already exists and is
     |        a directory, the source will be moved into it. If the path exists and is
     |        a file, or if a parent destination directory is missing, this method will
     |        raise an :class:`HdfsError`.
     |  
     |  rename_snapshot(self, hdfs_path, oldsnapshotname, snapshotname)
     |      Rename snapshot for a remote folder.
     |      
     |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
     |        or points to a normal file, an :class:`HdfsError` will be raised.
     |      :param oldsnapshotname snapshot name; if it does not exist,
     |        an :class:`HdfsError` will be raised.
     |      :param snapshotname new snapshot name; if it does already exist,
     |        an :class:`HdfsError` will be raised.
     |  
     |  resolve(self, hdfs_path)
     |      Return absolute, normalized path, with special markers expanded.
     |      
     |      :param hdfs_path: Remote path.
     |      
     |      Currently supported markers:
     |      
     |      * `'#LATEST'`: this marker gets expanded to the most recently updated file
     |        or folder. They can be combined using the `'{N}'` suffix. For example,
     |        `'foo/#LATEST{2}'` is equivalent to `'foo/#LATEST/#LATEST'`.
     |  
     |  set_acl(self, hdfs_path, acl_spec, clear=True)
     |      SetAcl_ or ModifyAcl_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Path to an existing remote file or directory. An
     |        :class:`HdfsError` will be raised if the path doesn't exist.
     |      :param acl_spec: String representation of an ACL spec. Must be a valid
     |        string with entries for user, group and other. For example:
     |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
     |      :param clear: Clear existing ACL entries. If set to false, all existing ACL
     |        entries that are not specified in this call are retained without changes,
     |        behaving like ModifyAcl_. For example: `"user:foo:rwx"`.
     |      
     |      .. _SetAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Set_ACL
     |      .. _ModifyAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Modify_ACL_Entries
     |  
     |  set_owner(self, hdfs_path, owner=None, group=None)
     |      Change the owner of file.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param owner: Optional, new owner for file.
     |      :param group: Optional, new group for file.
     |      
     |      At least one of `owner` and `group` must be specified.
     |  
     |  set_permission(self, hdfs_path, permission)
     |      Change the permissions of file.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param permission: New octal permissions string of file.
     |  
     |  set_replication(self, hdfs_path, replication)
     |      Set file replication.
     |      
     |      :param hdfs_path: Path to an existing remote file. An :class:`HdfsError`
     |        will be raised if the path doesn't exist or points to a directory.
     |      :param replication: Replication factor.
     |  
     |  set_times(self, hdfs_path, access_time=None, modification_time=None)
     |      Change remote timestamps.
     |      
     |      :param hdfs_path: HDFS path.
     |      :param access_time: Timestamp of last file access.
     |      :param modification_time: Timestamps of last file access.
     |  
     |  status(self, hdfs_path, strict=True)
     |      Get FileStatus_ for a file or folder on HDFS.
     |      
     |      :param hdfs_path: Remote path.
     |      :param strict: If `False`, return `None` rather than raise an exception if
     |        the path doesn't exist.
     |      
     |      .. _FileStatus: FS_
     |      .. _FS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#FileStatus
     |  
     |  upload(self, hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs)
     |      Upload a file or directory to HDFS.
     |      
     |      :param hdfs_path: Target HDFS path. If it already exists and is a
     |        directory, files will be uploaded inside.
     |      :param local_path: Local path to file or folder. If a folder, all the files
     |        inside of it will be uploaded (note that this implies that folders empty
     |        of files will not be created remotely).
     |      :param n_threads: Number of threads to use for parallelization. A value of
     |        `0` (or negative) uses as many threads as there are files.
     |      :param temp_dir: Directory under which the files will first be uploaded
     |        when `overwrite=True` and the final remote path already exists. Once the
     |        upload successfully completes, it will be swapped in.
     |      :param chunk_size: Interval in bytes by which the files will be uploaded.
     |      :param progress: Callback function to track progress, called every
     |        `chunk_size` bytes. It will be passed two arguments, the path to the
     |        file being uploaded and the number of bytes transferred so far. On
     |        completion, it will be called once with `-1` as second argument.
     |      :param cleanup: Delete any uploaded files if an error occurs during the
     |        upload.
     |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`write`. In
     |        particular, set `overwrite` to overwrite any existing file or directory.
     |      
     |      On success, this method returns the remote upload path.
     |  
     |  walk(self, hdfs_path, depth=0, status=False, ignore_missing=False, allow_dir_changes=False)
     |      Depth-first walk of remote filesystem.
     |      
     |      :param hdfs_path: Starting path. If the path doesn't exist, an
     |        :class:`HdfsError` will be raised. If it points to a file, the returned
     |        generator will be empty.
     |      :param depth: Maximum depth to explore. `0` for no limit.
     |      :param status: Also return each file or folder's corresponding FileStatus_.
     |      :param ignore_missing: Ignore missing nested folders rather than raise an
     |        exception. This can be useful when the tree is modified during a walk.
     |      :param allow_dir_changes: Allow changes to the directories' list to affect
     |        the walk. For example clearing it by setting `dirs[:] = []` would prevent
     |        the walk from entering any nested directories. This option can only be set
     |        when `status` is false.
     |      
     |      This method returns a generator yielding tuples `(path, dirs, files)`
     |      where `path` is the absolute path to the current directory, `dirs` is the
     |      list of directory names it contains, and `files` is the list of file names
     |      it contains.
     |  
     |  write(self, hdfs_path, data=None, overwrite=False, permission=None, blocksize=None, replication=None, buffersize=None, append=False, encoding=None)
     |      Create a file on HDFS.
     |      
     |      :param hdfs_path: Path where to create file. The necessary directories will
     |        be created appropriately.
     |      :param data: Contents of file to write. Can be a string, a generator or a
     |        file object. The last two options will allow streaming upload (i.e.
     |        without having to load the entire contents into memory). If `None`, this
     |        method will return a file-like object and should be called using a `with`
     |        block (see below for examples).
     |      :param overwrite: Overwrite any existing file or directory.
     |      :param permission: Octal permission to set on the newly created file.
     |        Leading zeros may be omitted.
     |      :param blocksize: Block size of the file.
     |      :param replication: Number of replications of the file.
     |      :param buffersize: Size of upload buffer.
     |      :param append: Append to a file rather than create a new one.
     |      :param encoding: Encoding used to serialize data written.
     |      
     |      Sample usages:
     |      
     |      .. code-block:: python
     |      
     |        from json import dump, dumps
     |      
     |        records = [
     |          {'name': 'foo', 'weight': 1},
     |          {'name': 'bar', 'weight': 2},
     |        ]
     |      
     |        # As a context manager:
     |        with client.write('data/records.jsonl', encoding='utf-8') as writer:
     |          dump(records, writer)
     |      
     |        # Or, passing in a generator directly:
     |        client.write('data/records.jsonl', data=dumps(records), encoding='utf-8')
     |  
     |  ----------------------------------------------------------------------
     |  Class methods inherited from hdfs.client.Client:
     |  
     |  from_options(options, class_name='Client') from hdfs.client._ClientType
     |      Load client from options.
     |      
     |      :param options: Options dictionary.
     |      :param class_name: Client class name. Defaults to the base :class:`Client`
     |        class.
     |      
     |      This method provides a single entry point to instantiate any registered
     |      :class:`Client` subclass. To register a subclass, simply load its
     |      containing module. If using the CLI, you can use the `autoload.modules` and
     |      `autoload.paths` options.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from hdfs.client.Client:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes inherited from hdfs.client.Client:
     |  
     |  __registry__ = {'Client': <class 'hdfs.client.Client'>, 'Hdfs': <class...
```

### DATA

```text
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/hdfs.py



==== http_config ====
```

---

## Módulo `bbmagic.http_config`

### NAME

`bbmagic.http_config`

### CLASSES

#### Hierarquia

```text
    bbmagic.file_config.FileConfig(builtins.object)
        HttpConfig
```

#### Classe `HttpConfig`

```text
    class HttpConfig(bbmagic.file_config.FileConfig)
     |  HttpConfig(set_no_proxy: bool = True)
     |  
     |  Method resolution order:
     |      HttpConfig
     |      bbmagic.file_config.FileConfig
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, set_no_proxy: bool = True)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  set_no_proxy(self) -> None
     |      Garante que a variável no_proxy está configurada para ignorar o domínio
     |      da API web da BBMagic
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  get_instance()
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from bbmagic.file_config.FileConfig:
     |  
     |  get(self, tag: str, key: str) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from bbmagic.file_config.FileConfig:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    BBMAGIC_VERSION = '3.1.4'
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/http_config.py



==== kinit ====
```

---

## Módulo `bbmagic.kinit`

### NAME

`bbmagic.kinit`

### DESCRIPTION

```text
    Módulo responsável pela autenticação Kerberos para utilização com as ferramentas
    de Big Data.
    
    Toda os parâmetros necessários para configuração da conexão com o Kerberos estão contidos
    nos arquivos .conf na pasta krb5 deste pacote. O arquivos são utilizados para parametrizar
    a variável de ambiente KRB5_CONFIG.
    
    Caso exista a variável de ambiente BBMAGIC_KRB5_CONFIG o conteúdo será utilizado para a
    configuração de um arquivo .conf que na pasta krb5 deste pacote que será utilizado no proceso
    de autenticação.
    
    A existência da variável de ambiente BBMAGIC_ALLOW_KEYTAB permitirá que o usuário se autentique
    utilizando um arquivo de keytab no ambiente de modelagem. Esse comportamento é desabilitado por
    padrão para permitir o melhor gerenciamento dos recursos do Big Data no nível da chave do
    usuário.
    
    Para a realizar a autenticação é realizada uma chamada da aplicação de linha de
    comando `kinit` utilizando um subprocesso.
    
    |
```

### CLASSES

#### Hierarquia

```text
    builtins.object
        Kinit
```

#### Classe `Kinit`

```text
    class Kinit(builtins.object)
     |  Kinit(username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
     |  
     |  Autentica o usuário no Kerberos utilizando kinit.
     |  
     |  :param username: matrícula ou caminho para arquivo keytab
     |  :param conf_file: caminho para o arquivo krb5.conf. Caso não seja informado será
     |                      utilizada configuração do arquivo temporátio gerado pelo pacote
     |  :param hdp: Paramêtro deprecado, mantido para retrocompatibilidade de código apenas.
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: Optional[str] = None, conf_file: Optional[str] = None, backoff_limit: int = 3600) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get_ticket(self) -> str
     |      Autentica no Kerberos utilizando Kinit.
     |      
     |      Verifica se o usuário já possui um ticket kerberos válido. Caso não encontre
     |      realiza a autenticação com kinit. O parâmetro informado pode ser a matrícula
     |      do usuário ou uma keytab.
     |      
     |      Caso a matrícula seja informada, um prompt será exibido para que a senha SISBB
     |      seja informada.
     |      
     |      Caso o caminho para uma keytab seja informada, utiliza o arquivo. Caso seja informado
     |      o nome de uma keytab sem a extensão ".keytab" assume existe o arquivo "username.keytab"
     |      no diretório de execução do script.
     |      
     |      Retorna o nome do usuário utilizado na autenticação.
     |  
     |  get_username(self, username: Optional[str]) -> str
     |  
     |  is_matricula(self, string: str) -> bool
     |  
     |  raise_keytab_on_modelagem(self) -> None
     |  
     |  run_kinit_cmd(self, kinit_cmd: list, password: Optional[str]) -> int
     |  
     |  user_has_ticket(self) -> bool
     |      Verifica se há um ticket válido no cache de credenciais do Kerberos.
     |      
     |      Verifica as credenciais no cache padrão ou no caminho indicado na
     |      variável de ambiente KRB5CCNAME.
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  ambiente
     |  
     |  bypass_disallow_keytab
     |  
     |  encoding
     |  
     |  krb5_conf
     |  
     |  refuse_keytab
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  BACKOFF_LIMIT = 3600
```

### DATA

```text
    ENV_KRB5_CONF = '/projeto/libs/lib/python3.9/site-packages/bbmagic/krb...
    HDP31_KRB5_CONF = '/projeto/libs/lib/python3.9/site-packages/bbmagic/k...
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/kinit.py



==== livyapi ====
```

---

## Módulo `bbmagic.livyapi`

### NAME

`bbmagic.livyapi`

### CLASSES

#### Hierarquia

```text
    livy.client.LivyClient(builtins.object)
        LivyApi
```

#### Classe `LivyApi`

```text
    class LivyApi(livy.client.LivyClient)
     |  LivyApi(username: str, spark_version: int = 3, config: Optional[bbmagic.file_config.FileConfig] = None, python: int = None) -> None
     |  
     |  Method resolution order:
     |      LivyApi
     |      livy.client.LivyClient
     |      builtins.object
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: str, spark_version: int = 3, config: Optional[bbmagic.file_config.FileConfig] = None, python: int = None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from livy.client.LivyClient:
     |  
     |  close(self) -> None
     |      Close the underlying requests session, if managed by this class.
     |  
     |  create_batch(self, file: str, class_name: str = None, args: List[str] = None, proxy_user: str = None, jars: List[str] = None, py_files: List[str] = None, files: List[str] = None, driver_memory: str = None, driver_cores: int = None, executor_memory: str = None, executor_cores: int = None, num_executors: int = None, archives: List[str] = None, queue: str = None, name: str = None, spark_conf: Dict[str, Any] = None) -> livy.models.Batch
     |      Create a new batch in Livy.
     |      
     |      The py_files, files, jars and archives arguments are lists of URLs,
     |      e.g. ["s3://bucket/object", "hdfs://path/to/file", ...] and must be
     |      reachable by the Spark driver process.  If the provided URL has no
     |      scheme, it's considered to be relative to the default file system
     |      configured in the Livy server.
     |      
     |      URLs in the py_files argument are copied to a temporary staging area
     |      and inserted into Python's sys.path ahead of the standard library
     |      paths.  This allows you to import .py, .zip and .egg files in Python.
     |      
     |      URLs for jars, py_files, files and archives arguments are all copied
     |      
     |      The driver_memory and executor_memory arguments have the same format
     |      as JVM memory strings with a size unit suffix ("k", "m", "g" or "t")
     |      (e.g. 512m, 2g).
     |      
     |      See https://spark.apache.org/docs/latest/configuration.html for more
     |      information on Spark configuration properties.
     |      
     |      :param file: File containing the application to execute.
     |      :param class_name: Application Java/Spark main class.
     |      :param args: An array of strings to be passed to the Spark app.
     |      :param proxy_user: User to impersonate when starting the session.
     |      :param jars: URLs of jars to be used in this session.
     |      :param py_files: URLs of Python files to be used in this session.
     |      :param files: URLs of files to be used in this session.
     |      :param driver_memory: Amount of memory to use for the driver process
     |          (e.g. '512m').
     |      :param driver_cores: Number of cores to use for the driver process.
     |      :param executor_memory: Amount of memory to use per executor process
     |          (e.g. '512m').
     |      :param executor_cores: Number of cores to use for each executor.
     |      :param num_executors: Number of executors to launch for this session.
     |      :param archives: URLs of archives to be used in this session.
     |      :param queue: The name of the YARN queue to which submitted.
     |      :param name: The name of this session.
     |      :param spark_conf: Spark configuration properties.
     |  
     |  create_session(self, kind: livy.models.SessionKind, proxy_user: str = None, jars: List[str] = None, py_files: List[str] = None, files: List[str] = None, driver_memory: str = None, driver_cores: int = None, executor_memory: str = None, executor_cores: int = None, num_executors: int = None, archives: List[str] = None, queue: str = None, name: str = None, spark_conf: Dict[str, Any] = None, heartbeat_timeout: int = None) -> livy.models.Session
     |      Create a new session in Livy.
     |      
     |      The py_files, files, jars and archives arguments are lists of URLs,
     |      e.g. ["s3://bucket/object", "hdfs://path/to/file", ...] and must be
     |      reachable by the Spark driver process.  If the provided URL has no
     |      scheme, it's considered to be relative to the default file system
     |      configured in the Livy server.
     |      
     |      URLs in the py_files argument are copied to a temporary staging area
     |      and inserted into Python's sys.path ahead of the standard library
     |      paths.  This allows you to import .py, .zip and .egg files in Python.
     |      
     |      URLs for jars, py_files, files and archives arguments are all copied
     |      
     |      The driver_memory and executor_memory arguments have the same format
     |      as JVM memory strings with a size unit suffix ("k", "m", "g" or "t")
     |      (e.g. 512m, 2g).
     |      
     |      See https://spark.apache.org/docs/latest/configuration.html for more
     |      information on Spark configuration properties.
     |      
     |      :param kind: The kind of session to create.
     |      :param proxy_user: User to impersonate when starting the session.
     |      :param jars: URLs of jars to be used in this session.
     |      :param py_files: URLs of Python files to be used in this session.
     |      :param files: URLs of files to be used in this session.
     |      :param driver_memory: Amount of memory to use for the driver process
     |          (e.g. '512m').
     |      :param driver_cores: Number of cores to use for the driver process.
     |      :param executor_memory: Amount of memory to use per executor process
     |          (e.g. '512m').
     |      :param executor_cores: Number of cores to use for each executor.
     |      :param num_executors: Number of executors to launch for this session.
     |      :param archives: URLs of archives to be used in this session.
     |      :param queue: The name of the YARN queue to which submitted.
     |      :param name: The name of this session.
     |      :param spark_conf: Spark configuration properties.
     |      :param heartbeat_timeout: Optional Timeout in seconds to which session
     |          be automatically orphaned if no heartbeat is received.
     |  
     |  create_statement(self, session_id: int, code: str, kind: livy.models.StatementKind = None) -> livy.models.Statement
     |      Run a statement in a session.
     |      
     |      :param session_id: The ID of the session.
     |      :param code: The code to execute.
     |      :param kind: The kind of code to execute.
     |  
     |  delete_batch(self, batch_id: int) -> None
     |      Kill a batch session.
     |      
     |      :param batch_id: The ID of the session.
     |  
     |  delete_session(self, session_id: int) -> None
     |      Kill a session.
     |      
     |      :param session_id: The ID of the session.
     |  
     |  get_batch(self, batch_id: int) -> Optional[livy.models.Batch]
     |      Get information about a batch.
     |      
     |      :param batch_id: The ID of the batch.
     |  
     |  get_batch_log(self, batch_id: int, from_: int = None, size: int = None) -> Optional[livy.models.BatchLog]
     |      Get logs for a batch.
     |      
     |      :param batch_id: The ID of the batch.
     |      :param from_: The line number to start getting logs from.
     |      :param size: The number of lines of logs to get.
     |  
     |  get_session(self, session_id: int) -> Optional[livy.models.Session]
     |      Get information about a session.
     |      
     |      :param session_id: The ID of the session.
     |  
     |  get_statement(self, session_id: int, statement_id: int) -> livy.models.Statement
     |      Get information about a statement in a session.
     |      
     |      :param session_id: The ID of the session.
     |      :param statement_id: The ID of the statement.
     |  
     |  legacy_server(self) -> bool
     |      Determine if the server is running a legacy version.
     |      
     |      Legacy versions support different session kinds than newer versions of
     |      Livy.
     |  
     |  list_batches(self) -> List[livy.models.Batch]
     |      List all the active batches in Livy.
     |  
     |  list_sessions(self) -> List[livy.models.Session]
     |      List all the active sessions in Livy.
     |  
     |  list_statements(self, session_id: int) -> List[livy.models.Statement]
     |      Get all the statements in a session.
     |      
     |      :param session_id: The ID of the session.
     |  
     |  server_version(self) -> livy.models.Version
     |      Get the version of Livy running on the server.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from livy.client.LivyClient:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/livyapi.py



==== log ====
```

---

## Módulo `bbmagic.log`

### NAME

`bbmagic.log`

### FUNCTIONS

#### Função `get_start_session`

```text
    get_start_session(session)
```

#### Função `log_project`

```text
    log_project(spark_bbmagic=None)
```

### VERSION

`3.1.4`

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/log.py



==== log_project ====
```

---

## Função `log_project` — módulo `bbmagic.log`

### Conteúdo

```text
log_project(spark_bbmagic=None)


==== lookup ====
```

---

## Módulo `bbmagic.lookup`

### NAME

`bbmagic.lookup`

### CLASSES

#### Hierarquia

```text
    builtins.object
        Lookup
```

#### Classe `Lookup`

```text
    class Lookup(builtins.object)
     |  Methods defined here:
     |  
     |  
     |  sigla(self) -> str
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/lookup.py



==== sas ====
```

---

## Pacote `bbmagic.sas`

### NAME

`bbmagic.sas`

### PACKAGE CONTENTS

- `authinfo`
- `sas`
- `sascfg`

### CLASSES

#### Hierarquia

```text
    builtins.Exception(builtins.BaseException)
        bbmagic.sas.sas.SASProcedureError
    builtins.object
        bbmagic.sas.authinfo.AuthInfo
        bbmagic.sas.authinfo.AuthKey
        bbmagic.sas.sas.SAS
```

#### Classe `AuthInfo`

```text
    class AuthInfo(builtins.object)
     |  Methods defined here:
     |  
     |  __init__(self)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __len__(self) -> int
     |  
     |  add_key(self, name: str, user: str, password: Optional[str] = None) -> None
     |  
     |  parse(self) -> list
     |  
     |  remove_key(self, name: str) -> None
     |  
     |  write(self) -> None
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  path
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `AuthKey`

```text
    class AuthKey(builtins.object)
     |  AuthKey(name: str, user: str, password: Optional[str] = None) -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self, name: str, user: str, password: Optional[str] = None) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  __str__(self) -> str
     |      Return str(self).
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `SAS`

```text
    class SAS(builtins.object)
     |  SAS(username: str = '', host: str = 'sasanl03.intranet.bb.com.br', port: int = 8591, appserver: str = 'SASApp_ANL03 - Workspace Server', authkey: str = '', libnames: Optional[List[dict]] = None, timeout: int = 30) -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self, username: str = '', host: str = 'sasanl03.intranet.bb.com.br', port: int = 8591, appserver: str = 'SASApp_ANL03 - Workspace Server', authkey: str = '', libnames: Optional[List[dict]] = None, timeout: int = 30) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  config_authinfo(self, name: str = 'bbmagic') -> None
     |  
     |  create_libnames(self) -> None
     |  
     |  query(self, sql: str, chunksize: Optional[int] = 2500, verbose: bool = False) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

#### Classe `SASProcedureError`

```text
    class SASProcedureError(builtins.Exception)
     |  Method resolution order:
     |      SASProcedureError
     |      builtins.Exception
     |      builtins.BaseException
     |      builtins.object
     |  
     |  Data descriptors defined here:
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.Exception:
     |  
     |  __init__(self, /, *args, **kwargs)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods inherited from builtins.Exception:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  ----------------------------------------------------------------------
     |  Methods inherited from builtins.BaseException:
     |  
     |  __delattr__(self, name, /)
     |      Implement delattr(self, name).
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __reduce__(...)
     |      Helper for pickle.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __setattr__(self, name, value, /)
     |      Implement setattr(self, name, value).
     |  
     |  __setstate__(...)
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  with_traceback(...)
     |      Exception.with_traceback(tb) --
     |      set self.__traceback__ to tb and return self.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors inherited from builtins.BaseException:
     |  
     |  __cause__
     |      exception cause
     |  
     |  __context__
     |      exception context
     |  
     |  __dict__
     |  
     |  __suppress_context__
     |  
     |  __traceback__
     |  
     |  args
```

### DATA

```text
    __all__ = ['AuthKey', 'AuthInfo', 'SAS', 'SASProcedureError']
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/sas/__init__.py



==== sigla_api ====
```

---

## Módulo `bbmagic.sigla_api`

### NAME

`bbmagic.sigla_api`

### CLASSES

#### Hierarquia

```text
    builtins.object
        SiglaAPI
```

#### Classe `SiglaAPI`

```text
    class SiglaAPI(builtins.object)
     |  SiglaAPI(timeout=10)
     |  
     |  Methods defined here:
     |  
     |  __init__(self, timeout=10)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get(self, sigla: str) -> dict
     |      Faz uma requisição GET à API passando a sigla como parâmetro.
     |      Retorna os dados em JSON ou None se houver erro.
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  BASE_URL = 'http://informacoes.big.intranet.bb.com.br/api/v1/sigla-loc...
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/sigla_api.py



==== spark ====
```

---

## Módulo `bbmagic.spark`

### NAME

`bbmagic.spark`

### CLASSES

#### Hierarquia

```text
    builtins.object
        PythonVersion
        Spark
```

#### Classe `PythonVersion`

```text
    class PythonVersion(builtins.object)
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
     |  
     |  ----------------------------------------------------------------------
     |  Data and other attributes defined here:
     |  
     |  PYTHON_27 = 2
     |  
     |  PYTHON_311 = 311
     |  
     |  PYTHON_36 = 3
     |  
     |  PYTHON_38 = 38
     |  
     |  PYTHON_39 = 39
```

#### Classe `Spark`

```text
    class Spark(builtins.object)
     |  Spark(session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
     |  
     |  Cria uma sessão Spark.
     |  
     |  :param session_name: nome da sessão que será exibido na Web UI do Spark
     |  :param username: caminho para arquivo .keytab ou matrícula sem o dígito do usuário
     |  :param python: versão do Python da sessão Spark (2 ou 3)
     |  :param language: linguagem utilizada na sessão Spark ('python' ou 'scala')
     |  :param auth: modo de autenticação no Livy
     |  :param timeout: tempo máximo até que a sessão Spark seja criada
     |  :param db2: configura a sessão Spark para conexão JDBC ao DB2
     |  :param spark_conf: dicionário de parâmetros adicionais para configuração da sessão Spark.
     |                     Esse parâmetro tem prioridade sobre a padrão do BBMagic
     |  :param jars: lista de paths de arquivos .jar localizados no HDFS que serão utilizados na
     |               sessão. Ex: ['hdfs:///user/jars/database.jar']
     |  :param env: dicionário utilizado para definição de variáveis de ambiente na sessão Spark
     |  :param debug: exibe mais informações sobre a sessão Spark
     |  :param driver_memory: Quantidade de memória alocada para o driver da sessão Spark seguida
     |                        pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
     |                        (Ex.: '512m', '4g').
     |  :param driver_cores: Quantidade de cores alocados para o driver da sessão Spark
     |  :param num_executors: Quantidade de executores alocados para a sessão Spark.
     |  :param executor_memory: Quantidade de memória alocada cada executor da sessão Spark seguida
     |                          pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
     |                          (Ex.: '512m', '4g').
     |  :param executor_cores: Quantidade de cores alocados para cada executor da sessão Spark
     |  :param spark_version: Identifica a versao do Spark que ira receber a conexao - 2 ou 3
     |  
     |  Methods defined here:
     |  
     |  __del__(self) -> None
     |      Garante que a sessão Livy é encerrada assim que o Python finalize
     |  
     |  __init__(self, session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  close(self) -> None
     |      Encerra a sessão Spark
     |  
     |  config_db2(self) -> None
     |  
     |  config_jars(self) -> None
     |      Adiciona os jars para utilização de bibliotecas de machine learning distribuidas nas sessões spark 3
     |  
     |  config_sparkmagic(self) -> None
     |  
     |  config_virtualenv(self, virtualenv: Optional[str], overwrite: bool = False) -> Optional[str]
     |  
     |  connect(self) -> None
     |  
     |  enforce_dynamic_allocation(self, config: Optional[Dict[str, str]]) -> Optional[dict]
     |  
     |  get_from_spark(self, var_name: str)
     |      Importa o conteúdo de uma variável da sessão Spark para a sessão local.
     |      
     |      
     |      :param var_name: nome da variável que será importada.
     |      
     |      :return: Retorna o valor da variável
     |  
     |  send_to_spark(self, var) -> None
     |      Envia uma variável local para a sessão Spark.
     |      
     |      A variável será definida com mesmo nome na sessão Spark e o valor
     |      será transmitido utilizando pickle.
     |      
     |      :param var: variável que será enviada para a sessão Spark.
     |      
     |      :return: None
     |  
     |  ----------------------------------------------------------------------
     |  Class methods defined here:
     |  
     |  
     |  ----------------------------------------------------------------------
     |  Readonly properties defined here:
     |  
     |  ambiente
     |  
     |  bbmagic_session_id
     |  
     |  
     |  default_env
     |  
     |  force_dynammic_allocation
     |  
     |  livy_conn
     |  
     |  livy_session_id
     |  
     |  livy_url
     |  
     |  livy_version
     |  
     |  pickle_protocol
     |  
     |  spark_session_name
     |  
     |  spark_version
     |  
     |  user
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### FUNCTIONS

#### Função `get_python_version`

```text
    get_python_version()
        Retorna a versão do Python configurada para a sessão Spark.
```

### DATA

```text
    Dict = typing.Dict
        A generic version of dict.
    
    LIBS_PATHS = {2: 'python', 3: 'python3.6', 38: 'python3.8', 39: 'pytho...
    LIVY_AUTH_KERBEROS = 'Kerberos'
    LIVY_TIMEOUT_SECONDS = 900
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
    
    PYSPARK_PATHS = {2: '/usr/bin/python', 3: '/usr/bin/python3', 38: '/us...
    logger = <Logger bbmagic.spark (DEBUG)>
    spark_checks = {'pre_run_cell': <function check_pre_run_cell>}
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/spark.py



==== sumary ====
```

---

## Módulo `bbmagic.sumary`

### NAME

`bbmagic.sumary`

### DESCRIPTION

```text
    Author: Matheus Gois
    Matrícula: c1323613
    docs: https://big-sumario-tabelas-replicadas.big.desenv.bb.com.br/api-docs/#/
    abstract: Criar função na bbmagic que acesse a api e verificar a situação da tabela no hive
```

### CLASSES

#### Hierarquia

```text
    builtins.object
        MetaDataHive
```

#### Classe `MetaDataHive`

```text
    class MetaDataHive(builtins.object)
     |  MetaDataHive() -> None
     |  
     |  Methods defined here:
     |  
     |  __init__(self) -> None
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  get_token(self) -> Optional[str]
     |  
     |  get_url(self) -> Optional[str]
     |  
     |  status_db(self, db: str, list: Optional[bool] = False) -> Optional[pandas.core.frame.DataFrame]
     |  
     |  status_table(self, nome_db: Optional[str] = None, nome_tabela: Optional[str] = None) -> Optional[pandas.core.frame.DataFrame]
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### DATA

```text
    Optional = typing.Optional
        Optional type.
        
        Optional[X] is equivalent to Union[X, None].
    
    Union = typing.Union
        Union type; Union[X, Y] means either X or Y.
        
        To define a union, use e.g. Union[int, str].  Details:
        - The arguments must be types and there must be at least one.
        - None as an argument is a special case and is replaced by
          type(None).
        - Unions of unions are flattened, e.g.::
        
            Union[Union[int, str], float] == Union[int, str, float]
        
        - Unions of a single argument vanish, e.g.::
        
            Union[int] == int  # The constructor actually returns int
        
        - Redundant arguments are skipped, e.g.::
        
            Union[int, str, int] == Union[int, str]
        
        - When comparing unions, the argument order is ignored, e.g.::
        
            Union[int, str] == Union[str, int]
        
        - You cannot subclass or instantiate a union.
        - You can use Optional[X] as a shorthand for Union[X, None].
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/sumary.py



==== suppress ====
```

---

## Classe `suppress` — módulo `contextlib`

### Conteúdo

```text
class suppress(AbstractContextManager)
 |  suppress(*exceptions)
 |  
 |  Context manager to suppress specified exceptions
 |  
 |  After the exception is suppressed, execution proceeds with the next
 |  statement following the with statement.
 |  
 |       with suppress(FileNotFoundError):
 |           os.remove(somefile)
 |       # Execution still resumes here if the file was already removed
 |  
 |  Method resolution order:
 |      suppress
 |      AbstractContextManager
 |      abc.ABC
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __enter__(self)
 |      Return `self` upon entering the runtime context.
 |  
 |  __exit__(self, exctype, excinst, exctb)
 |      Raise any exception triggered within the runtime context.
 |  
 |  __init__(self, *exceptions)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  __abstractmethods__ = frozenset()
 |  
 |  ----------------------------------------------------------------------
 |  Class methods inherited from AbstractContextManager:
 |  
 |  __class_getitem__ = GenericAlias(...) from abc.ABCMeta
 |      Represent a PEP 585 generic type
 |      
 |      E.g. for t = list[int], t.__origin__ is list and t.__args__ is (int,).
 |  
 |  __subclasshook__(C) from abc.ABCMeta
 |      Abstract classes can override this to customize issubclass().
 |      
 |      This is invoked early on by abc.ABCMeta.__subclasscheck__().
 |      It should return True, False or NotImplemented.  If it returns
 |      NotImplemented, the normal algorithm is used.  Otherwise, it
 |      overrides the normal algorithm (and the outcome is cached).
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from AbstractContextManager:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)


==== teams_notify ====
```

---

## Módulo `bbmagic.teams_notify`

### NAME

`bbmagic.teams_notify`

### CLASSES

#### Hierarquia

```text
    builtins.object
        TeamsNotify
```

#### Classe `TeamsNotify`

```text
    class TeamsNotify(builtins.object)
     |  TeamsNotify(webhook: str)
     |  
     |  Methods defined here:
     |  
     |  __init__(self, webhook: str)
     |      Initialize self.  See help(type(self)) for accurate signature.
     |  
     |  error(self, title, text, model='', situation='', other_details='', color='E81123')
     |  
     |  info(self, title, text, model='', situation='', other_details='', color='008000')
     |  
     |  post_msg(self, title, text, model, situation, other_details, color=None)
     |  
     |  post_msg_workflows(self, title: str, text: str, model: str = '', situation: str = '', other_details: str = '', type: str = '') -> dict
     |      Função que envia mensagens por meio dos fluxos Workflows no Microsoft Teams
     |  
     |  warning(self, title, text, model='', situation='', other_details='', color='FFFF00')
     |  
     |  ----------------------------------------------------------------------
     |  Data descriptors defined here:
     |  
     |  __dict__
     |      dictionary for instance variables (if defined)
     |  
     |  __weakref__
     |      list of weak references to the object (if defined)
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/teams_notify.py



==== utils ====
```

---

## Pacote `bbmagic.utils`

### NAME

`bbmagic.utils`

### PACKAGE CONTENTS

- `format_python_version`

### FUNCTIONS

#### Função `format_python_version`

```text
    format_python_version(version_num: int) -> str
        Recebe um número inteiro (ex.: 311, 39) e retorna a string formatada (ex.: '3.11', '3.9').
```

### DATA

```text
    __all__ = ['format_python_version']
```

### FILE

```text
    /projeto/libs/lib/python3.9/site-packages/bbmagic/utils/__init__.py



==== version ====
```

---

## Módulo `bbmagic.version`

### NAME

`bbmagic.version`

### VERSION

`3.1.4`

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/version.py`

---

## Pacote `bbmagic.utils`

### NAME

`bbmagic.utils`

### PACKAGE CONTENTS

- `format_python_version`

### FUNCTIONS

#### Função `format_python_version`

```text
    format_python_version(version_num: int) -> str
        Recebe um número inteiro (ex.: 311, 39) e retorna a string formatada (ex.: '3.11', '3.9').
```

### DATA

```text
    __all__ = ['format_python_version']
```

### FILE

`/projeto/libs/lib/python3.9/site-packages/bbmagic/utils/__init__.py`

---

## Classe `Hdfs` — módulo `bbmagic.hdfs`

### Conteúdo

```text
class Hdfs(hdfs.ext.kerberos.KerberosClient)
 |  Hdfs(username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
 |  
 |  Permite acesso ao HDFS com autenticação via kerberos.
 |  
 |  :param username: matrícula ou caminho para arquivo keytab
 |  :param \*\*kwargs: Argumentos adicionais passados para a classe HTTPKerberosAuth.
 |  
 |  Method resolution order:
 |      Hdfs
 |      hdfs.ext.kerberos.KerberosClient
 |      hdfs.client.Client
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __init__(self, username: Optional[str] = None, hdp: int = None, set_no_proxy: bool = True, config: Optional[bbmagic.file_config.FileConfig] = None, **kwargs) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  set_no_proxy(self) -> None
 |      Garante que a variável no_proxy está configurada para ignorar o domínio
 |      da API web da BBMagic
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from hdfs.client.Client:
 |  
 |  __repr__(self)
 |      Return repr(self).
 |  
 |  acl_status(self, hdfs_path, strict=True)
 |      Get AclStatus_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _AclStatus: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Get_ACL_Status
 |  
 |  allow_snapshot(self, hdfs_path)
 |      Allow snapshots for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist or does points to a normal file, an
 |        :class:`HdfsError` will be raised.  No-op if snapshotting is
 |        already allowed.
 |  
 |  checksum(self, hdfs_path)
 |      Get a remote file's checksum.
 |      
 |      :param hdfs_path: Remote path. Must point to a file.
 |  
 |  content(self, hdfs_path, strict=True)
 |      Get ContentSummary_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _ContentSummary: CS_
 |      .. _CS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#ContentSummary
 |  
 |  create_snapshot(self, hdfs_path, snapshotname=None)
 |      Create snapshot for a remote folder where it was allowed.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist, doesn't allow to create snapshot or points to a
 |        normal file, an :class:`HdfsError` will be raised.
 |      :param snapshotname snapshot name; if absent, name is generated
 |        by the server.
 |      
 |      Returns a path to created snapshot.
 |  
 |  delete(self, hdfs_path, recursive=False, skip_trash=True)
 |      Remove a file or directory from HDFS.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param recursive: Recursively delete files and directories. By default,
 |        this method will raise an :class:`HdfsError` if trying to delete a
 |        non-empty directory.
 |      :param skip_trash: When false, the deleted path will be moved to an
 |        appropriate trash folder rather than deleted. This requires Hadoop 2.9+
 |      
 |      This function returns `True` if the deletion was successful and `False` if
 |      no file or directory previously existed at `hdfs_path`.
 |  
 |  delete_snapshot(self, hdfs_path, snapshotname)
 |      Remove snapshot for a remote folder where it was allowed.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param snapshotname snapshot name; if it does not exist, an
 |        :class:`HdfsError` will be raised.
 |  
 |  disallow_snapshot(self, hdfs_path)
 |      Disallow snapshots for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path`
 |        doesn't exist, points to a normal file or there are some
 |        snapshots, an :class:`HdfsError` will be raised.
 |      
 |      No-op if snapshotting is disallowed/never allowed.
 |  
 |  download(self, hdfs_path, local_path, overwrite=False, n_threads=1, temp_dir=None, **kwargs)
 |      Download a file or folder from HDFS and save it locally.
 |      
 |      :param hdfs_path: Path on HDFS of the file or folder to download. If a
 |        folder, all the files under it will be downloaded.
 |      :param local_path: Local path. If it already exists and is a directory,
 |        the files will be downloaded inside of it.
 |      :param overwrite: Overwrite any existing file or directory.
 |      :param n_threads: Number of threads to use for parallelization. A value of
 |        `0` (or negative) uses as many threads as there are files.
 |      :param temp_dir: Directory under which the files will first be downloaded
 |        when `overwrite=True` and the final destination path already exists. Once
 |        the download successfully completes, it will be swapped in.
 |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`read`. If no
 |        `chunk_size` argument is passed, a default value of 64 kB will be used.
 |        If a `progress` argument is passed and threading is used, care must be
 |        taken to ensure correct behavior.
 |      
 |      On success, this method returns the local download path.
 |  
 |  list(self, hdfs_path, status=False)
 |      Return names of files contained in a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory. If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param status: Also return each file's corresponding FileStatus_.
 |  
 |  makedirs(self, hdfs_path, permission=None)
 |      Create a remote directory, recursively if necessary.
 |      
 |      :param hdfs_path: Remote path. Intermediate directories will be created
 |        appropriately.
 |      :param permission: Octal permission to set on the newly created directory.
 |        These permissions will only be set on directories that do not already
 |        exist.
 |      
 |      This function currently has no return value as WebHDFS doesn't return a
 |      meaningful flag.
 |  
 |  parts(self, hdfs_path, parts=None, status=False)
 |      Returns a dictionary of part-files corresponding to a path.
 |      
 |      :param hdfs_path: Remote path. This directory should contain at most one
 |        part file per partition (otherwise one will be picked arbitrarily).
 |      :param parts: List of part-files numbers or total number of part-files to
 |        select. If a number, that many partitions will be chosen at random. By
 |        default all part-files are returned. If `parts` is a list and one of the
 |        parts is not found or too many samples are demanded, an
 |        :class:`~hdfs.util.HdfsError` is raised.
 |      :param status: Also return each file's corresponding FileStatus_.
 |  
 |  read(self, hdfs_path, offset=0, length=None, buffer_size=None, encoding=None, chunk_size=0, delimiter=None, progress=None)
 |      Read a file from HDFS.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param offset: Starting byte position.
 |      :param length: Number of bytes to be processed. `None` will read the entire
 |        file.
 |      :param buffer_size: Size of the buffer in bytes used for transferring the
 |        data. Defaults the the value set in the HDFS configuration.
 |      :param encoding: Encoding used to decode the request. By default the raw
 |        data is returned. This is mostly helpful in python 3, for example to
 |        deserialize JSON data (as the decoder expects unicode).
 |      :param chunk_size: If set to a positive number, the context manager will
 |        return a generator yielding every `chunk_size` bytes instead of a
 |        file-like object (unless `delimiter` is also set, see below).
 |      :param delimiter: If set, the context manager will return a generator
 |        yielding each time the delimiter is encountered. This parameter requires
 |        the `encoding` to be specified.
 |      :param progress: Callback function to track progress, called every
 |        `chunk_size` bytes (not available if the chunk size isn't specified). It
 |        will be passed two arguments, the path to the file being uploaded and the
 |        number of bytes transferred so far. On completion, it will be called once
 |        with `-1` as second argument.
 |      
 |      This method must be called using a `with` block:
 |      
 |      .. code-block:: python
 |      
 |        with client.read('foo') as reader:
 |          content = reader.read()
 |      
 |      This ensures that connections are always properly closed.
 |      
 |      .. note::
 |      
 |        The raw file-like object returned by this method (when called without an
 |        encoding, chunk size, or delimiter) can have a very different performance
 |        profile than local files. In particular, line-oriented methods are often
 |        slower. The recommended workaround is to specify an encoding when
 |        possible or read the entire file before splitting it.
 |  
 |  remove_acl(self, hdfs_path)
 |      RemoveAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      
 |      .. _RemoveAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL
 |  
 |  remove_acl_entries(self, hdfs_path, acl_spec)
 |      RemoveAclEntries_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      :param acl_spec: String representation of an ACL spec. Must be a valid
 |        string with entries for user, group and other. For example:
 |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
 |      
 |      .. _RemoveAclEntries: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_ACL_Entries
 |  
 |  remove_default_acl(self, hdfs_path)
 |      RemoveDefaultAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      
 |      .. _RemoveDefaultAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Remove_Default_ACL
 |  
 |  rename(self, hdfs_src_path, hdfs_dst_path)
 |      Move a file or folder.
 |      
 |      :param hdfs_src_path: Source path.
 |      :param hdfs_dst_path: Destination path. If the path already exists and is
 |        a directory, the source will be moved into it. If the path exists and is
 |        a file, or if a parent destination directory is missing, this method will
 |        raise an :class:`HdfsError`.
 |  
 |  rename_snapshot(self, hdfs_path, oldsnapshotname, snapshotname)
 |      Rename snapshot for a remote folder.
 |      
 |      :param hdfs_path: Remote path to a directory.  If `hdfs_path` doesn't exist
 |        or points to a normal file, an :class:`HdfsError` will be raised.
 |      :param oldsnapshotname snapshot name; if it does not exist,
 |        an :class:`HdfsError` will be raised.
 |      :param snapshotname new snapshot name; if it does already exist,
 |        an :class:`HdfsError` will be raised.
 |  
 |  resolve(self, hdfs_path)
 |      Return absolute, normalized path, with special markers expanded.
 |      
 |      :param hdfs_path: Remote path.
 |      
 |      Currently supported markers:
 |      
 |      * `'#LATEST'`: this marker gets expanded to the most recently updated file
 |        or folder. They can be combined using the `'{N}'` suffix. For example,
 |        `'foo/#LATEST{2}'` is equivalent to `'foo/#LATEST/#LATEST'`.
 |  
 |  set_acl(self, hdfs_path, acl_spec, clear=True)
 |      SetAcl_ or ModifyAcl_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Path to an existing remote file or directory. An
 |        :class:`HdfsError` will be raised if the path doesn't exist.
 |      :param acl_spec: String representation of an ACL spec. Must be a valid
 |        string with entries for user, group and other. For example:
 |        `"user::rwx,user:foo:rw-,group::r--,other::---"`.
 |      :param clear: Clear existing ACL entries. If set to false, all existing ACL
 |        entries that are not specified in this call are retained without changes,
 |        behaving like ModifyAcl_. For example: `"user:foo:rwx"`.
 |      
 |      .. _SetAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Set_ACL
 |      .. _ModifyAcl: https://hadoop.apache.org/docs/stable2/hadoop-project-dist/hadoop-hdfs/WebHDFS.html#Modify_ACL_Entries
 |  
 |  set_owner(self, hdfs_path, owner=None, group=None)
 |      Change the owner of file.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param owner: Optional, new owner for file.
 |      :param group: Optional, new group for file.
 |      
 |      At least one of `owner` and `group` must be specified.
 |  
 |  set_permission(self, hdfs_path, permission)
 |      Change the permissions of file.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param permission: New octal permissions string of file.
 |  
 |  set_replication(self, hdfs_path, replication)
 |      Set file replication.
 |      
 |      :param hdfs_path: Path to an existing remote file. An :class:`HdfsError`
 |        will be raised if the path doesn't exist or points to a directory.
 |      :param replication: Replication factor.
 |  
 |  set_times(self, hdfs_path, access_time=None, modification_time=None)
 |      Change remote timestamps.
 |      
 |      :param hdfs_path: HDFS path.
 |      :param access_time: Timestamp of last file access.
 |      :param modification_time: Timestamps of last file access.
 |  
 |  status(self, hdfs_path, strict=True)
 |      Get FileStatus_ for a file or folder on HDFS.
 |      
 |      :param hdfs_path: Remote path.
 |      :param strict: If `False`, return `None` rather than raise an exception if
 |        the path doesn't exist.
 |      
 |      .. _FileStatus: FS_
 |      .. _FS: http://hadoop.apache.org/docs/r1.0.4/webhdfs.html#FileStatus
 |  
 |  upload(self, hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs)
 |      Upload a file or directory to HDFS.
 |      
 |      :param hdfs_path: Target HDFS path. If it already exists and is a
 |        directory, files will be uploaded inside.
 |      :param local_path: Local path to file or folder. If a folder, all the files
 |        inside of it will be uploaded (note that this implies that folders empty
 |        of files will not be created remotely).
 |      :param n_threads: Number of threads to use for parallelization. A value of
 |        `0` (or negative) uses as many threads as there are files.
 |      :param temp_dir: Directory under which the files will first be uploaded
 |        when `overwrite=True` and the final remote path already exists. Once the
 |        upload successfully completes, it will be swapped in.
 |      :param chunk_size: Interval in bytes by which the files will be uploaded.
 |      :param progress: Callback function to track progress, called every
 |        `chunk_size` bytes. It will be passed two arguments, the path to the
 |        file being uploaded and the number of bytes transferred so far. On
 |        completion, it will be called once with `-1` as second argument.
 |      :param cleanup: Delete any uploaded files if an error occurs during the
 |        upload.
 |      :param \*\*kwargs: Keyword arguments forwarded to :meth:`write`. In
 |        particular, set `overwrite` to overwrite any existing file or directory.
 |      
 |      On success, this method returns the remote upload path.
 |  
 |  walk(self, hdfs_path, depth=0, status=False, ignore_missing=False, allow_dir_changes=False)
 |      Depth-first walk of remote filesystem.
 |      
 |      :param hdfs_path: Starting path. If the path doesn't exist, an
 |        :class:`HdfsError` will be raised. If it points to a file, the returned
 |        generator will be empty.
 |      :param depth: Maximum depth to explore. `0` for no limit.
 |      :param status: Also return each file or folder's corresponding FileStatus_.
 |      :param ignore_missing: Ignore missing nested folders rather than raise an
 |        exception. This can be useful when the tree is modified during a walk.
 |      :param allow_dir_changes: Allow changes to the directories' list to affect
 |        the walk. For example clearing it by setting `dirs[:] = []` would prevent
 |        the walk from entering any nested directories. This option can only be set
 |        when `status` is false.
 |      
 |      This method returns a generator yielding tuples `(path, dirs, files)`
 |      where `path` is the absolute path to the current directory, `dirs` is the
 |      list of directory names it contains, and `files` is the list of file names
 |      it contains.
 |  
 |  write(self, hdfs_path, data=None, overwrite=False, permission=None, blocksize=None, replication=None, buffersize=None, append=False, encoding=None)
 |      Create a file on HDFS.
 |      
 |      :param hdfs_path: Path where to create file. The necessary directories will
 |        be created appropriately.
 |      :param data: Contents of file to write. Can be a string, a generator or a
 |        file object. The last two options will allow streaming upload (i.e.
 |        without having to load the entire contents into memory). If `None`, this
 |        method will return a file-like object and should be called using a `with`
 |        block (see below for examples).
 |      :param overwrite: Overwrite any existing file or directory.
 |      :param permission: Octal permission to set on the newly created file.
 |        Leading zeros may be omitted.
 |      :param blocksize: Block size of the file.
 |      :param replication: Number of replications of the file.
 |      :param buffersize: Size of upload buffer.
 |      :param append: Append to a file rather than create a new one.
 |      :param encoding: Encoding used to serialize data written.
 |      
 |      Sample usages:
 |      
 |      .. code-block:: python
 |      
 |        from json import dump, dumps
 |      
 |        records = [
 |          {'name': 'foo', 'weight': 1},
 |          {'name': 'bar', 'weight': 2},
 |        ]
 |      
 |        # As a context manager:
 |        with client.write('data/records.jsonl', encoding='utf-8') as writer:
 |          dump(records, writer)
 |      
 |        # Or, passing in a generator directly:
 |        client.write('data/records.jsonl', data=dumps(records), encoding='utf-8')
 |  
 |  ----------------------------------------------------------------------
 |  Class methods inherited from hdfs.client.Client:
 |  
 |  from_options(options, class_name='Client') from hdfs.client._ClientType
 |      Load client from options.
 |      
 |      :param options: Options dictionary.
 |      :param class_name: Client class name. Defaults to the base :class:`Client`
 |        class.
 |      
 |      This method provides a single entry point to instantiate any registered
 |      :class:`Client` subclass. To register a subclass, simply load its
 |      containing module. If using the CLI, you can use the `autoload.modules` and
 |      `autoload.paths` options.
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors inherited from hdfs.client.Client:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes inherited from hdfs.client.Client:
 |  
 |  __registry__ = {'Client': <class 'hdfs.client.Client'>, 'Hdfs': <class...
```

---

## Classe `Spark` — módulo `bbmagic.spark`

### Conteúdo

```text
class Spark(builtins.object)
 |  Spark(session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
 |  
 |  Cria uma sessão Spark.
 |  
 |  :param session_name: nome da sessão que será exibido na Web UI do Spark
 |  :param username: caminho para arquivo .keytab ou matrícula sem o dígito do usuário
 |  :param python: versão do Python da sessão Spark (2 ou 3)
 |  :param language: linguagem utilizada na sessão Spark ('python' ou 'scala')
 |  :param auth: modo de autenticação no Livy
 |  :param timeout: tempo máximo até que a sessão Spark seja criada
 |  :param db2: configura a sessão Spark para conexão JDBC ao DB2
 |  :param spark_conf: dicionário de parâmetros adicionais para configuração da sessão Spark.
 |                     Esse parâmetro tem prioridade sobre a padrão do BBMagic
 |  :param jars: lista de paths de arquivos .jar localizados no HDFS que serão utilizados na
 |               sessão. Ex: ['hdfs:///user/jars/database.jar']
 |  :param env: dicionário utilizado para definição de variáveis de ambiente na sessão Spark
 |  :param debug: exibe mais informações sobre a sessão Spark
 |  :param driver_memory: Quantidade de memória alocada para o driver da sessão Spark seguida
 |                        pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
 |                        (Ex.: '512m', '4g').
 |  :param driver_cores: Quantidade de cores alocados para o driver da sessão Spark
 |  :param num_executors: Quantidade de executores alocados para a sessão Spark.
 |  :param executor_memory: Quantidade de memória alocada cada executor da sessão Spark seguida
 |                          pelo sufixo reprensentando a unidade ('k', 'm', 'g' or 't')
 |                          (Ex.: '512m', '4g').
 |  :param executor_cores: Quantidade de cores alocados para cada executor da sessão Spark
 |  :param spark_version: Identifica a versao do Spark que ira receber a conexao - 2 ou 3
 |  
 |  Methods defined here:
 |  
 |  __del__(self) -> None
 |      Garante que a sessão Livy é encerrada assim que o Python finalize
 |  
 |  __init__(self, session_name: str, username: Optional[str] = None, language: str = 'python', auth: str = 'Kerberos', timeout: int = 900, db2: bool = False, spark_conf: Optional[dict] = None, jars: Optional[list] = None, archives: Optional[list] = None, pyfiles: Optional[list] = None, files: Optional[list] = None, python: int = None, env: Optional[dict] = None, debug: bool = False, driver_memory: str = '8g', driver_cores: int = 4, num_executors: int = 4, executor_memory: str = '2g', executor_cores: int = 4, virtualenv: Optional[str] = None, overwrite_virtualenv: bool = False, spark_version: int = 3)
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  close(self) -> None
 |      Encerra a sessão Spark
 |  
 |  config_db2(self) -> None
 |  
 |  config_jars(self) -> None
 |      Adiciona os jars para utilização de bibliotecas de machine learning distribuidas nas sessões spark 3
 |  
 |  config_sparkmagic(self) -> None
 |  
 |  config_virtualenv(self, virtualenv: Optional[str], overwrite: bool = False) -> Optional[str]
 |  
 |  connect(self) -> None
 |  
 |  enforce_dynamic_allocation(self, config: Optional[Dict[str, str]]) -> Optional[dict]
 |  
 |  get_from_spark(self, var_name: str)
 |      Importa o conteúdo de uma variável da sessão Spark para a sessão local.
 |      
 |      
 |      :param var_name: nome da variável que será importada.
 |      
 |      :return: Retorna o valor da variável
 |  
 |  send_to_spark(self, var) -> None
 |      Envia uma variável local para a sessão Spark.
 |      
 |      A variável será definida com mesmo nome na sessão Spark e o valor
 |      será transmitido utilizando pickle.
 |      
 |      :param var: variável que será enviada para a sessão Spark.
 |      
 |      :return: None
 |  
 |  ----------------------------------------------------------------------
 |  Class methods defined here:
 |  
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  ambiente
 |  
 |  bbmagic_session_id
 |  
 |  
 |  default_env
 |  
 |  force_dynammic_allocation
 |  
 |  livy_conn
 |  
 |  livy_session_id
 |  
 |  livy_url
 |  
 |  livy_version
 |  
 |  pickle_protocol
 |  
 |  spark_session_name
 |  
 |  spark_version
 |  
 |  user
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
```

---

## Classe `Db2` — módulo `bbmagic.db2`

### Conteúdo

```text
class Db2(builtins.object)
 |  Db2(user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
 |  
 |  Cria uma conexão ao DB2
 |  
 |  Methods defined here:
 |  
 |  __init__(self, user: Optional[str] = None, password: Optional[str] = None, host: str = 'gwdb2.bb.com.br', port: int = 50100, database: str = 'BDB2P04', trust_env: bool = True, jars_path: Optional[str] = None, backoff_limit: int = 3600, pconnect: bool = True) -> None
 |      Initialize self.  See help(type(self)) for accurate signature.
 |  
 |  connect(self) -> ibm_db_dbi.Connection
 |      Cria a conexão JDBC com o servidor DB2.
 |  
 |  describe(self, schema: str, table: str) -> IPython.core.display.HTML
 |      Gera um relatório consolidado com os metadados da tabela existentes no catálogo
 |      do DB2.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um objeto HTML com o relatório para exibição no Jupyter Notebook.
 |      :rtype: IPython.core.display.HTML
 |  
 |  get_cofre_credentials(self, project_id: str) -> dict
 |      Recupera credenciais do cofre com base no project_id do projeto
 |  
 |  query(self, sql: str, params: Optional[list] = None, chunksize: Optional[int] = 2500) -> Union[pandas.core.frame.DataFrame, Iterator[pandas.core.frame.DataFrame]]
 |      Retorna um DataFrame contendo o resultado da execução da query SQL.
 |      
 |      :param sql: query SQL para execução
 |      :param params: lista de parâmetros para utilização na query
 |      :param chunksize: Se especificado, retorna um iterador onde chunksize é a quantidade
 |                        de linhas incluídas em cada chunk
 |      
 |      :return: Daframe ou Iterator[DataFrame]
 |      
 |      Exemplos de Uso::
 |      
 |          >>> for chunk in db2.query("SELECT * FROM db2mci.cliente LIMIT 10000"):
 |          ...     print(len(chunk))
 |          2500
 |          2500
 |          2500
 |          2500
 |      
 |      Sem utilização de chunks
 |      
 |          >>> df = db2.query("SELECT cod FROM db2mci.cliente LIMIT 100", chunksize=None)
 |  
 |  set_conn_param(self, param_name, param_value: Union[str, int, NoneType]) -> Union[str, int]
 |  
 |  show_schemas(self) -> pandas.core.frame.DataFrame
 |      Lista todos os schemas no database
 |      
 |      :return: Retorna um Pandas DataFrame contendo uma linha para cada schema encontrado.
 |      :rtype: pandas.core.api.DataFrame
 |      
 |      Exemplo de uso::
 |      
 |          >>> db2.show_schemas()
 |  
 |  show_tables(self, schema: str) -> pandas.core.frame.DataFrame
 |      Lista todas as tabelas e views de um schema.
 |      
 |      :param schema: nome do schema
 |      
 |      :return: Retorna um Pandas DataFrame contendo uma linha para cada tabela do schema
 |               e as informações *schema*, *name* e *type* nas respectivas colunas.
 |      :rtype: pandas.core.api.DataFrame
 |      
 |      Exemplo de uso::
 |      
 |          >>> db2.show_tables("DB2MCI")
 |  
 |  syscolumns(self, schema: str, table: str) -> pandas.core.frame.DataFrame
 |      Retorna metadados das colunas de uma tabela.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um Pandas DataFrame contendo as informações sobre as colunas da
 |               tabela de acordo com o catálogo syscat.syscolumns
 |      :rtype: pandas.core.api.DataFrame
 |  
 |  systabstats(self, schema: str, table: str) -> pandas.core.frame.DataFrame
 |      Retorna metadados de uma tabela.
 |      
 |      :param schema: nome do schema
 |      :param table: nome da tabela
 |      
 |      :return: Retorna um Pandas DataFrame contendo as informações sobre a tabela
 |               existentes no catálogo syscat.systabstats
 |      :rtype: pandas.core.api.DataFrame
 |  
 |  ----------------------------------------------------------------------
 |  Readonly properties defined here:
 |  
 |  url
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  envs = {'database': 'DB2_DATABASE', 'host': 'DB2_HOST', 'password': 'D...
 |  
 |  jars_path = '/projeto/libs/lib/python3.9/site-packages/bbmagic/jars/db...
```

---
