# DDL Hive de referência para modelagem

**Projeto:** Avisos Finanças Cliente / Recomendações
**Objetivo:** documentação de referência da modelagem Hive das estruturas corporativas de recomendação e aviso financeiro por cliente.
**Base de referência:** DDL corporativo oficial das tabelas `CTL_OPRL_RCM`, `RCM_FNC_CLI` e `RCM_FNC_CLI_EVTL`.

---

## Regras gerais de modelagem

> ⚠️ **Regra conservadora de nulidade**
>
> Campo usado como chave, controle, rastreabilidade, conteúdo ou metadado operacional **não deve aceitar nulo**.
>
> Quando a informação não se aplicar, o fluxo deve padronizar valor e não gravar `NULL`.
>
> `NULL` permanece apenas para regras condicionais comprovadas.

> 🧭 **Regra estrutural importante**
>
> `RCM_FNC_CLI` e `RCM_FNC_CLI_EVTL` devem permanecer com **os mesmos atributos, na mesma ordem e com os mesmos tipos**.
>
> O objetivo é facilitar reconstrução, comparação, rastreabilidade e conversa direta entre a visão operacional e a visão histórica/eventual.

> 🧾 **Regra de comentários dos atributos**
>
> O comentário de cada atributo deve explicar o significado funcional ou operacional do campo.
>
> Campos que compõem a chave lógica devem iniciar o comentário com `#PK`.
>
> Campos com domínio fechado devem listar os valores aceitos.
>
> Campos com nulidade condicional devem explicar a condição de obrigatoriedade e a condição em que o nulo é permitido.

---

# 1. Tabela `CTL_OPRL_RCM`

## 1.1 Identificação da tabela

| Item                           | Definição                                           |
| ------------------------------ | --------------------------------------------------- |
| **Nome físico**                | `CTL_OPRL_RCM`                                      |
| **Natureza**                   | Controle operacional da recomendação                |
| **Formato**                    | `PARQUET`                                           |
| **Compressão**                 | `SNAPPY`                                            |
| **Localização física**         | `/dados/corporativos/t21/hve/external/ctl_oprl_rcm` |
| **Chave lógica**               | `NR_IDFR_PROJ`, `NR_IDFR_RCM`, `NR_VRS_VLDD_RCM`    |
| **Periodicidade**              | Diária                                              |
| **Classificação de segurança** | Interna                                             |
| **Origem**                     | Ambiente Sistêmico                                  |
| **Tempo de retenção**          | 10 anos                                             |
| **LGPD**                       | Dispensada                                          |
| **ModelAI**                    | S                                                   |

## 1.2 Definição da entidade

Controla a situação operacional das recomendações acompanhadas pela rotina de vinculação. Registra a versão validada da recomendação, o estado de processamento, os dados do aviso selecionado, os metadados da origem usada para identificar clientes elegíveis e as referências observadas ou processadas na origem.

**#PK:** Número Identificador Projeto, Número Identificador Recomendação, Número Versão Validada Recomendação

---

## 1.3 Campos obrigatórios

### `NR_IDFR_PROJ`

| Propriedade           | Valor                                                                   |
| --------------------- | ----------------------------------------------------------------------- |
| Nome lógico           | Número Identificador Projeto                                            |
| Tipo                  | `BIGINT`                                                                |
| Chave primária lógica | `Sim`                                                                   |
| Aceita nulo           | `Não (0%)`                                                              |
| Descrição             | Identifica o projeto ao qual a recomendação está vinculada.             |
| Comentário SQL        | `#PK` + identificação do projeto ao qual a recomendação está vinculada. |
| Unique                | `Não`                                                                   |

---

### `NR_IDFR_RCM`

| Propriedade           | Valor                                                                        |
| --------------------- | ---------------------------------------------------------------------------- |
| Nome lógico           | Número Identificador Recomendação                                            |
| Tipo                  | `BIGINT`                                                                     |
| Chave primária lógica | `Sim`                                                                        |
| Aceita nulo           | `Não (0%)`                                                                   |
| Descrição             | Identifica a recomendação acompanhada pela rotina de vinculação.             |
| Comentário SQL        | `#PK` + identificação da recomendação acompanhada pela rotina de vinculação. |
| Unique                | `Não`                                                                        |

---

### `NR_VRS_VLDD_RCM`

| Propriedade           | Valor                                                                                  |
| --------------------- | -------------------------------------------------------------------------------------- |
| Nome lógico           | Número Versão Validada Recomendação                                                    |
| Tipo                  | `SMALLINT`                                                                             |
| Chave primária lógica | `Sim`                                                                                  |
| Aceita nulo           | `Não (0%)`                                                                             |
| Descrição             | Identifica a versão validada da recomendação considerada operacionalmente.             |
| Comentário SQL        | `#PK` + identificação da versão validada da recomendação considerada operacionalmente. |
| Unique                | `Não`                                                                                  |

---

### `CD_EST_RCM`

| Propriedade           | Valor                                                                                            |
| --------------------- | ------------------------------------------------------------------------------------------------ |
| Nome lógico           | Código Estado Recomendação                                                                       |
| Tipo                  | `SMALLINT`                                                                                       |
| Chave primária lógica | `Não`                                                                                            |
| Aceita nulo           | `Não (0%)`                                                                                       |
| Descrição             | Indica a situação da recomendação no processo de negócio.                                        |
| Domínio               | `1` - Em preparação; `2` - Aguardando vigência; `3` - Vigente; `4` - Expirada; `5` - Finalizada. |
| Unique                | `Não`                                                                                            |

---

### `CD_EST_VRS_RCM`

| Propriedade           | Valor                                                                |
| --------------------- | -------------------------------------------------------------------- |
| Nome lógico           | Código Estado Versão Recomendação                                    |
| Tipo                  | `SMALLINT`                                                           |
| Chave primária lógica | `Não`                                                                |
| Aceita nulo           | `Não (0%)`                                                           |
| Descrição             | Indica a situação da versão da recomendação considerada pela rotina. |
| Domínio               | `1` - Aguardando aprovação; `2` - Aprovado; `3` - Reprovado.         |
| Unique                | `Não`                                                                |

---

### `IN_REG_ATU`

| Propriedade           | Valor                                                             |
| --------------------- | ----------------------------------------------------------------- |
| Nome lógico           | Indicador Registro Atual                                          |
| Tipo                  | `CHAR(1)`                                                         |
| Chave primária lógica | `Não`                                                             |
| Aceita nulo           | `Não (0%)`                                                        |
| Descrição             | Indica se o registro representa a situação atual da recomendação. |
| Domínio               | `S` - Sim; `N` - Não.                                             |
| Unique                | `Não`                                                             |

> ⚠️ **Atenção:** por ser natureza `IN`, deve conter apenas `S` ou `N`, não aceita nulo e deve permanecer como `CHAR(1)`.

---

### `IN_EXEA_PND`

| Propriedade           | Valor                                                                              |
| --------------------- | ---------------------------------------------------------------------------------- |
| Nome lógico           | Indicador Execução Pendente                                                        |
| Tipo                  | `CHAR(1)`                                                                          |
| Chave primária lógica | `Não`                                                                              |
| Aceita nulo           | `Não (0%)`                                                                         |
| Descrição             | Indica se a recomendação está pendente de processamento pela rotina de vinculação. |
| Domínio               | `S` - Sim; `N` - Não.                                                              |
| Unique                | `Não`                                                                              |

---

### `TS_INC_REG`

| Propriedade           | Valor                                                    |
| --------------------- | -------------------------------------------------------- |
| Nome lógico           | Timestamp Início Registro                                |
| Tipo                  | `TIMESTAMP`                                              |
| Chave primária lógica | `Não`                                                    |
| Aceita nulo           | `Não (0%)`                                               |
| Descrição             | Timestamp de início do registro no controle operacional. |
| Unique                | `Não`                                                    |

---

### `NM_RCM_PDRO`

| Propriedade           | Valor                                                     |
| --------------------- | --------------------------------------------------------- |
| Nome lógico           | Nome Recomendação Padrão                                  |
| Tipo                  | `VARCHAR(500)`                                            |
| Chave primária lógica | `Não`                                                     |
| Aceita nulo           | `Não (0%)`                                                |
| Descrição             | Nome cadastral utilizado para identificar a recomendação. |
| Unique                | `Não`                                                     |

---

### `TX_DCR_RCM`

| Propriedade           | Valor                                                        |
| --------------------- | ------------------------------------------------------------ |
| Nome lógico           | Texto Descrição Recomendação                                 |
| Tipo                  | `VARCHAR(750)`                                               |
| Chave primária lógica | `Não`                                                        |
| Aceita nulo           | `Não (0%)`                                                   |
| Descrição             | Descrição cadastral da recomendação acompanhada pela rotina. |
| Unique                | `Não`                                                        |

---

### `NR_IDFR_AVS_SELD`

| Propriedade           | Valor                                                    |
| --------------------- | -------------------------------------------------------- |
| Nome lógico           | Número Identificador Aviso Selecionado                   |
| Tipo                  | `BIGINT`                                                 |
| Chave primária lógica | `Não`                                                    |
| Aceita nulo           | `Não (0%)`                                               |
| Descrição             | Identifica o aviso selecionado associado à recomendação. |
| Unique                | `Não`                                                    |

---

### `NR_IDFR_PBCO`

| Propriedade           | Valor                                                      |
| --------------------- | ---------------------------------------------------------- |
| Nome lógico           | Número Identificador Público                               |
| Tipo                  | `BIGINT`                                                   |
| Chave primária lógica | `Não`                                                      |
| Aceita nulo           | `Não (0%)`                                                 |
| Descrição             | Identifica o público de clientes associado à recomendação. |
| Unique                | `Não`                                                      |

---

### `NR_IDFR_SGT`

| Propriedade           | Valor                                                                                                                                                                                 |
| --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Nome lógico           | Número Identificador Sugestão                                                                                                                                                         |
| Tipo                  | `BIGINT`                                                                                                                                                                              |
| Chave primária lógica | `Não`                                                                                                                                                                                 |
| Aceita nulo           | `Não (0%)`                                                                                                                                                                            |
| Descrição             | Identifica a sugestão associada à recomendação ou ao aviso selecionado. Para recomendações ainda não aptas à vinculação, o fluxo deve padronizar valor de controle e não gravar nulo. |
| Unique                | `Não`                                                                                                                                                                                 |

---

### `TX_TIT_PDRO_AVS`

| Propriedade           | Valor                                                            |
| --------------------- | ---------------------------------------------------------------- |
| Nome lógico           | Texto Título Padrão Aviso                                        |
| Tipo                  | `STRING`                                                         |
| Chave primária lógica | `Não`                                                            |
| Aceita nulo           | `Não (0%)`                                                       |
| Descrição             | Título padrão utilizado na composição do aviso finanças cliente. |
| Unique                | `Não`                                                            |

---

### `TX_STIT_PDRO_AVS`

| Propriedade           | Valor                                                                  |
| --------------------- | ---------------------------------------------------------------------- |
| Nome lógico           | Texto Subtítulo Padrão Aviso                                           |
| Tipo                  | `STRING`                                                               |
| Chave primária lógica | `Não`                                                                  |
| Aceita nulo           | `Não (0%)`                                                             |
| Descrição             | Subtítulo padrão utilizado como complemento do aviso finanças cliente. |
| Unique                | `Não`                                                                  |

---
### `TX_ACMT_PDRO_AVS`

| Propriedade           | Valor                                                             |
| --------------------- | ----------------------------------------------------------------- |
| Nome lógico           | Texto Acionamento Padrão Aviso                                    |
| Tipo                  | `STRING`                                                          |
| Chave primária lógica | `Não`                                                             |
| Aceita nulo           | `Não (0%)`                                                        |
| Descrição             | Texto principal utilizado como chamada do aviso finanças cliente. |
| Unique                | `Não`                                                             |

---

### `TX_PRPT_PRM_HDR_API`

| Propriedade           | Valor                                                                                                                               |
| --------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| Nome lógico           | Texto Proposta Parâmetro Header API                                                                                                 |
| Tipo                  | `STRING`                                                                                                                            |
| Chave primária lógica | `Não`                                                                                                                               |
| Aceita nulo           | `Sim (50%)`                                                                                                                         |
| Descrição             | Parâmetros utilizados para compor ou encaminhar o aviso por meio da API.                                                            |
| Regra condicional     | Deve ser preenchido quando houver parâmetro aplicável ao aviso. Pode ser nulo quando não houver parâmetro de acionamento associado. |
| Unique                | `Não`                                                                                                                               |

---

### `NM_DB_OGM`

| Propriedade           | Valor                                                                              |
| --------------------- | ---------------------------------------------------------------------------------- |
| Nome lógico           | Nome Banco de Dados Origem                                                         |
| Tipo                  | `CHAR(100)`                                                                        |
| Chave primária lógica | `Não`                                                                              |
| Aceita nulo           | `Não (0%)`                                                                         |
| Descrição             | Banco de dados onde estão os dados utilizados para identificar clientes elegíveis. |
| Unique                | `Não`                                                                              |

---

### `NM_TAB_OGM`

| Propriedade           | Valor                                                                      |
| --------------------- | -------------------------------------------------------------------------- |
| Nome lógico           | Nome Tabela Origem                                                         |
| Tipo                  | `CHAR(100)`                                                                |
| Chave primária lógica | `Não`                                                                      |
| Aceita nulo           | `Não (0%)`                                                                 |
| Descrição             | Tabela onde estão os dados utilizados para identificar clientes elegíveis. |
| Unique                | `Não`                                                                      |

---

### `CD_TIP_ECP_OGM`

| Propriedade           | Valor                                                                          |
| --------------------- | ------------------------------------------------------------------------------ |
| Nome lógico           | Código Tipo Escopo Origem                                                      |
| Tipo                  | `SMALLINT`                                                                     |
| Chave primária lógica | `Não`                                                                          |
| Aceita nulo           | `Não (0%)`                                                                     |
| Descrição             | Indica se a rotina deve considerar toda a origem ou apenas um recorte dela.    |
| Domínio               | `1` - Tabela inteira ou público único; `2` - Subconjunto por coluna de escopo. |
| Unique                | `Não`                                                                          |

---

### `CD_FMA_REF_OGM`

| Propriedade           | Valor                                                                                                                                          |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| Nome lógico           | Código Forma Referência Origem                                                                                                                 |
| Tipo                  | `CHAR(1)`                                                                                                                                      |
| Chave primária lógica | `Não`                                                                                                                                          |
| Aceita nulo           | `Não (0%)`                                                                                                                                     |
| Descrição             | Indica como a rotina controla a referência da origem no processamento.                                                                         |
| Domínio               | `D` - Data, quando a referência for a última data e hora da origem; `Q` - Quantidade, quando a referência for a quantidade de dados da origem. |
| Unique                | `Não`                                                                                                                                          |

> ⚠️ **Atenção:** os valores físicos aprovados são `D` e `Q`.

---

## 1.4 Campos com nulidade condicional comprovada

### `TS_FIM_REG`

| Propriedade           | Valor                                                                                    |
| --------------------- | ---------------------------------------------------------------------------------------- |
| Nome lógico           | Timestamp Fim Registro                                                                   |
| Tipo                  | `TIMESTAMP`                                                                              |
| Chave primária lógica | `Não`                                                                                    |
| Aceita nulo           | `Sim (50%)`                                                                              |
| Descrição             | Data e hora de encerramento da validade do registro.                                     |
| Regra condicional     | Deve ficar nulo enquanto `IN_REG_ATU = S`. Torna-se obrigatório quando `IN_REG_ATU = N`. |
| Unique                | `Não`                                                                                    |

---

### `NM_COL_ECP_OGM`

| Propriedade           | Valor                                                                                       |
| --------------------- | ------------------------------------------------------------------------------------------- |
| Nome lógico           | Nome Coluna Escopo Origem                                                                   |
| Tipo                  | `CHAR(100)`                                                                                 |
| Chave primária lógica | `Não`                                                                                       |
| Aceita nulo           | `Sim (50%)`                                                                                 |
| Descrição             | Coluna utilizada para restringir a origem ao público relacionado à recomendação.            |
| Regra condicional     | Obrigatória quando `CD_TIP_ECP_OGM = 2`. Pode ser nula somente quando `CD_TIP_ECP_OGM = 1`. |
| Unique                | `Não`                                                                                       |

---

### `TS_ULT_DT_OBSD_OGM`

| Propriedade           | Valor                                                                               |
| --------------------- | ----------------------------------------------------------------------------------- |
| Nome lógico           | Timestamp Última Data Observada Origem                                              |
| Tipo                  | `TIMESTAMP`                                                                         |
| Chave primária lógica | `Não`                                                                               |
| Aceita nulo           | `Sim (50%)`                                                                         |
| Descrição             | Data e hora mais recente identificada na origem durante a observação da rotina.     |
| Regra condicional     | Obrigatória quando `CD_FMA_REF_OGM = D`. Pode ser nula quando `CD_FMA_REF_OGM = Q`. |
| Unique                | `Não`                                                                               |

---

### `TS_ULT_DT_PRCD_OGM`

| Propriedade           | Valor                                                                                    |
| --------------------- | ---------------------------------------------------------------------------------------- |
| Nome lógico           | Timestamp Última Data Processada Origem                                                  |
| Tipo                  | `TIMESTAMP`                                                                              |
| Chave primária lógica | `Não`                                                                                    |
| Aceita nulo           | `Sim (50%)`                                                                              |
| Descrição             | Data e hora mais recente da origem já considerada com sucesso pela rotina de vinculação. |
| Regra condicional     | Obrigatória quando `CD_FMA_REF_OGM = D`. Pode ser nula quando `CD_FMA_REF_OGM = Q`.      |
| Unique                | `Não`                                                                                    |

---

### `QT_DADO_OGM`

| Propriedade           | Valor                                                                               |
| --------------------- | ----------------------------------------------------------------------------------- |
| Nome lógico           | Quantidade Dado Origem                                                              |
| Tipo                  | `BIGINT`                                                                            |
| Chave primária lógica | `Não`                                                                               |
| Aceita nulo           | `Sim (50%)`                                                                         |
| Descrição             | Quantidade de dados da origem considerada no controle operacional.                  |
| Regra condicional     | Obrigatória quando `CD_FMA_REF_OGM = Q`. Pode ser nula quando `CD_FMA_REF_OGM = D`. |
| Unique                | `Não`                                                                               |

---

# 2. Tabela `RCM_FNC_CLI`

## 2.1 Identificação da tabela

| Item                           | Definição                                                               |
| ------------------------------ | ----------------------------------------------------------------------- |
| **Nome físico**                | `RCM_FNC_CLI`                                                           |
| **Natureza**                   | Visão operacional corrente dos avisos de finanças gerados para clientes |
| **Formato**                    | `PARQUET`                                                               |
| **Compressão**                 | `SNAPPY`                                                                |
| **Localização física**         | `/dados/corporativos/t21/hve/external/rcm_fnc_cli`                      |
| **Chave lógica**               | `CD_IDFR_AVS`, `CD_CLI`                                                 |
| **Periodicidade**              | Diária                                                                  |
| **Classificação de segurança** | Interna                                                                 |
| **Origem**                     | Ambiente Sistêmico                                                      |
| **Tempo de retenção**          | 10 anos                                                                 |
| **LGPD**                       | `ANDO_RCM_FNC_CLI`                                                      |
| **ModelAI**                    | S                                                                       |

## 2.2 Definição da entidade

Armazena a visão operacional corrente dos avisos de finanças gerados para clientes. Cada registro representa um aviso vigente para um cliente, com o conteúdo do aviso, a recomendação que o originou e a referência da origem considerada no processamento.

Os atributos do tipo decimal contidos nesta entidade terão como separador o ponto `.`.

**#PK:** Código Identificador Aviso, Código do Cliente

---

## 2.3 Campos obrigatórios

### `CD_IDFR_AVS`

| Propriedade           | Valor                                                                |
| --------------------- | -------------------------------------------------------------------- |
| Nome lógico           | Código Identificador Aviso                                           |
| Tipo                  | `CHAR(36)`                                                           |
| Chave primária lógica | `Sim`                                                                |
| Aceita nulo           | `Não (0%)`                                                           |
| Descrição             | Identifica o aviso finanças gerado para a recomendação.              |
| Regra de formato      | Formato lógico: `NR_IDFR_PROJ + "_" + NR_IDFR_RCM`. Exemplo: `1_25`. |
| Comentário SQL        | `#PK` + identificação do aviso finanças gerado para a recomendação.  |
| Unique                | `Não`                                                                |

---

### `CD_CLI`

| Propriedade           | Valor                                                     |
| --------------------- | --------------------------------------------------------- |
| Nome lógico           | Código do Cliente                                         |
| Tipo                  | `INT`                                                     |
| Chave primária lógica | `Sim`                                                     |
| Aceita nulo           | `Não (0%)`                                                |
| Descrição             | Código do cliente que recebe o aviso de finanças.         |
| Comentário SQL        | `#PK` + código do cliente que recebe o aviso de finanças. |
| Unique                | `Não`                                                     |

---

### `DT_AVS_FNC_CLI`

| Propriedade           | Valor                                                                     |
| --------------------- | ------------------------------------------------------------------------- |
| Nome lógico           | Data Aviso Finanças Cliente                                               |
| Tipo                  | `DATE`                                                                    |
| Chave primária lógica | `Não`                                                                     |
| Aceita nulo           | `Não (0%)`                                                                |
| Descrição             | Data em que o aviso finanças foi disponibilizado ou vinculado ao cliente. |
| Unique                | `Não`                                                                     |

---

### `NR_IDFR_PROJ`

| Propriedade           | Valor                                                      |
| --------------------- | ---------------------------------------------------------- |
| Nome lógico           | Número Identificador Projeto                               |
| Tipo                  | `BIGINT`                                                   |
| Chave primária lógica | `Não`                                                      |
| Aceita nulo           | `Não (0%)`                                                 |
| Descrição             | Identifica o projeto que originou a recomendação do aviso. |
| Unique                | `Não`                                                      |

---

### `NR_IDFR_RCM`

| Propriedade           | Valor                                           |
| --------------------- | ----------------------------------------------- |
| Nome lógico           | Número Identificador Recomendação               |
| Tipo                  | `BIGINT`                                        |
| Chave primária lógica | `Não`                                           |
| Aceita nulo           | `Não (0%)`                                      |
| Descrição             | Identifica a recomendação que originou o aviso. |
| Unique                | `Não`                                           |

---

### `NR_VRS_VLDD_RCM`

| Propriedade           | Valor                                                                      |
| --------------------- | -------------------------------------------------------------------------- |
| Nome lógico           | Número Versão Validada Recomendação                                        |
| Tipo                  | `SMALLINT`                                                                 |
| Chave primária lógica | `Não`                                                                      |
| Aceita nulo           | `Não (0%)`                                                                 |
| Descrição             | Identifica a versão validada da recomendação utilizada para gerar o aviso. |
| Unique                | `Não`                                                                      |

---

### `NR_IDFR_AVS_SELD`

| Propriedade           | Valor                                                                      |
| --------------------- | -------------------------------------------------------------------------- |
| Nome lógico           | Número Identificador Aviso Selecionado                                     |
| Tipo                  | `BIGINT`                                                                   |
| Chave primária lógica | `Não`                                                                      |
| Aceita nulo           | `Não (0%)`                                                                 |
| Descrição             | Identifica o aviso padrão utilizado como base para gerar o aviso finanças. |
| Unique                | `Não`                                                                      |

---

### `NR_IDFR_PBCO`

| Propriedade           | Valor                                                   |
| --------------------- | ------------------------------------------------------- |
| Nome lógico           | Número Identificador Público                            |
| Tipo                  | `BIGINT`                                                |
| Chave primária lógica | `Não`                                                   |
| Aceita nulo           | `Não (0%)`                                              |
| Descrição             | Identifica o público da recomendação que gerou o aviso. |
| Unique                | `Não`                                                   |

---

### `NR_IDFR_SGT`

| Propriedade           | Valor                                                                   |
| --------------------- | ----------------------------------------------------------------------- |
| Nome lógico           | Número Identificador Sugestão                                           |
| Tipo                  | `BIGINT`                                                                |
| Chave primária lógica | `Não`                                                                   |
| Aceita nulo           | `Não (0%)`                                                              |
| Descrição             | Identifica a sugestão associada à recomendação ou ao aviso selecionado. |
| Unique                | `Não`                                                                   |

---

### `CD_EST_VRS_RCM`

| Propriedade           | Valor                                                                     |
| --------------------- | ------------------------------------------------------------------------- |
| Nome lógico           | Código Estado Versão Recomendação                                         |
| Tipo                  | `SMALLINT`                                                                |
| Chave primária lógica | `Não`                                                                     |
| Aceita nulo           | `Não (0%)`                                                                |
| Descrição             | Indica a situação da versão da recomendação utilizada para gerar o aviso. |
| Domínio               | `1` - Aguardando aprovação; `2` - Aprovado; `3` - Reprovado.              |
| Unique                | `Não`                                                                     |

---

### `TX_TIT_PDRO_AVS`

| Propriedade           | Valor                                       |
| --------------------- | ------------------------------------------- |
| Nome lógico           | Texto Título Padrão Aviso                   |
| Tipo                  | `STRING`                                    |
| Chave primária lógica | `Não`                                       |
| Aceita nulo           | `Não (0%)`                                  |
| Descrição             | Título utilizado no aviso finanças cliente. |
| Unique                | `Não`                                       |

---

### `TX_STIT_PDRO_AVS`

| Propriedade           | Valor                                          |
| --------------------- | ---------------------------------------------- |
| Nome lógico           | Texto Subtítulo Padrão Aviso                   |
| Tipo                  | `STRING`                                       |
| Chave primária lógica | `Não`                                          |
| Aceita nulo           | `Não (0%)`                                     |
| Descrição             | Subtítulo utilizado no aviso finanças cliente. |
| Unique                | `Não`                                          |

---

### `TX_ACMT_PDRO_AVS`

| Propriedade           | Valor                                                             |
| --------------------- | ----------------------------------------------------------------- |
| Nome lógico           | Texto Acionamento Padrão Aviso                                    |
| Tipo                  | `STRING`                                                          |
| Chave primária lógica | `Não`                                                             |
| Aceita nulo           | `Não (0%)`                                                        |
| Descrição             | Texto principal utilizado como chamada do aviso finanças cliente. |
| Unique                | `Não`                                                             |

---

### `TX_PRM_HDR_API_AVS`

| Propriedade           | Valor                                                                                 |
| --------------------- | ------------------------------------------------------------------------------------- |
| Nome lógico           | Texto Parâmetro Header API Aviso                                                      |
| Tipo                  | `STRING`                                                                              |
| Chave primária lógica | `Não`                                                                                 |
| Aceita nulo           | `Sim (50%)`                                                                           |
| Descrição             | Parâmetros utilizados para encaminhar o aviso por meio da API.                        |
| Regra condicional     | Deve ser preenchido apenas quando houver parâmetro de acionamento associado ao aviso. |
| Unique                | `Não`                                                                                 |

---

### `PC_NVL_CNFA_AVS`

| Propriedade           | Valor                                                          |
| --------------------- | -------------------------------------------------------------- |
| Nome lógico           | Percentual Nível Confiança Aviso                               |
| Tipo                  | `DECIMAL(4,2)`                                                 |
| Chave primária lógica | `Não`                                                          |
| Aceita nulo           | `Não (0%)`                                                     |
| Descrição             | Percentual que indica o nível de confiança atribuído ao aviso. |
| Unique                | `Não`                                                          |

> ⚠️ **Atenção:** os atributos do tipo decimal contidos nesta entidade terão como separador o ponto `.`.

---

### `NM_DB_OGM`

| Propriedade           | Valor                                                                              |
| --------------------- | ---------------------------------------------------------------------------------- |
| Nome lógico           | Nome Banco de Dados Origem                                                         |
| Tipo                  | `CHAR(100)`                                                                        |
| Chave primária lógica | `Não`                                                                              |
| Aceita nulo           | `Não (0%)`                                                                         |
| Descrição             | Banco de dados onde estão os dados utilizados para identificar o cliente elegível. |
| Unique                | `Não`                                                                              |

---

### `NM_TAB_OGM`

| Propriedade           | Valor                                                                      |
| --------------------- | -------------------------------------------------------------------------- |
| Nome lógico           | Nome Tabela Origem                                                         |
| Tipo                  | `CHAR(100)`                                                                |
| Chave primária lógica | `Não`                                                                      |
| Aceita nulo           | `Não (0%)`                                                                 |
| Descrição             | Tabela onde estão os dados utilizados para identificar o cliente elegível. |
| Unique                | `Não`                                                                      |

---

### `CD_TIP_ECP_OGM`

| Propriedade           | Valor                                                                          |
| --------------------- | ------------------------------------------------------------------------------ |
| Nome lógico           | Código Tipo Escopo Origem                                                      |
| Tipo                  | `SMALLINT`                                                                     |
| Chave primária lógica | `Não`                                                                          |
| Aceita nulo           | `Não (0%)`                                                                     |
| Descrição             | Indica se a rotina considerou toda a origem ou apenas um recorte dela.         |
| Domínio               | `1` - Tabela inteira ou público único; `2` - Subconjunto por coluna de escopo. |
| Unique                | `Não`                                                                          |

---

### `CD_FMA_REF_OGM`

| Propriedade           | Valor                                                                                                                                          |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| Nome lógico           | Código Forma Referência Origem                                                                                                                 |
| Tipo                  | `CHAR(1)`                                                                                                                                      |
| Chave primária lógica | `Não`                                                                                                                                          |
| Aceita nulo           | `Não (0%)`                                                                                                                                     |
| Descrição             | Indica como a rotina controlou a referência da origem no processamento.                                                                        |
| Domínio               | `D` - Data, quando a referência for a última data e hora da origem; `Q` - Quantidade, quando a referência for a quantidade de dados da origem. |
| Unique                | `Não`                                                                                                                                          |

> ⚠️ **Atenção:** os valores físicos aprovados são `D` e `Q`.

---

## 2.4 Campos com nulidade condicional comprovada

### `NM_COL_ECP_OGM`

| Propriedade           | Valor                                                                                       |
| --------------------- | ------------------------------------------------------------------------------------------- |
| Nome lógico           | Nome Coluna Escopo Origem                                                                   |
| Tipo                  | `CHAR(100)`                                                                                 |
| Chave primária lógica | `Não`                                                                                       |
| Aceita nulo           | `Sim (50%)`                                                                                 |
| Descrição             | Coluna utilizada para restringir a origem ao público da recomendação.                       |
| Regra condicional     | Obrigatória quando `CD_TIP_ECP_OGM = 2`. Pode ser nula somente quando `CD_TIP_ECP_OGM = 1`. |
| Unique                | `Não`                                                                                       |

---

### `TS_ULT_DT_PRCD_OGM`

| Propriedade           | Valor                                                                               |
| --------------------- | ----------------------------------------------------------------------------------- |
| Nome lógico           | Timestamp Última Data Processada Origem                                             |
| Tipo                  | `TIMESTAMP`                                                                         |
| Chave primária lógica | `Não`                                                                               |
| Aceita nulo           | `Sim (50%)`                                                                         |
| Descrição             | Data e hora mais recente da origem considerada na geração do aviso finanças.        |
| Regra condicional     | Obrigatória quando `CD_FMA_REF_OGM = D`. Pode ser nula quando `CD_FMA_REF_OGM = Q`. |
| Unique                | `Não`                                                                               |

---

### `QT_DADO_OGM`

| Propriedade           | Valor                                                                               |
| --------------------- | ----------------------------------------------------------------------------------- |
| Nome lógico           | Quantidade Dado Origem                                                              |
| Tipo                  | `BIGINT`                                                                            |
| Chave primária lógica | `Não`                                                                               |
| Aceita nulo           | `Sim (50%)`                                                                         |
| Descrição             | Quantidade de dados da origem considerada na geração do aviso finanças.             |
| Regra condicional     | Obrigatória quando `CD_FMA_REF_OGM = Q`. Pode ser nula quando `CD_FMA_REF_OGM = D`. |
| Unique                | `Não`                                                                               |

---

# 3. Tabela `RCM_FNC_CLI_EVTL`

## 3.1 Identificação da tabela

| Item                           | Definição                                                             |
| ------------------------------ | --------------------------------------------------------------------- |
| **Nome físico**                | `RCM_FNC_CLI_EVTL`                                                    |
| **Natureza**                   | Visão histórica/eventual dos avisos de finanças gerados para clientes |
| **Formato**                    | `ORC`                                                                 |
| **Compressão**                 | `ZLIB`                                                                |
| **Localização física**         | `/dados/corporativos/t21/hve/external/rcm_fnc_cli_evtl`               |
| **Chave lógica**               | `CD_IDFR_AVS`, `CD_CLI`, `DT_AVS_FNC_CLI`                             |
| **Periodicidade**              | Eventual                                                              |
| **Classificação de segurança** | Interna                                                               |
| **Origem**                     | Ambiente Sistêmico                                                    |
| **Tempo de retenção**          | 10 anos                                                               |
| **LGPD**                       | `ANDO_RCM_FNC_CLI_EVT`                                                |
| **ModelAI**                    | S                                                                     |

## 3.2 Definição da entidade

Armazena a visão histórica/eventual dos avisos de finanças gerados para clientes. Cada registro preserva o resultado de uma execução diária da rotina para um aviso e cliente, permitindo consulta histórica, reconstrução da visão operacional e uso analítico por data, projeto e recomendação.

A tabela mantém o mesmo desenho da `RCM_FNC_CLI` para facilitar reconstrução, comparação, rastreabilidade e conversa direta com a visão operacional.

Os atributos do tipo decimal contidos nesta entidade terão como separador o ponto `.`.

**#PK:** Código Identificador Aviso, Código do Cliente, Data Aviso Finanças Cliente

---

## 3.3 Campos obrigatórios

> ✅ **Regra estrutural:** os campos obrigatórios de `RCM_FNC_CLI_EVTL` são os mesmos de `RCM_FNC_CLI`, na mesma ordem e com os mesmos tipos. A diferença estrutural principal é que `DT_AVS_FNC_CLI` compõe a chave lógica da tabela histórica/eventual.

### Diferenças de chave lógica em relação à `RCM_FNC_CLI`

| Campo            | `RCM_FNC_CLI`      | `RCM_FNC_CLI_EVTL` | Observação                                                        |
| ---------------- | ------------------ | ------------------ | ----------------------------------------------------------------- |
| `CD_IDFR_AVS`    | Chave lógica `Sim` | Chave lógica `Sim` | Identifica o aviso finanças gerado para a recomendação.           |
| `CD_CLI`         | Chave lógica `Sim` | Chave lógica `Sim` | Identifica o cliente que recebe o aviso de finanças.              |
| `DT_AVS_FNC_CLI` | Chave lógica `Não` | Chave lógica `Sim` | Na tabela histórica/eventual, é a data de referência do registro. |

---

### Campos da `RCM_FNC_CLI_EVTL`

| Ordem | Campo                | Nome lógico                             | Tipo           | Chave lógica | Aceita nulo | Observação                                                                                                  |
| ----: | -------------------- | --------------------------------------- | -------------- | ------------ | ----------- | ----------------------------------------------------------------------------------------------------------- |
|     1 | `CD_IDFR_AVS`        | Código Identificador Aviso              | `CHAR(36)`     | `Sim`        | `Não (0%)`  | Identifica o aviso finanças gerado para a recomendação.                                                     |
|     2 | `CD_CLI`             | Código do Cliente                       | `INT`          | `Sim`        | `Não (0%)`  | Código do cliente que recebe o aviso de finanças.                                                           |
|     3 | `DT_AVS_FNC_CLI`     | Data Aviso Finanças Cliente             | `DATE`         | `Sim`        | `Não (0%)`  | Data de referência para dados históricos e data em que o aviso foi disponibilizado ou vinculado ao cliente. |
|     4 | `NR_IDFR_PROJ`       | Número Identificador Projeto            | `BIGINT`       | `Não`        | `Não (0%)`  | Identifica o projeto que originou a recomendação do aviso.                                                  |
|     5 | `NR_IDFR_RCM`        | Número Identificador Recomendação       | `BIGINT`       | `Não`        | `Não (0%)`  | Identifica a recomendação que originou o aviso.                                                             |
|     6 | `NR_VRS_VLDD_RCM`    | Número Versão Validada Recomendação     | `SMALLINT`     | `Não`        | `Não (0%)`  | Identifica a versão validada da recomendação utilizada para gerar o aviso.                                  |
|     7 | `NR_IDFR_AVS_SELD`   | Número Identificador Aviso Selecionado  | `BIGINT`       | `Não`        | `Não (0%)`  | Identifica o aviso padrão utilizado como base para gerar o aviso finanças.                                  |
|     8 | `NR_IDFR_PBCO`       | Número Identificador Público            | `BIGINT`       | `Não`        | `Não (0%)`  | Identifica o público da recomendação que gerou o aviso.                                                     |
|     9 | `NR_IDFR_SGT`        | Número Identificador Sugestão           | `BIGINT`       | `Não`        | `Não (0%)`  | Identifica a sugestão associada à recomendação ou ao aviso selecionado.                                     |
|    10 | `CD_EST_VRS_RCM`     | Código Estado Versão Recomendação       | `SMALLINT`     | `Não`        | `Não (0%)`  | `1` - Aguardando aprovação; `2` - Aprovado; `3` - Reprovado.                                                |
|    11 | `TX_TIT_PDRO_AVS`    | Texto Título Padrão Aviso               | `STRING`       | `Não`        | `Não (0%)`  | Título utilizado no aviso finanças cliente.                                                                 |
|    12 | `TX_STIT_PDRO_AVS`   | Texto Subtítulo Padrão Aviso            | `STRING`       | `Não`        | `Não (0%)`  | Subtítulo utilizado no aviso finanças cliente.                                                              |
|    13 | `TX_ACMT_PDRO_AVS`   | Texto Acionamento Padrão Aviso          | `STRING`       | `Não`        | `Não (0%)`  | Texto principal utilizado como chamada do aviso finanças cliente.                                           |
|    14 | `TX_PRM_HDR_API_AVS` | Texto Parâmetro Header API Aviso        | `STRING`       | `Não`        | `Sim (50%)` | Parâmetro de API, quando houver parâmetro de acionamento associado ao aviso.                                |
|    15 | `PC_NVL_CNFA_AVS`    | Percentual Nível Confiança Aviso        | `DECIMAL(4,2)` | `Não`        | `Não (0%)`  | Percentual que indica o nível de confiança atribuído ao aviso.                                              |
|    16 | `NM_DB_OGM`          | Nome Banco de Dados Origem              | `CHAR(100)`    | `Não`        | `Não (0%)`  | Banco de dados onde estão os dados utilizados para identificar o cliente elegível.                          |
|    17 | `NM_TAB_OGM`         | Nome Tabela Origem                      | `CHAR(100)`    | `Não`        | `Não (0%)`  | Tabela onde estão os dados utilizados para identificar o cliente elegível.                                  |
|    18 | `CD_TIP_ECP_OGM`     | Código Tipo Escopo Origem               | `SMALLINT`     | `Não`        | `Não (0%)`  | `1` - Tabela inteira ou público único; `2` - Subconjunto por coluna de escopo.                              |
|    19 | `CD_FMA_REF_OGM`     | Código Forma Referência Origem          | `CHAR(1)`      | `Não`        | `Não (0%)`  | `D` - Data; `Q` - Quantidade.                                                                               |
|    20 | `NM_COL_ECP_OGM`     | Nome Coluna Escopo Origem               | `CHAR(100)`    | `Não`        | `Sim (50%)` | Obrigatória quando `CD_TIP_ECP_OGM = 2`. Pode ser nula somente quando `CD_TIP_ECP_OGM = 1`.                 |
|    21 | `TS_ULT_DT_PRCD_OGM` | Timestamp Última Data Processada Origem | `TIMESTAMP`    | `Não`        | `Sim (50%)` | Obrigatória quando `CD_FMA_REF_OGM = D`. Pode ser nula quando `CD_FMA_REF_OGM = Q`.                         |
|    22 | `QT_DADO_OGM`        | Quantidade Dado Origem                  | `BIGINT`       | `Não`        | `Sim (50%)` | Obrigatória quando `CD_FMA_REF_OGM = Q`. Pode ser nula quando `CD_FMA_REF_OGM = D`.                         |

---

## 3.4 Campos com nulidade condicional comprovada

Os campos com nulidade condicional em `RCM_FNC_CLI_EVTL` são os mesmos da `RCM_FNC_CLI`:

| Campo                | Tipo        | Aceita nulo | Regra condicional                                                                           |
| -------------------- | ----------- | ----------- | ------------------------------------------------------------------------------------------- |
| `TX_PRM_HDR_API_AVS` | `STRING`    | `Sim (50%)` | Deve ser preenchido apenas quando houver parâmetro de acionamento associado ao aviso.       |
| `NM_COL_ECP_OGM`     | `CHAR(100)` | `Sim (50%)` | Obrigatória quando `CD_TIP_ECP_OGM = 2`. Pode ser nula somente quando `CD_TIP_ECP_OGM = 1`. |
| `TS_ULT_DT_PRCD_OGM` | `TIMESTAMP` | `Sim (50%)` | Obrigatória quando `CD_FMA_REF_OGM = D`. Pode ser nula quando `CD_FMA_REF_OGM = Q`.         |
| `QT_DADO_OGM`        | `BIGINT`    | `Sim (50%)` | Obrigatória quando `CD_FMA_REF_OGM = Q`. Pode ser nula quando `CD_FMA_REF_OGM = D`.         |

---

# 4. Resumo visual das tabelas

| Tabela             | Papel                                                              | Formato   | Compressão | Chave lógica                                     | Nulidade condicional |
| ------------------ | ------------------------------------------------------------------ | --------- | ---------- | ------------------------------------------------ | -------------------- |
| `CTL_OPRL_RCM`     | Controle operacional da recomendação                               | `PARQUET` | `SNAPPY`   | `NR_IDFR_PROJ`, `NR_IDFR_RCM`, `NR_VRS_VLDD_RCM` | Sim                  |
| `RCM_FNC_CLI`      | Visão operacional corrente dos avisos de finanças por cliente      | `PARQUET` | `SNAPPY`   | `CD_IDFR_AVS`, `CD_CLI`                          | Sim                  |
| `RCM_FNC_CLI_EVTL` | Visão histórica/eventual dos avisos de finanças por cliente e data | `ORC`     | `ZLIB`     | `CD_IDFR_AVS`, `CD_CLI`, `DT_AVS_FNC_CLI`        | Sim                  |

---

# 5. Resumo das regras de comentários

| Tipo de campo                         | Padrão de comentário                                                        |
| ------------------------------------- | --------------------------------------------------------------------------- |
| Campo de chave lógica                 | Iniciar com `#PK` e explicar a entidade identificada.                       |
| Campo identificador                   | Começar com `Identifica...`.                                                |
| Campo de estado ou código com domínio | Explicar a função do código e listar os valores permitidos.                 |
| Campo indicador `IN_*`                | Explicar a pergunta representada pelo indicador e listar `S`/`N`.           |
| Campo de texto                        | Explicar qual conteúdo será gravado e em que contexto será usado.           |
| Campo de origem                       | Explicar a relação com os dados usados para identificar clientes elegíveis. |
| Campo com nulidade condicional        | Explicar quando é obrigatório e quando pode ser nulo.                       |
| Campo decimal                         | Explicar a métrica representada e preservar o tipo definido no DDL.         |

---

# 6. Observações finais de modelagem

* `CTL_OPRL_RCM` é a estrutura de controle operacional da rotina de vinculação.
* `RCM_FNC_CLI` representa a visão operacional corrente dos avisos de finanças gerados para clientes.
* `RCM_FNC_CLI_EVTL` representa a visão histórica/eventual dos avisos de finanças gerados para clientes.
* `RCM_FNC_CLI` e `RCM_FNC_CLI_EVTL` devem manter a mesma estrutura de atributos, tipos e ordem física.
* A diferença lógica entre `RCM_FNC_CLI` e `RCM_FNC_CLI_EVTL` está na chave: na tabela histórica/eventual, `DT_AVS_FNC_CLI` também compõe a chave lógica.
* Campos de controle, rastreabilidade, conteúdo e metadados operacionais devem evitar nulidade, salvo quando houver regra condicional explícita.
* Os campos `CD_FMA_REF_OGM`, `TS_ULT_DT_PRCD_OGM` e `QT_DADO_OGM` devem ser analisados em conjunto, pois a forma de referência da origem determina qual atributo representa o controle operacional do processamento.
