"""validators - Pluggable validation framework with OpenTelemetry instrumentation.

Each validator implements :class:`BaseValidator` and emits OTel spans + metrics
so that results flow to Azure Foundry via Application Insights automatically.

Validators locais e judges externos compartilham instrumentação sem conteúdo.
"""

from __future__ import annotations

import logging
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from opentelemetry import metrics, trace

logger = logging.getLogger(__name__)

# Service identity injected into every metric as extra dimensions.
# Set SERVICE_NAME and DEPLOY_ENV in the container/pod environment.
_SERVICE_NAME: str = os.getenv("SERVICE_NAME", "")
_DEPLOY_ENV: str = os.getenv("DEPLOY_ENV", "")  # desenv | homol | prod
_EXTRA_ATTRS: dict = {
    k: v
    for k, v in [("service.name", _SERVICE_NAME), ("deploy.environment", _DEPLOY_ENV)]
    if v
}

# Handles compartilhados de OTel dependem do provider configurado pelo runtime.
# A validação local substitui exporters externos por doubles ou memória.
_tracer = trace.get_tracer("agent.validators")
_meter = metrics.get_meter("agent.validators")

# Instrumentos comuns: cada validator é identificado por validator.name.
# O score é uma distribuição genérica; sua interpretação depende do validator.
_validation_counter = _meter.create_counter(
    "validator.invocations",
    description="Number of validator invocations",
)
_validation_pass_counter = _meter.create_counter(
    "validator.passed",
    description="Number of validations that passed",
)
_validation_fail_counter = _meter.create_counter(
    "validator.failed",
    description="Number of validations that failed (blocked or flagged)",
)
_validation_score_histogram = _meter.create_histogram(
    "validator.score",
    description="Validator confidence score distribution (0-1)",
)
_validation_latency = _meter.create_histogram(
    "validator.latency_ms",
    description="Validator execution latency in milliseconds",
)


class ValidatorAction(str, Enum):
    """What the system should do when a validator fails."""
    BLOCK = "block"
    REDACT = "redact"
    LOG_ONLY = "log_only"


@dataclass
class ValidationResult:
    """Outcome of a single validator execution."""
    passed: bool
    validator_name: str
    score: float = 0.0          # scale depends on validator: risk-based (1=bad) or quality-based (1=good)
    action: ValidatorAction = ValidatorAction.LOG_ONLY
    details: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseValidator(ABC):
    """Contract for every validator.

    Subclasses implement ``_validate`` with their domain logic.
    The public ``validate`` method wraps it with OTel spans & metrics.
    """

    name: str = "base"
    default_action: ValidatorAction = ValidatorAction.LOG_ONLY
    threshold: float = 0.5

    def __init__(
        self,
        action: ValidatorAction | None = None,
        threshold: float | None = None,
    ):
        if action is not None:
            self.default_action = action
        if threshold is not None:
            self.threshold = threshold

    # -- hook da subclasse: a regra de domínio permanece separada da instrumentação --

    @abstractmethod
    def _validate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        """Run the validation logic. Return a :class:`ValidationResult`."""

    # -- entrada pública síncrona preservada para consumidores legados --

    def validate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        """Execute the validator with OTel tracing and metrics."""
        attrs = {"validator.name": self.name, **_EXTRA_ATTRS}

        with _tracer.start_as_current_span(f"validate.{self.name}", attributes=attrs) as span:
            t0 = time.perf_counter()
            try:
                result = self._validate(text, context)
            except Exception:
                logger.warning("Validator %s: internal_error", self.name)
                result = ValidationResult(
                    passed=True,  # fail-open
                    validator_name=self.name,
                    score=0.5,  # neutral
                    details="validator error",
                )
            elapsed_ms = (time.perf_counter() - t0) * 1000

            # Registra apenas resultado, score, ação e duração; detalhes livres
            # poderiam conter PII, chunks ou texto retornado pelo judge.
            span.set_attribute("validator.passed", result.passed)
            span.set_attribute("validator.score", result.score)
            span.set_attribute("validator.action", result.action.value)
            # Detalhes livres podem conter PII ou texto do judge; não são exportados.

            _validation_counter.add(1, attrs)
            _validation_latency.record(elapsed_ms, attrs)
            _validation_score_histogram.record(result.score, attrs)

            if result.passed:
                _validation_pass_counter.add(1, attrs)
            else:
                _validation_fail_counter.add(1, attrs)

            return result

    async def _avalidate(self, text: str, context=None) -> ValidationResult:
        """Hook assíncrono; subclasses com I/O sobrescrevem sem bloquear o event loop."""
        return self._validate(text, context)

    async def avalidate(self, text: str, context=None) -> ValidationResult:
        """Interface assíncrona usada pelo A0, com as mesmas medidas seguras."""
        attrs = {"validator.name": self.name, **_EXTRA_ATTRS}
        with _tracer.start_as_current_span(f"validate.{self.name}", attributes=attrs, record_exception=False) as span:
            started = time.perf_counter()
            try:
                result = await self._avalidate(text, context)
            except Exception:
                logger.warning("Validator %s: internal_error", self.name)
                result = ValidationResult(True, self.name, 0.5, details="validator error")
            span.set_attribute("validator.passed", result.passed)
            span.set_attribute("validator.score", result.score)
            span.set_attribute("validator.action", result.action.value)
            elapsed = (time.perf_counter() - started) * 1000
            span.set_attribute("validator.duration_ms", elapsed)
            _validation_counter.add(1, attrs)
            _validation_latency.record(elapsed, attrs)
            _validation_score_histogram.record(result.score, attrs)
            (_validation_pass_counter if result.passed else _validation_fail_counter).add(1, attrs)
            return result


class ValidatorPipeline:
    """Executa validators em sequência e coleta resultados.

    O pipeline permanece disponível para consumidores legados; o A0 chama
    explicitamente os validators pós-LLM de sua topologia determinística.
    """

    def __init__(self, validators: List[BaseValidator]):
        self._validators = validators

    def run(self, text: str, context: Dict[str, Any] | None = None) -> List[ValidationResult]:
        results: List[ValidationResult] = []
        for v in self._validators:
            results.append(v.validate(text, context))
        return results

    def run_until_block(
        self, text: str, context: Dict[str, Any] | None = None,
    ) -> tuple[List[ValidationResult], Optional[ValidationResult]]:
        """Run validators; stop early if one returns action=BLOCK and passed=False."""
        results: List[ValidationResult] = []
        for v in self._validators:
            r = v.validate(text, context)
            results.append(r)
            if not r.passed and r.action == ValidatorAction.BLOCK:
                return results, r
        return results, None
