"""context_precision.py - LLM-as-a-Judge validator for RAG context precision.

Uses an LLM to evaluate whether the retrieved context chunks are relevant
and sufficient to answer the user's query.

Score semantics:
    1.0 = context is highly relevant and sufficient
    0.0 = context is irrelevant or misleading

No A0 executa antes da geração; interface síncrona preservada para o legado.

Uses the same LLM provider configured in agent_config.yaml (via LLMFactory).
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List

from langchain_core.messages import HumanMessage, SystemMessage

from iaa_agent_mf_edu_fin.validators import BaseValidator, ValidationResult, ValidatorAction

logger = logging.getLogger(__name__)

# O judge retorna apenas score e justificativa curta; o score é observacional.
_SYSTEM_PROMPT = "You are a precise evaluator. Respond only with valid JSON."

_JUDGE_PROMPT = """Evaluate how relevant and useful the retrieved context is for answering the user's query.

Score from 0.0 to 1.0:
- 1.0 = Context is highly relevant, directly addresses the query, and is sufficient to formulate an answer.
- 0.7 = Context is mostly relevant with some useful information, but may have minor gaps.
- 0.4 = Context is partially relevant - some chunks relate to the topic but don't directly answer the query.
- 0.1 = Context is mostly irrelevant or misleading.
- 0.0 = Context has no relation to the query whatsoever.

Respond ONLY with valid JSON in this exact format:
{{"score": <float>, "reason": "<brief explanation>"}}

---
User Query: {query}

Retrieved Context Chunks:
{chunks}
"""


def _build_judge_llm():
    """Build a low-temperature LLM instance using the project's LLMFactory."""
    from iaa_agent_mf_edu_fin.llm import LLMFactory
    from iaa_agent_mf_edu_fin.config import get_config

    config = get_config()
    provider = config.llm.provider if hasattr(config, "llm") else "gateway_outbound"
    return LLMFactory.create(provider=provider, temperature=0.0, top_p=1.0)


def _parse_judge_response(content: str) -> tuple[float, str]:
    # A análise aceita JSON direto ou cercado por markdown, mas nunca usa
    # campos alternativos para inferir um score ausente.
    content = content.strip()
    if content.startswith("```json"):
        content = content[7:]
    elif content.startswith("```"):
        content = content[3:]
    if content.endswith("```"):
        content = content[:-3]
    content = content.strip()
    try:
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            return 0.0, "not a dict"
        # Mantém compatibilidade com respostas legadas que serializaram as chaves.
        score_val = parsed.get("score")
        if score_val is None and '"score"' in parsed:
            score_val = parsed.get('"score"')
        score = max(0.0, min(1.0, float(score_val) if score_val is not None else 0.0))
        reason = str(parsed.get("reason", parsed.get('"reason"', "")))
        return score, reason
    except Exception:
        logger.warning("Context precision: invalid_judge_json")
        return 0.0, "parse_error"


def _call_llm_judge(query: str, chunks: List[str]) -> tuple[float, Dict[str, Any]]:
    """Call the LLM to evaluate context precision. Returns (score, metadata)."""
    llm = _build_judge_llm()

    chunks_text = "\n---\n".join(
        f"[Chunk {i+1}]: {chunk[:500]}" for i, chunk in enumerate(chunks)
    )
    prompt = _JUDGE_PROMPT.format(query=query, chunks=chunks_text)

    response = llm.invoke([
        SystemMessage(content=_SYSTEM_PROMPT),
        HumanMessage(content=prompt),
    ])

    content = response.content if isinstance(response.content, str) else str(response.content)
    score, reason = _parse_judge_response(content)

    return score, {
        "reason": reason,
        "chunk_count": len(chunks),
        "method": "llm_as_judge",
    }


async def _call_llm_judge_async(query: str, chunks: List[str], llm=None) -> tuple[float, Dict[str, Any]]:
    """Transporte assíncrono com modelo da mesma instância do A0."""
    llm = llm if llm is not None else _build_judge_llm()

    chunks_text = "\n---\n".join(
        f"[Chunk {i+1}]: {chunk[:500]}" for i, chunk in enumerate(chunks)
    )
    prompt = _JUDGE_PROMPT.format(query=query, chunks=chunks_text)

    response = await llm.ainvoke([
        SystemMessage(content=_SYSTEM_PROMPT),
        HumanMessage(content=prompt),
    ])

    content = response.content if isinstance(response.content, str) else str(response.content)
    score, reason = _parse_judge_response(content)

    return score, {
        "reason": reason,
        "chunk_count": len(chunks),
        "method": "llm_as_judge_async",
    }


class ContextPrecisionValidator(BaseValidator):
    """Validates RAG retrieval quality using LLM-as-a-Judge.

    Pass ``context={"query": "...", "chunks": ["...", ...]}`` to ``validate()``.
    The ``text`` argument is ignored (use empty string).
    """

    # Esta é a métrica RAG atualmente usada no A0; não mede recall ou ranking.
    name = "context_precision"
    default_action = ValidatorAction.LOG_ONLY
    threshold = 0.3

    def _validate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        # Caminho síncrono preservado para consumidores legados e testes unitários.
        if context is None:
            return ValidationResult(
                passed=True, validator_name=self.name, score=1.0,
                details="no context provided - skipping",
            )

        query = context.get("query", "")
        chunks = context.get("chunks", [])

        if not query:
            return ValidationResult(
                passed=True, validator_name=self.name, score=1.0,
                details="no query in context - skipping",
            )

        if not chunks:
            return ValidationResult(
                passed=False, validator_name=self.name, score=0.0,
                action=self.default_action,
                details="no chunks retrieved",
                metadata={"reason": "empty_chunks"},
            )

        try:
            score, meta = _call_llm_judge(query, chunks)
        except Exception:
            logger.warning("LLM judge failed: judge_error")
            return ValidationResult(
                passed=True, validator_name=self.name, score=0.5,
                details="judge error (fail-open)",
                metadata={"error": "judge_error"},
            )

        passed = score >= self.threshold

        return ValidationResult(
            passed=passed,
            validator_name=self.name,
            score=score,
            action=self.default_action,
            details="llm_judge",
            metadata=meta,
        )

    async def _avalidate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        # O A0 usa este caminho assíncrono para compartilhar o transporte do provider.
        if context is None:
            return ValidationResult(
                passed=True, validator_name=self.name, score=1.0,
                details="no context provided - skipping",
            )

        query = context.get("query", "")
        chunks = context.get("chunks", [])

        if not query:
            return ValidationResult(
                passed=True, validator_name=self.name, score=1.0,
                details="no query in context - skipping",
            )

        if not chunks:
            return ValidationResult(
                passed=False, validator_name=self.name, score=0.0,
                action=self.default_action,
                details="no chunks retrieved",
                metadata={"reason": "empty_chunks"},
            )

        try:
            score, meta = await _call_llm_judge_async(query, chunks, context.get("judge_llm"))
        except Exception:
            logger.warning("LLM judge failed: judge_error")
            return ValidationResult(
                passed=True, validator_name=self.name, score=0.5,
                details="judge error (fail-open)",
                metadata={"error": "judge_error"},
            )

        passed = score >= self.threshold

        return ValidationResult(
            passed=passed,
            validator_name=self.name,
            score=score,
            action=self.default_action,
            details="llm_judge",
            metadata=meta,
        )
