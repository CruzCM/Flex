"""Testes unitários para iaa_agent_mf_edu_fin/graph.py - AgentFactory e AgentGraph."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.messages import AIMessage, HumanMessage

from iaa_agent_mf_edu_fin.graph import AgentFactory, AgentGraph


# ---------------------------------------------------------------------------
# Auxiliares
# ---------------------------------------------------------------------------


def _make_config(provider: str = "gateway_outbound"):
    """Retorna um objeto AgentConfig mínimo sem acessar o disco."""
    from iaa_agent_mf_edu_fin.config import (
        AgentConfig,
        GuardrailsConfig,
        LLMConfig,
        MCPAuthentication,
        MCPConfig,
        MCPServer,
        MCPTransport,
        Metadata,
        RAGConfig,
    )

    return AgentConfig(
        agent_id="test",
        agent_name="Test Agent",
        deployment="test",
        instructions="Be helpful.",
        agent_description="desc",
        temperature=0.7,
        top_p=0.95,
        mcp=MCPConfig(
            servers=[
                MCPServer(
                    name="local",
                    description="",
                    transport=MCPTransport(type="http", endpoint="http://localhost:9000/mcp"),
                    authentication=MCPAuthentication(type="none"),
                )
            ]
        ),
        metadata=Metadata(owner="team", version="0.1.0", created_at="2026-01-01"),
        llm=LLMConfig(provider=provider),
        guardrails=GuardrailsConfig(),
        rag=RAGConfig(),
    )


# ---------------------------------------------------------------------------
# AgentFactory._mcp_server_config
# ---------------------------------------------------------------------------


def test_mcp_server_config_no_token():
    cfg = _make_config()
    result = AgentFactory._mcp_server_config(cfg)
    assert "local" in result
    assert result["local"]["url"] == "http://localhost:9000/mcp"
    assert "headers" not in result["local"]


def test_mcp_server_config_with_bearer(monkeypatch):
    from iaa_agent_mf_edu_fin.config import MCPAuthentication

    monkeypatch.setenv("MY_TOKEN", "tok123")
    cfg = _make_config()
    cfg.mcp.servers[0].authentication = MCPAuthentication(
        type="bearer", token_env_var="MY_TOKEN"
    )
    result = AgentFactory._mcp_server_config(cfg)
    assert result["local"]["headers"] == {"Authorization": "Bearer tok123"}


# ---------------------------------------------------------------------------
# AgentFactory.create - falha de MCP degrada graciosamente
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_legacy_does_not_connect_when_mcp_is_disabled():
    cfg = _make_config()
    cfg.mcp.enabled = False
    mock_llm = MagicMock()
    mock_llm.ainvoke = AsyncMock(return_value=AIMessage(content="42"))

    with (
        patch("iaa_agent_mf_edu_fin.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_mf_edu_fin.graph.LLMFactory") as mock_factory,
    ):
        mock_factory.create.return_value = mock_llm
        compiled = await AgentFactory.create_legacy(cfg)

    assert hasattr(compiled, "ainvoke")
    mock_mcp_cls.assert_not_called()


@pytest.mark.asyncio
async def test_create_legacy_degrades_when_mcp_unavailable():
    cfg = _make_config()
    mock_llm = MagicMock()
    mock_llm.ainvoke = AsyncMock(return_value=AIMessage(content="42"))

    with (
        patch("iaa_agent_mf_edu_fin.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_mf_edu_fin.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(
            side_effect=ConnectionRefusedError("MCP down")
        )
        mock_factory.create.return_value = mock_llm
        compiled = await AgentFactory.create_legacy(cfg)

    assert hasattr(compiled, "ainvoke")
    mock_llm.bind_tools.assert_not_called()


@pytest.mark.asyncio
async def test_create_legacy_no_tools_graph_invokes_llm_directly():
    cfg = _make_config()
    ai_reply = AIMessage(content="hello")
    mock_llm = MagicMock()
    mock_llm.ainvoke = AsyncMock(return_value=ai_reply)

    with (
        patch("iaa_agent_mf_edu_fin.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_mf_edu_fin.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[])
        mock_factory.create.return_value = mock_llm

        compiled = await AgentFactory.create_legacy(cfg)
        result = await compiled.ainvoke({"messages": [HumanMessage(content="hi")]})

    assert "messages" in result
    assert result["messages"][-1].content == "hello"


@pytest.mark.asyncio
async def test_agent_graph_ainvoke():
    # Grafo A0 real; somente recuperação e modelos são doubles controlados.
    from iaa_agent_mf_edu_fin.config import load_agent_config
    from iaa_agent_mf_edu_fin.rag.rag_tool import RAGResponse, RAGResult
    cfg = load_agent_config()
    llm = MagicMock()
    llm.ainvoke = AsyncMock(return_value=AIMessage(content="The answer is 4."))
    with (
        patch("iaa_agent_mf_edu_fin.graph.get_config", return_value=cfg),
        patch("iaa_agent_mf_edu_fin.graph.LLMFactory.create", return_value=llm),
        patch("iaa_agent_mf_edu_fin.graph._call_gateway", new=AsyncMock(return_value=RAGResponse(["4"], RAGResult.SUCCESS))),
    ):
        result = await AgentGraph().ainvoke({"messages": [HumanMessage(content="orçamento")]})
    assert result["messages"][-1].content == "The answer is 4."
    assert result["rag_result"] == "success"


def test_agent_graph_invoke_sync():
    from unittest.mock import AsyncMock
    from langchain_core.messages import AIMessage
    ai_reply = AIMessage(content="sync reply")
    fake_result = {"messages": [ai_reply]}
    with patch("iaa_agent_mf_edu_fin.graph.AgentGraph.ainvoke", new=AsyncMock(return_value=fake_result)):
        g = AgentGraph()
        result = g.invoke({"messages": [HumanMessage(content="oi")]})
    assert result["messages"][-1].content == "sync reply"


@pytest.mark.asyncio
async def test_create_legacy_adds_rag_tool_when_enabled():
    cfg = _make_config()
    cfg.rag.enabled = True
    mock_llm = MagicMock()
    mock_llm.bind_tools = MagicMock(return_value=mock_llm)
    mock_llm.ainvoke = AsyncMock(return_value=AIMessage(content="ok"))

    with (
        patch("iaa_agent_mf_edu_fin.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_mf_edu_fin.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[])
        mock_factory.create.return_value = mock_llm
        await AgentFactory.create_legacy(cfg)

    mock_llm.bind_tools.assert_called_once()
    tools_passed = mock_llm.bind_tools.call_args[0][0]
    assert len(tools_passed) == 1
    assert tools_passed[0].name == "retrieve_context"


@pytest.mark.asyncio
async def test_create_legacy_system_message_prepended():
    cfg = _make_config()
    ai_reply = AIMessage(content="resposta")
    mock_llm = MagicMock()
    captured_messages: list = []

    async def _fake_ainvoke(messages):
        captured_messages.extend(messages)
        return ai_reply

    mock_llm.ainvoke = _fake_ainvoke

    with (
        patch("iaa_agent_mf_edu_fin.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_mf_edu_fin.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[])
        mock_factory.create.return_value = mock_llm
        compiled = await AgentFactory.create_legacy(cfg)
        await compiled.ainvoke({"messages": [HumanMessage(content="oi")]})

    from langchain_core.messages import SystemMessage
    assert isinstance(captured_messages[0], SystemMessage)
    assert cfg.instructions in captured_messages[0].content
