from src.domain import ConsultaDashboard
from src.providers import MockDashboardProvider


def consulta(cd_cli="123456"):
    return ConsultaDashboard(cd_cli=cd_cli, moeda="BRL")


def test_complete_contract_has_two_products():
    data = MockDashboardProvider().carregar(consulta(), cenario_mock="cliente_completo")
    assert data["meta"]["cliente_codigo"] == "123456"
    assert data["movimentacoes"]
    assert data["radar"]["fl_participa_radar"] == "S"
    assert len(data["radar"]["temas"]) == 5
    assert any(l["id"] == "clareza" for l in data["lentes"])


def test_query_filters_period_and_institution():
    q = ConsultaDashboard(
        cd_cli="777",
        periodo_inicio="2026-01-01",
        periodo_fim="2026-08-31",
        moeda="BRL",
        instituicoes=(101,),
    )
    data = MockDashboardProvider().carregar(q)
    assert data["movimentacoes"]
    assert all(t["instituicao"] == 101 for t in data["movimentacoes"])
    assert all("2026-01-01" <= t["data"] <= "2026-08-31" for t in data["movimentacoes"])


def test_adjusted_base_can_neutralize_identified_pairs():
    tx = MockDashboardProvider().carregar(consulta())["movimentacoes"]
    raw_entries = sum(t["valor"] for t in tx if t["natureza"] == "C")
    raw_exits = sum(t["valor"] for t in tx if t["natureza"] == "D")
    adj = [t for t in tx if t["identificacao_fluxo"] != "IDENTIFICADA"]
    adj_entries = sum(t["valor"] for t in adj if t["natureza"] == "C")
    adj_exits = sum(t["valor"] for t in adj if t["natureza"] == "D")
    assert raw_entries > adj_entries
    assert raw_exits > adj_exits
    assert round(raw_entries - raw_exits, 2) == round(adj_entries - adj_exits, 2)


def test_possible_and_unknown_are_not_removed_from_adjusted_base():
    tx = MockDashboardProvider().carregar(consulta())["movimentacoes"]
    adjusted = [t for t in tx if t["identificacao_fluxo"] != "IDENTIFICADA"]
    assert any(t["identificacao_fluxo"] == "POSSIVEL" for t in adjusted)
    assert any(t["identificacao_fluxo"] == "NAO_IDENTIFICADA" for t in adjusted)


def test_radar_unavailable_is_not_zero():
    radar = MockDashboardProvider().carregar(consulta(), cenario_mock="radar_indisponivel")["radar"]
    assert radar["fl_participa_radar"] == "N"
    assert radar["resultado_orcamentario"]["valor"] is None
    assert radar["temas"] == []


def test_lenses_keep_realized_reference_plan_separate():
    lenses = MockDashboardProvider().carregar(consulta())["lentes"]
    lens = next(x for x in lenses if x["id"] == "503020")
    assert lens["realizado"] != lens["referencia"]
    assert lens["plano_cliente"]["proveniencia"] == "PLANEJADO — MOCK"
