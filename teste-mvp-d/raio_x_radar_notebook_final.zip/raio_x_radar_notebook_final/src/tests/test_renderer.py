from src.domain import ConsultaDashboard
from src.providers import MockDashboardProvider
from src.renderer import render_dashboard


def dados():
    return MockDashboardProvider().carregar(ConsultaDashboard(cd_cli="123456"))


def test_preview_contains_final_navigation_and_sections():
    html = render_dashboard(dados(), full_html=True, include_plotly=False)
    assert "Raio-X financeiro" in html
    assert "Radar comportamental" in html
    assert "Diagnóstico em 30 segundos" in html
    assert "Caminho do dinheiro" in html
    assert "Onde existe concentração" in html
    assert "Resultado do Radar" in html
    assert "Explorar lentes" in html


def test_mock_warning_is_visible():
    html = render_dashboard(dados(), full_html=False, include_plotly=False)
    assert "Dados simulados para protótipo" in html
    assert "Nenhuma pontuação abaixo é resultado real do cliente" in html


def test_no_guided_journey_or_duplicate_explorer_modes():
    html = render_dashboard(dados(), full_html=False, include_plotly=False)
    assert "Jornada guiada" not in html
    assert "Explorar diretamente" not in html
