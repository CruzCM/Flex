from src.app import fluxo_dashboard


def test_public_function_requires_and_preserves_cd_cli():
    resultado = fluxo_dashboard("000123", exibir=False)
    assert resultado["cd_cli"] == "000123"
    assert resultado["dados"]["meta"]["cliente_codigo"] == "000123"
    assert "Raio-X financeiro" in resultado["html"]


def test_initial_radar_context_is_serialized():
    resultado = fluxo_dashboard(
        "123456",
        produto_inicial="radar",
        area_radar_inicial="lentes",
        exibir=False,
    )
    assert resultado["dados"]["ui"]["produto_inicial"] == "radar"
    assert resultado["dados"]["ui"]["area_radar_inicial"] == "lentes"
