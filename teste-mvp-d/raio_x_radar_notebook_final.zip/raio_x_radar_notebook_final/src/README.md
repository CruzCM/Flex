# Raio-X financeiro + Radar comportamental

## Estrutura de execução

```text
src/
requirements.txt
desenv.env
rotina-principal.ipynb
```

O front-end é gerado por Python e exibido dentro do notebook. O CSS está
embutido em `Visual.aplicar_estilo()` em `src/app.py`. Os gráficos Plotly são
incorporados à saída HTML; não existe site separado, servidor ou framework web.

## Chamada mínima

```python
from src.app import fluxo_dashboard

resultado = fluxo_dashboard(cd_cli="123456")
```

## Chamada com escopo

```python
resultado = fluxo_dashboard(
    cd_cli="123456",
    periodo_inicio="2025-09-01",
    periodo_fim="2026-08-31",
    moeda="BRL",
    instituicoes=[101, 202],
    produto_inicial="raio_x",
    base_inicial="ajustada",
)
```

## Provider produtivo

Implemente `src.providers.DashboardProvider` e injete a instância em
`fluxo_dashboard(provider=meu_provider)`. O renderer não depende de tabela,
SQL ou API específica.
