"""Provider mockado e determinístico.

Todos os valores exibidos no Resultado do Radar são identificados na interface
como ``Dados simulados para protótipo``. O provider pode ser trocado por um
adapter real sem alterar o renderer.
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from ..domain import ConsultaDashboard, Lente, Movimento, ResultadoRadar, TemaRadar
from .base import DashboardProvider

CLASSIFICACOES = {
    0: "Entradas e transferências a identificar",
    1: "Renda e benefícios recebidos",
    2: "Dinheiro devolvido ou ajustado",
    3: "Dinheiro retirado de investimentos",
    4: "Empréstimos e financiamentos recebidos",
    5: "Saídas e transferências a identificar",
    6: "Contas e gastos necessários",
    7: "Gastos que podem ser ajustados",
    8: "Dinheiro destinado ao futuro",
    9: "Dívidas, parcelas, juros e taxas",
}

CENARIOS = {
    "cliente_completo": "Cliente com doze meses, três instituições e Radar disponível",
    "cliente_parcial": "Cobertura transacional parcial e lentes com mais ressalvas",
    "radar_indisponivel": "Raio-X disponível e Resultado do Radar indisponível",
}


def listar_cenarios() -> dict[str, str]:
    return dict(CENARIOS)


def _months() -> list[str]:
    return [
        "2025-09", "2025-10", "2025-11", "2025-12",
        "2026-01", "2026-02", "2026-03", "2026-04",
        "2026-05", "2026-06", "2026-07", "2026-08",
    ]


def _build_movements() -> list[Movimento]:
    movements: list[Movimento] = []
    counter = 1

    def add(
        *, dt: str, descricao: str, instituicao: int, conta: str, produto: str,
        natureza: str, valor: float, grupo: str, categoria_original: str,
        categoria_vigente: str | None, macro: int, origem: str = "Motor de categorização",
        identificacao: str = "NAO_APLICAVEL", par: str | None = None,
        contraparte: int | None = None, confianca: float | None = None,
        marca: int | None = None, moeda: str = "BRL",
    ) -> None:
        nonlocal counter
        movements.append(Movimento(
            id=f"MOV-{counter:04d}",
            data=dt,
            mes=dt[:7],
            descricao_protegida=descricao,
            instituicao=instituicao,
            marca=marca or instituicao * 10 + 1,
            conta=conta,
            produto=produto,
            natureza=natureza,  # type: ignore[arg-type]
            valor=round(float(valor), 2),
            moeda=moeda,
            grupo_oficial=grupo,
            categoria_original=categoria_original,
            categoria_vigente=categoria_vigente or categoria_original,
            macroclasse=macro,
            macroclasse_nome=CLASSIFICACOES[macro],
            origem_categorizacao=origem,
            estado_movimentacao="EFETIVADA",
            identificacao_fluxo=identificacao,  # type: ignore[arg-type]
            par_interno_id=par,
            instituicao_contraparte=contraparte,
            confianca_identificacao=confianca,
        ))
        counter += 1

    months = _months()
    for idx, month in enumerate(months):
        base_day = date.fromisoformat(month + "-01")
        salary = 7700 + idx * 35
        add(dt=str(base_day + timedelta(days=4)), descricao="Crédito identificado •••• salário",
            instituicao=101, conta="•••• 4821", produto="Conta corrente", natureza="C",
            valor=salary, grupo="Receitas", categoria_original="Salário",
            categoria_vigente="Salário", macro=1)

        if idx in {2, 5, 8, 11}:
            add(dt=str(base_day + timedelta(days=9)), descricao="Crédito identificado •••• benefício",
                instituicao=101, conta="•••• 4821", produto="Conta corrente", natureza="C",
                valor=1150 + idx * 10, grupo="Receitas", categoria_original="Benefícios",
                categoria_vigente="Benefícios", macro=1)

        if idx in {1, 7}:
            add(dt=str(base_day + timedelta(days=12)), descricao="Crédito identificado •••• devolução",
                instituicao=202, conta="•••• 7714", produto="Conta corrente", natureza="C",
                valor=420 + idx * 15, grupo="Outros", categoria_original="Estorno e devolução",
                categoria_vigente="Reembolso", macro=2)

        if idx == 6:
            add(dt=str(base_day + timedelta(days=7)), descricao="Crédito identificado •••• resgate",
                instituicao=303, conta="•••• 9350", produto="Conta investimento", natureza="C",
                valor=3100, grupo="Investimentos", categoria_original="Resgate de investimento",
                categoria_vigente="Resgate de investimento", macro=3)

        # Transferência interna identificada: duas pontas, mesmo par.
        pair = f"TRI-{idx+1:02d}"
        transfer_value = 2100 + (idx % 3) * 180
        add(dt=str(base_day + timedelta(days=5)), descricao="Transferência protegida •••• saída entre contas",
            instituicao=101, conta="•••• 4821", produto="Conta corrente", natureza="D",
            valor=transfer_value, grupo="Outros", categoria_original="Transferências",
            categoria_vigente="Transferência entre contas", macro=5,
            identificacao="IDENTIFICADA", par=pair, contraparte=202, confianca=1.0)
        add(dt=str(base_day + timedelta(days=5)), descricao="Transferência protegida •••• entrada entre contas",
            instituicao=202, conta="•••• 7714", produto="Conta corrente", natureza="C",
            valor=transfer_value, grupo="Outros", categoria_original="Transferências",
            categoria_vigente="Transferência entre contas", macro=0,
            identificacao="IDENTIFICADA", par=pair, contraparte=101, confianca=1.0)

        # Movimentação interna possível: continua na base ajustada.
        if idx in {0, 3, 6, 9}:
            pair_possible = f"TRP-{idx+1:02d}"
            add(dt=str(base_day + timedelta(days=17)), descricao="Transferência protegida •••• possível saída interna",
                instituicao=101, conta="•••• 4821", produto="Conta corrente", natureza="D",
                valor=680 + idx * 7, grupo="Outros", categoria_original="Transferências",
                categoria_vigente="Transferência não confirmada", macro=5,
                identificacao="POSSIVEL", par=pair_possible, contraparte=303, confianca=.72)
            add(dt=str(base_day + timedelta(days=18)), descricao="Crédito protegido •••• possível contraparte",
                instituicao=303, conta="•••• 9350", produto="Conta investimento", natureza="C",
                valor=670 + idx * 7, grupo="Outros", categoria_original="Crédito não identificado",
                categoria_vigente="Crédito não identificado", macro=0,
                identificacao="POSSIVEL", par=pair_possible, contraparte=101, confianca=.68)

        # Saídas principais.
        expenses = [
            (202, "•••• 7714", "Casa", "Aluguel e condomínio", 6, 1850 + idx * 12, 8),
            (202, "•••• 7714", "Alimentação", "Feira e supermercado", 6, 930 + (idx % 4) * 70, 11),
            (101, "•••• 4821", "Transporte", "Combustível e mobilidade", 6, 510 + (idx % 5) * 45, 14),
            (202, "•••• 7714", "Lazer", "Restaurantes e entretenimento", 7, 480 + (idx % 3) * 95, 19),
            (303, "•••• 9350", "Investimentos", "Aplicações", 8, 720 + (idx % 4) * 110, 21),
            (101, "•••• 4821", "Tarifas e impostos", "Parcelas, juros e taxas", 9, 590 + (idx % 2) * 90, 24),
        ]
        for inst, conta, grupo, categoria, macro, valor, day in expenses:
            add(dt=str(base_day + timedelta(days=day)), descricao=f"Débito protegido •••• {categoria.lower()}",
                instituicao=inst, conta=conta, produto="Conta corrente" if inst != 303 else "Conta investimento",
                natureza="D", valor=valor, grupo=grupo, categoria_original=categoria,
                categoria_vigente=categoria, macro=macro)

        if idx in {2, 6, 10}:
            add(dt=str(base_day + timedelta(days=25)), descricao="Débito protegido •••• finalidade não identificada",
                instituicao=303, conta="•••• 9350", produto="Conta investimento", natureza="D",
                valor=760 + idx * 20, grupo="Outros", categoria_original="Sem categoria",
                categoria_vigente="Sem categoria", macro=5,
                origem="Fallback — sem categoria", identificacao="NAO_IDENTIFICADA")

        if idx in {4, 9}:
            add(dt=str(base_day + timedelta(days=22)), descricao="Débito protegido •••• categoria ampla",
                instituicao=101, conta="•••• 4821", produto="Conta corrente", natureza="D",
                valor=390 + idx * 12, grupo="Outros", categoria_original="Gastos Diversos",
                categoria_vigente="Gastos Diversos", macro=7,
                origem="Regra — categoria ampla", identificacao="NAO_IDENTIFICADA")

    return movements


def _radar(disponivel: bool = True) -> ResultadoRadar:
    if not disponivel:
        return ResultadoRadar(
            fl_participa_radar="N",
            motivo_indisponibilidade="Janela mensal insuficiente para executar os critérios do contrato mockado.",
            perfil_renda=None,
            macroperfil=None,
            microperfil=None,
            perfil_financeiro=None,
            resultado_orcamentario={"estado": "INDISPONIVEL", "valor": None},
            temas=[],
            periodo="Janela mensal simulada",
            moeda="BRL",
            cobertura="Dados insuficientes para o Resultado do Radar",
            limitacoes=["Ausência de dados suficientes não equivale a pontuação zero."],
        )

    themes = [
        TemaRadar(
            id="categorizacao", nome="Categorização de Gastos", pontuacao=72,
            percentual_observado=24.0, percentual_referencia=75.0,
            componentes=[
                {"nome": "PC_SAI_GEN", "valor": 24.0, "unidade": "%", "origem": "Campo simulado do contrato"},
                {"nome": "PC_REF_GEN", "valor": 75.0, "unidade": "%", "origem": "Referência simulada do contrato"},
            ],
            cobertura="Janela mensal simulada",
            limitacao="A pontuação pertence ao Radar legado e não representa a nova lente Clareza dos gastos.",
            formula_status="Contrato visual preparado; valores simulados para protótipo.",
        ),
        TemaRadar(
            id="orcamento", nome="Gestão de Orçamento", pontuacao=64,
            percentual_observado=81.5, percentual_referencia=80.0,
            componentes=[
                {"nome": "Indicador orçamentário A", "valor": 81.5, "unidade": "%", "origem": "Mock isolado"},
                {"nome": "Referência do tema", "valor": 80.0, "unidade": "%", "origem": "Mock isolado"},
            ],
            cobertura="Janela mensal simulada",
            limitacao="O Raio-X usa outra regra de diferença observada; os cálculos não são unificados.",
            formula_status="Fórmula real deve ser fornecida pelo adapter produtivo.",
        ),
        TemaRadar(
            id="consumo", nome="Consumo Planejado", pontuacao=58,
            percentual_observado=42.0, percentual_referencia=50.0,
            componentes=[
                {"nome": "Indicador de consumo", "valor": 42.0, "unidade": "%", "origem": "Mock isolado"},
                {"nome": "Referência do tema", "valor": 50.0, "unidade": "%", "origem": "Mock isolado"},
            ],
            cobertura="Janela mensal simulada",
            limitacao="A pontuação não autoriza afirmar intenção, planejamento ou disciplina do cliente.",
            formula_status="Fórmula real deve ser fornecida pelo adapter produtivo.",
        ),
        TemaRadar(
            id="reserva", nome="Formação de Reserva", pontuacao=69,
            percentual_observado=13.0, percentual_referencia=10.0,
            componentes=[
                {"nome": "Indicador de reserva", "valor": 13.0, "unidade": "%", "origem": "Mock isolado"},
                {"nome": "Referência do tema", "valor": 10.0, "unidade": "%", "origem": "Mock isolado"},
            ],
            cobertura="Janela mensal simulada",
            limitacao="Aplicação observada não comprova objetivo, reserva ou intenção sem confirmação.",
            formula_status="Fórmula real deve ser fornecida pelo adapter produtivo.",
        ),
        TemaRadar(
            id="credito", nome="Uso Consciente do Crédito", pontuacao=61,
            percentual_observado=18.0, percentual_referencia=30.0,
            componentes=[
                {"nome": "Participação de saídas relacionadas a crédito", "valor": 18.0, "unidade": "%", "origem": "Mock isolado"},
                {"nome": "Referência do tema", "valor": 30.0, "unidade": "%", "origem": "Mock isolado"},
            ],
            cobertura="Janela mensal simulada",
            limitacao="Participação nas saídas não é comprometimento da renda nem estoque de dívida.",
            formula_status="Fórmula real deve ser fornecida pelo adapter produtivo.",
        ),
    ]
    return ResultadoRadar(
        fl_participa_radar="S",
        motivo_indisponibilidade=None,
        perfil_renda="Perfil de renda R2 — valor simulado",
        macroperfil="Macroperfil M3 — valor simulado",
        microperfil="Microperfil 07 — valor simulado",
        perfil_financeiro="Perfil financeiro PF-04 — valor simulado",
        resultado_orcamentario={
            "estado": "RESULTADO_DISPONIVEL",
            "descricao": "Resultado orçamentário do contrato — valor simulado",
            "valor": 64,
            "unidade": "pontos",
        },
        temas=themes,
        periodo="Janela mensal simulada",
        moeda="BRL",
        cobertura="Contrato ANA_EDU_FIN_CLI representado por provider mockado",
        limitacoes=[
            "Não existe tema prioritário nem desempate calculado neste protótipo.",
            "As pontuações não são somadas às lentes e não produzem conclusão global.",
            "Todos os resultados desta área são simulados e não representam resultado real do cliente.",
        ],
    )


def _lenses(movements: list[Movimento], partial: bool = False) -> list[Lente]:
    debit_ids = [m.id for m in movements if m.natureza == "D"]
    unknown_ids = [m.id for m in movements if m.natureza == "D" and m.macroclasse == 5]
    known_value = sum(m.valor for m in movements if m.natureza == "D" and m.macroclasse not in {5})
    total_debits = sum(m.valor for m in movements if m.natureza == "D")
    clarity = round(known_value / total_debits * 100, 1) if total_debits else None
    clarity_state = "DISPONIVEL_COM_RESSALVAS" if clarity is not None else "INDISPONIVEL_POR_DADOS"
    if partial:
        clarity_state = "DISPONIVEL_COM_RESSALVAS"

    return [
        Lente(
            id="clareza", nome="Clareza dos gastos", familia="Qualidade da leitura",
            pergunta="Quanto das saídas observadas possui finalidade suficientemente identificada para sustentar esta leitura?",
            estado=clarity_state,
            resumo_estado="A leitura pode mostrar a cobertura de finalidade, preservando itens amplos e desconhecidos.",
            realizado={"percentual": clarity, "valor_conhecido": round(known_value, 2), "valor_total": round(total_debits, 2)},
            referencia={"percentual": 75, "tipo": "INTERNA_OPERACIONAL", "status": "HIPÓTESE EM VALIDAÇÃO"},
            plano_cliente=None,
            periodo="01/09/2025 a 31/08/2026", moeda="BRL",
            denominador="Valor total das saídas econômicas elegíveis observadas no mock.",
            origem_referencia="Framework de lentes — referência operacional interna candidata",
            versao="0.1 — idealização conceitual",
            cobertura="Saídas observadas após classificação do mock; meios sem finalidade permanecem explícitos.",
            limitacoes=[
                "O percentual mede cobertura da leitura, não organização ou comportamento do cliente.",
                "A referência de 75% é hipótese interna candidata e precisa de calibração.",
            ],
            como_calculamos=[
                "Numerador: saídas elegíveis com finalidade suficientemente conhecida.",
                "Denominador: todas as saídas econômicas elegíveis observadas.",
                "Sem categoria, categoria ampla e falha de mapeamento não são tratados como equivalentes.",
            ],
            perguntas=[
                "Quais itens ainda sem finalidade clara merecem ser revistos primeiro?",
                "Alguma categoria não representa corretamente a movimentação?",
            ],
            interpretacoes_proibidas=[
                "O cliente não organiza seus gastos.",
                "75% comprova uma leitura correta ou saúde financeira.",
            ],
            evidencias_ids=unknown_ids[:30],
        ),
        Lente(
            id="503020", nome="Distribuição 50/30/20", familia="Comparações educativas",
            pergunta="Como a distribuição observada se compara a uma orientação educativa e ao plano que o cliente considera possível?",
            estado="DISPONIVEL_COM_RESSALVAS" if not partial else "INDISPONIVEL_POR_DADOS",
            resumo_estado="Comparação opcional, sem aprovação, reprovação ou meta automática.",
            realizado={"essenciais": 56, "flexiveis": 25, "futuro": 12, "sem_finalidade": 7},
            referencia={"essenciais": 50, "flexiveis": 30, "futuro": 20, "tipo": "EXTERNA_EDUCATIVA"},
            plano_cliente={"essenciais": 55, "flexiveis": 25, "futuro": 15, "margem": 5, "proveniencia": "PLANEJADO — MOCK"},
            periodo="01/09/2025 a 31/08/2026", moeda="BRL",
            denominador="Renda de referência alocável simulada no protótipo.",
            origem_referencia="Referência educativa externa, opcional e contextual",
            versao="0.1 — idealização conceitual",
            cobertura="Distribuição simulada; 7% permanecem sem finalidade e não são renormalizados.",
            limitacoes=[
                "A referência não considera sozinha composição familiar, custo de vida ou renda irregular.",
                "A diferença para 50/30/20 não produz recomendação automática.",
            ],
            como_calculamos=[
                "Cada valor aparece uma única vez dentro desta lente.",
                "A parcela sem finalidade permanece como quarto bloco explícito.",
                "Realizado, referência e plano do cliente mantêm proveniências separadas.",
            ],
            perguntas=[
                "Esta divisão representa a realidade do período?",
                "Qual distribuição parece possível para o cliente?",
            ],
            interpretacoes_proibidas=[
                "Estar próximo da referência significa boa saúde financeira.",
                "Estar distante significa desorganização.",
            ],
            evidencias_ids=debit_ids[:40],
        ),
        Lente(
            id="credito", nome="Pagamentos e compromissos de crédito", familia="Comparações educativas",
            pergunta="Quanto da renda de referência foi destinado a pagamentos observados e quais obrigações devidas estão cobertas?",
            estado="INDISPONIVEL_POR_DADOS",
            resumo_estado="Há sinais observados, mas não há fonte suficiente para comprometimento contratual.",
            realizado={"sinais_observados": True, "pagamentos_observados": 8420.0, "razao_pagamentos_renda": None},
            referencia=None,
            plano_cliente=None,
            periodo="01/09/2025 a 31/08/2026", moeda="BRL",
            denominador="Não calculável: renda de referência e obrigações devidas não atendem aos gates.",
            origem_referencia="Referência externa de 30% não ativada por incompatibilidade metodológica",
            versao="0.1 — idealização conceitual",
            cobertura="Pagamentos relacionados a crédito parcialmente observados; obrigações devidas incompletas.",
            limitacoes=[
                "Pagamentos observados não equivalem a todas as obrigações devidas.",
                "Participação nas saídas não é comprometimento da renda.",
            ],
            como_calculamos=[
                "A razão não é exibida quando numerador e denominador não são compatíveis.",
                "Fatura, principal, juros e encargos precisariam de tratamento próprio.",
            ],
            perguntas=[
                "Estes pagamentos representam compromissos reconhecidos pelo cliente?",
                "A renda observada representa a renda disponível do período?",
            ],
            interpretacoes_proibidas=[
                "Abaixo de 30% significa crédito saudável.",
                "Pagamento de fatura comprova endividamento.",
            ],
            evidencias_ids=[m.id for m in movements if m.macroclasse == 9][:25],
        ),
        Lente(
            id="realidade", nome="Realidade reconhecida", familia="Minha jornada",
            pergunta="A leitura apresentada corresponde ao contexto que o cliente reconhece?",
            estado="FUTURA", resumo_estado="Lente futura dependente de autoria e registro de manifestação do cliente.",
            realizado=None, referencia=None, plano_cliente=None,
            periodo="Não aplicável", moeda="BRL", denominador="Sem referência numérica obrigatória.",
            origem_referencia="Metodológica e declarada", versao="Futura",
            cobertura="Não implementada", limitacoes=["Não pode ser registrada unilateralmente pelo gerente."],
            como_calculamos=[], perguntas=["Esta leitura corresponde à sua realidade?"],
            interpretacoes_proibidas=["Reconhecimento inferido sem manifestação do cliente."],
            evidencias_ids=[], futura=True,
        ),
    ]


class MockDashboardProvider(DashboardProvider):
    """Provider determinístico que respeita o mesmo contrato do adapter futuro."""

    def carregar(
        self,
        consulta: ConsultaDashboard,
        *,
        cenario_mock: str | None = None,
    ) -> dict[str, Any]:
        cenario = cenario_mock or "cliente_completo"
        if cenario not in CENARIOS:
            raise ValueError(f"Cenário desconhecido: {cenario}")

        movements = _build_movements()
        partial = cenario == "cliente_parcial"
        radar_available = cenario != "radar_indisponivel"
        if partial:
            movements = [m for m in movements if m.mes >= "2026-01"]

        # O provider aplica o escopo recebido pela função pública. A interface
        # ainda pode aplicar filtros adicionais sobre o conjunto retornado.
        if consulta.periodo_inicio:
            movements = [m for m in movements if m.data >= consulta.periodo_inicio]
        if consulta.periodo_fim:
            movements = [m for m in movements if m.data <= consulta.periodo_fim]
        if consulta.moeda:
            movements = [m for m in movements if m.moeda == consulta.moeda]
        if consulta.instituicoes:
            permitidas = set(consulta.instituicoes)
            movements = [m for m in movements if m.instituicao in permitidas]

        if movements:
            primeira_data = min(m.data for m in movements)
            ultima_data = max(m.data for m in movements)
            periodo = f"{primeira_data[8:10]}/{primeira_data[5:7]}/{primeira_data[:4]} a {ultima_data[8:10]}/{ultima_data[5:7]}/{ultima_data[:4]}"
        else:
            periodo = "Nenhuma movimentação encontrada no recorte"

        radar = _radar(radar_available).to_dict()
        radar["moeda"] = consulta.moeda
        radar["periodo"] = periodo

        return {
            "meta": {
                "produto": "Raio-X financeiro + Radar comportamental",
                "cenario": cenario,
                "cenario_descricao": CENARIOS[cenario],
                "cliente_codigo": consulta.cd_cli,
                "snapshot_id": f"SNAP-MOCK-{consulta.cd_cli}-20260805",
                "gerado_em": "05/08/2026 09:30",
                "periodo": periodo,
                "moedas": sorted({m.moeda for m in movements}) or [consulta.moeda],
                "dados_simulados": True,
                "limiar_equilibrio_pct": 0.02,
                "consulta": consulta.to_dict(),
            },
            "classificacoes": CLASSIFICACOES,
            "movimentacoes": [m.to_dict() for m in movements],
            "radar": radar,
            "lentes": [l.to_dict() for l in _lenses(movements, partial)],
            "config": {
                "instituicoes": sorted({m.instituicao for m in movements}),
                "contas": sorted({m.conta for m in movements}),
                "produtos": sorted({m.produto for m in movements}),
                "grupos": sorted({m.grupo_oficial for m in movements}),
                "categorias_vigentes": sorted({m.categoria_vigente for m in movements}),
                "categorias_originais": sorted({m.categoria_original for m in movements}),
            },
        }
