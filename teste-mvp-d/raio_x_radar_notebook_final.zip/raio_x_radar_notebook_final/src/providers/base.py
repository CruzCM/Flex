"""Interface substituível do provider de dados."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..domain import ConsultaDashboard


class DashboardProvider(ABC):
    @abstractmethod
    def carregar(
        self,
        consulta: ConsultaDashboard,
        *,
        cenario_mock: str | None = None,
    ) -> dict[str, Any]:
        """Retorna o contrato completo consumido pela apresentação."""
        raise NotImplementedError
