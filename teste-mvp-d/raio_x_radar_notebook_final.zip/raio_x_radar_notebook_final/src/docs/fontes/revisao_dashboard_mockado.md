# Revisão do dashboard mockado — aderência aos dados e à nomenclatura do Radar

## Decisão principal

O mockup atual não deve ser conectado diretamente à base como se todos os seus números fossem produtivos. Ele mistura três níveis diferentes:

1. dados que existem na tabela coração;
2. classificações derivadas pelo projeto;
3. interpretações financeiras que ainda dependem de novas fontes, perfilamento e regras homologadas.

A primeira versão viável deve ser apresentada como **Raio-X das movimentações observadas**. Ela pode ser construída com a tabela `DB2GFP.TRAN_RLZD_INST_PCT`, o catálogo de categorias e o mapa de classificações de `0` a `9` já usado pelo Radar.

Não deve ser chamada de “visão financeira tratada” enquanto não forem resolvidos, no mínimo, transferências próprias, compras e faturas, recorrência, cobertura das fontes e papéis econômicos.

## O que realmente temos hoje

### Na tabela coração

A `TRAN_RLZD_INST_PCT` oferece campos candidatos para:

- cliente: `CD_CLI`;
- identificação da movimentação: `NR_TRAN_INST_PCT` e `NR_PTC`;
- tipo de pessoa: `CD_TIP_PSS`;
- instituição e marca por código: `CD_INST_PCT` e `NR_MCA_PCT_OPB`;
- conta por identificadores: `NR_AG_TITR`, `CD_CT_TITR`, `DV_CT_TITR` e `NR_SEQL_CT_CLI`;
- produto: `CD_PRD`;
- valor e moeda: `VL_TRAN` e `CD_TIP_MOE_CRR`;
- descrição: `TX_DCR_TRAN`, `TX_CMPR_DCR_TRAN` e `TX_DCR_TRAN_OGNL`;
- entrada ou saída: `CD_NTZ_CTB_TRAN`;
- data e hora: `DT_TRAN` e `HR_TRAN`;
- categoria vigente e original: `CD_CTGR_TRAN` e `CD_CTGR_TRAN_OGNL`;
- estado e tipo da movimentação: `CD_EST_TRAN_INST` e `CD_TIP_TRAN`;
- indicadores de visualização e ocultação;
- inclusão e atualização do registro;
- mecanismo usado pelo motor de categorização: `CD_CLSC_MTO_CTGR`.

### No catálogo e no mapa do Radar

O catálogo local documenta 15 grupos e 71 categorias. O mapa atual do Radar usa a combinação:

```text
categoria original + natureza contábil (entrada ou saída)
                         ↓
              classificação de 0 a 9
```

Esses códigos são **classificações do projeto**, não os códigos das categorias oficiais. A interface deve evitar chamar os códigos `0–9` de “categorias”.

### Limite da base sumarizada atual

A base final `ANA_EDU_FIN_CLI` possui uma linha por cliente na janela mensal e não persiste data nessa versão. Sozinha, ela não sustenta gráficos mensais, detalhamento por instituição, conta, categoria ou movimentação.

Para o dashboard, é necessária uma visão analítica transacional derivada da tabela coração. A sumarizada pode continuar alimentando indicadores já existentes, mas não substitui a visão detalhada.

## Nomenclatura que deve aparecer para o usuário

Os nomes técnicos podem permanecer no processamento e na auditoria. Na comunicação, usar os nomes simples já propostos:

| Código | Nome para comunicação | Natureza |
|---:|---|---|
| 0 | Entradas e transferências a identificar | Entrada |
| 1 | Renda e benefícios recebidos | Entrada |
| 2 | Dinheiro devolvido ou ajustado | Entrada |
| 3 | Dinheiro retirado de investimentos | Entrada |
| 4 | Empréstimos e financiamentos recebidos | Entrada |
| 5 | Saídas e transferências a identificar | Saída |
| 6 | Contas e gastos necessários | Saída |
| 7 | Gastos que podem ser ajustados | Saída |
| 8 | Dinheiro destinado ao futuro | Saída |
| 9 | Dívidas, parcelas, juros e taxas | Saída |

Regras de apresentação:

- mostrar o nome simples em primeiro plano;
- deixar o código e o nome técnico apenas em “Como foi calculado” ou no detalhamento;
- informar que a classificação foi derivada da categoria registrada;
- não apresentar `6` como verdade universal sobre o que é necessário para aquela pessoa;
- não apresentar `7` como recomendação automática de corte;
- permitir que a conversa registre contexto sem alterar silenciosamente o dado de origem.

## Auditoria do mockup, bloco por bloco

| Bloco atual | Mudança obrigatória | Motivo |
|---|---|---|
| Nome “Mariana A. Souza” | Trocar por `Cliente código <CD_CLI>` | A tabela coração não possui nome do cliente |
| “Carteira Estilo Digital” | Remover | Não existe na fonte colocada em escopo |
| “ID CLI-001” | Usar o `CD_CLI` real, mascarado se necessário | Não criar identificador fictício com aparência produtiva |
| “Leitura disponível” | Trocar inicialmente por `Movimentações disponíveis` | Os gates de uma leitura financeira tratada não foram comprovados |
| “Snapshot RX-MOCK...” | Remover da tela principal; manter ID técnico em detalhes | É jargão e não ajuda a leitura do usuário |
| “12 meses representados” e “11 meses completos” | Mostrar `Período consultado` e `Meses com movimentação`; só afirmar completude após validar cobertura | Ter lançamentos em um mês não prova cobertura completa |
| Nomes de bancos e marcas | Mostrar inicialmente `Instituição código X` e `Marca código Y`; usar nomes somente com dimensão homologada | A tabela coração oferece códigos, não uma dimensão confiável de nomes |
| “Atualizado em” por banco | Trocar por `Última movimentação observada` ou `Última atualização de registro`, com rótulo exato | `TS_ATL_TRAN` não comprova sincronização completa da instituição |
| Quantidade de contas e cartões | Exibir como `identificadores de conta observados` e `movimentações de produtos 6/9`, após perfilamento | A tabela de transações não é inventário completo de produtos |
| “Cartões: COMPLETO” | Remover | A completude do detalhamento de cartão não foi comprovada |
| “Saldos: disponíveis” | Remover | Saldo não está na tabela coração |
| “0 limitações materiais” | Remover; mostrar limitações conhecidas | Ausência de limitação não pode ser simulada nem resumida sem regras validadas |
| “Renda externa identificada” | Trocar por `Entradas observadas` na V1 | Categoria de receita não comprova renda externa nem recorrência |
| “Usos financeiros identificados” | Trocar por `Saídas observadas` na V1 | O mockup pressupõe tratamento econômico e ausência de dupla contagem |
| “Diferença do fluxo tratado” | Trocar por `Diferença entre entradas e saídas observadas` | É o cálculo diretamente sustentado pela natureza contábil |
| “Valor inconclusivo” único | Separar `Entradas a identificar` e `Saídas a identificar` | Somar entrada e saída inconclusivas em um único valor perde o sentido financeiro |
| Lentes “Caixa observado”, “Visão financeira tratada”, “Compromissos” e “Posição” | Deixar apenas `Movimentações observadas` ativa na V1 | As demais dependem de regras e fontes ainda condicionais |
| Sankey de entradas | Usar as classificações `0–4` com nomes simples, ligadas ao total de entradas | É compatível com o mapa atual, desde que o denominador seja explícito |
| Sankey de saídas | Usar as classificações `5–9` com nomes simples, ligadas ao total de saídas | É compatível com o mapa atual, com ressalva sobre a categorização |
| Ligação entre entradas e saídas | Não criar | A base não rastreia qual entrada financiou qual saída |
| “Renda recorrente” e “Renda não recorrente” | Remover da V1 | Recorrência ainda não possui regra calibrada e auditável |
| “Destinação patrimonial”, “consumo”, “encargos” e outros papéis econômicos | Substituir pelas classificações `5–9` | Os papéis econômicos mais detalhados ainda são hipóteses do framework |
| Evolução mensal tratada | Mostrar entradas, saídas e diferença observadas por mês | Pode ser calculada diretamente com data, natureza e valor |
| Comparação entre instituições | Usar painéis por código, sem ranking e sem nome inventado | Os códigos existem; nomes e comparabilidade ainda precisam de validação |
| “Concentra recebimentos/pagamentos” | Trocar por texto factual, como `No período, houve mais entradas do que saídas` | O papel da conta não deve ser afirmado sem regra validada |
| Contas com nomes “BB CC 1234” | Usar identificador seguro e mascarado | Não presumir nome de banco nem expor conta completa |
| Cartões e faturas | Remover da V1 ou mostrar somente movimentações com `CD_PRD = 9`, sem afirmar compra, pagamento e compromisso futuro | Os vínculos entre compra, fatura e pagamento exigem complementos e perfilamento |
| Circulação entre contas | Remover da V1 | Não existe chave universal validada para confirmar as duas pontas de uma transferência própria |
| Posições observadas | Remover | Não há saldo nem posição na tabela coração |
| Evidências prioritárias | Reescrever usando somente fatos calculáveis | Não usar recorrência, renda tratada ou papel econômico ainda não homologado |
| Tabela “Movimentações de origem” | Manter, substituindo “Papel econômico” por `Classificação da movimentação` | Data, descrição, categoria, natureza e valor existem; papel econômico detalhado não |
| Descrições completas das transações | Mascarar inicialmente e revelar sob necessidade e autorização | Podem conter dados pessoais ou sensíveis |

## Estrutura recomendada para a primeira versão

### 1. Cabeçalho

Título:

> Raio-X das movimentações observadas

Identificação:

> Cliente código 123456

Metadados visíveis:

- período consultado;
- primeira e última movimentação encontradas;
- data e hora de geração;
- moeda ou moedas encontradas;
- filtros ativos.

Status inicial:

> Movimentações disponíveis

Texto de apoio:

> Esta visão considera as movimentações encontradas nas fontes disponíveis. Ela não representa, sozinha, toda a renda, todos os gastos, saldos, patrimônio ou dívidas do cliente.

### 2. O que foi encontrado

Mostrar fatos da base, sem afirmar cobertura total:

- quantidade de movimentações;
- quantidade de códigos de instituição encontrados;
- quantidade de identificadores de conta encontrados;
- quantidade de meses com pelo menos uma movimentação;
- moedas encontradas;
- movimentações sem correspondência no mapa de categorias;
- data mais recente de movimentação encontrada.

Não usar “completo”, “cobertura total” ou “sem limitações” sem gate aprovado.

### 3. Resumo em 30 segundos

Quatro cartões no máximo:

1. **Entradas observadas** — soma dos valores com natureza `C`;
2. **Saídas observadas** — soma dos valores com natureza `D`;
3. **Diferença entre entradas e saídas** — entradas menos saídas;
4. **Movimentações a identificar** — dois valores separados no mesmo cartão: entradas da classe `0` e saídas da classe `5`.

Cada cartão deve abrir:

- fórmula;
- período;
- quantidade de movimentações;
- filtros aplicados;
- lista das movimentações que compõem o valor;
- limitação do indicador.

### 4. Como o dinheiro que entrou foi classificado

Mostrar as classes `0–4` com:

- nome simples;
- valor;
- percentual sobre o total de entradas observadas;
- quantidade de movimentações;
- acesso ao detalhamento.

O percentual deve declarar o denominador: `percentual das entradas observadas no período`.

### 5. Como o dinheiro que saiu foi classificado

Mostrar as classes `5–9` com os mesmos elementos da seção anterior.

Nas classes `6` e `7`, incluir aviso curto:

> Classificação baseada na categoria registrada. O contexto do cliente pode mudar a interpretação.

### 6. Evolução por mês

Usar:

- barra de entradas observadas;
- barra de saídas observadas;
- linha ou barra divergente para a diferença;
- marcação do mês corrente como parcial por calendário;
- indicação de meses sem movimentação, sem tratá-los automaticamente como meses sem renda ou gasto.

Não usar “renda”, “uso financeiro” ou “resultado” nessa visualização da V1.

### 7. Grupos e categorias

Manter o Pareto, mas com duas abas:

1. **Grupos de movimentações**;
2. **Categorias de movimentações**.

Mostrar:

- nome e código;
- valor;
- percentual dentro de entradas ou saídas, nunca misturando os dois denominadores;
- quantidade de movimentações;
- categoria original e vigente quando forem diferentes;
- mecanismo de categorização, traduzido em linguagem simples;
- itens sem categoria;
- itens da categoria ampla “Gastos Diversos”, separados de “Sem categoria”.

O dashboard deve declarar se a visualização usa a categoria original ou a vigente. Como o mapa atual de `0–9` usa `CD_CTGR_TRAN_OGNL`, a V1 deve explicitar `classificação calculada a partir da categoria original` até que outra regra seja homologada.

### 8. Instituições e contas observadas

Usar códigos e identificadores seguros:

- `Instituição código 123`;
- `Marca código 456`, quando preenchida;
- `Conta observada •••• 1234` ou `Conta identificador 2`;
- `Produto: conta corrente`, quando `CD_PRD = 6`;
- `Produto: cartão`, quando `CD_PRD = 9`.

Por agrupamento, mostrar apenas:

- entradas observadas;
- saídas observadas;
- diferença;
- quantidade de movimentações;
- primeira e última data encontradas;
- classes e categorias mais representativas;
- valor a identificar.

Não mostrar saldo, limite, compromisso futuro, completude, consentimento ou função definitiva da conta.

### 9. Pontos para compreender na conversa

Gerar evidências exclusivamente descritivas, por exemplo:

- `R$ X das saídas observadas estão em “Saídas e transferências a identificar”.`;
- `O grupo Casa representa X% das saídas observadas no período.`;
- `Foram encontradas entradas em X dos Y meses com movimentação.`;
- `A diferença entre entradas e saídas variou entre R$ X e R$ Y.`;
- `X movimentações tiveram a categoria vigente diferente da categoria original.`

Perguntas seguras:

- `Quais movimentações a identificar merecem ser revistas primeiro?`;
- `Esta concentração corresponde ao que aconteceu no período?`;
- `Houve algum evento específico que ajude a compreender essa variação?`;
- `Alguma categoria não representa corretamente a movimentação?`

### 10. Movimentações que formam os números

Colunas recomendadas:

- data;
- descrição protegida;
- instituição por código;
- conta ou produto com identificação segura;
- grupo;
- categoria original;
- categoria vigente, quando diferente;
- classificação simples `0–9`;
- entrada ou saída;
- valor e moeda;
- origem da categorização;
- estado da movimentação.

Remover a coluna “Papel econômico” da V1.

## Camada de dados necessária para o dashboard

### Visão transacional recomendada

Criar uma visão específica, por exemplo `VW_RADAR_MOVIMENTACAO`, preservando o grão da movimentação e acrescentando os nomes derivados:

```text
CD_CLI
NR_TRAN_INST_PCT
NR_PTC
DT_TRAN
HR_TRAN
CD_INST_PCT
NR_MCA_PCT_OPB
NR_SEQL_CT_CLI
CD_CT_TITR_MASCARADO
CD_PRD
NM_PRD
VL_TRAN
CD_TIP_MOE_CRR
CD_NTZ_CTB_TRAN
NM_NATUREZA = Entrada | Saída
CD_CTGR_TRAN_OGNL
NM_CTGR_TRAN_OGNL
CD_GR_CTGR_TRAN_OGNL
NM_GR_CTGR_TRAN_OGNL
CD_CTGR_TRAN
NM_CTGR_TRAN
CD_CLASSIFICACAO_CATEGORIA
NM_CLASSIFICACAO_TECNICA
NM_CLASSIFICACAO_COMUNICACAO
CD_CLSC_MTO_CTGR
NM_ORIGEM_CATEGORIZACAO
FL_MAPEAMENTO_ENCONTRADO
FL_SEM_CATEGORIA
FL_CATEGORIA_AMPLA
FL_CATEGORIA_ALTERADA
CD_EST_TRAN_INST
IN_VSLO_CX
IN_OCTR_TRAN
TS_INCL_TRAN
TS_ATL_TRAN
```

### Ajuste importante no mapa atual

Hoje, uma categoria não encontrada no mapa recebe automaticamente classe `0` para entrada ou `5` para saída. O dashboard precisa preservar a causa desse fallback.

Adicionar pelo menos:

- `FL_MAPEAMENTO_ENCONTRADO`;
- `CD_CTGR_NAO_MAPEADA`;
- `NM_MOTIVO_CLASSIFICACAO`, com valores como `MAPEADA`, `SEM_CATEGORIA`, `CATEGORIA_NAO_MAPEADA` e `NATUREZA_INVALIDA`.

Sem isso, o usuário não conseguirá distinguir uma movimentação realmente sem categoria de uma falha do mapa do projeto.

### Visões agregadas

A partir da visão transacional, criar agregações por:

- cliente e período;
- cliente, mês e natureza;
- cliente, mês e classificação `0–9`;
- cliente, instituição e conta;
- cliente, grupo e categoria;
- cliente e origem da categorização.

Todos os totais devem manter a moeda. Valores de moedas diferentes não podem ser somados sem regra cambial explícita.

### Fórmulas seguras para a V1

```text
Entradas observadas = soma(VL_TRAN onde natureza = C)

Saídas observadas = soma(VL_TRAN onde natureza = D)

Diferença observada = Entradas observadas - Saídas observadas

Valor da classificação = soma(VL_TRAN por CD_CLASSIFICACAO_CATEGORIA)

Percentual da classificação de entrada = valor da classe / total de entradas

Percentual da classificação de saída = valor da classe / total de saídas
```

Antes de tornar esses cálculos produtivos, validar:

- unicidade de `NR_TRAN_INST_PCT` e `NR_PTC`;
- tratamento dos estados de transação;
- indicadores de ocultação e visualização;
- sinal e domínio de `VL_TRAN`;
- moedas;
- lançamentos divididos;
- sobreposição entre tabela principal e históricos auxiliares;
- categorias que não existem no mapa local;
- diferença entre categoria original e vigente.

## Elementos que ficam condicionais ou futuros

Não devem aparecer como prontos na V1:

- nome do cliente;
- nome de instituição ou marca;
- carteira ou segmento;
- inventário completo de contas e cartões;
- consentimento e autorização do gerente;
- completude por fonte;
- saldo e posição financeira;
- patrimônio;
- limite de cartão;
- compras detalhadas versus pagamento de fatura;
- compromissos futuros;
- transferências próprias confirmadas;
- renda recorrente ou não recorrente;
- renda externa identificada;
- fluxo financeiro tratado sem dupla contagem;
- classificação definitiva de consumo, obrigação, principal e encargo;
- comparação com referências;
- 50/30/20;
- diagnóstico, nota ou hábito financeiro;
- previsão, anomalia ou recomendação automática.

Cada item só pode entrar quando houver fonte, regra, gate de qualidade, limitação visível e rastreabilidade.

## Mudanças de linguagem e usabilidade

### Reduzir jargão

Substituir:

| Atual | Recomendado |
|---|---|
| Síntese executiva | Resumo do período |
| Cobertura e prontidão | O que foi encontrado |
| Lente ativa | Visão atual |
| Fluxo tratado | Entradas e saídas observadas |
| Usos financeiros | Saídas observadas |
| Valor inconclusivo | Movimentações a identificar |
| Papel econômico | Classificação da movimentação |
| Evidências prioritárias | Pontos para compreender |
| Rastreabilidade | Movimentações que formam os números |
| Snapshot | Identificador da consulta, somente em detalhes |

### Diminuir a densidade da página

O mockup atual é longo e concentra muitos módulos em uma única tela. A V1 deve deixar na página principal:

1. cabeçalho;
2. o que foi encontrado;
3. quatro indicadores;
4. composição das entradas e saídas;
5. evolução mensal;
6. grupos e categorias;
7. pontos para compreender.

Instituições, contas e movimentações devem abrir por abas ou detalhamento progressivo.

### Melhorar legibilidade

- elevar o texto comum para aproximadamente 14–16 px;
- evitar metadados importantes em 8–10 px;
- reduzir uso de caixa alta e espaçamento excessivo entre letras;
- não depender de tooltip para explicar um indicador;
- usar frases curtas abaixo de cada número;
- manter uma pergunta principal por seção;
- usar cor, rótulo e padrão juntos;
- não usar vermelho para transformar diferença negativa em julgamento;
- disponibilizar tabela equivalente para todo gráfico;
- diferenciar `R$ 0,00` de `Dado não disponível`;
- usar singular e plural corretamente (`1 evento`, `2 eventos`);
- usar acentos e nomes consistentes (`Débito`, `Crédito`, `Aplicação`);
- formatar datas no padrão brasileiro na comunicação e manter ISO apenas em detalhes técnicos.

### Filtros recomendados

- período;
- entrada ou saída;
- classificação simples `0–9`;
- grupo;
- categoria;
- instituição por código;
- conta por identificador seguro;
- produto;
- moeda;
- somente movimentações a identificar.

## Ordem de implementação

### Prioridade 0 — verdade dos dados

- retirar do mockup tudo que não é sustentado pela fonte;
- trocar nome por código do cliente;
- remover saldos, cartões completos, compromissos, posição e transferências confirmadas;
- usar entradas, saídas e diferença observadas;
- separar entrada e saída a identificar;
- explicitar limitações.

### Prioridade 1 — nomenclatura

- aplicar os nomes simples de `0–9`;
- separar “classificação” de “categoria” em toda a interface;
- substituir jargões pelos nomes propostos neste documento;
- manter termos técnicos apenas no detalhamento.

### Prioridade 2 — camada analítica

- criar a visão transacional do dashboard;
- incorporar grupo e nome da categoria;
- preservar categoria original e vigente;
- adicionar causa do fallback do mapa;
- criar agregações mensais e por dimensão;
- validar grão, estado, visibilidade, moeda e histórico.

### Prioridade 3 — experiência

- reorganizar a página pela hierarquia proposta;
- reduzir densidade;
- adicionar detalhamento progressivo;
- oferecer tabela equivalente aos gráficos;
- testar a compreensão com pessoas que não conhecem o projeto.

### Prioridade 4 — evoluções condicionais

- incorporar nomes de instituição somente com dimensão confiável;
- tratar cartão e fatura com complementos validados;
- conciliar transferências com evidência suficiente;
- ativar visão financeira tratada, compromissos e posição somente após os gates próprios.

## Critérios de aceite da primeira versão

A V1 estará coerente quando:

- nenhum nome de pessoa, banco, conta ou cartão for inventado;
- toda informação visível puder ser ligada a um campo ou regra documentada;
- as classificações `0–9` usarem os nomes simples;
- classificação e categoria não forem confundidas;
- entradas e saídas tiverem denominadores separados;
- a diferença for claramente descrita como diferença observada, não saldo ou patrimônio;
- moedas diferentes não forem somadas;
- zero não substituir ausência de informação;
- toda agregação abrir as movimentações de origem;
- “Sem categoria”, “Gastos Diversos” e “categoria não mapeada” forem estados distintos;
- limitações materiais estiverem visíveis;
- a tela puder ser compreendida sem conhecer SQL, Open Finance ou o modelo do Radar;
- o usuário conseguir responder: o que entrou, o que saiu, como foi classificado, o que ainda precisa ser identificado e quais movimentações formam cada número.
