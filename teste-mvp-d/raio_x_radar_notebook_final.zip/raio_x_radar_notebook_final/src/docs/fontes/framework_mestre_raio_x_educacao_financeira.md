# Framework mestre — Raio-X e Educação Financeira para o Gerente

## Status do documento

| Campo | Valor |
|---|---|
| Versão | `0.1 — idealização consolidada` |
| Data de referência | `2026-08-04` |
| Estado | Framework conceitual; não homologado nem implementado |
| Usuário principal | Gerente de relacionamento |
| Participação do cliente | Apresentação conjunta e escolhas voluntárias; sem autosserviço inicial |
| Finalidade | Compreensão financeira e conversa de educação financeira |

Este documento consolida o conceito completo do produto a ser idealizado. Ele combina:

- o levantamento das tabelas e categorias disponíveis;
- o roteiro original de descoberta do raio-X;
- o roteiro ampliado pelos pilares Diagnosticar, Sonhar, Orçar e Poupar;
- os conceitos, práticas, alertas e limitações identificados nos oito PDFs estudados;
- as decisões de produto tomadas para o contexto de uso pelo gerente.

Este é um **framework mestre de produto**, não uma especificação física aprovada. Telas, fórmulas, limites, regras de categorização, contratos de API e estruturas de banco ainda dependem de validação negocial, financeira, metodológica, jurídica, de privacidade e técnica.

Os documentos anteriores permanecem como baseline e não são substituídos:

- `roteiro_descoberta_negocial_mvp.md`;
- `roteiro_descoberta_negocial_mvp_dsop.md`;
- `gfp_catalago.md`;
- `categorias_transacoes_estruturado.md`.

O Radar permanece uma iniciativa independente. O novo produto poderá consultar fontes semelhantes, mas não herdará pontuação, perfis, regras, hábitos calculados ou resultados do Radar.

---

# 1. Decisão central de produto

## 1.1 O que será construído

Uma ferramenta para o gerente compreender a realidade financeira observável do cliente, apresentar uma visão geral durante a conversa e conduzir uma abordagem estruturada de educação financeira.

O produto terá dois módulos integrados e sequenciais:

1. **Raio-X financeiro observacional:** reúne um núcleo de registros observados e camadas calculadas ou inferidas claramente identificadas.
2. **Conversa de educação financeira:** módulo opcional que utiliza o raio-X como ponto de partida para compreender contexto, objetivos, orçamento, compromissos e próximos passos.

O raio-X é útil de forma autônoma, e o cliente pode encerrar a experiência após compreendê-lo. Quando desejar avançar, a conversa educativa completa a proposta de valor ponta a ponta. O produto não termina no gráfico: o gráfico ajuda o gerente a enxergar; o framework ajuda o gerente a conversar.

## 1.2 Pergunta central

> Como ajudar o gerente e o cliente a compreenderem a realidade financeira disponível, reconhecerem suas limitações, conectarem essa realidade aos objetivos do cliente e construírem um próximo passo que o próprio cliente considere viável?

## 1.3 Proposta de valor

> Oferecer ao gerente uma leitura financeira integrada, explicável e prudente, seguida de uma jornada de perguntas que transforme dados em compreensão, objetivos em planejamento e planejamento em compromisso revisável.

## 1.4 Resultado final esperado

Ao final de uma boa utilização do framework:

- o gerente compreende de onde o dinheiro observado veio, por onde circulou e para quais usos foi destinado;
- o cliente reconhece a visão apresentada ou consegue corrigi-la e contextualizá-la;
- ambos distinguem fatos, cálculos, estimativas, planos e hipóteses;
- pelo menos uma questão relevante para a vida financeira pode ser discutida sem julgamento;
- quando fizer sentido para o cliente, um objetivo, um cenário de orçamento, um compromisso e uma data de revisão são registrados;
- quando os dados ou o contexto forem insuficientes, o resultado correto é uma conclusão limitada ou inconclusiva.

Não é obrigatório que toda conversa produza um plano. Produzir compreensão confiável já pode ser um resultado válido.

## 1.5 Decisões assumidas

- O usuário principal é o **gerente**.
- Durante a conversa, uma apresentação simplificada e apropriada ao cliente estará obrigatoriamente disponível para acompanhamento conjunto; não haverá autosserviço do cliente na primeira versão.
- Não haverá oferta, recomendação ou contratação de produto financeiro dentro desta experiência.
- O gerente não será apresentado como terapeuta financeiro.
- A DSOP será utilizada como **estrutura conceitual de educação financeira**, pendente de validação formal de metodologia, terminologia, marca e formação necessária.
- Na interface com o cliente, os pilares poderão receber nomes descritivos: **Minha realidade**, **Meus objetivos**, **Meu plano** e **Meu progresso**.
- O Sankey será a hipótese de visualização principal da composição e da circulação financeira dentro do raio-X quando seus gates forem atendidos, mas não será o centro da jornada completa.
- O produto não produzirá nota, semáforo ou perfil definitivo de saúde financeira.

## 1.6 Legenda normativa

Para impedir que proposta seja confundida com regra aprovada, o documento usa cinco estados conceituais:

| Estado | Uso no framework |
|---|---|
| **DECISÃO** | Direção assumida para este produto e alterável somente por governança explícita |
| **HIPÓTESE** | Elemento que precisa de comparação, pesquisa ou teste antes de ser aprovado |
| **DEPENDÊNCIA** | Condição externa necessária, como perfilamento, autorização ou validação especializada |
| **CONDICIONAL** | Componente que integra o MVP apenas quando seus gates forem atendidos |
| **FORA DO ESCOPO** | Elemento que não pertence a este produto |

Números como doze meses, quantidade de indicadores, quantidade de sinais, duração de microconteúdo e limite inicial de objetivos são hipóteses de experiência, não regras da metodologia.

---

# 2. Arquitetura conceitual da jornada

```text
Autorização e cobertura
          ↓
Preparação e tratamento dos dados
          ↓
RAIO-X FINANCEIRO
Realidade observada, qualidade, fluxos e limitações
          ↓
Reconhecimento, contestação e contexto do cliente
          ↓
CONVERSA DE EDUCAÇÃO FINANCEIRA
Realidade → Objetivos → Plano → Compromisso
          ↓
Registro da conversa e próxima revisão
          ↓
Acompanhamento do planejado versus observado
```

## 2.1 Dois modos de uso

### Modo preparação do gerente

Permite maior detalhamento técnico:

- cobertura, consentimento e atualização;
- movimentações inconclusivas;
- regras de tratamento aplicadas;
- possíveis duplicidades;
- categorias e classificações;
- conciliação de transferências;
- compras, parcelas, faturas e pagamentos;
- evidências que podem originar perguntas;
- limitações que o gerente deverá explicar.

### Modo conversa com o cliente

Apresenta uma visão mais simples e neutra:

- período e dados considerados;
- principais entradas e saídas;
- composição das entradas e dos usos, além da circulação confirmada entre instituições, sem sugerir rastreamento inexistente;
- evolução ao longo do tempo;
- principais concentrações e variações;
- informações ainda não compreendidas;
- perguntas abertas;
- objetivo, cenário e próximo passo escolhidos pelo cliente.

O modo conversa não pode ocultar uma limitação material apenas para simplificar a tela.

## 2.2 Três horizontes de valor

### Em até 30 segundos

O gerente deve identificar:

- qual período está sendo analisado;
- quais contas e instituições estão representadas;
- quão atualizados estão os dados;
- qual é a principal característica da movimentação;
- se existe alguma limitação capaz de mudar a leitura.

### Em até cinco minutos

O gerente deve conseguir explicar:

- de onde vieram as entradas observadas;
- quais foram os principais usos do dinheiro;
- como a diferença de fluxo da lente selecionada variou entre os meses;
- que padrão de uso cada instituição ou conta apresenta como hipótese;
- quais valores continuam sem categoria ou sem conciliação;
- qual conjunto curto de perguntas parece mais útil para a conversa.

### Durante a conversa

O framework deve permitir:

- confirmar ou corrigir a leitura;
- registrar contexto que não existe nos extratos;
- compreender um objetivo relevante;
- testar um cenário simples;
- registrar um compromisso possível;
- combinar quando a situação será revista.

---

# 3. Princípios obrigatórios

## 3.1 Evidência antes de interpretação

Toda percepção apresentada deve permitir responder:

1. Qual dado a originou?
2. Qual tratamento foi aplicado?
3. Qual período foi considerado?
4. Qual é a cobertura da informação?
5. O que ainda não pode ser concluído?

## 3.2 Cliente como fonte e coautor

- Transações mostram acontecimentos, não motivações.
- O sistema não infere objetivos, prioridades ou necessidades pessoais.
- O cliente pode confirmar, corrigir, contestar ou deixar uma hipótese inconclusiva.
- Essencial e ajustável são conceitos que dependem do contexto do cliente.
- Um objetivo ou compromisso somente existe como plano quando for escolhido pelo cliente e registrado com sua ciência; o gerente não o confirma em nome do cliente.

## 3.3 Gerente como facilitador

O gerente deve:

- explicar evidências e limitações;
- fazer perguntas abertas;
- ajudar a comparar cenários;
- registrar o contexto informado;
- preservar a escolha do cliente;
- reconhecer quando não possui elementos para concluir.

O gerente não deve:

- definir o sonho do cliente;
- classificar personalidade ou comportamento;
- diagnosticar saúde mental;
- impor cortes ou percentuais;
- tratar uma hipótese como verdade;
- usar a conversa como roteiro comercial.

## 3.4 Linguagem não julgadora

Não utilizar como saída automática:

- saudável ou não saudável;
- disciplinado ou indisciplinado;
- consumista, compulsivo, avarento ou irresponsável;
- gasto certo ou errado;
- supérfluo definido pelo sistema;
- está no hospital, doente ou precisa de tratamento;
- fracassou ou não cumpriu.

Preferir:

- observado;
- informado;
- variou;
- concentrou;
- não foi identificado;
- precisa de contexto;
- ficou diferente do planejado;
- merece ser compreendido;
- pode ser revisto.

## 3.5 Contexto estrutural

Renda insuficiente, desemprego, doença, cuidado de dependentes, sazonalidade, emergências e outros eventos não podem ser reduzidos a falta de hábito ou disciplina.

## 3.6 Prudência visual

- Uma ligação visual incorreta é pior que duas pontas separadas.
- Ausência de dado não equivale a zero.
- Precisão gráfica não pode exceder a qualidade dos dados.
- Uma categoria não comprova a finalidade econômica.
- O Sankey representa fluxos agregados, não rastreia a identidade de cada real.

## 3.7 Separação do Radar

- Nenhuma nota ou regra do Radar será reutilizada automaticamente.
- Nenhuma tabela de saída do Radar será pré-requisito.
- Conceitos eventualmente semelhantes deverão ser revalidados para este produto.
- Apenas contratos neutros e fontes comprovadamente comuns poderão ser compartilhados no futuro.

## 3.8 Separação de produto comercial

Não haverá produto financeiro no framework. Contratação, recomendação, propensão, oportunidade comercial e meta de venda ficam fora da experiência, das métricas e dos registros de progresso.

## 3.9 Regra de valor negocial

Todo indicador, gráfico, sinal, pergunta ou campo deverá demonstrar qual compreensão ou conversa apoia. Se um elemento não ajuda o gerente a explicar a realidade, reconhecer uma limitação, formular uma pergunta ou registrar uma escolha do cliente, ele não entra no MVP.

## 3.10 Conceito de saúde financeira adotado

Neste framework, **saúde financeira é a capacidade, situada no contexto do cliente, de compreender e administrar fluxos e compromissos, lidar com variações e imprevistos e orientar recursos para necessidades e objetivos escolhidos**. É um conceito multidimensional e dinâmico; não é sinônimo de saldo positivo, renda alta, ausência de dívida ou volume investido.

O raio-X não mede sozinho a saúde financeira completa. Ele torna algumas dimensões observáveis e prepara perguntas sobre as demais:

| Dimensão | O que se busca compreender | Classe e suporte inicial |
|---|---|---|
| Cobertura e confiabilidade | Quanto da realidade está representado e quão atual é | Metadados observados; suportado no núcleo |
| Fluxo e margem do período | Entradas, saídas, circulação e saldo após usos identificados | Observado + calculado; tratamento financeiro é condicional |
| Compromissos | Obrigações presentes e futuras e seu peso no fluxo | Observado e declarado; cobertura atual parcial |
| Liquidez e resiliência | Recursos acessíveis e capacidade percebida de enfrentar variações | Saldos observados + essenciais declarados; condicional e incompleto |
| Estabilidade e previsibilidade | Variação, recorrência provável, sazonalidade e meses parciais | Calculado a partir do observado; não prova o futuro |
| Alinhamento a objetivos | Relação entre recursos, prioridades e prazo escolhidos | Declarado, estimado e planejado; exige coautoria |
| Contexto e autonomia | Restrições, escolhas e significado atribuído pelo cliente | Declarado; não inferível pelas transações |

O resultado do framework é um **painel de evidências e limitações por dimensão**, nunca uma soma, nota ou sentença global. Dizer “não há dados suficientes” para uma dimensão é mais correto do que preencher a lacuna com inferência.

---

# 4. Modelo de verdade e proveniência

## 4.1 Classe-base da informação

| Classe | Significado | Exemplo |
|---|---|---|
| **OBSERVADO** | Origem dos insumos recebidos de fonte identificada, mesmo quando posteriormente agregados | Débito de R$ 180 em uma conta |
| **DECLARADO** | Informação fornecida ou confirmada pelo cliente | Renda recebida fora das contas observadas |
| **ESTIMADO** | Projeção calculada a partir de premissas explícitas | Contribuição indicativa para um objetivo |
| **PLANEJADO** | Escolha futura registrada com participação do cliente | Reservar R$ 300 por mês |
| **HIPOTESE** | Interpretação ainda não confirmada | Duas pontas podem representar transferência própria |

## 4.2 Modo de produção

A classe-base será combinada com um segundo eixo:

| Modo | Significado | Exemplo |
|---|---|---|
| **BRUTO** | Conteúdo recebido sem transformação semântica | Registro original da transação |
| **NORMALIZADO** | Conteúdo padronizado sem interpretação financeira | Data, moeda e direção em formato canônico |
| **CALCULADO** | Resultado determinístico de regra documentada | Total mensal de débitos observados |
| **INFERIDO** | Resultado de associação ou classificação com incerteza | Transferência própria provável |

Exemplos combinados:

- um lançamento de origem é `OBSERVADO + BRUTO`;
- um total mensal é `OBSERVADO + CALCULADO`;
- um papel econômico atribuído por regra pode ser `HIPOTESE + INFERIDO`;
- uma contribuição futura escolhida pelo cliente é `PLANEJADO + BRUTO`;
- sua projeção de prazo é `ESTIMADO + CALCULADO`.

Essa composição impede que um total calculado pareça ter vindo pronto da fonte e evita criar uma nova proveniência apenas porque houve agregação.

## 4.3 Estado de validação

Além da classe, cada informação relevante poderá assumir um estado:

- não revisada;
- confirmada pelo cliente;
- corrigida;
- contestada;
- inconclusiva;
- expirada;
- substituída por nova versão.

Confirmação não altera a origem. Um dado observado e reconhecido pelo cliente continua observado. Quando o cliente confirma, corrige ou contextualiza uma hipótese, cria-se uma asserção separada `DECLARADO`, ligada à hipótese e às evidências; a hipótese original não é convertida em fato nem apagada. Uma visão calculada que use essa asserção deve declarar que combina insumos observados e declarados.

## 4.4 Metadados mínimos

Todo dado calculado, inferido, estimado, planejado ou hipotético deve registrar:

- cliente relacionado;
- autoria;
- fonte;
- data e hora;
- período de validade;
- versão;
- classe da informação;
- modo de produção;
- regra ou premissas utilizadas;
- estado de validação;
- confiança, quando aplicável;
- restrição de uso;
- ligação com as evidências de origem.

## 4.5 Regras de apresentação

- Observado e declarado podem coexistir, mesmo quando conflitantes.
- Planejado e realizado nunca são somados silenciosamente.
- Estimativas mostram premissas, arredondamentos e intervalo quando necessário.
- Hipóteses não entram em totais consolidados como fatos; quando houver confirmação do cliente, somente a asserção declarada vinculada poderá alimentar uma visão identificada como observada mais declarada.
- Uma correção do cliente não apaga o registro originalmente observado.
- Toda alteração relevante gera nova versão e trilha de auditoria.

---

# 5. Framework do Raio-X financeiro

## 5.1 Finalidade

O raio-X responde:

> O que os dados disponíveis permitem compreender sobre a entrada, a circulação, a destinação e a evolução do dinheiro observado do cliente?

Ele não responde sozinho:

- se o cliente está financeiramente saudável;
- por que o cliente tomou uma decisão;
- o que é essencial para aquela pessoa;
- qual objetivo ela deveria ter;
- se uma compra foi emocional;
- se todo o patrimônio, renda ou dívida está representado.

## 5.2 Ordem obrigatória da leitura

1. Cobertura e autorização.
2. Atualização e período observado.
3. Tratamentos e limitações materiais.
4. Visão de caixa.
5. Visão financeira tratada.
6. Circulação entre bancos e contas.
7. Evolução temporal.
8. Categorias e compromissos.
9. Evidências para conversa.

Indicadores financeiros não devem aparecer sem que o gerente consiga acessar cobertura e limitações.

## 5.3 Cobertura e prontidão dos dados

O cabeçalho de cobertura deve informar:

- instituições representadas;
- contas e cartões representados;
- tipos de conta;
- período disponível por conta;
- data da última atualização por fonte;
- consentimento do Open Finance, quando aplicável;
- autorização de exibição de transações;
- escolha de exibição dos dados da conta;
- estado do recurso;
- autorização institucional para a relação gerente-cliente, proveniente de fonte própria e distinta das anteriores;
- fontes temporariamente indisponíveis;
- moedas encontradas;
- lacunas de período;
- movimentações ocultas ou não exibíveis, quando essa informação puder ser apresentada;
- volume e valor sem categoria confiável;
- volume e valor de transferências inconclusivas;
- presença ou ausência de detalhamento de cartão;
- presença ou ausência de saldos.

Não haverá uma nota única de qualidade. A cobertura será apresentada por dimensões, pois uma média poderia esconder uma falha crítica.

### Estados candidatos de prontidão

| Estado | Significado |
|---|---|
| **Leitura disponível** | Os componentes necessários à visão selecionada estão presentes e dentro dos critérios validados |
| **Leitura parcial** | Há valor informacional, mas faltam contas, períodos ou tratamentos materiais |
| **Somente movimentações** | Os lançamentos podem ser exibidos, mas não sustentam diferença do fluxo tratado ou sinais |
| **Dados insuficientes** | A ausência, desatualização ou inconsistência impede uma leitura responsável |

Os critérios numéricos de cada estado somente poderão ser definidos após perfilamento das tabelas e testes com casos reais.

### Gate de elegibilidade e escopo

- O público inicial é pessoa física.
- Conta pessoal usada em atividade profissional deve ser identificada pelo cliente e não pode ser misturada silenciosamente ao fluxo doméstico; a visão será separada ou declarada inconclusiva.
- Conta conjunta exige escopo autorizado e tratamento de titularidade; o acesso de um titular não autoriza automaticamente expor dados ou contexto do outro.
- Orçamento familiar, objetivo compartilhado ou contribuição de outra pessoa exige consentimento individual, finalidade e participantes explicitamente registrados.
- Se o escopo pessoal, profissional ou compartilhado não puder ser separado com segurança, o gerente poderá mostrar movimentações, mas não consolidar conclusões sobre a vida financeira pessoal.

## 5.4 Unidade de análise

A unidade básica será a movimentação financeira vinculada a:

- cliente;
- instituição ou marca;
- conta ou cartão;
- data e, quando disponível, hora;
- valor e moeda;
- natureza contábil;
- tipo de transação;
- categoria original e categoria vigente;
- estado da transação;
- visibilidade;
- fonte e atualização;
- complemento específico de conta ou cartão.

Agregações mensais, por banco, conta, categoria ou papel econômico são produtos derivados dessa unidade.

## 5.5 Duas classificações simultâneas

Cada movimentação poderá possuir:

1. **Categoria operacional:** classificação recebida ou atribuída no GFP, preservando grupo, categoria, origem e mecanismo de classificação.
2. **Papel econômico no raio-X:** tratamento necessário para evitar que toda entrada seja chamada de renda e todo débito seja chamado de despesa.

Categoria operacional e papel econômico não são equivalentes.

### Papéis econômicos candidatos

- renda ou entrada externa recorrente;
- entrada externa não recorrente;
- consumo ou despesa de uso final observável;
- obrigação ou serviço de dívida;
- juros, tarifas e tributos;
- transferência entre contas próprias confirmada;
- transferência provável;
- transferência externa confirmada;
- transferência não conciliada;
- aplicação ou destinação patrimonial;
- resgate ou retorno patrimonial;
- estorno, reembolso ou devolução;
- saque com uso final não observado;
- entrada de financiamento ou empréstimo;
- liquidação de fatura;
- valor sem papel econômico confiável.

O papel econômico é uma hipótese de modelo a validar com especialistas e perfilamento. Não deve ser inferido apenas pelo sinal de crédito ou débito.

---

# 6. As quatro visões financeiras

## 6.1 Visão de caixa observada

Mostra o que foi creditado e debitado nas contas durante o período, usando a data da transação disponível. Data contábil, data de entrada na fatura, vencimento e pagamento são eventos distintos e só serão utilizados quando a fonte correspondente estiver preenchida e validada.

Componentes:

- créditos observados;
- débitos observados;
- diferença líquida entre créditos e débitos observados no período;
- evolução mensal;
- detalhamento por banco e conta;
- transações futuras ou não efetivadas separadas;
- valores em moedas diferentes não consolidados sem regra cambial explícita.

Essa visão descreve movimentação. Ela pode conter transferências internas, aplicações, resgates, empréstimos e liquidações de fatura, portanto não equivale automaticamente a renda menos consumo.

## 6.2 Visão financeira tratada

Busca responder quanto entrou de fora e quanto foi destinado a consumo, obrigações e encargos, mantendo movimentos internos e patrimoniais separados.

Estrutura conceitual candidata:

```text
Renda externa identificada
− saídas de consumo observadas
− principal de obrigações pago, quando decomposto
− juros, tarifas e tributos pagos, quando decompostos
= diferença do fluxo tratado no período
```

Separadamente:

```text
Aplicações − resgates = destinação patrimonial líquida observada
```

Quando principal, juros e encargos de uma obrigação não puderem ser separados, o pagamento será subtraído uma única vez como **obrigação sem decomposição**. Empréstimos recebidos, resgates, transferências de terceiros, estornos e créditos inconclusivos devem aparecer separadamente e não podem ser somados automaticamente à renda. A fórmula é um contrato semântico candidato, não regra aprovada, e não representa lucro, renda contábil, saldo de conta nem patrimônio. O total deverá mostrar o valor que permaneceu inconclusivo e quais componentes foram excluídos. Se renda e saídas elegíveis não puderem ser distinguidas com confiança suficiente, a diferença do fluxo tratado não será calculada.

## 6.3 Visão de compromissos — condicional

Mostra efeitos financeiros que não podem ser compreendidos apenas pelo movimento do mês, somente quando houver fonte explícita ou declaração do cliente:

- compras e parcelas já observadas;
- parcelas futuras explicitamente disponíveis, sem completar calendário por inferência;
- faturas abertas e vencimentos;
- pagamento integral, parcial, mínimo ou em atraso, quando comprovável;
- empréstimos e prestações observáveis;
- recorrências prováveis, sustentadas por ocorrências históricas, sem tratá-las como obrigação futura;
- compromissos declarados pelo cliente;
- diferença entre compromisso assumido e caixa liquidado.

Não será chamada de endividamento total, pois as fontes atuais podem não representar todas as obrigações do cliente. O complemento de cartão documentado não comprova, por si só, o valor total da compra, as datas das parcelas futuras ou um calendário completo.

## 6.4 Visão de posição

Quando os dados estiverem disponíveis e atualizados, poderá mostrar:

- saldo disponível;
- saldo bloqueado;
- saldo identificado como investimento;
- posição por conta, moeda e data;
- diferença temporal entre atualização de saldo e transações.

Saldo observado não equivale a patrimônio líquido. Não comprova reserva, objetivo ou intenção de poupar. Saldo disponível, bloqueado e identificado como investimento não serão somados automaticamente até que os tipos e sua aditividade sejam comprovados.

Quando existirem dois snapshots de saldo realmente comparáveis, ou outra fonte histórica validada, a integridade poderá ser testada por:

```text
saldo inicial + créditos observados − débitos observados = saldo final ± ajustes identificados
```

A reconciliação deve usar mesma conta, moeda, janela, tipo de saldo e critério temporal. `SDO_OPB_CT_CLI`, isoladamente, documenta uma posição vigente por tipo e não comprova um par histórico inicial/final nem que saldo disponível seja saldo contábil. Portanto, esta reconciliação é uma dependência futura: sua ausência não bloqueia as duas composições independentes, mas bloqueia um Sankey conectado que use balanço entre entradas e saídas. Diferença não explicada permanece como resíduo explícito; ausência de saldos não será tratada como falha do cliente.

---

# 7. Tratamentos financeiros críticos

## 7.1 Transferências

Cada ponta deverá assumir um estado:

- **própria confirmada:** há evidência suficiente de titularidade e correspondência;
- **provável:** existem indícios, mas falta prova;
- **externa confirmada:** há evidência de titularidade de terceiro;
- **não conciliada:** não foi possível estabelecer o papel;
- **parcialmente observada:** somente uma ponta está disponível.

Regras de prudência:

- apenas transferências próprias confirmadas podem ser neutralizadas na diferença do fluxo tratado padrão;
- provável não é sinônimo de confirmada;
- na visão de caixa, todas as pontas elegíveis permanecem como movimento; na visão financeira tratada, prováveis e não conciliadas ficam separadas de renda e consumo como valor inconclusivo;
- igualdade de valor e proximidade de data, isoladamente, não comprovam ligação;
- ausência de correspondência com uma conta própria conhecida não comprova transferência externa, pois o inventário de contas pode estar incompleto;
- mesma titularidade pode ser insuficiente em conta conjunta, conta profissional ou contexto não observado;
- uma ponta não observada não pode ser inventada;
- o gerente deve enxergar quanto permanece inconclusivo;
- o Sankey deve diferenciar visualmente conexão confirmada, provável e não conciliada.

## 7.2 Cartão e dupla contagem

O modelo deve distinguir quatro eventos:

1. compra;
2. parcela ou obrigação;
3. fatura;
4. pagamento da fatura.

Serão mantidas três perspectivas:

- **consumo tratado:** compras e seus estornos ou contestações vinculados, sem repetir a liquidação; encargos ficam em papel próprio;
- **compromissos:** parcelas e faturas abertas apenas quando explicitamente observadas ou declaradas;
- **impacto no caixa:** pagamento ou baixa financeira efetivamente observada.

Proteções:

- compra detalhada e pagamento da fatura não podem ser somados como duas despesas de consumo;
- pagamento da fatura permanece visível como liquidação financeira;
- quando não houver compras detalhadas, o pagamento continua sendo caixa observado, mas não pode ser usado como aproximação de consumo sem regra e ressalva explicitamente validadas;
- compra parcelada deve preservar os dados efetivamente recebidos; valor total, moeda original inequívoca e calendário futuro permanecem opcionais e não podem ser derivados apenas do número da parcela e da quantidade total;
- parcela e total de fatura representam compromisso ou consumo; somente pagamento ou baixa observada representa impacto de caixa;
- estornos e chargebacks devem ser ligados ao evento original quando houver evidência;
- vínculo entre compra, fatura e pagamento deve registrar estado, fonte, evidência e limitação;
- cada movimentação assume um único papel em cada lente; consumo, principal, encargos e liquidação são mutuamente exclusivos dentro do mesmo cálculo;
- rotativo, atraso e pagamento mínimo não podem ser inferidos apenas pelo valor pago;
- a tela deve declarar quando a visão do cartão estiver incompleta.

## 7.3 Aplicações e resgates

- Aplicação não é despesa de consumo.
- Resgate não é renda.
- Ambos representam movimentação patrimonial enquanto não houver evidência diferente.
- Uma aplicação não comprova poupança intencional nem vínculo com um objetivo.
- O progresso de um objetivo depende de declaração, confirmação ou vínculo explícito.

## 7.4 Empréstimos e pagamentos de dívida

- Recurso recebido por empréstimo é entrada de financiamento, não renda.
- Pagamento deve ser decomposto entre principal, juros, tarifas e tributos apenas quando os dados permitirem.
- Sem decomposição, o valor deve permanecer como obrigação financeira observada com limitação explícita.
- Presença de cartão ou prestação não significa inadimplência.

## 7.5 Saques

Saque representa saída de caixa cujo uso final não foi observado. Não deve ser automaticamente atribuído a consumo nem distribuído entre categorias por suposição.

## 7.6 Estornos, devoluções e reembolsos

- Quando o evento original for identificado, o valor deverá ajustar a leitura correspondente.
- Sem vínculo confiável, será mostrado separadamente como entrada corretiva ou inconclusiva.
- Um reembolso não deve inflar renda externa recorrente.

## 7.7 Duplicidades, estados e visibilidade

Antes de qualquer agregado, validar:

- chave e partição da transação;
- atualizações do mesmo registro;
- deleção lógica;
- lançamentos futuros;
- transações ocultas;
- divisão de lançamento;
- presença do mesmo evento em conta e cartão;
- comportamento dos indicadores de fluxo de caixa e perfil de consumo;
- estabilidade dos identificadores externos entre instituições.

Nenhum desses campos deverá ser usado produtivamente sem perfilamento de domínio e preenchimento.

---

# 8. Arquitetura da experiência do Raio-X

## 8.1 Hierarquia da tela

A experiência deverá respeitar a seguinte ordem visual:

1. identificação do cliente, período e momento de atualização;
2. cobertura e limitações materiais;
3. síntese executiva dos fluxos;
4. Sankey como visualização principal candidata, quando os gates de dados e balanço forem atendidos;
5. evolução mensal;
6. comparação entre bancos e contas;
7. categorias, compromissos e movimentos patrimoniais;
8. valores inconclusivos;
9. perguntas baseadas em evidências;
10. transição opcional para a conversa de educação financeira.

O Sankey é a hipótese visual protagonista da leitura dos fluxos, mas não aparece antes da cobertura, não substitui totais, evolução e detalhamento e deve ceder lugar a barras ou tabela quando os gates não forem atendidos.

## 8.2 Síntese executiva

Primeira linha com um conjunto compacto de indicadores. A hipótese inicial é de até quatro, sujeita a teste de compreensão.

Fallback somente-caixa:

1. créditos observados;
2. débitos observados;
3. diferença líquida entre créditos e débitos;
4. valor inconclusivo ou limitação material.

Quando a taxonomia financeira passar pelos gates, a linha poderá evoluir para:

1. renda externa identificada;
2. destinos financeiros identificados;
3. diferença do fluxo tratado;
4. valor inconclusivo ou sem papel econômico confiável.

Instituições, contas, atualização e lacunas permanecem na faixa de cobertura acima dos indicadores. Destinação patrimonial, meses positivos ou negativos, transferências e concentrações ficam como indicadores auxiliares vinculados às visualizações correspondentes.

Cada indicador deverá conter:

- nome inequívoco;
- valor e moeda;
- período;
- classe da informação;
- regra de composição;
- comparação temporal, quando cabível;
- cobertura relevante;
- acesso às movimentações de origem;
- texto sobre o que não permite concluir.

Não exibir mais indicadores do que o gerente consegue relacionar a uma pergunta concreta. A quantidade final deverá ser validada por teste de compreensão.

## 8.3 Sankey principal — duas composições financeiras independentes

Estrutura candidata:

```text
Composição de entradas: origens identificadas → total de entradas elegíveis

Composição de saídas: total de saídas elegíveis → destinos identificados
```

Nós da esquerda:

- renda externa identificada, separando recorrência somente após o gate específico;
- entradas de financiamento;
- resgates ou retornos patrimoniais;
- transferências de terceiros confirmadas;
- estornos ou reembolsos;
- créditos ainda não identificados.

Totais de referência:

- entradas e saídas possuem denominadores próprios;
- parcelas inconclusivas permanecem explicitamente separadas;
- os dois totais não são ligados entre si por padrão.

Nós da direita:

- consumo por grupos relevantes;
- principal de obrigações pago, quando decomposto;
- obrigação paga sem decomposição, quando principal e encargos não puderem ser separados;
- juros, tarifas e tributos;
- aplicações e destinação patrimonial;
- saques;
- saída ainda não identificada.

Transferências próprias confirmadas não devem inflar origens e destinos financeiros tratados. Elas podem ser exibidas em uma faixa própria ou na visão de circulação.

Instituição e conta funcionarão como filtros, dimensões de detalhamento ou visual separado. O Sankey não deverá ligar uma origem a um uso por intermédio de uma conta de modo que sugira que uma entrada específica financiou uma saída específica. Por padrão, serão exibidas duas composições independentes: `origens → total de entradas identificadas` e `total de saídas identificadas → destinos`. Um Sankey conectado somente poderá existir se um teste de balanço fechar origens, destinos, saldos inicial e final, movimentos patrimoniais e valores inconclusivos; qualquer resíduo deverá ser um nó explícito. É proibido alocar saídas proporcionalmente às entradas sem rotular a ligação como estimativa e validar sua utilidade.

## 8.4 Sankey alternativo — visão de circulação

Estrutura candidata:

```text
Instituição ou conta de origem
          ↓
Transferência
          ↓
Instituição ou conta de destino
```

Objetivos:

- mostrar como o dinheiro circula entre instituições;
- mostrar contas que concentram recebimentos, pagamentos ou passagem observada;
- distinguir ligação confirmada, provável e inconclusiva;
- tornar visível a parcela de circulação que ainda não pode ser conciliada.

Uma conta poderá receber um **papel observado**, como “concentra recebimentos”, “concentra pagamentos” ou “apresenta saldo observado”. O sistema não deverá afirmar que essa é sua função definitiva nem que há acumulação de recursos sem evidência temporal e semântica suficiente.

## 8.5 Regras visuais do Sankey

- Exibir valores absolutos e percentuais com denominador explícito.
- Limitar a quantidade de nós; agrupar caudas pequenas em “Outros”.
- Manter “Sem categoria” e “Não conciliado” separados de “Outros”.
- Usar cor, rótulo e padrão para distinguir classes; nunca apenas cor.
- Conexão provável não poderá ter a mesma aparência de conexão confirmada.
- Permitir alternância entre instituição e conta.
- Informar quando uma ponta do fluxo não está observada.
- Não ligar uma origem de renda a uma compra específica sem rastreabilidade real.
- Não produzir animação que sugira precisão ou causalidade inexistente.
- Disponibilizar tabela equivalente para acessibilidade e auditoria.
- Cada fluxo deverá permitir abrir sua composição.
- Se cobertura, categorização ou conciliação forem insuficientes para uma representação responsável, substituir o Sankey por barras ou tabela e explicar o motivo.

## 8.6 Evolução mensal

Visual candidato:

- barras para renda externa identificada e destinos financeiros tratados;
- linha ou barra divergente para a diferença mensal da lente selecionada;
- camada separada para destinação patrimonial;
- marcações para meses parciais, incompletos ou afetados por desatualização.

O gerente deverá conseguir alternar:

- visão de caixa;
- visão financeira tratada;
- visão de compromissos, quando sustentada por fonte explícita ou declaração;
- período completo ou janela selecionada.

Um mês negativo não será colorido ou descrito como falha. A pergunta correta é se ele é recorrente, explicável, relevante e reconhecido pelo cliente.

## 8.7 Comparação entre bancos e contas

A comparação lado a lado somente será feita quando período, moeda, atualização, escopo e cobertura forem suficientemente comparáveis. Quando o gate falhar, cada instituição será mostrada separadamente, com sua própria base, sem ranking ou contraste percentual direto.

Para cada instituição ou conta, mostrar quando possível:

- entradas externas recebidas;
- destinos financeiros tratados;
- transferências recebidas e enviadas;
- aplicações e resgates;
- resultado de caixa local;
- quantidade e valor de movimentações;
- principais categorias;
- recorrências prováveis, acompanhadas das ocorrências e da regra que as sustentam;
- atualização;
- valores sem categoria;
- papel observado da conta;
- limitações específicas.

A comparação é do próprio cliente entre suas fontes. Não haverá ranking entre clientes nem afirmação de que uma instituição é melhor.

## 8.8 Categorias e concentrações

Visual candidato: barras ordenadas ou Pareto, por ser mais comparável que múltiplos gráficos de pizza.

O catálogo local documenta 15 grupos e 71 categorias, mas isso é referência editorial. A base pode conter códigos personalizados ou valores adicionais, que deverão ser perfilados.

Mostrar:

- valor;
- participação nas saídas elegíveis;
- quantidade de movimentações;
- valor típico ou mediano, quando estatisticamente adequado;
- recorrência;
- variação ao longo do período;
- origem da categorização;
- parcela cuja categoria atual difere da original;
- parcela em categoria padrão ou personalizada;
- parcela ainda sem categoria.

Quantidade de transações isolada não significa pressão financeira. Concentração também não significa problema sem contexto.

O mecanismo registrado em `CD_CLSC_MTO_CTGR` informa como o motor categorizou o lançamento; não é probabilidade, confiança nem prova de autoria do cliente. Uma correção só poderá ser atribuída ao cliente se houver fonte de auditoria específica. “Sem categoria” e “Gastos Diversos” também devem permanecer distintos: o primeiro expressa ausência de classificação; o segundo é uma categoria ampla e não comprova finalidade econômica.

## 8.9 Recorrência e variabilidade

Componentes obrigatórios:

- quantidade de meses efetivamente observados;
- distinção entre mês completo e parcial;
- presença de entradas externas em cada mês;
- faixa e mediana mensal, quando adequadas;
- amplitude entre períodos;
- meses com diferença positiva, negativa ou inconclusiva na lente selecionada;
- concentração por fonte, instituição e categoria;
- lista explicável de possíveis recorrências.

Não rotular automaticamente a renda como regular ou irregular. Preferir uma descrição verificável:

> Foram observadas entradas externas em oito dos doze meses, variando entre X e Y.

Recorrência provável poderá considerar contraparte, descrição normalizada, categoria, conta, periodicidade e faixa de valor. A saída deverá mostrar as ocorrências que sustentam a associação. Tolerâncias só serão definidas após calibração.

Sazonalidade, previsão e detecção automática de anomalias ficam fora do MVP inicial.

## 8.10 Detalhamento e rastreabilidade

Todo total relevante deverá permitir navegar por:

```text
Indicador ou fluxo
      ↓
Regra de composição
      ↓
Agrupamentos
      ↓
Movimentações de origem
      ↓
Fonte e atualização
```

O gerente deverá conseguir responder “de onde veio este número?” sem recorrer a consulta externa.

## 8.11 Painel de limitações

Deve permanecer acessível em toda a jornada e destacar:

- contas conhecidas no escopo, mas indisponíveis, ocultas ou sem consentimento;
- possibilidade de existirem outras contas fora do inventário observado;
- dados desatualizados;
- períodos incompletos;
- categorias desconhecidas;
- transferências não conciliadas;
- cartão sem detalhamento;
- saldos ausentes ou defasados;
- moedas não consolidadas;
- regras ainda provisórias;
- hipóteses aguardando confirmação.

---

# 9. Evidências e sinais para a conversa

## 9.1 Estrutura de um sinal seguro

Um sinal não é uma conclusão. É um objeto explicável composto por:

1. evidência;
2. regra de detecção;
3. período;
4. materialidade;
5. cobertura;
6. limitações;
7. pergunta sugerida;
8. resposta ou contexto do cliente;
9. estado após a conversa: reconhecido pelo cliente, contextualizado, contestado ou inconclusivo.

Formato recomendado:

> **Evidência:** os usos financeiros tratados ficaram acima da renda externa identificada em quatro dos doze meses disponíveis.  
> **Limite:** duas contas ficaram desatualizadas durante parte do período.  
> **Pergunta:** houve algum evento ou ciclo de renda que ajude a compreender esses meses?

## 9.2 Catálogo candidato de sinais

| Tema | Evidência possível | Formulação segura | Pergunta ao cliente | Conclusão proibida |
|---|---|---|---|---|
| Cobertura | Conta desatualizada, período ausente ou consentimento indisponível | “Parte da realidade pode não estar representada.” | “Existe alguma conta ou compromisso relevante fora desta leitura?” | “Esta é toda a vida financeira do cliente.” |
| Renda | Concentração de entradas externas em uma fonte | “A maior parte das entradas observadas veio desta fonte.” | “Essa fonte costuma ser estável? Existe outra renda não observada?” | “O cliente depende perigosamente desta renda.” |
| Variabilidade | Oscilação mensal das entradas | “As entradas variaram ao longo do período.” | “Essa variação faz parte do seu ciclo normal?” | “O cliente não tem estabilidade.” |
| Diferença do fluxo tratado | Meses com usos tratados acima da renda externa identificada | “Houve meses em que os usos identificados superaram a renda identificada.” | “O que aconteceu nesses meses?” | “A saúde financeira é ruim.” |
| Tendência | Saídas cresceram mais que entradas na janela | “As saídas observadas cresceram mais nesta comparação.” | “Essa mudança era esperada e deverá continuar?” | “O cliente perdeu controle.” |
| Categoria | Concentração ou mudança material em um grupo | “Esta categoria representou parcela relevante das saídas observadas.” | “Esse valor corresponde à sua realidade e prioridade?” | “O cliente gasta demais nessa categoria.” |
| Recorrência | Lançamentos semelhantes em ciclos sucessivos | “Foram observados lançamentos semelhantes em N de M meses.” | “Isso corresponde a um compromisso? Ele deverá continuar?” | “É um gasto fixo obrigatório.” |
| Transferência | Valor relevante sem conciliação | “Parte da circulação entre contas continua inconclusiva.” | “Você reconhece estas movimentações como próprias?” | “Este dinheiro foi gasto ou recebido.” |
| Cartão | Detalhamento incompleto ou risco de duplicidade | “A leitura do cartão possui cobertura parcial.” | “As compras e o pagamento da fatura estão representados corretamente?” | “O cliente está endividado no cartão.” |
| Patrimônio | Aplicações ou resgates observados | “Houve destinação ou retorno patrimonial no período.” | “Esse valor está ligado a algum objetivo?” | “O cliente poupou para determinado sonho.” |
| Compromissos | Parcelas ou obrigações futuras conhecidas | “Existem compromissos que podem afetar os próximos ciclos.” | “Há outros compromissos que não aparecem?” | “Esta é a dívida total.” |
| Planejado | Diferença entre plano e realizado | “O realizado ficou diferente do cenário escolhido.” | “O que mudou: a realidade, a prioridade ou o plano?” | “O cliente falhou.” |

## 9.3 Seleção dos sinais

- Mostrar um conjunto pequeno de sinais prioritários; a hipótese inicial de três a cinco será validada em teste.
- Priorizar materialidade, recorrência, mudança e relevância para a pergunta do cliente.
- Sinal com baixa cobertura deve perder prioridade ou ser apresentado como limitação.
- Sinais conflitantes devem permanecer visíveis, não ser reduzidos a uma narrativa única.
- O gerente pode descartar um sinal, registrando motivo.
- O cliente pode contestar ou contextualizar cada sinal.
- Nenhum limite numérico será universal antes de validação com dados e especialistas.

---

# 10. Framework da conversa de Educação Financeira

## 10.1 Entrada da conversa

A conversa recebe um snapshot versionado do raio-X com:

- cliente e período;
- cobertura e atualização;
- instituições, contas e cartões incluídos;
- visões de caixa, financeira tratada, compromissos e posição disponíveis;
- evolução mensal;
- principais evidências;
- valores inconclusivos;
- acesso às movimentações de origem;
- regras e limitações aplicadas.

Antes de continuar, o gerente apresenta o escopo e informa que o cliente pode corrigir, não responder ou encerrar.

## 10.2 Sequência educativa

Na experiência inicial, os nomes para o cliente serão:

| Pilar conceitual | Nome na experiência | Pergunta principal |
|---|---|---|
| Diagnosticar | **Minha realidade** | O que os dados e o seu contexto permitem compreender? |
| Sonhar | **Meus objetivos** | Onde você deseja chegar e por que isso importa? |
| Orçar | **Meu plano** | Qual caminho cabe na realidade que você reconhece? |
| Poupar | **Meu progresso** | Qual próximo passo deseja assumir e como ele será revisto? |

`Minha realidade` é a validação contextual do raio-X com o cliente; não executa uma segunda análise automática nem transforma declaração em fato técnico.

Estados da apresentação e seus responsáveis:

| Estado | Como ocorre | Responsável pela mudança |
|---|---|---|
| `GERADO` | Snapshot versionado foi produzido | Sistema |
| `APTO_PARA_APRESENTAR_LEITURA` | Autorização, segurança e gates mínimos da visão selecionada foram atendidos | Sistema, por regra versionada |
| `APTO_PARA_APRESENTAR_LIMITACOES` | Autorização e segurança foram atendidas, mas os dados permitem mostrar apenas cobertura, ausências e limitações | Sistema, por regra versionada |
| `APRESENTADO` | Escopo, evidências e limitações foram mostrados | Gerente registra a ocorrência |
| `REVISADO_COM_CLIENTE` | Cliente reconheceu, corrigiu ou contextualizou a leitura e declarou ciência das limitações | Cliente manifesta; gerente apenas registra |
| `INCONCLUSIVO_RECONHECIDO_PELO_CLIENTE` | Cliente tomou ciência de que a leitura é limitada e decidiu se deseja continuar | Cliente manifesta; gerente apenas registra |
| `CONTESTADO` | Cliente contesta parte material ainda não resolvida | Cliente manifesta; sistema preserva a divergência |
| `EXPIRADO` | Atualização ou regra nova tornou o snapshot inadequado | Sistema |

O gerente não pode atribuir unilateralmente `REVISADO_COM_CLIENTE` nem encerrar uma contestação em nome do cliente. Estados de apresentação são distintos dos estados de prontidão dos dados definidos em 5.3. Autorização, finalidade, segurança e mascaramento são obrigatórios nos dois modos de aptidão; `APTO_PARA_APRESENTAR_LIMITACOES` não autoriza totais, sinais ou interpretações que os dados não sustentem.

Regras de passagem:

- `Minha realidade` pode começar após `APRESENTADO`, mesmo que o conteúdo apresentado tenha sido somente de limitações;
- orçamento ou compromisso somente avançam depois de `REVISADO_COM_CLIENTE` ou `INCONCLUSIVO_RECONHECIDO_PELO_CLIENTE`;
- dados insuficientes não impedem a declaração de um objetivo, mas tornam orçamento e compromisso explicitamente provisórios;
- o cliente pode encerrar depois do raio-X ou recusar qualquer etapa;
- em uma nova consulta, fatos atualizados são revisados antes de reapresentar o plano anterior.

## 10.3 Minha realidade — Diagnosticar

Finalidade: construir uma leitura compartilhada, sem nota ou sentença.

Perguntas essenciais:

1. Esta leitura corresponde ao que você viveu no período?
2. Qual parte parece correta e qual precisa de explicação ou correção?
3. Houve algum evento fora do habitual?
4. Existe renda, conta, despesa ou compromisso importante que não aparece?
5. Há alguma categoria que não representa a finalidade real?
6. Quais compromissos você considera essenciais neste momento?
7. Qual aspecto gostaria de compreender ou organizar primeiro?

Informações que poderão ser declaradas:

- renda e despesa não observadas;
- evento extraordinário;
- mudança profissional ou familiar relevante;
- finalidade de uma movimentação;
- compromisso futuro;
- classificação pessoal entre essencial e ajustável;
- discordância sobre categoria ou ligação;
- restrição do escopo que deseja discutir.

Saídas:

- resumo da realidade reconhecida;
- correções e contexto;
- evidências reconhecidas pelo cliente;
- asserções declaradas ligadas às evidências, sem converter inferência ou categoria em fato técnico;
- hipóteses que permanecem;
- tema escolhido para aprofundamento;
- estado contextual: reconhecido, reconhecido com ressalvas, contestado ou inconclusivo reconhecido.

## 10.4 Meus objetivos — Sonhar

Finalidade: registrar uma realização, proteção ou mudança que tenha significado para o cliente.

Perguntas essenciais:

1. Que realização, proteção ou mudança tornaria esta organização útil para você?
2. Como você prefere descrever esse objetivo?
3. Ele é individual ou compartilhado?
4. Existe um valor ou uma faixa aproximada?
5. Qual prazo ou horizonte seria desejável?
6. Há algum valor já destinado especificamente a ele?
7. Qual prioridade possui diante de outros objetivos?
8. O que pode ser flexibilizado: valor, prazo ou contribuição?
9. Que informação ainda falta para defini-lo melhor?

Metadados candidatos:

- nome e descrição;
- titularidade;
- motivação opcional;
- valor ou faixa;
- prazo;
- prioridade;
- valor já acumulado confirmado;
- flexibilidade de valor e prazo;
- estado: exploração, definição, ativo, pausado, realizado ou encerrado.

O cliente poderá não ter ou não desejar registrar um objetivo. Nesse caso, a jornada pode terminar com compreensão e uma pergunta para reflexão, sem ser considerada fracasso.

## 10.5 Meu plano — Orçar

Finalidade: combinar realidade, contexto e objetivo em alternativas transparentes.

Componentes candidatos:

- período ou ciclo financeiro;
- renda de referência e sua origem;
- faixa de renda para situações irregulares;
- compromissos essenciais declarados;
- despesas ajustáveis escolhidas pelo cliente;
- obrigações e dívidas observadas ou declaradas;
- contribuição para objetivos;
- margem para imprevistos;
- resultado esperado;
- premissas e informações ausentes;
- cenário escolhido.

Perguntas essenciais:

1. Qual referência de renda parece prudente para o próximo ciclo?
2. Existe mudança de renda ou compromisso já prevista?
3. Quais valores você considera essenciais ou contratuais?
4. O que você próprio considera ajustável?
5. Que margem deseja preservar para imprevistos?
6. Qual contribuição parece possível sem comprometer necessidades essenciais?
7. Como o plano deveria funcionar em um mês de renda menor?
8. Entre ajustar valor, prazo ou contribuição, qual alternativa prefere?
9. Qual premissa ainda deixa o plano inseguro ou incompleto?

Simulações permitidas:

- manter as condições declaradas;
- variar prazo;
- variar valor-alvo;
- contribuição fixa, faixa ou percentual escolhido;
- cenários conservador, esperado e favorável;
- inclusão de margem para imprevistos.

Cálculo indicativo simples, quando aplicável:

```text
(valor desejado − valor já destinado) ÷ ciclos restantes
```

O resultado deverá ser rotulado como estimativa sem rentabilidade, inflação, impostos ou garantia, salvo se futuramente existirem regras específicas validadas.

## 10.6 Meu progresso — Poupar

Finalidade: transformar o plano em próximo passo voluntário e revisável.

Perguntas essenciais:

1. Qual próximo passo você deseja assumir?
2. Prefere um valor, uma faixa ou um percentual?
3. Com que frequência e em qual data pretende realizá-lo?
4. Qual será o destino escolhido para esse recurso?
5. Como deseja confirmar que foi realizado?
6. Qual alternativa seria realista em um mês de menor renda?
7. Que mudança deveria provocar revisão do plano?
8. Quando deseja revisá-lo?
9. Há alguma informação necessária antes de começar?

Saídas candidatas:

- objetivo relacionado;
- valor, faixa ou percentual;
- frequência;
- primeira data;
- destino genérico ou conta indicada;
- forma de confirmação;
- alternativa para período adverso;
- gatilhos de revisão;
- data da próxima conversa.

Uma aplicação ou transferência só poderá ser ligada ao compromisso após confirmação. Saldo positivo não será tratado automaticamente como poupança.

## 10.7 Síntese final da conversa

Separar claramente:

1. o que foi observado;
2. o que foi calculado;
3. o que o cliente informou ou corrigiu;
4. o objetivo declarado;
5. as estimativas e premissas;
6. o plano escolhido;
7. o compromisso, se houver;
8. limitações e pendências;
9. próxima revisão.

Estados possíveis da sessão:

- jornada concluída;
- concluída parcialmente;
- aguardando informação;
- adiada por escolha do cliente;
- inconclusiva por dados;
- encerrada a pedido do cliente.

---

# 11. Roteiro operacional do gerente

## 11.1 Antes da conversa

1. Confirmar vínculo e autorização de acesso.
2. Selecionar período e snapshot.
3. Verificar cobertura, atualização e lacunas.
4. Revisar tratamentos críticos de cartão e transferências.
5. Revisar o conjunto compacto de evidências pré-selecionado por regra versionada de valor, recorrência, variação, incerteza ou pergunta do cliente; o limite inicial de cinco é hipótese de usabilidade.
6. Se substituir uma evidência, registrar o motivo e preservar acesso às demais, sem montar uma narrativa unilateral.
7. Remover perguntas que dependam de inferência psicológica.
8. Não preparar objetivo, corte ou compromisso em nome do cliente.

## 11.2 Abertura sugerida

> Esta visão organiza os dados disponíveis no período e pode não representar toda a sua realidade. Primeiro vamos conferir o que foi observado e o que ficou de fora. Depois, se fizer sentido para você, podemos relacionar essa visão aos seus objetivos e pensar em um próximo passo. Você pode corrigir, não responder ou encerrar a qualquer momento.

## 11.3 Durante o raio-X

Usar o padrão:

```text
Evidência observada
      ↓
Explicação curta e limite
      ↓
Pergunta aberta
      ↓
Contexto do cliente
      ↓
Confirmação de entendimento
```

Evitar palestra e excesso de gráficos. O gerente deverá verificar o entendimento antes de avançar.

## 11.4 Transição para educação financeira

Antes de iniciar os objetivos, realizar uma confirmação:

> Com base no que vimos, qual é a principal constatação e qual limitação você considera mais importante? Deseja usar essa leitura para conversar sobre algum objetivo ou organização futura?

## 11.5 Teach-back

O gerente pedirá que o cliente explique com suas palavras:

- o que a leitura representa;
- o que ficou de fora;
- qual objetivo foi escolhido, se houver;
- quais premissas sustentam o plano, se houver;
- quando o plano deverá ser revisto, se uma revisão tiver sido voluntariamente combinada.

O teach-back é uma decisão de produto a validar. Ele avalia a clareza da explicação e da interface, não a inteligência, a concordância ou o desempenho do cliente. Ausência de objetivo, plano ou revisão não reduz a qualidade da sessão.

## 11.6 Depois da conversa

Registrar apenas o necessário:

- snapshot utilizado;
- evidências apresentadas;
- contexto e correções autorizados;
- objetivo;
- cenários considerados;
- plano escolhido;
- compromisso ou decisão de não assumir compromisso;
- pendências;
- próxima revisão.

Evitar texto emocional livre quando campos estruturados forem suficientes.

## 11.7 Microconteúdos contextuais

Cada conteúdo educativo deve tratar um conceito, explicitar seu limite e terminar com uma pergunta. A duração inicial de 30 a 60 segundos é hipótese de experiência a validar. Ele aparece somente quando relacionado a uma evidência ou dúvida.

Padrão:

```text
O que é
  ↓
Por que importa
  ↓
O que não permite concluir
  ↓
Pergunta ao cliente
```

| Gatilho | Conceito | Pergunta de retorno |
|---|---|---|
| Cobertura incompleta | Conta ausente não equivale a saldo zero e pode alterar totais | “O que pode estar faltando?” |
| Crédito em conta | Empréstimo aumenta caixa, mas não é renda e cria compromisso | “Como esse crédito deve ser entendido no seu contexto?” |
| Transferência própria | Muda a localização do dinheiro e só é neutralizada com evidência | “Esta ligação está confirmada?” |
| Cartão e fatura | Compra detalhada é candidata a consumo conforme sua natureza; pagamento da fatura é liquidação | “O detalhamento permite entender a natureza e evitar dupla contagem?” |
| Caixa e visão financeira tratada | As lentes respondem perguntas diferentes e nenhuma é diagnóstico | “Qual visão ajuda mais a compreender este caso?” |
| Renda variável | Média pode esconder meses baixos, sazonalidade e ausência | “Qual cenário parece prudente para você?” |
| Sem categoria | Valor desconhecido não autoriza conclusão sobre comportamento | “Esse montante compromete a leitura?” |
| Essencial e ajustável | O sistema não conhece prioridades, dependentes e contexto | “Como você classificaria este compromisso?” |
| Estimativa | Simulação depende das premissas exibidas e não é previsão | “Que premissa você deseja alterar?” |
| Planejado e realizado | Diferença serve para revisão, não para avaliação moral | “O que mudou: realidade, prioridade ou plano?” |

## 11.8 Competências necessárias

O gerente deverá ser capacitado para:

1. explicar cobertura, atualização e proveniência;
2. diferenciar caixa, diferença do fluxo tratado, saldos de conta, patrimônio e compromissos;
3. reconhecer dupla contagem e incerteza;
4. formular perguntas abertas;
5. praticar escuta e confirmação;
6. distinguir fato, declaração, estimativa, plano e hipótese;
7. conduzir comparação de cenários;
8. reconhecer quando deve se abster;
9. registrar correções sem apagar a fonte;
10. usar linguagem não julgadora.

Questões psicológicas, coerção financeira, violência, perda de capacidade decisória ou sofrimento fora da competência do gerente exigem interrupção e encaminhamento conforme protocolo institucional aprovado.

Antes de qualquer conversa real, são gates obrigatórios:

- treinamento mínimo e avaliação de competência do gerente;
- protocolo de abstenção, interrupção e encaminhamento;
- responsável institucional por casos sensíveis;
- canal operacional de supervisão ou segunda revisão;
- registro e tratamento de incidentes.

A integração digital desse canal à plataforma pode evoluir depois; o processo seguro não pode ser adiado.

---

# 12. Contratos lógicos candidatos

Estes contratos descrevem responsabilidades de informação. Não representam tabelas físicas, endpoints ou eventos aprovados.

## 12.1 Núcleo do Raio-X

### `SnapshotRaioXFinanceiro`

Agrega uma leitura imutável utilizada na preparação e na conversa.

Campos candidatos:

- identificador e versão;
- cliente;
- período solicitado e período efetivamente coberto;
- data de geração;
- fontes incluídas;
- versão das regras semânticas;
- cobertura;
- visões financeiras disponíveis;
- indicadores;
- fluxos;
- sinais;
- limitações;
- estado de prontidão.

Invariante: uma conversa sempre aponta para a versão exata do snapshot que foi apresentada.

### `RegistroApresentacaoRaioX`

- snapshot e sessão relacionados;
- gerente, cliente e escopo autorizado;
- data e hora da apresentação;
- estado de apresentação;
- manifestação do cliente;
- correções, contestações e limitações reconhecidas;
- autoria de cada mudança;
- motivo de expiração ou substituição.

Invariante: somente o sistema altera estados técnicos; reconhecimento, contestação ou decisão de continuar exigem manifestação do cliente, que o gerente registra sem reclassificá-la como evidência observada.

### `CoberturaFonteFinanceira`

- instituição, marca, conta ou cartão;
- tipo de recurso;
- consentimento do Open Finance, quando aplicável;
- autorização de exibição das transações;
- escolha de exibição dos dados da conta;
- estado do recurso;
- autorização institucional para a relação gerente-cliente, oriunda de fonte externa a este conjunto;
- período disponível;
- última atualização da conta, transações e saldo;
- moedas;
- lacunas;
- componentes disponíveis;
- restrições.

Invariante: ausência de conta ou período não gera valores iguais a zero.

### `MovimentacaoCanonica`

- identificadores da fonte e do registro canônico;
- cliente, instituição, conta ou cartão;
- data, hora, valor e moeda;
- natureza contábil;
- descrição protegida;
- estado e visibilidade;
- categoria original e atual;
- origem da categorização;
- tipo de transação e origem técnica — conta, cartão, manual ou divisão;
- vínculo com complemento de conta ou cartão;
- vínculos de estorno, divisão, duplicidade ou atualização;
- proveniência.

Invariante: o registro canônico preserva a fonte; tratamentos posteriores são versionados em camadas separadas.

### `ClassificacaoEconomica`

- movimentação relacionada;
- papel econômico candidato;
- regra utilizada;
- versão da regra;
- evidências;
- confiança;
- estado de validação;
- correção ou contexto declarado.

Invariante: a categoria operacional não determina sozinha o papel econômico.

### `ConciliacaoTransferencia`

- ponta de origem e ponta de destino;
- tipo: própria confirmada, provável, externa confirmada, inconclusiva ou parcial;
- evidências de correspondência;
- regra e versão;
- confiança;
- decisão de neutralização;
- confirmação ou contestação do cliente.

Invariante: somente transferência própria confirmada poderá ser neutralizada automaticamente na diferença do fluxo tratado padrão; transferência externa confirmada continua sendo movimento de terceiro e não recebe esse tratamento.

### `EventoCartaoTratado`

- compra relacionada;
- valor observado;
- valor total e moeda original inequívoca, quando comprovados;
- parcela atual e total de parcelas, quando preenchidos;
- calendário futuro, somente quando houver fonte explícita;
- fatura;
- vencimento;
- pagamento relacionado;
- estorno ou contestação;
- disponibilidade do detalhamento;
- visão financeira tratada e visão de caixa;
- estado do vínculo, fonte, evidências e limitações;
- risco de dupla contagem.

Invariante: compra e liquidação de fatura nunca são tratadas simultaneamente como consumo.

### `IndicadorExplicavel`

- nome e definição;
- valor, unidade e moeda;
- período;
- classe de informação;
- fórmula e versão;
- componentes incluídos e excluídos;
- cobertura;
- limitações;
- ligação com as evidências;
- comparação utilizada.

### `FluxoVisual`

- visão financeira tratada ou de circulação;
- nó de origem e destino;
- valor;
- participação no denominador;
- classe e confiança;
- estado de conciliação;
- lista de componentes;
- regra de agrupamento em “Outros”.

### `SinalConversa`

- tema;
- evidência e indicador relacionados;
- regra de detecção;
- materialidade;
- cobertura;
- limitações;
- pergunta sugerida;
- prioridade;
- ação de facilitação do gerente;
- manifestação ou escolha do cliente;
- contexto e estado após a conversa.

Invariante: um sinal nunca cria automaticamente objetivo, corte de gasto, cenário, plano ou compromisso.

## 12.2 Núcleo da jornada educativa

### `ContextoInformadoCliente`

- tipo de contexto;
- descrição mínima necessária;
- valor e período, quando aplicável;
- movimentação ou indicador relacionado;
- autoria;
- sensibilidade;
- finalidade e restrição de uso;
- validade;
- estado de confirmação.

### `ObjetivoFinanceiro`

- nome e descrição;
- titularidade;
- escopo individual ou compartilhado;
- consentimento de cada participante quando compartilhado;
- motivação opcional;
- valor ou faixa;
- prazo;
- prioridade;
- valor já destinado e origem da confirmação;
- contribuição indicativa;
- flexibilidade;
- estado;
- autoria e versão.

### `CenarioOrcamentario`

- período e tipo de ciclo;
- renda de referência e origem;
- faixa ou sazonalidade;
- compromissos essenciais declarados;
- despesas ajustáveis planejadas;
- obrigações e dívidas;
- objetivos contemplados;
- margem para imprevistos;
- resultado esperado;
- premissas;
- limitações;
- consistência aritmética: não verificada, consistente ou inconsistente;
- estado da escolha: apresentado, compreendido, escolhido pelo cliente ou pendente;
- sustentabilidade percebida e declarada pelo cliente.

Invariante: consistência aritmética não significa que o cenário seja sustentável, recomendado ou tecnicamente “confirmado”.

### `CompromissoFinanceiroEducativo`

- objetivo relacionado;
- tipo de próximo passo;
- valor, faixa ou percentual;
- frequência;
- primeira data;
- destino genérico;
- alternativa em período adverso;
- forma de confirmação;
- gatilhos de revisão;
- estado.

### `ExecucaoCompromisso`

- compromisso relacionado;
- data e valor;
- forma de evidência;
- movimentação candidata, quando houver;
- confirmação do cliente;
- confiança do vínculo;
- contexto de diferença;

Invariante: sem confirmação ou vínculo explícito, uma movimentação semelhante não comprova execução.

### `RegistroConversa`

- participantes e escopo autorizado;
- snapshot apresentado;
- evidências discutidas;
- identificadores dos prompts aprovados utilizados;
- resultados estruturados estritamente necessários;
- correções e contexto;
- objetivo;
- cenários comparados;
- escolha do cliente;
- compromisso ou decisão de não assumir;
- pendências;
- síntese reconhecida ou contestada;
- próxima revisão;
- estado da sessão.

Invariante: não armazenar transcrição integral, respostas emocionais ou narrativa familiar, salvo finalidade indispensável, base autorizadora e consentimento específicos.

### `RevisaoJornada`

- jornada e versão anterior;
- novo snapshot;
- mudanças observadas;
- mudanças declaradas;
- comparação entre planejado e realizado;
- decisão de manter, ajustar, pausar ou encerrar;
- nova versão dos objetos afetados;
- próxima revisão.

## 12.3 Registro de regras semânticas

Cada cálculo ou tratamento candidato deverá possuir:

- identificador e nome;
- objetivo negocial;
- entradas e saídas;
- definição formal;
- premissas;
- exceções;
- proprietário negocial;
- responsável técnico;
- versão e vigência;
- testes unitários e casos adversariais;
- tabelas e campos utilizados;
- impacto quando a regra falha;
- aprovação necessária;
- estado: hipótese, em validação, aprovado, suspenso ou substituído.

---

# 13. Mapa mínimo de dados atuais

## 13.1 Tabelas centrais

| Necessidade | Fonte candidata | Contribuição | Validação ainda necessária |
|---|---|---|---|
| Movimentações | `TRAN_RLZD_INST_PCT` | Cliente, instituição, conta, produto, valor, moeda, natureza, data, categoria, tipo, estado, visibilidade e atualização | Grão, duplicidade, partições, domínios, estados, divisão, ocultação e histórico de atualizações |
| Contas e cobertura | `INF_OPB_CT_CLI` | Conta, instituição, marca, tipo, autorização de exibição, estado do recurso, última atualização e identificação | Cobertura real, vigência, comportamento BB versus Open Finance e qualidade dos identificadores |
| Contraparte de conta | `CMPT_TRAN_RLZD_CC` | Identificadores da contraparte, conta, titularidade possível, MCC, CNAE e data contábil documentada somente para BB | Preenchimento por origem, sensibilidade, possibilidade de conciliação e ausência de chave universal entre pontas |
| Categorias | `CTGR_TRAN_OPB` e `GR_CTGR_TRAN` | Descrições, grupos e estrutura de categorização | Domínios ativos, categorias personalizadas, ambiguidades e aderência ao papel econômico |

## 13.2 Tabelas condicionais

| Necessidade | Fonte candidata | Contribuição | Condição de uso |
|---|---|---|---|
| Compras e parcelas | `CMPT_TRAN_RLZD_CRT` | Cartão, referência de fatura, tipo de pagamento, número e quantidade de parcelas, valor relacionado à moeda da movimentação e data de entrada na fatura | Priorizar somente após validar grão, preenchimento, significado dos valores e relação com a tabela central; não presumir valor total, moeda original inequívoca ou calendário futuro |
| Faturas | `FAT_CRT_CRD` | Informações de fatura e estados associados | Exige perfilamento conjunto com compras e pagamentos. O catálogo diz que a tabela contém faturas de outras instituições, mas documenta o estado como preenchido somente para fatura BB; não prometer estados multibanco antes de resolver essa inconsistência |
| Saldos | `SDO_OPB_CT_CLI` | Saldo disponível, bloqueado ou identificado como investimento, moeda e atualização | Exibir apenas com data da origem, sem chamar de patrimônio total e sem somar tipos até comprovar que são aditivos |
| Categorias vinculadas ao cliente | `CTGR_TRAN_OPB_CLI` | Possível apoio a classificações personalizadas | Validar finalidade, cardinalidade e relação com a categoria vigente da movimentação |
| Renda informada | `REN_INFD_CLI` | Renda manual, data e versão | É declarada, não validada; uso atual e qualidade precisam ser comprovados |
| Orçamento por grupo | `GR_ORC_CT_GRDR_OPB` | Valor planejado por grupo e vigência | Estrutura produtiva e período de convivência precisam ser comprovados |
| Orçamento por categoria | `CTGR_ORC_CT_OPB` | Valor planejado por categoria | Relacionamento, vigência e uso produtivo precisam ser comprovados |
| Lançamento incluído ou dividido | `TRAN_INCD_CLI` | Mistura potencial de lançamento manual declarado e filhos de divisão de evento observado | Separar `MANUAL_DECLARADO` de `DIVISAO_DE_OBSERVADO`; preservar `NR_TRAN_RLZD_OGM` e substituir o pai pelos filhos apenas na visão categorial, sem dupla contagem financeira |
| Histórico auxiliar | `AUX_TRAN_RLZD_UM`, `AUX_TRAN_RLZD_DOIS`, `AUX_CMPT_CC_UM`, `AUX_CMPT_CC_DOIS`, `AUX_CMPT_CRT_UM` e `AUX_CMPT_CRT_DOIS` | Possível extensão histórica das transações e dos complementos de conta e cartão | Usar apenas após comprovar migração, janelas temporais, integridade entre principal e complementos e deduplicação durante estados intermediários |
| Controle e roteamento histórico | `CTL_PSQ_LCTO_CLI` e `CTL_PRCT_MIGR` | Candidatas a indicar onde consultar e o estágio do processo de migração | Perfilá-las junto às auxiliares; não presumir que o roteiro físico elimina sobreposição, lacuna ou estado intermediário |

O catálogo descreve como intenção física uma janela de 18 meses na tabela principal, 18 meses no primeiro conjunto auxiliar e 24 meses no segundo. Isso não comprova disponibilidade contínua por cliente; controles de migração, disparo por acesso, lacunas e sobreposição devem ser perfilados antes de prometer o horizonte histórico.

## 13.3 Campos relevantes da tabela coração

O catálogo indica em `TRAN_RLZD_INST_PCT` candidatos para:

- identificação: `NR_TRAN_INST_PCT`, `NR_PTC`, `CD_CLI`;
- instituição e conta: `NR_MCA_PCT_OPB`, `CD_INST_PCT`, `NR_AG_TITR`, `CD_CT_TITR`, `NR_SEQL_CT_CLI`;
- valor e moeda: `VL_TRAN`, `CD_TIP_MOE_CRR`;
- descrição: `TX_DCR_TRAN`, `TX_CMPR_DCR_TRAN`, `TX_DCR_TRAN_OGNL`;
- direção e tempo: `CD_NTZ_CTB_TRAN`, `DT_TRAN`, `HR_TRAN`;
- categorias: `CD_CTGR_TRAN`, `CD_CTGR_TRAN_OGNL`, `CD_CLSC_MTO_CTGR`, `CD_HASH_AGPT_TRAN`;
- estado e tipo: `CD_EST_TRAN_INST`, `CD_TIP_TRAN`;
- visibilidade: `IN_VSLO_EVT`, `IN_VSLO_CX`, `IN_VSLO_CSM`, `IN_OCTR_TRAN`;
- manutenção: `TS_INCL_TRAN`, `TS_ATL_TRAN`;
- tratamento especial: `IN_DVS_LCTO`.

A existência física não comprova preenchimento, confiabilidade ou adequação. Todos os campos permanecem candidatos até perfilamento.

Em `INF_OPB_CT_CLI`, `NR_SEQL_AUTZ_OPB`, `IN_AUTZ_EXB_TRAN`, `IN_EXB_DADO_CT` e `CD_EST_RCS_OPB` são candidatos a representar dimensões distintas de autorização, exibição e estado do recurso. Eles não devem ser condensados em um único “consentimento ativo” e nenhum comprova, por si só, a autorização institucional do gerente para atender aquele cliente.

## 13.4 Lacunas que as tabelas atuais não resolvem

- autorização institucional do gerente para consultar cada cliente;
- dimensão confiável para nome de exibição de todas as instituições e marcas;
- inventário completo de contas que o cliente possui fora do consentimento disponível;
- chave determinística universal de conciliação entre pontas de transferências;
- definição negocial aprovada de renda externa, usos financeiros e diferença do fluxo tratado;
- cobertura completa de dívidas, patrimônio e obrigações futuras;
- objetivo, motivação, prioridade e flexibilidade;
- orçamento consolidado cocriado;
- compromisso e execução vinculados a objetivo;
- contexto informado durante a conversa;
- registro, confirmação e revisão da jornada;
- protocolos de acesso a informações compartilhadas ou familiares.

## 13.5 Classificação de viabilidade

| Entrega | Situação preliminar |
|---|---|
| Movimentações por cliente, data, instituição e natureza | Possível após validar grão, estados e autorização |
| Cobertura, contas e atualização | Possível após validar semântica e preenchimento de `INF_OPB_CT_CLI` |
| Totais brutos de caixa | Possível após deduplicação, estados, visibilidade e moeda |
| Categorias e grupos | Possível após validar catálogo ativo e confiança |
| Diferença do fluxo tratado | Depende de taxonomia de papéis financeiros, decomposição sem dupla contagem e validação especializada |
| Comparação entre bancos | Possível após resolver nomes, contas e atualização |
| Sankey de composição financeira | Condicional a tratamentos, agrupamentos, teste de conservação e alternativa independente |
| Transferências próprias confirmadas | Possível apenas na parcela sustentada por evidência suficiente |
| Transferências prováveis | Possível como hipótese, sem neutralização automática |
| Cartão sem dupla contagem | Condicional ao perfilamento conjunto de compra, fatura e pagamento |
| Saldos por conta | Condicional à atualização e ao tipo de saldo |
| Renda declarada existente | Candidata; não validada e não observada |
| Orçamento existente | Candidato; uso produtivo e vigência não comprovados |
| Objetivos e compromissos | Exigem novos contratos ou fontes declaradas |
| Registro e acompanhamento da conversa | Exigem novos contratos e governança |

---

# 14. Plano obrigatório de perfilamento dos dados

Antes de aprovar qualquer regra ou tela, responder com dados reais controlados:

## 14.1 Grão e cardinalidade

- Qual é a unicidade real de `NR_TRAN_INST_PCT` e `NR_PTC`?
- Uma transação pode possuir múltiplos complementos?
- Como atualizações e deleções lógicas aparecem historicamente?
- Como lançamentos divididos se relacionam ao original?
- Existe sobreposição entre tabelas principais e auxiliares?

## 14.2 Cobertura temporal

- Quantos meses estão disponíveis por origem e tipo de conta?
- Qual é a distribuição de atualização?
- Quais lacunas são frequentes?
- Como identificar mês parcial?
- Como consentimento revogado afeta o histórico exibível?

## 14.3 Valores e moedas

- Qual é o sinal efetivo de `VL_TRAN` por natureza contábil?
- Existem zeros, negativos e moedas diferentes?
- O valor de cartão representa compra, parcela ou fatura em cada tipo?
- Como arredondamentos e moeda original se comportam?

## 14.4 Estados e visibilidade

- Quais domínios efetivos existem em `CD_EST_TRAN_INST` e `CD_TIP_TRAN`?
- Quando uma transação futura entra no caixa observado ou na visão de compromissos?
- Como ocultação e indicadores de fluxo de caixa são usados?
- Os indicadores existentes já evitam compra mais fatura? Com qual regra?

## 14.5 Categorias

- Qual percentual está sem categoria?
- Qual é a distribuição por mecanismo de classificação?
- Os códigos `F`, `R`, `M` e `C` representam apenas o mecanismo documentado, sem serem interpretados como probabilidade ou confiança?
- Como categoria original, atual e personalizada se relacionam?
- Há fonte de auditoria que permita atribuir uma correção ao cliente?
- Como “Sem categoria”, “Gastos Diversos” e outras categorias amplas se comportam nos dados?
- Quais contradições do catálogo aparecem nos dados?
- Categoria de transferência, aplicação, resgate, saque, fatura e empréstimo é consistente?

## 14.6 Transferências

- Qual percentual possui contraparte?
- CPF ou CNPJ, conta, instituição, data e valor são preenchidos com que qualidade?
- Existem identificadores compartilhados entre duas pontas?
- Quantas correspondências seriam confirmadas, prováveis ou inconclusivas?
- Qual é a taxa de falso vínculo em amostra validada manualmente?

## 14.7 Cartões

- Qual é o grão de cada evento?
- Como compra à vista, compra parcelada, estorno, fatura e pagamento aparecem?
- O valor total e o valor da parcela coexistem?
- Como fatura aberta, fechada e paga são representadas?
- Como resolver a contradição documental entre faturas de outras instituições na tabela e estado de fatura preenchido somente para BB?
- Qual é a cobertura efetiva dos estados por origem antes de exibir aberta, fechada, paga, parcial, mínima ou vencida?
- Em quais casos não existem compras detalhadas?
- Existe vínculo comprovável entre compra, fatura e pagamento? Qual estado e evidência esse vínculo pode carregar?

## 14.8 Orçamento, renda e saldos

- As tabelas estão ativas e preenchidas?
- Qual é a última data de uso?
- Qual estrutura substitui qual?
- Renda e orçamento têm versões coerentes?
- Saldos possuem atualização compatível com o raio-X?
- Os tipos de saldo são mutuamente exclusivos, sobrepostos ou aditivos?

## 14.9 Saídas do perfilamento

- relatório de qualidade por campo e origem;
- dicionário de domínios efetivos;
- chaves e cardinalidades comprovadas;
- conjunto de casos canônicos e adversariais;
- decisões semânticas aprovadas;
- regras rejeitadas;
- limites de cobertura;
- viabilidade atualizada de cada componente do MVP.

---

# 15. Recorte do MVP ponta a ponta

## 15.1 Princípio de recorte

O MVP precisa validar a proposta de valor completa. Entregar somente gráficos validaria uma ferramenta de consulta, mas não validaria se o raio-X melhora a conversa de educação financeira.

Por isso, o MVP candidato atravessa as duas partes com profundidade controlada:

```text
Raio-X mínimo confiável
        +
Conversa educativa mínima
        =
MVP ponta a ponta
```

“Ponta a ponta” descreve a capacidade do produto, não uma obrigação da sessão: o raio-X deve funcionar sozinho e o cliente pode recusar ou encerrar a conversa educativa sem que isso seja tratado como insucesso.

## 15.2 Entrega mínima do Raio-X

- consulta autorizada de cliente pessoa física;
- período padrão candidato de doze meses, usando apenas os meses efetivamente disponíveis;
- faixa de cobertura e atualização;
- conjunto compacto de indicadores executivos, com quantidade validada por teste;
- visão de caixa observada;
- evolução mensal;
- composição de créditos e débitos por identificador técnico seguro de fonte ou conta;
- tabela de movimentações, natureza contábil e descrições protegidas;
- tratamento conservador contra dupla contagem de cartão: se compra, fatura e pagamento não forem distinguíveis, o valor permanece inconclusivo e fora da diferença do fluxo tratado;
- valor sem categoria e sem conciliação;
- drill-down até a movimentação;
- conjunto curto de perguntas baseadas em evidências; a hipótese inicial é de até três;
- painel de limitações.

Esse núcleo é o mínimo garantido. A visão financeira tratada, o Sankey e os componentes de cartão e compromissos são ativados apenas após seus gates específicos. A ausência de um módulo condicional não pode ser mascarada como zero nem bloquear a leitura observacional que permaneça responsável.

## 15.3 Entrega mínima da conversa educativa

- reconhecimento, correção ou contestação da visão observacional;
- registro de contexto mínimo;
- escolha de um tema para aprofundamento;
- registro de até três objetivos na interface inicial, como limite de usabilidade a validar, trabalhando um como prioritário;
- possibilidade de anotar outros objetivos como não trabalhados nesta conversa, sem invalidá-los;
- valor, prazo, prioridade e flexibilidade do objetivo;
- uma simulação de orçamento simples com premissas visíveis;
- um próximo passo voluntário;
- data ou gatilho de revisão;
- síntese separando observado, declarado, estimado e planejado;
- registro da conversa vinculado ao snapshot.

Objetivo, orçamento ou compromisso podem permanecer pendentes. A interface não deverá preencher automaticamente aquilo que o cliente não definiu.

## 15.4 O que fica condicional no MVP

| Componente | Gate mínimo | Degradação segura |
|---|---|---|
| Origens, destinos, categorias, aplicações, resgates e transferências separados | Taxonomia financeira, domínios e preenchimento aprovados | Manter créditos e débitos por natureza contábil, com papel inconclusivo |
| Comparação por banco ou conta | Nome de exibição seguro, mesma janela, moeda, atualização, escopo e cobertura comparáveis | Painéis separados por identificador seguro, sem ranking ou comparação direta |
| Visão financeira tratada | Taxonomia e fórmula aprovadas; papéis distinguíveis; decomposição sem dupla contagem | Manter caixa observado e itens inconclusivos separados |
| Sankey | Cobertura, classificação, conciliação, denominadores e teste de conservação aprovados | Duas composições independentes, barras ou tabela |
| Compras, parcelas e faturas | Grão, vínculos, valores, datas e estados perfilados por origem | Mostrar somente eventos distinguíveis; pagamento como caixa e demais valores inconclusivos |
| Compromissos futuros | Fonte explícita ou declaração do cliente | Mostrar apenas parcelas já observadas e recorrências prováveis |
| Posição consolidada | Tipos de saldo, moedas, horários e aditividade comprovados | Posições separadas por conta, tipo, moeda e data |
| Recorrência provável | Regra calibrada, quantidade de ocorrências e meses completos acessíveis | Exibir histórico sem rótulo de recorrência |
| Conciliação probabilística | Evidências, taxa de falso vínculo, limiar e revisão aprovados | Pontas separadas como prováveis ou inconclusivas, sem neutralização |
| Renda e orçamento existentes | Atividade, vigência, autoria, versão e semântica das tabelas comprovadas | Coletar declaração e plano em contratos novos e separados |
| Padrão de uso de conta | Regra explicável, cobertura suficiente e linguagem de hipótese | Exibir apenas totais por conta |
| Planejado versus realizado | Versões comparáveis, vínculo explícito e revisão consentida | Mostrar plano e observado lado a lado, sem atribuir desvio |

## 15.5 O que fica para evolução

- múltiplos cenários salvos;
- vários objetivos simultaneamente no orçamento;
- acompanhamento longitudinal completo;
- sazonalidade e projeções;
- notificações de revisão;
- atualização ou confirmação diretamente pelo cliente;
- colaboração familiar com consentimentos individuais;
- biblioteca extensa de microconteúdos;
- integração da supervisão especializada dentro da plataforma, mantendo o processo e o canal externos obrigatórios desde o piloto.

## 15.6 Ondas de construção e validação

### Onda 0 — Verdade dos dados

- perfilamento;
- modelo canônico;
- taxonomia de papéis financeiros;
- regras de cartão e transferência;
- casos de teste;
- critérios de cobertura.

### Onda 1 — Protótipo do Raio-X

- arquitetura de informação;
- conjunto compacto de indicadores, com quantidade a validar;
- Sankey e alternativas;
- evolução e bancos;
- limitações e drill-down;
- testes com gerentes e especialistas.

### Onda 2 — Protótipo da conversa

- revisão contextual da visão observacional;
- perguntas por pilar;
- objetivo;
- cenário simples;
- compromisso e revisão;
- testes com gerente e voz do cliente.

### Onda 3 — MVP integrado em modo controlado

- snapshot real;
- experiência ponta a ponta;
- registro estruturado;
- operação em modo sombra ou ambiente restrito;
- auditoria de interpretações.

### Onda 4 — Piloto longitudinal

- retorno ao mesmo cliente;
- comparação de snapshots;
- revisão de objetivos e planos;
- avaliação de compreensão, utilidade e segurança ao longo do tempo.

Nenhuma onda inclui oferta comercial.

---

# 16. Cenários integrados de referência

## 16.1 Ana — especialização profissional

### Situação

Renda recorrente identificada, doze meses observados e quatro meses em que os usos tratados superaram a renda identificada. Ana deseja custear uma especialização de R$ 12 mil em dezoito meses.

### Raio-X esperado

- cobertura e meses efetivos;
- entradas recorrentes e extraordinárias separadas;
- evolução das saídas;
- contexto dos quatro meses;
- compromissos conhecidos;
- categorias e valores inconclusivos.

### Conversa

- confirmar se os meses correspondem a eventos extraordinários ou padrão recorrente;
- compreender importância, custo e prazo do objetivo;
- calcular contribuição indicativa simples;
- comparar contribuição, prazo e margem;
- registrar o cenário que Ana considera viável.

### Não concluir

- que quatro meses negativos significam saúde ruim;
- que uma categoria deve ser cortada;
- que o prazo de dezoito meses é inviável antes da simulação e do contexto.

## 16.2 Bruno — renda irregular e reserva

### Situação

Os dados mostram alta variação mensal e saldo anual observado positivo; Bruno declara que sua renda é irregular e deseja formar uma reserva equivalente a seis meses de despesas essenciais.

### Raio-X esperado

- meses com e sem entrada externa;
- faixa, mediana e amplitude da renda;
- ciclos de maior e menor saída;
- saldo e aplicações apenas como posição observada;
- cobertura e renda fora das contas.

### Conversa

- Bruno define o que considera essencial;
- o sistema não calcula seis meses antes dessa declaração;
- comparar cenário conservador, esperado e favorável;
- permitir compromisso por faixa, percentual ou valor mínimo mais adicional;
- combinar revisão diante de mês de baixa.

### Não concluir

- que a média representa a renda mensal disponível;
- que aplicação observada já é a reserva;
- que contribuição irregular significa indisciplina.

## 16.3 Carla — circulação entre três bancos

### Situação

Três bancos, transferências frequentes, compras detalhadas e pagamentos de fatura. Carla deseja separar consumo, reserva e objetivos entre suas contas.

### Raio-X esperado

- visão financeira tratada sem duplicidade;
- visão de circulação entre bancos;
- transferências confirmadas, prováveis e inconclusivas;
- compra separada de liquidação da fatura;
- padrão de uso observado de cada conta, apresentado como hipótese a confirmar.

### Conversa

- confirmar quais contas são próprias e qual uso Carla reconhece em cada uma;
- compreender o objetivo da organização;
- permitir que Carla escolha o papel planejado de cada conta;
- registrar compromisso sem inferir que toda aplicação representa reserva.

### Não concluir

- que todo PIX entre bancos é transferência própria;
- que pagamento de fatura é novo consumo;
- que o papel observado da conta é sua finalidade definitiva.

## 16.4 Diego — dados incompletos

### Situação

Contas desatualizadas, parte relevante sem categoria e uma instituição fora do período observado. Diego deseja organizar um objetivo, mas sua renda completa não está disponível.

### Raio-X esperado

- estado de leitura parcial ou insuficiente;
- valores que podem ser exibidos;
- componentes que não sustentam conclusão;
- ausência claramente distinta de zero.

### Conversa

- registrar o que Diego sabe e deseja informar;
- permitir que ele defina o objetivo;
- manter orçamento e compromisso como provisórios;
- escolher como próximo passo completar informações ou revisar após atualização.

### Não concluir

- que a renda ou despesa não observada não existe;
- que a diferença de fluxo consolidada representa toda a realidade;
- que um plano provisório é previsão confiável.

## 16.5 Variações obrigatórias de teste

| Caso | Risco principal | Resposta esperada |
|---|---|---|
| Cliente não deseja definir objetivo | Coação educativa | Encerrar após o raio-X, sem marcar insucesso |
| Renda cobre apenas necessidades | Culpa ou percentual universal | Não sugerir contribuição; registrar que, nas premissas e necessidades confirmadas pelo cliente, não foi identificada margem para contribuição |
| Categoria contestada | Sobrescrita da fonte | Preservar observado e registrar declaração separada |
| Conta conjunta | Exposição e titularidade | Exigir autorização e limitar detalhes |
| Fatura sem compras | Distribuição fictícia | Mostrar caixa e “fatura sem detalhamento” |
| Empréstimo recebido | Crédito tratado como renda | Separar entrada de financiamento |
| Resgate de investimento | Resgate tratado como renda | Separar movimento patrimonial |
| Aplicação observada | Intenção inferida | Pedir confirmação antes de ligar ao objetivo |
| Compromisso não realizado após emergência | Linguagem punitiva | Registrar mudança e rever o plano |
| Novo dado contradiz plano anterior | Plano prevalece sobre realidade | Reabrir a revisão da visão observacional |
| Baixa familiaridade numérica | Exclusão cognitiva | Linguagem simples, tabela e explicação progressiva |
| Baixa visão | Dependência do gráfico | Alternativa textual e navegação assistiva completa |

---

# 17. Estratégia de validação

## 17.1 Hipóteses principais

1. O gerente consegue compreender a cobertura antes de interpretar os números.
2. O Sankey melhora a compreensão dos fluxos em relação a uma tabela isolada.
3. Um conjunto compacto de indicadores orienta a primeira leitura; sua quantidade e composição precisam ser comparadas em teste.
4. A distinção entre caixa e visão financeira tratada reduz interpretações erradas.
5. O cliente reconhece ou corrige a realidade apresentada.
6. Perguntas vinculadas a evidências melhoram a conversa.
7. A sequência realidade, objetivo, plano e compromisso é compreensível e não coercitiva.
8. O gerente consegue facilitar sem assumir papel terapêutico ou prescritivo.
9. Dados incompletos continuam úteis quando as limitações são explícitas.
10. O valor negocial vem da qualidade da conversa, não da quantidade de indicadores.

## 17.2 Etapas de validação

### Validação semântica financeira

Participantes: especialista financeiro, dados, Negócio e controles.

Avaliar:

- papel econômico;
- fórmulas;
- caixa observado versus fluxo financeiro tratado;
- cartão;
- transferências;
- dívida e patrimônio;
- linguagem e limitações.

### Validação dos dados

Participantes: engenharia, arquitetura, responsáveis pelas fontes e qualidade.

Avaliar:

- grão;
- cardinalidade;
- preenchimento;
- domínios;
- histórico;
- duplicidade;
- atualização;
- performance;
- autorização.

### Validação de utilidade negocial

Participantes: gerentes e Negócio.

Avaliar:

- perguntas que o raio-X responde;
- tempo para localizar evidências;
- excesso ou falta de informação;
- utilidade de cada gráfico;
- qualidade das perguntas sugeridas;
- situações em que a tela não ajuda.

### Validação com clientes

Avaliar:

- reconhecimento da própria realidade;
- clareza dos termos;
- sentimento de respeito e autonomia;
- compreensão das limitações;
- capacidade de contestação;
- utilidade para objetivo e planejamento;
- percepção de pressão ou julgamento.

### Validação metodológica

Avaliar com especialista em educação financeira e, caso a terminologia DSOP seja mantida, com seus responsáveis:

- aderência dos pilares;
- formação necessária;
- uso de nome e marca;
- limites do papel do gerente;
- adaptação de perguntas e materiais;
- propriedade intelectual.

### Piloto controlado

- modo sombra antes da utilização em conversa real;
- casos anonimizados e cenários adversariais;
- dupla revisão das interpretações;
- registro de contestação;
- acompanhamento dos primeiros retornos;
- mecanismo de suspensão de regra ou sinal problemático.

## 17.3 Métricas do Raio-X

- gerente identifica período, cobertura e principal limitação;
- tempo para localizar a origem de um valor;
- concordância entre especialistas sobre o tratamento;
- incidência de dupla contagem;
- percentual de valor inconclusivo;
- taxa de transferências confirmadas, prováveis e não conciliadas;
- taxa de categorias contestadas;
- divergência entre cálculo e movimentações de suporte;
- frequência de Sankey substituído por visual mais seguro;
- compreensão de caixa versus visão financeira tratada.

## 17.4 Métricas da conversa

- cliente consegue explicar um fato e uma limitação;
- objetivo é reconhecido como escolha própria;
- premissas da estimativa são compreendidas;
- plano é considerado viável, provisório ou inviável pelo próprio cliente;
- compromisso possui autoria e possibilidade de revisão;
- gerente utiliza perguntas abertas;
- contexto é registrado sem sobrescrever o observado;
- cliente consegue contestar ou encerrar;
- linguagem é percebida como clara, respeitosa e não pressionadora;
- conversa gera compreensão, próximo passo relevante ou escolha informada de não prosseguir.

## 17.5 Métricas longitudinais

- proporção de revisões realizadas somente entre clientes que voluntariamente combinaram retorno;
- planos adaptados quando o contexto muda;
- diferença entre planejado e realizado compreendida;
- manutenção da compreensão das premissas;
- movimentações ligadas a compromissos com confirmação adequada;
- evolução da percepção de autonomia;
- incidentes de privacidade, julgamento ou falsa precisão.

Não utilizar como sucesso:

- contratação de produto;
- volume financeiro movimentado;
- valor absoluto poupado sem contexto;
- quantidade de objetivos;
- obediência ao plano;
- comparação entre clientes;
- tempo de tela isolado.

O acesso, a conclusão da sessão e a avaliação do gerente não podem depender da criação de objetivo, plano, compromisso ou revisão. Falha de teach-back indica problema potencial na explicação ou na interface, nunca deficiência do cliente.

## 17.6 Erros críticos

Tolerância zero nos testes para:

- dado ausente tratado como zero;
- hipótese apresentada como fato;
- dupla contagem de cartão ou transferência;
- ligação Sankey não sustentada;
- objetivo inferido;
- essencial ou supérfluo definido automaticamente;
- estimativa apresentada como previsão;
- plano definitivo com limitação material escondida;
- compromisso criado sem confirmação;
- inferência de caráter, saúde mental ou causa;
- exposição indevida de dado sensível;
- qualquer elemento comercial na jornada.

## 17.7 Metas candidatas para o piloto

As metas deverão ser recalibradas após uma linha de base. Como ponto de partida:

- 100% dos elementos exibem período, classe e fonte acessíveis;
- 100% dos casos incompletos permanecem explicitamente parciais ou provisórios;
- 100% dos fluxos críticos possuem alternativa acessível;
- ao menos 90% dos participantes distinguem fato de hipótese e ausência de zero;
- ao menos 85% conseguem explicar cobertura, evidência principal e limitação após a apresentação; dificuldades acionam revisão da explicação e da interface;
- ao menos 90% localizam a origem de um valor em até duas interações;
- ao menos 90% classificam a linguagem como clara, respeitosa e sem pressão.

Esses percentuais são critérios candidatos de pesquisa, não evidência de eficácia da metodologia.

---

# 18. Acessibilidade, inclusão e carga cognitiva

- Contraste mínimo compatível com o padrão institucional aplicável.
- Navegação completa por teclado.
- Foco visível, zoom e refluxo de conteúdo.
- Nenhuma distinção somente por cor.
- Gráficos acompanhados de tabela e resumo textual.
- Sankey com alternativa linear contendo origem, destino, valor e confiança.
- Valores absolutos e percentuais com denominador explícito.
- Leitura adequada de moedas, sinais e datas por tecnologia assistiva.
- Uma pergunta principal por etapa.
- Glossário contextual sem jargão.
- Sem animação obrigatória, reprodução automática ou limite de tempo.
- Possibilidade de pausar, salvar e retomar.
- Resumo imprimível ou compartilhável dentro das regras institucionais futuras.
- Exemplos que não presumam casamento, filhos, propriedade, renda fixa ou familiaridade com investimentos.
- Motivação do objetivo opcional.
- Descrições e contrapartes sensíveis mascaradas na visão inicial.
- Detalhes revelados progressivamente e apenas quando necessários.
- Cliente escolhe quanto contexto deseja compartilhar durante a conversa.

## 18.1 Antipadrões de experiência

- Sankey como tela inicial sem cobertura ou como peça decorativa.
- Dashboard com muitos indicadores sem pergunta orientadora.
- Começar por “qual é seu sonho?” antes de validar os fatos.
- Média isolada para representar renda variável.
- Planejado misturado ao realizado.
- Declaração sobrescrevendo a fonte.
- Simulação com premissas ocultas ou precisão excessiva.
- Desvio em vermelho, sequência, perda de pontos ou gamificação de culpa.
- Pergunta condutora com uma resposta considerada correta.
- Gerente em formato de palestra.
- Conteúdo educativo sem relação com a situação atual.
- Pedido de transparência familiar irrestrita.
- Exposição de contraparte ou descrição sensível sem necessidade.
- Sessão considerada incompleta porque o cliente recusou uma etapa.

---

# 19. Governança do framework

## 19.1 Papéis

| Papel | Responsabilidade principal |
|---|---|
| Cliente | Pode reconhecer, corrigir, contestar ou recusar a interpretação; define contexto, objetivos, cenários e compromissos somente quando desejar |
| Gerente | Explicar evidências, facilitar perguntas e registrar decisões autorizadas |
| Negócio | Definir valor esperado, prioridades, limites e critérios de sucesso |
| Especialista financeiro | Validar conceitos, fórmulas e interpretações |
| Especialista em educação financeira | Validar jornada, linguagem, perguntas e formação |
| Dados e engenharia | Comprovar fontes, qualidade, linhagem e execução das regras |
| UX e pesquisa | Validar compreensão, acessibilidade, autonomia e carga cognitiva |
| Privacidade, jurídico e controles | Validar acesso, finalidade, registros sensíveis, retenção e uso da metodologia |
| Segurança e arquitetura | Validar autenticação, autorização, auditoria e contratos técnicos |
| Governança de modelos e regras | Versionar, testar, aprovar, monitorar e suspender inferências |

## 19.2 Direitos de decisão

- Uma regra financeira não é aprovada apenas por tecnologia.
- Uma visualização não é aprovada apenas por preferência estética.
- Uma pergunta não é aprovada apenas por aderência metodológica; precisa ser segura no contexto bancário.
- Uma fonte não é considerada disponível apenas porque consta no catálogo.
- Uma informação declarada não pode ter finalidade ampliada sem nova validação.
- Uma hipótese não pode virar fato por repetição.

## 19.3 Privacidade e minimização

- Consultar somente clientes para os quais o gerente possua autorização comprovada.
- Mostrar apenas o detalhe necessário à finalidade da conversa.
- Mascarar conta, documento, contraparte e descrições sensíveis por padrão.
- Registrar contexto livre apenas quando indispensável.
- Separar informações de pessoas diferentes, inclusive em família ou conta conjunta.
- Permitir correção, contestação, retirada de consentimento e exercício dos direitos aplicáveis.
- Aprovar antes do piloto real as regras de retenção, exclusão, finalidade, acesso por supervisores e tratamento de dados declarados potencialmente sensíveis.
- Manter trilha de quem visualizou, alterou, confirmou ou exportou.
- Submeter a solução à validação formal de privacidade e jurídica antes de piloto real.

## 19.4 Gestão de mudanças

Qualquer alteração em categoria, papel econômico, fórmula, pergunta ou visual deverá registrar:

- problema que motivou a mudança;
- evidência;
- versão anterior e nova;
- impacto retroativo;
- casos de teste;
- aprovações;
- data de vigência;
- plano de reversão;
- necessidade de recalcular snapshots futuros ou históricos.

Snapshots usados em conversas não serão silenciosamente recalculados com regra nova.

## 19.5 Supervisão e contestação

- O gerente poderá sinalizar uma regra como inadequada.
- O cliente poderá contestar evidência ou interpretação.
- Casos inconclusivos poderão ser enviados a revisão especializada, respeitando acesso e finalidade.
- Uma regra poderá ser suspensa sem interromper todo o raio-X.
- Incidentes deverão alimentar o catálogo de testes adversariais.

---

# 20. Síntese crítica das fontes estudadas

## 20.1 Matriz auditável de uso das fontes

As páginas abaixo usam a numeração física do PDF.

| Fonte | Páginas | Natureza da evidência | Decisão prudente incorporada | O que não virou regra |
|---|---:|---|---|---|
| `Desenvolvimento novo perfil financeiro.pdf` | 11–14; 17 | Questionário exploratório, `n=35`, e conclusão normativa | Perguntas sobre suficiência da renda, pagamentos, orçamento, investimento, imprevisto, objetivos e horizonte; bem-estar como finalidade | Escore, perfis endividado/equilibrado/investidor, recomendação de previdência e causalidade |
| `EDUCACAO FINANCEIRA NA ESCOLA-.pdf` | 57–62; 108–117 | Relato escolar com 43 participantes e capítulo conceitual | Objetivo concreto, renda e gastos, plano, acompanhamento, fechamento e aprendizagem ligada à realidade | Eficácia generalizável e atribuição de teach-back; a fonte apresenta devolutiva e atividades, não um protocolo explícito de teach-back |
| `EDUCAÇÃO FINANCEIRA UMA CIÊNCIA COMPORTAMENTAL.pdf` | 5–12 | Revisão e exposição conceitual pelo autor da metodologia | Quatro pilares; registro de entradas e saídas; caminho do dinheiro; objetivo com custo e prazo; poupar distinto de investir | Eficácia comprovada, perfis, periodicidade anual e horizontes universais |
| `IMPORTÂNCIA DA EDUCAÇÃO FINANCEIRA.pdf` | 2–3; 8–12 | Revisão bibliográfica exploratória | Distinguir renda fixa e variável; mapear gastos, objetivos, orçamento e reserva | Regras rígidas de 30 ou 90 dias, ansiedade inferida e julgamento de consumo |
| `NEUROMARKETING.pdf` | 3; 5–10 | Revisão bibliográfica descrita como primeira abordagem | Considerar fatores psicológicos, socioculturais, situacionais e estímulos; desenhar interface não manipulativa | Inferir impulso, emoção ou subconsciente pelas transações e usar explicação neurodeterminista |
| `PLANEJAMENTO FINANCEIRO PESSOAL.pdf` | 3; 5–7 | Revisão bibliográfica breve com dados secundários | Fluxo de caixa, orçamento, metas e horizontes como componentes do planejamento | Promessa causal de resultado; a própria fonte pede aprofundamento |
| `Terapia Financeira 1.pdf` | 24–25; 32; 38; 52; 62 | Dissertação exploratória com amostra de conveniência e entrevista do idealizador | Cliente no controle; profissional apresenta alternativas sem escolher; acompanhamento como hipótese | Equiparar gerente a terapeuta, generalizar eficácia, aplicar testes de perfil ou fórmulas não especificadas |
| `Terapia Financeira 2.pdf` | 1; 4; 10–14 | Artigo derivado do mesmo estudo, com 89 profissionais e 11 clientes | Reforço exploratório da conversa individual ou familiar e necessidade de acompanhamento | Contar como replicação independente ou converter percepção em eficácia |

Fontes locais complementares:

| Fonte | Uso | Limite |
|---|---|---|
| Catálogos GFP | Fontes candidatas, tabela coração, contas, categorias, cartões, saldos e orçamento | Existência no catálogo não comprova preenchimento, atividade, cardinalidade, qualidade ou cobertura |
| Roteiros de descoberta | Perguntas, proteções, cenários, proveniência e viabilidade | Hipótese não é decisão final sem validação do Negócio e dos demais responsáveis |

## 20.2 Força real da evidência

Os PDFs formam um repertório de conceitos, perguntas, linguagem e ferramentas candidatas. São limitados como comprovação de eficácia:

- predominam revisões bibliográficas e relatos descritivos;
- o levantamento de perfil com 35 participantes não documenta validação suficiente;
- o estudo de Terapia Financeira possui 89 profissionais vinculados ao ecossistema e apenas 11 clientes;
- a segunda publicação de Terapia Financeira reutiliza o mesmo estudo;
- os relatos escolares mostram exequibilidade e engajamento, não mudança financeira causal ou longitudinal;
- números, perfis e limites não foram calibrados para os clientes deste produto.
- ferramentas citadas não devem ser tratadas como instrumentos validados, pois as fontes não apresentam protocolos, fórmulas e critérios de aplicação suficientes para esse uso.

Consequência: o framework utiliza as fontes para **formular e testar**, não para declarar que uma regra é cientificamente comprovada.

## 20.3 Convergências aproveitadas

- Compreender entradas e saídas é a base da conversa.
- Tempo, recorrência e contexto importam mais que um total isolado.
- Educação financeira envolve conhecimento, atitude, escolha e acompanhamento.
- Um objetivo continua válido enquanto está sendo explorado; ele se torna simulável quando autoria, valor ou faixa, prazo, prioridade e flexibilidade são declarados.
- Orçamento conecta realidade e objetivos.
- Poupar é diferente de investir e pressupõe intenção.
- Decisões não são puramente numéricas.
- Família e ambiente podem influenciar, mas não devem ser inferidos.
- Bem-estar e autonomia importam mais que acumulação ou obediência.

## 20.4 Tensões resolvidas pelo framework

| Tensão | Decisão adotada |
|---|---|
| Diagnóstico anual versus acompanhamento contínuo | Snapshot periódico mais revisão longitudinal; nenhum acompanhamento compulsivo |
| Compra total versus parcela e caixa | Duas lentes: compromisso econômico e impacto de caixa |
| Perfil financeiro versus conversa | Evidências e perguntas, sem perfil ou nota |
| Sonho primeiro versus segurança básica | Objetivo é central, mas plano não ignora essenciais, dívidas, margem e restrição de renda |
| Família como unidade versus privacidade | Participação individual e consentida; sem transparência familiar presumida |
| Terapeuta versus gerente | Gerente é facilitador capacitado, não terapeuta |
| Método personalizado versus escala | Regras estruturam a jornada; contexto e escolha permanecem individuais |
| Números versus comportamento | Números sustentam compreensão; comportamento não é inferido automaticamente |
| Aplicação versus poupança | Aplicação é observada; intenção de poupar precisa ser declarada ou confirmada |
| Sankey atraente versus precisão | Sankey somente quando cobertura e tratamento sustentarem a visualização |

## 20.5 Glossário controlado

| Termo | Definição neste framework |
|---|---|
| Crédito observado | Movimento de entrada em conta; não equivale automaticamente a renda |
| Entrada externa | Crédito proveniente de fora do conjunto de contas próprias confirmadas; ainda pode ser empréstimo, resgate, estorno ou transferência de terceiro |
| Renda externa identificada | Entrada cuja natureza de renda foi sustentada por regra aprovada, evidência ou declaração apresentada separadamente |
| Débito observado | Movimento de saída em conta; não equivale automaticamente a consumo |
| Consumo | Uso final identificado por natureza da transação; instrumento de pagamento ou categoria ampla não bastam sozinhos |
| Obrigação | Compromisso financeiro observado ou declarado; sua existência não implica atraso ou problema |
| Principal da dívida | Parcela do pagamento que reduz o valor devido; distinta de juros e encargos |
| Encargos | Juros, tarifas, tributos ou custos identificados; não devem ser contados novamente dentro de pagamento já não decomposto |
| Caixa observado | Créditos e débitos efetivados no período segundo a data disponível e validada |
| Diferença do fluxo tratado | Renda identificada menos usos elegíveis no período, com itens inconclusivos separados; não é lucro, saldo de conta, patrimônio ou nota de saúde |
| Posição | Snapshot de saldo por conta, tipo, moeda e data; não equivale a patrimônio total |
| Cobertura | Fontes, contas conhecidas, períodos, atualização e componentes efetivamente representados |
| Conciliação | Ligação sustentada entre eventos ou pontas, com evidência, regra e estado auditáveis |
| Transferência própria confirmada | Duas pontas com evidência suficiente de mesma titularidade e correspondência |
| Transferência provável | Ligação com indícios, mas sem prova suficiente para neutralização automática |
| Transferência externa confirmada | Transferência com evidência de titularidade de terceiro |
| Movimento inconclusivo | Valor cujo papel financeiro não pode ser estabelecido responsavelmente |
| Recorrência provável | Repetição histórica detectada por regra; não comprova contrato nem evento futuro |
| Confirmado | Qualificador reservado a evidência ou conciliação com critério aprovado; reconhecimento do cliente é registrado como declaração separada |

---

# 21. Fora do produto

Ficam explicitamente fora deste produto:

- nota, pontuação, faixa ou semáforo de saúde financeira;
- perfil endividado, equilibrado, investidor ou comportamental;
- diagnóstico psicológico ou clínico;
- inferência de emoção, ansiedade, compulsão, disciplina ou intenção;
- conclusão causal;
- classificação automática de essencial ou supérfluo;
- objetivo sugerido pelas transações;
- plano produzido sem o cliente;
- percentual universal de poupança;
- fórmula de independência financeira não validada;
- rastreamento de cada real;
- conciliação inventada;
- patrimônio líquido completo;
- dívida total sem fontes suficientes;
- comparação social;
- gamificação baseada em culpa, sequência ou punição;
- produto financeiro, recomendação, oferta ou contratação;
- lead, propensão, oportunidade ou métrica comercial;
- reutilização do resultado do Radar;
- uso externo da marca ou de materiais DSOP sem validação;
- implementação física de tela, API, banco ou cálculo nesta etapa documental.

Produto financeiro, oferta, recomendação, lead e métrica comercial são exclusões estruturais, não itens adiados. Incluí-los exigiria outro produto, outra finalidade, novo consentimento e nova governança — não uma simples ampliação deste escopo.

---

# 22. Dependências ainda pendentes

Estas não são dúvidas sobre a direção do produto. São comprovações necessárias antes da implementação:

1. Definição negocial de cada papel econômico.
2. Perfilamento das tabelas e campos centrais.
3. Fonte de autorização gerente–cliente.
4. Dimensão de nome de instituição e marca.
5. Critérios de leitura disponível, parcial ou insuficiente.
6. Regra validada de cartão e fatura.
7. Critério de transferência própria confirmada.
8. Período padrão e comparação temporal após pesquisa.
9. Uso real das tabelas de renda e orçamento.
10. Modelo de persistência das novas entidades.
11. Política de acesso, retenção e contestação.
12. Formação e supervisão dos gerentes.
13. Validação formal da adaptação e terminologia DSOP.
14. Protocolo de encaminhamento para situações fora da competência do gerente.
15. Metas definitivas do piloto após linha de base.

---

# 23. Checklist de cobertura documental da idealização

Neste checklist, `[x]` significa **tema definido ou protegido no documento**. Não significa dado perfilado, regra homologada, experiência validada nem componente implementado. O estado real de cada entrega deverá evoluir separadamente entre `DEFINIDO`, `A_VALIDAR`, `VALIDADO` e `IMPLEMENTADO`.

## Conceito

- [x] Raio-X e conversa educativa possuem papéis distintos e encadeados.
- [x] O gerente é o usuário principal.
- [x] O cliente participa da interpretação e das escolhas.
- [x] Não há produto comercial.
- [x] O Sankey está subordinado à verdade dos dados.
- [x] O Radar permanece independente.

## Informação

- [x] Observado, declarado, estimado, planejado e hipótese estão separados.
- [x] Modo bruto, normalizado, calculado e inferido está explícito.
- [x] Caixa, diferença do fluxo tratado, compromissos e posição estão separados.
- [x] Cartão, transferência, aplicação, resgate e saque possuem proteções.
- [x] Ausência não é zero.
- [x] Todo número deve ser rastreável.

## Experiência

- [x] Cobertura aparece antes dos indicadores.
- [x] A primeira linha usa um conjunto compacto cuja quantidade será validada.
- [x] Sankey permanece hipótese principal, com gates, alternativa e condições de não exibição.
- [x] Gerente possui modo de preparação e modo conversa.
- [x] Cliente pode corrigir, não responder ou encerrar.
- [x] Linguagem julgadora está proibida.

## Educação financeira

- [x] A realidade é validada antes dos objetivos.
- [x] Objetivos não são inferidos.
- [x] Essencial e ajustável pertencem ao contexto do cliente.
- [x] Simulações exibem premissas.
- [x] Compromissos são voluntários e revisáveis.
- [x] Não cumprir um plano não gera punição.

## Dados e governança

- [x] Tabelas atuais e entidades novas não foram confundidas.
- [x] Viabilidade permanece condicionada ao perfilamento.
- [x] Regras são versionadas e auditáveis.
- [x] Privacidade, acesso e contestação fazem parte do desenho.
- [x] Erros críticos possuem tolerância zero em teste.
- [x] Métricas comerciais não fazem parte do sucesso.

---

# 24. Definição final do produto

> O produto oferece ao gerente um raio-X multibanco, observacional e explicável da realidade financeira disponível do cliente. O raio-X mostra cobertura, entrada, circulação, saída, evolução, compromissos e incertezas sem produzir nota ou julgamento. Depois de revisar essa realidade com o cliente, o gerente utiliza uma jornada estruturada de educação financeira para compreender objetivos, comparar cenários e registrar o plano que o cliente considera possível, um próximo passo voluntário e, se desejado, sua revisão. Dados sustentam a conversa; contexto dá significado; a escolha permanece com o cliente. A experiência não oferece, recomenda nem mede contratação de produtos financeiros.

---

# Referências locais

- `roteiro_descoberta_negocial_mvp.md`;
- `roteiro_descoberta_negocial_mvp_dsop.md`;
- `gfp_catalago.md`;
- `categorias_transacoes_estruturado.md`;
- `pdfs/Desenvolvimento novo perfil financeiro.pdf`;
- `pdfs/EDUCACAO FINANCEIRA NA ESCOLA-.pdf`;
- `pdfs/EDUCAÇÃO FINANCEIRA UMA CIÊNCIA COMPORTAMENTAL.pdf`;
- `pdfs/IMPORTÂNCIA DA EDUCAÇÃO FINANCEIRA.pdf`;
- `pdfs/NEUROMARKETING.pdf`;
- `pdfs/PLANEJAMENTO FINANCEIRO PESSOAL.pdf`;
- `pdfs/Terapia Financeira 1.pdf`;
- `pdfs/Terapia Financeira 2.pdf`.
