# Handoff mínimo — finalização dos dashboards

## Objetivo

Finalizar o protótipo com um shell único e dois dashboards navegáveis:

```text
[ Raio-X financeiro ]  [ Radar comportamental ]
```

Manter a identidade visual da prévia atual, reduzir a densidade inicial e oferecer explicação, composição e transações sob demanda.

## Fontes obrigatórias

Usar como fonte de verdade, nesta ordem:

1. `v0_radar/documentacao_oficial_ana_edu_fin_cli.md` — contrato, temas, pontuações, perfis e elegibilidade do Resultado do Radar.
2. `v0_mvp_gerente/botao_comparar_referencia.md` — lentes independentes e Comparar com referências.
3. `v0_mvp_gerente/framework_mestre_raio_x_educacao_financeira.md` — limites conceituais do Raio-X e da educação financeira.
4. `v0_mvp_gerente/categorias_transacoes_estruturado.md` — categorias e macroclassificações 0–9.

Não substituir essas definições por interpretações genéricas.

## Decisão de implementação

Construir o **Resultado do Radar** usando o contrato oficial existente. Enquanto não houver integração com a fonte real, usar valores mockados, coerentes com esse contrato e identificados na interface como **Dados simulados para protótipo**.

Os mocks devem ficar isolados da apresentação por um adapter ou provider substituível. A troca futura para dados reais não poderá exigir a reconstrução dos componentes visuais.

Não apresentar valor mockado como resultado real do cliente.

## Estrutura final

### Raio-X financeiro

Uma página contínua com quatro blocos:

1. **Diagnóstico em 30 segundos** — status observado, entradas, saídas, diferença, fluxo interno, valor a identificar, cobertura e principal achado.
2. **Caminho do dinheiro** — Sankey com fluxo, destino, base bruta/ajustada e estado de identificação.
3. **Onde existe concentração** — categoria oficial ou macroclassificação Raio-X 0–9, consolidada ou por instituição.
4. **Fechamento do Raio-X** — fato principal, concentração, limitações, pendências e próximas investigações.

Remover a jornada obrigatória de sete etapas, a alternância guiado/explorador e abas que dupliquem conteúdo.

### Radar comportamental

O segundo dashboard terá duas áreas internas:

```text
[ Resultado do Radar ]  [ Explorar lentes ]
```

#### Resultado do Radar

Reproduzir o contrato de `ANA_EDU_FIN_CLI`, incluindo quando disponível no mock:

- participação e motivo de indisponibilidade (`FL_PARTICIPA_RADAR`);
- perfil de renda, macroperfil, microperfil e perfil financeiro;
- resultado orçamentário oficial do Radar;
- cinco temas: Categorização de Gastos, Gestão de Orçamento, Consumo Planejado, Formação de Reserva e Uso Consciente do Crédito;
- pontuação final e composição de cada tema;
- percentuais observados e referências oficiais do contrato;
- período, moeda, cobertura e limitações.

Não inventar um tema prioritário nem regra de desempate: a documentação oficial declara essa decisão como futura.

#### Explorar lentes

Seguir `botao_comparar_referencia.md`:

- catálogo por família;
- estados disponível, disponível com ressalvas, indisponível por dados e futuro;
- abertura voluntária pelo gerente;
- separação entre **Realizado**, **Referência** e **Plano do cliente**;
- origem, versão, período, denominador, cobertura e limitações;
- composição auditável e acesso às movimentações;
- perguntas neutras para a conversa;
- interpretações proibidas visíveis quando necessárias.

O botão **Comparar com referências** do Raio-X abre diretamente `Radar > Explorar lentes`, preservando cliente, snapshot, período, moeda e instituições.

## Regras que não podem ser violadas

- Resultado do Radar e lentes são independentes; não somar, converter ou completar resultados entre eles.
- Não produzir nota global, ranking, semáforo de saúde, recomendação de produto ou conclusão comercial.
- Não tratar qualidade do dado como comportamento do cliente.
- Não esconder valores inconclusivos nem renormalizar somente a parcela conhecida.
- Classificação 0–9 é macroclassificação do Raio-X, não categoria oficial nem lente do Radar.
- O Raio-X pode usar seu limiar parametrizado de equilíbrio; o Resultado do Radar preserva a regra oficial própria. Não unificar silenciosamente os dois cálculos.
- Toda ausência deve diferenciar zero, não calculável, indisponível e dado não fornecido.

## Interação comum

- Filtros globais compartilhados; estado visual independente por dashboard.
- Controle segmentado altera somente a visão correspondente.
- Clique em gráfico cria seleção contextual.
- Expandir mostra explicação e composição.
- Maximizar mostra até cinco registros relacionados.
- **Ver todas** abre painel lateral com tabela completa.
- Apenas um card maximizado por vez; ao fechar, restaurar filtros, seleção, rolagem e lente anterior.

## Critérios de conclusão

A entrega está concluída quando:

- os dois dashboards e as duas áreas do Radar são navegáveis sem recarregar a aplicação;
- todos os controles visíveis têm comportamento funcional;
- filtros atualizam cards, gráficos e tabelas coerentemente;
- qualquer valor detalhável leva às evidências ou ao mock que o compõe;
- mocks do Radar estão identificados e isolados para substituição;
- estados indisponíveis explicam o gate não atendido;
- não existe mistura silenciosa entre Raio-X, Resultado do Radar e lentes;
- a interface é responsiva, acessível por teclado e não apresenta erros no console;
- a implementação é validada com os testes e comandos já adotados pelo projeto.

Se surgir uma lacuna não coberta pelas fontes acima, exibir o recurso como indisponível ou hipótese de protótipo. Não criar regra financeira nova para preencher a lacuna.
