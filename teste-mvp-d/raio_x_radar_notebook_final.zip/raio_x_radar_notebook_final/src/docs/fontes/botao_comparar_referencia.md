# Botão “Comparar com referências” — framework de lentes independentes

## Status do documento

| Campo | Valor |
|---|---|
| Versão | `0.1 — idealização conceitual` |
| Data de referência | `2026-08-04` |
| Estado | Apêndice futuro; não homologado nem implementado |
| Usuário principal | Gerente de relacionamento |
| Finalidade | Apoiar conversas de educação financeira a partir de comparações delimitadas, explicáveis e opcionais |
| Relação com o MVP | Extensão candidata do raio-X; não integra automaticamente o núcleo inicial |

Este documento detalha uma extensão futura do [framework mestre do raio-X e educação financeira](./framework_mestre_raio_x_educacao_financeira.md). Ele não altera o roteiro original, o roteiro inspirado na DSOP, os catálogos, o Radar nem qualquer cálculo existente.

O nome físico solicitado para o arquivo permanece `botao_comparar_referencia.md`. Na experiência, a ação deverá ser apresentada no plural: **Comparar com referências**. Uma comparação nunca será única, obrigatória ou universal.

Este é um documento de idealização. Não cria tela, API, tabela, fórmula produtiva, regra de crédito ou classificação financeira.

---

# 1. Decisão central

## 1.1 O que será criado futuramente

Uma arquitetura extensível de **lentes independentes** que permita ao gerente observar a mesma realidade financeira sob perguntas diferentes.

Cada lente deverá:

- responder uma pergunta delimitada;
- explicar o que mede e o que não mede;
- utilizar um universo e um período explícitos;
- identificar a origem e a versão da referência;
- informar os dados necessários e sua cobertura;
- manter fatos, cálculos, declarações, planos e hipóteses separados;
- terminar em uma pergunta útil para a conversa;
- permanecer independente das demais;
- nunca produzir nota global, perfil ou diagnóstico do cliente.

## 1.2 Por que o conceito faz sentido

O raio-X responde **o que foi observado**. Uma lente acrescenta uma forma específica de explorar aquilo que foi observado, sem modificar o raio-X e sem transformar uma referência em verdade sobre o cliente.

Isso permite incorporar diferentes contribuições de educação financeira ao longo do tempo sem criar uma fórmula única de “saúde financeira”. O gerente poderá escolher a lente adequada ao assunto que o cliente deseja discutir.

Exemplos iniciais:

| Lente | Pergunta delimitada |
|---|---|
| Clareza dos gastos | Quanto das saídas observadas possui finalidade suficientemente identificada? |
| Distribuição 50/30/20 | Como a distribuição observada se compara a uma referência educativa opcional e ao plano do cliente? |
| Pagamentos e compromissos de crédito | Quanto da renda de referência foi destinado a pagamentos observados e o que os dados permitem afirmar sobre obrigações devidas? |
| Realizado versus plano | Como o período observado se compara à distribuição escolhida pelo cliente? |
| Progresso do objetivo | Como a realização confirmada se compara ao compromisso escolhido pelo cliente? |

## 1.3 A distinção que protege o framework

Nem toda lente mede uma “prática financeira do cliente”. Existem objetos diferentes:

| Família | O que representa | Exemplos |
|---|---|---|
| **Qualidade e prontidão da leitura** | Se os dados permitem interpretar uma dimensão com responsabilidade | Clareza dos gastos, atualização, cobertura de contas, conciliação |
| **Referência educativa** | Uma orientação externa ou interna usada voluntariamente para reflexão | 50/30/20; referência contextual de crédito |
| **Referência pessoal** | Uma escolha formulada pelo próprio cliente | Plano escolhido; compromisso por objetivo |
| **Lente observacional** | Uma descrição calculada sem referência prescritiva | Composição das saídas relacionadas a crédito |
| **Lente da jornada** | Estado de uma conversa, escolha ou revisão | Realidade reconhecida; objetivo em construção; plano; progresso |

A lente de categorização mede principalmente a **legibilidade do dado e a capacidade do sistema de interpretar as saídas**. Ela só poderá representar uma prática do cliente se existir uma ação de revisão ou categorização realizada por ele e registrada com autoria auditável.

As futuras lentes inspiradas na DSOP acompanharão escolhas e estados da jornada. Elas não deverão ser reduzidas a percentuais, pontos ou cumprimento de uma referência universal.

## 1.4 Limites estruturais

As lentes não serão usadas para:

- recomendar, ofertar ou contratar produto financeiro;
- gerar lead, propensão, oportunidade ou prioridade comercial;
- aprovar, reprovar ou conceder crédito;
- comparar clientes entre si;
- produzir nota, perfil, ranking ou semáforo de saúde financeira;
- inferir objetivo, intenção, disciplina, culpa ou comportamento;
- declarar que o cliente gasta demais;
- substituir a conversa e a escolha do cliente;
- reutilizar pontuações ou perfis do Radar.

Não haverá produtos envolvidos nesta experiência. Seu valor será a compreensão do gerente e a qualidade da conversa de educação financeira com o cliente.

---

# 2. Posição na experiência

## 2.1 Sequência candidata

```text
Autorização, escopo e cobertura
              ↓
Raio-X observacional
Fatos, fluxos, evolução, Sankey quando apto e limitações
              ↓
Gerente e cliente escolhem um assunto
              ↓
COMPARAR COM REFERÊNCIAS
Catálogo de lentes disponíveis para aquele snapshot
              ↓
Realizado | Referência | Plano do cliente
              ↓
Pergunta educativa e contextualização
              ↓
Registro opcional da conversa e próxima revisão
```

O comparador aparecerá **depois** da apresentação da cobertura e da realidade observada. Ele não substituirá o Sankey, os gráficos de fluxo, a evolução, a comparação entre bancos ou o detalhamento das movimentações.

Cobertura, atualização, conciliação e limitações essenciais continuarão visíveis no núcleo do raio-X mesmo que ninguém abra o comparador. Uma lente de qualidade aprofunda esses elementos; ela não os esconde atrás de uma ação opcional.

## 2.2 Ação explícita do gerente

Nenhuma referência educativa será exibida como diagnóstico padrão. O gerente deverá escolher **Comparar com referências** e selecionar uma lente disponível.

A ativação deverá registrar:

- lente e versão;
- snapshot e período;
- data e usuário;
- estado de disponibilidade;
- se a lente foi apenas aberta, apresentada ou contextualizada com o cliente;
- limitações exibidas naquele momento.

Abrir uma lente não altera os números do raio-X, os resultados de outra lente nem o plano do cliente.

## 2.3 Evolução do nome da entrada

Na primeira extensão, **Comparar com referências** descreve bem 50/30/20, crédito e categorização. Quando forem incorporadas lentes de jornada, nem todas envolverão comparação numérica. Nesse estágio, a entrada principal poderá evoluir para **Explorar lentes**, com três grupos:

1. **Qualidade da leitura**;
2. **Comparações educativas**;
3. **Minha jornada**.

“Comparar com referências” permanecerá como ação dentro do segundo grupo. Essa evolução evita forçar objetivos, escolhas e progresso a se comportarem como benchmarks externos.

## 2.4 Catálogo visível

Cada cartão de lente deverá mostrar antes da abertura:

- nome simples;
- pergunta que responde;
- família;
- tipo da referência;
- estado de disponibilidade naquele cliente e período;
- principal limitação, quando houver;
- origem resumida da referência.

Estados de aplicação permitidos:

| Estado | Significado |
|---|---|
| `NAO_AVALIADA` | Os gates ainda não foram executados |
| `INDISPONIVEL_POR_DADOS` | Os dados não sustentam a lente |
| `DISPONIVEL_COM_RESSALVAS` | A lente pode mostrar fatos e comparação limitada |
| `DISPONIVEL` | Os gates específicos foram atendidos |
| `SELECIONADA` | O gerente escolheu abrir a lente |
| `APRESENTADA` | A lente e suas limitações foram mostradas ao cliente |
| `CONTEXTUALIZADA` | O cliente comentou, reconheceu ou corrigiu o contexto |
| `CONTESTADA` | Há divergência material preservada |
| `EXPIRADA` | O snapshot, a referência ou a regra deixou de ser atual |

Não usar `APROVADO`, `REPROVADO`, `SAUDAVEL`, `INADEQUADO`, `BOM` ou `RUIM`.

---

# 3. Anatomia obrigatória de uma lente

## 3.1 O que deve aparecer

Uma lente aberta terá uma estrutura comum:

1. **Pergunta:** o assunto que está sendo explorado.
2. **Realizado ou estado observado:** resultado calculado no snapshot, sem julgamento.
3. **Referência:** parâmetro utilizado, sua natureza, origem, data e escopo.
4. **Plano do cliente:** quando existir e for pertinente.
5. **Cobertura e limitações:** o que entrou, o que ficou fora e o que permanece inconclusivo.
6. **Como calculamos:** período, numerador, denominador, inclusões, exclusões e tratamentos.
7. **Composição auditável:** acesso às movimentações ou registros que sustentam o resultado.
8. **Perguntas para a conversa:** formulações neutras vinculadas às evidências.
9. **O que não concluir:** interpretações expressamente proibidas.

## 3.2 Tríade de comparação

Quando aplicável, a visualização deverá separar:

| Camada | Significado | Proveniência típica |
|---|---|---|
| **Realizado** | O que foi observado e tratado no período | `OBSERVADO` + cálculo versionado |
| **Referência educativa ou operacional** | Um parâmetro usado para comparação, não um diagnóstico | `EXTERNA_EDUCATIVA` ou `INTERNA_OPERACIONAL` |
| **Plano do cliente** | A distribuição ou o compromisso que o cliente considera possível | `DECLARADO` e `PLANEJADO` |

O acompanhamento posterior deverá privilegiar **realizado versus plano do cliente**. A referência educativa poderá permanecer disponível como contexto, mas não substituirá a escolha pessoal.

## 3.3 Tipos de referência

| Código conceitual | Uso |
|---|---|
| `EXTERNA_EDUCATIVA` | Heurística publicada por fonte externa, com escopo e ressalvas |
| `INTERNA_OPERACIONAL` | Parâmetro de qualidade ou prontidão definido internamente e sujeito a calibração |
| `PESSOAL_DECLARADA` | Meta, plano ou compromisso escolhido pelo cliente |
| `METODOLOGICA` | Estrutura de etapas ou perguntas, sem benchmark numérico necessário |
| `SEM_REFERENCIA` | Lente puramente observacional |

## 3.4 Proveniência

Os seguintes estados nunca serão misturados:

| Proveniência | Significado |
|---|---|
| `OBSERVADO` | Registro obtido de uma fonte transacional ou cadastral identificada |
| `DECLARADO` | Informação expressa pelo cliente e registrada como tal |
| `ESTIMADO` | Valor produzido por premissas explícitas |
| `PLANEJADO` | Escolha para um período futuro |
| `HIPOTESE` | Interpretação a confirmar; não é fato nem declaração |

Uma comparação calculada não transforma declaração em fato observado. Uma aplicação, saldo ou transferência observada também não comprova intenção, objetivo ou compromisso.

## 3.5 Gates gerais

Uma lente só poderá ser apresentada quando todos os gates necessários à sua própria pergunta forem atendidos:

```text
Autorização e finalidade de uso
            ↓
Snapshot, período, moeda e fontes identificados
            ↓
Cobertura e atualização suficientes para a lente
            ↓
Tratamento semântico específico
Cartão, transferências, estornos, duplicidades e patrimônio
            ↓
Numerador e denominador válidos
            ↓
Referência ativa, versionada e aplicável
            ↓
Apresentação das limitações
```

Não existirá um único percentual global capaz de liberar todas as lentes. A categorização pode ser suficiente para discutir distribuição e insuficiente para discutir crédito; uma dívida pode estar bem identificada mesmo quando outras categorias estão incompletas. Cada lente terá gates próprios.

Quando um gate falhar:

- não estimar silenciosamente;
- não converter ausência em zero;
- não renormalizar apenas a parcela conhecida para aparentar totalidade;
- informar por que a lente não está disponível;
- continuar mostrando os fatos que permanecem sustentados;
- permitir a conversa e a declaração do cliente sem transformar declaração em observação.

---

# 4. Governança do catálogo de lentes

## 4.1 Contrato lógico candidato

Cada `DefinicaoLente` deverá conter, no mínimo:

| Campo lógico | Finalidade |
|---|---|
| `id_lente` | Identificador estável |
| `versao` | Versão imutável da definição |
| `nome_experiencia` | Nome exibido ao gerente e ao cliente |
| `pergunta_educativa` | Pergunta única que delimita a interpretação |
| `familia` | Qualidade, observacional, referência educativa, referência pessoal ou jornada |
| `pilar_relacionado` | Minha realidade, Meus objetivos, Meu plano ou Meu progresso, quando aplicável |
| `tipo_referencia` | Externa, interna, pessoal, metodológica ou ausente |
| `fonte_referencia` | Documento, área responsável, URL ou decisão formal |
| `validade_referencia` | Data de início, revisão e eventual encerramento |
| `populacao_aplicavel` | Público e exceções |
| `periodo` | Janela e regra temporal |
| `unidade` | Valor, percentual, faixa ou estado |
| `numerador` e `denominador` | Definições financeiras completas, quando houver razão |
| `inclusoes` e `exclusoes` | Universo de cálculo |
| `regras_antiduplicidade` | Compra, fatura, transferência, estorno e demais tratamentos |
| `dados_necessarios` | Fontes e campos candidatos |
| `gates` | Condições de cálculo e apresentação |
| `estados_aplicacao` | Resultados possíveis sem julgamento |
| `perguntas_sugeridas` | Apoio ao gerente |
| `interpretacoes_proibidas` | Conclusões que a lente não sustenta |
| `drill_down` | Evidências acessíveis |
| `responsavel` | Dono negocial/metodológico |
| `historico_validacao` | Evidências, testes, aprovações e revisões |

Cada aplicação produzirá uma `MedicaoLente` ligada a:

- cliente e snapshot;
- versão da lente;
- período e moeda;
- escopo de contas, instituições e cartões;
- valores observado, de referência e planejado, cada um com proveniência;
- cobertura específica;
- limitações;
- estado de aplicação;
- data de cálculo e validade;
- evidências de composição;
- contexto ou contestação, quando declarado.

Esses são contratos lógicos de idealização, não uma proposta de banco ou API.

## 4.2 Estado de homologação da lente

O estado do item no catálogo não será confundido com o resultado de um cliente:

```text
PROPOSTA
→ EM_VALIDACAO_METODOLOGICA
→ EM_VALIDACAO_DE_DADOS
→ HOMOLOGADA_PARA_PILOTO
→ ATIVA
→ SUSPENSA ou ARQUIVADA
```

Uma lente `PROPOSTA` não poderá aparecer como funcionalidade ativa. Mudanças de fórmula, taxonomia, fonte ou referência exigirão nova versão; resultados históricos manterão a versão original.

## 4.3 Princípio de independência

- Uma mesma movimentação pode cumprir papéis distintos em lentes diferentes, desde que isso seja explicado.
- Uma prestação imobiliária pode ser moradia na distribuição de finalidade e serviço da dívida na lente de crédito.
- Os valores de lentes diferentes não serão somados entre si.
- Dentro de uma mesma lente, cada evento terá um único papel econômico para impedir dupla contagem.
- O resultado de uma lente não será usado para completar silenciosamente outra.
- Uma lente de qualidade poderá limitar outra lente, mas não produzirá conclusão financeira sobre o cliente.

---

# 5. Lente 1 — Clareza dos gastos

## 5.1 Nome e propósito

Nome recomendado na experiência: **Clareza dos gastos**.

Nome de descoberta solicitado: **Gastos pouco categorizados**.

Pergunta:

> Quanto das saídas econômicas elegíveis observadas possui uma finalidade suficientemente identificada para sustentar esta leitura?

O nome positivo evita atribuir ao cliente uma falha que pode vir da fonte, da taxonomia, da sincronização ou do motor de categorização. “Gastos pouco categorizados” poderá aparecer como descrição do estado, nunca como rótulo comportamental da pessoa.

## 5.2 O que a lente mede

A lente mede a **cobertura de finalidade econômica** no universo relevante para a análise:

```text
clareza_dos_gastos
=
valor das saídas econômicas elegíveis com finalidade suficientemente conhecida
÷
valor total das saídas econômicas elegíveis observadas
```

Visão complementar:

```text
parcela_com_finalidade_pouco_conhecida
=
valor das saídas elegíveis sem finalidade suficientemente conhecida
÷
valor total das saídas econômicas elegíveis observadas
```

Se os conjuntos forem exaustivos e mutuamente exclusivos:

```text
clareza_dos_gastos + parcela_com_finalidade_pouco_conhecida = 100%
```

O indicador principal será calculado por **valor**. Quantidade de movimentações e valor absoluto deverão aparecer como apoio, pois muitas transações pequenas e uma única transação material produzem riscos diferentes.

## 5.3 A referência interna de 75%

**HIPÓTESE:** utilizar `clareza_dos_gastos ≥ 75%` como referência operacional interna candidata para aptidão inicial de comparações dependentes da finalidade.

Isso equivale, quando os conjuntos fecharem corretamente, a no máximo 25% das saídas elegíveis sem finalidade útil.

O significado da referência será:

> Parâmetro operacional interno de cobertura mínima para interpretar a distribuição dos gastos com ressalvas; não representa saúde financeira, organização, disciplina ou comportamento do cliente.

O 75% precisa ter proprietário, versão, data, justificativa e plano de calibração. Não há, nos documentos analisados, fundamento para tratá-lo como princípio universal de educação financeira.

## 5.4 Diferença explícita para o Radar legado

A documentação do Radar define:

```text
PC_SAI_GEN = VL_SAI_GEN ÷ VL_SAI_TOTAL
PC_REF_GEN = 75%
sinal legado quando PC_SAI_GEN > 75%
```

Portanto, o Radar usa 75% como teto para a parcela **genérica ou não classificada**. Na prática, a regra só dispara quando mais de 75% das saídas estão no bloco genérico. A parcela que não está nesse bloco seria de 25% no limite aritmético, mas isso **não comprova 25% de finalidade conhecida**: o bloco legado e a nova taxonomia de finalidade ainda não foram demonstrados como complementos semânticos exatos.

A nova proposta inverte o sentido conceitual:

| Modelo | Numerador | Condição de referência | Significado |
|---|---|---|---|
| Radar legado | Saídas do bloco genérico/não classificado do Radar | `parcela genérica ≤ 75%` não dispara o sinal | Regra de pontuação do Radar; não equivale à nova cobertura |
| Nova lente | Saídas elegíveis com finalidade conhecida | `clareza ≥ 75%` | Hipótese de cobertura mínima da leitura |

Essa mudança **não é reaproveitamento da fórmula antiga**. É uma nova definição, para outro produto e outra finalidade. Ela deverá ser validada e calibrada antes de qualquer implementação. A pontuação `99` do Radar não será transportada.

Quando não houver saídas elegíveis ou o universo não puder ser construído, o resultado será `NAO_CALCULAVEL`, nunca 0%, 100% ou uma pontuação neutra.

## 5.5 Universo de cálculo candidato

Antes do cálculo, as movimentações precisam ser tratadas para representar saídas econômicas sem duplicidade.

Possíveis classes:

| Classe | Papel na lente |
|---|---|
| `FINALIDADE_CONHECIDA` | Entra no numerador e denominador |
| `CATEGORIA_AMPLA` | Entra no denominador; tratamento no numerador depende de regra de utilidade validada |
| `SEM_CATEGORIA` | Entra no denominador, fora do numerador |
| `MEIO_SEM_FINALIDADE` | Saque, boleto, cheque ou transferência inconclusiva; entra no denominador quando representar saída econômica ainda não explicada |
| `PENDENCIA_TECNICA` | Permanece visível e poderá tornar o cálculo inconclusivo |
| `FORA_DO_ESCOPO` | Não entra na razão, mas aparece na reconciliação |

Excluir do universo somente quando houver evidência suficiente:

- transferências próprias confirmadas;
- aplicações e movimentos patrimoniais tratados separadamente;
- estornos, cancelamentos e duplicatas conciliados;
- pagamento de fatura quando as compras já representam o consumo naquela lente;
- eventos técnicos que não constituem uso final.

Não excluir silenciosamente transferências prováveis, saques ou pagamentos sem finalidade. A ausência de finalidade é justamente informação relevante para a cobertura.

“Sem categoria”, “Gastos diversos”, uma categoria ampla e um erro técnico não são equivalentes. A taxonomia deverá definir, por versão, quais categorias são suficientemente específicas para cada lente.

O mecanismo `F/R/M/C` registrado no catálogo atual informa como o motor categorizou uma movimentação. Ele não será interpretado como probabilidade, confiança, correção da categoria nem prova de ação do cliente.

## 5.6 Estados candidatos

| Estado | Regra conceitual | Apresentação |
|---|---|---|
| `LEITURA_APTA` | Cobertura igual ou superior à referência e demais gates atendidos | Mostrar comparação com cobertura e itens pendentes |
| `LEITURA_PARCIAL` | Cobertura abaixo da referência, mas fatos limitados continuam úteis | Mostrar valores, parcela desconhecida e ressalva; não produzir conclusão de distribuição |
| `LEITURA_INSUFICIENTE` | A falta de finalidade pode alterar materialmente a interpretação | Não comparar distribuição; oferecer revisão dos itens |
| `NAO_CALCULAVEL` | Sem denominador confiável, período inválido ou tratamento técnico incompleto | Explicar o motivo; não exibir percentual |

O limiar que separará `LEITURA_PARCIAL` de `LEITURA_INSUFICIENTE` ainda deverá ser calibrado. A referência de 75% não resolve sozinha todos os gates.

## 5.7 Efeito sobre outras lentes

- Para o 50/30/20, 75% poderá significar no máximo **apta com ressalvas**, não precisão plena.
- A parcela desconhecida aparecerá como quarto bloco; os valores conhecidos não serão renormalizados para 100%.
- Se os gastos desconhecidos puderem mudar materialmente a comparação, a lente 50/30/20 ficará inconclusiva ou mostrará intervalo de sensibilidade.
- Para crédito, a cobertura global de categorias não basta. Renda e obrigações exigem gates próprios.
- Para o Sankey, a saída sem finalidade permanecerá como nó explícito. Se sua materialidade impedir uma representação responsável, usar barras ou tabela.
- Dados incompletos não impedem o cliente de declarar um objetivo; apenas limitam inferências e tornam plano ou compromisso provisórios.

## 5.8 Conversa apoiada

Texto seguro:

> Identificamos a finalidade de X% das saídas elegíveis observadas. Os demais R$ Y ainda estão em categorias amplas, sem categoria ou dependem de contexto. Revisar os itens mais relevantes pode tornar a leitura mais precisa.

Perguntas possíveis:

- Estes itens representam a finalidade que você reconhece?
- Alguma destas saídas foi excepcional?
- Qual movimentação faria mais diferença esclarecer primeiro?
- Há saques, boletos ou transferências cuja finalidade não aparece nos dados?
- Você deseja revisar algum item ou prefere seguir com a limitação registrada?

Conclusões proibidas:

- “O cliente não organiza seus gastos.”
- “O cliente tem um hábito ruim de categorização.”
- “75% comprova uma leitura correta.”
- “A categoria automática representa a intenção do cliente.”
- “Tudo que não está categorizado é consumo.”

---

# 6. Lente 2 — Distribuição 50/30/20

## 6.1 Papel no framework

A regra 50/30/20, frequentemente associada a Elizabeth Warren e Amelia Warren Tyagi, será uma **referência educativa externa, opcional e contextualizada**. O produto não usará essa associação como argumento de autoridade. A regra não será um diagnóstico padrão nem uma meta imposta.

Ela não é fundamentada pelos PDFs estudados para o framework; sua inclusão vem de uma fonte educativa externa que deverá permanecer identificada na experiência.

Pergunta:

> Como a distribuição observada se compara a uma orientação educativa e à distribuição que o cliente considera possível para sua realidade?

A referência é normalmente apresentada como distribuição da renda líquida disponível entre necessidades, desejos e poupança/pagamento de dívidas. A atividade oficial do Consumer Financial Protection Bureau a trata como regra de orçamento e também convida a pessoa a formular sua própria regra. Isso sustenta seu uso como ponto de partida para reflexão, não como padrão universal.

## 6.2 Ativação

O sistema poderá calcular uma prévia quando os gates forem atendidos, mas não deverá exibi-la automaticamente. A comparação aparecerá apenas quando o gerente escolher:

> **Comparar com referências → Distribuição 50/30/20**

Ao abrir, a tela mostrará:

1. **Realizado:** distribuição observada no período;
2. **Referência educativa:** 50/30/20, identificada como orientação externa;
3. **Plano do cliente:** distribuição que o cliente reconhece como possível, se já declarada.

## 6.3 Denominador e reconciliação

Para afirmar comparação com 50/30/20, o denominador candidato será a **renda líquida de referência alocável**, e não o total de saídas.

```text
percentual_essenciais = usos essenciais elegíveis ÷ renda de referência alocável
percentual_flexiveis  = usos flexíveis elegíveis ÷ renda de referência alocável
percentual_futuro     = poupança, objetivos e pagamentos de dívida alocados exclusivamente a este bloco ÷ renda de referência alocável
```

O modelo externo reúne poupança e pagamentos de dívida no bloco de 20%. Para adaptá-lo a dados transacionais sem dupla contagem, a regra versionada deverá distinguir:

- consumo realizado por cartão, classificado uma única vez entre essencial e flexível;
- pagamento da fatura, neutralizado quando as compras já representam o consumo;
- pagamento contratual ou mínimo de obrigação, cujo papel orçamentário precisará ser validado e explicitado;
- amortização adicional escolhida, candidata ao bloco de futuro;
- juros e encargos, sempre visíveis e sem duplicidade;
- qualquer pagamento de dívida alocado ao bloco de 20%, que ficará excluído dos demais blocos dentro desta lente.

Uma regra candidata poderá colocar o pagamento mínimo ou contratual entre compromissos do ciclo e apenas a amortização adicional no bloco de futuro. Como diferentes formulações educativas tratam essa divisão de modos distintos, essa adaptação ainda exigirá validação metodológica. A decisão invariável é: **cada valor aparece uma única vez dentro da lente 50/30/20**.

A reconciliação deverá separar grandezas que não podem ser somadas sob um único rótulo:

```text
usos_classificados
= essenciais + flexíveis + futuro

residuo_orcamentario
= renda de referência alocável
   − usos classificados
   − saídas elegíveis sem finalidade conhecida

margem = máximo(residuo_orcamentario, 0)
deficit = máximo(−residuo_orcamentario, 0)
```

- **Saídas sem finalidade** são usos positivos observados que ainda não puderam ser alocados.
- **Margem** é o resíduo não negativo depois dos usos elegíveis.
- **Déficit** é o excesso dos usos sobre a renda de referência; não é uma categoria de gasto adicional.
- **Movimentos fora do orçamento** aparecem em reconciliação separada e não integram essa equação.
- **Divergências de renda** permanecem como limitação até serem reconciliadas.

Se o produto usar apenas a composição das saídas como denominador, o nome correto será **composição das saídas**, sem alegar equivalência direta à regra 50/30/20.

## 6.4 Classificação dependente do cliente

Essencial e flexível não serão propriedades universais de uma categoria. Moradia, transporte, saúde e apoio familiar podem ter composições e contextos diferentes.

O sistema poderá apresentar uma hipótese baseada em taxonomia, mas deverá permitir:

- reconhecer a classificação;
- corrigir ou contextualizar;
- manter o observado e a declaração separados;
- marcar valores inconclusivos;
- preservar a versão usada no cálculo.

Aplicação financeira não comprova automaticamente reserva. Um pagamento de dívida só integrará a faixa de “futuro” quando a regra validada o alocar exclusivamente ali; parcela contratual, amortização adicional, juros e liquidação de fatura permanecerão distinguíveis. A lente de crédito continuará mostrando a dimensão transversal sem somá-la novamente ao orçamento.

## 6.5 Gates específicos

- renda de referência suficientemente identificada e coerente com o período;
- tratamento de empréstimos recebidos, resgates, estornos e transferências;
- saídas econômicas sem dupla contagem;
- cartão tratado conforme a disponibilidade de compras e fatura;
- categorias mapeadas para o modelo com regra versionada;
- cobertura de finalidade explicitada;
- valores desconhecidos mantidos fora dos blocos conhecidos, sem renormalização;
- meses parciais e renda irregular identificados;
- referência, fonte e ressalvas vigentes.

Uma cobertura categorizada de 75% não garante que a comparação seja conclusiva. O peso e a possível alocação dos 25% restantes precisam ser considerados.

## 6.6 Forma de apresentação

Não usar medidores de aprovação. Mostrar barras ou tabela comparável:

| Dimensão | Realizado observado | Referência educativa | Plano do cliente | Cobertura/ressalva |
|---|---:|---:|---:|---|
| Necessidades/essenciais | X% | 50% | P% | Classificação parcialmente confirmada |
| Desejos/flexíveis | Y% | 30% | Q% | Parte das categorias é ampla |
| Poupança e pagamentos de dívida elegíveis | Z% | 20% | R% | Cada valor tem papel exclusivo nesta lente |
| Saídas elegíveis sem finalidade | W% | — | — | Uso observado; não redistribuído |
| Margem | M% | — | S% | Resíduo não negativo |
| Déficit | D% | — | — | Excesso sobre a renda; exibido separadamente |
| Movimentos fora do orçamento | R$ V | — | — | Reconciliação paralela, fora dos percentuais |

Perguntas possíveis:

- Esta divisão representa sua realidade?
- O que você considera essencial neste período?
- Alguma despesa foi temporária ou excepcional?
- Esta referência ajuda a pensar seu plano ou prefere outra distribuição?
- Qual distribuição parece possível sem comprometer suas necessidades?
- Como o plano deveria funcionar em um mês de renda menor?

## 6.7 O que não concluir

- Estar próximo de 50/30/20 não significa boa saúde financeira.
- Estar distante não significa desorganização.
- O modelo não considera sozinho composição familiar, custo de vida, renda irregular, território, eventos temporários, dívidas, patrimônio ou objetivos.
- O sistema não deverá classificar automaticamente uma despesa como necessária ou supérflua.
- A diferença para a referência não deverá ser transformada em recomendação automática.
- O acompanhamento não deverá cobrar que o cliente “atinja” 50/30/20; deverá comparar realizado com seu plano escolhido.

---

# 7. Lente 3 — Pagamentos observados e compromissos de crédito

## 7.1 Pergunta correta

> Quanto da renda de referência do período foi destinado a pagamentos de crédito efetivamente observados, quais obrigações devidas estão cobertas pelos dados e quais sinais merecem ser compreendidos?

Essa pergunta é diferente de:

> De tudo o que saiu da conta, quanto foi classificado no bloco de crédito?

As duas medidas podem existir, mas não podem receber o mesmo nome nem a mesma interpretação.

## 7.2 Memória correta do indicador do Radar

O indicador atual será preservado como memória conceitual do Radar:

```text
participacao_das_saidas_relacionadas_a_credito
=
saídas classificadas como dívida, crédito ou custo financeiro
÷
total das saídas do período
```

Ele responde sobre **composição bruta das saídas segundo o bloco legado**. Não mede comprometimento da renda, estoque da dívida, atraso, capacidade de pagamento ou qualidade do uso do crédito. Não deverá ser comparado automaticamente com 30% nem reutilizado diretamente como resultado da nova lente.

Se futuramente houver utilidade para uma composição de saídas relacionadas a crédito, ela deverá ser **recalculada** sobre uma visão escolhida e tratada:

```text
participacao_tratada_dos_pagamentos_de_credito
=
pagamentos de crédito elegíveis na visão escolhida
÷
total elegível da mesma visão e do mesmo período
```

A lente deverá declarar se a visão é de caixa ou econômica e aplicar as regras de cartão, transferências, estornos e duplicidades. O valor produzido pelo Radar não será transportado silenciosamente.

Exemplo:

| Situação | Pagamentos de crédito observados | Outras saídas | Total de saídas | Participação nas saídas | Pagamentos/renda com renda de R$ 5.000 |
|---|---:|---:|---:|---:|---:|
| Mês A | R$ 1.500 | R$ 1.500 | R$ 3.000 | 50% | 30% |
| Mês B | R$ 1.500 | R$ 3.500 | R$ 5.000 | 30% | 30% |
| Mês C | R$ 1.500 | R$ 6.000 | R$ 7.500 | 20% | 30% |

A parcela da renda destinada aos pagamentos observados permaneceu em 30%, enquanto a participação nas saídas caiu de 50% para 20%. A primeira razão muda quando mudam os pagamentos elegíveis ou a renda de referência; a participação nas saídas também pode mudar apenas porque os outros gastos aumentaram ou diminuíram. O exemplo não informa se esses pagamentos correspondem a todas as obrigações devidas.

## 7.3 Cálculos candidatos, com nomes distintos

```text
parcela_da_renda_destinada_a_pagamentos_observados_de_credito
=
pagamentos elegíveis de crédito observados no período
÷
renda recorrente de referência do mesmo período
```

Essa razão mede fluxo efetivamente observado. Ela **não mede, sozinha, comprometimento contratual**, pois uma parcela devida e não paga pode não aparecer, uma antecipação pode elevar o valor do período e uma obrigação mantida fora das fontes observadas pode estar ausente.

Somente quando existir uma fonte adequada de obrigações devidas, com escopo suficiente, poderá ser estudada uma segunda razão:

```text
comprometimento_contratual_candidato
=
obrigações elegíveis de crédito devidas no período
÷
renda de referência compatível
```

Os dois indicadores nunca receberão o mesmo rótulo. Seus numeradores e denominadores ainda dependem de definição e validação.

O numerador deverá separar, quando a fonte permitir:

| Componente | Significado |
|---|---|
| Principal pago | Redução da obrigação |
| Juros | Custo do crédito |
| Tarifas, tributos e multas | Outros custos financeiros |
| Parcela sem decomposição | Pagamento de obrigação cuja composição é desconhecida |
| Pagamento integral da fatura | Liquidação de meio de pagamento; não é automaticamente dívida elegível |
| Pagamento parcial, mínimo, rotativo ou parcelamento | Sinal de financiamento somente quando comprovado |

O denominador deverá declarar:

- se usa renda líquida observada, declarada ou combinação reconciliada;
- período e tratamento de renda irregular;
- cobertura de instituições e fontes de renda;
- exclusão de empréstimos recebidos, resgates, reembolsos e transferências próprias;
- eventos excepcionais;
- divergências não resolvidas.

## 7.4 Crédito como dimensão transversal

Crédito não será um quarto bloco somável a essenciais, flexíveis e futuro. Os três blocos descrevem a **finalidade** do dinheiro; crédito descreve **forma de financiamento, obrigação e custo**.

Uma prestação imobiliária pode aparecer:

- como moradia essencial na lente de distribuição;
- como serviço da dívida na lente de crédito.

Isso é permitido porque são perguntas independentes. O valor nunca será somado duas vezes dentro do mesmo orçamento nem agregado entre lentes.

## 7.5 Tratamento do cartão

| Evidência disponível | Papel seguro |
|---|---|
| Compra detalhada | Representa finalidade de consumo na data e regra escolhidas |
| Pagamento de fatura | Representa liquidação de caixa |
| Compra e fatura observadas | Uma delas deve ser neutralizada no total econômico para evitar dupla contagem |
| Apenas fatura observada | Mostrar “fatura sem detalhamento”; não inventar finalidade |
| Pagamento integral | Não inferir dificuldade ou dívida financiada |
| Pagamento parcial/mínimo | Só identificar se houver campo ou evidência específica |
| Rotativo/parcelamento/encargos | Mostrar separadamente quando comprovado |
| Estado desconhecido | Permanecer inconclusivo |

## 7.6 Entrada de empréstimo

Uma liberação de empréstimo é entrada de caixa e criação de obrigação futura. Ela não é renda recorrente.

O raio-X deverá distinguir:

```text
resultado de caixa
= todas as entradas de caixa − todas as saídas de caixa

diferença financeira recorrente tratada
= renda recorrente identificada − usos econômicos recorrentes elegíveis
```

Empréstimos recebidos, resgates, reembolsos e transferências inconclusivas permanecerão separados na segunda visão. Assim, contratar crédito não melhorará artificialmente a leitura de sustentabilidade recorrente.

## 7.7 Níveis de resposta da lente

| Nível | Condição | Resultado permitido |
|---|---|---|
| 1 — Sinais | Dados parciais, mas eventos de crédito identificados | Mostrar fatos: pagamentos, entrada de empréstimo, juros/encargos, fatura e limitações |
| 2 — Pagamentos/renda calculável | Renda e pagamentos observados atendem aos gates | Mostrar a parcela da renda destinada a pagamentos, composição e cobertura; não chamar de obrigação contratual |
| 3 — Comprometimento contratual calculável | Obrigações devidas e renda compatível atendem a gates próprios | Mostrar a razão contratual separada dos pagamentos observados |
| 4 — Comparação opcional | Nível 3, metodologia compatível e referência ativa; gerente escolheu comparar | Mostrar realizado, referência contextual e plano do cliente |

Quando uma razão não puder ser calculada, a lente não exibirá zero. A saída segura será:

> Foram observados sinais relacionados ao uso de crédito, mas os dados disponíveis não permitem calcular o comprometimento contratual da renda.

## 7.8 Referência externa de 30%

O 30% poderá ser estudado como **referência educativa externa contextual**, nunca como regra universal, diagnóstico ou limite regulatório do produto. Ele não será aplicado diretamente à razão de pagamentos observados enquanto não estiver demonstrado que numerador, denominador, escopo e período são compatíveis com a finalidade da referência.

Os documentos locais analisados não sustentam uma atribuição universal à Senacon. Uma nota técnica da Senacon de 2020 apoiou, durante a tramitação legislativa, uma proposta relacionada a dívidas superiores a 30% da renda líquida mensal, excluído financiamento habitacional. A Lei nº 14.181/2021 aprovada não fixou esse percentual como definição geral de superendividamento; adotou o comprometimento do mínimo existencial. O Banco Central define metodologicamente comprometimento de renda como serviço mensal da dívida sobre renda disponível, sem estabelecer nessa definição um limite universal de 30%. Há usos de aproximadamente 30% em contextos específicos, como financiamento habitacional, que não podem ser generalizados.

Antes de ativar a referência, será obrigatório registrar:

- fonte e link;
- data de consulta;
- finalidade original;
- população e produtos a que se aplica;
- diferença para o cálculo deste produto;
- responsável por sua validação;
- mensagem de que não se trata de diagnóstico ou regra de concessão.

## 7.9 Perguntas e linguagem segura

Perguntas possíveis:

- Estes pagamentos representam compromissos que você reconhece?
- Algum deles foi excepcional ou está perto de terminar?
- A renda observada representa a renda disponível do período?
- O pagamento da fatura foi integral, parcial ou não aparece com esse detalhe?
- Juros e encargos foram esperados?
- Como estes compromissos entram no plano que você considera viável?

Texto seguro quando houver evidência:

> No período, foram observados R$ X em pagamentos de crédito elegíveis, equivalentes a Y% da renda de referência utilizada. Isso descreve os pagamentos encontrados, não todas as obrigações devidas. Uma comparação externa somente será mostrada quando sua metodologia for compatível. A leitura considera as fontes e limitações abaixo.

Conclusões proibidas:

- “O cliente comprometeu mais de 30% da renda” quando o cálculo usar total de saídas.
- “Pagamentos observados equivalem a todas as parcelas devidas.”
- “Abaixo de 30% significa crédito saudável.”
- “Acima de 30% significa irresponsabilidade ou incapacidade.”
- “Pagamento de fatura comprova endividamento.”
- “Existe atraso, rotativo ou inadimplência” sem evidência.
- “A dívida total é X” sem fonte de estoque e escopo completos.
- “O cliente pode assumir mais crédito.”

---

# 8. Dependências entre as três lentes iniciais

```text
Tratamento do snapshot
├── cobertura de contas, período e atualização
├── transferências, patrimônio e estornos
└── cartão e dupla contagem
          ↓
Clareza dos gastos
          ├── qualifica a distribuição 50/30/20
          └── qualifica gráficos por finalidade

Renda de referência + pagamentos observados + obrigações devidas + tratamento do cartão
          ├── habilitam a razão pagamentos/renda
          └── quando o escopo contratual for completo, habilitam comprometimento contratual

Realidade revisada + escolha declarada do cliente
          └── habilitam realizado versus plano
```

A clareza de 75% não será um “selo” geral. A lente de crédito poderá ficar inconclusiva mesmo com 95% das saídas categorizadas, se a renda ou a condição da fatura estiver incompleta. Também poderá mostrar fatos seguros sobre uma obrigação específica mesmo com cobertura global inferior.

Todas as lentes deverão usar o mesmo snapshot, período, moeda e escopo consolidado, salvo diferença explicitamente apresentada. Uma diferença de base nunca ficará apenas em nota de rodapé.

---

# 9. Futuras lentes da jornada educativa

## 9.1 Como a DSOP se encaixa

Faz sentido trazer, no futuro, lentes inspiradas em Diagnosticar, Sonhar, Orçar e Poupar. O encaixe correto não é criar quatro novos escores. É utilizar o raio-X e os registros declarados ou planejados para acompanhar uma jornada cuja autoria continua sendo do cliente.

Na experiência, permanecem preferíveis os nomes genéricos:

| Pilar conceitual | Nome da experiência | Papel da lente |
|---|---|---|
| Diagnosticar | **Minha realidade** | Reconhecimento, ressalva ou contestação da leitura |
| Sonhar | **Meus objetivos** | Estruturação voluntária de objetivo declarado |
| Orçar | **Meu plano** | Comparação entre realizado, cenários e escolha do cliente |
| Poupar | **Meu progresso** | Acompanhamento de compromisso e realização confirmada |

O nome DSOP, a aderência metodológica e o uso da marca permanecem pendentes de validação formal com seus responsáveis. Até essa validação, as lentes serão descritas como jornada de educação financeira inspirada nos quatro movimentos.

## 9.2 Princípios

- O cliente é coautor.
- Objetivos nunca são inferidos das transações.
- Plano não é produzido sem participação do cliente.
- Produto financeiro não integra a experiência.
- Dados observados, declarados, estimados, planejados e hipóteses permanecem distinguíveis.
- O cliente pode não responder, corrigir, contestar, pausar ou encerrar.
- Ausência de objetivo ou compromisso não representa fracasso.
- A jornada não será gamificada por culpa, sequência, medalha ou punição.

## 9.3 Lente futura — Realidade reconhecida

Pergunta:

> A leitura apresentada corresponde ao contexto que o cliente reconhece, e quais ressalvas permanecem?

Referência: snapshot apresentado, limitações explicadas e contexto declarado pelo cliente.

Estados candidatos:

- `AINDA_NAO_APRESENTADA`;
- `RECONHECIDA`;
- `RECONHECIDA_COM_RESSALVAS`;
- `CONTESTADA`;
- `INCONCLUSIVA_RECONHECIDA`;
- `EXPIRADA`.

Perguntas:

- Esta leitura corresponde à sua realidade?
- O que está faltando ou precisa ser corrigido?
- Houve algum evento excepcional?
- Qual tema você gostaria de compreender primeiro?

O gerente não poderá registrar reconhecimento unilateralmente. A manifestação é do cliente; o gerente apenas registra a ocorrência e preserva divergências.

## 9.4 Lente futura — Objetivo em construção

Pergunta:

> O que o cliente deseja realizar, proteger ou mudar, e quais elementos ele deseja definir agora?

Referência: objetivo declarado pelo próprio cliente.

Estados candidatos:

- `CLIENTE_NAO_DESEJA_REGISTRAR`;
- `EM_EXPLORACAO`;
- `DEFINIDO`;
- `ATIVO`;
- `PAUSADO`;
- `REALIZADO`;
- `ENCERRADO`.

Elementos possíveis:

- descrição;
- valor ou faixa;
- prazo ou horizonte;
- prioridade;
- flexibilidade de valor, prazo e contribuição;
- valor já destinado, quando confirmado;
- autoria, data e versão.

Não haverá percentual de “qualidade do sonho”. Uma aplicação ou saldo observado não será ligado a um objetivo sem confirmação.

## 9.5 Lente futura — Realizado versus plano escolhido

Pergunta:

> Como o realizado observado se compara ao plano que o cliente considerou possível, dadas as premissas disponíveis?

Referência principal: plano pessoal declarado e planejado. O 50/30/20 poderá ter servido como inspiração, mas não permanecerá acima da escolha do cliente.

Estados candidatos:

- `SEM_PLANO`;
- `RASCUNHO`;
- `PROVISORIO_POR_DADOS`;
- `ESCOLHIDO_PELO_CLIENTE`;
- `AGUARDANDO_PRIMEIRO_CICLO`;
- `A_REVISAR`.

Apresentação candidata:

```text
Realizado observado
Referência educativa consultada, se escolhida
Plano definido pelo cliente
Premissas e parcela inconclusiva
```

Perguntas:

- O que você considera essencial?
- Que margem deseja preservar?
- Este plano continuaria possível em um mês de renda menor?
- Prefere ajustar valor, prazo ou contribuição?
- Que premissa ainda precisa ser revista?

Se a realidade estiver incompleta, o plano será explicitamente provisório. Não existirá “plano correto” calculado pelo sistema.

## 9.6 Lente futura — Compromisso e progresso

Pergunta:

> Como a realização confirmada se compara ao compromisso voluntário escolhido pelo cliente, e o que ele deseja revisar?

Referência: compromisso pessoal planejado.

Estados candidatos:

- `SEM_COMPROMISSO`;
- `AGUARDANDO_CICLO`;
- `REALIZACAO_CONFIRMADA`;
- `REALIZACAO_PARCIAL`;
- `NAO_CONFIRMADA`;
- `REVISAO_SOLICITADA`;
- `PAUSADO`;
- `ENCERRADO`.

Perguntas:

- O que aconteceu neste ciclo?
- O compromisso ainda faz sentido?
- Deseja ajustar valor, frequência, prazo ou objetivo?
- Qual próximo passo parece possível?

Aplicação, transferência ou aumento de saldo não comprova cumprimento. A execução será vinculada a evidência adequada ou à confirmação declarada, mantendo a proveniência.

## 9.7 Relação das lentes com a jornada

| Lente | Momento relacionado | Tipo de referência |
|---|---|---|
| Clareza dos gastos | Minha realidade | Interna operacional |
| 50/30/20 | Meu plano | Externa educativa |
| Pagamentos e compromissos de crédito | Minha realidade e Meu plano | Observacional; externa contextual somente com método compatível |
| Realidade reconhecida | Minha realidade | Metodológica e declarada |
| Objetivo em construção | Meus objetivos | Pessoal declarada |
| Realizado versus plano | Meu plano | Pessoal declarada |
| Compromisso e progresso | Meu progresso | Pessoal declarada |

---

# 10. Experiência candidata

## 10.1 Organização da entrada

```text
EXPLORAR LENTES                                      [futuro]

Qualidade da leitura
  Clareza dos gastos                    DISPONÍVEL COM RESSALVAS

Comparações educativas
  Distribuição 50/30/20                 DISPONÍVEL
  Pagamentos e compromissos de crédito  DADOS INSUFICIENTES

Minha jornada
  Realidade reconhecida                 FUTURA
  Objetivo em construção                FUTURA
  Realizado versus plano                FUTURA
  Compromisso e progresso               FUTURA
```

No primeiro append, a ação poderá abrir diretamente as comparações disponíveis. A tela mostrará poucas lentes por vez, relacionadas ao tema que o cliente deseja discutir.

## 10.2 Regras visuais

- Não abrir comparação automaticamente.
- Não usar vermelho e verde como aprovação ou reprovação.
- Não depender apenas de cor.
- Mostrar valor absoluto e percentual com denominador.
- Mostrar período, contas, instituições, moeda e atualização.
- Diferenciar zero, ausência, não calculável e inconclusivo.
- Exibir origem, data e tipo da referência.
- Disponibilizar “Como calculamos”.
- Permitir acesso às movimentações que compõem o resultado.
- Mostrar a parcela desconhecida, sem distribuí-la entre categorias conhecidas.
- Explicar quando as bases de duas colunas são diferentes.
- Manter alternativa textual e tabela para acessibilidade.
- Não usar a espessura do Sankey para sugerir uma conexão não comprovada.

## 10.3 Papel do Sankey

O Sankey permanece subordinado a **Minha realidade**. Ele mostra composição e circulação quando os gates do raio-X forem atendidos. Não será usado para representar pontuação, meta, aprovação ou progresso da jornada.

Ao abrir uma lente, o Sankey poderá:

- receber realce dos fluxos relevantes;
- manter “Sem finalidade identificada” como nó explícito;
- permitir drill-down para a composição da lente;
- ser substituído por barras ou tabela quando a comparação exigir eixos mais precisos;
- nunca modificar o tratamento financeiro original.

---

# 11. Dados candidatos e viabilidade

## 11.1 Núcleo observado

| Necessidade | Fonte candidata | Estado |
|---|---|---|
| Movimentações realizadas | `TRAN_RLZD_INST_PCT` | Coração; preenchimento e cardinalidade a validar |
| Contas, instituições, consentimento e atualização | `INF_OPB_CT_CLI` | Essencial para cobertura |
| Contraparte e transferências candidatas | `CMPT_TRAN_RLZD_CC` | Depende de conciliação e titularidade |
| Categorias e grupos | `CTGR_TRAN_OPB`, `GR_CTGR_TRAN` | Taxonomia e semântica a validar |
| Compras e detalhes de cartão | `CMPT_TRAN_RLZD_CRT` | Condicional à priorização e qualidade |
| Fatura e estado do cartão | `FAT_CRT_CRD` | Condicional; verificar capacidade de distinguir pagamento integral, parcial e financiamento |
| Renda informada | `REN_INFD_CLI` | Candidata; uso, vigência e confiabilidade não comprovados |
| Orçamento existente | `GR_ORC_CT_GRDR_OPB`, `CTGR_ORC_CT_OPB` | Candidato a validação; convivência e substituição são ambíguas no catálogo |

## 11.2 Novos registros lógicos futuros

As lentes pessoais e de jornada dependerão de entidades declaradas e planejadas, como:

- `ObjetivoFinanceiro`;
- `OrcamentoPlanejado`;
- `CompromissoPoupanca`;
- `ExecucaoCompromisso`;
- `ContextoInformadoCliente`;
- `RegistroConversa`.

Todos carregarão autoria, data, versão e proveniência. Esses contratos não serão confundidos com tabelas observadas nem implicam modelo físico nesta etapa.

## 11.3 Lacunas específicas

| Lente | O que falta provar antes de calcular |
|---|---|
| Clareza dos gastos | Universo elegível, categorias úteis, categorias amplas, causas técnicas, tratamento de meios sem finalidade e calibração do 75% |
| 50/30/20 | Renda alocável, mapeamento contextual, tratamento de dívida e reserva, cartão, parcela desconhecida e utilidade com clientes |
| Crédito | Serviço da dívida, renda de referência, cobertura das obrigações, situação da fatura, principal versus custos, eventos extraordinários |
| Jornada | Registro de autoria, consentimento para contexto, versionamento, estados, revisão e experiência com participação do cliente |

---

# 12. Riscos e proteções

| Risco | Proteção obrigatória |
|---|---|
| Transformar lentes em nova pontuação do Radar | Independência, ausência de agregação e uma pergunta delimitada por lente |
| Tratar qualidade do dado como comportamento | Nome “Clareza dos gastos”, causa visível e linguagem sobre a leitura |
| Reutilizar 75% com sentido invertido sem explicar | Registrar a regra legada e a nova definição como versões e produtos diferentes |
| Usar 75% sem evidência | Classificar como referência interna candidata e executar calibração |
| Renormalizar apenas valores conhecidos | Manter desconhecido como bloco explícito |
| Uma instituição ruim ser escondida pelo consolidado | Mostrar cobertura por fonte e permitir detalhamento |
| Um lançamento grande dominar a razão | Mostrar valor, quantidade e composição |
| Categoria técnica ser confundida com finalidade | Taxonomia por papel econômico e estados de inconclusão |
| Compra e fatura duplicarem consumo | Regra antiduplicidade por lente |
| Transferência própria virar renda ou gasto | Neutralizar apenas com evidência suficiente |
| 30% virar regra de concessão | Referência opcional, contextual e sem uso comercial |
| 50/30/20 virar meta universal | Ativação voluntária e plano do cliente como referência posterior |
| DSOP virar escore comportamental | Estados, escolhas e perguntas; nenhum percentual de desempenho |
| Gerente falar em nome do cliente | Registro de manifestação, autoria e contestação |
| Comparações alimentarem oferta | Proibição estrutural e finalidade segregada |

---

# 13. Casos mínimos de validação

## 13.1 Clareza dos gastos

1. 80% das saídas elegíveis sem finalidade identificada.
2. 80% das saídas elegíveis com finalidade conhecida.
3. Um único saque material e muitas compras pequenas categorizadas.
4. Muitas transações pequenas sem categoria e poucas grandes categorizadas.
5. Categoria ampla “Gastos diversos” versus ausência total de categoria.
6. Erro técnico de processamento versus falta real de contexto.
7. Nenhuma saída elegível.
8. Uma instituição desatualizada em consolidado aparentemente completo.

Validar se a interface comunica que 75% é cobertura da leitura e se impede qualquer atribuição de culpa ao cliente.

## 13.2 Distribuição 50/30/20

1. Renda observada parcial.
2. Renda irregular em doze meses.
3. Cobertura de finalidade exatamente em 75%, com 25% capazes de mudar qualquer bloco.
4. Compra classificada pelo sistema e contestada pelo cliente.
5. Aplicação sem objetivo confirmado.
6. Plano pessoal muito diferente da referência externa.
7. Renda inferior às necessidades reconhecidas.
8. Mês com empréstimo recebido.

Validar se o gerente compreende a diferença entre realizado, referência e plano e se evita usar a referência como diagnóstico.

## 13.3 Crédito

1. Os meses A, B e C do exemplo, mantendo pagamentos observados/renda em 30%.
2. Pagamento integral de fatura com compras detalhadas.
3. Fatura sem compras detalhadas.
4. Pagamento parcial, mínimo, rotativo e estado desconhecido.
5. Parcela imobiliária com finalidade e obrigação.
6. Empréstimo recebido no período.
7. Juros e encargos sem principal identificável.
8. Renda ausente, parcial ou declarada divergente.
9. Cobertura global alta e obrigações incompletas.
10. Cobertura global baixa e uma obrigação específica comprovada.

Validar se o sistema nunca chama participação nas saídas de comprometimento da renda.

## 13.4 Jornada futura

1. Cliente não deseja definir objetivo.
2. Cliente contesta o raio-X.
3. Objetivo sem valor ou prazo ainda definido.
4. Plano provisório por falta de dados.
5. Compromisso não realizado após emergência.
6. Aplicação observada sem vínculo confirmado com objetivo.
7. Cliente decide pausar ou encerrar.
8. Novo snapshot contradiz premissas do plano anterior.

Validar linguagem não punitiva, autoria e capacidade de revisão.

---

# 14. Métricas de sucesso

O sucesso das lentes será medido por qualidade da compreensão e da conversa, não por vendas nem por aproximação automática a uma referência.

Métricas candidatas:

- gerente identifica corretamente o que cada lente mede;
- gerente distingue referência interna, externa e pessoal;
- cliente compreende que a referência é opcional;
- tempo para explicar numerador, denominador e limitação;
- proporção de comparações em que a parcela inconclusiva foi comunicada;
- capacidade de localizar as evidências do cálculo;
- divergências registradas e preservadas;
- perguntas educativas consideradas úteis pelo gerente e pelo cliente;
- redução de dupla contagem em testes;
- ausência de frases julgadoras, falsa precisão e recomendações de produto;
- proporção de planos cuja autoria e proveniência estão registradas;
- revisões que usam o plano do cliente, não a referência externa, como base principal.

Não serão métricas deste produto:

- conversão comercial;
- contratação;
- aumento de limite ou concessão de crédito;
- quantidade de clientes classificados;
- média de nota financeira;
- percentual de clientes que “atingiu” 50/30/20;
- aderência forçada a compromisso.

---

# 15. Pendências antes da implementação

Estas pendências completam a idealização e precisam de validação; não exigem mudar a direção agora:

1. Nome final da entrada: manter “Comparar com referências” no primeiro append e testar a evolução para “Explorar lentes”.
2. Proprietário e governança do catálogo de lentes.
3. Definição versionada do universo de saídas econômicas elegíveis.
4. Lista de categorias suficientemente específicas para cada lente.
5. Tratamento de “Gastos diversos”, saque, boleto, cheque, transferência e pendência técnica.
6. Calibração empírica do limiar de 75%, separado da regra legada.
7. Regra de sensibilidade para os valores sem finalidade.
8. Definição de renda de referência e renda alocável.
9. Definições separadas de pagamentos observados, serviço elegível e obrigações contratualmente devidas.
10. Validação de cartão, fatura, principal, juros, rotativo e parcelamento.
11. Confirmação de cobertura de obrigações fora das contas observadas.
12. Fonte, validade e texto final das referências 50/30/20 e 30%.
13. Validação financeira, metodológica, negocial, jurídica, de privacidade e acessibilidade.
14. Pesquisa com gerentes e voz direta ou pesquisada de clientes.
15. Formação necessária para que o gerente explique as lentes sem prescrever.
16. Validação formal da inspiração DSOP, terminologia e uso da marca.
17. Regras de autoria, contestação, retenção e expiração dos registros declarados.
18. Teste de que as lentes não alimentam processos comerciais, oferta ou crédito.

---

# 16. Roadmap documental e de validação

| Fase | Objetivo | Saída |
|---|---|---|
| 0 — Idealização | Consolidar significado, limites e contratos | Este documento |
| 1 — Prova semântica | Validar fórmulas, universos, fontes e dupla contagem | Dicionário financeiro versionado |
| 2 — Protótipo | Testar clareza dos gastos, 50/30/20 e crédito com casos controlados | Protótipo sem integração produtiva |
| 3 — Validação com usuários | Verificar compreensão, utilidade e linguagem | Evidências e ajustes de experiência |
| 4 — Piloto controlado | Operar apenas lentes homologadas | Catálogo versionado e monitorado |
| 5 — Jornada educativa | Incorporar referências pessoais e lentes de jornada | Realizado versus plano e progresso |

Uma fase posterior não será iniciada apenas porque a anterior produziu uma tela. Cada lente precisará demonstrar verdade financeira, compreensão e utilidade negocial.

---

# 17. Decisões consolidadas

1. O conceito de lentes independentes será adotado como extensão candidata do framework.
2. O botão será **Comparar com referências**, no plural.
3. O gerente escolherá quando abrir uma comparação; nenhuma referência será diagnóstico padrão.
4. 50/30/20 será uma referência educativa externa opcional.
5. Crédito será uma dimensão transversal, separada da divisão orçamentária.
6. Participação do crédito nas saídas, pagamentos observados sobre renda e comprometimento contratual serão três métricas diferentes.
7. O 30% será, no máximo, referência externa contextual e pendente de validação, nunca regra universal.
8. A lente solicitada como “Gastos pouco categorizados” receberá o nome de experiência **Clareza dos gastos**.
9. O novo 75% significará **cobertura mínima candidata de finalidade conhecida**, e não o teto legado de 75% genérico.
10. A diferença para a regra do Radar será explícita; nenhum ponto ou perfil será herdado.
11. A categorização medirá qualidade da leitura, salvo ação comprovadamente realizada pelo cliente.
12. As lentes poderão evoluir para uma entrada mais ampla chamada **Explorar lentes**.
13. Lentes futuras inspiradas na DSOP acompanharão realidade, objetivos, plano e progresso sem se tornarem escores.
14. O plano do cliente será a principal referência no acompanhamento posterior.
15. Não haverá produto financeiro, recomendação, oferta, lead ou uso para concessão.

---

# 18. Checklist de aceite documental

## Arquitetura

- [x] Lentes independentes e sem resultado agregado.
- [x] Qualidade, referência educativa, referência pessoal, observação e jornada estão separadas.
- [x] Cada lente possui pergunta, escopo, gates, limitações e interpretações proibidas.
- [x] Ativar uma lente não altera o raio-X nem outra lente.
- [x] Estados do catálogo e da aplicação do cliente não são confundidos.

## Clareza dos gastos

- [x] A semântica legada de 75% foi documentada.
- [x] A nova referência de cobertura `≥ 75%` foi assumida como hipótese interna candidata.
- [x] O 75% não é chamado de saúde, hábito ou ciência.
- [x] Ausência de saídas resulta em não calculável.
- [x] Valor, quantidade, categorias amplas e causas técnicas permanecem visíveis.
- [x] A lente protege outras análises sem bloquear a conversa educativa.

## 50/30/20 e crédito

- [x] Realizado, referência e plano do cliente estão separados.
- [x] A exibição é opcional e acionada pelo gerente.
- [x] O denominador de 50/30/20 é renda alocável candidata, não total de saídas.
- [x] Crédito é transversal e não um quarto bloco orçamentário.
- [x] O indicador legado, a razão pagamentos/renda e o comprometimento contratual foram distinguidos.
- [x] Cartão e entrada de empréstimo receberam tratamentos conceituais próprios.
- [x] O 30% não foi apresentado como regra universal da Senacon.

## Jornada futura

- [x] Os quatro movimentos possuem lentes candidatas.
- [x] Objetivos, planos e compromissos dependem da autoria do cliente.
- [x] Observado, declarado, estimado, planejado e hipótese continuam separados.
- [x] DSOP permanece inspiração pendente de validação metodológica e de marca.
- [x] Não há pontuação, culpa, comparação social ou produto.

## Próxima validação

- [ ] Homologar o significado financeiro de cada universo.
- [ ] Perfilhar as fontes candidatas.
- [ ] Calibrar o 75% com casos reais e impacto sobre conclusões.
- [ ] Validar renda, pagamentos observados, serviço da dívida e obrigações devidas.
- [ ] Testar linguagem e utilidade com gerentes e clientes.
- [ ] Validar referências externas e governança.
- [ ] Prototipar somente após os gates documentais e semânticos.

---

# 19. Referências

## Documentos locais

- [Framework mestre do raio-X e educação financeira](./framework_mestre_raio_x_educacao_financeira.md)
- [Roteiro de descoberta negocial do MVP](./roteiro_descoberta_negocial_mvp.md)
- [Roteiro de descoberta inspirado na DSOP](./roteiro_descoberta_negocial_mvp_dsop.md)
- [Catálogo estruturado de categorias](./categorias_transacoes_estruturado.md)
- [Catálogo GFP](./gfp_catalago.md)
- [Documentação oficial do Radar](../v0_radar/documentacao_oficial_ana_edu_fin_cli.md)
- [Tabela de saída legada do Radar](../v0_radar/OLD/radar_tabela_saida.md)

## Referências externas para validação

- Elizabeth Warren e Amelia Warren Tyagi. *All Your Worth: The Ultimate Lifetime Money Plan*. Free Press, 2005. Referência bibliográfica associada à popularização do modelo 50/30/20; seu uso no produto continua opcional e contextual.
- [Consumer Financial Protection Bureau — Analyzing budgets](https://www.consumerfinance.gov/consumer-tools/educator-tools/youth-financial-education/teach/activities/analyzing-budgets/)
- [Consumer Financial Protection Bureau — My spending rule to live by](https://files.consumerfinance.gov/f/documents/cfpb_worksheet_my-spending-rule-to-live-by.pdf)
- [Banco Central do Brasil — Glossário do Relatório de Cidadania Financeira](https://www.bcb.gov.br/Nor/relcidfin/glossario.html)
- [Senacon — nota técnica de 2020 sobre o então projeto de combate ao superendividamento](https://www.gov.br/mj/pt-br/assuntos/noticias/senacon-e-sdnc-assinam-nota-tecnica-a-favor-de-pl-que-combate-superendividamento)
- [Lei nº 14.181/2021](https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14181.htm)
- [Lei nº 8.692/1993 — contexto específico de financiamento habitacional](https://www.planalto.gov.br/ccivil_03/leis/l8692compilado.htm)
- [Banco Central do Brasil — renda necessária para financiar um imóvel](https://www.bcb.gov.br/meubc/faqs/p/renda-necessaria-para-financiar-um-imovel)

As fontes externas registram a origem e o contexto das referências; não homologam automaticamente seu uso neste produto.
