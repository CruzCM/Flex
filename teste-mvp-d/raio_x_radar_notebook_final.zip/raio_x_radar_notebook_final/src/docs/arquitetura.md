# Arquitetura final

## Shell único

```text
[ Raio-X financeiro ] [ Radar comportamental ]

Cliente · Período · Instituições · Contas · Moeda · Natureza · Identificação
```

Os filtros são compartilhados. O estado visual dos dashboards é independente.

## Raio-X

```text
1. Diagnóstico em 30 segundos
2. Caminho do dinheiro
3. Onde existe concentração
4. Fechamento do Raio-X
```

- categoria vigente é a visualização oficial padrão;
- categoria original permanece na auditoria e nos filtros avançados;
- códigos 0–9 são macroclassificações do Raio-X;
- Resultado do Radar e lentes não completam nem recalculam o Raio-X;
- valor não identificado nunca desaparece.

## Radar

```text
Resultado do Radar | Explorar lentes
```

### Resultado do Radar

O provider representa:

- `FL_PARTICIPA_RADAR`;
- motivo de indisponibilidade;
- perfil de renda, macroperfil, microperfil e perfil financeiro;
- resultado orçamentário;
- cinco temas;
- pontuação e composição por tema;
- cobertura e limitações.

Os valores ficam marcados como simulados até a integração produtiva.

### Explorar lentes

Cada lente possui:

- pergunta delimitada;
- estado de disponibilidade;
- Realizado;
- Referência;
- Plano do cliente;
- período, moeda e denominador;
- cobertura e limitações;
- cálculo auditável;
- evidências;
- perguntas neutras;
- interpretações proibidas;
- registro opcional em memória de contextualização ou contestação.

## Interação

- filtro global recalcula os blocos;
- seletor de gráfico altera apenas aquela visualização;
- clique em gráfico abre a rastreabilidade;
- expandir mostra explicação e composição;
- maximizar mostra até cinco registros;
- Ver todas abre o painel lateral;
- `Esc` fecha painéis e modal;
- zero, não calculável, indisponível e não fornecido são estados distintos.
