# Assinatura pública do notebook

```python
resultado = fluxo_dashboard(
    cd_cli,
    *,
    periodo_inicio=None,
    periodo_fim=None,
    moeda=None,
    instituicoes=None,
    produto_inicial="raio_x",
    area_radar_inicial="resultado",
    base_inicial="ajustada",
    lente_inicial="clareza",
    provider=None,
    cenario_mock=None,
    exibir=True,
)
```

`cd_cli` é obrigatório. O provider recebe um `ConsultaDashboard` e devolve o
contrato consumido pela apresentação. O mock é apenas o adapter de desenvolvimento.
A integração produtiva implementará `DashboardProvider` e será injetada por
`provider=...`, sem reconstruir o front-end.
