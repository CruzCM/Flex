# Regras do mock

## Base bruta

Inclui todas as entradas e saídas encontradas nos filtros atuais.

## Base ajustada

Retira as duas pontas de pares com `identificacao_fluxo = IDENTIFICADA`.

- `POSSIVEL` permanece nos totais;
- `NAO_IDENTIFICADA` permanece nos totais;
- nenhum valor é renormalizado ou distribuído silenciosamente.

## Status observado

Hipótese parametrizada do protótipo:

```text
diferença / entradas >  2% → Superávit observado
diferença / entradas < -2% → Déficit observado
entre -2% e +2%             → Equilíbrio observado
```

A regra pertence ao Raio-X mockado. Não é regra do Resultado do Radar e não representa saúde financeira.

## Resultado do Radar

Os cinco temas e campos de perfil são mockados no provider e aparecem com a marca:

> Dados simulados para protótipo

O protótipo não calcula tema prioritário, desempate ou nota global.

## Lentes

- Clareza dos gastos: referência interna candidata de 75%, explicitamente hipotética;
- 50/30/20: referência educativa opcional, com parcela desconhecida explícita;
- Crédito: indisponível para razão contratual quando os gates não são atendidos;
- Realidade reconhecida: futura e dependente de autoria do cliente.
