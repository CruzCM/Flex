"""Contratos lógicos do protótipo Raio-X + Radar.

A apresentação depende destes contratos, e não da origem física dos dados.
O provider mockado pode ser substituído por um adapter produtivo sem alterar
os componentes visuais.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal

Natureza = Literal["C", "D"]
EstadoIdentificacao = Literal["IDENTIFICADA", "POSSIVEL", "NAO_IDENTIFICADA", "NAO_APLICAVEL"]
ProdutoInicial = Literal["raio_x", "radar"]
AreaRadarInicial = Literal["resultado", "lentes"]
BaseInicial = Literal["bruta", "ajustada"]


@dataclass(frozen=True)
class ConsultaDashboard:
    """Escopo solicitado pelo notebook ao provider de dados."""

    cd_cli: str
    periodo_inicio: str | None = None
    periodo_fim: str | None = None
    moeda: str = "BRL"
    instituicoes: tuple[int, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Movimento:
    id: str
    data: str
    mes: str
    descricao_protegida: str
    instituicao: int
    marca: int | None
    conta: str
    produto: str
    natureza: Natureza
    valor: float
    moeda: str
    grupo_oficial: str
    categoria_original: str
    categoria_vigente: str
    macroclasse: int
    macroclasse_nome: str
    origem_categorizacao: str
    estado_movimentacao: str
    identificacao_fluxo: EstadoIdentificacao
    par_interno_id: str | None = None
    instituicao_contraparte: int | None = None
    confianca_identificacao: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TemaRadar:
    id: str
    nome: str
    pontuacao: float | None
    percentual_observado: float | None
    percentual_referencia: float | None
    componentes: list[dict[str, Any]]
    cobertura: str
    limitacao: str
    formula_status: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ResultadoRadar:
    fl_participa_radar: str
    motivo_indisponibilidade: str | None
    perfil_renda: str | None
    macroperfil: str | None
    microperfil: str | None
    perfil_financeiro: str | None
    resultado_orcamentario: dict[str, Any]
    temas: list[TemaRadar]
    periodo: str
    moeda: str
    cobertura: str
    limitacoes: list[str]
    dados_simulados: bool = True

    def to_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["temas"] = [tema.to_dict() for tema in self.temas]
        return out


@dataclass(frozen=True)
class Lente:
    id: str
    nome: str
    familia: str
    pergunta: str
    estado: str
    resumo_estado: str
    realizado: Any
    referencia: Any
    plano_cliente: Any
    periodo: str
    moeda: str
    denominador: str
    origem_referencia: str
    versao: str
    cobertura: str
    limitacoes: list[str]
    como_calculamos: list[str]
    perguntas: list[str]
    interpretacoes_proibidas: list[str]
    evidencias_ids: list[str]
    futura: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
