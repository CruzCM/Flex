"""Configuração do ambiente de notebook."""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

from dotenv import load_dotenv


@dataclass(frozen=True)
class Configuracao:
    ambiente: str
    provider: str
    cenario_mock: str
    moeda_padrao: str
    limiar_equilibrio_pct: float
    incluir_plotly_offline: bool


def _bool_env(nome: str, padrao: bool) -> bool:
    valor = os.getenv(nome)
    if valor is None:
        return padrao
    return valor.strip().lower() in {"1", "true", "sim", "s", "yes"}


def carregar_configuracao(arquivo: str | Path | None = None) -> Configuracao:
    raiz = Path(__file__).resolve().parents[1]
    caminho = Path(arquivo) if arquivo else raiz / "desenv.env"
    if caminho.exists():
        load_dotenv(caminho, override=False)
    return Configuracao(
        ambiente=os.getenv("APP_AMBIENTE", "desenvolvimento"),
        provider=os.getenv("DASHBOARD_PROVIDER", "mock"),
        cenario_mock=os.getenv("DASHBOARD_CENARIO_MOCK", "cliente_completo"),
        moeda_padrao=os.getenv("DASHBOARD_MOEDA_PADRAO", "BRL").upper(),
        limiar_equilibrio_pct=float(os.getenv("DASHBOARD_LIMIAR_EQUILIBRIO_PCT", "0.02")),
        incluir_plotly_offline=_bool_env("DASHBOARD_PLOTLY_OFFLINE", True),
    )
