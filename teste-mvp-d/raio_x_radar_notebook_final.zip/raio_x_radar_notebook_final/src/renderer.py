"""Renderer HTML/CSS/JavaScript do protótipo.

A aplicação continua sendo executada no notebook. O Python gera uma interface
self-contained com CSS e JavaScript embutidos e gráficos Plotly offline.
"""
from __future__ import annotations

import json
from typing import Any

from plotly.offline import get_plotlyjs


from .app import Visual

def _markup(data_json: str) -> str:
    return f"""
<div class="fin-app" id="fin-app">
  <header class="fin-topbar">
    <div class="fin-brand">
      <small>Protótipo analítico para o gerente</small>
      <h1 id="page-title">Raio-X financeiro</h1>
      <p id="page-subtitle">O que aconteceu com o dinheiro no recorte observado.</p>
    </div>
    <nav class="fin-product-nav" aria-label="Produtos">
      <button type="button" class="is-active" data-product="raiox">Raio-X financeiro</button>
      <button type="button" data-product="radar">Radar comportamental</button>
    </nav>
  </header>

  <section class="fin-context" aria-label="Contexto e filtros globais">
    <div class="fin-context-label"><div><strong>Cliente código <span id="context-client">123456</span></strong><small id="context-meta">Dados simulados para protótipo</small></div></div>
    <div class="fin-control"><label for="filter-period">Período</label><select id="filter-period"><option value="all">12 meses</option><option value="6">Últimos 6 meses</option><option value="3">Últimos 3 meses</option></select></div>
    <div class="fin-control"><label for="filter-inst">Instituições</label><select id="filter-inst"><option value="all">Todas</option></select></div>
    <div class="fin-control"><label for="filter-account">Contas</label><select id="filter-account"><option value="all">Todas</option></select></div>
    <div class="fin-control"><label for="filter-currency">Moeda</label><select id="filter-currency"><option value="BRL">BRL</option></select></div>
    <div class="fin-control"><label for="filter-nature">Natureza</label><select id="filter-nature"><option value="all">Entradas e saídas</option><option value="C">Entradas</option><option value="D">Saídas</option></select></div>
    <div class="fin-control"><label for="filter-identification">Identificação</label><select id="filter-identification"><option value="all">Todos os estados</option><option value="IDENTIFICADA">Interna identificada</option><option value="POSSIVEL">Interna possível</option><option value="NAO_IDENTIFICADA">Não identificada</option></select></div>
    <div class="fin-context-actions">
      <button type="button" class="fin-btn" id="open-filters">Todos os filtros</button>
      <button type="button" class="fin-btn soft" id="compare-references">Comparar com referências</button>
    </div>
  </section>
  <div class="fin-chips" id="filter-chips" aria-live="polite"></div>

  <main>
    <div class="fin-panel is-active" data-product-panel="raiox">
      <section class="fin-section" id="diagnostico">
        <div class="fin-section-head">
          <div><div class="fin-kicker">1 · Diagnóstico em 30 segundos</div><h2>O recorte em uma conclusão</h2><p>Quanto entrou, quanto saiu, qual foi a diferença e o que ainda não está suficientemente compreendido.</p></div>
          <div class="fin-section-actions"><div class="fin-segment" aria-label="Base do Raio-X"><button type="button" data-base="bruta">Base bruta</button><button type="button" data-base="ajustada" class="is-active">Base ajustada</button></div></div>
        </div>
        <div class="fin-summary-grid">
          <article class="fin-status-card" id="status-card">
            <div class="fin-status-top"><span class="fin-status-label">Resultado do recorte</span><span class="fin-status-tag" id="status-base-tag">Base ajustada</span></div>
            <div class="fin-status-title" id="status-title">Superávit observado</div>
            <div class="fin-status-value" id="status-value">R$ 0,00</div>
            <div class="fin-status-rate" id="status-rate">0% das entradas observadas</div>
            <p class="fin-status-copy" id="status-copy"></p>
            <div class="fin-status-actions"><button type="button" class="fin-btn" id="expand-status">Expandir evolução</button><button type="button" class="fin-btn" data-max-card="resultado">Ver composição</button></div>
            <div class="fin-status-expanded" id="status-expanded"><div id="monthly-chart" class="fin-mini-chart"></div><p class="fin-tooltip-note">Mês sem movimentação encontrada não comprova ausência de renda ou gasto.</p></div>
          </article>
          <div>
            <div class="fin-metric-grid">
              <article class="fin-metric" data-card="entradas"><div class="fin-metric-label"><span>Entradas observadas</span></div><strong class="fin-metric-value" id="metric-entries">R$ 0,00</strong><small id="metric-entries-note"></small><div class="fin-card-tools"><button type="button" data-expand-card="entradas">Explicar</button><button type="button" data-max-card="entradas">Abrir</button></div></article>
              <article class="fin-metric" data-card="saidas" data-tone="teal"><div class="fin-metric-label"><span>Saídas observadas</span></div><strong class="fin-metric-value" id="metric-exits">R$ 0,00</strong><small id="metric-exits-note"></small><div class="fin-card-tools"><button type="button" data-expand-card="saidas">Explicar</button><button type="button" data-max-card="saidas">Abrir</button></div></article>
              <article class="fin-metric" data-card="internas" data-tone="amber"><div class="fin-metric-label"><span>Movimentação interna identificada</span></div><strong class="fin-metric-value" id="metric-internal">R$ 0,00</strong><small id="metric-internal-note"></small><div class="fin-card-tools"><button type="button" data-expand-card="internas">Explicar</button><button type="button" data-max-card="internas">Abrir</button></div></article>
              <article class="fin-metric" data-card="identificar" data-tone="purple"><div class="fin-metric-label"><span>Valor ainda a identificar</span></div><strong class="fin-metric-value" id="metric-unknown">R$ 0,00</strong><small id="metric-unknown-note"></small><div class="fin-card-tools"><button type="button" data-expand-card="identificar">Explicar</button><button type="button" data-max-card="identificar">Abrir</button></div></article>
            </div>
            <div class="fin-coverage" id="coverage-strip"></div>
          </div>
        </div>
        <div class="fin-smart-print"><div><h3 id="hero-insight-title">Principal achado</h3><p id="hero-insight-copy"></p></div><div class="fin-smart-next"><strong>Cuidado ao interpretar</strong><p id="hero-insight-caution"></p><button type="button" class="fin-btn teal" id="hero-next-action">Investigar concentração</button></div></div>
      </section>

      <section class="fin-section" id="caminho">
        <div class="fin-section-head"><div><div class="fin-kicker">2 · Caminho do dinheiro</div><h2>Por onde as movimentações passaram</h2><p>O fluxo completo preserva duas composições independentes: origens das entradas e destinos das saídas. Não liga causalmente uma entrada específica a um gasto.</p></div></div>
        <div class="fin-chart-card">
          <div class="fin-chart-toolbar">
            <div><h3>Caminho observado</h3><p>Clique em um nó ou conexão para abrir as movimentações relacionadas.</p></div>
            <div class="fin-toolbar-controls">
              <label>Fluxo<select id="flow-mode"><option value="completo">Completo</option><option value="entradas">Entradas</option><option value="saidas">Saídas</option></select></label>
              <label>Destino<select id="flow-destination"><option value="macro">Macroclassificação 0–9</option><option value="categoria">Categoria oficial</option><option value="instituicao">Instituição</option></select></label>
              <label>Base<select id="flow-base"><option value="ajustada">Ajustada</option><option value="bruta">Bruta</option></select></label>
              <label>Exibir<select id="flow-identification"><option value="todos">Todos</option><option value="identificados">Identificados</option><option value="possiveis">Possíveis</option><option value="nao_identificados">Não identificados</option></select></label>
            </div>
          </div>
          <div id="sankey-chart" class="fin-chart" aria-label="Gráfico de fluxo das movimentações"></div>
        </div>
        <div class="fin-flow-stats">
          <button type="button" class="fin-flow-stat" data-flow-stat="IDENTIFICADA"><span>Movimentação interna identificada</span><strong id="flow-identified">R$ 0,00</strong><small>Pares retirados apenas da base ajustada.</small></button>
          <button type="button" class="fin-flow-stat" data-flow-stat="POSSIVEL"><span>Possível movimentação interna</span><strong id="flow-possible">R$ 0,00</strong><small>Permanece nos totais até confirmação.</small></button>
          <button type="button" class="fin-flow-stat" data-flow-stat="NAO_IDENTIFICADA"><span>Fluxo sem destino compreendido</span><strong id="flow-unknown">R$ 0,00</strong><small>Nunca é ocultado nem redistribuído.</small></button>
        </div>
        <div class="fin-smart-print"><div><h3 id="flow-insight-title">Leitura do fluxo</h3><p id="flow-insight-copy"></p></div><div class="fin-smart-next"><strong>Próximo passo</strong><p id="flow-next-copy"></p><button type="button" class="fin-btn teal" id="flow-next-action">Abrir concentração</button></div></div>
      </section>

      <section class="fin-section" id="concentracao">
        <div class="fin-section-head"><div><div class="fin-kicker">3 · Onde existe concentração</div><h2>Uma lente, duas taxonomias</h2><p>Categoria oficial oferece granularidade. Macroclassificação Raio-X 0–9 reorganiza a categoria original para uma leitura analítica; não é categoria oficial nem indicador do Radar.</p></div></div>
        <div class="fin-concentration-grid">
          <div class="fin-chart-card">
            <div class="fin-chart-toolbar">
              <div><h3>Concentração das movimentações</h3><p>Selecione uma barra para destacar instituições e abrir transações.</p></div>
              <div class="fin-toolbar-controls">
                <label>Dimensão<select id="concentration-dimension"><option value="categoria">Categoria oficial</option><option value="macro">Macroclassificação 0–9</option></select></label>
                <label>Agrupar por<select id="concentration-group"><option value="consolidado">Consolidado</option><option value="instituicao">Instituição</option></select></label>
                <label>Métrica<select id="concentration-metric"><option value="valor">Valor</option><option value="quantidade">Quantidade</option><option value="participacao">Participação</option></select></label>
                <label>Natureza<select id="concentration-nature"><option value="D">Saídas</option><option value="C">Entradas</option></select></label>
              </div>
            </div>
            <div id="concentration-chart" class="fin-chart"></div>
          </div>
          <div class="fin-related-table"><div class="fin-related-table-head"><h3 id="concentration-table-title">Principais concentrações</h3><p id="concentration-table-copy">Categoria vigente como padrão.</p></div><div class="fin-table-scroll"><table><thead><tr><th>Dimensão</th><th>Instituição</th><th>Valor</th><th>Part.</th><th>Qtd.</th><th></th></tr></thead><tbody id="concentration-table-body"></tbody></table></div></div>
        </div>
        <div class="fin-smart-print"><div><h3 id="concentration-insight-title">Maior concentração</h3><p id="concentration-insight-copy"></p></div><div class="fin-smart-next"><strong>Cuidado ao interpretar</strong><p>Concentração descreve o recorte encontrado. Não determina preferência, excesso ou importância definitiva para o cliente.</p><button type="button" class="fin-btn teal" id="concentration-next-action">Ver transações principais</button></div></div>
      </section>

      <section class="fin-section" id="fechamento">
        <div class="fin-section-head"><div><div class="fin-kicker">4 · Fechamento do Raio-X</div><h2>O que a leitura permite concluir agora</h2><p>Uma resposta consolidada, sem repetir todos os gráficos e sem transformar o recorte em saldo, patrimônio ou diagnóstico.</p></div></div>
        <div class="fin-closing"><div class="fin-closing-main"><span>Conclusão do recorte</span><h3 id="closing-title"></h3><p id="closing-copy"></p><div class="fin-closing-actions"><button type="button" class="fin-btn" id="closing-investigate">Investigar principal concentração</button><button type="button" class="fin-btn" id="closing-unknown">Revisar a identificar</button><button type="button" class="fin-btn" id="closing-references">Comparar com referências</button></div></div><div class="fin-closing-list" id="closing-list"></div></div>
      </section>
    </div>

    <div class="fin-panel" data-product-panel="radar">
      <nav class="fin-radar-subnav" aria-label="Áreas do Radar"><button type="button" class="is-active" data-radar-tab="resultado">Resultado do Radar</button><button type="button" data-radar-tab="lentes">Explorar lentes</button></nav>

      <div class="fin-radar-view is-active" data-radar-view="resultado">
        <div class="fin-sim-banner"><b>i</b><div><strong>Dados simulados para protótipo</strong><p>Esta área representa o contrato do Resultado do Radar por meio de um provider substituível. Nenhuma pontuação abaixo é resultado real do cliente.</p></div></div>
        <section class="fin-radar-hero">
          <article class="fin-eligibility"><div class="fin-eligibility-header"><span>Elegibilidade e cobertura</span><span class="fin-state-badge" id="radar-eligibility-badge">Participa</span></div><h2 id="radar-eligibility-title"></h2><p id="radar-eligibility-copy"></p><div class="fin-profile-grid" id="radar-profiles"></div></article>
          <article class="fin-budget-result"><span>Resultado orçamentário oficial do Radar</span><strong id="radar-budget-value">—</strong><p id="radar-budget-copy"></p><small>O Resultado do Radar preserva sua regra oficial própria. Ele não é recalculado pela diferença observada do Raio-X.</small></article>
        </section>
        <section class="fin-section">
          <div class="fin-section-head"><div><div class="fin-kicker">Cinco temas do modelo existente</div><h2>Resultados independentes por tema</h2><p>Não há tema prioritário nem regra de desempate neste protótipo. Os temas não são somados às lentes e não produzem nota global.</p></div></div>
          <div class="fin-theme-grid"><div><div id="radar-themes-chart" class="fin-chart-card" style="min-height:360px;padding:7px"></div><div class="fin-theme-list" id="radar-theme-list"></div></div><aside class="fin-theme-detail" id="radar-theme-detail"></aside></div>
        </section>
      </div>

      <div class="fin-radar-view" data-radar-view="lentes">
        <div class="fin-sim-banner"><b>↗</b><div><strong>Lentes independentes e opcionais</strong><p>Abrir uma lente não altera o Raio-X, as pontuações do Radar nem outra lente. Realizado, Referência e Plano do cliente permanecem separados.</p></div></div>
        <div class="fin-lens-shell"><aside class="fin-lens-catalog"><div class="fin-lens-catalog-head"><h2>Explorar lentes</h2><p>O estado depende dos gates específicos de cada pergunta.</p></div><div class="fin-lens-groups" id="lens-catalog"></div></aside><section class="fin-lens-detail" id="lens-detail"></section></div>
      </div>
    </div>
  </main>

  <footer class="fin-footer">Protótipo executado em Jupyter · Python gera HTML, CSS e gráficos Plotly · valores mockados e rastreáveis ao provider.</footer>

  <div class="fin-overlay" id="filter-overlay"><aside class="fin-drawer" role="dialog" aria-modal="true" aria-labelledby="filters-title"><div class="fin-drawer-head"><div><h2 id="filters-title">Todos os filtros</h2><p>Filtros globais recalculam os dois dashboards. Controles dos gráficos alteram apenas a visão correspondente.</p></div><button type="button" class="fin-close" data-close-overlay="filter-overlay" aria-label="Fechar">×</button></div><div class="fin-filter-grid">
    <label>Categoria vigente<select id="adv-current-category"><option value="all">Todas</option></select></label>
    <label>Categoria original<select id="adv-original-category"><option value="all">Todas</option></select></label>
    <label>Macroclassificação 0–9<select id="adv-macro"><option value="all">Todas</option></select></label>
    <label>Produto<select id="adv-product"><option value="all">Todos</option></select></label>
    <label>Valor mínimo<input type="number" id="adv-min-value" min="0" step="10" placeholder="0"></label>
    <label>Valor máximo<input type="number" id="adv-max-value" min="0" step="10" placeholder="Sem limite"></label>
    <label>Transferência interna<select id="adv-transfer"><option value="all">Todos</option><option value="IDENTIFICADA">Identificada</option><option value="POSSIVEL">Possível</option><option value="NAO_APLICAVEL">Não aplicável</option></select></label>
    <label>Confiança mínima<input type="number" id="adv-confidence" min="0" max="100" step="1" placeholder="0 a 100"></label>
    <label style="grid-column:1/-1">Busca na descrição protegida<input type="search" id="adv-search" placeholder="Ex.: aluguel, transferência, aplicação"></label>
  </div><div class="fin-drawer-actions"><button type="button" class="fin-btn" id="reset-filters">Limpar</button><button type="button" class="fin-btn primary" id="apply-filters">Aplicar filtros</button></div></aside></div>

  <div class="fin-overlay" id="tx-overlay"><aside class="fin-drawer wide" role="dialog" aria-modal="true" aria-labelledby="tx-title"><div class="fin-drawer-head"><div><h2 id="tx-title">Movimentações que formam os números</h2><p id="tx-subtitle">Rastreabilidade do recorte atual.</p></div><button type="button" class="fin-close" data-close-overlay="tx-overlay" aria-label="Fechar">×</button></div><div class="fin-tx-toolbar"><input type="search" id="tx-search" placeholder="Filtrar descrição, categoria, instituição ou código"><button type="button" class="fin-btn" id="tx-clear-selection">Limpar seleção contextual</button></div><div class="fin-tx-summary" id="tx-summary"></div><div class="fin-tx-scroll"><table class="fin-tx-table"><thead><tr><th>Data</th><th>Descrição protegida</th><th>Instituição / conta</th><th>Grupo</th><th>Categoria vigente</th><th>Categoria original</th><th>Macroclassificação</th><th>Natureza</th><th>Valor</th><th>Identificação</th></tr></thead><tbody id="tx-table-body"></tbody></table></div></aside></div>

  <div class="fin-modal-wrap" id="card-modal"><article class="fin-modal" role="dialog" aria-modal="true" aria-labelledby="card-modal-title"><div class="fin-modal-head"><div><h2 id="card-modal-title">Detalhamento</h2><p class="fin-modal-sub" id="card-modal-sub"></p></div><button type="button" class="fin-close" id="close-card-modal" aria-label="Fechar">×</button></div><div class="fin-modal-body" id="card-modal-body"></div></article></div>

  <script type="application/json" id="dashboard-data">{data_json.replace("</", "<\\/")}</script>
</div>
"""


JAVASCRIPT = r"""
<script>
(function(){
'use strict';
const root=document.getElementById('fin-app');
const DATA=JSON.parse(document.getElementById('dashboard-data').textContent);
const fmtMoney=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL',maximumFractionDigits:2});
const fmtNumber=new Intl.NumberFormat('pt-BR');
const pct=(v,d=1)=>`${Number(v||0).toFixed(d).replace('.',',')}%`;
const esc=(v)=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const INITIAL_UI=DATA.ui||{};
const state={
 product:INITIAL_UI.produto_inicial==='radar'?'radar':'raiox',radarTab:INITIAL_UI.area_radar_inicial==='lentes'?'lentes':'resultado',base:INITIAL_UI.base_inicial==='bruta'?'bruta':'ajustada',selectedTheme:null,selectedLens:INITIAL_UI.lente_inicial||'clareza',selection:null,
 filters:{period:'all',institution:'all',account:'all',currency:'BRL',nature:'all',identification:'all',currentCategory:'all',originalCategory:'all',macro:'all',product:'all',minValue:null,maxValue:null,transfer:'all',confidence:null,search:''},
 flow:{mode:'completo',destination:'macro',identification:'todos'},
 concentration:{dimension:'categoria',group:'consolidado',metric:'valor',nature:'D'},
 cardExpanded:null,modalCard:null,lensRecords:{},
};
const byId=id=>document.getElementById(id);
const all=sel=>Array.from(root.querySelectorAll(sel));

function monthCutoff(){
 const months=[...new Set(DATA.movimentacoes.map(t=>t.mes))].sort();
 if(state.filters.period==='all') return null;
 const n=Number(state.filters.period); return months.slice(-n)[0]||null;
}
function filteredTransactions(opts={}){
 const cutoff=monthCutoff();
 return DATA.movimentacoes.filter(t=>{
   const f=state.filters;
   if(cutoff&&t.mes<cutoff)return false;
   if(f.institution!=='all'&&String(t.instituicao)!==String(f.institution))return false;
   if(f.account!=='all'&&t.conta!==f.account)return false;
   if(f.currency!=='all'&&t.moeda!==f.currency)return false;
   if(!opts.ignoreNature&&f.nature!=='all'&&t.natureza!==f.nature)return false;
   if(f.identification!=='all'&&t.identificacao_fluxo!==f.identification)return false;
   if(f.currentCategory!=='all'&&t.categoria_vigente!==f.currentCategory)return false;
   if(f.originalCategory!=='all'&&t.categoria_original!==f.originalCategory)return false;
   if(f.macro!=='all'&&String(t.macroclasse)!==String(f.macro))return false;
   if(f.product!=='all'&&t.produto!==f.product)return false;
   if(f.minValue!==null&&t.valor<f.minValue)return false;
   if(f.maxValue!==null&&t.valor>f.maxValue)return false;
   if(f.transfer!=='all'&&t.identificacao_fluxo!==f.transfer)return false;
   if(f.confidence!==null&&Number(t.confianca_identificacao||0)<f.confidence)return false;
   if(f.search&&!`${t.descricao_protegida} ${t.categoria_vigente} ${t.categoria_original}`.toLowerCase().includes(f.search.toLowerCase()))return false;
   return true;
 });
}
function baseTransactions(base=state.base,opts={}){
 const tx=filteredTransactions(opts);
 return base==='ajustada'?tx.filter(t=>t.identificacao_fluxo!=='IDENTIFICADA'):tx;
}
function sum(tx,pred=()=>true){return tx.filter(pred).reduce((a,t)=>a+Number(t.valor),0)}
function unique(arr){return [...new Set(arr)]}
function aggregate(){
 const raw=filteredTransactions({ignoreNature:true});
 const tx=baseTransactions(state.base,{ignoreNature:true});
 const entries=sum(tx,t=>t.natureza==='C');
 const exits=sum(tx,t=>t.natureza==='D');
 const difference=entries-exits;
 const ratio=entries?difference/entries:0;
 const threshold=Number(DATA.meta.limiar_equilibrio_pct||.02);
 let status='Equilíbrio observado'; if(ratio>threshold)status='Superávit observado'; else if(ratio<-threshold)status='Déficit observado';
 const internal=sum(raw,t=>t.natureza==='D'&&t.identificacao_fluxo==='IDENTIFICADA');
 const possible=sum(raw,t=>t.natureza==='D'&&t.identificacao_fluxo==='POSSIVEL');
 const unknownEntry=sum(tx,t=>t.natureza==='C'&&t.macroclasse===0&&t.identificacao_fluxo!=='IDENTIFICADA');
 const unknownExit=sum(tx,t=>t.natureza==='D'&&t.macroclasse===5&&t.identificacao_fluxo!=='IDENTIFICADA');
 const institutions=unique(raw.map(t=>t.instituicao));
 const accounts=unique(raw.map(t=>t.conta));
 const months=unique(raw.map(t=>t.mes));
 return{raw,tx,entries,exits,difference,ratio,status,internal,possible,unknownEntry,unknownExit,unknown:unknownEntry+unknownExit,institutions,accounts,months};
}
function topInstitution(tx,nature='D'){
 const total=sum(tx,t=>t.natureza===nature); const map={};
 tx.filter(t=>t.natureza===nature).forEach(t=>map[t.instituicao]=(map[t.instituicao]||0)+t.valor);
 const sorted=Object.entries(map).sort((a,b)=>b[1]-a[1]);
 if(!sorted.length)return null; return{code:sorted[0][0],value:sorted[0][1],share:total?sorted[0][1]/total*100:0};
}
function statusText(a){
 const base=state.base==='ajustada'?'ajustada, sem pares internos identificados':'bruta, com todas as movimentações encontradas';
 return `A diferença corresponde à base ${base}. Ela não representa saldo, patrimônio ou renda disponível completa.`;
}
function renderHero(){
 const a=aggregate();
 byId('status-title').textContent=a.status;
 byId('status-value').textContent=fmtMoney.format(a.difference);
 byId('status-rate').textContent=`${pct(Math.abs(a.ratio*100))} das entradas observadas · ${a.difference>=0?'diferença positiva':'diferença negativa'}`;
 byId('status-copy').textContent=statusText(a);
 byId('status-base-tag').textContent=state.base==='ajustada'?'Base ajustada':'Base bruta';
 byId('metric-entries').textContent=fmtMoney.format(a.entries);
 byId('metric-exits').textContent=fmtMoney.format(a.exits);
 byId('metric-internal').textContent=fmtMoney.format(a.internal);
 byId('metric-unknown').textContent=fmtMoney.format(a.unknown);
 byId('metric-entries-note').textContent=`${fmtNumber.format(a.tx.filter(t=>t.natureza==='C').length)} movimentações de entrada no recorte.`;
 byId('metric-exits-note').textContent=`${fmtNumber.format(a.tx.filter(t=>t.natureza==='D').length)} movimentações de saída no recorte.`;
 byId('metric-internal-note').textContent=state.base==='ajustada'?'Neutralizada dos totais da base ajustada.':'Incluída na base bruta; altere a base para neutralizar.';
 byId('metric-unknown-note').textContent=`${fmtMoney.format(a.unknownEntry)} em entradas · ${fmtMoney.format(a.unknownExit)} em saídas.`;
 byId('coverage-strip').innerHTML=`<span><strong>${fmtNumber.format(a.raw.length)}</strong> movimentações</span><span><strong>${a.institutions.length}</strong> instituições</span><span><strong>${a.accounts.length}</strong> contas observadas</span><span><strong>${a.months.length}</strong> meses com movimentação</span><span>Moeda: <strong>${state.filters.currency}</strong></span>`;
 const ti=topInstitution(a.tx,'D');
 if(ti){
   byId('hero-insight-title').textContent=`Instituição ${ti.code} concentra a maior parcela das saídas`;
   byId('hero-insight-copy').textContent=`Foram observados ${fmtMoney.format(ti.value)} em saídas na Instituição código ${ti.code}, equivalentes a ${pct(ti.share)} das saídas da base ${state.base}.`;
   byId('hero-insight-caution').textContent='A concentração descreve apenas as movimentações disponíveis e não comprova que esta seja a instituição principal do cliente.';
   byId('hero-next-action').dataset.institution=ti.code;
 }
 renderMonthly(a.tx);
 all('[data-base]').forEach(b=>b.classList.toggle('is-active',b.dataset.base===state.base));
 byId('flow-base').value=state.base;
}
function renderMonthly(tx){
 const months=unique(tx.map(t=>t.mes)).sort();
 const entries=months.map(m=>sum(tx,t=>t.mes===m&&t.natureza==='C'));
 const exits=months.map(m=>sum(tx,t=>t.mes===m&&t.natureza==='D'));
 const diff=entries.map((v,i)=>v-exits[i]);
 Plotly.react('monthly-chart',[
  {type:'bar',name:'Entradas',x:months,y:entries,marker:{color:'#27649b'},hovertemplate:'%{x}<br>Entradas: R$ %{y:,.2f}<extra></extra>'},
  {type:'bar',name:'Saídas',x:months,y:exits,marker:{color:'#267d82'},hovertemplate:'%{x}<br>Saídas: R$ %{y:,.2f}<extra></extra>'},
  {type:'scatter',mode:'lines+markers',name:'Diferença',x:months,y:diff,line:{color:'#9b6a19',width:2},marker:{size:5},hovertemplate:'%{x}<br>Diferença: R$ %{y:,.2f}<extra></extra>'}
 ],{height:220,margin:{l:45,r:12,t:20,b:35},barmode:'group',paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{family:'Inter,Segoe UI,Arial',size:10,color:'#43566b'},legend:{orientation:'h',y:1.12},xaxis:{tickangle:-25,gridcolor:'#eef2f5'},yaxis:{gridcolor:'#eef2f5'}},{responsive:true,displayModeBar:false});
}
function flowFiltered(tx){
 const mode=state.flow.identification;
 if(mode==='todos')return tx;
 if(mode==='possiveis')return tx.filter(t=>t.identificacao_fluxo==='POSSIVEL');
 if(mode==='nao_identificados')return tx.filter(t=>t.identificacao_fluxo==='NAO_IDENTIFICADA'||[0,5].includes(t.macroclasse));
 if(mode==='identificados')return tx.filter(t=>t.identificacao_fluxo==='IDENTIFICADA'||(t.identificacao_fluxo==='NAO_APLICAVEL'&&![0,5].includes(t.macroclasse)));
 return tx;
}
function addLink(store,source,target,value,meta){
 const key=`${source}|||${target}`; if(!store[key])store[key]={source,target,value:0,meta}; store[key].value+=value;
}
function destinationLabel(t){
 if(state.flow.destination==='categoria')return t.categoria_vigente;
 if(state.flow.destination==='instituicao')return `Instituição ${t.instituicao}`;
 return `${t.macroclasse} · ${t.macroclasse_nome}`;
}
function buildSankey(){
 const tx=flowFiltered(baseTransactions(state.base,{ignoreNature:true}));
 const links={};
 if(['completo','entradas'].includes(state.flow.mode)){
   tx.filter(t=>t.natureza==='C').forEach(t=>{
     const source=`Origem · ${t.macroclasse_nome}`;
     const target=`Entrada · Instituição ${t.instituicao}`;
     addLink(links,source,target,t.valor,{nature:'C',macro:t.macroclasse,institution:t.instituicao});
   });
 }
 if(['completo','saidas'].includes(state.flow.mode)){
   tx.filter(t=>t.natureza==='D').forEach(t=>{
     const source=`Saída · Instituição ${t.instituicao}`;
     let target;
     if(t.identificacao_fluxo==='IDENTIFICADA')target=`Interna identificada · Instituição ${t.instituicao_contraparte}`;
     else if(t.identificacao_fluxo==='POSSIVEL')target=`Interna possível · Instituição ${t.instituicao_contraparte||'?'}`;
     else if(t.identificacao_fluxo==='NAO_IDENTIFICADA'||t.macroclasse===5)target='Destino não identificado';
     else target=`Destino · ${destinationLabel(t)}`;
     addLink(links,source,target,t.valor,{nature:'D',macro:t.macroclasse,institution:t.instituicao,category:t.categoria_vigente,status:t.identificacao_fluxo});
   });
 }
 const rows=Object.values(links); const labels=unique(rows.flatMap(r=>[r.source,r.target])); const idx=Object.fromEntries(labels.map((l,i)=>[l,i]));
 const nodeColors=labels.map(l=>l.startsWith('Origem')?'#8eb6d5':l.startsWith('Entrada')?'#27649b':l.startsWith('Saída')?'#267d82':l.includes('não identificado')?'#a67a2d':l.includes('possível')?'#8b79bb':'#b9c9d7');
 return{tx,rows,labels,trace:{type:'sankey',arrangement:'snap',node:{label:labels,color:nodeColors,pad:18,thickness:18,line:{color:'#fff',width:1},hovertemplate:'%{label}<br>Valor: R$ %{value:,.2f}<extra></extra>'},link:{source:rows.map(r=>idx[r.source]),target:rows.map(r=>idx[r.target]),value:rows.map(r=>r.value),color:rows.map(r=>r.target.includes('não identificado')?'rgba(166,122,45,.35)':r.target.includes('possível')?'rgba(101,82,164,.28)':'rgba(39,100,155,.22)'),customdata:rows.map(r=>JSON.stringify(r.meta)),hovertemplate:'%{source.label} → %{target.label}<br>R$ %{value:,.2f}<extra></extra>'}}};
}
function renderSankey(){
 const built=buildSankey();
 if(!built.rows.length){byId('sankey-chart').innerHTML='<div class="fin-chart-empty">Não há movimentações para esta combinação de filtros e controles.</div>';return;}
 Plotly.react('sankey-chart',[built.trace],{height:430,margin:{l:10,r:10,t:18,b:18},font:{family:'Inter,Segoe UI,Arial',size:11,color:'#31465a'},paper_bgcolor:'rgba(0,0,0,0)'},{responsive:true,displayModeBar:false});
 const el=byId('sankey-chart'); el.removeAllListeners&&el.removeAllListeners('plotly_click');
 el.on('plotly_click',ev=>{
  const p=ev.points[0]; const label=p.label||p.source?.label||p.target?.label||'Seleção do fluxo';
  let selection={label};
  const inst=String(label).match(/Instituição\s+(\d+)/); if(inst)selection.institution=inst[1];
  const macro=String(label).match(/(?:Origem · |Destino · )(\d+) ·/); if(macro)selection.macro=macro[1];
  if(label.startsWith('Destino · ')&&!macro)selection.category=label.replace('Destino · ','');
  openTransactions(selection);
 });
 const a=aggregate();
 byId('flow-identified').textContent=fmtMoney.format(a.internal);
 byId('flow-possible').textContent=fmtMoney.format(a.possible);
 byId('flow-unknown').textContent=fmtMoney.format(a.unknown);
 const total=a.entries+a.exits; const internalShare=total?a.internal*2/total*100:0;
 byId('flow-insight-title').textContent=state.base==='ajustada'?'A base ajustada reduz a circulação interna confirmada':'A base bruta inclui a circulação entre contas';
 byId('flow-insight-copy').textContent=`Foram identificados ${fmtMoney.format(a.internal)} em saídas internas com contraparte pareada. Na base ajustada, as duas pontas desses pares são neutralizadas; ${fmtMoney.format(a.possible)} em possíveis transferências permanecem nos totais.`;
 byId('flow-next-copy').textContent=a.unknown>0?'Aprofundar as categorias ou instituições que concentram o valor sem destino compreendido.':'Comparar categorias e macroclassificações por instituição.';
}
function concentrationRows(){
 const nature=state.concentration.nature;
 const tx=baseTransactions(state.base,{ignoreNature:true}).filter(t=>t.natureza===nature);
 const total=sum(tx); const map={};
 tx.forEach(t=>{
   const dim=state.concentration.dimension==='categoria'?t.categoria_vigente:`${t.macroclasse} · ${t.macroclasse_nome}`;
   const inst=state.concentration.group==='instituicao'?String(t.instituicao):'Consolidado';
   const key=`${dim}|||${inst}`; if(!map[key])map[key]={dim,inst,value:0,count:0,unknown:0};
   map[key].value+=t.valor; map[key].count+=1; if([0,5].includes(t.macroclasse))map[key].unknown+=t.valor;
 });
 return Object.values(map).map(r=>({...r,share:total?r.value/total*100:0})).sort((a,b)=>b.value-a.value);
}
function renderConcentration(){
 const rows=concentrationRows(); const topDims=unique(rows.map(r=>r.dim)).slice(0,12); const shown=rows.filter(r=>topDims.includes(r.dim));
 const metric=state.concentration.metric; const metricValue=r=>metric==='quantidade'?r.count:metric==='participacao'?r.share:r.value;
 const traces=[];
 if(state.concentration.group==='instituicao'){
  unique(shown.map(r=>r.inst)).sort().forEach((inst,i)=>traces.push({type:'bar',orientation:'h',name:`Instituição ${inst}`,y:topDims,x:topDims.map(d=>metricValue(shown.find(r=>r.dim===d&&r.inst===inst)||{value:0,count:0,share:0})),customdata:topDims.map(d=>JSON.stringify({dim:d,inst})),hovertemplate:`%{y}<br>Instituição ${inst}<br>${metric==='valor'?'R$ %{x:,.2f}':metric==='participacao'?'%{x:.1f}%':'%{x} movimentações'}<extra></extra>`,marker:{color:['#27649b','#267d82','#6552a4','#9b6a19'][i%4]}}));
 }else{
  const consolidated=topDims.map(dim=>shown.filter(r=>r.dim===dim).reduce((a,r)=>({dim,value:a.value+r.value,count:a.count+r.count,share:a.share+r.share}),{value:0,count:0,share:0}));
  traces.push({type:'bar',orientation:'h',name:'Consolidado',y:topDims,x:consolidated.map(metricValue),customdata:consolidated.map(r=>JSON.stringify({dim:r.dim})),hovertemplate:`%{y}<br>${metric==='valor'?'R$ %{x:,.2f}':metric==='participacao'?'%{x:.1f}%':'%{x} movimentações'}<extra></extra>`,marker:{color:'#27649b'}});
 }
 Plotly.react('concentration-chart',traces,{height:430,margin:{l:170,r:20,t:22,b:42},barmode:'stack',paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{family:'Inter,Segoe UI,Arial',size:10,color:'#43566b'},legend:{orientation:'h',y:1.1},yaxis:{autorange:'reversed'},xaxis:{gridcolor:'#edf1f4',ticksuffix:metric==='participacao'?'%':'',tickprefix:metric==='valor'?'R$ ':''}},{responsive:true,displayModeBar:false});
 const chart=byId('concentration-chart'); chart.removeAllListeners&&chart.removeAllListeners('plotly_click'); chart.on('plotly_click',ev=>{const d=JSON.parse(ev.points[0].customdata);openTransactions({label:d.dim,dimension:state.concentration.dimension,value:d.dim,institution:d.inst});});
 renderConcentrationTable(rows);
 if(rows.length){const top=rows[0];byId('concentration-insight-title').textContent=`${top.dim} é a maior concentração`;byId('concentration-insight-copy').textContent=`A dimensão selecionada soma ${fmtMoney.format(top.value)} e representa ${pct(top.share)} das ${state.concentration.nature==='D'?'saídas':'entradas'} observadas${top.inst!=='Consolidado'?` na Instituição ${top.inst}`:''}.`;byId('concentration-next-action').dataset.dimension=top.dim;byId('concentration-next-action').dataset.institution=top.inst;}
}
function renderConcentrationTable(rows){
 byId('concentration-table-title').textContent=state.concentration.dimension==='categoria'?'Categorias oficiais':'Macroclassificações Raio-X 0–9';
 byId('concentration-table-copy').textContent=state.concentration.dimension==='categoria'?'Categoria vigente como padrão; a original permanece no detalhe.':'Classificação derivada da categoria original e da natureza contábil.';
 byId('concentration-table-body').innerHTML=rows.slice(0,15).map(r=>`<tr><td><strong>${esc(r.dim)}</strong><small>${state.concentration.dimension==='categoria'?'Categoria vigente':'Macroclassificação analítica'}</small></td><td>${r.inst==='Consolidado'?'—':`Código ${esc(r.inst)}`}</td><td class="fin-money">${fmtMoney.format(r.value)}</td><td>${pct(r.share)}</td><td>${fmtNumber.format(r.count)}</td><td><button type="button" class="fin-table-action" data-row-dim="${esc(r.dim)}" data-row-inst="${esc(r.inst)}">Ver transações</button></td></tr>`).join('')||'<tr><td colspan="6">Sem dados para a seleção.</td></tr>';
 all('[data-row-dim]').forEach(b=>b.addEventListener('click',()=>openTransactions({label:b.dataset.rowDim,dimension:state.concentration.dimension,value:b.dataset.rowDim,institution:b.dataset.rowInst})));
}
function renderClosing(){
 const a=aggregate(),ti=topInstitution(a.tx,'D');
 byId('closing-title').textContent=`${a.status} na base ${state.base}`;
 byId('closing-copy').textContent=`A diferença observada foi de ${fmtMoney.format(a.difference)}. ${ti?`A Instituição ${ti.code} concentrou ${pct(ti.share)} das saídas. `:''}${fmtMoney.format(a.internal)} em movimentação interna foi identificada e ${fmtMoney.format(a.unknown)} ainda precisa de compreensão adicional.`;
 byId('closing-list').innerHTML=`<div class="fin-closing-item"><strong>Principal fato</strong><p>${esc(a.status)} corresponde a ${pct(Math.abs(a.ratio*100))} das entradas da base ${state.base}.</p></div><div class="fin-closing-item"><strong>Limite da leitura</strong><p>O recorte não representa sozinho saldos, patrimônio, todas as dívidas ou toda a renda do cliente.</p></div><div class="fin-closing-item"><strong>Próximas investigações</strong><p>${a.unknown>0?'Revisar itens a identificar e possíveis transferências antes de ampliar interpretações.':'Aprofundar as concentrações por instituição e categoria.'}</p></div>`;
 byId('closing-investigate').dataset.institution=ti?ti.code:'';
}
function renderChips(){
 const f=state.filters; const chips=[];
 const add=(key,label,value,defaultValue='all')=>{if(value!==defaultValue&&value!==null&&value!=='')chips.push({key,label:`${label}: ${value}`})};
 add('period','Período',f.period==='all'?'all':`${f.period} meses`);add('institution','Instituição',f.institution);add('account','Conta',f.account);add('nature','Natureza',f.nature);add('identification','Identificação',f.identification);add('currentCategory','Categoria vigente',f.currentCategory);add('originalCategory','Categoria original',f.originalCategory);add('macro','Macroclasse',f.macro);add('product','Produto',f.product);if(f.minValue!==null)chips.push({key:'minValue',label:`Valor ≥ ${fmtMoney.format(f.minValue)}`});if(f.maxValue!==null)chips.push({key:'maxValue',label:`Valor ≤ ${fmtMoney.format(f.maxValue)}`});if(f.search)chips.push({key:'search',label:`Busca: ${f.search}`});
 byId('filter-chips').innerHTML=chips.length?chips.map(c=>`<span class="fin-chip">${esc(c.label)}<button type="button" data-remove-filter="${c.key}" aria-label="Remover filtro">×</button></span>`).join(''):'<span class="fin-chip">Nenhum filtro adicional ativo</span>';
 all('[data-remove-filter]').forEach(b=>b.addEventListener('click',()=>{const key=b.dataset.removeFilter;state.filters[key]=['minValue','maxValue','confidence'].includes(key)?null:key==='search'?'':'all';syncFilterControls();renderAll();}));
}
function populateFilters(){
 const setOptions=(id,vals,label=v=>v)=>{const el=byId(id);vals.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=label(v);el.appendChild(o)});};
 setOptions('filter-inst',DATA.config.instituicoes,v=>`Instituição ${v}`);setOptions('filter-account',DATA.config.contas);setOptions('adv-current-category',DATA.config.categorias_vigentes);setOptions('adv-original-category',DATA.config.categorias_originais);setOptions('adv-macro',Object.entries(DATA.classificacoes).map(([k,v])=>`${k}|${v}`),v=>{const [k,n]=v.split('|');return `${k} · ${n}`});Array.from(byId('adv-macro').options).slice(1).forEach(o=>o.value=o.value.split('|')[0]);setOptions('adv-product',DATA.config.produtos);
 byId('context-client').textContent=DATA.meta.cliente_codigo;byId('context-meta').textContent=`${DATA.meta.periodo} · dados simulados`;
}
function syncFilterControls(){
 const pairs={ 'filter-period':'period','filter-inst':'institution','filter-account':'account','filter-currency':'currency','filter-nature':'nature','filter-identification':'identification','adv-current-category':'currentCategory','adv-original-category':'originalCategory','adv-macro':'macro','adv-product':'product','adv-transfer':'transfer'};
 Object.entries(pairs).forEach(([id,key])=>{if(byId(id))byId(id).value=state.filters[key]??'all'});
 byId('adv-min-value').value=state.filters.minValue??'';byId('adv-max-value').value=state.filters.maxValue??'';byId('adv-confidence').value=state.filters.confidence===null?'':Math.round(state.filters.confidence*100);byId('adv-search').value=state.filters.search||'';
}
function readAdvancedFilters(){
 state.filters.currentCategory=byId('adv-current-category').value;state.filters.originalCategory=byId('adv-original-category').value;state.filters.macro=byId('adv-macro').value;state.filters.product=byId('adv-product').value;state.filters.transfer=byId('adv-transfer').value;state.filters.minValue=byId('adv-min-value').value===''?null:Number(byId('adv-min-value').value);state.filters.maxValue=byId('adv-max-value').value===''?null:Number(byId('adv-max-value').value);state.filters.confidence=byId('adv-confidence').value===''?null:Number(byId('adv-confidence').value)/100;state.filters.search=byId('adv-search').value.trim();
}
function resetFilters(){state.filters={period:'all',institution:'all',account:'all',currency:'BRL',nature:'all',identification:'all',currentCategory:'all',originalCategory:'all',macro:'all',product:'all',minValue:null,maxValue:null,transfer:'all',confidence:null,search:''};syncFilterControls();}
function selectionTransactions(selection=state.selection){
 let tx=filteredTransactions({ignoreNature:true}); if(!selection)return tx;
 if(selection.ids)tx=tx.filter(t=>selection.ids.includes(t.id));
 if(selection.institution&&selection.institution!=='Consolidado')tx=tx.filter(t=>String(t.instituicao)===String(selection.institution));
 if(selection.macro)tx=tx.filter(t=>String(t.macroclasse)===String(selection.macro));
 if(selection.dimension==='categoria'||selection.category)tx=tx.filter(t=>t.categoria_vigente===(selection.value||selection.category));
 if(selection.dimension==='macro')tx=tx.filter(t=>`${t.macroclasse} · ${t.macroclasse_nome}`===selection.value);
 if(selection.status)tx=tx.filter(t=>t.identificacao_fluxo===selection.status);
 if(selection.card==='entradas')tx=tx.filter(t=>t.natureza==='C');if(selection.card==='saidas')tx=tx.filter(t=>t.natureza==='D');if(selection.card==='internas')tx=tx.filter(t=>t.identificacao_fluxo==='IDENTIFICADA');if(selection.card==='identificar')tx=tx.filter(t=>[0,5].includes(t.macroclasse)&&t.identificacao_fluxo!=='IDENTIFICADA');
 return tx;
}
function openTransactions(selection){state.selection=selection||state.selection;renderTransactions();byId('tx-overlay').classList.add('is-open');setTimeout(()=>byId('tx-search').focus(),30)}
function renderTransactions(){
 const query=(byId('tx-search').value||'').toLowerCase();let tx=selectionTransactions();if(query)tx=tx.filter(t=>Object.values(t).join(' ').toLowerCase().includes(query));
 byId('tx-subtitle').textContent=state.selection?.label?`Seleção: ${state.selection.label}`:'Rastreabilidade do recorte atual.';
 byId('tx-summary').textContent=`${fmtNumber.format(tx.length)} movimentações · entradas ${fmtMoney.format(sum(tx,t=>t.natureza==='C'))} · saídas ${fmtMoney.format(sum(tx,t=>t.natureza==='D'))}`;
 byId('tx-table-body').innerHTML=tx.map(t=>`<tr><td>${esc(t.data.split('-').reverse().join('/'))}</td><td><strong>${esc(t.descricao_protegida)}</strong><small>${esc(t.id)} · ${esc(t.estado_movimentacao)}</small></td><td>Instituição ${esc(t.instituicao)}<small>${esc(t.conta)} · ${esc(t.produto)}</small></td><td>${esc(t.grupo_oficial)}</td><td>${esc(t.categoria_vigente)}</td><td>${esc(t.categoria_original)}</td><td><strong>${t.macroclasse} · ${esc(t.macroclasse_nome)}</strong><small>${esc(t.origem_categorizacao)}</small></td><td>${t.natureza==='C'?'Entrada':'Saída'}</td><td class="fin-money">${fmtMoney.format(t.valor)}</td><td>${esc(t.identificacao_fluxo.replaceAll('_',' '))}<small>${t.confianca_identificacao!==null?pct(t.confianca_identificacao*100):'Não aplicável'}</small></td></tr>`).join('')||'<tr><td colspan="10">Nenhuma movimentação encontrada.</td></tr>';
}
function cardInfo(card){
 const a=aggregate(); const map={entradas:{title:'Entradas observadas',value:a.entries,copy:'Soma dos valores com natureza de crédito na base e nos filtros atuais.',selection:{card:'entradas',label:'Entradas observadas'}},saidas:{title:'Saídas observadas',value:a.exits,copy:'Soma dos valores com natureza de débito na base e nos filtros atuais.',selection:{card:'saidas',label:'Saídas observadas'}},internas:{title:'Movimentação interna identificada',value:a.internal,copy:'Soma de uma ponta de cada par interno identificado. A base ajustada neutraliza crédito e débito pareados.',selection:{card:'internas',label:'Movimentações internas identificadas'}},identificar:{title:'Valor ainda a identificar',value:a.unknown,copy:`Entradas a identificar: ${fmtMoney.format(a.unknownEntry)}. Saídas a identificar: ${fmtMoney.format(a.unknownExit)}.`,selection:{card:'identificar',label:'Movimentações a identificar'}},resultado:{title:a.status,value:a.difference,copy:statusText(a),selection:{label:'Movimentações do resultado'}}};return map[card];
}
function openCardModal(card){
 const info=cardInfo(card); if(!info)return; state.modalCard=card; const tx=selectionTransactions(info.selection).sort((a,b)=>b.valor-a.valor);byId('card-modal-title').textContent=info.title;byId('card-modal-sub').textContent=`${fmtMoney.format(info.value)} · base ${state.base} · recorte filtrado`;byId('card-modal-body').innerHTML=`<div class="fin-smart-print"><div><h3>Como ler</h3><p>${esc(info.copy)}</p></div><div class="fin-smart-next"><strong>Próximo passo</strong><p>Abrir as movimentações que compõem este número.</p><button type="button" class="fin-btn teal" id="modal-open-all">Ver todas</button></div></div><div class="fin-related-table" style="margin-top:14px"><div class="fin-related-table-head"><h3>Maiores movimentações relacionadas</h3><p>Até cinco registros do recorte atual.</p></div><table><thead><tr><th>Data</th><th>Descrição</th><th>Instituição</th><th>Valor</th></tr></thead><tbody>${tx.slice(0,5).map(t=>`<tr><td>${t.data.split('-').reverse().join('/')}</td><td>${esc(t.descricao_protegida)}</td><td>Código ${t.instituicao}</td><td class="fin-money">${fmtMoney.format(t.valor)}</td></tr>`).join('')||'<tr><td colspan="4">Sem registros.</td></tr>'}</tbody></table></div>`;byId('card-modal').classList.add('is-open');setTimeout(()=>{const b=byId('modal-open-all');if(b)b.addEventListener('click',()=>{byId('card-modal').classList.remove('is-open');openTransactions(info.selection)})},0);
}
function renderRadar(){
 const r=DATA.radar; const available=r.fl_participa_radar==='S';byId('radar-eligibility-badge').textContent=available?'Participa do Radar':'Indisponível';byId('radar-eligibility-badge').classList.toggle('warn',!available);byId('radar-eligibility-title').textContent=available?'Resultado do Radar disponível no mock':'Resultado do Radar não calculável';byId('radar-eligibility-copy').textContent=available?`${r.cobertura}. Esta disponibilidade pertence ao contrato mockado e não altera os gates das lentes.`:r.motivo_indisponibilidade;
 const profiles=[['Perfil de renda',r.perfil_renda],['Macroperfil',r.macroperfil],['Microperfil',r.microperfil],['Perfil financeiro',r.perfil_financeiro]];byId('radar-profiles').innerHTML=profiles.map(([l,v])=>`<div class="fin-profile"><span>${l}</span><strong>${v?esc(v):'Dado não fornecido'}</strong></div>`).join('');
 const bo=r.resultado_orcamentario||{};byId('radar-budget-value').textContent=bo.valor===null||bo.valor===undefined?'Não calculável':`${bo.valor} ${bo.unidade||''}`;byId('radar-budget-copy').textContent=bo.descricao||bo.estado||'Dado não fornecido';
 if(!r.temas.length){byId('radar-themes-chart').innerHTML='<div class="fin-chart-empty">Os cinco temas não foram calculados porque a elegibilidade não foi atendida.</div>';byId('radar-theme-list').innerHTML='';byId('radar-theme-detail').innerHTML='<h3>Motivo</h3><p>Ausência de dados suficientes não equivale a pontuação zero.</p>';return}
 Plotly.react('radar-themes-chart',[{type:'bar',orientation:'h',y:r.temas.map(t=>t.nome),x:r.temas.map(t=>t.pontuacao),marker:{color:'#27649b'},customdata:r.temas.map(t=>t.id),hovertemplate:'%{y}<br>Pontuação simulada: %{x}<extra></extra>'}],{height:360,margin:{l:190,r:22,t:25,b:35},paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{family:'Inter,Segoe UI,Arial',size:10,color:'#43566b'},xaxis:{range:[0,100],gridcolor:'#edf1f4'},yaxis:{autorange:'reversed'}},{responsive:true,displayModeBar:false});
 const chart=byId('radar-themes-chart');chart.removeAllListeners&&chart.removeAllListeners('plotly_click');chart.on('plotly_click',ev=>selectTheme(ev.points[0].customdata));
 byId('radar-theme-list').innerHTML=r.temas.map(t=>`<button type="button" class="fin-theme-card ${state.selectedTheme===t.id?'is-selected':''}" data-theme="${t.id}"><span>Tema do Radar</span><strong>${esc(t.nome)}</strong><b class="fin-theme-score">${t.pontuacao}</b><small>${esc(t.cobertura)}</small></button>`).join('');all('[data-theme]').forEach(b=>b.addEventListener('click',()=>selectTheme(b.dataset.theme)));if(!state.selectedTheme)state.selectedTheme=r.temas[0].id;renderThemeDetail();
}
function selectTheme(id){state.selectedTheme=id;renderRadar();}
function renderThemeDetail(){const t=DATA.radar.temas.find(x=>x.id===state.selectedTheme)||DATA.radar.temas[0];if(!t)return;byId('radar-theme-detail').innerHTML=`<h3>${esc(t.nome)}</h3><p>${esc(t.limitacao)}</p><div class="fin-detail-facts"><div><span>Pontuação final</span><strong>${t.pontuacao??'Não calculável'}</strong></div><div><span>Percentual observado</span><strong>${t.percentual_observado===null?'Não fornecido':pct(t.percentual_observado)}</strong></div><div><span>Referência do contrato</span><strong>${t.percentual_referencia===null?'Não fornecida':pct(t.percentual_referencia)}</strong></div><div><span>Cobertura</span><strong>${esc(t.cobertura)}</strong></div></div><div class="fin-method"><strong>Como foi representado</strong><br>${esc(t.formula_status)} Os componentes abaixo pertencem somente a este tema.</div><table style="margin-top:12px"><thead><tr><th>Componente</th><th>Valor</th><th>Origem</th></tr></thead><tbody>${t.componentes.map(c=>`<tr><td>${esc(c.nome)}</td><td>${esc(c.valor)} ${esc(c.unidade)}</td><td>${esc(c.origem)}</td></tr>`).join('')}</tbody></table>`;}
function lensStatusClass(s){return s==='FUTURA'?'future':s.includes('INDISPONIVEL')||s.includes('RESSALVAS')?'warn':''}
function renderLensCatalog(){
 const groups={};DATA.lentes.forEach(l=>(groups[l.familia]||(groups[l.familia]=[])).push(l));byId('lens-catalog').innerHTML=Object.entries(groups).map(([family,lenses])=>`<div class="fin-lens-family">${esc(family)}</div>${lenses.map(l=>`<button type="button" class="fin-lens-card ${state.selectedLens===l.id?'is-selected':''}" data-lens="${l.id}"><strong>${esc(l.nome)}</strong><p>${esc(l.pergunta)}</p><span class="fin-lens-status ${lensStatusClass(l.estado)}">${esc(l.estado.replaceAll('_',' '))}</span></button>`).join('')}`).join('');all('[data-lens]').forEach(b=>b.addEventListener('click',()=>{state.selectedLens=b.dataset.lens;renderLenses()}));
}
function lensValue(v){if(v===null||v===undefined)return 'Não fornecido';if(typeof v==='number')return pct(v);if(typeof v==='string')return esc(v);if(Array.isArray(v))return esc(v.join(', '));if(typeof v==='object'){if('percentual'in v)return v.percentual===null?'Não calculável':pct(v.percentual);if('essenciais'in v)return `Essenciais ${v.essenciais}% · Flexíveis ${v.flexiveis}% · Futuro ${v.futuro}%`;if('sinais_observados'in v)return v.sinais_observados?'Sinais observados; razão não calculável':'Não calculável';return esc(JSON.stringify(v))}return esc(v)}
function renderLensChart(l){
 const id='lens-chart'; if(!byId(id))return;
 if(l.id==='clareza'&&l.realizado?.percentual!==null){Plotly.react(id,[{type:'bar',orientation:'h',name:'Realizado observado',y:['Clareza dos gastos'],x:[l.realizado.percentual],marker:{color:'#27649b'}},{type:'scatter',mode:'markers',name:'Referência candidata',y:['Clareza dos gastos'],x:[l.referencia.percentual],marker:{color:'#9b6a19',size:14,symbol:'diamond'}}],{height:260,barmode:'overlay',margin:{l:150,r:25,t:45,b:45},xaxis:{range:[0,100],ticksuffix:'%',gridcolor:'#edf1f4'},paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{family:'Inter,Segoe UI,Arial',size:10},legend:{orientation:'h',y:1.16}},{responsive:true,displayModeBar:false});}
 else if(l.id==='503020'&&!l.estado.includes('INDISPONIVEL')){const cats=['Essenciais','Flexíveis','Futuro','Sem finalidade'];Plotly.react(id,[{type:'bar',name:'Realizado',x:cats,y:[l.realizado.essenciais,l.realizado.flexiveis,l.realizado.futuro,l.realizado.sem_finalidade],marker:{color:'#27649b'}},{type:'bar',name:'Referência',x:cats,y:[l.referencia.essenciais,l.referencia.flexiveis,l.referencia.futuro,0],marker:{color:'#9b6a19'}},{type:'bar',name:'Plano do cliente',x:cats,y:[l.plano_cliente.essenciais,l.plano_cliente.flexiveis,l.plano_cliente.futuro,0],marker:{color:'#267d82'}}],{height:300,barmode:'group',margin:{l:45,r:15,t:40,b:55},yaxis:{ticksuffix:'%',gridcolor:'#edf1f4'},paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{family:'Inter,Segoe UI,Arial',size:10},legend:{orientation:'h',y:1.16}},{responsive:true,displayModeBar:false});}
 else{byId(id).innerHTML=`<div class="fin-chart-empty"><div><strong>${esc(l.estado.replaceAll('_',' '))}</strong><br>${esc(l.resumo_estado)}<br><small>Ausência de cálculo não é exibida como zero.</small></div></div>`;}
}
function renderLenses(){renderLensCatalog();const l=DATA.lentes.find(x=>x.id===state.selectedLens)||DATA.lentes[0];const statusClass=lensStatusClass(l.estado);byId('lens-detail').innerHTML=`<div class="fin-lens-head"><div><span class="fin-lens-status ${statusClass}">${esc(l.estado.replaceAll('_',' '))}</span><h2>${esc(l.nome)}</h2><p class="fin-lens-question">${esc(l.pergunta)}</p><div class="fin-lens-meta"><span>${esc(l.familia)}</span><span>Versão ${esc(l.versao)}</span><span>${esc(l.periodo)}</span><span>${esc(l.moeda)}</span></div></div></div><div class="fin-lens-triad"><div class="fin-triad-card"><span>Realizado</span><strong>${lensValue(l.realizado)}</strong><p>Observado ou calculado no snapshot, conforme cobertura.</p></div><div class="fin-triad-card"><span>Referência</span><strong>${lensValue(l.referencia)}</strong><p>${esc(l.origem_referencia)}</p></div><div class="fin-triad-card"><span>Plano do cliente</span><strong>${lensValue(l.plano_cliente)}</strong><p>Somente quando declarado ou planejado com proveniência.</p></div></div><div id="lens-chart" class="fin-lens-chart"></div><div class="fin-lens-info-grid"><div class="fin-info-box"><h3>Como calculamos</h3><ul>${l.como_calculamos.map(x=>`<li>${esc(x)}</li>`).join('')||'<li>Não aplicável nesta etapa.</li>'}</ul></div><div class="fin-info-box caution"><h3>Limitações e o que não concluir</h3><ul>${[...l.limitacoes,...l.interpretacoes_proibidas.map(x=>`Não concluir: ${x}`)].map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div><div class="fin-info-box"><h3>Perguntas para a conversa</h3><ul>${l.perguntas.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div><div class="fin-info-box"><h3>Cobertura e denominador</h3><ul><li>${esc(l.cobertura)}</li><li>${esc(l.denominador)}</li></ul></div></div><div class="fin-lens-actions"><button type="button" class="fin-btn" id="lens-evidence" ${l.evidencias_ids.length?'':'disabled'}>Ver evidências (${l.evidencias_ids.length})</button><button type="button" class="fin-btn soft" id="back-raiox">Voltar ao Raio-X</button></div><div class="fin-context-note"><label for="lens-context">Registro opcional de contextualização ou contestação</label><textarea id="lens-context" placeholder="Registre somente o que foi contextualizado ou contestado; não altere silenciosamente o observado.">${esc(state.lensRecords[l.id]?.text||'')}</textarea><div class="fin-context-note-actions"><button type="button" class="fin-btn" data-record-type="CONTEXTUALIZADA">Registrar contextualização</button><button type="button" class="fin-btn" data-record-type="CONTESTADA">Registrar contestação</button></div><div class="fin-context-feedback" id="lens-context-feedback">${state.lensRecords[l.id]?`Estado registrado nesta sessão: ${esc(state.lensRecords[l.id].type)}`:''}</div></div>`;renderLensChart(l);const evidence=byId('lens-evidence');if(evidence)evidence.addEventListener('click',()=>openTransactions({label:`Evidências — ${l.nome}`,ids:l.evidencias_ids}));byId('back-raiox').addEventListener('click',()=>switchProduct('raiox'));all('[data-record-type]').forEach(b=>b.addEventListener('click',()=>{state.lensRecords[l.id]={type:b.dataset.recordType,text:byId('lens-context').value};byId('lens-context-feedback').textContent=`Estado registrado nesta sessão: ${b.dataset.recordType}. O dado observado não foi alterado.`;}));}
function switchProduct(product,radarTab){state.product=product;if(radarTab)state.radarTab=radarTab;all('[data-product]').forEach(b=>b.classList.toggle('is-active',b.dataset.product===product));all('[data-product-panel]').forEach(p=>p.classList.toggle('is-active',p.dataset.productPanel===product));byId('page-title').textContent=product==='raiox'?'Raio-X financeiro':'Radar comportamental';byId('page-subtitle').textContent=product==='raiox'?'O que aconteceu com o dinheiro no recorte observado.':'Resultados do modelo existente e lentes independentes para a conversa.';all('[data-radar-tab]').forEach(b=>b.classList.toggle('is-active',b.dataset.radarTab===state.radarTab));all('[data-radar-view]').forEach(v=>v.classList.toggle('is-active',v.dataset.radarView===state.radarTab));if(product==='radar'){renderRadar();renderLenses();}window.scrollTo({top:0,behavior:'smooth'});}
function renderAll(){renderChips();renderHero();renderSankey();renderConcentration();renderClosing();renderRadar();renderLenses();}
function closeOverlay(id){byId(id).classList.remove('is-open')}
function setupEvents(){
 all('[data-product]').forEach(b=>b.addEventListener('click',()=>switchProduct(b.dataset.product)));
 all('[data-radar-tab]').forEach(b=>b.addEventListener('click',()=>{state.radarTab=b.dataset.radarTab;switchProduct('radar',state.radarTab)}));
 ['filter-period','filter-inst','filter-account','filter-currency','filter-nature','filter-identification'].forEach(id=>byId(id).addEventListener('change',e=>{const key={'filter-period':'period','filter-inst':'institution','filter-account':'account','filter-currency':'currency','filter-nature':'nature','filter-identification':'identification'}[id];state.filters[key]=e.target.value;renderAll();}));
 all('[data-base]').forEach(b=>b.addEventListener('click',()=>{state.base=b.dataset.base;renderAll()}));
 byId('flow-mode').addEventListener('change',e=>{state.flow.mode=e.target.value;renderSankey()});byId('flow-destination').addEventListener('change',e=>{state.flow.destination=e.target.value;renderSankey()});byId('flow-base').addEventListener('change',e=>{state.base=e.target.value;renderAll()});byId('flow-identification').addEventListener('change',e=>{state.flow.identification=e.target.value;renderSankey()});
 byId('concentration-dimension').addEventListener('change',e=>{state.concentration.dimension=e.target.value;renderConcentration()});byId('concentration-group').addEventListener('change',e=>{state.concentration.group=e.target.value;renderConcentration()});byId('concentration-metric').addEventListener('change',e=>{state.concentration.metric=e.target.value;renderConcentration()});byId('concentration-nature').addEventListener('change',e=>{state.concentration.nature=e.target.value;renderConcentration()});
 byId('expand-status').addEventListener('click',()=>{const el=byId('status-expanded');el.classList.toggle('is-open');byId('expand-status').textContent=el.classList.contains('is-open')?'Recolher evolução':'Expandir evolução';if(el.classList.contains('is-open'))Plotly.Plots.resize(byId('monthly-chart'))});
 all('[data-max-card]').forEach(b=>b.addEventListener('click',()=>openCardModal(b.dataset.maxCard)));all('[data-expand-card]').forEach(b=>b.addEventListener('click',()=>openCardModal(b.dataset.expandCard)));
 byId('close-card-modal').addEventListener('click',()=>byId('card-modal').classList.remove('is-open'));byId('card-modal').addEventListener('click',e=>{if(e.target===byId('card-modal'))byId('card-modal').classList.remove('is-open')});
 byId('open-filters').addEventListener('click',()=>{syncFilterControls();byId('filter-overlay').classList.add('is-open')});all('[data-close-overlay]').forEach(b=>b.addEventListener('click',()=>closeOverlay(b.dataset.closeOverlay)));all('.fin-overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('is-open')}));
 byId('apply-filters').addEventListener('click',()=>{readAdvancedFilters();closeOverlay('filter-overlay');renderAll()});byId('reset-filters').addEventListener('click',()=>{resetFilters();renderAll()});
 byId('tx-search').addEventListener('input',renderTransactions);byId('tx-clear-selection').addEventListener('click',()=>{state.selection=null;renderTransactions()});
 byId('compare-references').addEventListener('click',()=>switchProduct('radar','lentes'));byId('closing-references').addEventListener('click',()=>switchProduct('radar','lentes'));
 byId('hero-next-action').addEventListener('click',e=>{state.filters.institution=e.target.dataset.institution||'all';syncFilterControls();renderAll();byId('concentracao').scrollIntoView({behavior:'smooth'})});byId('flow-next-action').addEventListener('click',()=>byId('concentracao').scrollIntoView({behavior:'smooth'}));byId('concentration-next-action').addEventListener('click',e=>openTransactions({label:e.target.dataset.dimension,dimension:state.concentration.dimension,value:e.target.dataset.dimension,institution:e.target.dataset.institution}));byId('closing-investigate').addEventListener('click',e=>{state.filters.institution=e.target.dataset.institution||'all';syncFilterControls();renderAll();byId('concentracao').scrollIntoView({behavior:'smooth'})});byId('closing-unknown').addEventListener('click',()=>openTransactions({card:'identificar',label:'Movimentações a identificar'}));
 all('[data-flow-stat]').forEach(b=>b.addEventListener('click',()=>openTransactions({status:b.dataset.flowStat,label:b.querySelector('span').textContent})));
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){all('.fin-overlay.is-open').forEach(o=>o.classList.remove('is-open'));byId('card-modal').classList.remove('is-open')}});
}
populateFilters();syncFilterControls();setupEvents();renderAll();
if(state.product==='radar'){switchProduct('radar',state.radarTab);window.scrollTo({top:0,behavior:'auto'});}
})();
</script>
"""


def render_dashboard(data: dict[str, Any], *, full_html: bool = False, include_plotly: bool = True) -> str:
    """Renderiza o dashboard como fragmento ou documento HTML completo."""
    data_json = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    plotly = f"<script>{get_plotlyjs()}</script>" if include_plotly else ""
    content = Visual.aplicar_estilo() + plotly + _markup(data_json) + JAVASCRIPT
    if not full_html:
        return content
    title = "Raio-X financeiro e Radar comportamental — protótipo"
    return (
        "<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{title}</title></head><body>{content}</body></html>"
    )
