"""Entrada pública da experiência executada no Jupyter Notebook.

Não existe servidor web, React, Vue, Streamlit ou arquivos HTML/CSS separados.
O Python monta a experiência e a exibe com ``IPython.display.HTML``.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

from IPython.display import HTML, display

from .config import carregar_configuracao
from .domain import AreaRadarInicial, BaseInicial, ConsultaDashboard, ProdutoInicial
from .providers import DashboardProvider, MockDashboardProvider, listar_cenarios


class Visual:
    """Identidade visual compartilhada pelos dois dashboards."""

    @staticmethod
    def aplicar_estilo() -> str:
        return r"""
<style>
:root{
  --bg:#f3f6f9;--surface:#ffffff;--surface-2:#f8fafc;--ink:#172637;--muted:#66778b;
  --border:#dfe6ed;--border-strong:#c7d2dd;--navy:#17344f;--blue:#27649b;
  --blue-soft:#eaf2f8;--teal:#267d82;--teal-soft:#e8f4f3;--amber:#9b6a19;
  --amber-soft:#fff5df;--purple:#6552a4;--purple-soft:#f1eef9;--rose:#8d574e;
  --shadow:0 16px 44px rgba(23,52,79,.08);--radius:18px;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:#edf2f6;color:var(--ink);font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif}
button,select,input,textarea{font:inherit}
button{cursor:pointer}
button:focus-visible,select:focus-visible,input:focus-visible,textarea:focus-visible,summary:focus-visible{outline:3px solid rgba(39,100,155,.28);outline-offset:2px}
.fin-app{width:min(1500px,100%);margin:0 auto;padding:20px 24px 46px;background:var(--bg);min-height:100vh}
.fin-app h1,.fin-app h2,.fin-app h3,.fin-app h4,.fin-app p{margin:0}
.fin-topbar{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;padding:10px 2px 16px}
.fin-brand small{display:block;color:var(--blue);font-size:11px;font-weight:850;letter-spacing:.08em;text-transform:uppercase}
.fin-brand h1{margin-top:4px;font-size:clamp(24px,3vw,36px);line-height:1.08;letter-spacing:-.035em}
.fin-brand p{margin-top:7px;color:var(--muted);font-size:13px}
.fin-product-nav{display:flex;gap:5px;padding:5px;border:1px solid var(--border);border-radius:14px;background:var(--surface);box-shadow:0 6px 20px rgba(23,52,79,.04)}
.fin-product-nav button{border:0;border-radius:10px;background:transparent;padding:10px 15px;color:var(--muted);font-size:13px;font-weight:800;white-space:nowrap}
.fin-product-nav button.is-active{background:var(--navy);color:#fff}
.fin-context{position:sticky;top:0;z-index:50;display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 12px;border:1px solid var(--border);border-radius:15px;background:rgba(255,255,255,.96);backdrop-filter:blur(12px);box-shadow:0 8px 25px rgba(23,52,79,.06)}
.fin-context-label{display:flex;align-items:center;gap:8px;margin-right:6px;padding-right:12px;border-right:1px solid var(--border)}
.fin-context-label strong{font-size:13px}.fin-context-label small{display:block;color:var(--muted);font-size:10px}
.fin-control{display:flex;align-items:center;gap:6px;padding:0 4px}
.fin-control label{color:var(--muted);font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.04em}
.fin-control select{border:0;background:transparent;color:var(--ink);font-size:12px;font-weight:700;padding:7px 24px 7px 6px;max-width:190px}
.fin-context-actions{display:flex;gap:7px;margin-left:auto}
.fin-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:1px solid var(--border-strong);border-radius:11px;background:var(--surface);color:var(--ink);padding:9px 12px;font-size:12px;font-weight:800}
.fin-btn:hover{border-color:#9eb2c4;background:#fbfdff}.fin-btn.primary{border-color:var(--blue);background:var(--blue);color:#fff}.fin-btn.soft{border-color:#c9dceb;background:var(--blue-soft);color:var(--blue)}.fin-btn.teal{border-color:var(--teal);background:var(--teal);color:#fff}.fin-btn.ghost{border-color:transparent;background:transparent;color:var(--blue);padding:7px}.fin-btn:disabled{opacity:.48;cursor:not-allowed}
.fin-chips{display:flex;gap:6px;flex-wrap:wrap;margin:10px 2px 0;min-height:25px}
.fin-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 9px;border:1px solid var(--border);border-radius:999px;background:#fff;color:#516276;font-size:11px}.fin-chip button{border:0;background:transparent;color:var(--muted);padding:0;font-weight:900}
.fin-panel{display:none}.fin-panel.is-active{display:block}
.fin-section{margin-top:18px;padding:23px;border:1px solid var(--border);border-radius:var(--radius);background:var(--surface);box-shadow:var(--shadow)}
.fin-section-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px}
.fin-kicker{color:var(--blue);font-size:10px;font-weight:900;letter-spacing:.08em;text-transform:uppercase}
.fin-section-head h2{margin-top:4px;font-size:clamp(21px,2.2vw,28px);letter-spacing:-.025em}.fin-section-head p{margin-top:6px;color:var(--muted);font-size:13px;max-width:820px}
.fin-section-actions{display:flex;gap:7px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
.fin-segment{display:flex;gap:3px;padding:4px;border:1px solid var(--border);border-radius:11px;background:var(--surface-2)}
.fin-segment button{border:0;border-radius:8px;background:transparent;padding:7px 10px;color:var(--muted);font-size:11px;font-weight:800;white-space:nowrap}
.fin-segment button.is-active{background:var(--navy);color:#fff}
.fin-summary-grid{display:grid;grid-template-columns:minmax(340px,1.25fr) minmax(280px,.75fr);gap:14px}
.fin-status-card{position:relative;min-height:240px;padding:22px;border-radius:17px;background:var(--navy);color:#fff;overflow:hidden}
.fin-status-card:after{content:"";position:absolute;width:280px;height:280px;right:-120px;top:-130px;border-radius:50%;background:rgba(255,255,255,.06)}
.fin-status-top{position:relative;z-index:1;display:flex;justify-content:space-between;gap:12px}.fin-status-label{font-size:11px;font-weight:850;letter-spacing:.07em;text-transform:uppercase;color:#b9d5ec}.fin-status-tag{padding:6px 9px;border-radius:999px;background:rgba(255,255,255,.1);font-size:10px;font-weight:800}
.fin-status-title{position:relative;z-index:1;margin-top:17px;font-size:25px;font-weight:750;letter-spacing:-.025em}.fin-status-value{position:relative;z-index:1;margin-top:8px;font-size:clamp(34px,4vw,49px);line-height:1;font-weight:800;letter-spacing:-.045em}.fin-status-rate{position:relative;z-index:1;margin-top:8px;color:#c8dded;font-size:13px}.fin-status-copy{position:relative;z-index:1;margin-top:17px;max-width:680px;color:rgba(255,255,255,.78);font-size:13px;line-height:1.55}.fin-status-actions{position:relative;z-index:1;display:flex;gap:8px;margin-top:18px}.fin-status-actions .fin-btn{border-color:rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#fff}.fin-status-actions .fin-btn:hover{background:rgba(255,255,255,.14)}
.fin-status-expanded{display:none;position:relative;z-index:1;margin-top:18px;padding-top:15px;border-top:1px solid rgba(255,255,255,.15)}.fin-status-expanded.is-open{display:block}.fin-mini-chart{height:230px;background:#fff;border-radius:12px;padding:4px}
.fin-metric-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.fin-metric{position:relative;min-height:115px;padding:16px;border:1px solid var(--border);border-radius:14px;background:var(--surface-2);overflow:hidden}.fin-metric:before{content:"";position:absolute;left:0;top:15px;bottom:15px;width:3px;border-radius:3px;background:var(--blue)}.fin-metric[data-tone="teal"]:before{background:var(--teal)}.fin-metric[data-tone="amber"]:before{background:var(--amber)}.fin-metric[data-tone="purple"]:before{background:var(--purple)}
.fin-metric-label{display:flex;justify-content:space-between;gap:8px;margin-left:6px;color:var(--muted);font-size:11px;font-weight:750}.fin-metric-value{display:block;margin:8px 0 0 6px;font-size:24px;letter-spacing:-.035em}.fin-metric small{display:block;margin:6px 0 0 6px;color:var(--muted);font-size:10px;line-height:1.4}.fin-card-tools{position:absolute;right:8px;bottom:7px;display:flex;gap:3px}.fin-card-tools button{border:0;background:transparent;color:var(--blue);font-size:10px;font-weight:800;padding:5px}
.fin-coverage{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;padding:11px 13px;border:1px dashed var(--border-strong);border-radius:12px;background:#fbfcfe}.fin-coverage span{color:var(--muted);font-size:11px}.fin-coverage strong{color:var(--ink)}
.fin-smart-print{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(260px,.75fr);gap:14px;margin-top:14px;padding:16px;border-radius:14px;background:var(--blue-soft)}.fin-smart-print h3{font-size:16px}.fin-smart-print p{margin-top:6px;color:#41566b;font-size:12px;line-height:1.55}.fin-smart-next{padding:12px;border-radius:11px;background:var(--teal-soft)}.fin-smart-next strong{display:block;color:#315f63;font-size:11px}.fin-smart-next p{color:#44676a;font-size:11px}.fin-smart-next .fin-btn{margin-top:8px}
.fin-chart-card{border:1px solid var(--border);border-radius:15px;background:#fff;overflow:hidden}.fin-chart-toolbar{display:flex;align-items:flex-start;justify-content:space-between;gap:15px;padding:15px 16px;border-bottom:1px solid var(--border);background:#fbfcfd}.fin-chart-toolbar h3{font-size:17px}.fin-chart-toolbar p{margin-top:4px;color:var(--muted);font-size:11px}.fin-toolbar-controls{display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end}.fin-toolbar-controls label{display:flex;flex-direction:column;gap:3px;color:var(--muted);font-size:9px;font-weight:850;text-transform:uppercase;letter-spacing:.04em}.fin-toolbar-controls select{border:1px solid var(--border);border-radius:9px;background:#fff;padding:7px 25px 7px 8px;color:var(--ink);font-size:11px;font-weight:700}.fin-chart{min-height:410px;padding:6px}.fin-chart-empty{display:grid;place-items:center;min-height:330px;padding:30px;color:var(--muted);text-align:center}
.fin-flow-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:12px}.fin-flow-stat{padding:13px;border:1px solid var(--border);border-radius:12px;background:var(--surface-2)}.fin-flow-stat span,.fin-flow-stat strong,.fin-flow-stat small{display:block}.fin-flow-stat span{color:var(--muted);font-size:10px}.fin-flow-stat strong{margin-top:5px;font-size:19px}.fin-flow-stat small{margin-top:3px;color:var(--muted);font-size:10px}
.fin-concentration-grid{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(320px,.65fr);gap:14px}.fin-related-table{border:1px solid var(--border);border-radius:14px;overflow:hidden}.fin-related-table-head{padding:14px;border-bottom:1px solid var(--border);background:#fbfcfd}.fin-related-table-head h3{font-size:15px}.fin-related-table-head p{margin-top:4px;color:var(--muted);font-size:10px}.fin-table-scroll{max-height:430px;overflow:auto}
table{width:100%;border-collapse:collapse;font-size:11px;background:#fff}th{position:sticky;top:0;z-index:1;padding:10px 11px;background:#f1f5f8;color:#56677a;text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}td{padding:11px;border-top:1px solid #e8edf2;vertical-align:top}td strong{font-size:11px}td small{display:block;margin-top:3px;color:var(--muted);font-size:9px}.fin-money{white-space:nowrap;font-weight:800}.fin-table-action{border:0;background:transparent;color:var(--blue);font-size:10px;font-weight:850;padding:0;white-space:nowrap}
.fin-closing{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(300px,.75fr);gap:16px}.fin-closing-main{padding:21px;border-radius:15px;background:var(--navy);color:#fff}.fin-closing-main span{color:#b9d5ec;font-size:10px;font-weight:850;text-transform:uppercase;letter-spacing:.07em}.fin-closing-main h3{margin-top:7px;font-size:24px;letter-spacing:-.025em}.fin-closing-main p{margin-top:9px;color:rgba(255,255,255,.78);font-size:13px;line-height:1.55}.fin-closing-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}.fin-closing-actions .fin-btn{border-color:rgba(255,255,255,.18);background:rgba(255,255,255,.08);color:#fff}.fin-closing-list{display:flex;flex-direction:column;gap:9px}.fin-closing-item{padding:13px;border:1px solid var(--border);border-radius:12px;background:var(--surface-2)}.fin-closing-item strong{font-size:11px}.fin-closing-item p{margin-top:4px;color:var(--muted);font-size:11px;line-height:1.5}
.fin-radar-subnav{display:flex;gap:5px;width:max-content;max-width:100%;margin:18px 0 0;padding:5px;border:1px solid var(--border);border-radius:13px;background:#fff}.fin-radar-subnav button{border:0;border-radius:9px;background:transparent;padding:9px 13px;color:var(--muted);font-size:12px;font-weight:800}.fin-radar-subnav button.is-active{background:var(--blue-soft);color:var(--blue)}
.fin-radar-view{display:none}.fin-radar-view.is-active{display:block}.fin-sim-banner{display:flex;align-items:flex-start;gap:11px;margin-top:14px;padding:13px 15px;border:1px solid #ead7a5;border-radius:12px;background:var(--amber-soft)}.fin-sim-banner b{display:grid;place-items:center;min-width:25px;height:25px;border-radius:8px;background:#fff;color:var(--amber)}.fin-sim-banner strong{display:block;font-size:12px}.fin-sim-banner p{margin-top:3px;color:#6d5a32;font-size:11px;line-height:1.45}
.fin-radar-hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(320px,.8fr);gap:14px;margin-top:14px}.fin-eligibility{padding:19px;border:1px solid var(--border);border-radius:15px;background:#fff}.fin-eligibility-header{display:flex;justify-content:space-between;gap:10px}.fin-eligibility-header span{font-size:10px;color:var(--muted);text-transform:uppercase;font-weight:850}.fin-state-badge{display:inline-flex;align-items:center;padding:6px 9px;border-radius:999px;background:var(--teal-soft);color:var(--teal);font-size:10px;font-weight:850}.fin-state-badge.warn{background:var(--amber-soft);color:var(--amber)}.fin-eligibility h2{margin-top:10px;font-size:24px}.fin-eligibility p{margin-top:7px;color:var(--muted);font-size:12px;line-height:1.55}.fin-profile-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:15px}.fin-profile{padding:11px;border-radius:10px;background:var(--surface-2)}.fin-profile span{display:block;color:var(--muted);font-size:9px;text-transform:uppercase}.fin-profile strong{display:block;margin-top:4px;font-size:11px}
.fin-budget-result{padding:19px;border-radius:15px;background:var(--navy);color:#fff}.fin-budget-result span{color:#b9d5ec;font-size:10px;text-transform:uppercase;font-weight:850}.fin-budget-result strong{display:block;margin-top:9px;font-size:34px}.fin-budget-result p{margin-top:7px;color:rgba(255,255,255,.75);font-size:11px}.fin-budget-result small{display:block;margin-top:15px;padding-top:12px;border-top:1px solid rgba(255,255,255,.14);color:#c4d7e6;font-size:10px}
.fin-theme-grid{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(360px,.85fr);gap:14px;margin-top:14px}.fin-theme-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-top:10px}.fin-theme-card{position:relative;padding:14px;border:1px solid var(--border);border-radius:12px;background:var(--surface-2);text-align:left}.fin-theme-card:hover,.fin-theme-card.is-selected{border-color:#9cb8ce;background:#fff}.fin-theme-card span{color:var(--muted);font-size:9px}.fin-theme-card strong{display:block;margin-top:4px;font-size:13px}.fin-theme-score{position:absolute;right:12px;top:12px;font-size:20px!important;color:var(--navy)!important}.fin-theme-card small{display:block;margin-top:8px;color:var(--muted);font-size:9px}.fin-theme-detail{padding:16px;border:1px solid var(--border);border-radius:14px;background:#fff}.fin-theme-detail h3{font-size:17px}.fin-theme-detail>p{margin-top:6px;color:var(--muted);font-size:11px;line-height:1.5}.fin-detail-facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:12px}.fin-detail-facts div{padding:10px;border-radius:10px;background:var(--surface-2)}.fin-detail-facts span{display:block;color:var(--muted);font-size:9px}.fin-detail-facts strong{display:block;margin-top:4px;font-size:15px}.fin-method{margin-top:12px;padding:11px;border-radius:10px;background:var(--amber-soft);color:#665530;font-size:10px;line-height:1.5}
.fin-lens-shell{display:grid;grid-template-columns:330px minmax(0,1fr);gap:14px;margin-top:14px}.fin-lens-catalog{border:1px solid var(--border);border-radius:15px;background:#fff;overflow:hidden}.fin-lens-catalog-head{padding:15px;border-bottom:1px solid var(--border);background:#fbfcfd}.fin-lens-catalog-head h2{font-size:17px}.fin-lens-catalog-head p{margin-top:5px;color:var(--muted);font-size:10px}.fin-lens-groups{padding:9px}.fin-lens-family{margin:8px 6px 5px;color:var(--muted);font-size:9px;text-transform:uppercase;font-weight:900;letter-spacing:.06em}.fin-lens-card{display:block;width:100%;margin-top:5px;padding:12px;border:1px solid transparent;border-radius:11px;background:var(--surface-2);text-align:left}.fin-lens-card:hover,.fin-lens-card.is-selected{border-color:#9fb7ca;background:#fff}.fin-lens-card strong{display:block;font-size:12px}.fin-lens-card p{margin-top:4px;color:var(--muted);font-size:10px;line-height:1.4}.fin-lens-status{display:inline-flex;margin-top:7px;padding:4px 7px;border-radius:999px;background:var(--blue-soft);color:var(--blue);font-size:8px;font-weight:850;text-transform:uppercase}.fin-lens-status.warn{background:var(--amber-soft);color:var(--amber)}.fin-lens-status.future{background:#edf0f3;color:#738092}
.fin-lens-detail{min-width:0;padding:20px;border:1px solid var(--border);border-radius:15px;background:#fff}.fin-lens-head{display:flex;justify-content:space-between;gap:15px}.fin-lens-head h2{font-size:25px;letter-spacing:-.025em}.fin-lens-question{margin-top:7px!important;color:#3e5267;font-size:13px;line-height:1.5}.fin-lens-meta{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}.fin-lens-meta span{padding:5px 8px;border-radius:999px;background:var(--surface-2);border:1px solid var(--border);color:var(--muted);font-size:9px}.fin-lens-triad{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;margin-top:16px}.fin-triad-card{padding:14px;border:1px solid var(--border);border-radius:12px;background:var(--surface-2)}.fin-triad-card span{display:block;color:var(--muted);font-size:9px;text-transform:uppercase;font-weight:850}.fin-triad-card strong{display:block;margin-top:6px;font-size:18px}.fin-triad-card p{margin-top:5px;color:var(--muted);font-size:9px}.fin-lens-chart{min-height:300px;margin-top:13px;border:1px solid var(--border);border-radius:12px;padding:5px}.fin-lens-info-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:13px}.fin-info-box{padding:13px;border-radius:11px;background:var(--blue-soft)}.fin-info-box.caution{background:var(--amber-soft)}.fin-info-box h3{font-size:12px}.fin-info-box ul{margin:7px 0 0;padding-left:17px;color:#465a6e;font-size:10px}.fin-info-box li+li{margin-top:4px}.fin-lens-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px}.fin-context-note{margin-top:13px;padding:13px;border:1px dashed var(--border-strong);border-radius:11px}.fin-context-note label{display:block;color:var(--muted);font-size:10px;font-weight:800}.fin-context-note textarea{width:100%;min-height:74px;margin-top:6px;border:1px solid var(--border);border-radius:9px;padding:9px;resize:vertical}.fin-context-note-actions{display:flex;gap:7px;margin-top:7px}.fin-context-feedback{margin-top:6px;color:var(--teal);font-size:10px;min-height:15px}
.fin-overlay{display:none;position:fixed;inset:0;z-index:100;background:rgba(18,31,44,.38)}.fin-overlay.is-open{display:block}.fin-drawer{position:absolute;right:0;top:0;bottom:0;width:min(610px,94vw);padding:22px;background:#fff;box-shadow:-18px 0 55px rgba(18,31,44,.18);overflow:auto}.fin-drawer.wide{width:min(960px,96vw)}.fin-drawer-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:13px;border-bottom:1px solid var(--border)}.fin-drawer-head h2{font-size:23px}.fin-drawer-head p{margin-top:5px;color:var(--muted);font-size:11px}.fin-close{border:0;background:transparent;color:var(--muted);font-size:26px;line-height:1}.fin-filter-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:16px}.fin-filter-grid label{display:flex;flex-direction:column;gap:5px;color:var(--muted);font-size:10px;font-weight:800}.fin-filter-grid select,.fin-filter-grid input{width:100%;border:1px solid var(--border-strong);border-radius:10px;background:#fff;padding:10px}.fin-drawer-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:18px}.fin-tx-toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}.fin-tx-toolbar input{flex:1;min-width:220px;border:1px solid var(--border-strong);border-radius:10px;padding:9px 11px}.fin-tx-summary{margin-top:10px;color:var(--muted);font-size:10px}.fin-tx-table{min-width:1100px}.fin-tx-scroll{margin-top:10px;max-height:66vh;overflow:auto;border:1px solid var(--border);border-radius:12px}
.fin-modal-wrap{display:none;position:fixed;inset:0;z-index:120;align-items:center;justify-content:center;padding:20px;background:rgba(18,31,44,.45)}.fin-modal-wrap.is-open{display:flex}.fin-modal{width:min(880px,96vw);max-height:88vh;overflow:auto;padding:22px;border-radius:18px;background:#fff;box-shadow:0 30px 90px rgba(18,31,44,.3)}.fin-modal-head{display:flex;justify-content:space-between;gap:10px}.fin-modal h2{font-size:24px}.fin-modal-sub{margin-top:6px!important;color:var(--muted);font-size:11px}.fin-modal-body{margin-top:15px}
.fin-tooltip-note{margin-top:11px;color:var(--muted);font-size:10px;text-align:center}.fin-footer{padding:18px 4px 0;color:var(--muted);font-size:10px;text-align:center}
.fin-hidden{display:none!important}
@media(max-width:1100px){.fin-summary-grid,.fin-concentration-grid,.fin-closing,.fin-radar-hero,.fin-theme-grid{grid-template-columns:1fr}.fin-lens-shell{grid-template-columns:1fr}.fin-lens-catalog{max-height:none}.fin-theme-list{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:780px){.fin-app{padding:12px}.fin-topbar{flex-direction:column}.fin-product-nav{width:100%}.fin-product-nav button{flex:1}.fin-context{top:0;padding:8px}.fin-context-label{width:100%;border-right:0;border-bottom:1px solid var(--border);padding-bottom:7px}.fin-context-actions{width:100%;margin-left:0}.fin-context-actions .fin-btn{flex:1}.fin-control{width:calc(50% - 5px);flex-direction:column;align-items:flex-start}.fin-control select{width:100%;max-width:none}.fin-section{padding:16px}.fin-section-head,.fin-chart-toolbar{flex-direction:column}.fin-section-actions,.fin-toolbar-controls{justify-content:flex-start}.fin-summary-grid{grid-template-columns:1fr}.fin-metric-grid,.fin-flow-stats,.fin-lens-triad,.fin-lens-info-grid,.fin-profile-grid{grid-template-columns:1fr 1fr}.fin-smart-print{grid-template-columns:1fr}.fin-theme-list{grid-template-columns:1fr 1fr}.fin-filter-grid{grid-template-columns:1fr}.fin-chart{min-height:330px}}
@media(max-width:480px){.fin-metric-grid,.fin-flow-stats,.fin-lens-triad,.fin-lens-info-grid,.fin-profile-grid,.fin-theme-list{grid-template-columns:1fr}.fin-section{border-radius:14px}.fin-status-card{padding:18px}.fin-status-value{font-size:36px}.fin-segment{width:100%;overflow:auto}.fin-segment button{flex:1}.fin-toolbar-controls label{width:100%}.fin-toolbar-controls select{width:100%}}
</style>
"""


def _normalizar_cd_cli(cd_cli: str | int) -> str:
    valor = str(cd_cli).strip()
    if not valor:
        raise ValueError("cd_cli é obrigatório e não pode ser vazio.")
    return valor


def _normalizar_instituicoes(instituicoes: Iterable[int | str] | None) -> tuple[int, ...]:
    if not instituicoes:
        return ()
    try:
        return tuple(dict.fromkeys(int(item) for item in instituicoes))
    except (TypeError, ValueError) as exc:
        raise ValueError("instituicoes deve conter somente códigos inteiros.") from exc


def fluxo_dashboard(
    cd_cli: str | int,
    *,
    periodo_inicio: str | None = None,
    periodo_fim: str | None = None,
    moeda: str | None = None,
    instituicoes: Iterable[int | str] | None = None,
    produto_inicial: ProdutoInicial = "raio_x",
    area_radar_inicial: AreaRadarInicial = "resultado",
    base_inicial: BaseInicial = "ajustada",
    lente_inicial: str = "clareza",
    provider: DashboardProvider | None = None,
    cenario_mock: str | None = None,
    exibir: bool = True,
) -> dict[str, Any]:
    """Monta e opcionalmente exibe Raio-X e Radar no notebook.

    Parameters
    ----------
    cd_cli:
        Código do cliente. É o único argumento obrigatório.
    periodo_inicio, periodo_fim:
        Datas ISO ``AAAA-MM-DD`` que definem o escopo consultado.
    moeda:
        Moeda do recorte. Usa ``DASHBOARD_MOEDA_PADRAO`` quando omitida.
    instituicoes:
        Códigos de instituições que devem compor o escopo inicial.
    produto_inicial:
        ``"raio_x"`` ou ``"radar"``.
    area_radar_inicial:
        ``"resultado"`` ou ``"lentes"`` quando o Radar abrir primeiro.
    base_inicial:
        ``"ajustada"`` neutraliza somente transferências internas identificadas;
        ``"bruta"`` preserva todas as entradas e saídas observadas.
    lente_inicial:
        Identificador da lente inicialmente aberta no Radar.
    provider:
        Adapter de dados. Quando omitido, usa o provider mockado.
    cenario_mock:
        Cenário determinístico apenas para desenvolvimento. Em produção, o
        adapter real ignora este argumento.
    exibir:
        Quando verdadeiro, executa ``display(HTML(...))``.

    Returns
    -------
    dict
        Consulta normalizada, contratos carregados e HTML renderizado.
    """
    if produto_inicial not in {"raio_x", "radar"}:
        raise ValueError("produto_inicial deve ser 'raio_x' ou 'radar'.")
    if area_radar_inicial not in {"resultado", "lentes"}:
        raise ValueError("area_radar_inicial deve ser 'resultado' ou 'lentes'.")
    if base_inicial not in {"bruta", "ajustada"}:
        raise ValueError("base_inicial deve ser 'bruta' ou 'ajustada'.")
    if periodo_inicio and periodo_fim and periodo_inicio > periodo_fim:
        raise ValueError("periodo_inicio não pode ser posterior a periodo_fim.")

    config = carregar_configuracao()
    consulta = ConsultaDashboard(
        cd_cli=_normalizar_cd_cli(cd_cli),
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
        moeda=(moeda or config.moeda_padrao).upper(),
        instituicoes=_normalizar_instituicoes(instituicoes),
    )

    if provider is None:
        if config.provider != "mock":
            raise RuntimeError(
                "O provider configurado não está instalado. Injete um DashboardProvider "
                "produtivo em fluxo_dashboard(provider=...)."
            )
        provider = MockDashboardProvider()

    dados = provider.carregar(
        consulta,
        cenario_mock=cenario_mock or config.cenario_mock,
    )
    dados.setdefault("meta", {})["limiar_equilibrio_pct"] = config.limiar_equilibrio_pct
    dados["ui"] = {
        "produto_inicial": produto_inicial,
        "area_radar_inicial": area_radar_inicial,
        "base_inicial": base_inicial,
        "lente_inicial": lente_inicial,
    }

    # Importação tardia evita dependência circular: renderer usa Visual desta classe.
    from .renderer import render_dashboard

    html = render_dashboard(
        dados,
        full_html=False,
        include_plotly=config.incluir_plotly_offline,
    )
    if exibir:
        display(HTML(html))

    return {
        "cd_cli": consulta.cd_cli,
        "consulta": consulta.to_dict(),
        "provider": provider.__class__.__name__,
        "dados": dados,
        "html": html,
    }


def gerar_preview(
    cd_cli: str | int,
    destino: str | Path = "preview.html",
    **kwargs: Any,
) -> Path:
    """Exporta uma cópia HTML autônoma usando a mesma função do notebook."""
    kwargs["exibir"] = False
    resultado = fluxo_dashboard(cd_cli, **kwargs)
    from .renderer import render_dashboard

    output = Path(destino)
    output.write_text(
        render_dashboard(resultado["dados"], full_html=True, include_plotly=True),
        encoding="utf-8",
    )
    return output.resolve()


__all__ = ["Visual", "fluxo_dashboard", "gerar_preview", "listar_cenarios"]
