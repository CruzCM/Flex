# Relatório de alterações e validação local

**Registro da revisão anterior.** A distribuição gfp-jdbc-integrado-2 acrescenta seis verificações JDBC antes das leituras de negócio, inclusive em retomadas. As contagens e os resultados abaixo descrevem a revisão anterior. [Resultados da nova distribuição](Testes_Run_All.md)

## Mudança operacional

A execução padrão é HOMOLOGACAO. AMOSTRAL usa população fornecida, marcadores INTEGER para CD_CLI e a janela semiaberta em DT_TRAN. CENSITARIO e AUDITORIA mantêm a possibilidade de observar o universo integral mediante escolha explícita. Os recortes de amostra e de segmentos são identificados no pacote. Os resultados científicos e as regras do Radar continuam dependendo da análise posterior.

A versão anterior executava os 13 SQLs separadamente para toda a população da janela. Nesta versão, ao solicitar todas as saídas em um lote amostral, o plano contém **nove instruções JDBC**: dois cadastros, uma cobertura de clientes, uma base compartilhada e cinco consultas específicas. Cada lote adicional executa sete instruções. A base compartilhada atende seis saídas. Esse é o número de comandos planejados; o número de acessos físicos e o custo de cada um dependem do plano do Db2. O experimento de partição e as leituras independentes de auditoria acrescentam operações. [Plano JDBC completo para conferência](../03_CONSULTAS/03_OTIMIZADAS/Plano_amostral_1_cliente.sql)

O driver consolida os agregados em SQLite temporário com soma decimal, agrega datas por mínimo/máximo e preserva a linha de controle da Q00 no vazio. Cada consulta ou lote pode falhar independentemente. A tentativa publica um pacote de diagnóstico mesmo quando não há CSV de negócio. As unidades concluídas ficam no HDFS para retomada. O inventário do ZIP passou a refletir o modo, a seleção, a auditoria e os resultados disponíveis. A verificação de CRC, tamanhos e SHA-256 continua delegada ao gerenciador HDFS.

## Evidências executadas nesta revisão

Comando a partir da raiz do projeto:

```powershell
python -B -X utf8 -m unittest discover -s tests -v
```

**20 testes aprovados.** A suíte executa as células locais e a chamada remota do notebook com transporte simulado, utiliza o código da V3 para configurar a conexão e usa JDBC, BBMagic e HDFS simulados. Os SQLs parametrizados são executados em SQLite com dados sintéticos e adaptações das funções do Db2. Os arquivos ZIP e os hashes são reais no filesystem local. A checagem estática com Ruff também passou.

| Verificação | Resultado observado |
|---|---|
| Intervalos e seleção | Janelas de 1, 2, 5, 7, 15, 30, 31 e 366 dias. Datas inválidas, ordem e dias futuros rejeitados. Todas as 13 consultas puderam ser selecionadas individualmente |
| Equivalência | As 13 saídas concordaram com as referências independentes na auditoria de dois lotes. Os dez controles cruzados passaram. A base vazia retornou a linha de Q00 com zero e datas observadas nulas |
| Isolamento de falhas | Recusa de somente leitura impediu SQL. Falha de abertura e perda da conexão produziram diagnóstico sanitizado. A próxima consulta usou nova conexão. Statements e conexões foram fechados |
| Timeout, interrupção e orçamento | Situações distintas registradas. O orçamento esgotado antes do primeiro lote impediu a abertura da conexão. A interrupção produziu diagnóstico |
| Recuperação | Na repetição de uma execução completa, zero SQLs foram executados. Após falha de Q05, apenas a unidade ausente foi reexecutada. Alterar população impediu reutilização. A troca de dois checkpoints válidos foi detectada |
| Precisão e granularidade | A soma decimal preservou centavos em valor de 31 dígitos. A simulação de bordas conferiu os derivados internos e externos na Q08. Grupos com indicadores nulos participaram da auditoria |
| Chaves textuais e cadastros | Valores de agrupamento que diferiam apenas em espaços finais consolidaram na mesma linha entre lotes. O cadastro manteve a ordenação numérica de chaves. [Comparação de strings no Db2 13](https://www.ibm.com/docs/en/db2-for-zos/13.0.0?topic=comparison-string-comparisons) |
| Censo e fórmula experimental | O censo exigiu autorização. O filtro do segmento na Q08 atingiu apenas o original. Ao deslocar duas linhas da partição prevista pela fórmula, a comparação divergiu e a Q00 ainda contou as seis transações do recorte |
| Privacidade e integridade | Identificador e segredo sintéticos ausentes de logs e arquivos exportados. Parâmetros privados e anexos de células adicionais foram eliminados da cópia do notebook. Inventário, CRC e SHA-256 conferidos |
| Notebook e download | Fluxo amostral percorreu transferência privada da lista, preparação, extração, limpeza da entrada, ZIP e download. O download de um pacote SEM_RESULTADOS também foi executado com sucesso na simulação |
| Preservação de fontes | Conferência por SHA-256 das células de conexão, dos gerenciadores corporativos e dos SQLs históricos antes e depois da alteração |

## Limites da evidência

Os tempos reais de conectividade e das consultas de um MCI e a falha anterior de Q00 foram informados pela equipe e constam da documentação consolidada. Esta revisão não executou SQL no DSN13018. Os testes locais comprovam os comportamentos exercitados com os dados sintéticos. Permanecem para homologação o plano de acesso dos marcadores no JCC 4.19.26, o custo de combinação das dimensões, o comportamento de timeout sob carga, o volume e espaço no driver, a publicação no HDFS e o transporte BBMagic desta revisão. A equivalência em produção requer confronto pareado na mesma população e janela. [Roteiro, métricas e arquivos de implantação](Operacao_Estudo_Otimizado.md)

