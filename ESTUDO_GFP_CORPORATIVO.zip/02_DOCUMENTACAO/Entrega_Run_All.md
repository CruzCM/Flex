# Instalação e execução da revisão gfp-jdbc-integrado-2

Extraia o ZIP de distribuição na raiz do projeto autorizado do JupyterLab, mantendo a estrutura de diretórios. O arquivo `Inventario.json` deve ficar ao lado de `ESTUDO_RADAR.ipynb`. Em instalações com fontes documentais originais, conserve esses originais. As cópias de referência de `tran.txt` e do modelo ERwin incluídas na distribuição ocultam identificadores desnecessários. A execução precisa apenas do notebook, do inventário, dos utilitários em `src/utils` e das três pastas de SQL principais, complementares e otimizados.

Abra `ESTUDO_RADAR.ipynb` e clique em **Run All**. A configuração distribuída executa o modo HOMOLOGACAO com o último dia civil completo, timeout de 30 segundos para transações e cadastros e orçamento de 120 segundos. A publicação e a transferência continuam após o encerramento do trabalho JDBC. O recibo final informa situação funcional, publicação, caminho HDFS, caminho no JupyterLab e SHA-256 da cópia verificada.

Para a primeira leitura real, selecione AMOSTRAL e informe a lista autorizada de MCIs ou um arquivo local com um MCI por linha. Q00, Q02, Q03 e Q04 já estão selecionadas. Após as seis sondas, cada lote faz uma consulta de cobertura e uma leitura agregada compartilhada. A janela aceita um dia ou qualquer intervalo positivo validado. Amplie até sete dias conforme o desempenho observado. O processamento é sequencial. O censo, a retomada e o experimento de partição exigem configuração explícita. [Matriz, controles e roteiro incremental](Operacao_Estudo_Otimizado.md)

## O que o Run All verifica

| Etapa | Evidência que aparece no notebook ou no pacote |
|---|---|
| Instalação | Hashes do módulo, gerenciadores e modelos SQL. Revisão e sequência das células fixas. Os parâmetros podem ser editados. |
| Conexão | Versões informadas pelo Spark, V3, servidor e JCC. A V3 aplica os setters JDBC. O estudo lê de volta somente leitura, autocommit e isolamento 2 em cada conexão. |
| Execução JDBC | SELECT simples, DATE bissexta, DECIMAL com 31 dígitos, CTE simples, CAST de um marcador INTEGER e CTE integrada de data e decimal. Cada sonda confere o resultado e a cardinalidade. |
| Preparação | Em HOMOLOGACAO, os 13 SQLs de origem e os modelos do plano passam pela triagem. As sondas consultam apenas SYSIBM.SYSDUMMY1. |
| Extração | Os eventos vinculam lote, operação, SQL sem valores vinculados, mecanismo, número de marcadores, duração, linhas lidas e estado. Uma falha na pré-validação impede a extração. |
| Publicação | O ZIP contém o inventário dos arquivos produzidos, os eventos e os controles disponíveis. A limpeza dos avulsos ocorre após a confirmação do gerenciador HDFS. |
| Download | BBMagic transfere o ZIP para arquivo temporário e o notebook compara o SHA-256 antes de publicar a cópia local. O recibo privado ao lado do ZIP registra a confirmação posterior à transferência. |

O artefato de execução contém `Execucao.json`, `Manifesto_Execucao.md`, as fontes disponíveis e os resultados da tentativa. O hash do próprio ZIP e o caminho realmente baixado só existem depois do fechamento e da transferência. O recibo `.recibo.json` e a saída final do notebook registram esses dados. A publicação de diagnóstico depende do funcionamento da sessão Spark e do HDFS. O download depende do BBMagic autenticado, da conexão com o JupyterLab e de espaço para a cópia local. Uma falha de transporte conserva o ZIP já publicado.

## Investigação do SQLCODE -104

**Evidência corporativa informada pela equipe.** A execução integrada anterior falhou em 0,346 s com 42601/-104. O HDFS publicou o diagnóstico e o JupyterLab confirmou o hash. Os dez testes isolados passaram em 0,629 s, inclusive a CTE. O token rejeitado permaneceu desconhecido.

**Constatação no código anterior.** A CTE sintética não tinha marcadores. Nessa operação a V3 usava `Statement.executeQuery(sql)` por meio de `blocos_nativos`. O checkpoint registrava o SQL do planejamento, antes da normalização interna da V3. O SQL continha os argumentos numéricos adjacentes `,31,2`. Há uma ambiguidade documentada quando o Db2 interpreta a vírgula como separador decimal. A IBM documenta o uso de espaços para desambiguar separadores. [IBM APAR PP45785](https://www.ibm.com/support/pages/node/6424467) · [Referência SQL do Db2 13](https://www.ibm.com/docs/en/SSEPEK_13.0.0/pdf/db2z_13_sqlrefbook.pdf)

**Correção entregue.** O estudo normaliza os separadores fora de literais e identificadores delimitados, confere a aridade e o tipo dos marcadores, arquiva o texto efetivo sem acrescentar caracteres e registra seu SHA-256. As consultas parametrizadas usam `setInt` seguido de `PreparedStatement.executeQuery()`. Os valores dos clientes ficam fora do texto SQL. O notebook verifica a revisão das dependências antes de liberar a extração.

**Atribuição histórica pendente.** O ZIP anterior encontra-se no projeto corporativo. A primeira execução verifica automaticamente o arquivo indicado pela equipe na raiz do JupyterLab e confere o SHA-256 fornecido. Ela lê os três componentes históricos e registra a correspondência do SQL, do erro e do manifesto. Se o texto for o sintético conhecido, a homologação compara a forma corrigida e a anterior na mesma conexão, dentro do orçamento. A instrução de comparação vem de uma constante revisada. Se apenas a forma anterior reproduzir 42601/-104, o resultado demonstra a diferença de sintaxe nessa sessão. Se ambas passarem, o manifesto conserva a causa histórica como inconclusiva. A versão local não teve acesso ao ZIP corporativo nem aos atributos de configuração do subsistema.

## Arquivos e dependências

O inventário relaciona os caminhos exatos e os hashes de todos os componentes distribuídos, com exceção do próprio inventário. Para executar a revisão sobre uma instalação anterior, atualize o notebook, `src/utils/estudo_indicadores_gfp.py` e instale `Inventario.json` juntos. Os gerenciadores e SQLs de origem incluídos correspondem aos hashes do inventário. A distribuição também contém o plano amostral de conferência, os SQLs otimizados, a documentação técnica, os testes e a ferramenta de empacotamento.

O ambiente fornece JupyterLab/IPython, Sparkmagic/Livy com exportação de DataFrame para o kernel local, BBMagic (o gerenciador local foi desenvolvido para 3.1.7), Spark/PySpark/Py4J, Hadoop/HDFS e IBM JCC no classpath. O perfil corporativo fornece as permissões e credenciais. O módulo de estudo e os testes usam a biblioteca padrão Python, inclusive SQLite e ZIP com deflate. A revisão não acrescenta pacotes ao ambiente. O Spark informado pela equipe é 3.5.4.7.3.2.0-957, o Db2 é DSN13018 e o JCC é 4.19.26.

O ingresso em AMOSTRAL depende do sucesso das validações e da autorização da população. A decisão sobre filtros depende da análise dos resultados do Db2. [Evidências dos testes desta distribuição](Testes_Run_All.md)

