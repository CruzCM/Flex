# Relatório de validação local da revisão gfp-jdbc-integrado-2

A suíte desta distribuição contém **23 testes automatizados**. O comando de reprodução a partir da raiz é `python -m unittest discover -s tests -v`. A equipe de desenvolvimento pode repeti-lo com Python e a biblioteca padrão. Para utilizar o estudo basta executar o notebook.

| Verificação | Resultado observado na simulação |
|---|---|
| SQL da homologação | Seis sondas concluídas. O texto recebido pelo Statement e pelo PreparedStatement coincidiu byte a byte com o arquivo SQL de cada operação. Hash e aridade conferidos. |
| Separadores e marcadores | Literais com apóstrofo duplicado, vírgulas e interrogações, identificador delimitado e comentário preservaram a contagem correta. Tipos e quantidades de marcadores incompatíveis foram rejeitados. |
| Contraste histórico | Com rejeição simulada da forma antiga foi registrado 42601/-104. Com aceitação das duas formas a comparação registrou o sucesso de ambas. O leitor histórico verificou ausência, digest divergente e arquivo de teste com digest válido. |
| Escopo e parâmetros | As 13 consultas passaram por seleção individual, preparação e triagem da V3. Q05 ficou sem placeholder. Q09 e Q10 disponíveis e Q12 fora do plano. Janelas de 1, 2, 5, 7, 15, 30 e 450 dias aceitas. Datas inválidas, ordem incorreta e dias futuros rejeitados. |
| Homologação sem extração | Nenhuma instrução contra DB2GFP foi enviada. Recusa de somente leitura, falha de abertura, erro de sintaxe na sonda, timeout e esgotamento do orçamento bloquearam o trabalho dependente. Os recursos JDBC abertos foram fechados. |
| Equivalência | Auditoria com dois lotes e transações sintéticas. As 13 saídas comparadas com as referências independentes tiveram resultado OK. Os dez controles cruzados passaram. Incluiu conta, cartão, categorização cadastral e um original dividido com derivado. |
| Consolidação | Verificação independente das quatro consultas do primeiro teste amostral, somas registradas e absolutas, nulos, limites de data, população e janela vazia. Q00 produziu uma linha de controle no vazio. Centavos preservados na sonda de 31 dígitos e na soma entre lotes. |
| Falha parcial e retomada | Perda de conexão durante uma leitura produziu pacote parcial. A unidade seguinte utilizou nova conexão. A retomada repetiu as sondas e apenas a leitura de negócio faltante. O total consolidado permaneceu exato. |
| Run All | Execução das células de código em ordem, com namespaces distintos para JupyterLab e driver. Casos de homologação, amostra, recusa JDBC, SQL de outra revisão, módulo ausente e transferência corrompida. A falha funcional publicou e baixou um ZIP de diagnóstico. Uma cópia corrompida foi rejeitada e o ZIP publicado permaneceu disponível. |
| Integridade | Conferidos CRC, relação exata dos arquivos no ZIP, digest do download e recibo. Identificador e segredo sentinelas ficaram fora dos logs e conteúdos exportados na falha simulada. |

**Como o teste funciona.** As células dos três gerenciadores corporativos são carregadas na ordem da distribuição. A V3 real abre, configura e fecha objetos JDBC simulados. As consultas da amostra rodam sobre tabelas SQLite de teste, com equivalentes locais para funções do Db2. Os testes monetários de 31 dígitos usam a representação textual do JDBC e Decimal. A simulação das magias executa o código remoto em namespace independente. A JVM, o serviço Spark, o cliente BBMagic e o armazenamento HDFS são substituídos por componentes locais de teste.

**Evidência corporativa disponível.** A equipe informou que as dez verificações isoladas passaram no ambiente real, e que o pacote da falha anterior foi publicado, baixado e verificado. A suíte acima corresponde à revisão entregue. A confirmação da causa histórica, o aceite do Run All no DSN13018, o plano de acesso por índice e o custo por lote dependem da execução corporativa. [Roteiro de homologação e métricas](Operacao_Estudo_Otimizado.md)

