"""Estudo pontual dos seis indicadores GFP. Executar pelo notebook no driver Spark."""

import csv
import json
import re
import sqlite3
from collections import Counter, defaultdict
from contextlib import closing
from datetime import date, timedelta
from decimal import Decimal, localcontext
from pathlib import Path
from tempfile import TemporaryDirectory
from time import perf_counter
from uuid import uuid4

PRINCIPAIS = ("Q00", "Q01", "Q01B", "Q02", "Q03", "Q04", "Q05", "Q06", "Q07", "Q08", "Q11")
COMPLEMENTARES = ("Q09", "Q10")
INDICADORES = ("IN_VSLO_CSM", "IN_VSLO_CX", "IN_VSLO_EVT", "IN_DVS_LCTO", "IN_OCTR_TRAN", "IN_TRAN_IR")
METRICAS = ("QT_TRAN", "VL_TOTAL", "VL_ABS")
CADASTROS = ("Q01", "Q01B")


ZERO = (0, Decimal(0), Decimal(0))
CENARIOS_Q04 = (
    "ORIGINAL",
    "CSM",
    "CX",
    "EVT",
    "DVS",
    "OCTR",
    "IR",
    "RADAR",
    "CSM_D",
    "GFP_EVT_INST",
    "GFP_CX_INST",
    "GFP_CSM_INST",
)
ISOLAMENTO = "READ_COMMITTED"
COLUNAS_RESTRITAS = re.compile(
    r"^(CD_CLI(?:_|$)|NR_CPF|CD_CPF|NR_TRAN_(?:INST|INCD|RLZD)|"
    r"(?:NR|CD|DV)_(?:AG|CT)_|(?:CD|NR)_IDFR_|TX_(?:CMPR_)?DCR_TRAN)"
)


class ErroValidacao(ValueError):
    """Validação com mensagem controlada para o manifesto."""


def validar_periodo(inicio, fim, spark=None):
    """Confere [início, fim) e, no driver, o último dia incluído pelo calendário da sessão."""
    if not all(
        isinstance(valor, str) and re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", valor)
        for valor in (inicio, fim)
    ):
        raise ErroValidacao("Informe as duas datas no formato AAAA-MM-DD.")
    try:
        primeiro_dia, fim_exclusivo = date.fromisoformat(inicio), date.fromisoformat(fim)
    except ValueError:
        raise ErroValidacao("Informe datas de calendário válidas no formato AAAA-MM-DD.") from None
    if primeiro_dia >= fim_exclusivo:
        raise ErroValidacao("A data inicial deve ser anterior à data final exclusiva.")
    if spark is not None:
        hoje = spark.sql("SELECT CURRENT_DATE() AS HOJE").first()[0]
        if fim_exclusivo - timedelta(days=1) > hoje:
            raise ErroValidacao("O período inclui um dia futuro segundo a data atual da sessão Spark.")


def preparar_consultas(pasta, inicio, fim):
    """Carrega as consultas previstas e parametriza seus limites."""
    validar_periodo(inicio, fim)
    consultas = {}
    for consulta in (*PRINCIPAIS, *COMPLEMENTARES, "BASE"):
        pasta_sql = "02_COMPLEMENTARES" if consulta in COMPLEMENTARES else "01_PRINCIPAIS"
        if consulta == "BASE":
            pasta_sql = "03_OTIMIZADAS"
        sql = (Path(pasta) / pasta_sql / f"{consulta}.sql").read_text(encoding="utf-8-sig")
        sql = re.sub(r"(?m)^--[^\n]*\n?", "", sql).strip()
        if sql.endswith(";"):
            sql = sql[:-1].rstrip()
        if not re.match(r"^(SELECT|WITH)\b", sql, re.I) or ";" in sql or re.search(r"\{[^}]*\}", sql):
            raise ValueError(f"{consulta} deve conter uma única consulta de leitura completa.")
        if consulta not in CADASTROS:
            for coluna, data in (("DT_INI", inicio), ("DT_FIM_EXCL", fim)):
                padrao = rf"DATE\('\d{{4}}-\d{{2}}-\d{{2}}'\)(\s+AS\s+{coluna}\b)"
                sql, substituicoes = re.subn(padrao, rf"DATE('{data}')\1", sql, flags=re.I)
                if substituicoes != 1:
                    raise ValueError(f"{consulta} precisa declarar exatamente um limite {coluna}.")
        consultas[consulta] = sql
    return consultas


def codificar_campo(valor):
    if valor is None:
        return r"\N"
    return "\\" + valor if valor.startswith("\\") else valor


def ler_metricas(linha):
    quantidade = int(linha["QT_TRAN"])
    total, absoluto = (Decimal(linha[campo]) for campo in METRICAS[1:])
    if quantidade < 0 or not total.is_finite() or not absoluto.is_finite() or absoluto < abs(total):
        raise ErroValidacao("Contagem ou valores agregados inválidos.")
    return quantidade, total, absoluto


def somar_metricas(primeiro, segundo):
    return tuple(a + b for a, b in zip(primeiro, segundo))


def acumular(grupos, chave, valores):
    grupos[chave] = somar_metricas(grupos.get(chave, (0,) * len(valores)), valores)


class ResumoConsulta:
    """Guarda somente os subtotais usados nos controles cruzados."""

    def __init__(self, consulta, inicio, fim):
        self.consulta = consulta
        self.inicio = inicio
        self.fim = fim
        self.linhas = 0
        self.total = ZERO
        self.produtos = {}
        self.combinacoes = {}
        self.cenarios = defaultdict(dict)
        self.divididos = Counter()
        self.chaves = set()
        self.fora_dominio = Counter()

    def adicionar(self, linha):
        self.linhas += 1
        consulta = self.consulta
        if consulta in ("Q01", "Q01B"):
            coluna = "CD_CTGR_TRAN" if consulta == "Q01" else "CD_GR_CTGR_TRAN"
            chave = linha[coluna]
            if chave is None or chave in self.chaves:
                raise ErroValidacao("Chave ausente ou repetida no cadastro.")
            self.chaves.add(chave)
            return

        if consulta == "Q08":
            chave = tuple(linha[c] for c in ("CD_PRD", "CD_NTZ_CTB_TRAN", *INDICADORES[:3]))
            quantidade = int(linha["QT_ORIGINAIS"])
            if quantidade < 1 or int(linha["QT_DERIVADOS"]) < 0:
                raise ErroValidacao("Contagem inválida de originais ou derivados.")
            self.divididos[chave] += quantidade
            return

        if consulta == "Q04":
            chave = linha["CD_PRD"], linha["CD_NTZ_CTB_TRAN"]
            if chave in self.cenarios:
                raise ErroValidacao("Produto e natureza repetidos na Q04.")
            cenarios = {
                nome: (int(linha[f"QT_{nome}"]), Decimal(linha[f"VL_ABS_{nome}"])) for nome in CENARIOS_Q04
            }
            qt_base, vl_base = cenarios["ORIGINAL"]
            if any(not (0 <= qt <= qt_base and 0 <= vl <= vl_base) for qt, vl in cenarios.values()):
                raise ErroValidacao("O resultado de um cenário da Q04 excede seu universo.")
            self.cenarios[chave] = cenarios
            return

        metricas = ler_metricas(linha)
        if consulta == "Q00":
            dias = (date.fromisoformat(self.fim) - date.fromisoformat(self.inicio)).days
            if (
                self.linhas != 1
                or linha["DT_INI"] != self.inicio
                or linha["DT_FIM_EXCL"] != self.fim
                or int(linha["QT_DIAS"]) != dias
            ):
                raise ErroValidacao("A Q00 deve retornar uma linha para a janela selecionada.")
            minimo, maximo = linha["DT_MIN_OBS"], linha["DT_MAX_OBS"]
            if metricas[0]:
                if not minimo or not maximo or not self.inicio <= minimo <= maximo < self.fim:
                    raise ErroValidacao("A Q00 retornou datas observadas fora da janela.")
            elif minimo is not None or maximo is not None or metricas != ZERO:
                raise ErroValidacao("A Q00 retornou medidas incompatíveis com janela vazia.")

        produto = linha.get("CD_PRD")
        if consulta == "Q10" and (
            produto not in ("6", "9")
            or linha["CD_EST_TRAN_INST"] != "0"
            or (linha["CD_TIP_MOE_CRR"] or "").rstrip() != "BRL"
        ):
            return
        self.total = somar_metricas(self.total, metricas)
        if consulta in ("Q02", "Q03", "Q10"):
            indicadores = tuple(linha[nome] for nome in INDICADORES)
            acumular(self.combinacoes, indicadores, metricas)
        if consulta == "Q02":
            for nome, valor in zip(INDICADORES, indicadores):
                if valor not in ("S", "N"):
                    self.fora_dominio[nome] += metricas[0]
        if consulta == "Q03":
            acumular(self.produtos, produto, metricas)
            natureza = linha["CD_NTZ_CTB_TRAN"]
            csm, cx, evt, dvs, octr, ir = indicadores
            consumo_debito = natureza == "D" and csm == "S"
            condicoes = (
                True,
                csm == "S",
                cx == "S",
                evt == "S",
                dvs == "N",
                octr == "N",
                ir == "S",
                natureza == "C" or consumo_debito,
                consumo_debito,
                evt == "S" and dvs == "N",
                cx == "S" and dvs == "N",
                consumo_debito and dvs == "N",
            )
            grupo = self.cenarios[produto, natureza]
            for nome, condicao in zip(CENARIOS_Q04, condicoes):
                acumular(grupo, nome, (metricas[0], metricas[2]) if condicao else (0, Decimal(0)))
            if dvs == "S":
                self.divididos[produto, natureza, csm, cx, evt] += metricas[0]
        if (consulta == "Q05" and produto != "9") or (consulta == "Q06" and produto != "6"):
            raise ErroValidacao("A consulta retornou produto fora de seu recorte.")


def verificar_resultados(resultados, consultas):
    verificacoes = []

    def conferir(nome, primeira, segunda, atributo, esperado=None):
        if primeira not in resultados or segunda not in resultados:
            verificacoes.append((nome, "PENDENTE"))
            return
        observado = getattr(resultados[primeira], atributo)
        comparavel = (
            getattr(resultados[segunda], atributo) if esperado is None else esperado(resultados[segunda])
        )
        verificacoes.append((nome, "OK" if observado == comparavel else "DIVERGÊNCIA"))

    conferir("Q00 × Q02 em quantidade, valor registrado e valor absoluto", "Q00", "Q02", "total")
    conferir("Q00 × Q03 em quantidade, valor registrado e valor absoluto", "Q00", "Q03", "total")
    conferir("Q02 × Q03 por combinação dos seis indicadores", "Q02", "Q03", "combinacoes")
    conferir("Q04 × Q03 por produto, natureza e cenário de retenção", "Q04", "Q03", "cenarios")
    for consulta, produto in (("Q05", "9"), ("Q06", "6")):
        conferir(
            f"{consulta} × Q03 para produto {produto}",
            consulta,
            "Q03",
            "total",
            lambda resumo, prd=produto: resumo.produtos.get(prd, ZERO),
        )
    conferir(
        "Q08 × Q03 para originais divididos por produto, natureza e visibilidade",
        "Q08",
        "Q03",
        "divididos",
    )
    for consulta in ("Q09", "Q11"):
        if consulta in consultas:
            conferir(f"{consulta} × Q03 para o universo principal", consulta, "Q03", "total")
    if "Q10" in consultas:
        conferir(
            "Q10 × Q02 por combinação, no recorte BRL efetivado de produtos 6 e 9",
            "Q10",
            "Q02",
            "combinacoes",
        )
    return verificacoes


COMPARTILHADAS = ("Q00", "Q02", "Q03", "Q04", "Q09", "Q11")
BASE_Q03 = ("CD_PRD", "CD_NTZ_CTB_TRAN", "CD_TIP_TRAN", "CD_CTGR_TRAN", "CD_CTGR_TRAN_OGNL", *INDICADORES)
DIMENSOES = {
    "Q00": (),
    "Q02": INDICADORES,
    "Q03": BASE_Q03,
    "Q04": ("CD_PRD", "CD_NTZ_CTB_TRAN", *INDICADORES),
    "Q09": ("CD_INST_PCT", "NR_MCA_PCT_OPB", *BASE_Q03),
    "Q11": (
        "CD_PRD",
        "CD_NTZ_CTB_TRAN",
        "CD_TRAN_IR",
        "CD_CTGR_TRAN",
        "CD_CTGR_TRAN_OGNL",
        "IN_TRAN_IR",
        "IN_OCTR_TRAN",
        "IN_VSLO_CSM",
        "IN_DVS_LCTO",
    ),
}


def texto(v):
    return format(v, "f") if isinstance(v, Decimal) else str(v) if v is not None else None


def checar_colunas(colunas):
    if (
        not colunas
        or len(set(colunas)) != len(colunas)
        or any(not re.fullmatch("[A-Z][A-Z0-9_]*", k) or COLUNAS_RESTRITAS.search(k) for k in colunas)
    ):
        raise ErroValidacao("Cabeçalho inseguro ou duplicado.")


class SomaExata:
    def __init__(self):
        self.valor = None

    def step(self, v):
        if v is not None:
            self.valor = Decimal(v) if self.valor is None else self.valor + Decimal(v)

    def finalize(self):
        return texto(self.valor.normalize()) if self.valor is not None else None


def reduzir(q, cols, inicio, fim, sql_q04):
    """As dimensões são TEXT (incluindo NULL); SOMA usa Decimal, nunca REAL."""
    tabela = "agregados"

    def agrupar(dimensoes, medidas):
        return (
            "SELECT "
            + ", ".join([*dimensoes, *medidas])
            + " FROM "
            + tabela
            + (" GROUP BY " + ", ".join(dimensoes) if dimensoes else "")
        )

    if q == "Q00":
        ini = inicio
        dias = (date.fromisoformat(fim) - date.fromisoformat(ini)).days
        return agrupar(
            [],
            [
                f"'{ini}' AS DT_INI",
                f"'{fim}' AS DT_FIM_EXCL",
                f"'{dias}' AS QT_DIAS",
                "MIN(DT_MIN_OBS) AS DT_MIN_OBS",
                "MAX(DT_MAX_OBS) AS DT_MAX_OBS",
                *(f"COALESCE(SOMA({k}),'0') AS {k}" for k in METRICAS),
            ],
        )
    if q in CADASTROS:
        return f"SELECT * FROM {tabela} ORDER BY CAST({cols[0]} AS INTEGER)"
    if q == "Q04":
        # Reutiliza os CASE originais, substituindo a unidade de contagem pela multiplicidade.
        s = sql_q04.rsplit("SELECT ", 1)[1].split("FROM B")[0]
        s = (
            s.replace("COUNT_BIG(*)", "SOMA(QT_TRAN)")
            .replace("COUNT_BIG(CASE", "SOMA(CASE")
            .replace("THEN 1 END", "THEN QT_TRAN ELSE '0' END")
        )
        s = re.sub(r"ABS\(DECIMAL\(VL_TRAN,\s*31,\s*2\)\)", "VL_ABS", s)
        s = re.sub(r"DECIMAL\(0,\s*31,\s*2\)", "'0'", s).replace("SUM(", "SOMA(")
        return f"SELECT {s} FROM {tabela} GROUP BY CD_PRD, CD_NTZ_CTB_TRAN"
    if q in ("Q07", "Q08"):
        return f"SELECT * FROM {tabela}"
    dims = DIMENSOES[q] if q in COMPARTILHADAS else [k for k in cols if k not in METRICAS]
    return agrupar(dims, [f"SOMA({k}) AS {k}" for k in METRICAS])


def leituras(operacao, sql):
    if operacao not in ("BASE", "Q05", "Q06", "Q10"):
        yield None, sql
        return
    # NR_PTC é não nula. Os dois extremos incluem toda a faixa de SMALLINT.
    for parte in range(1, 101):
        operador = "<=" if parte == 1 else ">=" if parte == 100 else "="
        trecho = "WHERE T.DT_TRAN >="
        if sql.count(trecho) != 1:
            raise ErroValidacao("Não foi possível localizar o predicado da tabela principal.")
        yield parte, sql.replace(trecho, f"WHERE T.NR_PTC {operador} {parte} AND T.DT_TRAN >=")


def incorporar_leitura(banco, db, conexao, sql, timeout, colunas):
    # Uma falha de fetch ou de fechamento desfaz todas as linhas desta leitura.
    with (
        banco,
        db.blocos_nativos(sql, conexao=conexao, isolation_level=ISOLAMENTO, query_timeout=timeout) as (
            nomes,
            blocos,
        ),
    ):
        nomes = [str(k).upper() for k in nomes]
        checar_colunas(nomes)
        if not colunas:
            campos = ", ".join(k + " TEXT COLLATE RTRIM" for k in nomes)
            banco.execute("CREATE TABLE agregados (" + campos + ")")
        elif nomes != colunas:
            raise ErroValidacao("As colunas diferem entre partições.")
        inserir = "INSERT INTO agregados VALUES (" + ", ".join("?" for _ in nomes) + ")"
        linhas = 0
        for bloco in blocos:
            banco.executemany(inserir, (tuple(texto(x) for x in r) for r in bloco))
            linhas += len(bloco)
    return nomes, linhas


def escrever_csv(local, q, cursor, inicio, fim):
    colunas = [col[0] for col in cursor.description]
    checar_colunas(colunas)
    resumo = ResumoConsulta(q, inicio, fim)
    with local.open("w", newline="", encoding="utf8") as f:
        out = csv.writer(f, delimiter=";")
        out.writerow(colunas)
        for linha in cursor:
            valores = [
                format(Decimal(v), ".2f") if k.startswith("VL_") and v is not None else texto(v)
                for k, v in zip(colunas, linha)
            ]
            resumo.adicionar(dict(zip(colunas, valores)))
            out.writerow([codificar_campo(v) for v in valores])
    return resumo


def executar_estudo(criar_db2, criar_hdfs, spark, consultas, inicio, fim, timeout):
    validar_periodo(inicio, fim, spark)
    if type(timeout) is not int or not 1 <= timeout <= 2147483647:
        raise ErroValidacao("Informe um timeout JDBC positivo em segundos.")

    identificador = uuid4().hex
    pasta = criar_hdfs().criar_diretorio("estudo_gfp_" + identificador)
    hdfs = criar_hdfs(diretorio_base=pasta)
    arquivos, resumos, operacoes, saidas = [], {}, {}, {}
    inicio_execucao = perf_counter()
    print(f"Universo autorizado completo | [{inicio}, {fim}) | resultados em {pasta}")
    for op in ("Q01", "Q01B", "BASE", "Q05", "Q06", "Q07", "Q08", "Q10"):
        inicio_leitura = perf_counter()
        unidade = operacoes[op] = {"leituras_concluidas": 0, "leituras": []}
        instrucoes, colunas = [], []
        with (
            TemporaryDirectory() as tmp,
            closing(sqlite3.connect(str(Path(tmp) / "dados.sqlite"))) as banco,
            localcontext() as precisao,
        ):
            precisao.prec = 64
            banco.create_aggregate("SOMA", 1, SomaExata)
            db = None
            try:
                db = criar_db2()
                with db.conexao_nativa_leitura(ISOLAMENTO) as conexao:
                    for parte, sql in leituras(op, consultas[op]):
                        tic = perf_counter()
                        evento = {"particao": parte, "estado": "EM EXECUÇÃO"}
                        unidade["leituras"].append(evento)
                        print(f"{op} | " + (f"partição {parte}/100" if parte else "leitura integral"))
                        sql = db._normalizar_sql(sql)
                        instrucao = f"-- {op} | " + (f"partição {parte}" if parte else "integral")
                        try:
                            instrucoes.append(instrucao + "\n" + sql + ";")
                            colunas, linhas = incorporar_leitura(banco, db, conexao, sql, timeout, colunas)
                            evento.update(estado="OK", linhas_agregadas=linhas)
                            unidade["leituras_concluidas"] += 1
                        finally:
                            evento["segundos"] = round(perf_counter() - tic, 3)
            except Exception as erro:
                falha = {"tipo": type(erro).__name__}
                if db is not None:
                    diag = db.diagnosticar_erro(erro)
                    falha.update(sqlstate=diag.get("sqlstate"), sqlcode=diag.get("sqlcode"))
                if isinstance(erro, ErroValidacao):
                    falha["mensagem"] = str(erro)
                unidade["falha"] = falha
                if unidade["leituras"] and unidade["leituras"][-1]["estado"] == "EM EXECUÇÃO":
                    unidade["leituras"][-1]["estado"] = "ERRO"
                print(op, "falhou", falha)
            unidade["segundos"] = round(perf_counter() - inicio_leitura, 3)
            if instrucoes:
                nome = op + "_db2.sql"
                hdfs.salvar_texto(nome, "\n\n".join(instrucoes) + "\n")
                arquivos.append(nome)

            for q in COMPARTILHADAS if op == "BASE" else (op,):
                saida = saidas[q] = {
                    "origem": op,
                    "estado": "SEM RESULTADO",
                    "segundos_leitura": unidade["segundos"],
                }
                if not unidade["leituras_concluidas"]:
                    continue
                tic = perf_counter()
                try:
                    sql_local = reduzir(q, colunas, inicio, fim, consultas["Q04"])
                    cursor = banco.execute(sql_local)
                    nome_sql = q + "_consolidacao.sql"
                    hdfs.salvar_texto(nome_sql, sql_local + ";\n")
                    arquivos.append(nome_sql)
                    parcial = "falha" in unidade
                    nome_csv = q + ("_PARCIAL.csv" if parcial else ".csv")
                    local = Path(tmp) / nome_csv
                    resumo = escrever_csv(local, q, cursor, inicio, fim)
                    hdfs.copiar_do_driver(local, nome_csv)
                    arquivos.append(nome_csv)
                    local.unlink()
                    if not parcial:
                        resumos[q] = resumo
                    saida.update(
                        estado="PARCIAL" if parcial else "OK", linhas=resumo.linhas, arquivo=nome_csv
                    )
                except Exception as erro:
                    saida.update(estado="ERRO", erro=type(erro).__name__)
                    if isinstance(erro, ErroValidacao):
                        saida["mensagem"] = str(erro)
                saida["segundos_consolidacao"] = round(perf_counter() - tic, 3)
                print(q, saida["estado"], saida.get("linhas", 0), "linhas")
    controles = verificar_resultados(resumos, consultas)
    situacao = "COMPLETO" if len(resumos) == 13 and all(v == "OK" for _, v in controles) else "PARCIAL"
    resumo_execucao = {
        "situacao": situacao,
        "inicio_inclusivo": inicio,
        "fim_exclusivo": fim,
        "populacao": "universo autorizado completo",
        "particoes": "todas",
        "timeout_segundos": timeout,
        "segundos_ate_empacotamento": round(perf_counter() - inicio_execucao, 3),
        "consultas": saidas,
        "controles": dict(controles),
        "operacoes_db2": operacoes,
    }
    hdfs.salvar_texto("Resumo.json", json.dumps(resumo_execucao, ensure_ascii=False, indent=2))
    nome = f"ESTUDO_GFP_{inicio}_{fim}_{situacao}_{identificador[:12]}.zip"
    arquivos.append("Resumo.json")
    info = hdfs.compactar_zip(arquivos, nome)
    for arquivo in arquivos:
        try:
            hdfs.remover(arquivo)
        except Exception:
            print("Arquivo avulso preservado no HDFS", arquivo)
    print(situacao, "|", len(resumos), "consultas completas | ZIP", info["caminho"])
    for controle, resultado in controles:
        print(resultado, controle)
    return info["caminho"]
