"""Estudo pontual dos seis indicadores GFP. Executar pelo notebook no driver Spark."""

import csv
import json
import re
import sqlite3
from collections import Counter, defaultdict
from contextlib import closing
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, localcontext
from pathlib import Path
from tempfile import TemporaryDirectory
from time import perf_counter
from uuid import uuid4
from zipfile import ZipFile
import shutil

PRINCIPAIS = ("Q00", "Q01", "Q01B", "Q02", "Q03", "Q04", "Q05", "Q06", "Q07", "Q08", "Q11")
COMPLEMENTARES = ("Q09", "Q10")
INDICADORES = ("IN_VSLO_CSM", "IN_VSLO_CX", "IN_VSLO_EVT", "IN_DVS_LCTO", "IN_OCTR_TRAN", "IN_TRAN_IR")
METRICAS = ("QT_TRAN", "VL_TOTAL", "VL_ABS")
CADASTROS = ("Q01", "Q01B")


ZERO = (0, Decimal(0), Decimal(0))
CENARIOS_Q04 = (
    "ORIGINAL",
    "CSM",
    "CX",
    "EVT",
    "DVS",
    "OCTR",
    "IR",
    "RADAR",
    "CSM_D",
    "GFP_EVT_INST",
    "GFP_CX_INST",
    "GFP_CSM_INST",
)
ISOLAMENTO = "READ_COMMITTED"
COLUNAS_RESTRITAS = re.compile(
    r"^(CD_CLI(?:_|$)|NR_CPF|CD_CPF|NR_TRAN_(?:INST|INCD|RLZD)|"
    r"(?:NR|CD|DV)_(?:AG|CT)_|(?:CD|NR)_IDFR_|TX_(?:CMPR_)?DCR_TRAN)"
)


class ErroValidacao(ValueError):
    """Validação com mensagem controlada para o manifesto."""


def validar_periodo(inicio, fim, spark=None):
    """Confere [início, fim) e, no driver, o último dia incluído pelo calendário da sessão."""
    if not all(
        isinstance(valor, str) and re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", valor)
        for valor in (inicio, fim)
    ):
        raise ErroValidacao("Informe as duas datas no formato AAAA-MM-DD.")
    try:
        primeiro_dia, fim_exclusivo = date.fromisoformat(inicio), date.fromisoformat(fim)
    except ValueError:
        raise ErroValidacao("Informe datas de calendário válidas no formato AAAA-MM-DD.") from None
    if primeiro_dia >= fim_exclusivo:
        raise ErroValidacao("A data inicial deve ser anterior à data final exclusiva.")
    if spark is not None:
        hoje = spark.sql("SELECT CURRENT_DATE() AS HOJE").first()[0]
        if fim_exclusivo - timedelta(days=1) > hoje:
            raise ErroValidacao("O período inclui um dia futuro segundo a data atual da sessão Spark.")


def preparar_consultas(pasta, inicio, fim):
    """Carrega as consultas previstas e parametriza seus limites."""
    validar_periodo(inicio, fim)
    consultas = {}
    for consulta in (*PRINCIPAIS, *COMPLEMENTARES, "BASE"):
        pasta_sql = "02_COMPLEMENTARES" if consulta in COMPLEMENTARES else "01_PRINCIPAIS"
        if consulta == "BASE":
            pasta_sql = "03_OTIMIZADAS"
        sql = (Path(pasta) / pasta_sql / f"{consulta}.sql").read_text(encoding="utf-8-sig")
        sql = re.sub(r"(?m)^--[^\n]*\n?", "", sql).strip()
        if sql.endswith(";"):
            sql = sql[:-1].rstrip()
        if not re.match(r"^(SELECT|WITH)\b", sql, re.I) or ";" in sql or re.search(r"\{[^}]*\}", sql):
            raise ValueError(f"{consulta} deve conter uma única consulta de leitura completa.")
        if consulta not in CADASTROS:
            for coluna, data in (("DT_INI", inicio), ("DT_FIM_EXCL", fim)):
                padrao = rf"DATE\('\d{{4}}-\d{{2}}-\d{{2}}'\)(\s+AS\s+{coluna}\b)"
                sql, substituicoes = re.subn(padrao, rf"DATE('{data}')\1", sql, flags=re.I)
                if substituicoes != 1:
                    raise ValueError(f"{consulta} precisa declarar exatamente um limite {coluna}.")
        consultas[consulta] = sql
    return consultas


def codificar_campo(valor):
    if valor is None:
        return r"\N"
    return "\\" + valor if valor.startswith("\\") else valor


def ler_metricas(linha):
    quantidade = int(linha["QT_TRAN"])
    total, absoluto = (Decimal(linha[campo]) for campo in METRICAS[1:])
    if quantidade < 0 or not total.is_finite() or not absoluto.is_finite() or absoluto < abs(total):
        raise ErroValidacao("Contagem ou valores agregados inválidos.")
    return quantidade, total, absoluto


def somar_metricas(primeiro, segundo):
    return tuple(a + b for a, b in zip(primeiro, segundo))


def acumular(grupos, chave, valores):
    grupos[chave] = somar_metricas(grupos.get(chave, (0,) * len(valores)), valores)


class ResumoConsulta:
    """Guarda somente os subtotais usados nos controles cruzados."""

    def __init__(self, consulta, inicio, fim):
        self.consulta = consulta
        self.inicio = inicio
        self.fim = fim
        self.linhas = 0
        self.total = ZERO
        self.produtos = {}
        self.combinacoes = {}
        self.cenarios = defaultdict(dict)
        self.divididos = Counter()
        self.chaves = set()
        self.fora_dominio = Counter()

    def adicionar(self, linha):
        self.linhas += 1
        consulta = self.consulta
        if consulta in ("Q01", "Q01B"):
            coluna = "CD_CTGR_TRAN" if consulta == "Q01" else "CD_GR_CTGR_TRAN"
            chave = linha[coluna]
            if chave is None or chave in self.chaves:
                raise ErroValidacao("Chave ausente ou repetida no cadastro.")
            self.chaves.add(chave)
            return

        if consulta == "Q08":
            chave = tuple(linha[c] for c in ("CD_PRD", "CD_NTZ_CTB_TRAN", *INDICADORES[:3]))
            quantidade = int(linha["QT_ORIGINAIS"])
            if quantidade < 1 or int(linha["QT_DERIVADOS"]) < 0:
                raise ErroValidacao("Contagem inválida de originais ou derivados.")
            self.divididos[chave] += quantidade
            return

        if consulta == "Q04":
            chave = linha["CD_PRD"], linha["CD_NTZ_CTB_TRAN"]
            if chave in self.cenarios:
                raise ErroValidacao("Produto e natureza repetidos na Q04.")
            cenarios = {
                nome: (int(linha[f"QT_{nome}"]), Decimal(linha[f"VL_ABS_{nome}"])) for nome in CENARIOS_Q04
            }
            qt_base, vl_base = cenarios["ORIGINAL"]
            if any(not (0 <= qt <= qt_base and 0 <= vl <= vl_base) for qt, vl in cenarios.values()):
                raise ErroValidacao("O resultado de um cenário da Q04 excede seu universo.")
            self.cenarios[chave] = cenarios
            return

        metricas = ler_metricas(linha)
        if consulta == "Q00":
            dias = (date.fromisoformat(self.fim) - date.fromisoformat(self.inicio)).days
            if (
                self.linhas != 1
                or linha["DT_INI"] != self.inicio
                or linha["DT_FIM_EXCL"] != self.fim
                or int(linha["QT_DIAS"]) != dias
            ):
                raise ErroValidacao("A Q00 deve retornar uma linha para a janela selecionada.")
            minimo, maximo = linha["DT_MIN_OBS"], linha["DT_MAX_OBS"]
            if metricas[0]:
                if not minimo or not maximo or not self.inicio <= minimo <= maximo < self.fim:
                    raise ErroValidacao("A Q00 retornou datas observadas fora da janela.")
            elif minimo is not None or maximo is not None or metricas != ZERO:
                raise ErroValidacao("A Q00 retornou medidas incompatíveis com janela vazia.")

        produto = linha.get("CD_PRD")
        if consulta == "Q10" and (
            produto not in ("6", "9")
            or linha["CD_EST_TRAN_INST"] != "0"
            or (linha["CD_TIP_MOE_CRR"] or "").rstrip() != "BRL"
        ):
            return
        self.total = somar_metricas(self.total, metricas)
        if consulta in ("Q02", "Q03", "Q10"):
            indicadores = tuple(linha[nome] for nome in INDICADORES)
            acumular(self.combinacoes, indicadores, metricas)
        if consulta == "Q02":
            for nome, valor in zip(INDICADORES, indicadores):
                if valor not in ("S", "N"):
                    self.fora_dominio[nome] += metricas[0]
        if consulta == "Q03":
            acumular(self.produtos, produto, metricas)
            natureza = linha["CD_NTZ_CTB_TRAN"]
            csm, cx, evt, dvs, octr, ir = indicadores
            consumo_debito = natureza == "D" and csm == "S"
            condicoes = (
                True,
                csm == "S",
                cx == "S",
                evt == "S",
                dvs == "N",
                octr == "N",
                ir == "S",
                natureza == "C" or consumo_debito,
                consumo_debito,
                evt == "S" and dvs == "N",
                cx == "S" and dvs == "N",
                consumo_debito and dvs == "N",
            )
            grupo = self.cenarios[produto, natureza]
            for nome, condicao in zip(CENARIOS_Q04, condicoes):
                acumular(grupo, nome, (metricas[0], metricas[2]) if condicao else (0, Decimal(0)))
            if dvs == "S":
                self.divididos[produto, natureza, csm, cx, evt] += metricas[0]
        if (consulta == "Q05" and produto != "9") or (consulta == "Q06" and produto != "6"):
            raise ErroValidacao("A consulta retornou produto fora de seu recorte.")


def verificar_resultados(resultados, consultas):
    verificacoes = []

    def conferir(nome, primeira, segunda, atributo, esperado=None):
        if primeira not in resultados or segunda not in resultados:
            verificacoes.append((nome, "PENDENTE"))
            return
        observado = getattr(resultados[primeira], atributo)
        comparavel = (
            getattr(resultados[segunda], atributo) if esperado is None else esperado(resultados[segunda])
        )
        verificacoes.append((nome, "OK" if observado == comparavel else "DIVERGÊNCIA"))

    conferir("Q00 × Q02 em quantidade, valor registrado e valor absoluto", "Q00", "Q02", "total")
    conferir("Q00 × Q03 em quantidade, valor registrado e valor absoluto", "Q00", "Q03", "total")
    conferir("Q02 × Q03 por combinação dos seis indicadores", "Q02", "Q03", "combinacoes")
    conferir("Q04 × Q03 por produto, natureza e cenário de retenção", "Q04", "Q03", "cenarios")
    for consulta, produto in (("Q05", "9"), ("Q06", "6")):
        conferir(
            f"{consulta} × Q03 para produto {produto}",
            consulta,
            "Q03",
            "total",
            lambda resumo, prd=produto: resumo.produtos.get(prd, ZERO),
        )
    conferir(
        "Q08 × Q03 para originais divididos por produto, natureza e visibilidade",
        "Q08",
        "Q03",
        "divididos",
    )
    for consulta in ("Q09", "Q11"):
        if consulta in consultas:
            conferir(f"{consulta} × Q03 para o universo principal", consulta, "Q03", "total")
    if "Q10" in consultas:
        conferir(
            "Q10 × Q02 por combinação, no recorte BRL efetivado de produtos 6 e 9",
            "Q10",
            "Q02",
            "combinacoes",
        )
    return verificacoes


COMPARTILHADAS = ("Q00", "Q02", "Q03", "Q04", "Q09", "Q11")
BASE_Q03 = ("CD_PRD", "CD_NTZ_CTB_TRAN", "CD_TIP_TRAN", "CD_CTGR_TRAN", "CD_CTGR_TRAN_OGNL", *INDICADORES)
DIMENSOES = {
    "Q00": (),
    "Q02": INDICADORES,
    "Q03": BASE_Q03,
    "Q04": ("CD_PRD", "CD_NTZ_CTB_TRAN", *INDICADORES),
    "Q09": ("CD_INST_PCT", "NR_MCA_PCT_OPB", *BASE_Q03),
    "Q11": (
        "CD_PRD",
        "CD_NTZ_CTB_TRAN",
        "CD_TRAN_IR",
        "CD_CTGR_TRAN",
        "CD_CTGR_TRAN_OGNL",
        "IN_TRAN_IR",
        "IN_OCTR_TRAN",
        "IN_VSLO_CSM",
        "IN_DVS_LCTO",
    ),
}


def texto(v):
    return format(v, "f") if isinstance(v, Decimal) else str(v) if v is not None else None


def checar_colunas(colunas):
    if (
        not colunas
        or len(set(colunas)) != len(colunas)
        or any(not re.fullmatch("[A-Z][A-Z0-9_]*", k) or COLUNAS_RESTRITAS.search(k) for k in colunas)
    ):
        raise ErroValidacao("Cabeçalho inseguro ou duplicado.")


class SomaExata:
    def __init__(self):
        self.valor = None

    def step(self, v):
        if v is not None:
            self.valor = Decimal(v) if self.valor is None else self.valor + Decimal(v)

    def finalize(self):
        return texto(self.valor.normalize()) if self.valor is not None else None


def reduzir(q, cols, inicio, fim, sql_q04):
    """As dimensões são TEXT (incluindo NULL); SOMA usa Decimal, nunca REAL."""
    tabela = "agregados"

    def agrupar(dimensoes, medidas):
        return (
            "SELECT "
            + ", ".join([*dimensoes, *medidas])
            + " FROM "
            + tabela
            + (" GROUP BY " + ", ".join(dimensoes) if dimensoes else "")
        )

    if q == "Q00":
        ini = inicio
        dias = (date.fromisoformat(fim) - date.fromisoformat(ini)).days
        return agrupar(
            [],
            [
                f"'{ini}' AS DT_INI",
                f"'{fim}' AS DT_FIM_EXCL",
                f"'{dias}' AS QT_DIAS",
                "MIN(DT_MIN_OBS) AS DT_MIN_OBS",
                "MAX(DT_MAX_OBS) AS DT_MAX_OBS",
                *(f"COALESCE(SOMA({k}),'0') AS {k}" for k in METRICAS),
            ],
        )
    if q in CADASTROS:
        return f"SELECT * FROM {tabela} ORDER BY CAST({cols[0]} AS INTEGER)"
    if q == "Q04":
        # Reutiliza os CASE originais, substituindo a unidade de contagem pela multiplicidade.
        s = sql_q04.rsplit("SELECT ", 1)[1].split("FROM B")[0]
        s = (
            s.replace("COUNT_BIG(*)", "SOMA(QT_TRAN)")
            .replace("COUNT_BIG(CASE", "SOMA(CASE")
            .replace("THEN 1 END", "THEN QT_TRAN ELSE '0' END")
        )
        s = re.sub(r"ABS\(DECIMAL\(VL_TRAN,\s*31,\s*2\)\)", "VL_ABS", s)
        s = re.sub(r"DECIMAL\(0,\s*31,\s*2\)", "'0'", s).replace("SUM(", "SOMA(")
        return f"SELECT {s} FROM {tabela} GROUP BY CD_PRD, CD_NTZ_CTB_TRAN"
    if q in ("Q07", "Q08"):
        return f"SELECT * FROM {tabela}"
    dims = DIMENSOES[q] if q in COMPARTILHADAS else [k for k in cols if k not in METRICAS]
    return agrupar(dims, [f"SOMA({k}) AS {k}" for k in METRICAS])


def leituras(operacao, sql, tamanho=1):
    if operacao not in ("BASE", "Q05", "Q06", "Q10"):
        yield None, None, sql
        return
    # NR_PTC é não nula. Os dois extremos incluem toda a faixa de SMALLINT.
    trecho = "WHERE T.DT_TRAN >="
    if sql.count(trecho) != 1:
        raise ErroValidacao("Predicado da tabela principal não localizado.")
    for primeiro in range(1, 101, tamanho):
        ultimo = min(100, primeiro + tamanho - 1)
        if primeiro == 1 and ultimo == 100:
            yield primeiro, ultimo, sql
            continue
        if primeiro == 1:
            faixa = f"T.NR_PTC <= {ultimo}"
        elif ultimo == 100:
            faixa = f"T.NR_PTC >= {primeiro}"
        elif primeiro == ultimo:
            faixa = f"T.NR_PTC = {primeiro}"
        else:
            faixa = f"T.NR_PTC BETWEEN {primeiro} AND {ultimo}"
        yield primeiro, ultimo, sql.replace(trecho, f"WHERE {faixa} AND T.DT_TRAN >=")


def incorporar_leitura(banco, db, conexao, sql, timeout, colunas):
    # Uma falha de fetch ou de fechamento desfaz todas as linhas desta leitura.
    with (
        banco,
        db.blocos_nativos(sql, conexao=conexao, isolation_level=ISOLAMENTO, query_timeout=timeout) as (
            nomes,
            blocos,
        ),
    ):
        nomes = [str(k).upper() for k in nomes]
        checar_colunas(nomes)
        if not colunas:
            campos = ", ".join(k + " TEXT COLLATE RTRIM" for k in nomes)
            banco.execute("CREATE TABLE agregados (" + campos + ")")
        elif nomes != colunas:
            raise ErroValidacao("As colunas diferem entre partições.")
        inserir = "INSERT INTO agregados VALUES (" + ", ".join("?" for _ in nomes) + ")"
        linhas = 0
        for bloco in blocos:
            banco.executemany(inserir, (tuple(texto(x) for x in r) for r in bloco))
            linhas += len(bloco)
    return nomes, linhas


def escrever_csv(local, q, cursor, inicio, fim):
    colunas = [col[0] for col in cursor.description]
    checar_colunas(colunas)
    resumo = ResumoConsulta(q, inicio, fim)
    representadas = 0
    with local.open("w", newline="", encoding="utf8") as f:
        out = csv.writer(f, delimiter=";")
        out.writerow(colunas)
        for linha in cursor:
            valores = [
                format(Decimal(v), ".2f") if k.startswith("VL_") and v is not None else texto(v)
                for k, v in zip(colunas, linha)
            ]
            registro = dict(zip(colunas, valores))
            resumo.adicionar(registro)
            representadas += int(
                registro.get("QT_TRAN", registro.get("QT_ORIGINAL", registro.get("QT_ORIGINAIS", 0)))
            )

            out.writerow([codificar_campo(v) for v in valores])
    return resumo, None if q in CADASTROS else representadas


CONSULTAS = PRINCIPAIS + COMPLEMENTARES
PARTICIONADAS = ("BASE", "Q05", "Q06", "Q10")


def agora():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def gravar_json(hdfs, nome, dados):
    hdfs.salvar_texto(nome, json.dumps(dados, ensure_ascii=False, indent=1), sobrescrever=True)


def inspecionar(criar_hdfs, inicio, fim):
    """Inspeção de metadados na home antes da primeira conexão ao Db2."""
    home = criar_hdfs()
    diretorios = home.listar(limite=10000)
    if len(diretorios) == 10000:
        raise ErroValidacao("Listagem da home atingiu o limite. Indique a pasta explicitamente.")
    candidatas = []
    for item in diretorios:
        if not item["diretorio"] or not re.fullmatch(r"estudo_gfp_[0-9a-f]{32}", item["nome"]):
            continue
        h = criar_hdfs(diretorio_base=item["caminho"])
        nomes = [f["nome"] for f in h.listar()]
        if "Parametros.json" in nomes:
            p = json.loads(h.ler_texto("Parametros.json"))
            if (p["inicio"], p["fim"]) != (inicio, fim):
                continue
        zips = [n for n in nomes if n.endswith(".zip")]
        if zips and not any(f"_{inicio}_{fim}_" in n for n in zips):
            continue
        arquivos = sorted(n for n in nomes if n.endswith((".csv", ".zip")))
        print("Pasta existente", h.base, "| arquivos disponíveis", arquivos)
        candidatas.append(h.base)
    return candidatas


class Execucao:
    """Estado das células de uma única pasta HDFS. Somente os agregados passam pelo driver."""

    def __init__(
        self,
        criar_db2,
        criar_hdfs,
        spark,
        consultas,
        inicio,
        fim,
        timeout,
        pasta=None,
        tamanho=1,
        baixar=True,
    ):
        validar_periodo(inicio, fim, spark)
        if type(timeout) is not int or not 1 <= timeout <= 2147483647:
            raise ErroValidacao("Timeout JDBC inválido.")
        if type(tamanho) is not int or not 1 <= tamanho <= 100:
            raise ErroValidacao("A faixa deve conter de 1 a 100 partições.")
        self.criar_db2, self.sqls = criar_db2, consultas
        self.param = dict(
            inicio=inicio,
            fim=fim,
            timeout_segundos=timeout,
            particoes_por_leitura=tamanho,
            baixar_zip=baixar,
            populacao="universo autorizado completo",
            particoes="todas",
        )
        self.resumos = {}
        candidatas = inspecionar(criar_hdfs, inicio, fim) if pasta in (None, "nova") else []
        if candidatas and pasta is None:
            raise ErroValidacao(
                "Há resultados anteriores. Veja as pastas acima. Selecione uma pasta encerrada ou 'nova' nos parâmetros antes de consultar o Db2. "
                + ", ".join(candidatas)
            )
        anterior = None
        if pasta is not None and pasta != "nova":
            if not isinstance(pasta, str) or not re.fullmatch(
                r"estudo_gfp_[0-9a-f]{32}", pasta.rstrip("/").split("/")[-1]
            ):
                raise ErroValidacao("Informe o diretório de execução exibido na inspeção.")
            h = criar_hdfs(diretorio_base=pasta)
            if h.existe("Parametros.json"):
                p = json.loads(h.ler_texto("Parametros.json"))
                if (inicio, fim, tamanho) != (p["inicio"], p["fim"], p["particoes_por_leitura"]):
                    raise ErroValidacao("Período ou faixas incompatíveis com a pasta selecionada.")
                self.h = h
                self.d = json.loads(h.ler_texto("Resumo.json"))
                self.d["parametros"] = self.param
                gravar_json(h, "Parametros.json", self.param)
                self.salvar()
                self.progresso("INFRA", "Pasta reaberta")
                self.tmp = TemporaryDirectory()
                self.base_local = Path(self.tmp.name) / "BASE.sqlite"
                return
            anterior = h
        destino = criar_hdfs().criar_diretorio("estudo_gfp_" + uuid4().hex)
        self.h = criar_hdfs(diretorio_base=destino)
        self.d = {
            "inicio_utc": agora(),
            "situacao": "PARCIAL",
            "parametros": self.param,
            "consultas": {},
            "operacoes_db2": {},
            "controles": {},
        }
        gravar_json(self.h, "Parametros.json", self.param)
        self.salvar()
        if anterior is not None:
            self.aproveitar_anterior(anterior)
        self.progresso("INFRA", "Pronta")
        self.tmp = TemporaryDirectory()
        self.base_local = Path(self.tmp.name) / "BASE.sqlite"

    def salvar(self):
        gravar_json(self.h, "Resumo.json", self.d)

    def progresso(self, etapa, estado, **dados):
        s = self.d["consultas"]
        info = {
            "utc": agora(),
            "etapa": etapa,
            "estado": estado,
            "consultas_concluidas": sum(v["estado"] == "OK" for v in s.values()),
            "total_consultas": len(CONSULTAS),
            **dados,
        }
        gravar_json(self.h, "Progresso.json", info)
        if estado not in ("Leitura JDBC", "Leitura concluída", "Faixa concluída"):
            print(json.dumps(info, ensure_ascii=False), flush=True)

    def erro(self, erro, db=None):
        d = {"tipo": type(erro).__name__}
        if isinstance(erro, ErroValidacao):
            d["mensagem"] = str(erro)
        if db is not None:
            diag = db.diagnosticar_erro(erro)
            d.update(sqlstate=diag.get("sqlstate"), sqlcode=diag.get("sqlcode"))
        return d

    def aproveitar_anterior(self, origem):
        """Importa apenas saídas completas cuja leitura e consolidação correspondem à edição anterior."""
        self.d["origem_anterior"] = origem.base
        nomes = {i["nome"] for i in origem.listar()}
        ini, fim = self.param["inicio"], self.param["fim"]
        zips = sorted(n for n in nomes if n.startswith(f"ESTUDO_GFP_{ini}_{fim}_") and n.endswith(".zip"))
        with TemporaryDirectory() as tmp:
            local = Path(tmp)
            if zips:
                origem.copiar_para_driver(zips[-1], local / "antigo.zip")
                with ZipFile(local / "antigo.zip") as z:
                    resumo = json.loads(z.read("Resumo.json"))
                    if (resumo["inicio_inclusivo"], resumo["fim_exclusivo"]) != (ini, fim):
                        raise ErroValidacao("Período incompatível no ZIP anterior.")
                    for q in CONSULTAS:
                        if resumo["consultas"].get(q, {}).get("estado") == "OK":
                            op = "BASE" if q in COMPARTILHADAS else q
                            for nome in (q + ".csv", q + "_consolidacao.sql", op + "_db2.sql"):
                                if not (local / nome).exists():
                                    with z.open(nome) as r, (local / nome).open("wb") as w:
                                        shutil.copyfileobj(r, w)
            elif any(n.endswith(".zip") for n in nomes):
                raise ErroValidacao("O ZIP existente pertence a outro período.")
            else:
                for q in CONSULTAS:
                    op = "BASE" if q in COMPARTILHADAS else q
                    arquivos = (q + ".csv", q + "_consolidacao.sql", op + "_db2.sql")
                    if set(arquivos) <= nomes:
                        for nome in arquivos:
                            if not (local / nome).exists():
                                origem.copiar_para_driver(nome, local / nome)
            for q in CONSULTAS:
                op = "BASE" if q in COMPARTILHADAS else q
                csvnome = q + ".csv"
                if not (local / csvnome).exists():
                    continue
                # O arquivo legado contém o texto de cada instrução e sua faixa.
                sqlnome = op + "_db2.sql"
                executado = re.sub(r"(?m)^--[^\n]*\n", "", (local / sqlnome).read_text(encoding="utf8"))
                esperado = [s.strip() for _, _, s in leituras(op, self.sqls[op])]
                if [s.strip() for s in executado.split(";") if s.strip()] != esperado:
                    print(q, "ignorada: período, cobertura ou SQL anterior incompatível")
                    continue
                with (local / csvnome).open(newline="", encoding="utf8") as f:
                    cabecalho = next(csv.reader(f, delimiter=";"))
                reducao = reduzir(q, cabecalho, ini, fim, self.sqls["Q04"])
                if (local / (q + "_consolidacao.sql")).read_text(encoding="utf8").strip().rstrip(
                    ";"
                ) != reducao:
                    print(q, "ignorada: consolidação anterior incompatível")
                    continue
                for nome in (sqlnome, q + "_consolidacao.sql", csvnome):
                    if not self.h.existe(nome):
                        self.h.copiar_do_driver(local / nome, nome)
                self.d["operacoes_db2"].setdefault(
                    op, {"estado": "IMPORTADA", "sql": sqlnome, "leituras": []}
                )
                with localcontext() as ctx:
                    ctx.prec = 64
                    r, total = self.ler_csv(q, local / csvnome)
                self.resumos[q] = r
                self.d["consultas"][q] = {
                    "estado": "OK",
                    "origem": op,
                    "arquivo": csvnome,
                    "sql": q + "_consolidacao.sql",
                    "linhas": r.linhas,
                    "transacoes": total,
                    "observacao": "Resultado completo importado da pasta anterior",
                }
                self.salvar()
        if not self.d["consultas"]:
            raise ErroValidacao(
                "Nenhuma saída anterior completa e compatível. A origem foi preservada. Para começar outra extração, selecione 'nova'."
            )
        print("Resultados aproveitados", sorted(self.d["consultas"]))

    def ler_csv(self, q, local):
        r = ResumoConsulta(q, self.param["inicio"], self.param["fim"])
        transacoes = 0
        with local.open(newline="", encoding="utf8") as f:
            leitor = csv.DictReader(f, delimiter=";")
            checar_colunas(leitor.fieldnames)
            for linha in leitor:
                registro = {
                    k: None if v == r"\N" else v[1:] if v.startswith("\\\\") else v for k, v in linha.items()
                }
                r.adicionar(registro)
                transacoes += int(
                    registro.get("QT_TRAN", registro.get("QT_ORIGINAL", registro.get("QT_ORIGINAIS", 0)))
                )
        return r, None if q in CADASTROS else transacoes

    def etapa(self, q):
        if q not in (*CONSULTAS, "BASE"):
            raise ValueError("Etapa desconhecida.")
        saidas, ops = self.d["consultas"], self.d["operacoes_db2"]
        if q == "BASE":
            if ops.get(q, {}).get("estado") == "OK" and self.h.existe("BASE.sqlite"):
                self.progresso(q, "Base já disponível", arquivo=self.h.base + "/BASE.sqlite")
                return
            if all(saidas.get(k, {}).get("estado") == "OK" for k in COMPARTILHADAS):
                self.progresso(q, "Seis saídas anteriores já disponíveis")
                return
        elif (
            saidas.get(q, {}).get("estado") == "OK"
            and self.h.existe(saidas[q]["arquivo"])
            and not (q in COMPARTILHADAS and self.h.existe("BASE.sqlite"))
        ):
            self.progresso(q, "CSV já disponível", arquivo=self.h.base + "/" + saidas[q]["arquivo"])
            return
        t = perf_counter()
        inicio = agora()
        self.d.update(controles={}, situacao="PARCIAL")
        base = q in COMPARTILHADAS
        op = "BASE" if base else q
        if not base:
            if q == "BASE":
                # Toda saída dependente volta a exigir consolidação da base desta tentativa.
                for k in COMPARTILHADAS:
                    saidas.pop(k, None)
                    self.resumos.pop(k, None)
                self.base_local.unlink(missing_ok=True)
            if op in ops:
                self.d.setdefault("tentativas_anteriores", []).append(dict(ops[op], operacao=op))
            ops[op] = {
                "inicio": inicio,
                "estado": "EM EXECUÇÃO",
                "leituras": [],
                "leituras_concluidas": 0,
                "timeout_segundos": self.param["timeout_segundos"],
            }
        if q != "BASE":
            saidas[q] = {"inicio": inicio, "estado": "EM EXECUÇÃO", "origem": op}
        self.salvar()
        self.progresso(q, "Iniciada", inicio=inicio)
        with TemporaryDirectory() as tmp, localcontext() as ctx:
            ctx.prec = 64
            local = self.base_local if q == "BASE" or base else Path(tmp) / "agregados.sqlite"
            try:
                if base:
                    if ops.get("BASE", {}).get("estado") not in ("OK", "PARCIAL") or not self.h.existe(
                        "BASE.sqlite"
                    ):
                        saidas[q]["estado"] = "DEPENDÊNCIA PENDENTE"
                        raise ErroValidacao("Execute a célula BASE antes desta consolidação.")
                    if not local.exists():
                        self.h.copiar_para_driver("BASE.sqlite", local)
                with closing(sqlite3.connect(local)) as banco:
                    banco.create_aggregate("SOMA", 1, SomaExata)
                    if not base:
                        self.ler_operacao(q, banco)
                        ops[op]["bytes_agregados_driver"] = local.stat().st_size
                        if not ops[op]["leituras_concluidas"]:
                            raise ErroValidacao("Nenhuma faixa concluída. Consulte a falha da operação.")
                    if q != "BASE":
                        self.progresso(q, "Consolidação no driver", inicio=inicio)
                        cols = [r[1] for r in banco.execute("PRAGMA table_info(agregados)")]
                        sql = reduzir(q, cols, self.param["inicio"], self.param["fim"], self.sqls["Q04"])
                        cursor = banco.execute(sql)
                        self.h.salvar_texto(q + "_consolidacao.sql", sql + ";\n", sobrescrever=True)
                        parcial = ops[op]["estado"] != "OK"
                        nome = q + ("_PARCIAL.csv" if parcial else ".csv")
                        csvlocal = Path(tmp) / nome
                        r, total = escrever_csv(csvlocal, q, cursor, self.param["inicio"], self.param["fim"])
                        self.progresso(q, "Publicando CSV", linhas=r.linhas, transacoes=total)
                        self.h.copiar_do_driver(csvlocal, nome, sobrescrever=True)
                        saidas[q].update(
                            estado="PARCIAL" if parcial else "OK",
                            arquivo=nome,
                            sql=q + "_consolidacao.sql",
                            linhas=r.linhas,
                            transacoes=total,
                            bytes_csv=csvlocal.stat().st_size,
                        )
                        if not parcial:
                            self.resumos[q] = r
                if q == "BASE":
                    self.progresso(q, "Publicando base no HDFS", bytes=local.stat().st_size)
                    self.h.copiar_do_driver(local, "BASE.sqlite", sobrescrever=True)
                    ops[q].update(arquivo="BASE.sqlite", bytes_agregados=local.stat().st_size)
            except Exception as erro:
                alvo = ops[q] if q == "BASE" else saidas[q]
                if alvo.get("estado") != "DEPENDÊNCIA PENDENTE":
                    alvo["estado"] = "ERRO"
                alvo.setdefault("falha", ops.get(op, {}).get("falha") or self.erro(erro))
            alvo = ops[q] if q == "BASE" else saidas[q]
            alvo.update(fim=agora(), segundos=round(perf_counter() - t, 3))
            self.d["segundos_etapas"] = round(self.d.get("segundos_etapas", 0) + alvo["segundos"], 3)
            self.salvar()
            self.progresso(
                q,
                alvo["estado"],
                inicio=inicio,
                fim=alvo["fim"],
                segundos=alvo["segundos"],
                linhas=alvo.get("linhas"),
                transacoes=alvo.get("transacoes"),
                arquivo=self.h.base + "/" + alvo["arquivo"] if alvo.get("arquivo") else None,
                falha=ops.get(op, {}).get("falha") or alvo.get("falha"),
            )

    def ler_operacao(self, op, banco):
        u = self.d["operacoes_db2"][op]
        db = None
        consultas = []
        colunas = []
        concluidas = 0
        try:
            db = self.criar_db2()
            with db.conexao_nativa_leitura(ISOLAMENTO) as conn:
                for de, ate, sql in leituras(op, self.sqls[op], self.param["particoes_por_leitura"]):
                    tic = perf_counter()
                    evento = {"de": de, "ate": ate, "inicio": agora(), "estado": "EM EXECUÇÃO"}
                    u["leituras"].append(evento)
                    self.progresso(
                        op,
                        "Leitura JDBC",
                        **{k: evento[k] for k in ("de", "ate", "inicio")},
                        particoes_concluidas=concluidas,
                        particoes_previstas=100 if de else None,
                    )
                    sql = db._normalizar_sql(sql)
                    consultas.append(sql + ";")
                    try:
                        colunas, linhas = incorporar_leitura(
                            banco, db, conn, sql, self.param["timeout_segundos"], colunas
                        )
                        u["leituras_concluidas"] += 1
                        concluidas += ate - de + 1 if de else 0
                        evento.update(estado="OK", linhas_agregadas=linhas)
                    finally:
                        evento.update(fim=agora(), segundos=round(perf_counter() - tic, 3))
                    self.progresso(
                        op,
                        "Faixa concluída" if de else "Leitura concluída",
                        de=de,
                        ate=ate,
                        particoes_concluidas=concluidas,
                        linhas=linhas,
                        segundos=evento["segundos"],
                    )
            u["estado"] = "OK"
        except Exception as erro:
            u["falha"] = self.erro(erro, db)
            if u["leituras"] and u["leituras"][-1]["estado"] == "EM EXECUÇÃO":
                u["leituras"][-1]["estado"] = "ERRO"
                u["falha"].update(de=u["leituras"][-1]["de"], ate=u["leituras"][-1]["ate"])
            u["estado"] = "PARCIAL" if u["leituras_concluidas"] else "ERRO"
        u["particoes_concluidas"] = concluidas
        u["linhas"] = sum(e.get("linhas_agregadas", 0) for e in u["leituras"])
        if consultas:
            tentativa = sum(s["operacao"] == op for s in self.d.get("tentativas_anteriores", []))
            u["sql"] = op + ("_" + str(tentativa + 1) if tentativa else "") + "_db2.sql"
            self.h.salvar_texto(u["sql"], "\n\n".join(consultas) + "\n", sobrescrever=True)
        if op == "BASE" and u["leituras_concluidas"]:
            # QT_TRAN contém inteiros positivos; SOMA utiliza Decimal inclusive para grandes totais.
            u["transacoes"] = int(
                banco.execute("SELECT COALESCE(SOMA(QT_TRAN),'0') FROM agregados").fetchone()[0]
            )
        u["fim"] = agora()
        u["segundos"] = sum(e.get("segundos", 0) for e in u["leituras"])

    def fechar_cache(self):
        self.tmp.cleanup()

    def validar(self):
        with TemporaryDirectory() as tmp, localcontext() as ctx:
            ctx.prec = 64
            completos = {}
            for q, s in self.d["consultas"].items():
                if s["estado"] != "OK":
                    continue
                try:
                    if not self.h.existe(s["arquivo"]):
                        raise ErroValidacao("CSV ausente no HDFS.")
                    if q not in self.resumos:
                        local = Path(tmp) / s["arquivo"]
                        self.h.copiar_para_driver(s["arquivo"], local)
                        self.resumos[q], _ = self.ler_csv(q, local)
                        local.unlink()
                    completos[q] = self.resumos[q]
                except Exception as erro:
                    s.update(estado="ERRO", falha=self.erro(erro))
            controles = dict(verificar_resultados(completos, self.sqls))
        self.d.update(
            controles=controles,
            situacao="COMPLETO"
            if len(completos) == 13 and all(x == "OK" for x in controles.values())
            else "PARCIAL",
        )
        self.salvar()
        for nome, estado in controles.items():
            print(estado, nome)

    def resumo(self):
        print("Consulta | Situação | Segundos | Linhas | Transações | Arquivo")
        for q in CONSULTAS:
            s = self.d["consultas"].get(q, {})
            print(
                q,
                s.get("estado", "PENDENTE"),
                s.get("segundos", "—"),
                s.get("linhas", "—"),
                s.get("transacoes", "—"),
                s.get("arquivo", "—"),
                sep=" | ",
            )
        ops = self.d["operacoes_db2"]
        saidas = self.d["consultas"]
        self.d["balanco"] = {
            "consultas_com_erro": sum(s["estado"] == "ERRO" for s in saidas.values()),
            "consultas_pendentes": sum(
                saidas.get(q, {}).get("estado") in (None, "DEPENDÊNCIA PENDENTE", "EM EXECUÇÃO")
                for q in CONSULTAS
            ),
            "coberturas_particao_concluidas": sum(
                v.get("particoes_concluidas", 0) for k, v in ops.items() if k in PARTICIONADAS
            ),
            "consultas_completas": sum(s["estado"] == "OK" for s in saidas.values()),
            "consultas_com_erro_ou_parciais": sum(
                s["estado"] in ("ERRO", "PARCIAL") for s in saidas.values()
            ),
            "particoes_concluidas_por_operacao": {
                k: v.get("particoes_concluidas") for k, v in ops.items() if k in PARTICIONADAS
            },
            "segundos_processamento": self.d.get("segundos_etapas", 0),
        }
        print("Verificações cruzadas", self.d["controles"])
        self.d["balanco"]["particoes_distintas_confirmadas"] = len(
            {
                p
                for op in ops.values()
                for leitura in op["leituras"]
                if leitura.get("de") and leitura["estado"] == "OK"
                for p in range(leitura["de"], leitura["ate"] + 1)
            }
        )
        self.d["balanco"]["segundos_desde_inicio"] = round(
            (datetime.now(timezone.utc) - datetime.fromisoformat(self.d["inicio_utc"])).total_seconds(), 1
        )
        print(
            self.param["inicio"],
            self.param["fim"],
            "(fim exclusivo)",
            self.d["situacao"],
            self.d["balanco"],
            self.h.base,
        )
        self.salvar()

    def compactar(self):
        if not self.d["controles"]:
            self.validar()
        self.resumo()
        nomes = {"Resumo.json", "Parametros.json"}
        for s in (
            *self.d.get("tentativas_anteriores", []),
            *self.d["operacoes_db2"].values(),
            *self.d["consultas"].values(),
        ):
            if s.get("sql"):
                nomes.add(s["sql"])
        for s in self.d["consultas"].values():
            if s.get("arquivo") and s["estado"] in ("OK", "PARCIAL"):
                nomes.add(s["arquivo"])
        nome = f"ESTUDO_GFP_{self.param['inicio']}_{self.param['fim']}_{self.d['situacao']}_{uuid4().hex[:12]}.zip"
        return self.h.compactar_zip(sorted(nomes), nome)["caminho"]


INTERVALO_PROGRESSO = 15


def executar_no_jupyter(magia, codigo, etapa, pasta, cliente_hdfs, exportar=""):
    """A magia ocupa a thread principal. A cópia de progresso usa BBMagic local, sem ocupar o Livy."""
    from threading import Event, Thread
    from urllib.parse import urlsplit

    terminado = Event()
    tic = perf_counter()
    caminho = urlsplit(pasta).path + "/Progresso.json"

    def consultar():
        with TemporaryDirectory() as tmp:
            local = Path(tmp) / "progresso.json"
            while not terminado.wait(INTERVALO_PROGRESSO):
                try:
                    cliente_hdfs.download(caminho, str(local), overwrite=True)
                    p = json.loads(local.read_text(encoding="utf8"))
                    print(
                        f"[{agora()}] {etapa} | {perf_counter() - tic:.0f}s | último registro HDFS",
                        p,
                        flush=True,
                    )
                except Exception as erro:
                    print("Leitura independente do progresso indisponível", type(erro).__name__, flush=True)

    print(f"[{agora()}] {etapa} iniciada | {pasta}/Progresso.json", flush=True)
    leitor = Thread(target=consultar, daemon=True)
    leitor.start()
    try:
        magia("spark", exportar, codigo)
    finally:
        terminado.set()
        leitor.join(timeout=1)
        print(f"[{agora()}] {etapa} | chamada Livy encerrada em {perf_counter() - tic:.1f}s", flush=True)
