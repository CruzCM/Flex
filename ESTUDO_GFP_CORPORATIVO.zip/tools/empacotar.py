"""Gera a distribuição por lista de inclusão e confere os bytes relidos do ZIP."""

import ast
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

RAIZ = Path(__file__).resolve().parents[1]
NOME = "ESTUDO_GFP_CORPORATIVO.zip"
REVISAO = "gfp-jdbc-integrado-2"


def arquivos():
    nomes = {
        "ESTUDO_RADAR.ipynb",
        "README.md",
        "DB2GFP_TRAN_RLZD_INST_PCT_documentacao_final.md",
        "03_CONSULTAS/SQLs_preparados_30_dias.zip",
        "04_RESULTADOS_DB2/Manifesto_Execucao.md",
        "tools/empacotar.py",
    }
    for pasta, padrao in (
        ("01_FONTES", "*"),
        ("02_DOCUMENTACAO", "*.md"),
        ("05_CONCLUSOES", "*"),
        ("03_CONSULTAS", "**/*.sql"),
        ("tests", "*.py"),
        ("src/utils", "*.py"),
        ("src/utils", "*.ipynb"),
    ):
        for p in (RAIZ / pasta).glob(padrao):
            if p.is_file():
                nomes.add(p.relative_to(RAIZ).as_posix())
    # Arquivos em diretórios de resultados, ZIPs de execução e entradas de população são privados.
    permitidos_fontes = {
        "tran.txt",
        "GFP.json",
        "db2gfp_estrutura_sysibm.json",
        "mapa_categorias_radar.sql",
        "radar_todos_v1.ipynb",
    }
    permitidos_conclusoes = {
        "Analise_Indicadores.md",
        "Decisao_Filtros_Radar.md",
        "Matriz_Comportamento_Indicadores.csv",
    }
    for n in sorted(nomes):
        p = RAIZ / n
        if n.startswith("src/utils/") and p.name not in {
            "__init__.py",
            "estudo_indicadores_gfp.py",
            "gerenciador_local_v2.py",
            "gerenciador_spark_v2.ipynb",
            "gerenciador_db2_spark_v3.ipynb",
            "gerenciador_hdfs_spark_v1.ipynb",
            "gerenciador_oracle_spark_v2.ipynb",
        }:
            continue
        if n.startswith("01_FONTES/") and p.name not in permitidos_fontes:
            continue
        if n.startswith("05_CONCLUSOES/") and p.name not in permitidos_conclusoes:
            continue
        if p.is_symlink() or RAIZ not in p.resolve().parents:
            raise ValueError("Entrada fora do projeto.")
        data = p.read_bytes()
        if n == "01_FONTES/tran.txt":
            data = re.sub(rb"(?i)(\bCD_CLI\s*=\s*)\d+\b", rb"\1:CLIENTE_AUTORIZADO", data)
            data = re.sub(rb"(?i)(\bNR_TRAN_INST_PCT\s*=\s*)\d+\b", rb"\1:TRANSACAO", data)
        if n == "01_FONTES/GFP.json":
            # Estes campos ERwin incluem proveniência com caminhos de perfil e matrículas.
            # Conserva campos de catálogo e oculta apenas os dados identificadores na cópia de distribuição.
            data = re.sub(rb"(?i)(?<![a-z0-9-])[af]\d{7}(?![a-z0-9-])", b"USUARIO", data)
            data = re.sub(rb'(?i)([a-z]:\\+users\\+)[^\\"]+', rb"\1USUARIO", data)
            json.loads(data)
        yield n, data


def gerar():
    itens = dict(arquivos())
    hashes = {k: hashlib.sha256(v).hexdigest() for k, v in itens.items()}
    nb = json.loads(itens["ESTUDO_RADAR.ipynb"])
    modulo = ast.parse(itens["src/utils/estudo_indicadores_gfp.py"])
    padrao = next(
        ast.literal_eval(n.value)
        for n in modulo.body
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "PARAMETROS_PUBLICOS" for t in n.targets)
    )
    if "".join(nb["cells"][5]["source"]) != padrao or any(c.get("outputs") for c in nb["cells"]):
        raise ValueError("A distribuição requer a cópia pública do notebook, sem resultados ou população.")
    inventario = {
        "revisao": REVISAO,
        "algoritmo": "SHA-256",
        "arquivos": hashes,
        "celulas_fixas": [
            hashlib.sha256("".join(c["source"]).encode()).hexdigest()
            for i, c in enumerate(nb["cells"])
            if i != 5
        ],
    }
    data = (json.dumps(inventario, ensure_ascii=False, indent=2) + "\n").encode()
    (RAIZ / "Inventario.json").write_bytes(data)
    itens["Inventario.json"] = data
    destino = RAIZ / NOME
    temp = destino.with_suffix(".construindo")
    with ZipFile(temp, "w", ZIP_DEFLATED) as z:
        for nome, conteudo in itens.items():
            z.writestr(nome, conteudo)
    with ZipFile(temp) as z:
        if (
            sorted(z.namelist()) != sorted(itens)
            or z.testzip() is not None
            or any(z.read(k) != v for k, v in itens.items())
        ):
            raise ValueError("Distribuição inconsistente.")
    temp.replace(destino)
    print(
        f"{destino.name} | {len(itens)} arquivos | SHA-256 {hashlib.sha256(destino.read_bytes()).hexdigest()}"
    )


if __name__ == "__main__":
    gerar()
