# Estudo dos seis indicadores GFP

Extraia o pacote na raiz do projeto no JupyterLab corporativo. Abra **ESTUDO_RADAR.ipynb** e clique em **Run All**. A sessão usa a autenticação corporativa existente. O ZIP de resultados fica no HDFS e é baixado automaticamente na pasta do notebook.

O período inicial vai de **20/11/2026 inclusive a 27/11/2026 exclusivo**. Para estudar apenas um dia, informe a data desejada e o dia seguinte. A seção de parâmetros contém as duas datas, o timeout JDBC por instrução (inicialmente 7.200 segundos) e o download automático.

## Leitura e resultados

O estudo inclui o universo autorizado completo e todas as 100 partições. A base comum aplica os critérios originais de produto, moeda e estado e conserva todos os valores dos seis indicadores. Q00, Q02, Q03, Q04, Q09 e Q11 compartilham essa leitura. Q01, Q01B, Q05, Q06, Q07, Q08 e Q10 mantêm seus próprios universos.

BASE, Q05, Q06 e Q10 percorrem sequencialmente as faixas de `NR_PTC`. Q07 e Q08 rodam uma vez cada para evitar a releitura da tabela de inclusões em cada faixa. Os dois cadastros também rodam uma vez. Uma execução completa utiliza oito conexões de leitura e 404 instruções JDBC. O Db2 realiza os agrupamentos. O driver consolida os agregados em disco com soma decimal exata. O custo e a poda efetiva de partições dependem do otimizador corporativo. Cada instrução usa READ_COMMITTED e autocommit. Alterações concorrentes na origem podem aparecer nas conferências.

O ZIP completo contém **13 CSVs**, os SQLs enviados ao Db2, os SQLs de consolidação e `Resumo.json`. O resumo informa os tempos, as faixas lidas e as dez conferências de consistência. Em caso de falha, a operação para na primeira faixa afetada e o estudo continua com as operações independentes. Faixas lidas integralmente permanecem disponíveis em CSVs com sufixo `_PARCIAL`. Uma saída sem nenhuma leitura concluída fica registrada no resumo. Uma falha ou divergência identifica o ZIP como **PARCIAL**. Os arquivos avulsos são limpos após a publicação do ZIP.

Para analisar **IN_VSLO_CSM**, comece pela Q03. Por categoria, produto e natureza, compare quantidade, valor registrado e valor absoluto entre `S`, `N`, nulo e demais valores observados. Isso permite distinguir uma categoria totalmente removida pelo filtro de outra que só perde parte das transações. As mesmas linhas contêm os outros cinco indicadores para análise combinada. Q04 quantifica os cenários de retenção e Q01 fornece os nomes das categorias. Os CSVs usam UTF-8, separador ponto e vírgula e `\N` para nulo.

