# Estudo GFP por etapas

## Execução anterior em andamento

A versão anterior escrevia os CSVs concluídos em uma pasta `estudo_gfp_<id>` na home do HDFS. Ao concluir, publicava o ZIP e removia os avulsos. A ausência de novos CSVs durante a leitura da BASE é compatível com trabalho em curso. Essa versão não gravava a partição corrente no HDFS.

Mantenha a sessão que está trabalhando. Pelo navegador HDFS autorizado, consulte a home do usuário e as pastas `estudo_gfp_*`. Se o terminal corporativo tiver o cliente Hadoop autenticado, `hdfs dfs -ls 'estudo_gfp_*/*'` lista os arquivos sem ocupar a sessão Livy. Um ZIP completo do período já pode ser utilizado. Um CSV com sufixo `_PARCIAL` cobre apenas parte do universo.

## Abrir o notebook

Extraia o ZIP de instalação na raiz do projeto. Abra `ESTUDO_RADAR.ipynb`. A única célula de parâmetros traz o período de 20/11/2026 inclusivo a 27/11/2026 exclusivo, timeout JDBC de 7.200 segundos e download automático. O período admite um ou mais dias. O universo contém todos os clientes autorizados e todas as partições.

Com `pasta_execucao = None`, a inicialização inspeciona a home HDFS e informa CSVs e ZIPs de possíveis execuções anteriores. Se houver candidatas, a extração aguarda a escolha da pasta. Diretórios antigos com apenas cadastros podem ter período desconhecido. Para aproveitar dados existentes, informe o caminho da **pasta de uma execução encerrada**. Para iniciar outra observação após a inspeção, informe `"nova"`. Use uma única sessão gravadora por pasta.

- Na pasta desta revisão, as etapas reconhecem os resultados já publicados. O período e o tamanho das faixas devem coincidir com os parâmetros gravados.
- Na pasta da edição anterior, a inicialização copia para uma pasta nova os CSVs completos com SQL de leitura e consolidação compatíveis. Lê também o ZIP legado do período selecionado. Q01 e Q01B são cadastros sem filtro temporal. O resumo registra a origem. A pasta original permanece disponível. Se faltar alguma saída da base antiga e esta precisar ser relida, as seis saídas dependentes serão calculadas sobre a mesma nova base.

## Acompanhar e repetir

Cada consulta tem uma célula. A leitura da BASE tem célula própria e publica `BASE.sqlite` com os agregados no HDFS. Q00, Q02, Q03, Q04, Q09 e Q11 usam essa base. Para regenerar Q03 após reabrir a pasta, execute a inicialização e a célula Q03. Para repetir Q05 após falha, execute a célula Q05. A operação reinicia as próprias faixas. Os outros CSVs concluídos continuam disponíveis.

Durante o JDBC, o driver atualiza `Progresso.json` antes e depois de cada faixa. O JupyterLab lê esse arquivo pelo BBMagic a cada 15 segundos e mostra a etapa, a faixa corrente, as partições concluídas, as consultas concluídas e o tempo transcorrido. A célula de inicialização testa essa rota independente. O arquivo pode ser consultado também no navegador HDFS enquanto o Livy estiver ocupado. Um registro com horário inalterado identifica a última transição conhecida. O Db2 pode continuar processando a mesma instrução. Diagnóstico de espera ou bloqueio interno requer observabilidade do próprio Db2.

Cada CSV é publicado assim que a consulta termina. `Resumo.json` registra horários UTC, linhas agregadas, transações representadas, arquivo, duração e falhas com SQLSTATE/SQLCODE quando disponíveis. Em Q08 o contador de transações exibido representa os originais. Os derivados têm medidas próprias no CSV. Q10 conta todo o seu universo e os controles aplicam o recorte comum. A BASE concluída permanece no HDFS. Uma falha JDBC tratada conserva as faixas integralmente lidas com indicação parcial. A perda abrupta do driver durante uma etapa pode exigir repetir essa etapa.

As três últimas células validam, apresentam a tabela das 13 saídas e publicam o ZIP. Podem ser executadas usando a pasta reaberta, sem JDBC. O ZIP contém os CSVs disponíveis, SQLs, parâmetros e resumo com os controles. Pendências, erros ou divergências identificam um ZIP **PARCIAL**. CSVs parciais são nomeados explicitamente. Os intermediários permanecem na pasta privada para consulta e regeneração.

## Carga e desempenho

| Partições por leitura | Instruções JDBC numa execução completa nova | Acesso |
|---:|---:|---|
| 1 (inicial) | 404 | Uma faixa física por instrução das quatro operações particionadas |
| 5 | 84 | Vinte grupos contíguos por operação particionada |
| 100 | 8 | Uma instrução integral por operação |

BASE, Q05, Q06 e Q10 cobrem a chave não nula `NR_PTC`, incluindo os extremos documentados. Q01, Q01B, Q07 e Q08 leem uma vez cada. A BASE fornece seis saídas. O processamento é sequencial com READ_COMMITTED. Comparações entre instruções podem refletir alterações concorrentes na origem.

A configuração inicial conserva a granularidade anterior. Na simulação local, os três tamanhos produziram os mesmos 13 CSVs. A quantidade de instruções é conhecida; o tempo no servidor depende do plano, da concorrência e da poda de partições. Para comparar carga corporativa, use pastas separadas no mesmo recorte estável, comece com uma operação e compare duração, linhas, totais, falhas e GETPAGE/CPU se disponíveis. `bytes_agregados_driver` mede espaço do SQLite local incluindo sua estrutura. As linhas agregadas medem cardinalidade transferida. Nenhuma das duas medidas é tráfego de rede medido. O balanço separa cobertura por operação, processamento acumulado e tempo de calendário desde a abertura da pasta.

Para estudar **IN_VSLO_CSM**, comece pela Q03. Compare categorias, tipos, produtos e naturezas por valor do indicador e pelos cinco indicadores restantes. Q04 permite conferir as quantidades e os valores dos cenários de retenção.

