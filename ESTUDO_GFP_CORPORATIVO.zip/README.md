# Estudo dos indicadores transacionais do GFP — aplicabilidade ao Radar Financeiro

**Instalação da distribuição** — Extraia o pacote na raiz do projeto, abra `ESTUDO_RADAR.ipynb` e execute **Run All**. O modo inicial de homologação usa seis sondas JDBC, publica o ZIP e valida a cópia local. [Guia de instalação e diagnóstico](02_DOCUMENTACAO/Entrega_Run_All.md) · [Testes desta revisão](02_DOCUMENTACAO/Testes_Run_All.md)

**Estado:** investigação aberta; nenhum filtro novo homologado.  
**Objetivo:** descobrir exatamente o que cada indicador original do GFP sinaliza, mantém e remove, e decidir se, quando e por que deve ser aplicado ao Radar Financeiro.

## 1. Escopo exclusivo

Tabela principal: `DB2GFP.TRAN_RLZD_INST_PCT`.

| Indicador | Finalidade documentada a verificar nas fontes | Condição a investigar |
|---|---|---|
| `IN_VSLO_CSM` | Visualização no perfil de consumo | `= 'S'` |
| `IN_VSLO_CX` | Visualização no fluxo de caixa | `= 'S'` |
| `IN_VSLO_EVT` | Visualização nos eventos | `= 'S'` |
| `IN_DVS_LCTO` | Divisão de lançamento | `= 'N'` |
| `IN_OCTR_TRAN` | Ocultação de transação | `= 'N'` (comparar com `<> 'S'` do GFP) |
| `IN_TRAN_IR` | Marcação para Imposto de Renda | `= 'S'` (somente diagnóstico) |

Para cada indicador, responder: definição, domínio, tipo, default, finalidade, condições de leitura no GFP, lógica de atribuição (se encontrada), quais operações recebem cada valor, quais ficam e quais saem pelo filtro, quantidade e valor afetados, diferenças entre naturezas/produtos/tipos/categorias, interações, exceções, recomendação e justificativa para o Radar. Distinguir `S`/`N` de valores inesperados. Não presumir que visibilidade implica validade econômica.

**Não faz parte do estudo:** redesenhar a arquitetura, revisar orçamento, classes essenciais/não essenciais, classificação tributária, patrimônio, matriz de categorias ou algoritmo de reconciliação. Usar essas informações somente quando necessárias para interpretar um indicador. O mapa Radar é apoio descritivo, não verdade de origem nem um filtro do estudo. Não alterar a regra `QT_MOV_CICLO` antes da conclusão.

## 2. Fontes e organização

- `01_FONTES/`: originais ERwin, SYSIBM, código Java/SQL GFP, notebook Radar e mapa de categorias fornecido na conversa. O mapa é referência auxiliar; verificar sua correspondência com o tesauro real.
- `02_DOCUMENTACAO/`: documentos anteriores, preservados para rastreabilidade. Este README prevalece em caso de divergência de escopo.
- `03_CONSULTAS/`: arquivo consolidado original e consultas separadas por ID e prioridade. Não executar duas vezes por existirem as duas apresentações.
- `04_RESULTADOS_DB2/`: destino dos CSVs e manifesto de execução.
- `05_CONCLUSOES/`: modelos para preencher após a investigação, não resultados já validados.

O `tran.txt` mostra principalmente a lógica de leitura. Para comprovar a atribuição dos indicadores, procurar também rotinas de INSERT, UPDATE, MERGE, classificação, sincronização e respectivas regras de negócio. Se encontradas, incluir em `01_FONTES/` sem modificar os originais.

## 3. Universo, período e premissas

- O período inicial cobre o último dia civil completo, de ontem inclusive a hoje exclusivo. Ajuste as duas datas no notebook para qualquer duração positiva. Para um único dia, informe a data desejada e o dia seguinte.
- O último dia incluído deve ser anterior ou igual à data atual da sessão Spark. Ao incluir o dia corrente, o resultado reflete as transações disponíveis no momento da leitura. As 11 consultas transacionais usam os dois limites na CTE `P`, inclusive para originais e derivados da Q08. Q01 e Q01B consultam cadastros.
- Em AMOSTRAL, a população é a seleção autorizada de MCIs. Em CENSITARIO, o universo integral ou o recorte de segmentos requer autorização explícita. Universo principal: produtos 6 e 9, `CD_EST_TRAN_INST = 0`, `CD_TIP_MOE_CRR = 'BRL'`, `DT_TRAN` no período.
- Não aplicar previamente nenhum dos seis indicadores. Não aplicar a regra atual do Radar, reconciliação ou elegibilidade pelo mapa na extração principal.
- Categorias, grupos, tipos, complementos de CC/cartão e instituições são meios de identificação, não filtros antecipados. Preservar casos desconhecidos e valores inesperados.
- Resultados agregados; não enviar CPF, MCI, número de conta/cartão, IDs transacionais ou descrição livre. Os arquivos-fonte podem conter identificadores ou código interno: manter em ambiente autorizado, revisar antes de compartilhar.
- Q07/Q08 analisam outra tabela ou relacionamento com o original; Q10 expande o universo. Não somar seus totais ao universo principal.

## 4. Ordem de execução e retorno esperado

O notebook executa as leituras em sequência e exporta resultados agregados com cabeçalhos. A matriz de correspondência identifica as saídas que compartilham a base e as consultas com leitura própria. [Notebook de execução](ESTUDO_RADAR.ipynb) · [Matriz e guia de operação](02_DOCUMENTACAO/Operacao_Estudo_Otimizado.md) · [Caderno técnico](02_DOCUMENTACAO/Estudo_Indicadores_GFP_Radar.md)

| ID | Prioridade | Resultado esperado / questão respondida |
|---|---|---|
| Q00 | Principal | Uma linha de controle do período, quantidade e valores; referência para conciliar as consultas. |
| Q01 | Apoio principal | Cadastro de categorias, natureza e grupos; identifica a natureza das operações. |
| Q01B | Apoio principal | Cadastro dos grupos, inclusive 13; esclarece o filtro de grupo do GFP. |
| Q02 | Principal | Combinações reais dos seis indicadores, quantidade e valores; inclui padrões raros. |
| Q03 | Essencial | Matriz por produto, natureza, tipo, categoria atual/original e indicadores; identifica exatamente quais classes de lançamentos ficam e saem. |
| Q04 | Essencial | Impacto isolado e combinado dos filtros; quantifica retenção e exclusão. |
| Q05 | Principal | Detalhamento de cartão: tipo, categoria, parcelamento e indicadores; diferencia compras, parcelas, pagamentos e demais representações. |
| Q06 | Principal | Detalhamento de conta corrente por tipos, históricos e possível mesma titularidade; sem expor identificadores. |
| Q07 | Principal (DVS) | Lançamentos incluídos pelo cliente, manuais e derivados; demonstra o universo relacionado à divisão. |
| Q08 | Principal (DVS) | Correspondência entre originais divididos e derivados; mede risco de perder registros ao aplicar DVS. |
| Q11 | Principal (IR) | Relação entre `IN_TRAN_IR` e `CD_TRAN_IR`, quantidade e valor; verifica o uso tributário. |
| Q09 | Complementar | Diferenças por instituição; usar se necessário para explicar divergências. |
| Q10 | Complementar | Estado, moeda e produto fora do escopo principal; usar se necessário para explicar exceções. |
| Q12 | Fora do escopo inicial | Indicadores de visualização de contas; preservado apenas por rastreabilidade. Não executar nesta etapa. |

### Executar, auditar e retomar

Abra `ESTUDO_RADAR.ipynb` na raiz do projeto. A primeira execução usa HOMOLOGACAO, publica um pacote sintético no HDFS e confere a cópia no JupyterLab. Para investigar, escolha AMOSTRAL, informe a população autorizada, selecione as consultas e comece com um dia. AUDITORIA executa as referências independentemente e compara cada saída. CENSITARIO requer autorização explícita de carga.

O notebook publica um ZIP por tentativa com a situação funcional, os CSVs disponíveis, SQLs com marcadores, métricas, manifesto, notebook sanitizado e módulo. Os checkpoints privados permitem retomar unidades concluídas. O número de arquivos varia com a seleção, a cobertura e o modo de execução.

- [Guia de operação, correspondência entre consultas, atualização e homologação](02_DOCUMENTACAO/Operacao_Estudo_Otimizado.md)
- [Relatório das alterações e testes locais](02_DOCUMENTACAO/Validacao_Estudo_Otimizado.md)
- [Dicionário físico consolidado da tabela principal](DB2GFP_TRAN_RLZD_INST_PCT_documentacao_final.md)

## 5. Metodologia de análise

1. **Documental:** confirmar definições, valores, defaults e exemplos em ERwin/SYSIBM. Registrar divergências.
2. **Código:** localizar os filtros efetivos e separar critérios de leitura de regras de atribuição; conferir natureza, produto, união de originais e derivados e filtros adicionais.
3. **Empírica:** observar todas as combinações e distribuições, por tipo/categoria/produto/natureza. Identificar padrões e exceções, inclusive valores fora do domínio esperado.
4. **Exclusão:** comparar universo sem filtro versus cada condição e combinações. Identificar exatamente quais classes são mantidas/removidas, quantidade, valor registrado e valor absoluto; não confundir soma de valores registrados com saldo, renda ou consumo. Exclusões podem se sobrepor.
5. **Exceções:** examinar divergências dentro de uma mesma categoria; solicitar complementos somente quando necessários. Padrão empírico não comprova causalidade nem regra de atribuição.
6. **Aplicabilidade:** decidir por indicador entre aplicar integralmente, condicionalmente, não aplicar, apenas informativo ou pendente. Especificar condição SQL e justificativa, inclusive riscos de perder possíveis contrapartes da reconciliação.

## 6. Critérios de qualidade e validação

- Conciliação de totais de Q00, Q02, Q03 e Q04 quando os universos são idênticos; verificar multiplicação por joins e distinguir totais específicos. Q00 sem dados deve ser interpretada como janela vazia, não inexistência universal de casos.
- Conferir domínio e exceções; documentar valores inesperados, categorias sem correspondência e divergência de natureza.
- Separar evidência documental (catálogo/código), empírica (DB2, período observado), inferência, hipótese e pendência. Citar arquivo/trecho/consulta e período em cada conclusão.
- Distinguir exclusão por indicador, neutralização por reconciliação e exclusão por outra condição. Não somar exclusões sobrepostas.
- Não tratar uma janela sem ocorrência como prova de inexistência da situação.
- SQLs não executados; registrar versão, isolamento e eventuais alterações. As consultas com `WITH UR` são exploratórias; homologação requer consistência de leitura adequada ao ambiente.

## 7. Entregáveis de encerramento

- Dicionário técnico dos seis indicadores com fontes e limitações.
- Matriz de combinações observadas e operações mantidas/removidas.
- Impacto quantitativo e financeiro dos filtros.
- Exceções, divergências e pendências.
- Matriz de decisão por indicador, com aplicabilidade, condição e justificativa.
- Proposta de SQL final para o Radar apenas depois de fundamentadas as decisões.

**Critério de conclusão:** saber o que cada indicador efetivamente sinaliza, o que sua aplicação mantém/remove dentro do escopo observado, como se combina com outros indicadores e por que deve ou não ser utilizado no Radar. Lacunas devem permanecer explícitas. Não avançar para revisão de regras paralelas.
