"""Dublês locais de JVM/JDBC, filesystem e Sparkmagic. Os métodos JDBC da V3 são os distribuídos."""

import hashlib
import json
import os
import shutil
import sqlite3
import sys
from contextlib import contextmanager
from datetime import date
from pathlib import Path
from types import ModuleType
from types import SimpleNamespace as NS
from unittest.mock import patch
from urllib.parse import urlsplit
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
from src.utils import estudo_indicadores_gfp as g


class FalhaJDBC(Exception):
    def __init__(self, estado="42601", codigo=-104):
        super().__init__("Falha SQLERRMC=31,2; dados confidenciais: VALOR_SENSIVEL")
        self.java_exception = NS(getSQLState=lambda: estado, getErrorCode=lambda: codigo)


class Resultado:
    def __init__(self, cursor):
        self.cols = [d[0] for d in cursor.description]
        self.rows = iter(cursor.fetchall())
        self.closed = False

    def getMetaData(self):
        return NS(
            getColumnCount=lambda: len(self.cols),
            getColumnLabel=lambda i: self.cols[i - 1],
            getColumnType=lambda i: 3 if self.cols[i - 1] == "VL_TESTE" else 12,
        )

    def next(self):
        self.row = next(self.rows, None)
        return self.row is not None

    def getString(self, i):
        return None if self.row[i - 1] is None else str(self.row[i - 1])

    def close(self):
        self.closed = True


class Statement:
    def __init__(self, env, sql):
        self.env, self.sql, self.binds, self.closed = env, sql, [], False
        self.result = None

    def setQueryTimeout(self, n):
        assert n > 0
        self.timeout = n

    def setFetchSize(self, n):
        assert n > 0

    def setInt(self, i, val):
        assert i == len(self.binds) + 1 and type(val) is int
        self.binds.append(val)

    def executeQuery(self, *args):
        assert len(args) == int(self.sql is None)
        sql = self.sql if self.sql is not None else args[0]
        self.env.calls.append((sql, tuple(self.binds)))
        if self.env.falhar:
            self.env.falhar(sql, self.binds)
        if sql == g.SINTETICO_ANTERIOR and self.env.virgula_decimal:
            raise FalhaJDBC()
        sql = sql.replace("COUNT_BIG(", "COUNT(")
        self.result = Resultado(self.env.sqlite.execute(sql, self.binds))
        return self.result

    def close(self):
        self.closed = True


class Conexao:
    def __init__(self, env):
        self.env, self.closed, self.stmts = env, False, []
        self.readonly = self.auto = False
        self.isolation = 0

    def setReadOnly(self, flag):
        self.readonly = flag and self.env.aceita_readonly

    def isReadOnly(self):
        return self.readonly

    def setAutoCommit(self, flag):
        self.auto = flag

    def getAutoCommit(self):
        return self.auto

    def setTransactionIsolation(self, n):
        self.isolation = n

    def getTransactionIsolation(self):
        return self.isolation

    def getMetaData(self):
        return NS(getDriverVersion=lambda: "4.19.26", getDatabaseProductVersion=lambda: "DSN13018")

    def prepareStatement(self, sql):
        stmt = Statement(self.env, sql)
        self.stmts.append(stmt)
        return stmt

    def createStatement(self):
        return self.prepareStatement(None)

    def close(self):
        self.closed = True


class Disco:
    def __init__(self, raiz, diretorio_base=None):
        self.raiz = raiz
        self.base = diretorio_base or "hdfs://sim/home"
        self.path(".").mkdir(parents=True, exist_ok=True)

    def path(self, nome):
        uri = nome if str(nome).startswith("hdfs://") else self.base + "/" + str(nome)
        return self.raiz / urlsplit(uri).path.lstrip("/")

    def criar_diretorio(self, nome, existir_ok=False):
        p = self.path(nome)
        p.mkdir(exist_ok=existir_ok)
        return "hdfs://sim/" + p.relative_to(self.raiz).as_posix()

    def salvar_texto(self, nome, conteudo):
        with self.abrir_escrita(nome) as f:
            f.write(conteudo)

    def abrir_escrita(self, nome):
        return self.path(nome).open("x", encoding="utf8", newline="")

    def ler_texto(self, nome):
        return self.path(nome).read_text(encoding="utf8")

    def copiar_do_driver(self, arquivo, nome):
        assert not self.existe(nome)
        shutil.copyfile(arquivo, self.path(nome))

    def copiar_para_driver(self, nome, arquivo):
        shutil.copyfile(self.path(nome), arquivo)

    def existe(self, nome):
        return self.path(nome).exists()

    def remover(self, nome, recursivo=False):
        p = self.path(nome)
        if not p.is_dir():
            p.unlink()
        elif recursivo:
            shutil.rmtree(p)
        else:
            p.rmdir()
        return True

    def compactar_zip(self, nomes, destino):
        p = self.path(destino)
        with ZipFile(p, "x", ZIP_DEFLATED) as z:
            for nome in nomes:
                z.write(self.path(nome), nome)
        with ZipFile(p) as z:
            assert z.testzip() is None and sorted(z.namelist()) == sorted(nomes)
        return dict(
            arquivos=nomes,
            caminho=self.base + "/" + destino,
            sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
        )


class Ambiente:
    def __init__(self, pasta):
        self.pasta, self.calls, self.connections = Path(pasta), [], []
        self.aceita_readonly = self.virgula_decimal = True
        self.falhar = None
        self.sqlite = sqlite3.connect(":memory:")
        for schema in ("SYSIBM", "DB2GFP"):
            self.sqlite.execute(f"ATTACH ':memory:' AS {schema}")
        self.sqlite.execute("CREATE TABLE SYSIBM.SYSDUMMY1 (v INT)")
        self.sqlite.execute("INSERT INTO SYSIBM.SYSDUMMY1 VALUES (1)")
        self.sqlite.create_function("DECIMAL", 3, lambda v, p, s: v)
        self.sqlite.create_function("DAYS", 1, lambda d: date.fromisoformat(d).toordinal())
        self.cols = [
            "CD_CLI",
            "DT_TRAN",
            "NR_TRAN_INST_PCT",
            "VL_TRAN",
            "CD_EST_TRAN_INST",
            "CD_TIP_MOE_CRR",
            *g.BASE_Q03,
        ]
        self.sqlite.execute("CREATE TABLE DB2GFP.TRAN_RLZD_INST_PCT (" + ", ".join(self.cols) + ")")
        jvm = NS(
            java=NS(
                lang=NS(Class=NS(forName=lambda name: NS(newInstance=lambda: NS(connect=self.connect)))),
                util=NS(Properties=lambda: NS(setProperty=lambda k, v: None)),
                sql=NS(Connection=NS(TRANSACTION_READ_COMMITTED=2)),
            )
        )
        self.spark = NS(
            _jvm=jvm,
            version="3.5.4",
            sql=lambda q: NS(first=lambda: (date.today(),)),
            createDataFrame=lambda rows, schema: rows,
        )
        self.remote = {"spark": self.spark}
        self.carregar("gerenciador_db2_spark_v3")

    def transacao(self, cliente, data="2024-02-01", valor=1, flags=("S", "N", "N", "N", "N", "S")):
        row = (cliente, data, 1, valor, 0, "BRL", 6, "D", 7, 8, 9, *flags)
        self.sqlite.execute(
            "INSERT INTO DB2GFP.TRAN_RLZD_INST_PCT ("
            + ",".join(self.cols)
            + ") VALUES ("
            + ",".join("?" for x in row)
            + ")",
            row,
        )

    def connect(self, url, props):
        conn = Conexao(self)
        self.connections.append(conn)
        return conn

    def db(self):
        env = {k: "teste" for k in ("DB2_HOST", "DB2_DATABASE", "DB2_USER", "DB2_PASSWORD")}
        env["DB2_PORTA"] = "123"
        return self.remote["criar_conector_db2_spark"](env=env)

    def hdfs(self, diretorio_base=None):
        return Disco(self.pasta, diretorio_base)

    def carregar(self, nome):
        p = ROOT / "src/utils" / (nome + ".ipynb")
        mods = {
            k: ModuleType(k) for k in ("pyspark", "pyspark.sql", "pyspark.sql.functions", "pyspark.sql.types")
        }
        mods["pyspark.sql"].DataFrame = mods["pyspark.sql"].SparkSession = object
        mods["pyspark.sql.types"].StructType = mods["pyspark.sql.types"].DataType = object
        mods["pyspark.sql"].functions = mods["pyspark.sql.functions"]
        with patch.dict(sys.modules, mods):
            for c in json.loads(p.read_text(encoding="utf8"))["cells"]:
                if c["cell_type"] == "code":
                    src = "".join(c["source"]).split("%%spark\n", 1)[-1]
                    exec(compile(src, str(p), "exec"), self.remote)

    def config(self, modo="HOMOLOGACAO", qs=("Q00", "Q02", "Q03", "Q04")):
        return dict(
            modo=modo,
            inicio="2024-02-01",
            fim="2024-02-02",
            consultas=list(qs),
            lote=1,
            particoes=[],
            experimental=False,
            autorizar_censo=False,
            orcamento=120,
            retomar=None,
            destino=None,
            timeout_transacoes=30,
            timeout_cadastros=30,
        )

    def run(self, c, clientes=()):
        qs, plano = g.preparar_plano(ROOT / "03_CONSULTAS", c)
        fontes = {
            g.FONTES_PACOTE[0]: g.preparar_notebook(ROOT, g.REVISAO),
            g.FONTES_PACOTE[1]: Path(g.__file__).read_text(encoding="utf8"),
        }
        recibo = {}
        g.executar_estudo(
            self.db, qs, c, fontes, self.hdfs, recibo, plano=plano, clientes=clientes, sessao_spark=self.spark
        )
        caminho = self.hdfs().path(recibo["caminho"])
        with ZipFile(caminho) as z:
            assert (
                z.testzip() is None and hashlib.sha256(caminho.read_bytes()).hexdigest() == recibo["sha256"]
            )
            arquivos = {n: z.read(n).decode() for n in z.namelist()}
        d = json.loads(arquivos["Execucao.json"])
        assert set(d["inventario"]) == set(arquivos)
        return d, arquivos


class Tabela:
    def __init__(self, rows):
        self.iloc = rows

    def __len__(self):
        return len(self.iloc)


@contextmanager
def kernel(amb, pasta, opcoes=None):
    """Dois namespaces, magias %run/%%spark/-o, upload/download BBMagic em disco temporário."""
    local, rem = {}, amb.remote

    class Magic:
        def run_cell_magic(self, magic, opts, code):
            assert magic == "spark"
            exec(compile(code, "<livy-simulado>", "exec"), rem)
            if opts:
                name = opts.split()[1]
                rows = rem[name]
                local[name] = Tabela([{"pasta": r[0]} if isinstance(r, tuple) else r for r in rows])

    class Hdfs:
        def __init__(self, *args, **kwargs):
            pass

        def download(self, nome, local_path, overwrite):
            assert not overwrite
            shutil.copyfile(amb.pasta / nome.lstrip("/"), local_path)
            if getattr(amb, "corromper_download", False):
                with open(local_path, "ab") as f:
                    f.write(b"danificado")

        def upload(self, hdfs_path, local_path, overwrite):
            assert not overwrite
            shutil.copyfile(local_path, amb.pasta / hdfs_path.lstrip("/"))

    fake = ModuleType("src.utils.gerenciador_local_v2")
    fake.GerenciadorLocal = lambda **kw: NS(keytab=None, criar_sessao_spark=lambda **k: amb.spark)
    magic = Magic()
    local["get_ipython"] = lambda: magic
    bb = ModuleType("bbmagic")
    bb.Hdfs = Hdfs
    cwd = Path.cwd()
    os.chdir(pasta)
    try:
        with patch.dict(
            sys.modules, {"src.utils.gerenciador_local_v2": fake, "bbmagic": bb, "ipywidgets": None}
        ):
            yield local
            cells = json.loads(Path("ESTUDO_RADAR.ipynb").read_text(encoding="utf8"))["cells"]
            for i, c in enumerate(cells):
                if c["cell_type"] != "code":
                    continue
                src = "".join(c["source"])
                if src.startswith("%run "):
                    for linha in src.splitlines():
                        amb.carregar(Path(linha[5:]).stem)
                    db_real = amb.remote["criar_conector_db2_spark"]
                    env = {
                        k: "teste"
                        for k in ("DB2_HOST", "DB2_DATABASE", "DB2_USER", "DB2_PASSWORD", "DB2_PORTA")
                    }
                    rem.update(
                        criar_gerenciador_hdfs_spark=amb.hdfs,
                        criar_conector_db2_spark=lambda: db_real(env=env),
                    )
                else:
                    exec(compile(src, f"<cell-{i}>", "exec"), local)
                if i == 5:
                    local.update(opcoes or {})
    finally:
        os.chdir(cwd)
