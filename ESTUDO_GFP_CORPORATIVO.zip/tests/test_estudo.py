import csv
import hashlib
import io
import json
import shutil
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import date, timedelta
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile

from simulacao import ROOT, Ambiente, FalhaJDBC, g, kernel


class Estudo(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(tmp.cleanup)
        self.tmp = Path(tmp.name)
        self.log = io.StringIO()
        contexto = redirect_stdout(self.log)
        contexto.__enter__()
        self.addCleanup(contexto.__exit__, None, None, None)
        self.env = Ambiente(self.tmp / "hdfs")
        self.addCleanup(self.env.sqlite.close)

    def test_periodo(self):
        for dias in (1, 2, 5, 7, 15, 30, 450):
            g.validar_periodo("2020-01-01", str(date(2020, 1, 1) + timedelta(days=dias)), self.env.spark)
        for ini, fim in [
            ("2025-02-29", "2025-03-01"),
            ("2020-01-01", "2020-01-01"),
            ("2090-01-01", "2090-02-01"),
        ]:
            with self.assertRaises(ValueError):
                g.validar_periodo(ini, fim, self.env.spark)

    def test_todos_modelos_e_marcadores(self):
        db = self.env.db()
        for q in g.TODAS:
            c = self.env.config("AMOSTRAL", [q])
            qs, plano = g.preparar_plano(ROOT / "03_CONSULTAS", c)
            self.assertEqual(list(qs), [q])
            for lote, op, sql, binds, _ in g.unidades(plano, c, [42, 43]):
                canon = g.sql_jdbc(db, sql, binds)
                self.assertEqual(db._normalizar_sql(canon), canon)
                self.assertNotIn("{filters}", canon)
                if q not in g.CADASTROS and op == q:
                    self.assertIn("T.CD_CLI IN (", canon)
                    self.assertIn(c["fim"], canon)
                    self.assertIn(c["inicio"], canon)
        self.assertEqual(len(g.TODAS), 13)
        self.assertNotIn("Q12", g.TODAS)

    def test_literal_identificador_e_aridade(self):
        db = self.env.db()
        sql = """SELECT 'a,b?''x' AS "x,?", DECIMAL(?,31,2) AS V FROM SYSIBM.SYSDUMMY1 /* ? */;"""
        canon = g.sql_jdbc(db, sql, [1])
        self.assertIn("""'a,b?''x' AS "x,?", DECIMAL(?, 31, 2)""", canon)
        for args in ([], [1, 2], [True], [2**32]):
            with self.assertRaises(g.ErroValidacao):
                g.sql_jdbc(db, sql, args)

    def test_homologacao_e_sql_exato(self):
        d, arq = self.env.run(self.env.config())
        self.assertEqual(d["situacao_funcional"], "COMPLETO")
        self.assertEqual(len(self.env.calls), len(g.SONDAS))
        for (sql, binds), ev in zip(self.env.calls, d["operacoes"]):
            self.assertEqual(sql, arq[ev["sql"]])
            self.assertEqual(hashlib.sha256(sql.encode()).hexdigest(), ev["sql_sha256"])
            self.assertNotIn("DB2GFP.", sql)
            self.assertEqual(ev["marcadores"], len(binds))
            self.assertEqual(ev["linhas"], 1)
            self.assertTrue(all(ev["conexao"].values()))
        self.assertEqual(self.env.calls[4][1], (7,))
        self.verificar_fechamento()

    def verificar_fechamento(self):
        for conn in self.env.connections:
            self.assertTrue(conn.closed)
            for stmt in conn.stmts:
                self.assertTrue(stmt.closed)
                if stmt.result:
                    self.assertTrue(stmt.result.closed)

    def test_diferencial_historico(self):
        c = self.env.config()
        c["historico"] = {"corresponde_ao_sql_anterior": True}
        for rejeitar in (True, False):
            self.env.virgula_decimal = rejeitar
            d, _ = self.env.run(c)
            ab = d["operacoes"][-1]["comparacao_sintaxe"]
            self.assertEqual(ab.get("sqlcode"), -104 if rejeitar else None)
            self.assertEqual(d["situacao_funcional"], "COMPLETO")

    def test_historico_verifica_arquivo(self):
        self.assertIn("Indisponível", g.verificar_historico(self.tmp)["estado"])
        nome = "TESTE_" + "a" * 16 + ".sql"
        p = self.tmp / g.HISTORICO_NOME
        with ZipFile(p, "w") as z:
            z.writestr(nome, g.SINTETICO_ANTERIOR)
            z.writestr(g.MANIFESTO, "SEM_RESULTADOS")
            z.writestr(
                "Execucao.json",
                json.dumps({"operacoes": [{"operacao": "TESTE", "sql": nome, "diagnostico": "42601 -104"}]}),
            )
        self.assertIn("divergente", g.verificar_historico(self.tmp)["estado"])
        with patch.object(g, "HISTORICO_SHA", hashlib.sha256(p.read_bytes()).hexdigest()):
            info = g.verificar_historico(self.tmp)
            self.assertTrue(info["corresponde_ao_sql_anterior"] and info["registro_42601_menos104"])

    def test_readonly_bloqueia_extracao(self):
        self.env.aceita_readonly = False
        d, _ = self.env.run(self.env.config("AMOSTRAL"), [51])
        self.assertEqual(d["situacao_funcional"], "SEM_RESULTADOS")
        self.assertFalse(self.env.calls)
        self.assertTrue(all(e["estado"].startswith("Bloqueada") for e in d["operacoes"][1:]))
        self.verificar_fechamento()

    def test_conexao_inicial(self):
        with patch.object(self.env, "connect", side_effect=FalhaJDBC("08001", -1)):
            d, _ = self.env.run(self.env.config())
        self.assertEqual(d["operacoes"][0]["sqlstate"], "08001")
        self.assertFalse(self.env.calls)

    def test_sintaxe_sql_sanitizado(self):
        def falha(sql, params):
            if params:
                raise FalhaJDBC()

        self.env.falhar = falha
        d, a = self.env.run(self.env.config("AMOSTRAL"), [99872211])
        ev = next(e for e in d["operacoes"] if e.get("sqlcode") == -104)
        self.assertIn("?", ev["sql_sanitizado"])
        self.assertEqual(ev["etapa"], "execução JDBC")
        for v in (self.log.getvalue(), *a.values()):
            self.assertNotIn("99872211", v)
            self.assertNotIn("VALOR_SENSIVEL", v)
        self.verificar_fechamento()

    def test_consolidacao_e_auditoria(self):
        self.env.transacao(101, valor=-2.25)
        self.env.transacao(102, valor=1.25, flags=("N", None, "S", "N", "S", "S"))
        self.env.transacao(101, data="2024-02-02", valor=50)
        self.env.transacao(103, valor=50)
        d, a = self.env.run(self.env.config("AUDITORIA"), [101, 102])
        self.assertEqual(d["comparacao_independente"], dict.fromkeys(("Q00", "Q02", "Q03", "Q04"), "OK"))
        self.assertEqual(d["situacao_funcional"], "COMPLETO")
        self.assertEqual(d["cobertura"]["com_dados"], 2)
        row = next(csv.DictReader(io.StringIO(a["Q00.csv"]), delimiter=";"))
        self.assertEqual((row["QT_TRAN"], row["VL_TOTAL"], row["VL_ABS"]), ("2", "-1.00", "3.50"))
        self.assertIn(r"\N", a["Q02.csv"])
        self.assertFalse(any(x[1] == "DIVERGÊNCIA" for x in d["controles"]))

    def test_vazio(self):
        d, a = self.env.run(self.env.config("AUDITORIA"), [101])
        self.assertEqual(d["situacao_funcional"], "COMPLETO")
        self.assertEqual(d["consultas"]["Q03"], "Vazia")
        self.assertEqual(d["cobertura"]["sem_dados"], 1)
        self.assertEqual(len(a["Q00.csv"].splitlines()), 2)
        self.assertEqual(set(d["comparacao_independente"].values()), {"OK"})

    def test_falha_e_retomada_sem_duplicar(self):
        for cliente in [101, 102]:
            self.env.transacao(cliente)
        c = self.env.config("AMOSTRAL")

        def perder(sql, params):
            if "MIN(T.DT_TRAN)" in sql and params == [101]:
                raise FalhaJDBC("08006", -4499)

        self.env.falhar = perder
        d, _ = self.env.run(c, [101, 102])
        self.assertEqual(d["situacao_funcional"], "PARCIAL")
        self.assertEqual(d["cobertura"]["com_falhas"], 1)
        self.verificar_fechamento()
        self.env.calls.clear()
        self.env.falhar = None
        c["retomar"] = d["retomada"]
        d, a = self.env.run(c, [101, 102])
        self.assertEqual(d["situacao_funcional"], "COMPLETO")
        self.assertEqual(len([s for s, b in self.env.calls if "DB2GFP." in s]), 1)
        self.assertIn(";2;2.00;2.00", a["Q00.csv"])

    def test_timeout(self):
        self.env.falhar = lambda s, b: (_ for _ in ()).throw(FalhaJDBC("57014", -905))
        d, _ = self.env.run(self.env.config())
        self.assertEqual(d["operacoes"][0]["estado"], "Timeout")
        self.verificar_fechamento()

    def test_opcoes_seguras(self):
        for modo in ("CENSITARIO", "AUDITORIA", "AMOSTRAL"):
            with self.assertRaises(ValueError):
                g.validar_config(self.env.config(modo), 0)
        c = self.env.config("AMOSTRAL")
        c["experimental"] = True
        c["particoes"] = [1]
        with self.assertRaises(ValueError):
            g.validar_config(c, 1)

    def run_all(self, opts=None, corromper=False, sem_modulo=False):
        local = self.tmp / "lab"
        local.mkdir()
        for n in ("ESTUDO_RADAR.ipynb", "Inventario.json"):
            shutil.copyfile(ROOT / n, local / n)
        for n in ("src", "03_CONSULTAS"):
            shutil.copytree(ROOT / n, local / n, ignore=shutil.ignore_patterns("__pycache__"))
        if sem_modulo:
            (local / "src/utils/estudo_indicadores_gfp.py").unlink()
        if corromper:
            with (local / "03_CONSULTAS/01_PRINCIPAIS/Q05.sql").open("a") as f:
                f.write("\n-- mistura de revisões")
        with kernel(self.env, local, opts):
            pass
        receipt = json.loads(next(local.glob("*.recibo.json")).read_text(encoding="utf8"))
        p = Path(receipt["jupyterlab"])
        self.assertEqual(receipt["sha256"], hashlib.sha256(p.read_bytes()).hexdigest())
        with ZipFile(p) as z:
            self.assertIsNone(z.testzip())
            return json.loads(z.read("Execucao.json")), receipt

    def test_run_all_completo(self):
        d, r = self.run_all()
        self.assertEqual(r["situacao"], "COMPLETO")
        self.assertEqual(len(d["sondas"]), 6)

    def test_run_all_diagnostico_sem_resultados(self):
        self.env.aceita_readonly = False
        d, r = self.run_all()
        self.assertEqual(r["situacao"], "SEM_RESULTADOS")
        self.assertIn("Erro", d["sondas"].values())

    def test_run_all_impede_revisoes_mistas(self):
        d, r = self.run_all(corromper=True)
        self.assertEqual(r["situacao"], "SEM_RESULTADOS")
        self.assertFalse(self.env.calls)
        self.assertIn("Revisões incompatíveis", d["operacoes"][0]["mensagem"])

    def test_run_all_amostra(self):
        self.env.transacao(101)
        d, r = self.run_all(
            dict(
                modo="AMOSTRAL",
                data_inicial="2024-02-01",
                data_final_exclusiva="2024-02-02",
                mcis_autorizados=[101],
            )
        )
        self.assertEqual(r["situacao"], "COMPLETO")
        self.assertEqual(d["cobertura"]["processados"], 1)
        self.assertEqual(d["leituras_por_consulta"]["Q00"]["operacao"], "BASE")

    def test_run_all_sem_modulo(self):
        d, r = self.run_all(sem_modulo=True)
        self.assertEqual(r["situacao"], "SEM_RESULTADOS")
        self.assertIn("integridade e revisão do módulo", d["operacoes"][0]["mensagem"])
        self.assertFalse(self.env.calls)

    def test_download_corrompido(self):
        self.env.corromper_download = True
        with self.assertRaisesRegex(RuntimeError, "SHA-256 divergente"):
            self.run_all()
        self.assertFalse(list((self.tmp / "lab").glob("*.zip")))
        self.assertEqual(len(list((self.tmp / "hdfs").rglob("ESTUDO_GFP_HOMOLOGACAO_COMPLETO.zip"))), 1)

    def test_orcamento(self):
        from itertools import count

        with patch.object(g, "perf_counter", side_effect=count(0, 130)):
            d, _ = self.env.run(self.env.config())
        self.assertIn("orçamento", d["operacoes"][0]["estado"])
        self.assertFalse(self.env.calls)

    def test_precisao_decimal_entre_lotes(self):
        from decimal import localcontext

        with localcontext() as ctx:
            ctx.prec = 64
            soma = g.SomaExata()
            soma.step(g.PRECISAO_TESTE)
            soma.step("0.01")
            self.assertEqual(soma.finalize(), g.PRECISAO_TESTE[:-1] + "2")

    def test_auditoria_todas_as_consultas(self):
        db = self.env.sqlite
        for col in ("CD_INST_PCT", "NR_MCA_PCT_OPB", "CD_TRAN_IR", "NR_CPF_CNPJ_TITR", "NR_PTC"):
            db.execute("ALTER TABLE DB2GFP.TRAN_RLZD_INST_PCT ADD COLUMN " + col + " INTEGER")
        db.executescript("""
            CREATE TABLE DB2GFP.TRAN_INCD_CLI AS SELECT *, 0 AS NR_TRAN_RLZD_OGM FROM DB2GFP.TRAN_RLZD_INST_PCT;
            CREATE TABLE DB2GFP.CMPT_TRAN_RLZD_CRT (NR_TRAN_INST_PCT, CD_TIP_TRAN_CRT, TX_TIP_PGTO,
                TX_TIP_LNCD, NR_PCL_CPR, QT_PCL_CPR, TX_TIP_TARF, TX_TIP_CRD_CTRD, DT_TRAN_FAT);
            CREATE TABLE DB2GFP.CMPT_TRAN_RLZD_CC (NR_TRAN_INST_PCT, CD_HST_TRAN, CD_SHST_TRAN, NR_CPF_CNPJ_PGDR);
            CREATE TABLE DB2GFP.CTGR_TRAN_OPB (CD_CTGR_TRAN, TX_DCR_CTGR_TRAN, CD_NTZ_CTB_TRAN,
                IN_CTGR_PDRO_SIS, CD_TRAN_IR, CD_GR_CTGR_TRAN);
            CREATE TABLE DB2GFP.GR_CTGR_TRAN (CD_GR_CTGR_TRAN, TX_DCR_GR_CTGR, CD_COR_GR_CTGR);
            INSERT INTO DB2GFP.CTGR_TRAN_OPB VALUES (8,'Categoria','D','N',1,13);
            INSERT INTO DB2GFP.GR_CTGR_TRAN VALUES (13,'Grupo',1);
        """)
        self.env.transacao(101, valor=1.25, flags=("S", "S", "N", "S", "N", "S"))
        self.env.transacao(102, valor=-2.25)
        db.executescript("""
            UPDATE DB2GFP.TRAN_RLZD_INST_PCT SET CD_PRD=9 WHERE CD_CLI=102;
            INSERT INTO DB2GFP.TRAN_INCD_CLI SELECT *,1 FROM DB2GFP.TRAN_RLZD_INST_PCT WHERE CD_CLI=101;
        """)
        d, arq = self.env.run(self.env.config("AUDITORIA", g.TODAS), [101, 102])
        self.assertEqual(d["situacao_funcional"], "COMPLETO", d["erros_consolidacao"])
        self.assertEqual(d["comparacao_independente"], dict.fromkeys(g.TODAS, "OK"))
        self.assertEqual(set(v for _, v in d["controles"]), {"OK"})
        self.assertIn("UM_DERIVADO_NO_ESCOPO", arq["Q08.csv"])
