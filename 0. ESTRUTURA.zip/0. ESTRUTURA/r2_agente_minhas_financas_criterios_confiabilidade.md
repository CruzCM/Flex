# AGENTE MINHAS FINANÇAS — Critérios de Confiabilidade dos Dados Financeiros

## 1. Princípio fundamental

O **AGENTE MINHAS FINANÇAS** deve apresentar resultados conclusivos somente quando os dados disponíveis forem suficientes para sustentar a afirmação, considerando o período consultado, a cobertura, a integridade, a classificação das movimentações e a finalidade da análise.

Quando existirem limitações, o agente deverá apresentar apenas as informações comprovadas e comunicar claramente o que não foi possível verificar.

**Regra principal:** ausência de registros não significa necessariamente ausência de gastos. Resultados incompletos não devem ser apresentados como totais definitivos, e análises sem evidência suficiente não devem gerar conclusões.

## 2. Critérios para considerar um resultado confiável

Um resultado financeiro pode ser considerado confiável dentro do escopo consultado quando:

1. A consulta foi executada com sucesso e os dados pertencem ao cliente autorizado.
2. O período solicitado está coberto pelos dados disponíveis.
3. O resultado está completo para a operação solicitada, sem falhas de paginação, truncamento ou processamento.
4. Os valores e tipos de movimentação necessários estão disponíveis e são válidos.
5. As classificações necessárias para a análise são conhecidas.
6. A quantidade e a qualidade dos dados são suficientes para sustentar o cálculo ou a conclusão pretendida.
7. As regras de cálculo utilizadas são consistentes com a natureza das movimentações financeiras.

Nem todas as análises exigem todas essas condições. Um total geral de gastos, por exemplo, pode ser calculado mesmo com categorias ausentes, desde que os valores estejam completos e seja possível distinguir gastos de consumo de outras movimentações.

Aplicações, resgates, transferências e pagamentos de fatura não devem ser confundidos automaticamente com gastos de consumo.

## 3. Cenários de confiabilidade

| Situação encontrada | O que pode ser afirmado com segurança | O que não pode ser concluído | Comunicação ao cliente |
|---|---|---|---|
| **1. Período completo e dados válidos** | Totais, agrupamentos e comparações sustentados pelos dados | Informações fora do período consultado | "Em setembro, seus gastos registrados totalizaram R$ 5.610,00." |
| **2. Mês ainda em andamento** | Resultado acumulado até a última data disponível | Resultado final do mês ou tendência definitiva | "Até 9 de outubro, seus gastos somam R$ 5.230,40. O mês ainda não terminou." |
| **3. Nenhuma transação encontrada, com consulta completa** | Não existem movimentações registradas no escopo consultado | Que o cliente não realizou operações fora da cobertura | "Não encontrei movimentações registradas nesse período nos dados consultados." |
| **4. Existem transações, mas nenhum gasto de consumo** | O total de gastos identificados é zero, se a classificação for confiável | Que não ocorreram transferências, aplicações ou outras movimentações | "Não identifiquei gastos de consumo no período, mas existem outras movimentações." |
| **5. Serviço indisponível ou consulta com falha** | Não foi possível obter os dados | Qualquer valor financeiro, inclusive zero | "Não consegui consultar suas movimentações agora. Por isso, não posso confirmar os valores." |
| **6. Dados parcialmente recebidos** | Valores referentes à parte comprovadamente disponível | Totais definitivos do período inteiro | "Consegui analisar apenas parte das movimentações. Os valores apresentados são parciais." |
| **7. Lançamentos sem categoria** | Total geral, caso valores e natureza das movimentações estejam identificados | Distribuição completa dos gastos por categoria | "Consigo informar o gasto total, mas parte das movimentações não possui categoria definida." |
| **8. Tipo de movimentação desconhecido** | Valores registrados e identificados como não classificados | Total definitivo de gastos de consumo que dependa dessas movimentações | "Algumas movimentações não puderam ser identificadas como gastos ou outros tipos de operação. O total pode estar incompleto." |
| **9. Comparação entre períodos incompletos ou desiguais** | Valores efetivamente registrados em cada período | Que houve aumento ou redução comparável entre períodos de cobertura diferente | "Outubro ainda está em andamento. Posso mostrar os valores registrados, mas não comparar os dois meses como períodos completos." |
| **10. Amostra insuficiente para análise estatística** | Quantidade de lançamentos e valores observados | Padrões habituais ou anomalias com confiança | "Ainda não há movimentações suficientes para identificar um padrão confiável." |
| **11. Período fora do histórico disponível** | Resultados dentro do período coberto pelo serviço | Valores relativos a períodos não disponibilizados | "Tenho dados disponíveis apenas para o período informado pelo serviço. Não consigo analisar os meses anteriores." |
| **12. Lista de lançamentos limitada** | Itens efetivamente retornados e totais independentes, se fornecidos pela ferramenta | Que a lista contém todas as movimentações | "Encontrei mais movimentações do que as exibidas. Esta lista apresenta apenas parte dos resultados." |

*Os valores apresentados são ilustrativos.*

## 4. Distinção obrigatória entre estados de informação

O agente deverá distinguir explicitamente quatro situações:

| Estado | Definição | Comportamento esperado |
|---|---|---|
| **Sem gastos** | Consulta válida e completa confirma que não existem gastos de consumo registrados no escopo | Informar zero, mencionando período e cobertura |
| **Sem dados** | Não existem registros disponíveis ou não há cobertura suficiente para verificar o período | Não presumir que o valor seja zero |
| **Inconclusivo** | Existem dados, mas são insuficientes para a conclusão solicitada | Apresentar fatos observáveis e explicar a limitação |
| **Indisponível** | O serviço ou a consulta necessária falhou | Informar impossibilidade de consulta, sem apresentar valores não verificados |

### Exemplo prático

**Pergunta do cliente:** "Quanto gastei em setembro?"

**Cenário A — Consulta completa, sem gastos identificados**

> Não foram registrados gastos de consumo em setembro nos dados consultados.

**Cenário B — Dados insuficientes**

> Não há informações suficientes para determinar quanto você gastou em setembro.

**Cenário C — Serviço indisponível**

> Não consegui consultar seus gastos de setembro neste momento.

Uma lista vazia, isoladamente, não comprova que houve zero gastos. Para essa conclusão, é necessário confirmar que a consulta foi bem-sucedida e cobriu adequadamente o período e os tipos de movimentação necessários.

## 5. Regras para análises específicas

### 5.1. Comparações entre períodos

As comparações devem utilizar períodos e critérios equivalentes.

O agente deverá:

- Distinguir períodos completos de períodos parciais.
- Informar a cobertura efetiva de cada período.
- Evitar conclusões definitivas quando as coberturas forem diferentes.
- Utilizar períodos equivalentes quando houver dados suficientes.
- Não interpretar a ausência de dados como redução de gastos.

**Exemplo:**

Comparar setembro completo com outubro até o dia 9 permite apresentar os valores registrados, mas não afirmar que os gastos diminuíram em outubro.

Uma comparação entre 1º e 9 de setembro e 1º e 9 de outubro poderá ser válida, desde que ambos os intervalos tenham cobertura confirmada e sejam utilizados os mesmos critérios de cálculo.

### 5.2. Lançamentos atípicos

A identificação de um lançamento estatisticamente atípico não comprova irregularidade, erro ou fraude.

O agente deverá:

- Utilizar os critérios estatísticos definidos pelas ferramentas.
- Considerar a suficiência da amostra.
- Apresentar os valores observados e o contexto da comparação.
- Não classificar automaticamente uma movimentação como suspeita ou fraudulenta.

**Comunicação recomendada:**

> Esse lançamento ficou acima do comportamento normalmente observado nessa categoria. Isso não significa necessariamente que exista uma irregularidade.

### 5.3. Possíveis lançamentos repetidos

A identificação de movimentações com mesma data, descrição e valor não confirma cobrança duplicada ou indevida.

O agente poderá apresentar as ocorrências encontradas, mas deverá tratar o resultado como uma possível repetição que merece conferência.

**Comunicação recomendada:**

> Encontrei dois lançamentos com a mesma descrição, data e valor. Eles podem representar uma repetição, mas os dados disponíveis não permitem confirmar uma cobrança indevida.

### 5.4. Estatísticas de gastos

Análises estatísticas deverão respeitar a quantidade e a qualidade dos dados disponíveis.

Quando a amostra não for suficiente, o agente poderá apresentar valores observados, mas não deverá afirmar que representam um comportamento habitual confiável.

Mediana, quartis e medidas de dispersão deverão ser calculados pelas ferramentas financeiras.

### 5.5. Indicadores financeiros

Indicadores relacionados à renda exigem informações válidas e compatíveis com o período analisado.

O agente deverá distinguir:

- Renda informada ou identificada.
- Gastos de consumo.
- Resultado financeiro calculado.
- Aplicações e resgates.
- Poupança efetivamente comprovada, quando existir informação suficiente.

**Uma diferença positiva entre renda e gastos não comprova, isoladamente, poupança efetivamente realizada.**

Também não se deve apresentar indicadores de um período parcial como se representassem necessariamente o resultado do mês completo.

### 5.6. Categorias ausentes ou desconhecidas

A ausência de categoria não deve impedir automaticamente todas as análises.

Se os valores e a natureza das movimentações forem conhecidos, o agente poderá apresentar totais gerais confiáveis.

Entretanto, não deverá apresentar uma distribuição completa por categoria quando existirem movimentações sem classificação.

**Comunicação recomendada:**

> O total de gastos do período foi calculado, mas algumas movimentações não possuem categoria. Por isso, a distribuição por categoria está incompleta.

### 5.7. Histórico conversacional

O histórico recebido do consumidor poderá ser utilizado para interpretar referências feitas pelo cliente.

Por exemplo:

> "E no mês anterior?"

O histórico pode ajudar a identificar qual análise e qual período estão sendo solicitados.

Entretanto, respostas anteriores da conversa não devem substituir os resultados das ferramentas quando uma nova consulta ou cálculo financeiro for necessário.

**O contexto conversacional auxilia na interpretação da solicitação. Os dados financeiros verificados sustentam os resultados numéricos.**

## 6. Política de decisão do agente

Toda análise financeira deverá ser classificada conforme a suficiência das informações.

| Classificação | Condição | Resposta esperada |
|---|---|---|
| **Suficiente** | Os dados sustentam integralmente a conclusão solicitada | Apresentar resultado fundamentado |
| **Parcial** | Parte da informação está disponível e é verificável | Apresentar somente a parte comprovada e explicar a limitação |
| **Inconclusivo** | Os dados não permitem uma conclusão confiável | Não produzir a conclusão pretendida; comunicar o motivo |
| **Indisponível** | Não foi possível executar a consulta necessária | Informar a indisponibilidade, sem inventar valores |

Uma análise parcialmente respondível não deverá ser rejeitada integralmente quando existirem informações confiáveis que possam ser apresentadas.

Por outro lado, uma informação parcial não deverá ser apresentada como resultado completo.

## 7. Requisitos para as ferramentas financeiras

Para que o agente aplique essa política de maneira consistente, as ferramentas deverão fornecer informações suficientes para diferenciar:

1. Consulta executada com sucesso.
2. Consulta completa sem registros.
3. Resultado com registros válidos.
4. Resultado parcialmente disponível.
5. Cobertura temporal insuficiente.
6. Resultado limitado por paginação ou quantidade de registros.
7. Dados com classificação incompleta.
8. Falha ou indisponibilidade da fonte de dados.
9. Amostra insuficiente para determinada análise.

Esses requisitos devem orientar a definição dos contratos internos das ferramentas na refatoração do novo harness.

Não se deve depender exclusivamente da interpretação do LLM para determinar se a consulta foi completa, se existem registros suficientes ou se ocorreu uma falha.

## 8. Diretrizes de comportamento

O AGENTE MINHAS FINANÇAS deverá:

- Priorizar informações verificadas em vez de estimativas.
- Não inventar valores, transações, períodos ou classificações.
- Não transformar ausência de informação em resultado igual a zero.
- Não omitir limitações que possam alterar a interpretação de um resultado.
- Não produzir conclusões estatísticas sem evidência suficiente.
- Não afirmar fraude, erro ou cobrança indevida apenas com base em indícios.
- Não comparar períodos incompatíveis como se fossem equivalentes.
- Não apresentar resultados parciais como totais definitivos.
- Apresentar informações úteis quando parte da análise for confiável.
- Comunicar limitações de maneira objetiva, sem explicações técnicas desnecessárias ao cliente.

## 9. Regra negocial consolidada

> **O AGENTE MINHAS FINANÇAS deverá apresentar conclusões financeiras somente quando sustentadas por dados suficientes, válidos e compatíveis com a análise solicitada.**
>
> A ausência de registros não poderá ser interpretada como ausência de gastos sem confirmação da cobertura e integridade da consulta.
>
> Resultados parciais deverão ser identificados como parciais. Análises sem evidência suficiente deverão ser consideradas inconclusivas. Falhas de consulta deverão ser comunicadas como indisponibilidade, nunca como resultado financeiro igual a zero.
>
> Sempre que houver informações comprovadas que respondam parcialmente à solicitação, o agente deverá apresentá-las de maneira clara, indicando suas limitações e evitando extrapolações.

**Essa política deverá ser aplicada a todas as capacidades financeiras do novo harness, independentemente da ferramenta ou do fluxo LangGraph responsável pela execução.**
