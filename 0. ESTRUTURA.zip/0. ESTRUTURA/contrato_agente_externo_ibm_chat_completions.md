# Proposta de contrato — Agente externo IBM via Chat Completions

Este documento apresenta **uma proposta de integração** de nosso agente externo ao **IBM watsonx Orchestrate**, baseada no formato Chat Completions descrito na documentação de referência da IBM.

**Atenção:** os exemplos abaixo **não representam um contrato oficialmente homologado pela IBM**. Estamos adaptando a referência às necessidades do nosso ambiente. Antes da implantação, será necessário validar com a IBM **toda a integração**, inclusive a URL e a operação `POST`, os cabeçalhos, o repasse do token intermediário, a autenticação e o comportamento do histórico de mensagens.

## 1. Endpoint proposto

```http
POST /v1/chat/completions
Content-Type: application/json
Authorization: Bearer <AGENT_API_TOKEN>
X-IBM-THREAD-ID: <thread_id>
X-SENDER-ID: <sender_id>
```

**Campos adicionais exigidos pelo nosso ambiente:**

| Cabeçalho | Finalidade | Situação |
|---|---|---|
| `X-IBM-THREAD-ID` | Identifica a sessão/conversa. | Cabeçalho previsto na referência IBM como **opcional**; será **obrigatório** para nós. |
| `X-SENDER-ID` | Transporta o **token intermediário do cliente** usado por ferramentas internas. | **Personalização nossa**, não confirmada como cabeçalho encaminhado pela IBM. Será **obrigatório** para nós. |

`Authorization` autentica o consumidor perante nosso agente; não deve ser confundido com o token intermediário carregado em `X-SENDER-ID`.

## 2. Entrada — Com contexto

O consumidor envia as mensagens disponíveis da conversa no array `messages`.

```json
{
  "model": "meu-agente",
  "messages": [
    {
      "role": "user",
      "content": "Qual o status do pedido 123?"
    },
    {
      "role": "assistant",
      "content": "O pedido está em transporte."
    },
    {
      "role": "user",
      "content": "Qual a previsão de entrega?"
    }
  ],
  "stream": false
}
```

## 3. Entrada — Sem contexto

O consumidor envia somente a mensagem atual no array `messages`.

```json
{
  "model": "meu-agente",
  "messages": [
    {
      "role": "user",
      "content": "Qual o status do pedido 123?"
    }
  ],
  "stream": false
}
```

**Observação:** os cabeçalhos da seção 1 são obrigatórios em **ambos os cenários**. Não serão criados endpoints separados nem um parâmetro `stateless`. A quantidade e a seleção do histórico enviado dependem do consumidor; este contrato não exige um número fixo de mensagens.

## 4. Saída — Formato Chat Completions de referência

**HTTP 200 OK**

```json
{
  "id": "chatcmpl-001",
  "object": "chat.completion",
  "created": 1791460800,
  "model": "meu-agente",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "O pedido 123 está em transporte."
      },
      "finish_reason": "stop"
    }
  ]
}
```

A resposta é a mesma nos dois cenários. Os identificadores e os conteúdos nos exemplos são ilustrativos. Não retornaremos `thread_id`, `sender_id` ou tokens no JSON de sucesso.

## 5. Regras da nossa integração

| Elemento | Regra proposta |
|---|---|
| `model` | Obrigatório. |
| `messages` | Obrigatório; contém uma ou mais mensagens. |
| `stream` | Obrigatoriamente `false` (sem streaming). |
| `X-IBM-THREAD-ID` | Obrigatório para identificar a conversa. |
| `X-SENDER-ID` | Obrigatório para transportar o token intermediário do cliente. |
| Ferramentas | Executadas internamente pelo agente; não compõem a interface externa. |
| Histórico | Enviado pelo consumidor quando disponível; nosso agente não o persiste. |
| Saída | JSON no formato `chat.completion`. |

## 6. Pontos de validação com a IBM

- Confirmar **URL, caminho e operação HTTP** utilizados pela integração no ambiente real.
- Confirmar o envio consistente de `X-IBM-THREAD-ID`, inclusive na primeira mensagem.
- Confirmar a possibilidade de encaminhar dinamicamente `X-SENDER-ID` com o token intermediário do cliente, de forma segura.
- Confirmar o método de autenticação entre o watsonx Orchestrate e nosso agente.
- Confirmar a composição efetiva de `messages` com a opção **Send conversation history** ligada e desligada, inclusive em conversas com múltiplos agentes.
- Confirmar a aceitação do contrato síncrono com `stream: false` e do formato de resposta mostrado.

## Referências oficiais

- [IBM — Agent Chat API, OpenAPI de referência](https://github.com/watson-developer-cloud/watsonx-orchestrate-developer-toolkit/blob/main/external_agent/spec.yaml)
- [IBM — Adding agents from third-party platforms](https://www.ibm.com/docs/en/watsonx/watson-orchestrate/base?topic=platforms-adding-agents-from-third-party)
