# Agente Conversacional de Educação Financeira

## 1. Visão negocial

### 1.1. Objetivo

O produto é um agente conversacional voltado à relação do usuário com suas finanças pessoais.

Seu objetivo não é apenas responder perguntas sobre transações. O agente deve conseguir transitar entre três necessidades diferentes:

1. entender os gastos do usuário;
2. fornecer educação financeira contextualizada;
3. orientar sobre como utilizar funcionalidades disponíveis no aplicativo.

Essas três capacidades podem aparecer isoladamente ou combinadas na mesma conversa.

O princípio central do produto é que o agente deve entender primeiro **o que o usuário está tentando resolver** e, a partir disso, decidir quais recursos são necessários para produzir a resposta.

---

# 2. Capacidades do agente

## 2.1. Análise de gastos

O agente pode responder perguntas relacionadas às transações financeiras do usuário.

Exemplos simples:

- Quanto gastei com alimentação em setembro?
- Quanto gastei este mês?
- Qual foi minha maior categoria?

Exemplos intermediários:

- Gastei mais com alimentação em agosto ou setembro?
- Qual categoria mais aumentou?
- Qual percentual dos meus gastos foi com lazer?

Exemplos mais complexos:

- Quais categorias explicam o aumento dos meus gastos nos últimos três meses?
- Meus gastos variáveis estão crescendo?
- Minha alimentação ficou mais cara ou eu apenas fiz mais compras?

A dificuldade da pergunta não é definida apenas pela linguagem utilizada pelo usuário.

Ela depende principalmente das operações necessárias para respondê-la e das ferramentas disponíveis para manipular os dados.

Portanto, o agente pode compreender perfeitamente uma pergunta e, ainda assim, não possuir capacidade operacional para respondê-la.

Nesse caso, ele deve reconhecer sua limitação em vez de improvisar uma análise.

---

# 3. Educação financeira

O agente também deve responder perguntas de educação financeira.

Exemplos:

- O que é reserva de emergência?
- Como posso começar a controlar melhor meus gastos?
- Como posso economizar mais?
- Quanto devo considerar ao organizar meu orçamento?

Existe uma regra de produto fundamental:

**Toda orientação, conceito ou recomendação de educação financeira deve estar fundamentada na base de conhecimento de educação financeira.**

O modelo não deve utilizar apenas seu conhecimento interno para produzir recomendações financeiras.

Para isso, existe uma ferramenta de recuperação de contexto que pode ser chamada com o índice:

`educacao-financeira`

O conteúdo recuperado passa a ser a fonte utilizada pelo agente para construir a orientação.

---

# 4. Uso do aplicativo

A terceira capacidade é explicar como utilizar funcionalidades do aplicativo.

Exemplos:

- Onde encontro o Planejamento Financeiro?
- Como configuro um limite para alimentação?
- Como altero um planejamento?
- Como acompanho o valor que ainda posso gastar?

Nesses casos, os detalhes operacionais devem obrigatoriamente vir da base de conhecimento:

`navegacao-app`

O agente não deve inventar telas, botões, caminhos ou comportamentos do produto.

---

# 5. Recomendação de funcionalidades

Recomendar uma funcionalidade é diferente de ensinar como utilizá-la.

Essa distinção é importante.

Considere a pergunta:

“Quanto gastei com alimentação em setembro e como posso controlar melhor esse gasto?”

O agente pode responder o valor, fornecer orientação de educação financeira e dizer:

“Você também pode utilizar o Planejamento Financeiro para definir um limite para essa categoria.”

Para fazer essa recomendação, não é necessário consultar a base de navegação do aplicativo.

O agente apenas precisa saber que determinada funcionalidade existe e qual problema ela ajuda a resolver.

Por outro lado, se o usuário perguntar:

“Como uso o Planejamento Financeiro?”

a consulta à base `navegacao-app` passa a ser obrigatória.

Portanto:

**Recomendar funcionalidade**
→ não exige RAG de navegação.

**Explicar como utilizar funcionalidade**
→ exige RAG de navegação.

---

# 6. Feature Manifest

As funcionalidades que podem ser recomendadas pelo agente devem estar descritas em um manifesto estruturado.

Exemplo conceitual:

```yaml id="cr9zzt"
feature:
  id: planejamento_financeiro
  name: Planejamento Financeiro

  purpose:
    - definir limite de gasto por categoria
    - acompanhar o consumo do orçamento

  recommend_when:
    - usuário quer controlar uma categoria
    - usuário quer reduzir gastos
    - usuário quer definir limites

  do_not_recommend_when:
    - usuário quer apenas consultar um valor
    - a funcionalidade não contribui diretamente para o objetivo

  allowed_without_rag:
    - citar a funcionalidade
    - descrever brevemente sua finalidade

  requires_navigation_rag:
    - onde acessar
    - como configurar
    - como alterar
    - passo a passo
```

O Feature Manifest é a fonte de verdade sobre quais funcionalidades podem ser recomendadas.

O modelo não deve inventar funcionalidades.

---

# 7. Uso combinado das capacidades

O agente não deve classificar obrigatoriamente cada pergunta em uma única intenção.

Uma pergunta pode exigir várias capacidades simultaneamente.

Exemplo:

“Quanto gastei com alimentação em setembro e como posso economizar?”

Necessidades:

- análise de gastos;
- educação financeira.

Outro exemplo:

“Quanto gastei com alimentação, como posso reduzir isso e como configuro um limite no aplicativo?”

Necessidades:

- análise de gastos;
- educação financeira;
- navegação do aplicativo.

Portanto, as capacidades são combináveis.

---

# 8. Princípio central: entender antes de executar

O coração do sistema é o entendimento da pergunta.

Antes de considerar qualquer ferramenta concreta, o agente deve entender semanticamente:

- o que o usuário quer;
- quais partes existem na pergunta;
- quais referências dependem da conversa anterior;
- qual período está envolvido;
- quais informações seriam necessárias;
- quais operações seriam necessárias para responder.

Esse planejamento ocorre em nível semântico.

Exemplo:

“Qual categoria aumentou mais de agosto para setembro?”

O agente pode concluir:

1. preciso obter gastos de agosto;
2. preciso obter gastos de setembro;
3. preciso agrupar por categoria;
4. preciso somar os valores;
5. preciso comparar os períodos;
6. preciso encontrar o maior aumento.

Esse raciocínio pode acontecer mesmo que nenhuma ferramenta esteja disponível.

---

# 9. Planejamento não significa capacidade

Depois de entender o que seria necessário fazer, o agente deve verificar se possui as capacidades necessárias.

Essa é uma das principais regras do sistema.

O agente pode saber **como um problema deveria ser resolvido** sem possuir ferramentas suficientes para resolvê-lo.

Por exemplo:

Pergunta:

“Qual categoria mais aumentou de agosto para setembro?”

Operações necessárias:

- recuperar transações;
- agrupar por categoria;
- somar;
- comparar;
- encontrar maior aumento.

Se as ferramentas disponíveis permitirem compor essas operações, a pergunta é suportada.

Caso contrário, o agente deve informar que não consegue realizar aquela análise com as capacidades disponíveis.

---

# 10. Tool Capability Manifest

Para permitir essa avaliação, cada ferramenta deve declarar claramente quais capacidades oferece.

Exemplo:

```yaml id="zc1ilh"
tool: get_transactions

provides:
  - retrieve_transactions_by_period
```

```yaml id="qf1v3t"
tool: dataframe_groupby

provides:
  - group_by_column
```

```yaml id="6rq772"
tool: dataframe_aggregate

provides:
  - sum
  - count
  - mean
```

O agente não precisa obrigatoriamente possuir uma ferramenta chamada `compare_months`.

Ele pode responder à comparação se for capaz de compor ferramentas menores e chegar ao resultado.

Portanto, o que importa é a cobertura de capacidades e não a existência de uma ferramenta com o mesmo nome da intenção do usuário.

---

# 11. Contexto conversacional

O agente deve considerar o contexto já estabelecido na conversa.

Exemplo:

Usuário:

“Quanto gastei com alimentação em setembro?”

Depois:

“E agosto?”

Depois:

“Qual foi maior?”

O agente deve resolver essas referências sem obrigar o usuário a repetir toda a pergunta.

Outro exemplo:

Usuário:

“Você disse que eu posso usar o Planejamento Financeiro. Como faço isso?”

Nesse caso, “isso” deve ser associado à funcionalidade mencionada anteriormente.

O contexto, portanto, participa diretamente da etapa de entendimento.

---

# 12. Estados possíveis

Após avaliar a pergunta e as capacidades disponíveis, o harness deve trabalhar com pelo menos quatro estados:

### SUPPORTED

A pergunta foi compreendida e existe um plano executável com as capacidades disponíveis.

### UNSUPPORTED

A pergunta foi compreendida, porém falta uma ou mais capacidades necessárias.

### AMBIGUOUS

Não há informação suficiente para determinar com segurança o que deve ser executado.

### FAILED

A pergunta era suportada, porém houve uma falha durante sua execução.

Essa separação é importante para observabilidade e governança.

---

# 13. Arquitetura conceitual

O comportamento geral do agente é:

```text id="j77pho"
Usuário + contexto
        ↓
Entender a necessidade
        ↓
Criar plano semântico
        ↓
Identificar capacidades necessárias
        ↓
Comparar com capacidades disponíveis
        ↓
SUPPORTED?
   ↓            ↓
 NÃO            SIM
   ↓             ↓
abster       executar
                 ↓
            observar
                 ↓
            replanejar
                 ↓
             validar
                 ↓
      avaliar recomendação de feature
                 ↓
              responder
```

---

# 14. O que deve existir antes do harness

Antes da implementação do fluxo operacional, devem ser construídos os seguintes elementos.

## 14.1. Contrato do agente

Documento definindo:

- o que o agente pode fazer;
- o que não pode fazer;
- quais fontes são obrigatórias para cada tipo de informação;
- quando deve reconhecer falta de capacidade.

## 14.2. Taxonomia de capacidades

Vocabulário semântico comum usado para descrever aquilo que uma pergunta exige.

Exemplos:

- retrieve_transactions;
- filter_by_category;
- group_by_category;
- aggregate_sum;
- compare_periods;
- calculate_percentage;
- financial_education;
- app_navigation.

## 14.3. Tool Capability Manifest

Descrição estruturada das capacidades oferecidas por cada ferramenta.

## 14.4. Feature Manifest

Descrição das funcionalidades que podem ser recomendadas e em quais situações.

## 14.5. Contratos dos RAGs

Definição das bases:

- `educacao-financeira`;
- `navegacao-app`.

Também devem ser estabelecidas as regras que tornam a consulta obrigatória.

## 14.6. Contrato de contexto

Definição de:

- quais mensagens anteriores chegam ao agente;
- quais resultados são preservados;
- quais entidades mencionadas anteriormente são mantidas;
- data e timezone utilizados para interpretação temporal.

## 14.7. Semantic Plan

Estrutura que representa o entendimento da pergunta antes de vinculá-la a ferramentas concretas.

## 14.8. Dataset inicial de avaliação

Bateria de perguntas que deverá existir antes mesmo da implementação completa do agente.

---

# 15. Harness

O harness é a estrutura operacional que conecta modelo, contexto, ferramentas, regras, conhecimento e validações.

O modelo é responsável pelo raciocínio.

As tools fornecem capacidades.

O harness controla como essas capacidades podem ser utilizadas.

O fluxo do MVP será dividido nas etapas seguintes.

---

## 15.1. Build Context

Construir o contexto necessário para aquele turno.

Entrada mínima:

- mensagem atual;
- histórico relevante;
- resultados anteriores relevantes;
- funcionalidades mencionadas;
- data atual;
- timezone;
- políticas.

---

## 15.2. Understand + Semantic Plan

O agente interpreta a pergunta e produz um plano semântico.

Exemplo conceitual:

```json id="81mx6q"
{
  "goals": [
    "informar gasto com alimentação",
    "orientar redução"
  ],
  "resolved_context": {
    "category": "alimentacao",
    "period": "setembro"
  },
  "required_capabilities": [
    "retrieve_transactions",
    "filter_by_category",
    "aggregate_sum",
    "financial_education"
  ]
}
```

Essa etapa não deve depender da lista concreta de tools.

---

## 15.3. Capability Grounding

O plano semântico é comparado ao catálogo real de ferramentas.

O sistema tenta mapear ou compor as capacidades necessárias.

Resultado:

```text id="1rycm8"
SUPPORTED
UNSUPPORTED
AMBIGUOUS
```

Se for `UNSUPPORTED`, nenhuma análise financeira dependente daquela capacidade deve ser improvisada.

---

## 15.4. Execution Loop

Quando a pergunta é suportada, começa a execução.

O fluxo não precisa ser rigidamente pré-determinado.

O agente pode:

1. chamar uma tool;
2. observar o resultado;
3. atualizar seu entendimento;
4. decidir se precisa de outra tool;
5. continuar até obter evidência suficiente.

Exemplo:

```text id="xzw10k"
get_transactions
        ↓
DataFrame
        ↓
filter
        ↓
groupby
        ↓
aggregate
        ↓
resultado
```

Ou:

```text id="p0gwjp"
resultado financeiro
        ↓
retrieve_context(
  index="educacao-financeira"
)
        ↓
orientação
```

---

# 16. Replanejamento

A execução deve permitir replanejamento.

Isso é importante porque o agente pode descobrir novas necessidades a partir dos resultados.

Exemplo:

O usuário pede uma análise e uma orientação.

Primeiro são consultados os gastos.

Depois, com base no resultado, é buscado conhecimento de educação financeira mais adequado à situação identificada.

O plano inicial orienta a execução, mas não precisa definir antecipadamente todas as chamadas.

---

# 17. Validação antes da resposta

Antes de gerar a resposta final, o harness precisa verificar se existe sustentação suficiente para as afirmações.

Exemplos:

“Você gastou R$ 850.”

Precisa estar sustentado pelas ferramentas transacionais.

“Uma reserva de emergência deve...”

Precisa estar sustentado pelo RAG de educação financeira.

“Para acessar o Planejamento Financeiro, vá até...”

Precisa estar sustentado pelo RAG de navegação.

A ausência de evidência não pode ser substituída pelo conhecimento interno do modelo quando a política exigir uma fonte específica.

---

# 18. Avaliação de recomendação de funcionalidade

Ao final da análise, existe uma decisão independente:

```json id="g63ppe"
{
  "recommend_app_feature": true,
  "recommended_feature": "planejamento_financeiro"
}
```

ou:

```json id="5jdb4i"
{
  "recommend_app_feature": false
}
```

Essa avaliação considera o objetivo do usuário e o Feature Manifest.

Ela não exige RAG.

A recomendação deve ser breve e contextual.

Ela não deve se transformar automaticamente em tutorial.

---

# 19. Geração da resposta

A resposta deve atender exatamente às necessidades identificadas.

Exemplo:

“Quanto gastei este mês?”

→ responder gastos.

Não acrescentar automaticamente educação financeira.

“Como posso economizar?”

→ usar educação financeira.

“Como configuro isso?”

→ usar navegação do app.

“Quanto gastei e como posso economizar?”

→ integrar dados e educação financeira.

O agente não deve transformar toda resposta em recomendação financeira ou divulgação de funcionalidades.

---

# 20. Depois do harness: governança

Depois que o fluxo existe, entra a camada permanente de governança.

Ela tem quatro objetivos:

1. medir qualidade;
2. detectar regressões;
3. compreender falhas;
4. impedir que mudanças inseguras cheguem à produção.

---

# 21. Tracing

Cada execução deve registrar:

```text id="hwzy4s"
pergunta
→ contexto utilizado
→ semantic plan
→ capacidades necessárias
→ resultado do capability check
→ tools chamadas
→ parâmetros
→ resultados
→ RAG utilizado
→ feature recommendation
→ resposta final
```

O trace é uma parte central do produto.

Avaliar apenas a resposta final não é suficiente.

---

# 22. Baterias de testes

Devem existir baterias permanentes.

## Bateria A — Gastos

Separada em:

- fácil;
- médio;
- difícil;
- unsupported.

## Bateria B — Educação financeira

Avalia:

- decisão de consultar RAG;
- recuperação;
- fidelidade à fonte;
- ausência de recomendação inventada.

## Bateria C — Navegação do aplicativo

Avalia:

- reconhecimento de perguntas de uso;
- consulta obrigatória ao índice correto;
- fidelidade ao fluxo recuperado.

## Bateria D — Composição

Inclui:

- gastos + educação;
- gastos + app;
- educação + app;
- gastos + educação + app;
- contexto multi-turn;
- recomendação de feature.

---

# 23. Métricas do MVP

## Understanding Accuracy

Mede se o sistema entendeu corretamente a necessidade do usuário.

## Context Resolution Accuracy

Mede se referências a turnos anteriores foram corretamente interpretadas.

## Temporal Resolution Accuracy

Mede se períodos como “mês passado”, “últimos três meses” ou “em setembro” foram corretamente resolvidos.

## Capability Detection Accuracy

Mede se o agente classificou corretamente o caso como suportado ou não suportado.

## False Support Rate

Mede a quantidade de vezes em que o agente tentou responder uma pergunta para a qual não possuía capacidade suficiente.

Essa é uma das métricas prioritárias do MVP.

## Over-Abstention Rate

Mede quantas vezes o agente recusou uma pergunta que poderia ter respondido.

## Execution Correctness

Verifica se operações como soma, filtro, agrupamento e comparação produziram o resultado correto.

Sempre que possível, deve ser avaliada deterministicamente.

## RAG Routing Accuracy

Verifica se o agente escolheu corretamente:

- educação financeira;
- navegação do app;
- ambos;
- nenhum.

## Groundedness

Verifica se as afirmações estão sustentadas pelas fontes obrigatórias.

## Feature Recommendation Precision

Mede se funcionalidades são recomendadas apenas quando realmente pertinentes.

## Unnecessary Tool Rate

Mede chamadas de ferramentas que não contribuíram para a resposta.

## Answer Completeness

Mede se todas as partes da pergunta foram respondidas.

## Latência e custo

Monitora:

- quantidade de chamadas;
- tokens;
- tempo total;
- custo por interação.

---

# 24. Erros críticos

Algumas falhas devem ser classificadas como bloqueadoras, independentemente da média geral das métricas.

São exemplos:

- inventar gasto;
- inventar transação;
- utilizar período incorreto e apresentá-lo como correto;
- responder análise não suportada pelas ferramentas;
- fornecer recomendação financeira fora do RAG;
- inventar funcionalidade do aplicativo;
- explicar navegação sem utilizar a base de navegação;
- recomendar funcionalidade inexistente no Feature Manifest.

Essas falhas devem funcionar como release gates.

---

# 25. Ciclo de melhoria contínua

Todo erro relevante descoberto em teste ou produção deve seguir o fluxo:

```text id="5smanf"
erro
↓
análise do trace
↓
identificação da etapa responsável
↓
criação de novo caso de teste
↓
correção
↓
execução da regressão
```

Assim, a bateria de testes cresce com o produto.

---

# Parte II — Spec-Driven Development

## 26. Objetivo do SDD

O desenvolvimento deve ser conduzido por especificações verificáveis.

A implementação não começa pelo prompt nem pelas tools.

Começa pelos contratos que definem o comportamento esperado.

A ordem proposta é:

```text id="a6j9hv"
Especificação
↓
Casos de aceitação
↓
Implementação
↓
Evals
↓
Validação
```

---

# 27. SPEC-001 — Agent Contract

## Objetivo

Definir as responsabilidades e limitações globais do agente.

## Requisitos

### AC-001

O agente MUST suportar análise de gastos quando possuir as capacidades necessárias.

### AC-002

O agente MUST NOT produzir valores personalizados sem evidência proveniente das ferramentas de dados.

### AC-003

Orientações de educação financeira MUST ser fundamentadas no índice `educacao-financeira`.

### AC-004

Instruções operacionais sobre o aplicativo MUST ser fundamentadas no índice `navegacao-app`.

### AC-005

O agente MAY recomendar funcionalidades presentes no Feature Manifest sem consultar `navegacao-app`.

### AC-006

A recomendação de uma funcionalidade MUST NOT incluir instruções operacionais caso o usuário não as tenha solicitado.

### AC-007

O agente MUST reconhecer quando uma pergunta não pode ser executada com as capacidades disponíveis.

---

# 28. SPEC-002 — Semantic Planning

## Objetivo

Interpretar a necessidade sem depender da implementação das tools.

## Output mínimo

```json id="408ush"
{
  "goals": [],
  "resolved_context": {},
  "required_capabilities": [],
  "ambiguities": []
}
```

## Critérios de aceitação

Dado:

“Quanto gastei com alimentação em setembro e como posso economizar?”

Deve identificar:

```text id="voexnt"
goal 1 → informar gasto
goal 2 → orientar economia

required:
retrieve_transactions
filter_category
aggregate_sum
financial_education
```

Não deve exigir `app_navigation` somente porque uma funcionalidade poderia ser recomendada.

---

# 29. SPEC-003 — Tool Capability Manifest

Cada ferramenta MUST declarar:

```yaml id="9v1k35"
id:
description:
inputs:
outputs:
provides:
limitations:
```

Exemplo:

```yaml id="hl7f6n"
id: dataframe_groupby

provides:
  - group_by_column
```

O manifesto é utilizado para capability grounding.

---

# 30. SPEC-004 — Capability Grounding

## Input

```text id="6ff5dq"
Semantic Plan
+
Tool Capability Manifest
```

## Output

```json id="lqmg9h"
{
  "status": "SUPPORTED | UNSUPPORTED | AMBIGUOUS",
  "execution_plan": [],
  "missing_capabilities": []
}
```

## Regra

O sistema MUST permitir composição de tools.

A ausência de uma tool com o mesmo nome de uma operação semântica não significa automaticamente falta de capacidade.

---

# 31. SPEC-005 — Financial Data Execution

Qualquer resposta dependente de transações MUST ser obtida pelas tools autorizadas.

O modelo MUST NOT realizar inferências sobre valores ausentes.

Operações realizadas sobre DataFrame devem permanecer rastreáveis.

---

# 32. SPEC-006 — Financial Education Retrieval

Quando `financial_education` fizer parte das capacidades necessárias:

```text id="vzp39b"
retrieve_context(
  index="educacao-financeira"
)
```

MUST ocorrer antes da geração da recomendação financeira.

Se a recuperação falhar, o agente MUST NOT substituir o conteúdo por conhecimento próprio.

---

# 33. SPEC-007 — App Navigation Retrieval

Quando o usuário solicitar instruções operacionais sobre o aplicativo:

```text id="xzg4a7"
retrieve_context(
  index="navegacao-app"
)
```

MUST ocorrer.

Exemplos que acionam essa regra:

- como faço;
- onde encontro;
- como configuro;
- onde clico;
- como altero;
- passo a passo.

---

# 34. SPEC-008 — Feature Recommendation

## Output

```json id="15qf1m"
{
  "recommend_app_feature": true,
  "recommended_feature": "feature_id"
}
```

ou:

```json id="7ofh00"
{
  "recommend_app_feature": false,
  "recommended_feature": null
}
```

A decisão MUST utilizar somente funcionalidades presentes no Feature Manifest.

Ela MUST NOT, por si só, acionar o RAG de navegação.

---

# 35. SPEC-009 — Execution Loop

O harness MUST permitir:

```text id="322ebh"
plan
→ tool
→ observation
→ replan
```

até que uma destas condições seja atingida:

```text id="u96atf"
evidência suficiente
UNSUPPORTED
FAILED
limite operacional
```

---

# 36. SPEC-010 — Grounding Validation

Antes da resposta final, o sistema MUST verificar:

```text id="b13eoc"
dados personalizados → tool evidence

educação financeira → education RAG evidence

navegação → navigation RAG evidence

feature recomendada → Feature Manifest
```

Uma resposta que viole essas relações MUST NOT ser liberada normalmente.

---

# 37. SPEC-011 — Conversation Context

O harness MUST suportar resolução de referências ao contexto.

Casos mínimos:

```text id="f6nk9z"
"E agosto?"

"E sem alimentação?"

"Qual foi maior?"

"Como faço isso?"
```

O sistema deve preservar contexto suficiente para interpretar esses turnos.

---

# 38. SPEC-012 — Trace

Toda execução MUST produzir registro suficiente para reconstruir:

```text id="algqvo"
input
context
semantic plan
capability decision
tool calls
tool outputs
retrieval calls
validation
feature decision
final answer
```

---

# 39. SPEC-013 — Eval Suite

Mudanças relevantes MUST executar as baterias de regressão.

Triggers mínimos:

```text id="51oopj"
mudança de modelo
mudança de system prompt
mudança de descrição de tool
nova tool
remoção de tool
mudança no harness
mudança no Feature Manifest
mudança relevante nas bases RAG
```

---

# 40. Critérios mínimos de aceite do MVP

O MVP pode ser considerado funcional quando:

1. perguntas simples de gastos são corretamente respondidas;
2. perguntas compostas são corretamente decompostas;
3. perguntas não suportadas são reconhecidas;
4. educação financeira nunca é fornecida sem RAG;
5. navegação do app nunca é inventada;
6. funcionalidades só são recomendadas quando constam no manifesto;
7. recomendar uma feature não dispara automaticamente tutorial;
8. contexto multi-turn é corretamente interpretado;
9. operações e fontes podem ser reconstruídas pelo trace;
10. a bateria de regressão pode ser executada de forma repetível.

---

# 41. Ordem de implementação proposta pelo SDD

```text id="qjtopf"
1. Agent Contract
2. Taxonomia de capacidades
3. Semantic Plan schema
4. Tool Capability Manifest
5. Feature Manifest
6. RAG contracts
7. Conversation Context contract
8. Capability Grounding
9. Execution Loop
10. Grounding Validation
11. Response generation
12. Tracing
13. Eval runner
14. Release gates
```

A implementação deve avançar apenas quando a especificação da etapa atual possuir casos de aceitação suficientes para demonstrar o comportamento esperado.

---

# 42. Princípio final

A principal responsabilidade do agente não é sempre encontrar uma resposta.

É saber:

```text id="p42sus"
o que o usuário quer
+
o que precisa ser feito
+
o que ele realmente consegue fazer
+
qual fonte deve sustentar cada afirmação
```

A partir disso, ele pode executar, responder ou reconhecer corretamente seus limites.

Esse princípio deve orientar tanto o desenho do harness quanto sua implementação e governança.
