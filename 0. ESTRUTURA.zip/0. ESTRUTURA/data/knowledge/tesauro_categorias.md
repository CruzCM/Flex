# Tesauro de Categorias de Transações Financeiras

> **Fonte:** `Tesauro.xlsx` (abas: Tesauro, Categoria, Categorias_Def, MCC, MCC-INTERNO).
> **Objetivo:** servir como contexto/conhecimento para um assistente categorizador de transações financeiras no **Microsoft Copilot Studio**.
> **Idioma:** Português (Brasil).
> **Convenções:**
> - `Cód.` = código numérico da categoria interna.
> - `Natureza`: **C** = crédito/receita, **D** = débito/despesa.
> - `MCC` = Merchant Category Code (padrão Visa/Mastercard, 4 dígitos).

---

## 1. Como usar este documento (instruções para o assistente)

Você é um assistente que classifica lançamentos financeiros em uma das categorias listadas abaixo. Para cada transação, considere, em ordem de prioridade:

1. **Descrição textual** da transação (palavras-chave, nome do estabelecimento, observações).
2. **Natureza contábil** (crédito vs débito) — receitas só podem cair em categorias `C`; despesas só em `D`.
3. **Código MCC** (quando disponível): use a Seção 4 para mapear MCC → categoria.
4. **CNAE** ou ramo de atividade do estabelecimento, quando informado.
5. **Definições detalhadas** da Seção 3 — leia o bloco "Devem ser incluídos" e "Não devem ser incluídos" para confirmar o enquadramento.

Regras gerais:

- Se houver dúvida entre duas categorias, prefira a **mais específica**.
- Para créditos sem origem identificável, use **`5 – Outros Rendimentos`**.
- Para débitos genéricos em cartão de crédito sem detalhamento, use **`44 – Compras Diversas`**.
- Para transferências entre contas/PIX sem finalidade clara, use **`39436 – Transferência`**.
- Categorias do grupo **Agro** (300, 310, 330, 350, 370) têm prioridade quando o lançamento vem de empresa do agronegócio (verificar CNAE / nome).
- Quando não houver informação suficiente para qualquer outra classificação, use **`279 – Gastos Diversos`**. O código `0` não é mais uma categoria válida — ver Seção 2.3.

---

## 2. Estrutura de Grupos e Categorias

As categorias estão organizadas em **grupos** macro. A tabela abaixo lista todas as
categorias agrupadas, com código, natureza e código do grupo.

> **O de-para dos grupos não mora mais aqui.** A tabela `código do grupo → nome`
> foi extraída em 2026-08-14 para `data/knowledge/grupos_gfp.json`, arquivo próprio
> e de substituição simples. Motivo: o GFP não devolve o nome do grupo, só o código,
> e esse de-para é a única exceção autorizada pela **ADR-014** — que não tem relação
> com o papel deste documento, que é definir **o que conta** em cada categoria.
> As colunas `Grupo` e `Cód. Grupo` abaixo permanecem como referência editorial e
> **não** alimentam runtime.

### 2.2 Tabela de categorias

| Cód. | Categoria | Grupo | Cód. Grupo | Natureza |
|---:|---|---|---:|:---:|
| 1 | Salário | Receitas | 1 | C |
| 2 | Vale Alimentação | Receitas | 1 | C |
| 3 | Restituição de IR | Receitas | 1 | C |
| 4 | Bonificação | Receitas | 1 | C |
| 5 | Outros Rendimentos | Receitas | 1 | C |
| 6 | Água | Casa | 2 | D |
| 7 | Eletricidade e Gás | Casa | 2 | D |
| 9 | Compra de Imóvel | Casa | 2 | D |
| 10 | Aluguel e Condomínio | Casa | 2 | D |
| 11 | Móveis e Utensílios | Casa | 2 | D |
| 12 | Serviços e Manutenção | Casa | 2 | D |
| 13 | Empregados | Casa | 2 | D |
| 14 | Animais e Pets | Casa | 2 | D |
| 3790 | Seguro Residencial | Casa | 2 | D |
| 15 | Educação Superior | Educação | 3 | D |
| 16 | Colégio | Educação | 3 | D |
| 17 | Idiomas | Educação | 3 | D |
| 18 | Livraria e Papelaria | Educação | 3 | D |
| 20 | Outros Gastos, Educação | Educação | 3 | D |
| 21 | Viagens e Lazer | Lazer | 4 | D |
| 22 | Esportes e Academia | Lazer | 4 | D |
| 25 | Cultura e Entretenimento | Lazer | 4 | D |
| 26 | Publicações Digitais | Lazer | 4 | D |
| 61 | Jogos e Loterias | Lazer | 4 | D |
| 27 | Plano de Saúde | Saúde | 5 | D |
| 28 | Serviços de Saúde | Saúde | 5 | D |
| 29 | Dentista | Saúde | 5 | D |
| 30 | Farmácias e Drogarias | Saúde | 5 | D |
| 32 | Feira e Supermercado | Alimentação | 6 | D |
| 35 | Bares e Restaurantes | Alimentação | 6 | D |
| 36 | Compra de Veículo | Transporte | 7 | D |
| 37 | Combustível | Transporte | 7 | D |
| 38 | Estacionamento e Pedágio | Transporte | 7 | D |
| 39 | Seguro de Veículo | Transporte | 7 | D |
| 40 | Serviços e Manutenção | Transporte | 7 | D |
| 41 | Transporte Urbano e Apps | Transporte | 7 | D |
| 42 | Vestuário e Acessórios | Despesas Pessoais | 8 | D |
| 43 | Cuidado Pessoal e Beleza | Despesas Pessoais | 8 | D |
| 44 | Compras Diversas | Despesas Pessoais | 8 | D |
| 45 | Pensão Alimentícia | Despesas Pessoais | 8 | D |
| 46 | Seguros e Previdência | Despesas Pessoais | 8 | D |
| 47 | Doação | Despesas Pessoais | 8 | D |
| 48 | Gasto com Familiares | Despesas Pessoais | 8 | D |
| 49 | Presentes | Despesas Pessoais | 8 | D |
| 4417 | Empréstimos e Prestações | Despesas Pessoais | 8 | D |
| 60 | Serviços Diversos | Despesas Pessoais | 8 | D |
| 51 | Telefonia e Internet | Comunicação | 9 | D |
| 53 | Assinatura TV e Streaming | Comunicação | 9 | D |
| 54 | IPTU | Tarifas e impostos | 10 | D |
| 55 | IPVA e Gastos Detran | Tarifas e impostos | 10 | D |
| 56 | Imposto de Renda | Tarifas e impostos | 10 | D |
| 57 | ISS(Imposto sobre Serviços) | Tarifas e impostos | 10 | D |
| 58 | GPS(Guia de Previdência Social) | Tarifas e impostos | 10 | D |
| 59 | Serviços Financeiros | Tarifas e impostos | 10 | D |
| 3787 | IOF | Tarifas e impostos | 10 | D |
| 3788 | Encargos e Tarifas | Tarifas e impostos | 10 | D |
| 279 | Gastos Diversos | Outros | 11 | D |
| 39434 | Cheque | Outros | 11 | D |
| 39435 | Saque | Outros | 11 | D |
| 39436 | Transferência | Outros | 11 | D |
| 39437 | Boletos Diversos | Outros | 11 | D |
| 111 | Cartão de Crédito | Fatura | 12 | D |
| 448977 | Aplicação | Investimentos | 13 | D |
| 448978 | Resgate de Investimentos | Investimentos | 13 | D |
| 300 | Receitas Agro | Agro | 14 | C |
| 310 | Criações | Agro | 14 | D |
| 330 | Cultivos | Agro | 14 | D |
| 350 | Insumos | Agro | 14 | D |
| 370 | Apoio Produtivo | Agro | 14 | D |

---

## 3. Definições detalhadas por categoria

> As descrições detalhadas foram movidas para data/knowledge/descricoes_categorias.md pela ADR-014. O runtime lê esse glossário diretamente por código; esta tabela permanece apenas como referência editorial.

## 4. Mapeamento de Faixas MCC → Categoria interna

Use esta tabela quando a transação informar o **MCC** (Merchant Category Code) do estabelecimento. A faixa de MCC indica o segmento Visa/Mastercard, que aqui é mapeado para o código interno de categoria.

| Faixa MCC | Descrição (Grupo Visa) | Categoria interna | Cód. categoria |
|---|---|---|---:|
| 0001 - 1499 | Serviços Agrícolas (Plantação, Cultivo) | Insumos | 350 |
| 1500 - 2999 | Serviços Contratados (Construção, Reparos) | Serviços e Manutenção | 12 |
| 3000 - 3299 | Companhias Aéreas (Gol, Latam, Azul, etc.) | Viagens e Lazer | 21 |
| 3351 - 3441 | Aluguel de Carros (Localiza, Movida, Hertz) | Viagens e Lazer | 21 |
| 3501 - 3999 | Hotéis e Hospedagem (Hilton, Accor, Ibis) | Viagens e Lazer | 21 |
| 4011 - 4110 | Ferrovias e Transporte de Passageiros | Viagens e Lazer | 21 |
| 4111 - 4112 | Transporte Urbano (Ônibus, Metrô, Trens locais) | Transporte Urbano e Apps | 41 |
| 4121 | Táxis e Limusines (Inclui Uber/99 em muitos casos) | Transporte Urbano e Apps | 41 |
| 4131 | Ônibus (Viagem/Rodoviário) | Viagens e Lazer | 21 |
| 4214 - 4215 - 8043 | Serviços de Entrega e Correios | Serviços Diversos | 60 |
| 4411 - 4468 | Cruzeiros e Linhas Marítimas | Viagens e Lazer | 21 |
| 4722 - 4789 | Agências de Viagem e Operadoras de Turismo | Viagens e Lazer | 21 |
| 4812 - 4816 | Equipamentos e Serviços de Telecomunicação | Telefonia e Internet | 51 |
| 4899 | TV a Cabo e Outros Serviços Pagos | Assinatura TV e Streaming | 53 |
| 4900 | Utilidades Públicas (Eletricidade, Gás, Água) | Eletricidade e Gás | 7 |
| 5000 - 5199 | Comércio Atacadista (Geral) | Compras Diversas | 44 |
| 5200 - 5262 | Lojas de Material de Construção e Jardim | Serviços e Manutenção | 12 |
| 5300 | Atacadistas e Clubes de Compras (Ex: Sam's Club) | Feira e Supermercado | 32 |
| 5311 - 5331 | Lojas de Departamento e Variedades | Compras Diversas | 44 |
| 5411 | Supermercados e Mercearias | Feira e Supermercado | 32 |
| 5422 - 5499 | Açougues, Lojas de Doces, Empórios | Feira e Supermercado | 32 |
| 5511 - 5521 | Concessionárias (Venda de Carros/Motos) | Compra de Veículo | 36 |
| 5531 - 5533 | Peças e Acessórios Automotivos | Serviços e Manutenção | 12 |
| 5541 - 5542 | Postos de Combustível (Serviço e Automático) | Combustível | 37 |
| 5611 - 5699 | Lojas de Vestuário (Roupas, Sapatos, Acessórios) | Vestuário e Acessórios | 42 |
| 5712 - 5719 | Móveis e Decoração | Móveis e Utensílios | 11 |
| 5722 | Eletrodomésticos | Móveis e Utensílios | 11 |
| 5732 - 5735 | Eletrônicos, Celulares e Lojas de Música | Compras Diversas | 44 |
| 5811 | Distribuidores de Refeições | Alimentação | 35 |
| 5812 | Restaurantes e Lanchonetes | Bar, Rest. e Padaria | 35 |
| 5813 | Bares, Discotecas e Casas Noturnas | Bar, Rest. e Padaria | 35 |
| 5814 | Fast Food | Bar, Rest. e Padaria | 35 |
| 5912 | Farmácias e Drogarias | Farmácias e Drogarias | 30 |
| 5941 | Lojas de Esportes | Esportes e Academia | 22 |
| 5942 - 5943 | Livrarias e Papelarias | Publicações e Papelaria | 18 |
| 5960 - 5969 | Marketing Direto (Vendas Online/Catálogo) | Compras Diversas | 44 |
| 5977 | Lojas de Cosméticos | Cuidado Pessoal e Beleza | 43 |
| 6010 - 6011 | Saque de Dinheiro (Instituições Financeiras) | Saque | 39435 |
| 6012 | Mercadorias - Instituições Financeiras | Serviços Financeiros | 59 |
| 6050 - 6051 | Quasi Cash - Câmbio, Cheques de Viagem | Serviços Financeiros | 59 |
| 6211 | Corretoras de Valores e Títulos | Aplicação | 448977 |
| 6300 | Seguros (Venda e Prêmios) | Seguros e Previdência | 46 |
| 6513 | Agentes e Gestores Imobiliários (Aluguéis) | Aluguel e Condomínio | 10 |
| 7011 - 7033 | Hotéis, Motéis e Resorts | Viagens e Lazer | 21 |
| 7210 - 7217 | Lavanderias e Limpeza a Seco | Serviços Diversos | 60 |
| 7221 | Estúdios fotográficos | Compras Diversas | 44 |
| 7230 - 7298 | Barbearias, Salões de Beleza e Spas | Cuidado Pessoal e Beleza | 43 |
| 7393 | Agências de detetives, serviços de proteção e serviços de segurança, incluindo carros blindados e cães de guarda | Serviços Diversos | 60 |
| 7420 - 7449 | Serviços Veterinários | Animais e Pets | 14 |
| 7512 - 7519 | Aluguel de Automóveis e Trailers | Viagens e Lazer | 21 |
| 7523 | Estacionamentos e Garagens | Estacionamento e Pedágio | 38 |
| 7531 - 7549 | Oficinas Mecânicas e Reparos Automotivos | Serviços e Manutenção | 12 |
| 7812 - 7841 | Cinemas, Produção de Vídeo e Locadoras | Cultura e Entretenimento | 25 |
| 7911 - 7929 | Shows, Bandas, Orquestras | Cultura e Entretenimento | 25 |
| 7932 - 7933 | Bilhar, Boliche e Jogos | Cultura e Entretenimento | 25 |
| 7941 | Campos de Esporte e Estádios | Esportes e Academia | 22 |
| 7991 - 7994 | Atrações Turísticas e Videogames | Cultura e Entretenimento | 25 |
| 7995 | Apostas, Loterias e Cassinos | Jogos e Loterias | 61 |
| 7997 | Clubes (Membros), Country Clubs, Golfe | Esportes e Academia | 22 |
| 7999 | Serviços de Recreação (Geral) | Viagens e Lazer | 21 |
| 8011 - 8049 | Médicos, Quiropraxia, Oftalmologia, etc. | Serviços de Saúde | 28 |
| 8021 | Dentistas e Ortodontistas | Dentista | 29 |
| 8050 - 8071 - 8099 | Instalações de Enfermagem e Laboratórios | Serviços de Saúde | 28 |
| 8111 | Serviços Legais e Advogados | Serviços Diversos | 60 |
| 8211 - 8220 | Escolas Elementares e Secundárias | Colégio | 16 |
| 8241 - 8299 | Faculdades, Universidades e Escolas Técnicas | Educação Superior | 15 |
| 8351 | Creches e Cuidado Infantil | Colégio | 16 |
| 8398 | Organizações de Caridade e Serviço Social | Doação | 47 |
| 8641 - 8699 | Associações Cívicas, Sociais e Religiosas | Doação | 47 |
| 8999 | Serviços Profissionais (Não classificados) | Serviços Diversos | 60 |
| 9211 - 9223 | Pagamentos Governamentais (Multas, Taxas) | IPVA e Gastos Detran | 55 |
| 9311 | Pagamento de Impostos | Imposto de Renda | 56 |
| 9399 | Serviços Governamentais (Geral) | Impostos/Taxas (Diversos) | 3788 |
| 9700 - 9702 | Serviços de Emergência Internacional | Serviços Financeiros | 59 |
| ND / Nulo | Código Inválido ou Ausente | Sem categoria | 0 |

> **Observação:** o MCC isolado nem sempre é decisivo. Por exemplo, MCC 5812 (restaurantes) pode aparecer em compras de delivery via app — mas o destino final pode ser uma categoria diferente se o lançamento for marcado como tarifa do app. Sempre cruze MCC + descrição textual.

---

## 5. Referência completa de Códigos MCC (lista oficial)

Lista de **410 códigos MCC** com o nome do setor correspondente. Use esta tabela quando o lançamento informar um MCC específico e você precisar interpretar o segmento exato antes de aplicar a Seção 4.

| MCC | Setor / Descrição |
|---:|---|
| 742 | Serviços Veterinários |
| 763 | Cooperativas Agrícolas |
| 780 | Serviços de paisagismo e horticultura |
| 1520 | Empreiteiros Gerais – Residenciais e Comerciais |
| 1711 | Empreiteiros de aquecimento, encanamento e ar condicionado |
| 1731 | Empreiteiros elétricos |
| 1740 | Empreiteiros de alvenaria, cantaria, colocação de azulejos, reboco e isolamento |
| 1750 | Empreiteiros de carpintaria |
| 1761 | Empreiteiros de telhados, revestimentos e chapas metálicas |
| 1771 | Empreiteiros de obras de concreto |
| 1799 | Empreiteiros comerciais especiais (não classificados em outro lugar) |
| 2741 | Publicação e impressão diversas |
| 2791 | Composição tipográfica, confecção de chapas e serviços relacionados |
| 2842 | Preparações especiais para limpeza, polimento e higienização |
| 3000 | Companhias Aéreas e Transportadoras Aéreas - UNITED AIRLINES |
| 3001 | Companhias Aéreas e Transportadoras Aéreas - AMERICAN AIRLINES |
| 3005 | Companhias Aéreas e Transportadoras Aéreas - BRITISH AIRWAYS |
| 3007 | Companhias Aéreas e Transportadoras Aéreas - AIR FRANCE |
| 3008 | Companhias Aéreas e Transportadoras Aéreas - LUFTHANSA |
| 3009 | Companhias Aéreas e Transportadoras Aéreas - AIR CANADA |
| 3010 | Companhias Aéreas e Transportadoras Aéreas - KLM (ROYAL DUTCH AIRLINES) |
| 3012 | Companhias Aéreas e Transportadoras Aéreas - QANTAS |
| 3013 | Companhias Aéreas e Transportadoras Aéreas - ITA AIRWAYS (FORMERLY ALITALIA) |
| 3015 | Companhias Aéreas e Transportadoras Aéreas - SWISS INTERNATIONAL AIRLINES |
| 3016 | Companhias Aéreas e Transportadoras Aéreas - SAS |
| 3020 | Companhias Aéreas e Transportadoras Aéreas - AIR-INDIA |
| 3026 | Companhias Aéreas e Transportadoras Aéreas - EMIRATES AIRLINES |
| 3030 | Companhias Aéreas e Transportadoras Aéreas - AEROLINEAS ARGENTINAS |
| 3035 | Companhias Aéreas e Transportadoras Aéreas - TAP (PORTUGAL) |
| 3039 | Companhias Aéreas e Transportadoras Aéreas - AVIANCA |
| 3043 | Companhias Aéreas e Transportadoras Aéreas - AER LINGUS |
| 3047 | Companhias Aéreas e Transportadoras Aéreas - TURKISH AIRLINES |
| 3050 | Companhias Aéreas e Transportadoras Aéreas - ICELANDAIR |
| 3052 | Companhias Aéreas e Transportadoras Aéreas - LAN AIRLINES |
| 3058 | Companhias Aéreas e Transportadoras Aéreas - DELTA |
| 3066 | Companhias Aéreas e Transportadoras Aéreas - SOUTHWEST |
| 3075 | Companhias Aéreas e Transportadoras Aéreas - SINGAPORE AIRLINES |
| 3076 | Companhias Aéreas e Transportadoras Aéreas - AEROMEXICO |
| 3079 | Companhias Aéreas e Transportadoras Aéreas - JETSTAR AIRWAYS |
| 3102 | Companhias Aéreas e Transportadoras Aéreas - IBERIA |
| 3127 | Companhias Aéreas e Transportadoras Aéreas - TACA INTERNATIONAL |
| 3132 | Companhias Aéreas e Transportadoras Aéreas - FRONTIER AIRLINES |
| 3136 | Companhias Aéreas e Transportadoras Aéreas - QATAR AIRWAYS |
| 3161 | Companhias Aéreas e Transportadoras Aéreas - ALL NIPPON AIRWAYS |
| 3174 | Companhias Aéreas e Transportadoras Aéreas - JETBLUE AIRWAYS |
| 3180 | Companhias Aéreas e Transportadoras Aéreas - WESTJET AIRLINES |
| 3182 | Companhias Aéreas e Transportadoras Aéreas - LOT (POLAND) |
| 3206 | Companhias Aéreas e Transportadoras Aéreas - CHINA EASTERN AIRLINES |
| 3211 | Companhias Aéreas e Transportadoras Aéreas - NORWEGIAN AIR SHUTTLE |
| 3219 | Companhias Aéreas e Transportadoras Aéreas - COPA |
| 3245 | Companhias Aéreas e Transportadoras Aéreas - EASYJET AIRLINES |
| 3246 | Companhias Aéreas e Transportadoras Aéreas - RYANAIR |
| 3247 | Companhias Aéreas e Transportadoras Aéreas - GOL AIRLINES |
| 3248 | Companhias Aéreas e Transportadoras Aéreas - TAM AIRLINES |
| 3256 | Companhias Aéreas e Transportadoras Aéreas - ALASKA AIRLINES |
| 3260 | Companhias Aéreas e Transportadoras Aéreas - SPIRIT AIRLINES |
| 3300 | Companhias Aéreas e Transportadoras Aéreas - AZUL AIR |
| 3301 | Companhias Aéreas e Transportadoras Aéreas - WIZZ AIR |
| 3351 | Agências de aluguel de automóveis - AFFILIATED AUTO RENTAL |
| 3355 | Agências de aluguel de automóveis - SIXT CAR RENTAL |
| 3357 | Agências de aluguel de automóveis - HERTZ |
| 3366 | Agências de aluguel de automóveis - BUDGET RENT-A-CAR |
| 3381 | Agências de aluguel de automóveis - EUROP CAR |
| 3387 | Agências de aluguel de automóveis - ALAMO RENT-A-CAR |
| 3389 | Agências de aluguel de automóveis - AVIS RENT-A-CAR |
| 3390 | Agências de aluguel de automóveis - DOLLAR RENT-A-CAR |
| 3393 | Agências de aluguel de automóveis - NATIONAL CAR RENTAL |
| 3395 | Agências de aluguel de automóveis - THRIFTY CAR RENTAL |
| 3405 | Agências de aluguel de automóveis - ENTERPRISE RENT-A-CAR |
| 3412 | Agências de aluguel de automóveis - A-1 RENT-A-CAR |
| 3501 | Hospedagem – Hotéis, Motéis, Resorts - HOLIDAY INNS |
| 3502 | Hospedagem – Hotéis, Motéis, Resorts - BEST WESTERN HOTELS |
| 3503 | Hospedagem – Hotéis, Motéis, Resorts - SHERATON |
| 3504 | Hospedagem – Hotéis, Motéis, Resorts - HILTON HOTELS |
| 3506 | Hospedagem – Hotéis, Motéis, Resorts - GOLDEN TULIP HOTELS |
| 3508 | Hospedagem – Hotéis, Motéis, Resorts - QUALITY INNS |
| 3509 | Hospedagem – Hotéis, Motéis, Resorts - MARRIOTT |
| 3510 | Hospedagem – Hotéis, Motéis, Resorts - DAYS INNS |
| 3512 | Hospedagem – Hotéis, Motéis, Resorts - INTER-CONTINENTAL HOTELS |
| 3513 | Hospedagem – Hotéis, Motéis, Resorts - WESTIN |
| 3516 | Hospedagem – Hotéis, Motéis, Resorts - LA QUINTA INN AND SUITES |
| 3520 | Hospedagem – Hotéis, Motéis, Resorts - MERIDIEN HOTELS |
| 3528 | Hospedagem – Hotéis, Motéis, Resorts - RED LION INNS |
| 3530 | Hospedagem – Hotéis, Motéis, Resorts - RENAISSANCE HOTELS |
| 3533 | Hospedagem – Hotéis, Motéis, Resorts - HOTEL IBIS |
| 3535 | Hospedagem – Hotéis, Motéis, Resorts - HILTON INTERNATIONALS |
| 3542 | Hospedagem – Hotéis, Motéis, Resorts - ROYAL HOTELS |
| 3543 | Hospedagem – Hotéis, Motéis, Resorts - FOUR SEASONS HOTELS |
| 3548 | Hospedagem – Hotéis, Motéis, Resorts - HOTELES MELIA |
| 3551 | Hospedagem – Hotéis, Motéis, Resorts - MIRAGE HOTEL AND CASINO |
| 3555 | Hospedagem – Hotéis, Motéis, Resorts - TREASURE ISLAND HOTEL AND CASINO |
| 3559 | Hospedagem – Hotéis, Motéis, Resorts - CANDLEWOOD SUITES |
| 3562 | Hospedagem – Hotéis, Motéis, Resorts - COMFORT INNS |
| 3577 | Hospedagem – Hotéis, Motéis, Resorts - MANDARIN ORIENTAL HOTEL |
| 3579 | Hospedagem – Hotéis, Motéis, Resorts - HOTEL MERCURE |
| 3581 | Hospedagem – Hotéis, Motéis, Resorts - DELTA HOTEL |
| 3583 | Hospedagem – Hotéis, Motéis, Resorts - RADISSON BLU |
| 3590 | Hospedagem – Hotéis, Motéis, Resorts - FAIRMONT HOTELS |
| 3591 | Hospedagem – Hotéis, Motéis, Resorts - SONESTA HOTELS |
| 3592 | Hospedagem – Hotéis, Motéis, Resorts - OMNI HOTELS |
| 3596 | Hospedagem – Hotéis, Motéis, Resorts - WYNN LAS VEGAS |
| 3604 | Hospedagem – Hotéis, Motéis, Resorts - HILTON GARDEN INN |
| 3608 | Hospedagem – Hotéis, Motéis, Resorts - GAYLORD OPRYLAND |
| 3619 | Hospedagem – Hotéis, Motéis, Resorts - ALOFT |
| 3621 | Hospedagem – Hotéis, Motéis, Resorts - EXTENDED STAY |
| 3628 | Hospedagem – Hotéis, Motéis, Resorts - EXCALIBUR HOTEL AND CASINO |
| 3634 | Hospedagem – Hotéis, Motéis, Resorts - SWISSOTEL |
| 3637 | Hospedagem – Hotéis, Motéis, Resorts - RAMADA INNS |
| 3638 | Hospedagem – Hotéis, Motéis, Resorts - HOWARD JOHNSON |
| 3640 | Hospedagem – Hotéis, Motéis, Resorts - HYATT HOTELS |
| 3641 | Hospedagem – Hotéis, Motéis, Resorts - SOFITEL HOTELS |
| 3642 | Hospedagem – Hotéis, Motéis, Resorts - NOVOTEL HOTELS |
| 3644 | Hospedagem – Hotéis, Motéis, Resorts - ECONO LODGES |
| 3649 | Hospedagem – Hotéis, Motéis, Resorts - RADISSON HOTELS |
| 3654 | Hospedagem – Hotéis, Motéis, Resorts - LOEWS HOTELS |
| 3663 | Hospedagem – Hotéis, Motéis, Resorts - HOTELES EL PRESIDENTE |
| 3665 | Hospedagem – Hotéis, Motéis, Resorts - HAMPTON INNS |
| 3667 | Hospedagem – Hotéis, Motéis, Resorts - LUXOR HOTEL AND CASINO |
| 3681 | Hospedagem – Hotéis, Motéis, Resorts - ADAMS MARK HOTELS |
| 3687 | Hospedagem – Hotéis, Motéis, Resorts - CLARION HOTELS |
| 3690 | Hospedagem – Hotéis, Motéis, Resorts - COURTYARD BY MARRIOTT |
| 3692 | Hospedagem – Hotéis, Motéis, Resorts - DOUBLETREE HOTELS |
| 3693 | Hospedagem – Hotéis, Motéis, Resorts - DRURY INNS |
| 3695 | Hospedagem – Hotéis, Motéis, Resorts - EMBASSY SUITES |
| 3700 | Hospedagem – Hotéis, Motéis, Resorts - MOTEL 6 |
| 3703 | Hospedagem – Hotéis, Motéis, Resorts - RESIDENCE INNS |
| 3709 | Hospedagem – Hotéis, Motéis, Resorts - SUPER 8 MOTELS |
| 3710 | Hospedagem – Hotéis, Motéis, Resorts - THE RITZ-CARLTON |
| 3715 | Hospedagem – Hotéis, Motéis, Resorts - FAIRFIELD INN |
| 3721 | Hospedagem – Hotéis, Motéis, Resorts - HILTON CONRAD |
| 3722 | Hospedagem – Hotéis, Motéis, Resorts - WYNDHAM |
| 3728 | Hospedagem – Hotéis, Motéis, Resorts - BALLY’S HOTEL AND CASINO |
| 3740 | Hospedagem – Hotéis, Motéis, Resorts - TOWNEPLACE SUITES |
| 3742 | Hospedagem – Hotéis, Motéis, Resorts - CLUB MED |
| 3750 | Hospedagem – Hotéis, Motéis, Resorts - CROWNE PLAZA HOTELS |
| 3751 | Hospedagem – Hotéis, Motéis, Resorts - HOMEWOOD SUITES |
| 3770 | Hospedagem – Hotéis, Motéis, Resorts - SPRINGHILL SUITES |
| 3771 | Hospedagem – Hotéis, Motéis, Resorts - CAESAR’S HOTEL AND CASINO |
| 3773 | Hospedagem – Hotéis, Motéis, Resorts - THE VENETIAN RESORT HOTEL CASINO |
| 3777 | Hospedagem – Hotéis, Motéis, Resorts - MANDALAY BAY RESORT |
| 3778 | Hospedagem – Hotéis, Motéis, Resorts - FOUR POINTS HOTELS |
| 3779 | Hospedagem – Hotéis, Motéis, Resorts - W HOTELS |
| 3780 | Hospedagem – Hotéis, Motéis, Resorts - DISNEY RESORTS |
| 3791 | Hospedagem – Hotéis, Motéis, Resorts - STAYBRIDGE SUITES |
| 3807 | Hospedagem – Hotéis, Motéis, Resorts - ELEMENT |
| 3811 | Hospedagem – Hotéis, Motéis, Resorts - PREMIER INN |
| 3812 | Hospedagem – Hotéis, Motéis, Resorts - HYATT PLACE |
| 3813 | Hospedagem – Hotéis, Motéis, Resorts - HOTEL INDIGO |
| 3816 | Hospedagem – Hotéis, Motéis, Resorts - HOME2SUITES |
| 3824 | Hospedagem – Hotéis, Motéis, Resorts - ARIA |
| 3826 | Hospedagem – Hotéis, Motéis, Resorts - AUTOGRAPH |
| 3829 | Hospedagem – Hotéis, Motéis, Resorts - COUNTRY INN BY RADISSON |
| 3832 | Hospedagem – Hotéis, Motéis, Resorts - CURIO HOTELS |
| 4111 | Transporte local e suburbano de passageiros, incluindo balsas |
| 4112 | Ferrovias de Passageiros |
| 4119 | Serviços de ambulância |
| 4121 | Táxis e limusines |
| 4131 | Linhas de ônibus |
| 4214 | Transportadoras de carga motorizada e caminhões - empresas locais e de longa distância, empresas de movimentação e armazenamento e serviços de entrega local |
| 4215 | Serviços de Courier – Aéreo e Terrestre, e Transitários |
| 4225 | Armazenagem e Armazenamento Público - Produtos Agrícolas, Bens Refrigerados, Bens Domésticos e Armazenamento |
| 4411 | Navios a vapor e cruzeiros |
| 4457 | Aluguel e leasing de barcos |
| 4468 | Marinas, serviços marítimos e suprimentos |
| 4511 | Companhias aéreas e transportadoras aéreas (não classificadas em outros lugares) |
| 4582 | Aeroportos, campos voadores e terminais aeroportuários |
| 4722 | Agências de viagens e operadores turísticos |
| 4784 | Portagens e taxas de pontes |
| 4789 | Serviços de transporte (não classificados em outra parte) |
| 4812 | Vendas de equipamentos de telecomunicações e telefone |
| 4814 | Serviços de telecomunicações, incluindo chamadas locais e de longa distância, chamadas com cartão de crédito, chamadas através do uso de telefones com leitura de tarja magnética e serviços de fax |
| 4816 | Rede de computadores/serviços de informação |
| 4821 | Serviços telegráficos |
| 4829 | Transferência de dinheiro |
| 4899 | Cabo, satélite e outros serviços de televisão/rádio/streaming pagos |
| 4900 | Utilidades – Elétrica, Gás, Água e Sanitária |
| 5013 | Suprimentos para veículos motorizados e peças novas |
| 5021 | Móveis para Escritório e Comerciais.... |
| 5039 | Materiais de construção (não classificados em outra parte) |
| 5044 | Equipamentos e suprimentos fotográficos, fotocópias e microfilmes |
| 5045 | Computadores e equipamentos e software periféricos de computador |
| 5046 | Equipamento comercial (não classificado em outra parte) |
| 5047 | Equipamentos e Suprimentos Médicos, Odontológicos, Oftalmológicos e Hospitalares |
| 5051 | Centros e escritórios de serviços metálicos |
| 5065 | Peças e equipamentos elétricos |
| 5072 | Hardware, Equipamentos e Suprimentos |
| 5074 | Equipamentos e suprimentos para encanamento e aquecimento |
| 5085 | Suprimentos industriais (não classificados em outra parte) |
| 5094 | Pedras e metais preciosos, relógios e joias |
| 5099 | Bens duráveis ​​(não classificados em outra parte) |
| 5111 | Papelaria, material de escritório, papel para imprimir e escrever |
| 5122 | Drogas, proprietários de drogas e artigos diversos para farmacêuticos |
| 5131 | Produtos por peça, noções e outros produtos secos |
| 5137 | Uniformes e roupas comerciais masculinas, femininas e infantis |
| 5139 | Calçado Comercial |
| 5169 | Produtos Químicos e Afins (Não Classificados em Outra Parte) |
| 5172 | Petróleo e Produtos Petrolíferos |
| 5192 | Livros, periódicos e jornais |
| 5193 | Suprimentos para floristas, estoque de viveiro e flores |
| 5198 | Tintas, Vernizes e Suprimentos |
| 5199 | Bens não duráveis ​​(não classificados em outra parte) |
| 5200 | Armazéns de suprimentos domésticos |
| 5211 | Lojas de madeira e materiais de construção |
| 5231 | Lojas de vidro, tinta e papel de parede |
| 5251 | Lojas de ferragens |
| 5261 | Viveiros e lojas de materiais para gramados e jardins |
| 5271 | Revendedores de casas móveis |
| 5300 | Clubes de atacado |
| 5309 | Lojas Duty Free |
| 5310 | Lojas de desconto |
| 5311 | Lojas de departamento |
| 5331 | Lojas de variedades |
| 5399 | Mercadorias Gerais Diversas |
| 5411 | Mercearias e Supermercados |
| 5422 | Fornecedores de carne para congeladores e armários |
| 5441 | Lojas de doces, nozes e confeitaria |
| 5451 | Lojas de laticínios |
| 5462 | Padarias |
| 5499 | Lojas de alimentos diversos – Lojas de conveniência e mercados especializados |
| 5511 | Revendedores de carros e caminhões (novos e usados), vendas, serviços, reparos, peças e leasing |
| 5521 | Revendedores de carros e caminhões (somente usados) Vendas, serviços, reparos, peças e leasing |
| 5532 | Lojas de pneus automotivos |
| 5533 | Lojas de peças e acessórios automotivos |
| 5541 | Postos de Atendimento (Com ou sem Serviços Auxiliares) |
| 5542 | Distribuidores de combustível automatizados |
| 5551 | Revendedores de barcos |
| 5561 | Revendedores de trailers para campistas, recreativos e utilitários |
| 5571 | Lojas e revendedores de motocicletas |
| 5599 | Revendedores diversos de automóveis, aeronaves e equipamentos agrícolas (não classificados em outro lugar) |
| 5611 | Lojas de roupas e acessórios masculinos e masculinos |
| 5621 | Lojas de pronto-a-vestir feminino. |
| 5631 | Lojas especializadas e de acessórios femininos |
| 5641 | Lojas de roupas infantis e infantis |
| 5651 | Lojas de roupas familiares |
| 5655 | Lojas de roupas esportivas e de equitação |
| 5661 | Lojas de calçados |
| 5681 | Peleteiros e lojas de peles |
| 5691 | Lojas de roupas masculinas e femininas |
| 5697 | Alfaiates, Costureiras, Remendos e Alterações |
| 5698 | Lojas de perucas e perucas |
| 5699 | Lojas de roupas e acessórios diversos |
| 5712 | Lojas de móveis, artigos de decoração e equipamentos, exceto eletrodomésticos |
| 5713 | Lojas de revestimentos para pisos |
| 5714 | Lojas de cortinas, coberturas de janelas e estofados |
| 5719 | Diversas lojas especializadas em móveis domésticos |
| 5722 | Lojas de eletrodomésticos |
| 5732 | Lojas de eletrônicos |
| 5733 | Lojas de música – instrumentos musicais, pianos e partituras |
| 5734 | Lojas de software de computador |
| 5735 | Lojas de discos |
| 5811 | Fornecedores |
| 5812 | Locais para comer e restaurantes |
| 5813 | Locais para beber (bebidas alcoólicas) – Bares, tabernas, discotecas, salões de cocktails e discotecas |
| 5814 | Restaurantes fast food |
| 5815 | Mídia de bens digitais – livros, filmes, obras de arte/imagens digitais, música |
| 5816 | Bens Digitais – Jogos |
| 5817 | Bens Digitais – Aplicativos (Exclui Jogos) |
| 5818 | Bens Digitais – Grande Comerciante de Bens Digitais |
| 5912 | Drogarias e Farmácias |
| 5921 | Lojas de pacotes – cerveja, vinho e licores |
| 5931 | Mercadorias usadas e lojas de segunda mão |
| 5932 | Lojas de antiguidades – serviços de vendas, reparos e restauração |
| 5933 | Lojas de penhores |
| 5935 | Pátios de demolição e salvamento |
| 5937 | Reproduções antigas |
| 5940 | Lojas de bicicletas – Vendas e serviços |
| 5941 | Lojas de artigos esportivos |
| 5942 | Livrarias |
| 5943 | Papelarias, lojas de materiais para escritório e escolares |
| 5944 | Joalherias, lojas de relógios, relógios e talheres |
| 5945 | Lojas de hobby, brinquedos e jogos |
| 5946 | Lojas de câmeras e materiais fotográficos |
| 5947 | Lojas de presentes, cartões, novidades e lembranças |
| 5948 | Lojas de malas e artigos de couro |
| 5949 | Lojas de costura, bordados, tecidos e peças |
| 5950 | Lojas de vidrarias/cristais |
| 5960 | Marketing Direto – Serviços de Seguros |
| 5962 | Marketing direto – serviços de organização de viagens |
| 5963 | Vendas porta a porta |
| 5964 | Marketing Direto – Comerciante de Catálogo |
| 5965 | Marketing Direto – Combinação de Catálogo e Comerciante de Varejo |
| 5966 | Marketing direto – comerciante de telemarketing ativo |
| 5967 | Marketing Direto – Comerciante de Telesserviços Inbound |
| 5968 | Marketing Direto – Comerciante de Continuidade/Assinatura |
| 5969 | Marketing direto – outros profissionais de marketing direto (não classificados em outra parte) |
| 5970 | Lojas de materiais para artistas e artesanato |
| 5971 | Negociantes de arte e galerias |
| 5972 | Lojas de selos e moedas |
| 5973 | Lojas de artigos religiosos |
| 5975 | Aparelhos auditivos – vendas, serviços e fornecimento |
| 5976 | Artigos Ortopédicos – Dispositivos Protéticos |
| 5977 | Lojas de cosméticos |
| 5983 | Revendedores de combustível - óleo combustível, madeira, carvão e petróleo liquefeito |
| 5992 | Floristas |
| 5993 | Lojas e barracas de charutos |
| 5994 | Revendedores e bancas de jornais |
| 5995 | Pet Shops, lojas de alimentos e suprimentos para animais de estimação |
| 5996 | Piscinas – Vendas e Serviços |
| 5998 | Lojas de tendas e toldos |
| 5999 | Lojas de varejo diversas e especializadas |
| 6011 | Instituições Financeiras – Desembolsos de Dinheiro Automatizados |
| 6012 | Instituições Financeiras – Mercadorias, Serviços e Reembolso de Dívidas |
| 6051 | Instituições Não Financeiras – Moeda Estrangeira, em vigor até 19 de janeiro de 2024, Moeda Não-Fiduciária e em vigor a partir de 20 de janeiro de 2024 Ativos Líquidos e Criptomoedas (por exemplo: Criptomoeda), Ordens de Pagamento (Não Transferência de Dinheiro), Financiamento de Conta (não Carga de Valor Armazenado) ), Cheques de viagem e reembolso de dívidas |
| 6211 | Corretores/Revendedores de Segurança |
| 6300 | Vendas de seguros, subscrição e prêmios |
| 6513 | Agentes e Gestores Imobiliários |
| 6540 | Instituições Não Financeiras – Compra/Carga de Cartão com Valor Armazenado |
| 7011 | Hospedagem – Hotéis, Motéis, Resorts, Serviços Centrais de Reservas (Não Classificados em Outros Lugares) |
| 7012 | Compartilhamento de tempo |
| 7032 | Acampamentos Esportivos e Recreativos |
| 7033 | Parques de trailers e acampamentos |
| 7210 | Serviços de lavanderia, limpeza e vestuário |
| 7211 | Lavanderias – Familiares e Comerciais |
| 7216 | Lavanderias a seco |
| 7217 | Limpeza de carpetes e estofados |
| 7221 | Estúdios fotográficos |
| 7230 | Lojas de beleza e barbearias |
| 7251 | Oficinas de conserto de calçados, engraxates e oficinas de limpeza de chapéus |
| 7261 | Serviços Funerários e Crematórios |
| 7273 | Serviços de namoro |
| 7276 | Serviços de preparação de impostos |
| 7277 | Serviços de aconselhamento - dívidas, casamento e pessoais |
| 7278 | Serviços e clubes de compras e compras |
| 7296 | Aluguel de roupas – fantasias, uniformes, trajes formais |
| 7297 | Casas de massagem |
| 7298 | Spas de saúde e beleza |
| 7299 | Serviços pessoais diversos (não classificados em outra parte) |
| 7311 | Serviços de publicidade |
| 7321 | Agências de relatórios de crédito ao consumidor |
| 7333 | Fotografia comercial, arte e gráficos |
| 7338 | Serviços rápidos de cópia, reprodução e blueprinting |
| 7339 | Apoio Estenográfico e Secretariado |
| 7342 | Serviços de exterminação e desinfecção |
| 7349 | Serviços de limpeza, manutenção e zeladoria |
| 7361 | Agências de Emprego e Serviços de Ajuda Temporária |
| 7372 | Serviços de programação de computadores, processamento de dados e design de sistemas integrados |
| 7375 | Serviços de recuperação de informações |
| 7379 | Manutenção, reparo e serviços de computadores (não classificados em outra parte) |
| 7392 | Serviços de gestão, consultoria e relações públicas |
| 7393 | Agências de detetives, serviços de proteção e serviços de segurança, incluindo carros blindados e cães de guarda |
| 7394 | Aluguel e locação de equipamentos, ferramentas, móveis e eletrodomésticos |
| 7395 | Laboratórios de Fotoacabamento e Revelação Fotográfica |
| 7399 | Serviços empresariais (não classificados em outra parte) |
| 7512 | Agência de aluguel de automóveis |
| 7513 | Aluguel de caminhões e trailers utilitários |
| 7519 | Aluguel de motorhomes e veículos recreativos |
| 7523 | Estacionamentos, parquímetros e garagens |
| 7531 | Oficinas de conserto de carrocerias automotivas |
| 7534 | Oficinas de recauchutagem e reparação de pneus |
| 7535 | Oficinas de pintura automotiva |
| 7538 | Oficinas de serviços automotivos (não revendedores) |
| 7542 | Lavagens de carros |
| 7549 | Serviços de reboque |
| 7622 | Oficinas de conserto de eletrônicos |
| 7623 | Oficinas de conserto de ar condicionado e refrigeração |
| 7629 | Oficinas de reparos elétricos e de pequenos eletrodomésticos |
| 7631 | Conserto de relógios, relógios e joias |
| 7641 | Móveis – Reestofamento, Reparo e Refinamento |
| 7692 | Serviços de soldagem |
| 7699 | Oficinas diversas e serviços relacionados |
| 7829 | Produção e distribuição de filmes e fitas de vídeo |
| 7832 | Cinemas |
| 7841 | Lojas de aluguel de fitas de DVD/vídeo |
| 7911 | Salões de dança, estúdios e escolas |
| 7922 | Agências de ingressos e produtores teatrais (exceto filmes) |
| 7929 | Bandas, orquestras e artistas diversos (não classificados em outra parte) |
| 7932 | Estabelecimentos de bilhar e piscina |
| 7933 | Aliados de bowling |
| 7941 | Esportes Comerciais, Clubes Esportivos Profissionais, Campos de Atletismo e Promotores Esportivos |
| 7991 | Atrações Turísticas e Exposições |
| 7992 | Campos de golfe públicos |
| 7993 | Suprimentos para videogames de diversão |
| 7994 | Fliperamas/estabelecimentos de videogame |
| 7996 | Parques de diversões, circos, carnavais e cartomantes |
| 7997 | Clubes de associados (esportivos, recreativos, atléticos), clubes de campo e campos de golfe privados |
| 7998 | Aquários, aquários marinhos, delfinários e zoológicos |
| 7999 | Serviços recreativos (não classificados em outra parte) |
| 8011 | Médicos e Médicos (Não Classificados em Outros Lugares) |
| 8021 | Dentistas e Ortodontistas |
| 8041 | Quiropráticos |
| 8042 | Optometristas e oftalmologistas |
| 8043 | Ópticos, produtos ópticos e óculos |
| 8049 | Podólogos e quiropodistas |
| 8050 | Instalações de enfermagem, assistência médica domiciliar e cuidados pessoais |
| 8062 | Hospitais |
| 8071 | Laboratórios Médicos e Odontológicos |
| 8099 | Serviços médicos e profissionais de saúde (não classificados em outra parte) |
| 8111 | Serviços Jurídicos e Advogados |
| 8211 | Escolas primárias e secundárias |
| 8220 | Faculdades, universidades, escolas profissionais e faculdades juniores |
| 8241 | Escolas por correspondência |
| 8244 | Escolas de Negócios e Secretariado |
| 8249 | Escolas Profissionais e Comerciais |
| 8299 | Escolas e serviços educacionais (não classificados em outra parte) |
| 8351 | Serviços de cuidados infantis |
| 8398 | Organizações de caridade de serviço social |
| 8641 | Associações Cívicas, Sociais e Fraternas |
| 8661 | Organizações Religiosas |
| 8675 | Associações Automobilísticas |
| 8699 | Organizações associadas (não classificadas em outro lugar) |
| 8734 | Laboratórios de testes (testes não médicos) |
| 8911 | Serviços de arquitetura, engenharia e topografia |
| 8931 | Serviços de contabilidade, auditoria e escrituração contábil |
| 8999 | Serviços profissionais (não classificados em outra parte) |
| 9222 | Multas |
| 9311 | Pagamentos de impostos |
| 9399 | Serviços governamentais (não classificados em outra parte) |
| 9402 | Serviços Postais – Somente Governo |
| 9405 | Agências ou Departamentos do Governo Federal dos EUA |
| 9406 | Loterias de propriedade do governo (região fora dos EUA) |

---

## 6. Apêndice — Heurísticas rápidas de classificação

Atalhos úteis para o assistente:

- **PIX/TED/DOC recebido sem origem clara** → `5 – Outros Rendimentos` (se receita) ou `39436 – Transferência` (se entre contas próprias).
- **PIX/TED/DOC enviado sem destino claro** → `39436 – Transferência`.
- **Salário, proventos, holerite** → `1 – Salário`.
- **Vale Alimentação (crédito recebido)** → `2 – Vale Alimentação`.
- **PLR, bônus, dividendos, JCP** → `4 – Bonificação`.
- **Restituição de IR** → `3 – Restituição de IR`.
- **Compra genérica em marketplace (Amazon, Mercado Livre, Shopee, Magalu)** sem identificação do item → `44 – Compras Diversas`.
- **PicPay / Mercado Pago** sem indicação clara → `44 – Compras Diversas` (exceto tarifa → 59, transferência → 39436).
- **Tarifa bancária, juros do rotativo** → `59 – Serviços Financeiros`.
- **IOF em operações financeiras (câmbio, crédito)** → `3787 – IOF`.
- **Contribuição sindical, anuidade de classe (CNAE 9412-0/99)** → `3788 – Encargos e Tarifas`.
- **Lotérica / aposta esportiva regulamentada / Mega-Sena** → `61 – Jogos e Loterias`.
- **Combustível em posto** → `37 – Combustível`.
- **Estacionamento, pedágio, Zona Azul** → `38 – Estacionamento e Pedágio`.
- **Uber, 99, táxi, ônibus urbano, metrô** → `41 – Transporte Urbano e Apps`.
- **Passagem aérea, hotel, locação de carro para viagem, cruzeiro** → `21 – Viagens e Lazer`.
- **Supermercado, açougue, hortifruti** → `32 – Feira e Supermercado`.
- **Restaurante, bar, lanchonete, fast food, padaria** → `35 – Bares e Restaurantes`.
- **Farmácia, drogaria** → `30 – Farmácias e Drogarias`.
- **Plano de saúde mensal** → `27 – Plano de Saúde`.
- **Consulta médica, exame, laboratório** → `28 – Serviços de Saúde`.
- **Dentista, ortodontista** → `29 – Dentista`.
- **Streaming (Netflix, Spotify, Disney+, etc.)** → `53 – Assinatura TV e Streaming`.
- **Internet, telefonia, celular pós-pago** → `51 – Telefonia e Internet`.
- **IPTU** → `54`. **IPVA / Detran** → `55`. **IR a pagar** → `56`. **GPS/INSS** → `58`.
- **Compra de imóvel ou prestação imobiliária** → `9 – Compra de Imóvel`.
- **Aluguel residencial/comercial + condomínio** → `10 – Aluguel e Condomínio`.
- **Pet, ração, veterinário** → `14 – Animais e Pets`.
- **Crédito recebido de empresa agro / cooperativa rural** → `300 – Receitas Agro`.
- **Defensivos, fertilizantes, sementes, ração para confinamento** → `350 – Insumos`.
- **Cultivo (plantio, colheita, beneficiamento)** → `330 – Cultivos`. **Criação animal** → `310 – Criações`.
- **Serviços rurais terceirizados (pulverização, colheita mecanizada, transporte de safra)** → `370 – Apoio Produtivo`.
- **Cartão de crédito (pagamento de fatura)** → `111 – Cartão de Crédito`.
- **Aplicação em CDB/Tesouro/Fundo** → `448977 – Aplicação`. **Resgate** → `448978`.
- **Empréstimo, parcela de financiamento (não imobiliário)** → `4417 – Empréstimos e Prestações`.
- **Saque em ATM** → `39435 – Saque`. **Cheque emitido/recebido** → `39434 – Cheque`. **Boleto avulso sem categoria clara** → `39437 – Boletos Diversos`.

---

## 7. Metadados

- Total de categorias internas: **69**. O código `0` foi removido em 2026-08-14 (ver Seção 2.3).
- Total de categorias com definição detalhada: **69**.
- Total de faixas MCC mapeadas para categoria: **75**.
- Total de códigos MCC oficiais listados: **410**.
- Fonte das definições: aba `Tesauro` (versão mais recente; `Categorias_Def` é uma versão anterior — pequenas divergências nos códigos 44 e 3788 foram resolvidas em favor da Tesauro).
