
# AGENTE MINHAS FINANÇAS
## Matriz de Pendências de Integração — IBM

### 1. Conclusão executiva

O desenho de integração está definido, mas não há evidência disponível que permita declarar sua homologação no ambiente real do projeto.

A documentação pública do IBM watsonx Orchestrate confirma capacidades de integração de agentes externos por Chat Completions, incluindo a opção `Send conversation history` e o uso do cabeçalho `X-IBM-THREAD-ID`.

Entretanto, a existência dessas funcionalidades na documentação não comprova que estejam habilitadas ou funcionando conforme o esperado no ambiente do AGENTE MINHAS FINANÇAS.

**Recomendação:** manter a arquitetura e as decisões negociais já aprovadas, condicionando a disponibilização do MVP à homologação dos contratos de integração, histórico, identidade, segurança e comportamento operacional.

---

## 2. Critérios de classificação

| Situação | Significado |
|---|---|
| Confirmado documentalmente | Existe contrato de projeto ou documentação técnica que define ou suporta o comportamento, sem comprovação de execução no ambiente. |
| Homologado no ambiente | Existe teste executado no ambiente do projeto, com resultado aprovado e evidência rastreável. |
| Pendente | O comportamento precisa de configuração, confirmação documental específica ou teste de integração. |
| Não suportado | Existe evidência objetiva de incompatibilidade ou impossibilidade técnica. |

**Importante:** documentação pública da IBM comprova capacidades gerais do produto, não a configuração efetiva da instância utilizada.

### Estado das evidências disponíveis

- **Capacidades gerais identificadas na documentação IBM:** 3.
- **Homologações comprovadas com as evidências disponibilizadas:** 0.
- **Comportamentos comprovadamente não suportados:** nenhum identificado.

Isso não significa que o projeto não tenha executado homologações, apenas que suas evidências não foram disponibilizadas para esta análise.

---

## 3. Premissas arquiteturais aprovadas

As seguintes decisões estão confirmadas no escopo informado e não devem ser reabertas sem incompatibilidade técnica demonstrável.

| Decisão | Situação |
|---|---|
| Integração externa por Chat Completions | Aprovada; capacidade IBM documentada |
| IBM encaminha requisição HTTP e array `messages` | Contrato previsto; comportamento real pendente |
| Histórico conversacional recebido utilizado como está | Decisão aprovada do agente |
| Ausência de memória conversacional persistente própria | Decisão aprovada do agente |
| Ferramentas financeiras e RAGs coordenados pelo harness | Decisão aprovada do agente |
| Resposta externa compatível com `chat.completion` | Contrato previsto; aceitação pendente |
| Streaming desabilitado inicialmente | Decisão aprovada |
| `X-IBM-THREAD-ID` identifica a conversa | Contrato previsto; entrega pendente de homologação |
| `X-SENDER-ID` transporta credencial intermediária | Extensão prevista; homologação pendente |

**Princípio de fronteira:**

A IBM transporta a interação e o histórico conversacional. O harness executa a lógica financeira, controla ferramentas, RAGs, autorização e geração da resposta.

Essa separação não garante, por si só, que a IBM encaminhe todo o histórico sem alterações.

---

# 4. Matriz de validação — IBM × AGENTE MINHAS FINANÇAS

## Bloco A — Contrato e continuidade conversacional

### A01 — Contrato HTTP e `messages`

- **Situação:** Confirmado documentalmente; execução pendente.
- **Evidência disponível:** A especificação IBM de agente externo prevê `POST /chat/completions` e o campo `messages`.
- **Limitação conhecida:** Payload real ainda não capturado no ambiente do projeto.
- **Impacto potencial:** Incompatibilidade de campos, tipos ou estrutura das mensagens.
- **Responsável:** IBM + Integração.
- **Condição de encerramento:** Requisição real recebida e validada contra o contrato definido.

### A02 — Configuração `Send conversation history`

- **Situação:** Pendente no ambiente.
- **Evidência disponível:** Funcionalidade documentada no watsonx Orchestrate.
- **Limitação conhecida:** Estado da configuração no ambiente do projeto desconhecido.
- **Impacto potencial:** Perda de continuidade entre turnos.
- **Responsável:** IBM.
- **Condição de encerramento:** Evidência de configuração habilitada e teste multitur aprovado.

### A03 — Estrutura do histórico em vários turnos

- **Situação:** Pendente.
- **Evidência disponível:** Não há captura real disponibilizada.
- **Limitação conhecida:** Quantidade, ordenação e conteúdo efetivo desconhecidos.
- **Impacto potencial:** Interpretação incorreta de referências conversacionais.
- **Responsável:** IBM + Harness.
- **Condição de encerramento:** Comparação entre histórico original e `messages` recebido em conversas de 2, 5 e 10 turnos.

### A04 — Truncamento, seleção ou resumo do histórico

- **Situação:** Pendente.
- **Evidência disponível:** Não foi demonstrada garantia de preservação integral do histórico.
- **Limitação conhecida:** Limites e políticas de redução de contexto desconhecidos.
- **Impacto potencial:** Respostas baseadas em contexto incompleto.
- **Responsável:** IBM.
- **Condição de encerramento:** Limites documentados e testes de conversas longas, incluindo identificação de eventuais perdas.

### A05 — Preservação dos papéis das mensagens

- **Situação:** Confirmado documentalmente quanto ao esquema; preservação pendente.
- **Evidência disponível:** O esquema de Chat Completions publicado pela IBM contempla os papéis `system`, `user`, `assistant` e `tool`.
- **Limitação conhecida:** Aceitar os papéis no esquema não garante o encaminhamento integral em execução.
- **Impacto potencial:** Perda de instruções ou interpretação incorreta de mensagens técnicas.
- **Responsável:** IBM + Harness.
- **Condição de encerramento:** Testes verificando presença, ordem, conteúdo e metadados de cada papel necessário.

### A06 — Histórico com respostas de outros agentes

- **Situação:** Pendente.
- **Evidência disponível:** Sem evidência específica do projeto.
- **Limitação conhecida:** Desconhecido se a IBM inclui, filtra, transforma ou identifica respostas de outros agentes.
- **Impacto potencial:** Confusão de autoria, contexto e escopo.
- **Responsável:** IBM.
- **Condição de encerramento:** Conversa com alternância entre agentes, acompanhada de inspeção do histórico recebido.

### A07 — Preservação da resposta textual

- **Situação:** Pendente.
- **Evidência disponível:** O contrato Chat Completions contempla `choices[].message.content`.
- **Limitação conhecida:** Não há evidência de fidelidade do texto nas chamadas posteriores.
- **Impacto potencial:** Perda de valores, ressalvas, períodos ou outras informações financeiras.
- **Responsável:** IBM + Integração.
- **Condição de encerramento:** Comparação entre resposta emitida pelo agente, resposta exibida ao cliente e conteúdo reenviado no histórico.

**Conclusão do Bloco A:**

O agente utilizará o histórico exatamente como o recebe, conforme a decisão aprovada.

Entretanto, essa decisão não equivale a garantir que o histórico recebido seja completo.

A fidelidade e a cobertura do histórico continuam dependentes de homologação.

---

## Bloco B — Datas, identidade e segurança

### B08 — Data, hora e timezone

- **Situação:** Pendente.
- **Evidência disponível:** O esquema externo não estabelece campos obrigatórios de timezone para o contexto da conversa.
- **Limitação conhecida:** Não se sabe se informações temporais serão encaminhadas, nem em qual formato.
- **Impacto potencial:** Erros em consultas como "hoje", "ontem" e "mês passado".
- **Responsável:** IBM + Harness.
- **Condição de encerramento:** Identificação da origem e do formato dos metadados temporais e homologação em cenários de virada de dia e mês.

### B09 — Cabeçalho `X-IBM-THREAD-ID`

- **Situação:** Confirmado documentalmente; homologação pendente.
- **Evidência disponível:** Cabeçalho opcional descrito pela IBM para identificação da thread.
- **Limitação conhecida:** Presença e estabilidade não comprovadas na integração do projeto.
- **Impacto potencial:** Dificuldade de correlação e rastreabilidade entre turnos.
- **Responsável:** IBM.
- **Condição de encerramento:** Mesmo identificador em turnos da mesma conversa e identificadores distintos entre conversas diferentes.

### B10 — Cabeçalho `X-SENDER-ID`

- **Situação:** Pendente.
- **Evidência disponível:** Extensão definida pelo projeto, sem comprovação de suporte específico nessa modalidade de integração.
- **Limitação conhecida:** Encaminhamento de cabeçalho personalizado desconhecido.
- **Impacto potencial:** Impossibilidade de propagar a credencial intermediária do cliente.
- **Responsável:** IBM + Segurança.
- **Condição de encerramento:** Cabeçalho recebido sem alteração, transportado de forma segura e credencial validada corretamente.

### B11 — Separação entre conversa, cliente e autorização

- **Situação:** Pendente quanto ao contrato de identidade.
- **Evidência disponível:** `X-IBM-THREAD-ID` documentado e credencial intermediária prevista no projeto.
- **Limitação conhecida:** Não existe evidência do contrato de vínculo entre thread e identidade autenticada.
- **Impacto potencial:** Risco de consulta de dados de outro cliente.
- **Responsável:** Arquitetura + Segurança + IBM.
- **Condição de encerramento:** Identidades distintas, vínculo validado e testes negativos de troca de cliente e thread aprovados.

### B12 — Autenticação, autorização e transporte

- **Situação:** Confirmado documentalmente quanto a opções de autenticação; requisitos completos pendentes.
- **Evidência disponível:** A IBM documenta opções como Bearer Token e API Key para conexão com agentes externos.
- **Limitação conhecida:** Configuração efetiva de TLS, credenciais, autorização e controles de rede desconhecida.
- **Impacto potencial:** Acesso indevido ou exposição de informações financeiras.
- **Responsável:** Segurança + Infraestrutura + IBM.
- **Condição de encerramento:** Controles de autenticação, autorização, transporte e proteção de credenciais aprovados em revisão de segurança e testes de integração.

### B13 — Expiração e renovação da credencial intermediária

- **Situação:** Pendente.
- **Evidência disponível:** Sem contrato de ciclo de vida disponibilizado.
- **Limitação conhecida:** TTL, renovação, revogação e comportamento após expiração desconhecidos.
- **Impacto potencial:** Interrupção de consultas financeiras ou uso indevido de credenciais.
- **Responsável:** IAM/Segurança + IBM.
- **Condição de encerramento:** Testes de credencial válida, vencida, revogada e renovada, com respostas de erro apropriadas.

### B14 — Limites de requisição, contexto e execução

- **Situação:** Pendente.
- **Evidência disponível:** Documentação consultada não estabelece os limites efetivos aplicáveis à instância do projeto.
- **Limitação conhecida:** Payload máximo, contexto efetivo, duração e tamanho máximo de resposta desconhecidos.
- **Impacto potencial:** Interrupção de consultas, perda de histórico ou respostas incompletas.
- **Responsável:** IBM + Infraestrutura + Harness.
- **Condição de encerramento:** Limites por ambiente registrados e testes de fronteira executados.

### Distinção obrigatória de identidades

**Identidade da conversa**
- Representada por `X-IBM-THREAD-ID`.
- Identifica a thread.
- Não comprova, isoladamente, a identidade do cliente.

**Identidade do cliente**
- Deve ser obtida por mecanismo autenticado e validável.
- Deve possuir vínculo verificável com o escopo autorizado.

**Credencial de autorização**
- Permite acesso às ferramentas financeiras após validação.
- Deve possuir autenticidade, validade e permissões verificáveis.

O `X-SENDER-ID`, no desenho aprovado, está previsto para transportar a credencial intermediária. Seu nome não o torna automaticamente um identificador confiável do cliente.

A autenticação da IBM perante o endpoint do agente é distinta da autorização do cliente perante os serviços financeiros.

**Conclusão do Bloco B:**

A propagação e a validação da credencial intermediária constituem dependência crítica para a disponibilização de consultas financeiras personalizadas.

---

## Bloco C — Respostas, erros e operação

### C15 — Tratamento de erros HTTP e Chat Completions

- **Situação:** Pendente.
- **Evidência disponível:** O contrato define respostas de sucesso, mas não comprova o tratamento operacional completo de falhas no fluxo do projeto.
- **Limitação conhecida:** Comportamento diante de HTTP 401, 403, 429, 500, 503, timeout e payload inválido desconhecido.
- **Impacto potencial:** Mensagens incorretas, falhas ocultadas ou interpretação errada de indisponibilidade.
- **Responsável:** IBM + Harness.
- **Condição de encerramento:** Matriz de erros validada ponta a ponta, incluindo mensagens apresentadas ao cliente.

### C16 — Excesso de entrada ou tempo de execução

- **Situação:** Pendente.
- **Evidência disponível:** Sem testes ou limites efetivos fornecidos.
- **Limitação conhecida:** Desconhecido se a IBM rejeita, encerra, tenta novamente ou transforma a requisição.
- **Impacto potencial:** Respostas incompletas ou execuções duplicadas.
- **Responsável:** IBM + Infraestrutura.
- **Condição de encerramento:** Testes acima dos limites, com registro de erros, timeouts e eventual comportamento de retry.

### C17 — Dependência do conteúdo da resposta

- **Situação:** Pendente.
- **Evidência disponível:** Compatibilidade estrutural com `chat.completion` documentada.
- **Limitação conhecida:** Desconhecido se a IBM aplica pós-processamento, moderação, roteamento ou formatação adicional que afete o conteúdo.
- **Impacto potencial:** Perda de ressalvas ou alteração da interpretação financeira.
- **Responsável:** IBM + Negócio + Harness.
- **Condição de encerramento:** Testes de fidelidade textual, formatação, mensagens de limitação e respostas extensas.

### C18 — Concorrência, disponibilidade e desempenho

- **Situação:** Pendente.
- **Evidência disponível:** Sem compromissos operacionais específicos disponibilizados.
- **Limitação conhecida:** SLA, throughput, concorrência, retries e latência não pactuados nesta análise.
- **Impacto potencial:** Lentidão, falhas intermitentes ou interferência entre sessões.
- **Responsável:** IBM + SRE/Infraestrutura.
- **Condição de encerramento:** SLOs acordados e testes de carga, concorrência, isolamento e recuperação aprovados.

### C19 — Conversa simples e conversa com histórico

- **Situação:** Pendente.
- **Evidência disponível:** Não foram fornecidos logs, evidências de execução ou aceite.
- **Limitação conhecida:** Ainda não há comprovação ponta a ponta.
- **Impacto potencial:** Falha funcional no fluxo básico do MVP.
- **Responsável:** QA + IBM + Harness.
- **Condição de encerramento:** Suíte mínima de homologação aprovada com evidências anexadas.

### C20 — Compatibilidade com o comportamento negocial do MVP

- **Situação:** Pendente.
- **Evidência disponível:** Regras negociais aprovadas; compatibilidade operacional ainda não demonstrada.
- **Limitação conhecida:** Histórico, credenciais, datas e falhas podem afetar as respostas.
- **Impacto potencial:** Respostas financeiras equivocadas ou indisponibilidade de funcionalidades aprovadas.
- **Responsável:** Produto + Arquitetura + IBM.
- **Condição de encerramento:** Cenários negociais críticos executados com dados controlados e resultados aprovados.

**Conclusão do Bloco C:**

A compatibilidade do formato Chat Completions é necessária, mas não suficiente para homologar o comportamento operacional da integração.

---

# 5. Casos mínimos de homologação

Os testes devem ser executados a partir da IBM, chegando ao endpoint real do agente, e não apenas por chamadas diretas ao harness.

| ID | Cenário | Critério de aprovação | Prioridade |
|---|---|---|---|
| H01 | Conversa de um turno | Requisição válida e resposta `chat.completion` aceita e exibida corretamente. | Bloqueante |
| H02 | Conversa com múltiplos turnos | Histórico recebido permite recuperar referências relevantes de turnos anteriores. | Bloqueante |
| H03 | Troca entre agentes | Sem contaminação de contexto; autoria e conteúdo das mensagens relevantes identificáveis. | Bloqueante |
| H04 | Histórico com diferentes papéis | Papéis, conteúdos e ordem compatíveis com o contrato acordado. | Bloqueante quando utilizados |
| H05 | Conversa longa | Comportamento de truncamento e limitação conhecido, sem conclusões baseadas em contexto ausente. | Bloqueante |
| H06 | Fidelidade da resposta | Valores, datas e ressalvas preservados na exibição e nos turnos posteriores. | Bloqueante |
| H07 | Identificação de thread | Identificador estável na mesma conversa e isolado entre conversas diferentes. | Bloqueante |
| H08 | Identidade e credencial intermediária | Cabeçalho aceito, identidade validada e ausência de acesso cruzado. | Bloqueante |
| H09 | Credencial inválida ou expirada | Acesso recusado, sem exposição de dados financeiros. | Bloqueante |
| H10 | Datas relativas e timezone | Expressões temporais resolvidas conforme a referência definida pelo sistema. | Bloqueante |
| H11 | Timeout, excesso de contexto e indisponibilidade | Falhas tratadas sem respostas financeiras inventadas ou falso sucesso. | Bloqueante |
| H12 | Concorrência e recuperação | Sessões isoladas e desempenho dentro dos SLOs pactuados. | Bloqueante |

## Evidências exigidas

Cada teste deve apresentar:

- Identificador do teste.
- Ambiente e versão da IBM.
- Configuração utilizada.
- Identificação da execução.
- Entrada e saída relevantes.
- Resultado esperado.
- Resultado observado.
- Status de aprovação.
- Responsável pelo aceite.
- Evidências técnicas anexadas.

Logs e evidências devem proteger segredos, credenciais e dados financeiros sensíveis.

---

# 6. Impactos sobre o comportamento negocial aprovado

Não há necessidade de rever decisões aprovadas por mera possibilidade de limitação técnica.

A revisão somente se justifica diante de incompatibilidade efetivamente demonstrada.

| Dependência não validada | Comportamento potencialmente afetado | Tratamento necessário |
|---|---|---|
| Histórico completo | Perguntas de continuidade, como "e no mês anterior?" | Responder somente quando o contexto recebido for suficiente. |
| Credencial intermediária | Consulta personalizada a contas e transações | Não acessar dados financeiros sem identidade e autorização válidas. |
| Timezone | Datas relativas e comparações temporais | Utilizar referência temporal confiável ou esclarecer ambiguidades. |
| Integridade do texto | Exibição de valores e limitações financeiras | Homologar a fidelidade da resposta antes da disponibilização. |
| Limites de execução | Consultas extensas e agregações | Tratar falhas explicitamente, sem confundir indisponibilidade com ausência de gastos. |
| Isolamento de conversas | Confidencialidade das informações | Impedir acesso cruzado entre clientes e threads. |

---

# 7. Critérios de liberação do MVP

## Checklist de homologação

- [ ] Chat Completions homologado ponta a ponta.
- [ ] Histórico multitur homologado no escopo aprovado.
- [ ] Identidade do cliente e credencial intermediária homologadas.
- [ ] Autenticação, autorização e isolamento aprovados.
- [ ] Datas e timezone validados.
- [ ] Fidelidade das respostas e tratamento de erros aprovados.
- [ ] Limites, timeout, desempenho e concorrência aceitos.
- [ ] Cenários negociais críticos executados e aprovados.

**Condição de liberação:** todos os critérios bloqueantes aplicáveis ao escopo do MVP devem possuir evidência de homologação e aceite dos responsáveis.

---

# 8. Parecer consolidado

## 8.1 Confirmado documentalmente

A documentação pública da IBM apresenta suporte para:

1. Integração de agentes externos via Chat Completions.
2. Opção de envio de histórico conversacional (`Send conversation history`).
3. Cabeçalho `X-IBM-THREAD-ID` para identificação da thread.

Essas capacidades não comprovam sua configuração ou funcionamento no ambiente específico do projeto.

## 8.2 Homologado no ambiente

Nenhum comportamento pode ser declarado homologado com as evidências disponibilizadas nesta análise.

## 8.3 Pendente

Permanecem dependentes de validação:

1. Configuração efetiva de `Send conversation history`.
2. Conteúdo e ordenação de `messages`.
3. Preservação de histórico e comportamento de truncamento.
4. Preservação de papéis e respostas de outros agentes.
5. Fidelidade das respostas em turnos posteriores.
6. Metadados temporais e timezone.
7. Entrega e estabilidade de `X-IBM-THREAD-ID`.
8. Encaminhamento de `X-SENDER-ID`.
9. Separação e validação de identidade e autorização.
10. Segurança do transporte e ciclo de vida das credenciais.
11. Limites de requisição, contexto, execução e resposta.
12. Tratamento de erros, timeouts e indisponibilidade.
13. Eventuais transformações do conteúdo pela IBM.
14. Concorrência, isolamento, disponibilidade e desempenho.
15. Homologação dos cenários críticos do MVP.

## 8.4 Não suportado

Nenhuma incompatibilidade foi demonstrada conclusivamente.

Ausência de documentação ou evidência não equivale a comprovação de que um comportamento não seja suportado.

---

# 9. Recomendação final

As duas dependências mais críticas para a disponibilização do AGENTE MINHAS FINANÇAS são:

**1. Propagação segura e homologada da credencial intermediária.**

Sem identidade e autorização válidas, o agente não pode executar consultas financeiras personalizadas com segurança.

**2. Fidelidade do histórico conversacional multitur.**

Sem memória conversacional persistente própria, a continuidade da conversa depende do contexto efetivamente entregue pela IBM.

A homologação deve comprovar essas capacidades no ambiente real, juntamente com os demais critérios bloqueantes.

**Princípio de encerramento:**

O contrato de integração somente deve ser considerado homologado quando o comportamento efetivamente observado corresponder ao comportamento aprovado, com evidências técnicas rastreáveis.

O objetivo não é reconsiderar as decisões negociais do MVP, mas assegurar que a fronteira IBM–Harness consiga executá-las de maneira confiável, segura e previsível.

---

# 10. Referências técnicas

Fontes oficiais para consulta e verificação da versão aplicável ao projeto:

- IBM watsonx Orchestrate — Documentação de agentes externos e integração por Chat Completions.
- IBM watsonx Orchestrate — Configuração `Send conversation history`.
- IBM watsonx Orchestrate — Especificação de API para agentes externos.
- IBM watsonx Orchestrate — Cabeçalhos de integração e `X-IBM-THREAD-ID`.
- IBM watsonx Orchestrate — Autenticação de agentes externos.
- IBM watsonx Orchestrate — Release notes e correções da versão implantada.

A documentação deve ser confrontada com a versão e o ambiente efetivamente utilizados antes do encerramento de qualquer pendência.
