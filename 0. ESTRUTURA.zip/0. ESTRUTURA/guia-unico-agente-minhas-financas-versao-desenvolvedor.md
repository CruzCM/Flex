# Agente Minhas Finanças — Guia Único de Arquitetura e Especificação do MVP

<!-- markdownlint-disable MD013 -->

> [!IMPORTANT]
> **Fonte Única da Verdade Universal:** A especificação oficial, completa e autoritativa do projeto encontra-se exclusivamente em **[`Documentação-Final-Agent-MF.md`](Documentação-Final-Agent-MF.md)**. Em qualquer dúvida ou divergência, prevalece exclusivamente [`Documentação-Final-Agent-MF.md`](Documentação-Final-Agent-MF.md).

| Informação | Conteúdo |
| --- | --- |
| **Fonte da Verdade Oficial** | **[`Documentação-Final-Agent-MF.md`](Documentação-Final-Agent-MF.md)** (referência universal negocial e técnica do projeto). |
| **Objetivo** | Especificação completa do MVP funcional com cinco ferramentas no MCP (resumo financeiro, consulta de lançamentos, consulta de categorias, educação financeira e ajuda do aplicativo), memória conversacional em RAM e trilha de execução observável. |
| **Público** | Desenvolvedores do Agente (`iaa-agent-minhas-financas`), do Servidor MCP (`iaa-mcp-mf`) e responsáveis pelos testes e avaliação. |
| **Situação** | Especificação técnica e funcional para implementação; não constitui comprovação de entrega executada nos repositórios de código. |
| **Premissa imutável de dados** | **A estrutura dos arquivos `.csv` (13 colunas), `.json` (`grupos_gfp.json`) e `.md` ([categorias_transacoes_estruturado.md](categorias_transacoes_estruturado.md) / `descricoes_categorias.md`) não pode ser alterada.** Esses formatos representam contratos oriundos dos sistemas corporativos. Qualquer normalização ou conciliação de nomes deve ocorrer nos *providers* em código. |
| **Ambiente inicial** | Massas sintéticas em [`clientes_sinteticos/`](clientes_sinteticos/) (`001.csv` a `007.csv`), catálogo local em Markdown/JSON, memória conversacional em RAM (`InMemorySaver`) e persistência local da trilha de execução em JSONL. |
| **Referências relacionadas** | [Documentação Final (Fonte Única da Verdade)](Documentação-Final-Agent-MF.md), [Plano de evolução do MCP financeiro](plano-evolucao-mcp-financeiro.md), [Guia de testes dos CSVs sintéticos](guia-testes-clientes-sinteticos-csv.md) e [Catálogo estruturado de categorias](categorias_transacoes_estruturado.md). |

---

## 1. Visão Geral, Escopo e Sequência do MVP

> **Proposta do agente:** *“Eu te ajudo a entender o que acontece com seu dinheiro e a usar o Minhas Finanças para acompanhar isso.”*

O Agente Minhas Finanças atende três necessidades que podem aparecer isoladas ou combinadas na mesma conversa:

| Frente | O que o cliente recebe | Limite operacional |
| --- | --- | --- |
| **1. Resumo e detalhamento financeiro pessoal** | Explicação simples das entradas, dos gastos de consumo, de onde se concentram as despesas e dos lançamentos que compõem cada valor (separando aplicações, resgates e pagamento de fatura). | Não chama a diferença entre entradas e gastos de "saldo em conta", não julga se o cliente "gastou demais" e não afirma conciliação completa de cartão sem lastro nos dados. |
| **2. Educação financeira** | Explicações acessíveis e breves sobre conceitos financeiros que surgem na conversa, com base nos trechos recuperados da base educativa. | Não vira aula automática, não define metas pessoais e não recomenda quanto gastar, poupar ou onde investir. |
| **3. Uso do aplicativo (App BB)** | Ajuda prática para localizar telas e utilizar jornadas documentadas do Minhas Finanças no App BB (consultar gastos, consultar entradas, encontrar lançamentos e entender categorias). | Orienta exclusivamente a partir da documentação recuperada, sem inventar telas, botões ou caminhos não documentados. |

Uma dúvida simples recebe uma resposta simples: o agente não precisa acionar as três frentes em toda interação e **só consulta os dados financeiros quando a pergunta depender do extrato**.

### Divisão de responsabilidades entre Modelo (LLM) e Código

- **Responsabilidade do código (determinística):** validar identidade e sessão (`session_id` ↔ `mci`), ler e validar o CSV e o catálogo, classificar movimentações, filtrar, ordenar, calcular somas e percentuais com precisão decimal, injetar `mci` nas ferramentas pessoais e registrar a trilha de execução (`execution_id`).
- **Responsabilidade do LLM (ReAct):** compreender a intenção do cliente (inclusive elipses e linguagem cotidiana), selecionar as ferramentas necessárias, interpretar os dados retornados sem realizar aritmética mental e redigir uma resposta clara com as ressalvas aplicáveis.

### Arquitetura de execução e observabilidade

```mermaid
flowchart LR
    C[Cliente] -->|POST /chat| API[FastAPI + Validação]
    API --> LG[LangGraph ReAct + InMemorySaver]
    LG -->|Sem mci no schema do LLM| WR[Wrapper de Ferramentas]
    WR -->|Injeta mci nas tools 1 e 2| MCP[Servidor FastMCP: iaa-mcp-mf]
    MCP --> T1[1. obter_resumo_financeiro]
    MCP --> T2[2. consultar_lancamentos]
    MCP --> T3[3. explicar_categoria]
    MCP --> T4[4. consultar_educacao_financeira]
    MCP --> T5[5. consultar_faq_minhas_financas]
    T1 & T2 --> P1[FonteDadosExtrato: CSV 13 colunas]
    T3 --> P2[FonteCategorias: Markdown + JSON]
    T4 & T5 --> GEN[GeneraBB Core: Educação / FAQ]
    API & LG & WR -.->|Coleta durante a execução| COL[EvaluationRecord: JSONL local]
    COL -.->|Quando diagnostico=true| DIAG[Resposta HTTP / Adaptadores DeepEval e Ragas]
```

### Modos de verificação

| Modo | Finalidade |
| --- | --- |
| **Teste técnico determinístico** | Verificar leitura dos 7 CSVs, reconciliação matemática entre resumo e detalhamento, filtros, ordenação, memória por sessão, bloqueio de troca de `mci` e preenchimento da trilha de execução. |
| **Teste com modelo efetivo** | Avaliar compreensão das intenções em diferentes formulações, seleção adequada das 5 ferramentas, fidelidade aos dados retornados e naturalidade conversacional. |

### Sequência de execução do MVP (4 passos)

1. **Passo 1 — Fechar contratos e resultados esperados:** fixar a classificação financeira, as regras de período e data de referência, os estados de carga dos 7 CSVs, o esquema das 5 ferramentas e o contrato de `diagnostico: false | true` com `execution_id`.
2. **Passo 2 — Implementar as 3 ferramentas financeiras e a integração Agente ↔ MCP:** construir `FonteDadosExtrato` e `FonteCategorias` no MCP, expor `obter_resumo_financeiro`, `consultar_lancamentos` e `explicar_categoria`, ativar `InMemorySaver` e injeção de `mci` no Agente e validar os testes numéricos determinísticos.
3. **Passo 3 — Conectar os 2 RAGs e validar as jornadas completas:** integrar `consultar_educacao_financeira` e `consultar_faq_minhas_financas`, validando tanto perguntas documentais isoladas (sem leitura de CSV) quanto conversas que transitam entre extrato, catálogo, educação e aplicativo (como a Jornada A completa).
4. **Passo 4 — Executar a avaliação conversacional:** rodar os cenários das jornadas e dos 5 comportamentos humanos com gabaritos explícitos (`case_id`), combinando asserções determinísticas para números financeiros e métricas do DeepEval/Ragas para seleção de ferramentas e recuperação documental.

---

## 2. Jornadas Conversacionais, Comportamentos Humanos e Limites dos Dados

As conversas do projeto são construídas a partir de **situações reais da vida financeira**, nas quais as ferramentas são consequência da dúvida do cliente. Um mesmo objetivo pode ser expresso de forma direta ou coloquial:

| Necessidade do cliente | Formulação direta / objetiva | Formulação contextual / coloquial | O que o agente precisa identificar |
| --- | --- | --- | --- |
| Entender o resumo do período | *"Quanto entrou e quanto saiu este mês?"* | *"Não sei o que tá acontecendo, recebi esses dias e já gastei quase tudo."* | Apresentar entradas, gastos de consumo e os principais grupos/categorias, separando aplicações, resgates e pagamento de fatura. |
| Conferir o detalhe de um grupo | *"Quais foram meus gastos com Alimentação?"* | *"Pera, eu gastei isso tudo com comida? Não é possível."* | Associar *"comida"* ao grupo `Alimentação` (`CodGrupo=6`) e detalhar categorias e lançamentos que formam o total. |
| Acompanhar gastos no aplicativo | *"Onde vejo meus gastos por categoria no app?"* | *"Tem algum lugar no app que eu consiga ficar de olho nisso?"* / *"Tinha uma tela que mostrava onde eu mais gastava. Onde fica mesmo?"* | Consultar a base de ajuda (`consultar_faq_minhas_financas`) e informar o caminho documentado da funcionalidade. |
| Entender uma categoria e ver seus itens | *"O que entra em Compras Diversas?"* | *"Que compras são essas aqui que aparecem como 'Diversas'?"* | Explicar a definição pelo catálogo (`explicar_categoria`) e, quando a fala apontar para o extrato do cliente (*"essas aqui"*), listar também os lançamentos da categoria (`consultar_lancamentos`). |
| Avaliar um gasto específico | *"Quanto gastei com Uber?"* | *"Será que eu tô gastando muito com Uber? Dá uma olhada pra mim."* | Buscar `"Uber"` na descrição (`consultar_lancamentos`), informando soma, quantidade e participação percentual no consumo do período, sem julgar pelo cliente. |
| Entender reserva de emergência | *"O que é reserva de emergência?"* | *"Todo mundo fala pra ter reserva de emergência, mas quanto eu preciso guardar?"* | Explicar como a referência é construída segundo a base educativa (`consultar_educacao_financeira`), sem prescrever meta individualizada ou produto. |

### Jornadas de referência (caminhos válidos de execução, não roteiros fixos no prompt)

> **Importante:** estas jornadas **não devem ser inseridas como roteiros fixos (*scripts*) no prompt de produção**. Elas orientam os testes de integração e avaliação. Se uma informação confiável já estiver presente no histórico do turno anterior, o modelo pode reutilizá-la sem repetir uma chamada idêntica.

#### Jornada A — O dinheiro não está rendendo (Resumo, Catálogo, Detalhamento e Aplicativo)

1. **Cliente:** *"Cara, não entendo. Parece que todo mês eu ganho e gasto tudo. O que tá pesando tanto?"*
   - **Caminho esperado:** `obter_resumo_financeiro` → apresenta entradas, gastos de consumo e os grupos/categorias onde as despesas se concentram (mantendo movimentações patrimoniais separadas).
2. **Cliente:** *"Mas pera, alimentação é tudo isso? Tá contando mercado também?"*
   - **Caminho esperado:** `explicar_categoria(termo="Alimentação")` → esclarece quais categorias compõem o grupo `Alimentação` (`Feira e Supermercado` e `Bar` / `Bares e Restaurantes`).
3. **Cliente:** *"Ahh, entendi. Então mostra só o que eu gastei em mercado."*
   - **Caminho esperado:** `consultar_lancamentos(categoria="Feira e Supermercado")` mantendo o período em foco na sessão → exibe a soma e os lançamentos da categoria.
4. **Cliente:** *"Nossa... e tem como eu ir vendo isso no app? Porque quando percebo já foi."*
   - **Caminho esperado:** `consultar_faq_minhas_financas` → orienta onde acompanhar gastos por categoria no aplicativo.

#### Jornada B — O cliente não confia no valor apresentado (Conferência e separação de fatura/aplicação)

1. **Cliente:** *"Esse valor de gasto aqui tá muito alto. Tem certeza que é isso mesmo?"*
   - **Caminho esperado:** `obter_resumo_financeiro` → informa o período considerado, o total de gastos de consumo e os componentes principais, sem insistir que o número está certo antes de demonstrar sua composição.
2. **Cliente:** *"Mas você não tá somando o pagamento do cartão junto com as compras, né?"* *(ou *"Ué, mas e aquele dinheiro que eu coloquei na aplicação? Você contou como gasto?"*)*
   - **Caminho esperado:** explica, com base nos totais separados (`total_fatura` e `total_aplicacoes`), que pagamento de fatura e aplicações financeiras não entram na soma dos gastos de consumo. **Limitação explícita:** o agente explica a regra de separação da base, mas não afirma que auditou se todas as compras individuais do cartão constam no extrato.
3. **Cliente:** *"Tá, então me mostra as compras maiores. Quero entender de onde saiu esse total."*
   - **Caminho esperado:** `consultar_lancamentos(escopo="consumo", ordenar_por="maior_valor")` → lista os maiores gastos de consumo do período, reconciliando com o resumo (sem misturar aplicação de R$ 300,00 ou pagamento de fatura de R$ 90,00 no topo das compras de consumo).

#### Jornada C — A pessoa começa sem saber o que perguntar (Descoberta e transição para Educação Financeira)

1. **Cliente:** *"Queria começar a cuidar melhor do meu dinheiro, mas nem sei por onde começar."*
   - **Caminho esperado:** sem disparar ferramenta desnecessária, propõe: *"A gente pode começar olhando onde seus gastos estão concentrados ou conversar sobre como organizar seu dinheiro. O que seria mais útil agora?"*
2. **Cliente:** *"Acho que ver meus gastos primeiro. Tenho a impressão de que tô gastando muito com coisa pequena."*
   - **Caminho esperado:** `obter_resumo_financeiro` (e `consultar_lancamentos` se necessário) → apresenta a distribuição dos gastos e a quantidade de lançamentos por categoria.
3. **Cliente:** *"E aquele negócio de separar uma grana pra emergência... como funciona?"*
   - **Caminho esperado:** reconhece a mudança de assunto e chama `consultar_educacao_financeira`, explicando o conceito com apoio documental sem reiniciar a conversa.

### Os 5 comportamentos humanos e o respeito aos limites reais dos dados

| # | Comportamento humano | Exemplos de fala | Regra de tratamento e limite dos dados |
| :-: | :--- | :--- | :--- |
| **1** | **Perguntas incompletas (Elipse)** | *"E mês passado?"* / *"E só em mercado?"* / *"Mas isso aí inclui o quê?"* | Recuperar período, grupo ou categoria do turno anterior pela memória da sessão (`session_id`) e alterar apenas o recorte pedido. |
| **2** | **Mudança de ideia** | *"Não, esquece mercado. Quero ver restaurante e delivery."* | Substituir o filtro anterior sem carregá-lo como restrição acumulada. Como *"delivery"* não é uma categoria oficial, filtrar pela categoria `Bares e Restaurantes` (`CodCategoria=35`) e/ou buscar termos na descrição conforme o caso, explicando o critério usado. |
| **3** | **Dúvida e desconfiança** | *"Não tô lembrando de ter comprado isso."* / *"Tem alguma coisa errada nessa conta."* | Exibir data, descrição, valor, categoria e instituição disponíveis no registro para ajudar na conferência, **sem concluir fraude, erro bancário ou legitimidade** apenas pela descrição. |
| **4** | **Linguagem cotidiana e termos subjetivos** | *"Gastei quanto com besteira?"* / *"O que tá comendo meu salário?"* / *"Onde tô deixando mais dinheiro?"* | Para *"o que tá comendo meu salário"*, apresentar a concentração de gastos do resumo. Para termos subjetivos (*"besteira"*, *"supérfluo"*), não inventar classificação: apresentar as categorias presentes no extrato e pedir que o cliente indique quais deseja considerar. |
| **5** | **Assuntos misturados** | *"Quanto foi de farmácia? E outra coisa, onde vejo isso no aplicativo?"* | Executar `consultar_lancamentos(categoria="Farmácias e Drogarias")` e `consultar_faq_minhas_financas`, respondendo ambas as partes (e preservando a parte válida se uma das ferramentas falhar). |

### Capacidades ausentes nas 13 colunas do CSV (não prometer ao cliente)

1. **Meio de pagamento (*"Só de cartão?"*, *"Foi no Pix ou no débito?"*):**
   - No CSV de 13 colunas, a coluna `Tipo` contém apenas `"Débito"` ou `"Crédito"` como **direção contábil** (saída vs. entrada). Ela **não informa o instrumento de pagamento** (cartão de crédito, cartão de débito, Pix, TED ou boleto).
   - Se o cliente pedir *"Me mostra só o que passei no cartão"*, o agente deve esclarecer que os dados do extrato disponível identificam o lançamento de **pagamento da fatura (`Cartão de Crédito (Fatura)`, código `111`)**, mas não separam quais compras de consumo foram pagas com cartão, Pix ou débito em conta.
2. **Identificação exata de estabelecimentos por busca textual (*"Uber"*, *"iFood"*):**
   - Filtrar por `termos_descricao` localiza os lançamentos cuja coluna `Descricao` contém o termo buscado. O agente deve apresentar os lançamentos encontrados sem afirmar que constituem 100% das transações com aquela empresa caso existam abreviações ou razões sociais distintas na fonte.

---

## 3. Criação Nova do Serviço, Migração do Legado e Contratos dos Providers

O `ServiceFinanceiro` no servidor MCP (`iaa-mcp-mf`) é uma **implementação nova**, construída para atender às 5 ferramentas do MVP. Do código legado aproveitamos apenas as regras de classificação e os catálogos de negócio:

### Matriz de reaproveitamento e criação

| Componente | Encaminhamento na nova implementação | Origem de referência | Situação |
| --- | --- | --- | --- |
| **Arquivos de massa (`.csv`) e catálogos (`.json`, `.md`)** | **Preservar estrutura sem qualquer alteração.** Ler diretamente nos providers `FonteDadosExtrato` e `FonteCategorias`. | [`clientes_sinteticos/`](clientes_sinteticos/), [categorias_transacoes_estruturado.md](categorias_transacoes_estruturado.md), `grupos_gfp.json` e `descricoes_categorias.md` | CSVs e catálogo Markdown presentes neste workspace; `grupos_gfp.json` no repositório legado. |
| **Classificação financeira (Consumo vs. Patrimonial)** | Implementar regra determinística que separa `CodGrupo=12` / `CodCategoria=111` (Fatura) e `CodGrupo=13` / `CodCategoria in (448977, 448978)` (Aplicação e Resgate) de consumo e receita. | Regra negocial consolidada em [Documentação-Final-Agent-MF.md](Documentação-Final-Agent-MF.md) | Regra documentada; validar com `001.csv`. |
| **Leitura e validação do extrato (`FonteDadosExtrato`)** | Implementar provider novo sobre os CSVs de 13 colunas, registrando contagens e motivos de descarte. | Contrato das 13 colunas de `GerenciadorDados.df` e `extrato_bb.py` | Especificado na Seção 3.1. |
| **Consulta e normalização do catálogo (`FonteCategorias`)** | Implementar provider novo com suporte a código, nome, grupo e tabela de aliases (resolvendo divergências como código `35`). | [categorias_transacoes_estruturado.md](categorias_transacoes_estruturado.md) e `consultar_tesauro.py` | Especificado na Seção 3.2. |
| **Cálculos de resumo e consulta filtrada** | Implementar funções próprias para `obter_resumo_financeiro` e `consultar_lancamentos`, descartando a antiga super-tool `resumir_extrato` de 19 parâmetros. | Novo `ServiceFinanceiro` em `iaa-mcp-mf` | Especificado na Seção 4. |
| **Estatísticas avançadas, atípicos, duplicidades e indicadores** | **Fora do escopo das tools do MVP.** | Catálogo de evolução futura | Não expor no MVP. |

### 3.1. Contrato do Provider `FonteDadosExtrato`

A estrutura dos arquivos [`001.csv`](clientes_sinteticos/001.csv) a [`007.csv`](clientes_sinteticos/007.csv) possui exatamente estas **13 colunas** (vindas do sistema):

```text
Descricao,Data,Categoria,Valor,Tipo,Instituicao,CodCategoria,CodGrupo,Ano,Mês,Dia,DiaSemana,MêsNome
```

O provider expõe o contrato interno:

```text
carregar_transacoes(mci: str) -> ResultadoCargaExtrato
```

#### Etapas obrigatórias de leitura e validação linha a linha (sem descarte silencioso)

1. **Leitura e validação estrutural do cabeçalho:** abrir `<mci>.csv` com `encoding="utf-8-sig"`. Verificar se as 13 colunas obrigatórias estão presentes na ordem esperada. Se o arquivo não existir ou o cabeçalho for inválido (caso de [`007.csv`](clientes_sinteticos/007.csv), que possui 1 linha de dados sob 3 colunas inválidas), retornar imediatamente `estado="indisponivel"` com motivo `"erro_schema_colunas"`.
2. **Verificação de arquivo vazio:** se o cabeçalho de 13 colunas for válido e houver `0` linhas de dados (caso de [`004.csv`](clientes_sinteticos/004.csv)), retornar `estado="sem_lancamentos_recebidos"`, `quantidade_linhas_csv=0`, `quantidade_linhas_validas=0`.
3. **Validação explícita de cada linha e contabilização de descartes (`descartes_por_motivo`):**
   - **Data (`Data`):** converter `YYYY-MM-DD` para `date`. Não usar `errors="coerce"` para apagar linhas silenciosamente: toda linha cuja data seja vazia ou inválida (ex.: `2026-13-40` em `005.csv` e `006.csv`) deve ser rejeitada e incrementar `descartes_por_motivo["data_invalida"]`.
   - **Valor monetário (`Valor`):** converter para `Decimal` (2 casas, `ROUND_HALF_UP`). Se não for numérico (ex.: `"abc"` em `005.csv`) ou for `NaN`, rejeitar e incrementar `descartes_por_motivo["valor_invalido"]`. Se for igual a `0.00` (em `005.csv` e `006.csv`), rejeitar e incrementar `descartes_por_motivo["valor_zero"]`.
   - **Direção e coerência de sinal (`Valor` vs. `Tipo`):** `Valor < 0` representa saída (`natureza="saida"`) e `Valor > 0` representa entrada (`natureza="entrada"`). Se `Tipo` vier preenchido em contradição com o sinal de `Valor` (ex.: `Valor < 0` com `Tipo="Crédito"`), registrar ocorrência em `alertas_qualidade["sinal_tipo_divergente"]` (ou descartar conforme regra configurada, mantendo o sinal de `Valor` como fonte primária se aproveitado).
   - **Códigos (`CodCategoria`, `CodGrupo`):** converter para `int`. Vazio ou ausente assume `0`. Se `CodCategoria` não existir no catálogo de 71 categorias (ex.: `9999` em `005.csv`), manter a transação válida com `cod_categoria_desconhecido=True` e agrupar `CodGrupo=0` em `"Sem grupo"`.
   - **Campos textuais (`Descricao`, `Categoria`, `Instituicao`):** tratar células vazias como `""` antes de qualquer conversão para string (impedindo que `NaN` vire o literal `"nan"`). `Descricao` vazia assume `"(sem descricao)"`; `Instituicao` vazia assume `None`; `Categoria` vazia ou igual a nome de instituição conhecida registra alerta em `alertas_qualidade`.
4. **Determinação do `estado` final da carga:**
   - `processado`: `quantidade_linhas_validas > 0` e total de linhas descartadas igual a `0` (`001.csv`, `002.csv`, `003.csv`).
   - `sem_lancamentos_recebidos`: `quantidade_linhas_csv == 0` (`004.csv`).
   - `inconclusivo`: `quantidade_linhas_csv > 0` com pelo menos 1 linha descartada — seja com aproveitamento parcial (`005.csv`: 8 lidas, 3 descartadas, 5 válidas), seja com 100% das linhas descartadas no pós-processamento (`006.csv`: 2 lidas, 2 descartadas, 0 válidas).
   - `indisponivel`: erro estrutural de colunas (`007.csv`) ou falha de leitura.

#### Matriz dos 7 cenários sintéticos ([guia-testes-clientes-sinteticos-csv.md](guia-testes-clientes-sinteticos-csv.md))

| CSV | Situação representada | Linhas no CSV | Linhas válidas | Estado esperado |
| --- | --- | ---: | ---: | --- |
| [`001.csv`](clientes_sinteticos/001.csv) | Massa completa de teste (maio a out/2026) | 22 | 22 | `processado` |
| [`002.csv`](clientes_sinteticos/002.csv) | Apenas uma saída de consumo (`-10.00` em `2026-10-10`) | 1 | 1 | `processado` |
| [`003.csv`](clientes_sinteticos/003.csv) | Apenas uma entrada de salário (`1000.00` em `2026-10-01`) | 1 | 1 | `processado` |
| [`004.csv`](clientes_sinteticos/004.csv) | Cabeçalho válido de 13 colunas, sem registros | 0 | 0 | `sem_lancamentos_recebidos` |
| [`005.csv`](clientes_sinteticos/005.csv) | 5 registros válidos e 3 descartados (`valor_zero`, `data_invalida`, `valor_invalido`) | 8 | 5 | `inconclusivo` |
| [`006.csv`](clientes_sinteticos/006.csv) | 2 registros lidos e todos descartados no pós-processamento | 2 | 0 | `inconclusivo` |
| [`007.csv`](clientes_sinteticos/007.csv) | Estrutura inválida (cabeçalho com 3 colunas e 1 linha de dados) | 1 | `null` | `indisponivel` |

### 3.2. Contrato do Provider `FonteCategorias` e Resolução de Divergências de Nomes

Como os arquivos `.csv`, `.json` e `.md` vêm do sistema e **não podem ser editados**, o código deve tratar divergências de nomenclatura entre eles:

- **Divergência conhecida no código `35`:** em [categorias_transacoes_estruturado.md](categorias_transacoes_estruturado.md) (linha 1291), a categoria `35` intitula-se **`Bar`** (embora outras notas do próprio documento citem `"Bares e Restaurantes"`), enquanto nos CSVs (`001.csv`, `002.csv`, `005.csv`, `006.csv`) a coluna `Categoria` traz **`Bares e Restaurantes`**.
- **Regra obrigatória de conciliação em código:**
  > **O código numérico (`CodCategoria` e `CodGrupo`) é o identificador canônico.** O provider `FonteCategorias` indexa cada categoria pelo seu código e mantém uma tabela explícita de **aliases normalizados** (sem acentos, minúsculas e pontuação ignorada), mapeando tanto `"bar"` quanto `"bares e restaurantes"` (e termos como `"restaurante"`) para `CodCategoria=35`.
- Assim, quando o cliente ou o modelo filtra por `"Bares e Restaurantes"`, `"Bar"` ou `35`, tanto `consultar_lancamentos` (que filtra prioritariamente por `CodCategoria=35` além do texto da coluna `Categoria`) quanto `explicar_categoria` apontam exatamente para a mesma entidade.
- **Compatibilidade do parser Markdown:** `FonteCategorias` deve suportar tanto o padrão de cabeçalho `### Categoria <COD>: <NOME>` (presente em [categorias_transacoes_estruturado.md](categorias_transacoes_estruturado.md)) quanto `#### Categoria <COD> — <NOME>` (padrão de `descricoes_categorias.md`).
- **Substituição futura por API:** o isolamento em `FonteDadosExtrato` e `FonteCategorias` tem como objetivo arquitetural restringir uma futura troca de fonte aos providers, **condicionado a que a API futura forneça os mesmos campos essenciais (ou mapeáveis)** deste contrato.

### 3.3. Regras de Período, Data de Referência e Cobertura

1. **Data de referência explícita (`data_referencia`):**
   - Expressões relativas (*"este mês"*, *"mês passado"*, *"esses dias"*) não podem depender da última data encontrada dentro de um CSV específico (em `003.csv`, por exemplo, a única transação é de `2026-10-01`).
   - O serviço utiliza uma `data_referencia` explícita (configurada no ambiente de testes das massas atuais como **`2026-10-17`**, com janela nominal de referência de **`2026-05-01` a `2026-10-17`**). Logo, nos testes sintéticos, *"este mês / outubro"* corresponde a `2026-10-01`–`2026-10-17` (mês parcial) e *"mês passado / setembro"* corresponde a `2026-09-01`–`2026-09-30`.
2. **Datas observadas vs. cobertura da fonte:**
   - `primeira_data_observada` (`extrato_inicio`) e `ultima_data_observada` (`extrato_fim`) informam apenas os extremos das transações válidas encontradas no arquivo, **não** comprovando que a instituição enviou 100% dos movimentos daquele intervalo.
3. **Tabela de decisão para períodos e estados da carga:**

| Situação | Tratamento obrigatório |
| --- | --- |
| **Cliente informa período explícito** | Respeitar exatamente o intervalo solicitado; se ultrapassar a janela nominal (`> 2026-10-17` ou `< 2026-05-01`), informar o limite da janela coberta sem inventar dados. |
| **Cliente continua um recorte anterior** (*"E em mercado?"*, *"E mês passado?"*) | Preservar os filtros aplicáveis do turno anterior e substituir apenas a dimensão alterada pelo cliente. |
| **Pedido genérico sem contexto prévio** (*"Como estão meus gastos?"*) | Aplicar o padrão documentado (mês corrente da `data_referencia` para visão do mês ou janela completa disponível quando a pergunta disser *"todo mês"* / *"semestre"*), declarando explicitamente na resposta qual período foi utilizado. |
| **Nenhum lançamento recebido (`004.csv`)** | Retornar `sem_lancamentos_recebidos`; o agente informa ausência de dados e **nunca** conclui gasto zero. |
| **Parte dos registros inválida (`005.csv`)** | Retornar `inconclusivo` com os contadores de descarte; se os registros válidos forem apresentados, identificar expressamente que o resultado é **parcial** devido a registros inconsistentes descartados. |
| **Todos os registros inválidos (`006.csv`)** | Retornar `inconclusivo` com `quantidade_linhas_validas=0`; **não** apresentar totais financeiros conclusivos nem gasto zero. |
| **Erro estrutural (`007.csv`)** | Retornar `indisponivel`; o agente informa indisponibilidade técnica da consulta. |

---

## 4. As 5 Ferramentas do MCP, Regras Financeiras e Reconciliação

O catálogo do MVP possui **exatamente 5 ferramentas cadastradas no MCP**:

| # | Ferramenta no MCP | Serviço | Pergunta ou capacidade principal | Exige `mci`? |
| :-: | --- | --- | --- | :-: |
| **1** | `obter_resumo_financeiro` | `ServiceFinanceiro` | Quanto entrou, quanto foi gasto em consumo e onde se concentram as despesas no período? | Sim (injetado) |
| **2** | `consultar_lancamentos` | `ServiceFinanceiro` | Quais lançamentos atendem aos filtros e quanto somam? | Sim (injetado) |
| **3** | `explicar_categoria` | `ServiceFinanceiro` | O que significa uma categoria ou quais categorias formam um grupo? | Não |
| **4** | `consultar_educacao_financeira` | `ServiceRAG` | Qual explicação educativa consta na base de educação financeira? | Não |
| **5** | `consultar_faq_minhas_financas` | `ServiceRAG` | Qual orientação sobre telas e recursos consta na base de ajuda do App BB? | Não |

### Regra de reconciliação entre `obter_resumo_financeiro` e `consultar_lancamentos`

Ambas as ferramentas aplicam **exatamente a mesma classificação financeira**:

- **Gastos de consumo (`escopo="consumo"`):** saídas (`Valor < 0`) **excluindo** `CodCategoria in (111, 448977, 448978)` (e fallback `CodGrupo in (12, 13)` quando `CodCategoria` não pertencer ao catálogo).
- **Entradas consideradas (`escopo="consumo"`):** entradas (`Valor > 0`) **excluindo** `CodCategoria in (111, 448977, 448978)` (e fallback `CodGrupo in (12, 13)` quando `CodCategoria` não pertencer ao catálogo).
- **Movimentações patrimoniais (`escopo="patrimonial"`):** Aplicações (`448977`), Resgates (`448978`) e Pagamento de Fatura (`111`), precedendo `CodGrupo`.
- **Exemplo concreto em [`001.csv`](clientes_sinteticos/001.csv) (outubro: `2026-10-01` a `2026-10-17`):**
  - Entradas consideradas = **R$ 1.000,00** (`SALARIO TESTE - EMPRESA TESTE`)
  - Gastos de consumo = **R$ 35,00** (`PADARIA TESTE` R$ 10,00 + `RESTAURANTE TESTE` R$ 20,00 + `TRANSPORTE TESTE` R$ 5,00)
  - Resultado do período (entradas consideradas − gastos de consumo) = **R$ 965,00** *(nunca chamado de saldo em conta)*
  - Movimentações patrimoniais separadas: Aplicação = **R$ 300,00**, Resgate = **R$ 100,00**, Pagamento de Fatura = **R$ 90,00** (soma bruta de todas as saídas de outubro = R$ 425,00, mas o consumo é R$ 35,00).

---

### Ficha 1 — `obter_resumo_financeiro`

- **Finalidade:** entregar o panorama de entradas, gastos de consumo, resultado do período, totais patrimoniais separados e a composição completa por grupo e por categoria (dispensando uma tool separada de agrupamento no MVP).
- **Uso inadequado:** não usar para listar lançamentos individuais ou buscar um estabelecimento específico na descrição.
- **Argumentos visíveis ao modelo:**
  - `data_inicio: str | None = None` (`YYYY-MM-DD`; se informada, `data_fim` é obrigatória).
  - `data_fim: str | None = None` (`YYYY-MM-DD`; se omitida junto com `data_inicio`, usa a janela disponível).
  - `top_n_categorias: int = 10` (intervalo `1..20`).
- **Contexto injetado pelo Agente:** `mci: str`.
- **Retorno estruturado:**
  - `estado_carga`: `"processado" | "sem_lancamentos_recebidos" | "inconclusivo" | "indisponivel"`
  - `janela_referencia_inicio`, `janela_referencia_fim`, `primeira_data_observada`, `ultima_data_observada`, `periodo_analisado_inicio`, `periodo_analisado_fim`
  - `quantidade_linhas_csv`, `quantidade_linhas_validas`, `descartes_por_motivo`, `alertas_qualidade`
  - `total_entradas`: string decimal (`"1000.00"`)
  - `total_gastos_consumo`: string decimal (`"35.00"`)
  - `resultado_periodo`: string decimal (`"965.00"`, correspondente a `total_entradas - total_gastos_consumo`)
  - `movimentacoes_patrimoniais`: `{"total_aplicacoes": "300.00", "total_resgates": "100.00", "total_fatura": "90.00"}`
  - `gastos_por_grupo`: lista ordenada por valor decrescente `[{"cod_grupo": int, "grupo": str, "total": str, "percentual": float | None, "quantidade_lancamentos": int}]`
  - `gastos_por_categoria`: até `top_n_categorias` itens `[{"cod_categoria": int, "categoria": str, "grupo": str, "total": str, "percentual": float | None, "quantidade_lancamentos": int}]` + `percentual_coberto_top_categorias`
  - `evolucao_mensal`: populado quando o período abrange mais de 1 mês `[{"ano": int, "mes": int, "mes_nome": str, "total_entradas": str, "total_gastos_consumo": str, "resultado_periodo": str, "parcial": bool}]`

---

### Ficha 2 — `consultar_lancamentos`

- **Finalidade:** localizar e somar movimentações específicas por período, categoria(s), grupo(s), termos na descrição, instituição, natureza, escopo e faixa de valor.
- **Uso inadequado:** não usar para explicar regras conceituais do catálogo sem relação com o extrato do cliente.
- **Argumentos visíveis ao modelo:**
  - `data_inicio: str | None = None`, `data_fim: str | None = None`
  - `escopo: Literal["consumo", "patrimonial", "todos"] = "consumo"` *(padrão `"consumo"` garante que pedir "as maiores compras" na Jornada B retorne apenas gastos de consumo, reconciliando com os R$ 35,00 do resumo; se o cliente pedir para ver aplicações ou pagamentos de fatura, o modelo usa `"patrimonial"` ou `"todos"`)*
  - `natureza: Literal["saida", "entrada", "todos"] = "saida"`
  - `categorias: list[str | int] | None = None` *(aceita 1 ou mais nomes/aliases/códigos em união `OR`, permitindo atender "restaurante e mercado" em uma única chamada sem soma mental no LLM)*
  - `grupos: list[str | int] | None = None` *(união `OR` de grupos)*
  - `termos_descricao: list[str] | None = None` *(união `OR` case-insensitive e sem acentos sobre `Descricao`)*
  - `instituicao: str | None = None` *(filtro case-insensitive sobre `Instituicao`)*
  - `valor_minimo: str | float | None = None`, `valor_maximo: str | float | None = None` *(comparados sobre a **magnitude absoluta `abs(Valor)`**)*
  - `ordenar_por: Literal["maior_valor", "menor_valor", "mais_recente", "mais_antigo"] = "maior_valor"` *(para despesas, `"maior_valor"` ordena por maior magnitude `abs(Valor)` decrescente, com desempate estável por `Data` decrescente e `Descricao`)*
  - `limite: int = 10` (intervalo `1..50`).
- **Contexto injetado pelo Agente:** `mci: str`.
- **Regras de cálculo e retorno:**
  - Totais e contagens (`total_encontrado`, `soma_saidas_filtradas`, `soma_entradas_filtradas`) são calculados **sobre todos os lançamentos que atendem ao filtro antes de aplicar `limite`**.
  - `pct_sobre_gasto_total_periodo`: calculado apenas quando `escopo="consumo"` e `natureza="saida"` e `total_gastos_consumo_periodo > 0`, comparando `soma_saidas_filtradas / total_gastos_consumo_periodo * 100` (2 casas decimais). Caso o denominador seja `0` ou `escopo != "consumo"`, retorna `null` acompanhado de `motivo_pct_nulo` (`"sem_gastos_consumo_no_periodo"` ou `"escopo_inclui_movimentacao_patrimonial"`).
  - Retorna também `lista_truncada: bool` (`total_encontrado > len(lancamentos_exibidos)`), `lancamentos` (com valores sempre em magnitude positiva + campo `natureza`), `primeira_data_observada`, `ultima_data_observada`, `intervalo_filtrado_inicio`, `intervalo_filtrado_fim`, `categorias_presentes_no_periodo` e `grupos_presentes_no_periodo`.

---

### Ficha 3 — `explicar_categoria`

- **Finalidade:** consultar o catálogo oficial para explicar o que entra e o que não entra em uma categoria, listar quais categorias compõem um grupo ou resolver dúvidas sobre nomes de categorias.
- **Uso inadequado:** **não** usar para estabelecimentos ou marcas (*"Uber entra em qual categoria?"* deve ser respondido consultando os lançamentos do cliente em `consultar_lancamentos(termos_descricao=["Uber"])`).
- **Argumentos visíveis ao modelo:**
  - `termo: str | int` (código numérico, nome/alias da categoria ou nome do grupo).
  - `tipo: Literal["categoria", "grupo", "auto"] = "auto"` *(como os códigos `1` a `14` existem tanto para grupos quanto para categorias — ex.: grupo `1 = Receitas` e categoria `1 = Salário` —, se `tipo="auto"` receber um número ambíguo, retorna ambos ou prioriza a categoria informando o grupo homônimo; se `tipo="grupo"` ou `"categoria"`, resolve sem ambiguidade)*.
- **Contexto injetado:** nenhum.
- **Retorno e regras de interpretação:**
  - Quando encontra categoria: `{status: "encontrado_categoria", cod_categoria, nome_canonico, aliases_aceitos, cod_grupo, nome_grupo, natureza_catalogo: "C" | "D", devem_ser_incluidos: [...], nao_devem_ser_incluidos: [...], observacao}`.
  - Quando encontra grupo: `{status: "encontrado_grupo", cod_grupo, nome_grupo, categorias_do_grupo: [{"cod_categoria", "nome_canonico", "aliases_aceitos"}]}`.
  - Quando categoria não possui definição detalhada (ex.: `0` ou `83` — `Sem categoria`): `{status: "sem_definicao", mensagem}`.
  - Quando não encontrado: `{status: "nao_encontrado", sugestoes: [...]}`.
  - **Ressalva obrigatória:** a `natureza_catalogo` (`C` ou `D`) descreve o comportamento típico previsto no catálogo, mas não substitui a verificação da direção real (`Valor`) do lançamento no extrato.

---

### Fichas 4 e 5 — `consultar_educacao_financeira` e `consultar_faq_minhas_financas`

- **Finalidade:** recuperar passagens verificadas nos índices GeneraBB de Educação Financeira (`idx-minhas-financas`) e de FAQ/Ajuda do App BB (`ix-mf-faq`) via `ServiceRAG`.
- **Argumentos visíveis ao modelo:** `pergunta: str`, `top_k: int | None = 5`.
- **Contexto injetado:** nenhum (`mci` não é enviado ao RAG).
- **Retorno:** `{"status": status, "mensagem": str, "total_contextos": int, "contextos": list[dict | str]}` (preservando a ordem de relevância e, quando disponível na resposta do índice, o identificador/título do documento de origem para rastreabilidade na avaliação).

---

## 5. Contrato `/chat` e Integração Agente ↔ MCP

### Contrato de entrada (`POST /chat`)

| Campo | Tipo e padrão | Regra |
| --- | --- | --- |
| `message` | `str` (obrigatório, `1..4096` chars) | Fala do usuário no turno atual. |
| `session_id` | `str \| None = None` | Identificador da sessão conversacional; se omitido, o servidor gera um UUID novo. |
| `mci` | `str` (obrigatório nos testes financeiras, ex.: `"001"`) | Identificador textual do cliente (preservando zeros à esquerda). Seleciona a massa sintética no MVP; em produção virá de contexto autenticado, nunca de escolha do LLM. |
| `diagnostico` | `bool = False` | Quando `true` (e permitido pela configuração do ambiente), inclui a trilha de execução completa na resposta HTTP. |
| `case_id` | `str \| None = None` | Metadado opcional de rastreamento da bateria de testes, gravado no registro de execução sem ser enviado ao prompt do LLM. |
| `incluir_diagnostico_mcp` | `bool = False` | Mantido temporariamente por compatibilidade retroativa com testes anteriores do template (retorna apenas o resumo legado `diagnostico_mcp` sem habilitar por si só o novo bloco completo `diagnostico`). |

### Fluxo de execução em 9 passos no Agente

1. **Gerar `execution_id` (UUID4)** e inicializar o coletor do `EvaluationRecord` antes de qualquer validação ou guardrail.
2. **Validar a requisição e permissões** (incluindo se o ambiente autoriza `diagnostico=True`; se solicitado sem permissão do ambiente, recusar ou omitir `diagnostico=None` com aviso explícito, sem exposição parcial).
3. **Adquirir lock da sessão (`session_id`) e validar vínculo `session_id` ↔ `mci`** no checkpointer **antes** de incorporar a mensagem ao estado do grafo.
4. **Executar o guardrail de entrada** conforme o modo configurado (`disabled | observe | enforce`), registrando o resultado no `EvaluationRecord`.
5. **Construir o contexto confiável da execução** (`RuntimeContext(mci=req.mci, execution_id=execution_id, data_referencia=...)`).
6. **Executar o grafo LangGraph uma única vez** para o turno corrente.
7. **No wrapper das ferramentas financeiras pessoais (`obter_resumo_financeiro` e `consultar_lancamentos`):**
   - Apresentar ao LLM um schema de argumentos **sem o campo `mci`**;
   - Ao interceptar a chamada do modelo, **injetar `mci` a partir do contexto confiável da requisição** (descartando e sobrescrevendo qualquer tentativa do modelo de enviar `mci`);
   - Nas ferramentas `explicar_categoria`, `consultar_educacao_financeira` e `consultar_faq_minhas_financas`, não injetar `mci`;
   - Registrar no coletor: `tool_call_id`, argumentos propostos pelo LLM, argumentos efetivos enviados ao MCP, instante inicial, duração em ms, status e retorno bruto.
8. **Executar o guardrail de saída** conforme o modo configurado (`disabled | observe | enforce`).
9. **Persistir o `EvaluationRecord` em JSONL local** e montar o `ChatResponse` (sem reexecutar o grafo quando `diagnostico=True`).

---

## 6. Memória Conversacional e Vínculo Sessão–Cliente

Para garantir continuidade conversacional (*"E mês passado?"*, *"Não, esquece mercado"*) com segurança entre clientes no MVP:

1. **Instância única de `InMemorySaver` no ciclo de vida da aplicação:**
   - O checkpointer em RAM é instanciado no startup da aplicação FastAPI e compartilhado entre as requisições em **processo único (1 worker / 1 réplica enquanto a memória for local em RAM)**.
2. **`session_id` como `thread_id` e vínculo imutável com `mci`:**
   - O `thread_id` do LangGraph é o próprio `session_id`.
   - O estado do grafo armazena `mci_vinculado: str`. Antes de processar o turno, o backend consulta o checkpoint atual da `thread_id`:
     - Se o checkpoint já existir e `checkpoint.mci_vinculado != req.mci`, a requisição é **rejeitada imediatamente (HTTP 403/409)** antes de enviar histórico ao LLM ou chamar qualquer tool.
     - Isso impede vazamento de contexto entre clientes sem exigir um banco externo no MVP.
   - *(Nota arquitetural: concatenar `f"{mci}:{session_id}"` como `thread_id` criaria silenciosamente uma nova conversa quando o `mci` mudasse em vez de rejeitar o uso indevido do `session_id`; por isso o vínculo é validado explicitamente sobre o `session_id`).*
3. **Concorrência na mesma sessão:**
   - Requisições simultâneas para o mesmo `session_id` (inclusive na criação da primeira mensagem) devem ser serializadas por `asyncio.Lock` por `session_id` (ou rejeitadas com HTTP 409), evitando condição de corrida na gravação do vínculo e na lista de mensagens.
4. **Ciclo de vida e limpeza da memória:**
   - Fechar a aba do cliente **não** exclui automaticamente o checkpoint no servidor. A exclusão ocorre por endpoint explícito de encerramento de sessão, por expiração/TTL configurável em memória ou quando o processo reinicia.
   - A memória conversacional (`InMemorySaver`, efêmera no MVP) e o registro de avaliação (`EvaluationRecord` em JSONL, persistido em disco) possuem ciclos de vida independentes.
5. **Roteiro de evolução futura para Redis:**
   - Quando a persistência distribuída for priorizada, envolverá: adição da dependência `langgraph-checkpoint-redis`, configuração de pool/conexão e TTL, inicialização dos índices no lifespan da aplicação e testes de concorrência multi-réplica.

---

## 7. Trilha de Execução (`diagnostico`), Avaliação (DeepEval / Ragas) e Guardrails

### 7.1. Estrutura do `EvaluationRecord` (Fonte única para Diagnóstico HTTP e Avaliadores)

O coletor instrumentado durante a execução alimenta um `EvaluationRecord` versionado (`schema_version="1.0"`), gravado em arquivo JSONL local a cada turno (inclusive em casos de falha de ferramenta, bloqueio ou timeout):

| Bloco | Campos mínimos registrados |
| --- | --- |
| **Identificação e versões** | `schema_version`, `execution_id`, `session_id`, `mci`, `case_id`, `data_referencia`, versões de agente/modelo/prompt/catálogo. |
| **Entrada, histórico e saída** | `user_input` (fala original do turno), `conversational_history` (mensagens anteriores da sessão necessárias para interpretar elipses) e `actual_output` (resposta final entregue). |
| **Tempos e contadores** | `status_execucao`, `inicio_iso`, `fim_iso`, `duracao_total_ms`, `chamadas_modelo` (nº de invocações ao LLM) e `chamadas_tools` (nº de tools acionadas, separado de `chamadas_modelo` pois uma rodada do modelo pode solicitar múltiplas tools em paralelo). |
| **Trilha de ferramentas (`chamadas_ferramentas`)** | Lista ordenada com `tool_call_id`, `nome_ferramenta`, `rodada_modelo`, `tentativa`, `argumentos_propostos_llm`, `contexto_injetado` (`{"mci": "..."}` apenas nas tools 1 e 2), `argumentos_efetivos_enviados`, `inicio_iso`, `duracao_ms`, `status`, `erro`, `retorno_bruto` e `conteudo_entregue_ao_modelo`. |
| **Evidências separadas por natureza** | `evidencias_financeiras` (retornos estruturados de `obter_resumo_financeiro`, `consultar_lancamentos` e `explicar_categoria`) e `recuperacoes_documentais` (passagens retornadas por `consultar_educacao_financeira` e `consultar_faq_minhas_financas`, preservando consulta, ordem, origem e identificadores). |
| **Guardrails e integridade** | `guardrails`: `{entrada: {modo, resultado, motivo, duracao_ms}, saida: {modo, resultado, motivo, duracao_ms}}` e `integridade_captura` (`"completa"`, `"parcial"` ou `"truncada"`). |

Quando `POST /chat` recebe `"diagnostico": true`, o campo `diagnostico` do `ChatResponse` projeta diretamente esse `EvaluationRecord` (sem reexecutar o grafo e sem expor credenciais/segredos).

### 7.2. Adaptação técnica para DeepEval e Ragas (Fora do `/chat`)

O `EvaluationRecord` é a fonte de dados bruta, mas **DeepEval** e **Ragas** possuem schemas distintos e exigem gabaritos externos (`expected_output`, `expected_tools`, `reference`) associados pelo `case_id` na suíte de avaliação:

| Dado no `EvaluationRecord` + Gabarito (`case_id`) | Adaptador **DeepEval** (`LLMTestCase`) | Adaptador **Ragas** (`SingleTurnSample` / `MultiTurnSample`) |
| --- | --- | --- |
| Pergunta do turno (`user_input`) | `input` | `user_input` |
| Resposta final (`actual_output`) | `actual_output` | `response` |
| Passagens documentais (`recuperacoes_documentais`) | `retrieval_context: list[str]` | `retrieved_contexts: list[str]` |
| Ferramentas acionadas (`chamadas_ferramentas`) | `tools_called: list[ToolCall]` (`name`, `input_parameters`, `output`) | Não possui campo nativo em `SingleTurnSample`; avaliado em trajetória/agente ou via DeepEval. |
| Gabarito do caso de teste *(definido no dataset de teste, fora do `/chat`)* | `expected_output: str`, `expected_tools: list[ToolCall]` | `reference: str`, `reference_contexts: list[str]` |

#### Regras críticas de avaliação (para evitar falsos positivos nas métricas)

1. **Valores financeiros exigem asserção determinística antes de LLM-as-a-Judge:** uma resposta pode ser julgada "fiel" (*Faithfulness = 1.0*) a um cálculo errado. Totais, datas, contagens e separação de fatura/aplicação nos cenários `001.csv` a `007.csv` devem ser validados por testes determinísticos contra o oráculo numérico.
2. **Não misturar extrato com passagens RAG ao medir qualidade de recuperação documental:** manter `evidencias_financeiras` e `recuperacoes_documentais` em campos separados no `EvaluationRecord`. Para métricas de RAG (*Context Precision*, *Context Recall*), passar apenas `recuperacoes_documentais`; quando avaliar sustentação global da resposta (*Faithfulness*), o adaptador pode serializar as evidências utilizadas naquele caso de teste.
3. **Requisitos reais de cada métrica:**
   - *Tool Correctness* (DeepEval): requer `tools_called` (do registro) **e** `expected_tools` (do gabarito do `case_id`, aceitando caminhos equivalentes válidos nas jornadas).
   - *Context Recall* (Ragas / DeepEval): requer `reference` / `expected_output` no gabarito para comparar se o conteúdo necessário foi recuperado.
   - *Context Precision*: depende da variante escolhida (com `reference`/`expected_output` ou variante sem referência no Ragas).
   - *Answer Relevancy*: requer `input` e `actual_output` (independe de contexto).
   - *Task Completion* (DeepEval): requer instrumentação de tracing do DeepEval na execução ou adaptador específico da versão fixada, não apenas uma lista JSON estática.

### 7.3. Modos de Guardrails no MVP

Os guardrails de conteúdo operam com três modos configuráveis:

```text
modo: disabled | observe | enforce
resultado: nao_executado | aprovado | reprovado | erro
```

Durante os testes funcionais do MVP, os guardrails de conteúdo podem operar em `observe` (registrando decisões no `EvaluationRecord` sem bloquear a conversa), **mas as validações estruturais de segurança permanecem sempre ativas em qualquer modo**: validação do vínculo `session_id` ↔ `mci`, ocultação e injeção forçada do `mci`, whitelist estrita de nomes de arquivos CSV (`001` a `007`, sem *path traversal*), whitelist das 5 tools do MCP, limites de tamanho e timeouts.

---

### Critérios de Pronto do MVP (Matriz de Aceite)

| Grupo | O que deve ser comprovado nos testes |
| --- | --- |
| **Reconciliação financeira** | Em `001.csv` (outubro), `obter_resumo_financeiro` e `consultar_lancamentos(escopo="consumo")` reconciliam exatamente **R$ 35,00** de consumo, mantendo Aplicação (R$ 300,00), Resgate (R$ 100,00) e Fatura (R$ 90,00) separados. |
| **7 cenários CSV** | `001` (22 válidas, `processado`), `002` (1 saída, entradas R$ 0,00 legítimo), `003` (1 entrada, consumo R$ 0,00 legítimo), `004` (`sem_lancamentos_recebidos`, nunca gasto zero), `005` (`inconclusivo` parcial com 3 descartes e 5 válidas), `006` (`inconclusivo` com 2 descartes e 0 válidas), `007` (`indisponivel` por schema). |
| **Conciliação de catálogo** | Código `35` resolve tanto `"Bar"` quanto `"Bares e Restaurantes"` em `explicar_categoria` e `consultar_lancamentos`; códigos ambíguos entre grupo e categoria respeitam `tipo`. |
| **Continuidade e desvios humanos** | *"E mês passado?"* altera apenas o período preservando o filtro; *"Esquece mercado, quero ver restaurante"* substitui o filtro anterior sem acumulá-lo; *"Só de cartão?"* esclarece a limitação da coluna `Tipo`. |
| **Isolamento de fontes** | Perguntas exclusivamente educativas (`consultar_educacao_financeira`) ou sobre o aplicativo (`consultar_faq_minhas_financas`) respondem sem acionar `FonteDadosExtrato`. Perguntas mistas entregam a parte disponível mesmo se outra tool falhar. |
| **Identidade e sessão** | Schema das tools no LLM não expõe `mci`; tentativa do modelo de enviar outro `mci` é sobrescrita pelo wrapper; reutilização de `session_id` com outro `mci` é rejeitada antes de acionar o modelo. |
| **Diagnóstico e avaliação** | `diagnostico=True` retorna a trilha de execução coletada em tempo real (sem reexecutar o grafo), gravada em JSONL local e consumível pelos adaptadores do DeepEval e do Ragas. |
