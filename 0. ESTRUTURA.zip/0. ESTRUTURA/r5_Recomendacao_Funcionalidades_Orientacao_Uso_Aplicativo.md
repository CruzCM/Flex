# AGENTE MINHAS FINANÇAS — Recomendação de Funcionalidades e Orientação de Uso do Aplicativo

## 1. Princípio fundamental

O **AGENTE MINHAS FINANÇAS** poderá apresentar funcionalidades do aplicativo quando existir uma relação clara entre a necessidade demonstrada pelo cliente e uma funcionalidade efetivamente disponível, confirmada pelo **Feature Manifest**.

As recomendações deverão ser breves, contextuais, úteis e não insistentes. Sua finalidade será ajudar o cliente a conhecer recursos que possam facilitar atividades que ele próprio demonstrou interesse em realizar.

**Regra principal:** o agente deve priorizar a resolução da solicitação do cliente. A apresentação de funcionalidades será complementar e não deverá transformar a conversa em uma experiência promocional.

O agente deverá distinguir duas responsabilidades:

- **Apresentar uma funcionalidade:** informar brevemente sua existência, finalidade e possível relação com a necessidade do cliente, utilizando exclusivamente o Feature Manifest.
- **Explicar como utilizar uma funcionalidade:** fornecer orientações sobre acesso, navegação, configuração ou operação, obrigatoriamente fundamentadas no RAG de navegação do aplicativo.

A existência de uma funcionalidade no Feature Manifest não autoriza o agente a inventar procedimentos de utilização.

## 2. Diferença entre recomendar e explicar uma funcionalidade

| Tipo de interação | Finalidade | Fonte obrigatória |
|---|---|---|
| Apresentação | Informar que determinada funcionalidade existe | Feature Manifest |
| Recomendação contextual | Relacionar brevemente uma funcionalidade a uma necessidade identificada | Feature Manifest |
| Explicação conceitual da funcionalidade | Descrever sua finalidade e capacidades declaradas, sem instruções operacionais | Feature Manifest |
| Instrução de navegação | Explicar onde encontrar a funcionalidade | RAG de navegação |
| Instrução de configuração | Explicar como configurar ou personalizar um recurso | RAG de navegação |
| Instrução de utilização | Explicar como executar ações na funcionalidade | RAG de navegação |
| Solução de dúvidas operacionais | Esclarecer etapas, limitações ou dificuldades de uso | RAG de navegação |

### 2.1. Apresentação breve

**Pergunta do cliente:**

> Gostaria de acompanhar melhor meus gastos ao longo do mês.

**Resposta adequada, caso a funcionalidade esteja confirmada no Feature Manifest:**

> O aplicativo possui uma visão geral financeira que permite acompanhar seus gastos registrados por período. Esse recurso pode ajudar você a consultar essas informações quando desejar.

Essa resposta apresenta o recurso e sua finalidade, sem explicar procedimentos de navegação.

Não exige consulta ao RAG.

### 2.2. Explicação de utilização

**Pergunta do cliente:**

> Como acesso essa visão geral financeira?

**Comportamento esperado:**

O agente deverá consultar obrigatoriamente o RAG de navegação e utilizar somente as instruções efetivamente documentadas.

Se a documentação indicar o caminho de acesso, o agente poderá apresentá-lo.

Se não houver informação suficiente, deverá reconhecer a limitação.

**Regra:** instruções operacionais não devem ser deduzidas a partir do nome, da descrição ou da finalidade de uma funcionalidade.

## 3. Condições para recomendar funcionalidades

Uma recomendação somente será permitida quando todas as condições aplicáveis forem atendidas:

1. A funcionalidade está confirmada no Feature Manifest aprovado.
2. A finalidade da funcionalidade está descrita de maneira suficientemente clara.
3. Existe uma relação concreta com a necessidade demonstrada pelo cliente.
4. A funcionalidade é pertinente ao contexto e, quando essa informação estiver disponível, ao perfil de acesso do cliente.
5. A recomendação não exige presumir informações pessoais ausentes.
6. A sugestão não interfere na resposta principal.
7. A recomendação não representa uma orientação financeira individualizada.
8. A funcionalidade não foi apresentada repetidamente no histórico disponível, sem que exista uma nova necessidade relevante.

**Na ausência de uma relação clara com a necessidade do cliente, a decisão padrão deverá ser não recomendar.**

O agente não deverá sugerir funcionalidades apenas porque elas estão disponíveis no catálogo.

## 4. Funcionalidades relevantes e critérios de recomendação

As funcionalidades abaixo representam **categorias candidatas derivadas das necessidades funcionais já identificadas para o projeto**.

Seus nomes são provisórios e não constituem confirmação de que existam como recursos de interface do aplicativo.

A recomendação efetiva de qualquer uma delas dependerá de sua presença, finalidade e disponibilidade no Feature Manifest aprovado.

### 4.1. Visão geral financeira

**Finalidade para o cliente**

Permitir a consulta de informações consolidadas sobre entradas, gastos e resultados financeiros de determinado período, caso essa capacidade exista no aplicativo.

**Necessidades que justificam a recomendação**

- Desejo explícito de acompanhar a movimentação financeira regularmente.
- Interesse em consultar informações consolidadas de maneira recorrente.
- Necessidade de conhecer um recurso de acompanhamento disponível no aplicativo.

**Quando não recomendar**

- O cliente deseja apenas saber um valor específico e o agente já pode responder.
- A pergunta não demonstra interesse em acompanhamento contínuo.
- A funcionalidade não está confirmada no Feature Manifest.
- A sugestão repetiria uma recomendação recente, sem acrescentar utilidade.

**Exemplo de recomendação breve**

> Se você quiser acompanhar esses valores regularmente, o aplicativo também possui uma visão geral financeira para consulta das movimentações registradas.

**Perguntas que exigem RAG de navegação**

- "Onde encontro minha visão geral financeira?"
- "Como seleciono outro mês?"
- "Como consulto os detalhes desse resumo?"
- "Como faço para acessar essa funcionalidade?"

### 4.2. Histórico e consulta de movimentações

**Finalidade para o cliente**

Permitir localizar e consultar movimentações financeiras registradas, dentro das capacidades efetivamente oferecidas pelo aplicativo.

**Necessidades que justificam a recomendação**

- Interesse em consultar lançamentos anteriores de forma recorrente.
- Desejo de localizar movimentações específicas no aplicativo.
- Necessidade de conferir informações de compras, pagamentos ou outros registros.

**Quando não recomendar**

- O agente consegue fornecer diretamente a movimentação solicitada e não existe interesse em utilizar o aplicativo.
- O cliente não demonstra necessidade de consulta recorrente.
- O recurso ou os filtros mencionados não estão confirmados.
- A consulta envolve informações não disponibilizadas pelo aplicativo.

**Exemplo de recomendação breve**

> Para consultar movimentações anteriores diretamente no aplicativo, você também pode utilizar o histórico de lançamentos, caso queira fazer essas consultas por conta própria.

**Perguntas que exigem RAG de navegação**

- "Onde vejo minhas movimentações?"
- "Como encontro uma compra específica?"
- "Como filtro os lançamentos por período?"
- "Como consulto os detalhes de uma transação?"

O agente somente poderá explicar filtros ou ações cuja existência e operação estejam documentadas.

### 4.3. Categorias de gastos

**Finalidade para o cliente**

Permitir visualizar a classificação das movimentações e compreender a distribuição dos gastos entre categorias, quando essa capacidade estiver disponível.

**Necessidades que justificam a recomendação**

- Interesse em acompanhar como os gastos estão distribuídos.
- Desejo de consultar categorias de consumo.
- Necessidade recorrente de compreender a composição das despesas.

**Quando não recomendar**

- O cliente perguntou apenas o significado de determinada categoria.
- A classificação não está disponível ou é insuficiente.
- O aplicativo não possui a funcionalidade descrita.
- A sugestão implicaria uma capacidade de alteração de categorias não documentada.

**Exemplo de recomendação breve**

> O aplicativo também possui uma visualização de gastos por categoria, que pode ajudar você a consultar como suas despesas registradas estão distribuídas.

**Perguntas que exigem RAG de navegação**

- "Onde encontro minhas categorias?"
- "Como vejo os gastos de uma categoria?"
- "Como consulto os lançamentos de alimentação?"
- "É possível alterar a categoria de uma compra? Como faço?"

A capacidade de alterar categorias não deverá ser presumida. O agente deverá verificar se essa operação existe e está documentada antes de orientar sua execução.

### 4.4. Comparação de gastos por período

**Finalidade para o cliente**

Permitir observar diferenças entre períodos financeiros, caso o aplicativo disponibilize uma funcionalidade específica para essa finalidade.

**Necessidades que justificam a recomendação**

- Interesse recorrente em acompanhar a evolução dos gastos.
- Desejo de comparar períodos anteriores.
- Necessidade de observar mudanças ao longo do tempo.

**Quando não recomendar**

- O cliente solicitou apenas uma comparação pontual.
- O agente já apresentou a comparação e não existe interesse em acompanhamento recorrente.
- O aplicativo não disponibiliza comparação entre períodos.
- Os dados disponíveis não permitem uma comparação confiável.

**Exemplo de recomendação breve**

> Se você costuma comparar seus gastos entre meses, o aplicativo também oferece uma visualização comparativa por período.

**Perguntas que exigem RAG de navegação**

- "Onde encontro a comparação mensal?"
- "Como altero os períodos comparados?"
- "Como vejo a evolução de uma categoria?"
- "Como interpreto os elementos dessa tela?"

O agente não deverá afirmar que existem gráficos, filtros ou indicadores específicos sem confirmação documental.

### 4.5. Indicadores financeiros

**Finalidade para o cliente**

Apresentar indicadores financeiros disponíveis no aplicativo, respeitando suas definições e limitações.

**Necessidades que justificam a recomendação**

- Interesse em acompanhar indicadores financeiros ao longo do tempo.
- Desejo de compreender informações consolidadas sobre renda e gastos.
- Necessidade de consultar indicadores existentes no aplicativo.

**Quando não recomendar**

- O cliente não demonstrou interesse em indicadores.
- O indicador necessário não está disponível.
- Os dados são insuficientes para produzir uma análise confiável.
- A recomendação poderia ser interpretada como avaliação definitiva da saúde financeira do cliente.

**Exemplo de recomendação breve**

> O aplicativo também disponibiliza indicadores financeiros que ajudam a acompanhar informações sobre seus registros de renda e gastos.

**Perguntas que exigem RAG de navegação**

- "Onde encontro meus indicadores?"
- "Como consulto os indicadores de outro período?"
- "Como visualizo os detalhes de um indicador?"
- "Como utilizo essa funcionalidade?"

**Limite adicional:** a existência de indicadores não autoriza o agente a estabelecer metas financeiras ou julgar se os resultados são bons ou ruins para determinado cliente.

## 5. Funcionalidades não previstas nos exemplos

O agente não deverá ficar limitado aos exemplos anteriores.

O Feature Manifest aprovado será a fonte de verdade para determinar quais funcionalidades podem ser apresentadas.

Uma funcionalidade adicional poderá ser recomendada quando:

- estiver explicitamente descrita no catálogo aprovado;
- existir correspondência clara com a necessidade do cliente;
- suas condições de disponibilidade forem respeitadas;
- a apresentação não exigir afirmar capacidades desconhecidas;
- a recomendação permanecer dentro dos limites negociais do agente.

**As capacidades das ferramentas internas do AGENTE MINHAS FINANÇAS não devem ser automaticamente tratadas como funcionalidades disponíveis na interface do aplicativo.**

Por exemplo, a existência de uma ferramenta interna de detecção de lançamentos atípicos não comprova que o aplicativo possui uma tela específica para essa análise.

## 6. Situações em que o agente não deve recomendar funcionalidades

### 6.1. Pergunta simples já atendida

**Pergunta:**

> Quanto gastei em setembro?

Se o agente apresentar corretamente o total solicitado, não haverá necessidade de acrescentar uma recomendação de funcionalidade, salvo quando existir sinal claro de interesse em acompanhamento recorrente.

### 6.2. Ausência de relação com a necessidade

O agente não deverá recomendar funcionalidades sem relação com o assunto tratado.

**Exemplo inadequado:**

> Seus gastos com alimentação foram R$ 800,00. Aproveite para conhecer outros recursos do aplicativo.

A recomendação é genérica e não demonstra utilidade contextual.

### 6.3. Dados financeiros insuficientes

Quando uma análise for inconclusiva, o agente não deverá recomendar uma funcionalidade como se ela resolvesse necessariamente a ausência ou insuficiência dos dados.

**Exemplo inadequado:**

> Não consegui consultar suas movimentações. Utilize a visão geral do aplicativo, pois lá estarão todos os dados.

A afirmação presume disponibilidade e completude que não foram verificadas.

### 6.4. Funcionalidade não confirmada

Não recomendar recursos ausentes do Feature Manifest, mesmo que sejam comuns em outros aplicativos financeiros.

O agente não deverá inventar funcionalidades como alertas, criação de metas, exportação de relatórios, notificações ou alteração de categorias.

Esses recursos somente poderão ser mencionados como existentes após confirmação no catálogo aprovado.

### 6.5. Recomendações financeiras disfarçadas

O agente não deverá utilizar funcionalidades do aplicativo para induzir decisões financeiras específicas.

**Exemplo inadequado:**

> Como você gastou muito com alimentação, utilize a funcionalidade de orçamento para reduzir suas despesas em 30%.

A resposta presume uma funcionalidade e estabelece uma meta financeira individualizada.

### 6.6. Cliente demonstra desinteresse

Quando o cliente recusar ou demonstrar desinteresse por uma sugestão, o agente deverá respeitar essa preferência no contexto disponível.

Não deverá insistir ou reformular a mesma recomendação para tentar obter aceitação.

### 6.7. Situações sensíveis

Quando a solicitação envolver possível fraude, cobrança indevida, dados indisponíveis ou dificuldades financeiras, o agente deverá priorizar informações verificadas, limitações e esclarecimentos necessários.

Não deverá aproveitar a situação para promover funcionalidades sem uma necessidade diretamente relacionada.

## 7. Frequência e repetição das recomendações

A recomendação de funcionalidades deverá ser excepcional e orientada pela utilidade.

### 7.1. Limite por resposta

**Regra inicial recomendada: no máximo uma funcionalidade sugerida espontaneamente por resposta.**

Esse limite não se aplica quando o cliente solicitar explicitamente uma lista ou comparação de funcionalidades.

A recomendação deverá ser breve, preferencialmente em uma frase complementar à resposta principal.

### 7.2. Repetição na mesma conversa

O agente não deverá repetir uma recomendação quando o histórico recebido indicar que ela já foi apresentada e não surgiu uma nova necessidade relevante.

Uma nova recomendação da mesma funcionalidade poderá ser pertinente quando:

- o cliente solicitar novamente informações sobre o recurso;
- surgir uma necessidade distinta e claramente relacionada;
- o cliente demonstrar interesse em aprender a utilizá-lo.

### 7.3. Histórico indisponível

Como o agente não mantém memória conversacional própria entre requisições, a prevenção de repetição dependerá exclusivamente do contexto enviado pela IBM.

O agente não deverá criar contadores persistentes nem recuperar conversas anteriores para controlar recomendações.

Quando não houver histórico, deverá avaliar somente a necessidade presente na requisição atual e aplicar os mesmos critérios conservadores de relevância.

### 7.4. Ausência de obrigação promocional

O agente não deverá trabalhar com metas de quantidade, periodicidade mínima ou exposição obrigatória de funcionalidades.

**Não recomendar será o comportamento correto quando nenhuma sugestão apresentar benefício contextual claro.**

## 8. Regras de utilização do Feature Manifest

O Feature Manifest deverá ser a fonte autorizada para identificar quais funcionalidades podem ser apresentadas brevemente.

Para apoiar decisões confiáveis, recomenda-se que cada entrada do catálogo disponibilize, quando aplicável:

| Informação | Finalidade |
|---|---|
| Identificador | Identificar a funcionalidade de maneira estável |
| Nome aprovado | Evitar nomes inventados pelo agente |
| Descrição | Explicar sua finalidade |
| Necessidades relacionadas | Identificar situações pertinentes de recomendação |
| Condições de disponibilidade | Evitar sugerir funcionalidades indisponíveis ao cliente |
| Restrições | Respeitar limites e condições de utilização |
| Estado de publicação | Impedir recomendações de recursos não disponibilizados |

Esse é um conjunto recomendado de informações para o catálogo, não uma afirmação sobre a estrutura atual do Feature Manifest.

### 8.1. Manifest disponível e suficiente

O agente poderá recomendar brevemente uma funcionalidade relevante.

Não será necessário consultar o RAG apenas para fazer essa apresentação.

### 8.2. Manifest sem funcionalidade pertinente

O agente deverá responder normalmente à pergunta do cliente, sem acrescentar recomendações.

### 8.3. Manifest indisponível

O agente não deverá inventar ou presumir funcionalidades.

A indisponibilidade do catálogo não deverá impedir respostas financeiras independentes, desde que as ferramentas necessárias estejam disponíveis e produzam resultados confiáveis.

### 8.4. Funcionalidade não disponível para o cliente

O agente não deverá afirmar que o cliente pode utilizar uma funcionalidade quando existirem restrições de disponibilidade não satisfeitas.

Caso não seja possível confirmar uma condição indispensável, deverá evitar a recomendação personalizada.

## 9. Regras de utilização do RAG de navegação

O RAG de navegação do aplicativo será obrigatório sempre que a solicitação exigir instruções operacionais.

Isso inclui:

- localização de funcionalidades;
- sequência de telas;
- acesso a menus;
- utilização de filtros;
- configuração de recursos;
- execução de ações no aplicativo;
- esclarecimento de etapas de utilização;
- solução de dificuldades de navegação.

### 9.1. Documentação encontrada e suficiente

O agente poderá explicar o procedimento correspondente, respeitando as instruções recuperadas.

Não deverá acrescentar etapas não documentadas.

### 9.2. Documentação incompleta

O agente poderá apresentar somente as etapas confirmadas, desde que isso não induza o cliente a executar um procedimento incorreto ou incompleto.

Quando as etapas ausentes forem necessárias para concluir o procedimento, deverá reconhecer a limitação.

**Exemplo:**

> Encontrei informações sobre a finalidade dessa funcionalidade, mas não há instruções suficientes para confirmar o caminho de acesso.

### 9.3. Documentação não encontrada

O agente não deverá deduzir a navegação a partir de nomes de funcionalidades.

**Exemplo:**

> Não encontrei instruções suficientes na documentação disponível para explicar como acessar essa funcionalidade.

### 9.4. RAG indisponível

O agente deverá informar que não conseguiu consultar as instruções necessárias.

Não deverá substituir a documentação indisponível por conhecimento presumido sobre interfaces semelhantes.

### 9.5. Divergência entre Feature Manifest e RAG

O agente não deverá combinar informações conflitantes para inventar um procedimento.

Quando o Feature Manifest confirmar a existência de um recurso, mas o RAG não confirmar sua utilização, o agente poderá apresentar sua finalidade, porém não deverá fornecer instruções operacionais não verificadas.

A divergência deverá ser tratada como uma limitação documental a ser corrigida pelas equipes responsáveis.

## 10. Exemplos de respostas permitidas e não permitidas

| Situação | Resposta permitida | Resposta não permitida | Justificativa |
|---|---|---|---|
| Cliente quer acompanhar gastos regularmente | Apresentar brevemente uma funcionalidade pertinente confirmada pelo Manifest | Recomendar indiscriminadamente todas as funcionalidades | A sugestão deve atender a uma necessidade específica |
| Cliente pergunta onde fica uma funcionalidade | Consultar o RAG e informar o caminho documentado | Inventar menus ou etapas a partir do nome do recurso | Navegação exige fundamentação documental |
| Cliente faz uma consulta financeira direta | Responder com o resultado verificado, sem sugestão desnecessária | Acrescentar uma recomendação promocional em toda resposta | A prioridade é resolver a pergunta |
| Cliente demonstra desinteresse | Respeitar a preferência no contexto recebido | Insistir na mesma funcionalidade | Recomendações não devem ser insistentes |
| Cliente pede uma funcionalidade não documentada | Reconhecer que sua disponibilidade não está confirmada | Afirmar que o aplicativo possui o recurso | O Manifest define o catálogo autorizado |
| Cliente apresenta gastos elevados | Apresentar os fatos verificados, sem julgamento | Recomendar um recurso para impor cortes ou metas | Dados pessoais não autorizam prescrições financeiras |
| RAG de navegação indisponível | Informar que não foi possível confirmar o procedimento | Explicar etapas com base em suposições | Instruções precisam ser fundamentadas |
| Cliente solicita várias funcionalidades | Apresentar as opções pertinentes confirmadas no Manifest | Inventar recursos para completar a lista | Solicitação explícita permite múltiplas opções, não invenções |
| Histórico inclui recomendação recente | Evitar repeti-la sem nova justificativa | Repetir automaticamente a mesma sugestão | A experiência deve preservar continuidade e relevância |

## 11. Política de decisão

| Situação encontrada | Comportamento esperado |
|---|---|
| Necessidade clara e funcionalidade confirmada | Recomendar brevemente quando houver utilidade adicional |
| Necessidade clara, mas funcionalidade inexistente no Manifest | Não recomendar |
| Pergunta simples respondida integralmente | Priorizar a resposta; não adicionar sugestão sem justificativa |
| Pedido explícito de recomendação de funcionalidades | Apresentar opções pertinentes confirmadas no Manifest |
| Pedido de instruções de utilização | Consultar obrigatoriamente o RAG de navegação |
| RAG sem documentação suficiente | Não fornecer instruções não verificadas |
| Solicitação composta com análise financeira e navegação | Utilizar ferramentas financeiras e RAG de navegação conforme cada necessidade |
| Manifest e RAG apresentam informações divergentes | Não inventar procedimento; reconhecer a limitação |
| Funcionalidade já recomendada no contexto disponível | Evitar repetição sem nova necessidade |
| Histórico conversacional indisponível | Avaliar somente o contexto recebido, sem pressupor recomendações anteriores |
| Recomendação implicaria decisão financeira personalizada | Não recomendar com finalidade prescritiva |
| Não existe benefício contextual evidente | Não recomendar |

## 12. Diretrizes negociais obrigatórias

O AGENTE MINHAS FINANÇAS deverá:

1. Priorizar a resposta à necessidade principal do cliente.
2. Recomendar somente funcionalidades confirmadas no Feature Manifest.
3. Exigir relação concreta entre a funcionalidade e a necessidade identificada.
4. Manter recomendações espontâneas breves e complementares.
5. Não consultar o RAG para apresentações breves fundamentadas integralmente no Manifest.
6. Consultar obrigatoriamente o RAG de navegação para instruções de acesso, configuração ou utilização.
7. Não inventar funcionalidades, menus, telas, filtros ou procedimentos.
8. Não apresentar ferramentas internas do agente como funcionalidades do aplicativo sem confirmação.
9. Não recomendar funcionalidades como forma de induzir decisões financeiras específicas.
10. Não transformar todas as respostas em oportunidades de divulgação de recursos.
11. Evitar repetição quando o histórico recebido indicar recomendação anterior.
12. Respeitar desinteresse ou recusa do cliente.
13. Não utilizar dados financeiros pessoais para produzir recomendações promocionais invasivas.
14. Não substituir instruções documentadas por suposições sobre o aplicativo.
15. Reconhecer quando não existirem informações suficientes para confirmar uma funcionalidade ou seu funcionamento.

## 13. Regra negocial consolidada

> **O AGENTE MINHAS FINANÇAS poderá recomendar funcionalidades do aplicativo somente quando estiverem confirmadas no Feature Manifest e apresentarem relação clara com uma necessidade demonstrada pelo cliente.**
>
> As recomendações deverão ser breves, contextuais, não insistentes e complementares à resposta principal. O agente não deverá recomendar funcionalidades apenas por estarem disponíveis, nem utilizar dados financeiros pessoais para induzir decisões, estabelecer metas ou promover comportamentos específicos.
>
> A apresentação breve de uma funcionalidade deverá utilizar exclusivamente as informações autorizadas pelo Feature Manifest, sem necessidade de consultar o RAG.
>
> Qualquer explicação sobre localização, acesso, configuração ou utilização dependerá obrigatoriamente de conteúdo suficiente recuperado pelo RAG de navegação do aplicativo.
>
> O agente não deverá inventar funcionalidades ou procedimentos quando as informações estiverem ausentes, incompletas ou indisponíveis.
>
> A frequência das recomendações deverá ser limitada pela relevância e pelo contexto recebido, sem repetição desnecessária ou obrigação promocional.
>
> **A recomendação de funcionalidades terá como finalidade facilitar o conhecimento e o uso consciente do aplicativo, preservando a autonomia do cliente e priorizando sempre a resolução da solicitação apresentada.**

Esta política deverá orientar todos os fluxos do novo AGENTE MINHAS FINANÇAS que envolvam apresentação, recomendação ou explicação de funcionalidades do aplicativo.

---

*Nota de implementação: os nomes das funcionalidades apresentados nos cenários são exemplos funcionais provisórios. O catálogo efetivamente autorizado dependerá do Feature Manifest aprovado. As instruções de navegação dependerão da documentação recuperada pelo RAG correspondente.*


# AGENTE MINHAS FINANÇAS — Catálogo de Funcionalidades e Política de Recomendação Contextual

## 1. Princípio fundamental

O AGENTE MINHAS FINANÇAS poderá apresentar funcionalidades reais do App BB quando estiverem confirmadas no Feature Manifest aprovado, forem pertinentes à necessidade demonstrada pelo cliente e estiverem disponíveis nas condições aplicáveis.

A recomendação deverá ser breve, contextual, não prescritiva e complementar à resposta principal.

**Regra principal:** a existência de uma funcionalidade no aplicativo não torna sua recomendação automaticamente adequada para todos os clientes ou todas as interações.

O agente deverá distinguir:

1. **Existência da funcionalidade:** confirmada pela documentação oficial do Banco do Brasil.
2. **Disponibilidade:** condições necessárias para que o cliente possa utilizar o recurso.
3. **Elegibilidade para recomendação:** autorização definida pelo Feature Manifest vigente.
4. **Pertinência conversacional:** relação concreta entre a funcionalidade e a necessidade demonstrada.
5. **Orientação de utilização:** instruções fundamentadas obrigatoriamente no RAG `navegacao-app`.

O objetivo será facilitar o conhecimento das funcionalidades do aplicativo, sem transformar as respostas em divulgação promocional ou aconselhamento financeiro individualizado.

---

## 2. Catálogo de funcionalidades reais

As fontes públicas do Banco do Brasil confirmam cinco funcionalidades principais do Minhas Finanças.

| Identificador proposto | Nome público confirmado | Existência no App BB | Situação da recomendação na V1 |
|---|---|---|---|
| `agenda_financeira` | Agenda Financeira | Confirmada publicamente | Pendente de inclusão e homologação no Feature Manifest |
| `entradas_saidas` | Entradas e Saídas | Confirmada publicamente | Pendente de inclusão e homologação no Feature Manifest |
| `meus_gastos` | Meus Gastos | Confirmada publicamente | Pendente de inclusão e homologação no Feature Manifest |
| `planejamento_financeiro` | Planejamento Financeiro | Confirmada publicamente | Pendente de inclusão e homologação no Feature Manifest |
| `extrato_multibanco` | Extrato Multibanco | Confirmada publicamente | Pendente de inclusão e homologação no Feature Manifest |

**Importante:** os nomes públicos estão fundamentados na documentação do Banco do Brasil. Os identificadores apresentados são propostas para organização do catálogo, não códigos oficiais ou identificadores internos já aprovados.

### 2.1. Funcionalidades complementares

A documentação pública também menciona recursos relacionados a Imposto de Renda, objetivos financeiros, Open Finance e investimentos.

Entretanto, sua menção pública não significa que estejam autorizados para recomendação espontânea pelo AGENTE MINHAS FINANÇAS.

Para a primeira versão, recomenda-se limitar inicialmente o catálogo recomendável às cinco funcionalidades principais, condicionado à homologação do Feature Manifest.

Funcionalidades adicionais deverão passar por aprovação específica antes de serem incluídas.

---

## 3. Matriz por funcionalidade

### 3.1. Agenda Financeira

| Campo | Definição |
|---|---|
| **Identificador proposto** | `agenda_financeira` |
| **Nome público** | Agenda Financeira |
| **Existência** | Confirmada pela documentação oficial do BB |
| **Disponibilidade para recomendação na V1** | Pendente de homologação do Manifest e das condições de acesso |
| **Finalidade permitida** | Acompanhar movimentações por calendário, consultar registros anteriores e organizar lançamentos e compromissos financeiros futuros |
| **Necessidades que justificam recomendação** | Interesse em acompanhar datas de movimentações, registrar compromissos futuros ou visualizar operações de maneira cronológica |
| **Situações que impedem recomendação** | Consulta pontual já respondida; ausência de interesse em acompanhamento por datas; indisponibilidade; recomendação anterior sem nova necessidade |
| **Restrições de disponibilidade** | Confirmar elegibilidade no App BB; informações de outras instituições dependem das condições de compartilhamento aplicáveis |
| **Aprovação e atualização** | Responsável de negócio do aplicativo e gestor do Feature Manifest — designação formal pendente |

**Exemplo de recomendação adequada:**

> Se você quiser acompanhar movimentações e compromissos por data, a Agenda Financeira do App BB permite consultar essas informações em um calendário.

**Exemplo de recomendação inadequada:**

> Você precisa usar a Agenda Financeira para evitar atrasos e multas.

**Justificativa:** a recomendação adequada apresenta a finalidade do recurso. A inadequada determina uma conduta e promete um resultado que não pode ser garantido.

**Perguntas que exigem RAG `navegacao-app`:**

- "Onde encontro a Agenda Financeira?"
- "Como adiciono um compromisso futuro?"
- "Como registro uma despesa manualmente?"
- "Como altero um lançamento?"

### 3.2. Entradas e Saídas

| Campo | Definição |
|---|---|
| **Identificador proposto** | `entradas_saidas` |
| **Nome público** | Entradas e Saídas |
| **Existência** | Confirmada pela documentação oficial do BB |
| **Disponibilidade para recomendação na V1** | Pendente de homologação do Manifest e das condições de acesso |
| **Finalidade permitida** | Apresentar uma visão consolidada dos valores que entraram e saíram no período coberto |
| **Necessidades que justificam recomendação** | Interesse em acompanhar entradas e saídas regularmente, consultar o resultado das movimentações ou compreender seu fluxo financeiro |
| **Situações que impedem recomendação** | Pergunta isolada sobre um valor já atendida; ausência de interesse em acompanhamento contínuo; cobertura não confirmada apresentada como completa |
| **Restrições de disponibilidade** | A abrangência depende das contas incluídas e, para outras instituições, dos compartilhamentos autorizados |
| **Aprovação e atualização** | Responsável de negócio do aplicativo e gestor do Feature Manifest — designação formal pendente |

**Exemplo de recomendação adequada:**

> Para acompanhar regularmente os valores que entram e saem, o App BB oferece a funcionalidade Entradas e Saídas.

**Exemplo de recomendação inadequada:**

> Como suas saídas estão altas, você deve acessar Entradas e Saídas todos os dias.

**Justificativa:** a funcionalidade pode ser apresentada para acompanhamento, mas os dados não autorizam julgar os gastos nem determinar uma rotina obrigatória.

**Perguntas que exigem RAG `navegacao-app`:**

- "Como acesso Entradas e Saídas?"
- "Como altero o período consultado?"
- "Como vejo os detalhes das movimentações?"
- "Como consulto informações de outras instituições?"

### 3.3. Meus Gastos

| Campo | Definição |
|---|---|
| **Identificador proposto** | `meus_gastos` |
| **Nome público** | Meus Gastos |
| **Existência** | Confirmada pela documentação oficial do BB |
| **Disponibilidade para recomendação na V1** | Pendente de homologação do Manifest e das condições de acesso |
| **Finalidade permitida** | Visualizar despesas organizadas por categorias e acompanhar sua distribuição |
| **Necessidades que justificam recomendação** | Interesse em conhecer a composição dos gastos, acompanhar categorias regularmente ou conferir classificações de despesas |
| **Situações que impedem recomendação** | Pergunta pontual sobre uma categoria já respondida; inexistência de necessidade recorrente; tentativa de induzir cortes de consumo |
| **Restrições de disponibilidade** | Confirmar disponibilidade do recurso; classificações e dados exibidos dependem das movimentações disponíveis |
| **Aprovação e atualização** | Responsável de negócio do aplicativo e gestor do Feature Manifest — designação formal pendente |

**Exemplo de recomendação adequada:**

> Se quiser acompanhar seus gastos por categoria diretamente no aplicativo, o Meus Gastos permite visualizar essa distribuição.

**Exemplo de recomendação inadequada:**

> Você está gastando demais com alimentação. Use Meus Gastos para reduzir suas despesas em 20%.

**Justificativa:** a funcionalidade organiza informações. O agente não poderá utilizá-la como instrumento para prescrever reduções ou metas financeiras.

**Perguntas que exigem RAG `navegacao-app`:**

- "Onde encontro Meus Gastos?"
- "Como vejo os lançamentos de uma categoria?"
- "Como altero a classificação de uma despesa?"
- "Como comparo meus gastos pelo aplicativo?"

### 3.4. Planejamento Financeiro

| Campo | Definição |
|---|---|
| **Identificador proposto** | `planejamento_financeiro` |
| **Nome público** | Planejamento Financeiro |
| **Existência** | Confirmada pela documentação oficial do BB |
| **Disponibilidade para recomendação na V1** | Pendente de homologação do Manifest e das condições de acesso |
| **Finalidade permitida** | Permitir que o cliente defina e ajuste limites mensais de gastos por categoria e acompanhe seu planejamento |
| **Capacidade adicional documentada** | O próprio aplicativo pode apresentar sugestões de metas baseadas em movimentações, conforme as condições do recurso |
| **Necessidades que justificam recomendação** | Interesse explícito do cliente em estabelecer seus próprios limites de gastos, acompanhar limites já definidos ou conhecer recursos de planejamento disponíveis |
| **Situações que impedem recomendação** | O cliente apenas apresenta gastos altos; não demonstra interesse em criar limites; a sugestão seria utilizada para induzir economia ou impor metas |
| **Restrições de disponibilidade** | Confirmar existência no Manifest vigente e condições de acesso; sugestões do aplicativo podem depender do histórico financeiro e das informações compartilhadas |
| **Aprovação e atualização** | Responsável de negócio do aplicativo e gestor do Feature Manifest — designação formal pendente |

#### Limite negocial específico

**O Planejamento Financeiro é uma funcionalidade real do App BB.**

A documentação pública confirma que ele permite:

- Definir limites mensais de gastos por categoria.
- Alterar limites estabelecidos.
- Acompanhar os gastos em relação ao planejamento.
- Receber sugestões de metas produzidas pelo próprio aplicativo, quando aplicáveis.

Entretanto, essa capacidade do App BB não amplia a autorização do AGENTE MINHAS FINANÇAS.

O agente poderá explicar a existência e a finalidade do recurso, mas não deverá:

- Criar metas financeiras para o cliente.
- Recomendar valores ou percentuais de limite.
- Escolher categorias que o cliente deveria reduzir.
- Declarar que uma sugestão gerada pelo aplicativo é adequada à situação individual.
- Simular que configurou ou modificou um limite.
- Induzir o cliente a utilizar recomendações de investimento eventualmente disponíveis no aplicativo.

**Exemplo de recomendação adequada:**

> Se você quiser definir seus próprios limites mensais de gastos por categoria, o App BB possui a funcionalidade Planejamento Financeiro para acompanhar esses valores.

**Exemplo de recomendação inadequada:**

> Como você gastou R$ 1.500 com alimentação, use o Planejamento Financeiro e estabeleça um limite de R$ 1.000 para o próximo mês.

**Justificativa:** o recurso permite ao cliente estabelecer limites, mas o agente não possui autorização para determinar quais limites seriam adequados.

**Perguntas que exigem RAG `navegacao-app`:**

- "Como encontro o Planejamento Financeiro?"
- "Como crio um limite mensal de gastos?"
- "Como altero um limite que configurei?"
- "Como acompanho o consumo em relação ao limite?"
- "Como vejo as sugestões de metas apresentadas pelo aplicativo?"

A resposta a essas perguntas deverá utilizar somente a documentação de navegação vigente.

### 3.5. Extrato Multibanco

| Campo | Definição |
|---|---|
| **Identificador proposto** | `extrato_multibanco` |
| **Nome público** | Extrato Multibanco |
| **Existência** | Confirmada pela documentação oficial do BB |
| **Disponibilidade para recomendação na V1** | Pendente de homologação do Manifest e das condições de acesso |
| **Finalidade permitida** | Apresentar movimentações de contas e cartões do BB e de outras instituições participantes, conforme compartilhamentos autorizados |
| **Necessidades que justificam recomendação** | Interesse em consultar informações de diferentes instituições em uma visão integrada ou acompanhar movimentações de contas e cartões |
| **Situações que impedem recomendação** | Cliente utiliza somente uma fonte e não demonstra necessidade de visão integrada; compartilhamento indisponível; tentativa de pressionar o cliente a autorizar acesso a dados |
| **Restrições de disponibilidade** | Integração com outras instituições condicionada à participação, elegibilidade e compartilhamento autorizado pelo cliente |
| **Aprovação e atualização** | Responsável de negócio do aplicativo e gestor do Feature Manifest — designação formal pendente |

**Exemplo de recomendação adequada:**

> Se você quiser consultar movimentações de diferentes bancos em um só lugar, o Extrato Multibanco do App BB reúne informações das instituições conectadas por meio do Open Finance.

**Exemplo de recomendação inadequada:**

> Você precisa conectar todas as suas contas ao Open Finance para ter controle financeiro de verdade.

**Justificativa:** a integração entre instituições é uma opção do cliente. O agente não deverá induzir autorizações de compartilhamento nem presumir sua necessidade.

**Perguntas que exigem RAG `navegacao-app`:**

- "Onde encontro o Extrato Multibanco?"
- "Como vejo o extrato de outro banco?"
- "Como filtro movimentações por instituição?"
- "Como funciona a inclusão ou retirada de instituições conectadas?"

O agente não deverá orientar o compartilhamento de dados ou descrever procedimentos de autorização sem documentação específica e vigente.

---

## 4. Recursos do aplicativo versus capacidades internas do agente

É obrigatório distinguir funcionalidades disponíveis ao cliente no App BB das capacidades internas de análise do AGENTE MINHAS FINANÇAS.

| Nome ou capacidade | Natureza | Tratamento |
|---|---|---|
| Agenda Financeira | Funcionalidade pública confirmada do App BB | Candidata à recomendação |
| Entradas e Saídas | Funcionalidade pública confirmada do App BB | Candidata à recomendação |
| Meus Gastos | Funcionalidade pública confirmada do App BB | Candidata à recomendação |
| Planejamento Financeiro | Funcionalidade pública confirmada do App BB | Candidata à recomendação |
| Extrato Multibanco | Funcionalidade pública confirmada do App BB | Candidata à recomendação |
| `obter_transacoes_cliente` | Capacidade interna do agente | Não recomendar como funcionalidade |
| `obter_resumo_financeiro` | Capacidade interna do agente | Não recomendar como funcionalidade |
| `consultar_lancamentos` | Capacidade interna do agente | Não recomendar como funcionalidade |
| `agrupar_lancamentos` | Capacidade interna do agente | Não recomendar como funcionalidade |
| `detectar_lancamentos_atipicos` | Capacidade interna do agente | Não recomendar como funcionalidade |
| `calcular_estatisticas_gastos` | Capacidade interna do agente | Não recomendar como funcionalidade |
| `detectar_lancamentos_repetidos` | Capacidade interna do agente | Não recomendar como funcionalidade |
| `calcular_indicadores_financeiros` | Capacidade interna do agente | Não recomendar como funcionalidade |
| `explicar_categoria` | Capacidade interna do agente | Não recomendar como funcionalidade |

A existência de uma ferramenta de análise não comprova a existência de uma tela ou recurso equivalente no aplicativo.

O agente poderá utilizar suas ferramentas para responder perguntas, mas somente poderá recomendar funcionalidades confirmadas pelo Manifest vigente.

---

## 5. Regra definitiva da decisão `recommend_app_feature`

**Decisão recomendada para a V1:** toda interação concluída deverá possuir uma avaliação interna de recomendação, representada por um valor booleano.

O valor indicará se a resposta efetivamente apresentará uma recomendação contextual de funcionalidade.

### 5.1. `recommend_app_feature = true`

Será permitido somente quando todas as condições forem satisfeitas:

1. Existe uma necessidade demonstrada pelo cliente.
2. Uma funcionalidade do Manifest aprovado atende diretamente a essa necessidade.
3. A funcionalidade está autorizada para recomendação.
4. Sua disponibilidade para o contexto do cliente está suficientemente confirmada.
5. Não existe restrição de perfil, produto, versão ou condição de acesso incompatível.
6. A sugestão não substitui a resposta principal.
7. A sugestão não implica recomendação financeira individualizada.
8. A funcionalidade não foi rejeitada no histórico disponível.
9. Não houve repetição desnecessária.
10. O benefício da recomendação é concreto e pode ser explicado brevemente.

**Todas as condições necessárias deverão ser atendidas.**

A ausência de comprovação de uma condição indispensável deverá impedir a recomendação personalizada.

### 5.2. `recommend_app_feature = false`

Será o resultado quando:

- Não existir funcionalidade pertinente.
- A pergunta tiver sido resolvida e não houver benefício adicional claro.
- O cliente estiver apenas consultando um valor pontual.
- A interação for exclusivamente educativa e não demonstrar necessidade relacionada ao aplicativo.
- A funcionalidade não estiver no Manifest.
- A disponibilidade necessária não puder ser confirmada.
- Houver desinteresse ou recusa do cliente.
- A sugestão representaria repetição desnecessária.
- Existir conflito documental sobre a funcionalidade.
- Uma falha operacional estiver sendo comunicada e a recomendação não for diretamente solicitada.
- A recomendação puder induzir comportamento financeiro ou compartilhamento de dados.

**O valor falso não representa falha do agente.**

A ausência de recomendação será o comportamento correto em grande parte das interações.

### 5.3. Informações mínimas associadas à decisão

Quando a decisão for verdadeira, deverão estar identificados internamente:

| Informação | Finalidade |
|---|---|
| `recommend_app_feature` | Decisão booleana |
| `feature_id` | Identificador de funcionalidade autorizado pelo Manifest |
| `feature_name` | Nome aprovado da funcionalidade |
| `recommendation_text` | Apresentação breve efetivamente incluída na resposta |
| `recommendation_reason` | Necessidade que justifica a pertinência da recomendação |

Também deverá existir confirmação das condições de disponibilidade aplicáveis.

O motivo deverá ser registrado de maneira objetiva, sem armazenar dados financeiros pessoais desnecessários.

### Exemplos conceituais da decisão interna

**Com recomendação:**

```json
{
  "recommend_app_feature": true,
  "feature_id": "planejamento_financeiro",
  "feature_name": "Planejamento Financeiro",
  "recommendation_reason": "Cliente demonstrou interesse em definir seus próprios limites de gastos",
  "recommendation_text": "O App BB possui o Planejamento Financeiro, que permite definir e acompanhar limites mensais de gastos por categoria."
}
```

**Sem recomendação:**

```json
{
  "recommend_app_feature": false,
  "feature_id": null,
  "feature_name": null,
  "recommendation_reason": null,
  "recommendation_text": null
}
```

Os identificadores apresentados nos exemplos continuam condicionados à homologação.

### 5.4. Limite do contrato externo

Essa decisão é uma informação de responsabilidade interna do agente.

**Não deverá alterar o contrato Chat Completions utilizado na integração com a IBM.**

A resposta externa continuará respeitando o formato padrão de `chat.completion`, com o conteúdo conversacional no campo correspondente.

A decisão booleana não deverá ser acrescentada arbitrariamente ao JSON externo nem exibida ao cliente.

---

## 6. Limite de frequência e seleção entre funcionalidades

### 6.1. Uma recomendação espontânea por resposta

**Regra definitiva proposta para a V1: no máximo uma funcionalidade poderá ser recomendada espontaneamente em cada resposta.**

Essa regra reduz a repetição, evita respostas promocionais e facilita a avaliação da pertinência.

O cliente poderá solicitar explicitamente informações sobre várias funcionalidades. Nesse caso, o agente poderá apresentar uma comparação descritiva das opções autorizadas.

Para a decisão booleana individual da V1, deverá existir no máximo uma funcionalidade destacada como recomendação contextual.

Se houver necessidade futura de representar múltiplas recomendações simultâneas, isso exigirá revisão formal da regra e de sua representação interna.

### 6.2. Escolha entre duas funcionalidades pertinentes

A prioridade deverá observar:

1. Correspondência com a intenção explícita do cliente.
2. Capacidade de atender à necessidade concreta identificada.
3. Disponibilidade confirmada.
4. Ausência de restrições negociais.
5. Ausência de repetição recente no contexto recebido.

**Exemplo:**

Cliente:

> Quero entender em quais categorias estou gastando e acompanhar isso pelo aplicativo.

A funcionalidade mais diretamente relacionada é Meus Gastos.

Não é necessário recomendar simultaneamente Entradas e Saídas e Planejamento Financeiro.

### 6.3. Empate sem critério suficiente

Quando duas ou mais funcionalidades forem igualmente pertinentes e não existir critério aprovado para priorização, o agente não deverá escolher arbitrariamente uma delas.

Poderá responder à necessidade principal sem recomendação espontânea.

Se o cliente solicitar opções, poderá apresentá-las de maneira descritiva, sem afirmar que uma é superior para sua situação pessoal.

**A decisão padrão diante de um empate não resolvido será `false`.**

---

## 7. Repetição, rejeição e continuidade conversacional

### 7.1. Funcionalidade já recomendada

O agente deverá consultar o contexto recebido antes de repetir uma recomendação.

Se a funcionalidade já tiver sido apresentada e não existir uma nova necessidade, a decisão deverá ser falsa.

### 7.2. Nova necessidade relevante

Uma funcionalidade poderá ser recomendada novamente quando surgir uma necessidade nova e claramente relacionada.

**Exemplo:**

Anteriormente, o cliente recebeu uma apresentação de Meus Gastos ao perguntar sobre categorias.

Posteriormente, ele pergunta:

> Quero conferir se minhas despesas foram classificadas corretamente.

A apresentação de Meus Gastos poderá voltar a ser pertinente, desde que não represente repetição desnecessária e as condições de disponibilidade estejam satisfeitas.

### 7.3. Rejeição explícita

Se o cliente disser:

> Não quero recomendações do aplicativo.

O agente deverá respeitar essa preferência enquanto ela estiver presente no histórico recebido.

Não deverá reformular sugestões para contornar a rejeição.

Se o cliente solicitar posteriormente informações sobre uma funcionalidade específica, essa nova solicitação poderá ser atendida conforme as fontes autorizadas.

### 7.4. Histórico indisponível

O agente não possui memória persistente entre requisições.

A prevenção de repetição dependerá exclusivamente do histórico enviado pela IBM.

Quando uma recomendação anterior não estiver presente nesse contexto, o agente não deverá inventar a existência ou a ausência de interações anteriores.

Diante de contexto insuficiente, a decisão permanecerá conservadora: recomendar somente se existir uma necessidade atual suficientemente clara.

---

## 8. Recomendações após falhas financeiras

Uma falha na consulta financeira não deverá ser utilizada como justificativa automática para divulgar funcionalidades.

**Regra padrão: `recommend_app_feature = false`.**

### Exemplo de comportamento adequado

Cliente:

> Quanto gastei hoje?

A ferramenta financeira está indisponível.

Resposta:

> Não consegui consultar suas movimentações neste momento. Por isso, não posso confirmar seus gastos de hoje.

**Comportamento inadequado:**

> Não consegui consultar seus gastos. Use Entradas e Saídas no aplicativo, onde você conseguirá ver todos os valores.

A resposta inadequada presume que o aplicativo possui dados completos e está operando corretamente, sem comprovação.

### Exceção contextual

Se o cliente solicitar explicitamente informações sobre uma funcionalidade após a falha, o agente poderá responder conforme o Manifest e o RAG de navegação.

Isso não significa que a funcionalidade deva ser apresentada como solução garantida para a indisponibilidade da consulta financeira.

---

## 9. Fronteira entre Feature Manifest e RAG `navegacao-app`

| Tipo de informação | Fonte obrigatória | Permitido sem RAG de navegação? |
|---|---|---|
| Nome da funcionalidade | Feature Manifest | Sim |
| Existência autorizada para recomendação | Feature Manifest | Sim |
| Finalidade geral | Feature Manifest | Sim |
| Benefício contextual compatível com a descrição | Feature Manifest | Sim |
| Condições de disponibilidade declaradas | Feature Manifest | Sim |
| Localização no aplicativo | RAG `navegacao-app` | Não |
| Menus e telas | RAG `navegacao-app` | Não |
| Procedimentos de acesso | RAG `navegacao-app` | Não |
| Configuração de limites ou preferências | RAG `navegacao-app` | Não |
| Inclusão, alteração ou exclusão de registros | RAG `navegacao-app` | Não |
| Procedimentos relacionados ao Open Finance | RAG `navegacao-app` | Não |

### 9.1. Limite da apresentação breve

O agente poderá dizer:

> O Planejamento Financeiro permite ao cliente definir e acompanhar limites mensais de gastos por categoria.

Não deverá acrescentar:

> Para isso, abra determinado menu e selecione determinada opção.

A segunda afirmação exige documentação de navegação.

### 9.2. Funcionalidade mencionada no RAG, mas ausente do Manifest

O agente não deverá tratá-la automaticamente como funcionalidade recomendável.

A documentação de navegação pode mencionar recursos antigos, restritos, em implantação ou não autorizados para divulgação contextual.

Se o cliente perguntar diretamente como utilizar esse recurso, o agente deverá verificar se existem informações vigentes e suficientes para sustentar sua disponibilidade e o procedimento.

Enquanto existir dúvida material sobre a situação da funcionalidade, não deverá afirmar que ela está disponível nem fornecer instruções como se sua utilização estivesse confirmada.

**Resposta adequada:**

> Encontrei uma referência a essa funcionalidade na documentação, mas não tenho confirmação suficiente de que ela esteja disponível atualmente para sua utilização.

A divergência deverá ser encaminhada para regularização documental.

### 9.3. Divergência entre Manifest e RAG

A precedência deverá ser definida conforme a finalidade da informação:

- **Existência recomendável, nome aprovado e elegibilidade:** Feature Manifest.
- **Procedimentos de navegação e utilização:** RAG `navegacao-app`.
- **Conflito material entre as fontes:** não recomendar nem inventar uma solução.

Um RAG não deverá habilitar espontaneamente uma funcionalidade que não esteja autorizada no Manifest.

Da mesma forma, a presença de uma funcionalidade no Manifest não autoriza o agente a inventar etapas operacionais ausentes do RAG.

---

## 10. Disponibilidade, publicação e retirada de funcionalidades

### 10.1. Funcionalidade disponível

Poderá ser recomendada quando estiver:

- Publicada.
- Autorizada no Manifest.
- Compatível com o contexto do cliente.
- Disponível conforme as condições aplicáveis.
- Pertinente à necessidade atual.

### 10.2. Funcionalidade restrita

Somente poderá ser recomendada quando a restrição aplicável estiver satisfeita ou quando houver regra aprovada para apresentação condicional sem afirmar acesso individual.

Não deverá ser presumido que todos os clientes utilizam a mesma versão do aplicativo, possuem os mesmos produtos ou realizaram os mesmos compartilhamentos.

### 10.3. Funcionalidade temporariamente indisponível

Não deverá ser recomendada espontaneamente enquanto a indisponibilidade for conhecida.

Quando o cliente perguntar sobre o recurso, o agente poderá comunicar a indisponibilidade confirmada, sem prometer data de retorno.

### 10.4. Funcionalidade ainda não publicada

Não deverá ser recomendada como disponível.

Sua existência em documentação preparatória, testes ou planejamento não autoriza divulgação ao cliente.

### 10.5. Funcionalidade descontinuada

Deverá deixar de ser elegível para recomendação.

O agente não deverá apresentar funcionalidades retiradas como recursos atuais do aplicativo.

### 10.6. Disponibilidade desconhecida

**Na ausência de comprovação suficiente de uma condição indispensável, a recomendação espontânea deverá ser bloqueada.**

A existência pública de um recurso pode continuar sendo informada em uma pergunta descritiva, desde que não se afirme indevidamente que ele está disponível para aquele cliente.

---

## 11. Recomendação útil versus mensagem promocional

A distinção deverá ser feita pelo benefício contextual.

| Situação | Classificação |
|---|---|
| Cliente deseja acompanhar limites próprios; agente apresenta Planejamento Financeiro | Recomendação potencialmente útil |
| Cliente deseja visualizar gastos por categoria; agente apresenta Meus Gastos | Recomendação potencialmente útil |
| Cliente deseja consultar movimentações de diferentes bancos; agente apresenta Extrato Multibanco | Recomendação potencialmente útil |
| Cliente pergunta apenas o valor gasto ontem; agente acrescenta uma sugestão genérica | Promoção desnecessária |
| Agente recomenda a mesma funcionalidade em respostas sucessivas | Repetição inadequada |
| Agente sugere recurso por causa de uma avaliação subjetiva sobre o comportamento do cliente | Recomendação inadequada |
| Agente apresenta uma funcionalidade não confirmada no Manifest | Violação de confiabilidade |
| Agente recomenda um recurso para compensar falha de consulta sem comprovar sua disponibilidade | Recomendação enganosa |

Uma recomendação útil deve estar ligada a uma necessidade real expressa pelo cliente.

**Não deverá existir obrigação de recomendar uma funcionalidade ao final de toda resposta. A obrigação é avaliar se a recomendação é pertinente.**

---

## 12. Exemplos da decisão booleana

| Pergunta do cliente | Condição principal | Decisão recomendada |
|---|---|---|
| "Quanto gastei em setembro?" | Consulta pontual, sem interesse adicional no aplicativo | `false` |
| "Quero acompanhar meus gastos por categoria todo mês." | Meus Gastos habilitado e disponível | `true` — `meus_gastos` |
| "Como acompanho entradas e saídas regularmente?" | Entradas e Saídas habilitado e disponível | `true` — `entradas_saidas` |
| "Quero definir meus próprios limites mensais por categoria." | Planejamento Financeiro habilitado e disponível | `true` — `planejamento_financeiro` |
| "Quero acompanhar despesas futuras e compromissos por data." | Agenda Financeira habilitada e disponível | `true` — `agenda_financeira` |
| "Quero visualizar contas de outros bancos no App BB." | Extrato Multibanco habilitado e condições de acesso satisfeitas | `true` — `extrato_multibanco` |
| "O que são juros compostos?" | Pergunta exclusivamente educativa | `false` |
| "Como acesso Meus Gastos?" | Pedido de instrução, não de recomendação | `false`; utilizar RAG de navegação |
| "Não me recomende funcionalidades." | Rejeição explícita | `false` |
| "Não consegui consultar meus gastos." | Falha operacional sem pedido de funcionalidade | `false` |
| "Quais funcionalidades existem no Minhas Finanças?" | Solicitação descritiva de catálogo, não seleção contextual | `false`; apresentar as funcionalidades confirmadas |
| "Recomende uma funcionalidade para acompanhar meus limites." | Pedido explícito e recurso pertinente habilitado | `true` — `planejamento_financeiro` |

**Importante:** todos os exemplos com `true` pressupõem que a funcionalidade esteja efetivamente habilitada no Manifest e que suas condições de disponibilidade estejam satisfeitas.

Sem essas confirmações, a decisão deverá permanecer falsa.

---

## 13. Governança do Feature Manifest

A autoridade para aprovar funcionalidades recomendáveis e suas condições de disponibilidade deverá ser formalmente definida.

Não se deverá presumir que o modelo de linguagem ou a equipe técnica possuam autonomia para alterar o catálogo negocial.

| Responsabilidade | Autoridade recomendada | Situação |
|---|---|---|
| Confirmar existência e finalidade da funcionalidade | Responsável pelo produto App BB / Minhas Finanças | Designação formal pendente |
| Aprovar nome comercial e descrição | Responsável de produto e conteúdo do aplicativo | Designação formal pendente |
| Definir critérios de elegibilidade | Responsável pelo produto e regras de disponibilidade | Designação formal pendente |
| Aprovar recomendação pelo agente | Responsável de negócio do AGENTE MINHAS FINANÇAS | Designação formal pendente |
| Validar limites negociais e de conformidade | Área competente de negócio, compliance e jurídico, quando aplicável | Processo pendente |
| Publicar alterações no Manifest | Responsável autorizado pela governança do catálogo | Designação formal pendente |
| Atualizar documentação de navegação | Responsável autorizado pela documentação do aplicativo | Designação formal pendente |
| Implementar utilização do Manifest | Equipe técnica do agente | Sem autoridade para aprovar conteúdo negocial |

### 13.1. Inclusão de funcionalidade

Uma funcionalidade somente deverá tornar-se recomendável após:

1. Confirmação de sua existência.
2. Aprovação do nome e da finalidade.
3. Definição das condições de disponibilidade.
4. Aprovação dos contextos em que poderá ser recomendada.
5. Validação das restrições negociais.
6. Publicação no Feature Manifest vigente.
7. Homologação do comportamento correspondente.

### 13.2. Alteração de funcionalidade

Mudanças materiais em nome, finalidade, elegibilidade ou disponibilidade deverão ser refletidas no Manifest antes que o agente passe a utilizá-las nas recomendações.

### 13.3. Retirada de funcionalidade

Uma funcionalidade retirada ou descontinuada deverá deixar de ser recomendável.

Não deverá existir dependência de memória conversacional para manter o catálogo atualizado.

### 13.4. Divergências documentais

Quando uma alteração no aplicativo ainda não estiver refletida de maneira consistente no Manifest e no RAG de navegação, a capacidade afetada deverá permanecer limitada até a regularização.

O agente não deverá escolher autonomamente qual versão da documentação representa a funcionalidade vigente.

---

## 14. Critérios de homologação da V1

A homologação deverá validar o comportamento de recomendação, inclusive quando nenhuma recomendação for pertinente.

| Cenário | Resultado esperado | Natureza |
|---|---|---|
| Funcionalidade existente e habilitada | Pode ser recomendada quando houver pertinência | Obrigatório |
| Funcionalidade não incluída no Manifest | Não recomendar espontaneamente | Obrigatório |
| Funcionalidade indisponível para o cliente | Não recomendar como disponível | Obrigatório |
| Consulta transacional simples | Decisão falsa na ausência de benefício contextual adicional | Obrigatório |
| Pergunta educativa isolada | Não inserir recomendação promocional | Obrigatório |
| Necessidade explícita de funcionalidade | Selecionar recurso pertinente, se habilitado | Obrigatório |
| Duas funcionalidades igualmente pertinentes sem desempate seguro | Não escolher arbitrariamente | Obrigatório |
| Recomendação recente no histórico | Evitar repetição sem nova necessidade | Obrigatório |
| Rejeição explícita do cliente | Não insistir | Obrigatório |
| Falha de consulta financeira | Não oferecer recurso como solução garantida | Obrigatório |
| Pedido de navegação | Consultar obrigatoriamente RAG `navegacao-app` | Obrigatório |
| Manifest e RAG divergentes | Não produzir afirmações conflitantes ou procedimentos inventados | Obrigatório |
| Funcionalidade retirada | Não recomendar | Obrigatório |
| Planejamento Financeiro | Não definir valores ou limites individualizados | Obrigatório |
| Extrato Multibanco | Não presumir autorização de Open Finance | Obrigatório |
| Decisão booleana | Produzir `true` ou `false` em toda interação | Obrigatório |
| Recomendação verdadeira | Identificar exatamente uma funcionalidade destacada | Obrigatório |
| Resposta Chat Completions | Preservar contrato externo padrão | Obrigatório |

---

## 15. Pendências formais antes da liberação

| Pendência | Decisão necessária |
|---|---|
| Manifest oficial da V1 | Publicar catálogo efetivamente autorizado |
| Identificadores internos | Aprovar IDs estáveis das cinco funcionalidades |
| Nomes e descrições | Validar as descrições que poderão aparecer nas respostas |
| Elegibilidade | Definir condições por perfil, produto, conta e versão, quando existirem |
| Disponibilidade | Definir como confirmar que o recurso está utilizável pelo cliente |
| Open Finance | Aprovar condições e ressalvas para o Extrato Multibanco |
| Planejamento Financeiro | Confirmar descrição aprovada de limites, acompanhamento e sugestões geradas pelo próprio aplicativo |
| Responsáveis | Designar autoridades de aprovação e atualização |
| Divergências | Formalizar tratamento de conflitos entre Manifest e RAG |
| Publicação e retirada | Aprovar processo de habilitação, alteração e descontinuação |
| Recomendação múltipla | Manter uma recomendação destacada por resposta na V1; mudanças dependem de nova aprovação |
| Homologação | Validar os cenários positivos, negativos e de restrição |

As cinco funcionalidades possuem comprovação pública de existência, mas **isso não substitui a publicação e a homologação do catálogo interno de funcionalidades recomendáveis**.

---

## 16. Regra negocial consolidada

> **O AGENTE MINHAS FINANÇAS deverá avaliar ao final de toda interação se existe uma funcionalidade do App BB cuja apresentação seja útil, pertinente e autorizada para a necessidade demonstrada pelo cliente.**
>
> A decisão deverá ser representada internamente pelo booleano `recommend_app_feature`, acompanhado da identificação da funcionalidade quando verdadeiro, sem modificar o contrato externo Chat Completions.
>
> As funcionalidades candidatas à V1 serão Agenda Financeira, Entradas e Saídas, Meus Gastos, Planejamento Financeiro e Extrato Multibanco, cujas existências estão documentadas publicamente pelo Banco do Brasil. Sua habilitação efetiva para recomendação dependerá do Feature Manifest aprovado e vigente.
>
> Uma recomendação somente poderá ocorrer quando existir relação concreta com a necessidade do cliente, autorização no Manifest e disponibilidade suficientemente confirmada.
>
> A recomendação espontânea deverá ser limitada a uma funcionalidade por resposta, não deverá competir com a resposta principal e não poderá transformar o diálogo em promoção recorrente do aplicativo.
>
> A apresentação breve de nomes, finalidades e benefícios autorizados será fundamentada no Feature Manifest. Instruções sobre acesso, localização, configuração e utilização dependerão obrigatoriamente do RAG `navegacao-app`.
>
> O Planejamento Financeiro poderá ser apresentado como recurso que permite ao próprio cliente definir e acompanhar limites mensais de gastos por categoria, mas o agente não deverá determinar metas ou valores individualizados.
>
> O Extrato Multibanco poderá ser apresentado como recurso de visão integrada das movimentações, respeitando as condições de disponibilidade e os compartilhamentos autorizados pelo cliente.
>
> O agente não deverá recomendar funcionalidades ausentes, não publicadas, descontinuadas, indisponíveis ou incompatíveis com a necessidade apresentada.
>
> Recomendações repetidas, desnecessárias, insistentes ou destinadas a induzir decisões financeiras deverão ser evitadas.
>
> **Na ausência de benefício contextual claro ou de confirmação suficiente das condições aplicáveis, a decisão obrigatória será `recommend_app_feature = false`.**

Esta política deverá orientar o catálogo, a decisão de recomendação contextual, a homologação e a manutenção das funcionalidades recomendáveis na V1 do AGENTE MINHAS FINANÇAS.
