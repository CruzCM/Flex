# Guia direto dos CSVs sintéticos (`001.csv` a `007.csv`)

<!-- markdownlint-disable MD013 -->

> [!IMPORTANT]
> **Fonte Única da Verdade Universal:** A especificação oficial, completa e autoritativa do projeto (incluindo o oráculo matemático verificado e os hashes SHA-256 dos 7 CSVs) encontra-se exclusivamente em **[`Documentação-Final-Agent-MF.md`](Documentação-Final-Agent-MF.md)**. Em qualquer dúvida ou divergência, prevalece exclusivamente [`Documentação-Final-Agent-MF.md`](Documentação-Final-Agent-MF.md).

Este documento resume, de forma direta, o que cada arquivo em [`clientes_sinteticos/`](clientes_sinteticos/) contém, qual resultado é esperado nos providers e nas tools do `ServiceFinanceiro` (`obter_resumo_financeiro`, `consultar_lancamentos` e `explicar_categoria`), e o que deve ser testado em cada cenário.

---

## 1. Regra de leitura (comum a todos os CSVs)

Cada arquivo `<mci>.csv` (`001` a `007`) possui exatamente o contrato estrutural imutável do **DataFrame final de 13 colunas**:

```text
Descricao,Data,Categoria,Valor,Tipo,Instituicao,CodCategoria,CodGrupo,Ano,Mês,Dia,DiaSemana,MêsNome
```

O `FonteDadosExtrato` (`LeitorCSVLocal`) deve executar estes 5 passos:

1. Ler `<mci>.csv` com `encoding="utf-8-sig"`.
2. Validar se as **13 colunas obrigatórias** existem no cabeçalho (se não existirem, como em `007.csv`, retornar `estado = "indisponivel"` antes de qualquer conversão).
3. Aplicar `df["Descricao"] = df["Descricao"].fillna("")` (evita que descrição vazia vire `"nan"` e garante o fallback `"(sem descricao)"`).
4. Converter `Data` com `pd.to_datetime(df["Data"], errors="coerce")` e `Valor` com `pd.to_numeric(df["Valor"], errors="coerce")`, contabilizando descartes em `pulos` (`valor_zero`, `data_invalida`, `valor_invalido`).
5. Derivar a direção contábil pelo sinal de `Valor` (`< 0` = `"saida"`, `> 0` = `"entrada"`), resolver `CodGrupo` via [`grupos_gfp.json`](grupos_gfp.json) (`0` ou ausente -> `"Sem grupo"`) e preservar `Categoria` como `categoria_csv` ao lado do nome canônico de [`categorias_transacoes_estruturado.md`](categorias_transacoes_estruturado.md).

---

## 2. Visão rápida dos 7 arquivos

| Arquivo | Cenário | Linhas no CSV | Transações válidas | `estado_carga` esperado |
| --- | --- | --- | --- | --- |
| [`001.csv`](clientes_sinteticos/001.csv) | Extrato completo (maio a out/2026) | 22 | 22 | `processado` |
| [`002.csv`](clientes_sinteticos/002.csv) | Apenas 1 saída (consumo) | 1 | 1 | `processado` |
| [`003.csv`](clientes_sinteticos/003.csv) | Apenas 1 entrada (salário) | 1 | 1 | `processado` |
| [`004.csv`](clientes_sinteticos/004.csv) | Sem lançamentos (só cabeçalho) | 0 | 0 | `sem_lancamentos_recebidos` |
| [`005.csv`](clientes_sinteticos/005.csv) | Descartes parciais + bordas de qualidade | 8 | 5 (3 descartadas) | `inconclusivo` |
| [`006.csv`](clientes_sinteticos/006.csv) | 100% das linhas descartadas no pós-processamento | 2 | 0 (2 descartadas) | `inconclusivo` |
| [`007.csv`](clientes_sinteticos/007.csv) | Cabeçalho corrompido (colunas faltando) | 1 | `null` (erro estrutural) | `indisponivel` |

---

## 3. O que é esperado e o que testar em cada CSV

### `001.csv` — Cliente completo (caminho feliz)

- **O que tem no CSV:** 22 linhas válidas de `2026-05-01` a `2026-10-17`:
  - **6 entradas de salário:** `+1000.00` por mês de maio a outubro (`CodCategoria = 1, CodGrupo = 1`).
  - **1 entrada de resgate patrimonial:** `+100.00` em `2026-10-13` (`CodCategoria = 448978, CodGrupo = 13`).
  - **1 saída de aplicação patrimonial:** `-300.00` em `2026-10-12` (`CodCategoria = 448977, CodGrupo = 13`).
  - **1 saída de pagamento de fatura:** `-90.00` em `2026-10-14` (`FATURA TESTE`, `CodCategoria = 111, CodGrupo = 12`).
  - **13 saídas de consumo (totalizando R$ 985,00):**
    - `Aluguel e Condomínio` (`CodCategoria = 10, CodGrupo = 2 — Casa`): `-200.00` (`2026-05-15`, `ALUGUEL TESTE`) e `-200.00` (`2026-07-10`, `ALUGUEL TESTE - JULHO`) -> total **R$ 400,00**.
    - `Feira e Supermercado` (`CodCategoria = 32, CodGrupo = 6 — Alimentação`): `-100.00` (`2026-05-10`), `-120.00` (`2026-06-10`) e `-80.00` (`2026-08-10`) -> total **R$ 300,00**.
    - `Farmácias e Drogarias` (`CodCategoria = 30, CodGrupo = 5 — Saúde`): `-30.00` (`2026-06-15`, `Instituicao` vazia) e `-50.00` (`2026-09-10`) -> total **R$ 80,00**.
    - `Idiomas` (`CodCategoria = 17, CodGrupo = 3 — Educação`): `-70.00` (`2026-09-15`, `IDIOMAS TESTE`) -> total **R$ 70,00**.
    - `Eletricidade e Gás` (`CodCategoria = 7, CodGrupo = 2 — Casa`): `-60.00` (`2026-08-15`, `ENERGIA TESTE`) -> total **R$ 60,00**.
    - `Transporte Urbano e Apps` (`CodCategoria = 41, CodGrupo = 7 — Transporte`): `-40.00` (`2026-07-15`, `TRANSPORTE TESTE`) e `-5.00` (`2026-10-17`, `TRANSPORTE TESTE`) -> total **R$ 45,00**.
    - `Bares e Restaurantes` (`CodCategoria = 35, CodGrupo = 6 — Alimentação`): `-10.00` (`2026-10-10`, `PADARIA TESTE`) e `-20.00` (`2026-10-10`, `RESTAURANTE TESTE`) -> total **R$ 30,00**.
- **O que é esperado nas tools:**
  - **Metadados de carga:** `estado_carga = "processado"`, `quantidade_linhas_csv = 22`, `quantidade_linhas_validas = 22`, `primeira_data_observada = "2026-05-01"`, `ultima_data_observada = "2026-10-17"`, `descartes_por_motivo = {"valor_zero": 0, "data_invalida": 0, "valor_invalido": 0}`.
  - **`obter_resumo_financeiro` em outubro (`2026-10-01` a `2026-10-17`):**
    - `total_gastos_consumo = "35.00"` (`10.00` Padaria + `20.00` Restaurante + `5.00` Transporte)
    - `total_entradas = "1000.00"` (Salário)
    - `resultado_periodo = "965.00"`
    - Separados do consumo: `total_aplicacoes = "300.00"`, `total_resgates = "100.00"`, `total_fatura = "90.00"`
  - **`obter_resumo_financeiro` na janela completa (`2026-05-01` a `2026-10-17`):**
    - `total_gastos_consumo = "985.00"` (13 lançamentos; grupos: `Casa` R$ 460,00, `Alimentação` R$ 330,00, `Saúde` R$ 80,00, `Educação` R$ 70,00, `Transporte` R$ 45,00)
    - `total_entradas = "6000.00"` (6 salários)
    - `resultado_periodo = "5015.00"`
    - Separados do consumo: `total_aplicacoes = "300.00"`, `total_resgates = "100.00"`, `total_fatura = "90.00"`
  - **`consultar_lancamentos` em outubro (`2026-10-01` a `2026-10-17`, `natureza="saida"`, `escopo="consumo"` padrão):**
    - Retorna exatamente 3 lançamentos (`RESTAURANTE TESTE` `20.00` em `10/10`, `PADARIA TESTE` `10.00` em `10/10`, `TRANSPORTE TESTE` `5.00` em `17/10`), com `soma_saidas_filtradas = "35.00"`, reconciliando 100% com `total_gastos_consumo`.
- **O que testar:**
  - [ ] Soma de outubro e soma de 6 meses em `obter_resumo_financeiro` garantindo que Aplicação (`448977`), Resgate (`448978`) e Pagamento de Fatura (`111`) **não** entram em `total_gastos_consumo` nem em `total_entradas`.
  - [ ] Reconciliação entre `obter_resumo_financeiro` e `consultar_lancamentos(escopo="consumo", natureza="saida")`.
  - [ ] Reconciliação de `CodCategoria = 35` aceitando busca tanto por `"Bar"` (catálogo Markdown) quanto por `"Bares e Restaurantes"` (CSV).

---

### `002.csv` — Apenas 1 saída (consumo)

- **O que tem no CSV:** 1 linha de débito em `2026-10-10` (`PADARIA TESTE`, `Valor = -10.00`, `CodCategoria = 35`, `CodGrupo = 6`).
- **O que é esperado:**
  - **Metadados de carga:** `estado_carga = "processado"`, `1` linha lida e `1` válida, primeira e última data = `"2026-10-10"`.
  - **`obter_resumo_financeiro`:** `total_gastos_consumo = 10.00`, `total_entradas_consideradas = 0.00` (zero legítimo), `resultado_periodo = -10.00`.
- **O que testar:**
  - [ ] Confirmar que `total_entradas_consideradas = 0.00` é tratado como zero legítimo (e não como erro ou ausência de extrato).

---

### `003.csv` — Apenas 1 entrada (salário)

- **O que tem no CSV:** 1 linha de crédito em `2026-10-01` (`SALARIO TESTE - EMPRESA TESTE`, `Valor = 1000.00`, `CodCategoria = 1`, `CodGrupo = 1`).
- **O que é esperado:**
  - **Metadados de carga:** `estado_carga = "processado"`, `1` linha lida e `1` válida, primeira e última data = `"2026-10-01"`.
  - **`obter_resumo_financeiro`:** `total_gastos_consumo = 0.00` (zero legítimo), `total_entradas_consideradas = 1000.00`, `resultado_periodo = 1000.00`.
- **O que testar:**
  - [ ] Distinguir **gasto zero legítimo** (`003.csv`, onde houve carga válida e não houve saídas) de **ausência de lançamentos** (`004.csv`).
  - [ ] Confirmar que consultar outros dias dentro da janela de referência (`2026-05-01` a `2026-10-17`) continua válido mesmo havendo apenas 1 transação em `2026-10-01`.

---

### `004.csv` — Sem lançamentos (extrato vazio)

- **O que tem no CSV:** apenas o cabeçalho das 13 colunas (`0` linhas de dados).
- **O que é esperado:**
  - **Metadados de carga:** `estado_carga = "sem_lancamentos_recebidos"`, `quantidade_linhas_csv = 0`, `quantidade_linhas_validas = 0`, datas observadas = `null`.
  - **`obter_resumo_financeiro` e `consultar_lancamentos`:** **não** podem responder "Você gastou R$ 0,00"; devem sinalizar ausência de lançamentos registrados para o cliente.
- **O que testar:**
  - [ ] Garantir que o agente informa ausência de lançamentos e **nunca** afirma gasto zero.

---

### `005.csv` — Descartes parciais e casos de borda de qualidade

- **O que tem no CSV:** 8 linhas combinando 3 linhas inválidas e 5 linhas válidas de borda:
  1. `Valor = 0.00` (`2026-10-10`) -> descartada em `pulos["valor_zero"]`.
  2. `Data = 2026-13-40` (`Valor = -15.00`) -> vira `NaT` e é descartada em `pulos["data_invalida"]`.
  3. `Valor = abc` (`2026-10-11`) -> descartada em `pulos["valor_invalido"]`.
  4. `CodCategoria = 9999` e `CodGrupo = 0` (`2026-10-12`, `-40.00`) -> válida; `cod_cat_desconhecido` e `grupo_display = "Sem grupo"`.
  5. `Categoria = "Nubank"` (`2026-10-13`, `-25.00`) -> válida; contabiliza em `rotulos_suspeitos`.
  6. `Descricao = ""`, `Categoria = ""`, `Instituicao = ""` (`2026-10-14`, `-30.00`) -> válida; vira `descricao = "(sem descricao)"`, `instituicao = None` e contabiliza em `rotulos_sem_texto`.
  7. e 8. Duas linhas idênticas (`2026-10-15`, `DUPLICADA TESTE`, `-50.00`) -> ambas válidas; preservadas como lançamentos distintos.
- **O que é esperado:**
  - **Metadados de carga:** `estado_carga = "inconclusivo"` (pois houve descarte de 3 linhas na carga), `quantidade_linhas_csv = 8`, `quantidade_linhas_validas = 5`, datas observadas `"2026-10-12"` a `"2026-10-15"`, reportando as anomalias de descarte e de qualidade (`valor_zero`, `data_invalida`, `valor_invalido`, `cod_cat_desconhecido`, `rotulos_suspeitos`, `rotulos_sem_texto`).
  - **Totais sobre as 5 linhas válidas:** `total_gastos_consumo = 195.00`, exigindo ressalva explícita na resposta de que 3 registros inconsistentes foram ignorados.
- **O que testar:**
  - [ ] Contabilização exata dos 3 motivos de descarte (`valor_zero`, `data_invalida`, `valor_invalido`).
  - [ ] Fallback `"(sem descricao)"` (garantindo que não virou `"nan"`).
  - [ ] Agrupamento de `CodGrupo = 0` em `"Sem grupo"`.
  - [ ] Ressalva explícita ao usuário de que houve linhas descartadas (`inconclusivo`), sem esconder a perda parcial.

---

### `006.csv` — Lote 100% inválido no pós-processamento

- **O que tem no CSV:** cabeçalho válido de 13 colunas e 2 linhas de dados, ambas inválidas (`Data = 2026-13-40` com `-10.00`, e `Data = 2026-10-10` com `Valor = 0.00`).
- **O que é esperado:**
  - **Metadados de carga:** `estado_carga = "inconclusivo"`, `quantidade_linhas_csv = 2`, `quantidade_linhas_validas = 0`, datas observadas = `null`, `anomalias = ["data_invalida", "valor_zero"]`.
  - **`obter_resumo_financeiro` e `consultar_lancamentos`:** falha controlada de pós-processamento (nenhum dado válido restou após o processamento), distinta de extrato vazio (`004.csv`) e nunca tratada como gasto zero.
- **O que testar:**
  - [ ] Garantir que `006.csv` retorna `inconclusivo` (linhas recebidas e 100% descartadas) e **não** `sem_lancamentos_recebidos` (`004.csv`) nem gasto zero.

---

### `007.csv` — Erro estrutural (schema de colunas quebrado)

- **O que tem no CSV:** cabeçalho inválido com apenas 3 colunas (`coluna_invalida_a,coluna_invalida_b,coluna_invalida_c`), sem as 13 colunas obrigatórias do DataFrame final.
- **O que é esperado:**
  - **Metadados de carga:** falha imediata na validação estrutural das 13 colunas (`estado_carga = "indisponivel"`, `quantidade_linhas_validas = null`, `anomalias = ["schema_invalido"]`).
- **O que testar:**
  - [ ] Garantir que o erro estrutural resulta em `indisponivel` e que o agente informa indisponibilidade técnica da consulta, sem inventar valores ou dizer que não há gastos.
