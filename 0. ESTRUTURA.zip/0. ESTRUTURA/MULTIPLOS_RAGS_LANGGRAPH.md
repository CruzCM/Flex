# Múltiplos RAGs no LangGraph

## Objetivo

Este documento descreve uma arquitetura de LangGraph na qual um único agente
responde a dois tipos de assunto:

- dúvidas sobre funcionalidades e uso do aplicativo;
- dúvidas sobre educação financeira.

Nos dois casos, a resposta deve obrigatoriamente usar recuperação de contexto
por RAG. O agente pode decidir qual base documental consultar, mas não pode
decidir responder sem consultar uma base.

## Princípio da arquitetura

O roteamento e a recuperação devem fazer parte da topologia do grafo. O RAG não
deve ser apenas uma ferramenta opcional disponibilizada ao modelo, porque nesse
formato o modelo pode responder sem chamá-la.

O fluxo recomendado é:

```mermaid
flowchart TD
    A[Mensagem do usuário] --> B[Classificar assunto]
    B -->|Aplicativo| C[RAG do aplicativo]
    B -->|Educação financeira| D[RAG de educação financeira]
    B -->|Ambos ou dúvida| E[Consultar os dois RAGs]
    C --> F[Validar contexto]
    D --> F
    E --> F
    F -->|Contexto encontrado| G[Gerar resposta fundamentada]
    F -->|Sem contexto| H[Resposta controlada: informação não encontrada]
    G --> I[Fim]
    H --> I
```

Essa estrutura fornece três garantias:

1. toda mensagem aceita pelo agente passa por uma classificação;
2. toda classificação leva a pelo menos uma consulta RAG;
3. a geração da resposta acontece somente depois da recuperação.

## Separação das bases documentais

Cada assunto deve ter um índice próprio:

- **Aplicativo:** telas, funcionalidades, cadastro, navegação e solução de
  problemas. Exemplo: `indice-documentacao-app`.
- **Educação financeira:** orçamento, dívidas, reserva, planejamento e
  investimentos. Exemplo: `indice-educacao-financeira`.

Uma configuração possível é:

```yaml
rag:
  enabled: true
  total_context: 5
  indexes:
    app: "indice-documentacao-app"
    educacao_financeira: "indice-educacao-financeira"
```

Os identificadores dos índices devem vir da configuração da aplicação. O texto
produzido pelo LLM nunca deve ser usado diretamente como `index_id`. O roteador
escolhe apenas entre nomes de domínio previamente permitidos.

## Estado do LangGraph

O estado precisa armazenar a classificação, os contextos recuperados e a origem
de cada contexto:

```python
from typing import Literal, TypedDict

from langchain_core.messages import BaseMessage


Domain = Literal["app", "educacao_financeira", "ambos"]


class RetrievedContext(TypedDict):
    domain: Literal["app", "educacao_financeira"]
    text: str


class AgentState(TypedDict):
    messages: list[BaseMessage]
    query: str
    domain: Domain
    contexts: list[RetrievedContext]
```

Manter o domínio junto de cada trecho evita misturar as fontes silenciosamente
e facilita observabilidade, auditoria e avaliação da qualidade da recuperação.

## Classificação do assunto

O classificador deve retornar uma saída estruturada com um conjunto fechado de
valores:

```python
from enum import Enum

from pydantic import BaseModel, Field


class Domain(str, Enum):
    APP = "app"
    EDUCACAO_FINANCEIRA = "educacao_financeira"
    AMBOS = "ambos"


class RouteDecision(BaseModel):
    domain: Domain = Field(
        description="Base documental necessária para responder à pergunta."
    )
```

Exemplos de classificação:

| Pergunta | Resultado |
| --- | --- |
| Como cadastrar uma meta no aplicativo? | `app` |
| Quanto devo guardar para uma reserva de emergência? | `educacao_financeira` |
| Como criar uma reserva e acompanhar sua evolução pelo app? | `ambos` |

O prompt do classificador deve deixar claro que ele não responde à pergunta. A
única responsabilidade desse nó é selecionar o domínio.

Quando a mensagem precisar de conhecimento das duas bases, ou quando a
classificação não for suficientemente segura, a decisão recomendada é `ambos`.
Isso preserva a obrigatoriedade do RAG sem bloquear indevidamente o usuário.

## Recuperação por domínio

Uma única função pode atender os dois RAGs, desde que receba um domínio validado
e faça internamente o mapeamento para o índice permitido:

```python
INDEX_BY_DOMAIN = {
    "app": settings.rag.app_index_id,
    "educacao_financeira": settings.rag.educacao_financeira_index_id,
}


async def retrieve_from_domain(
    query: str,
    domain: str,
) -> list[RetrievedContext]:
    if domain not in INDEX_BY_DOMAIN:
        raise ValueError(f"Domínio RAG inválido: {domain}")

    passages = await call_gateway(
        query=query,
        index_id=INDEX_BY_DOMAIN[domain],
    )

    return [
        {"domain": domain, "text": passage}
        for passage in passages
    ]
```

Os nós de recuperação ficam simples:

```python
async def retrieve_app(state: AgentState) -> dict:
    contexts = await retrieve_from_domain(state["query"], "app")
    return {"contexts": contexts}


async def retrieve_financial_education(state: AgentState) -> dict:
    contexts = await retrieve_from_domain(
        state["query"],
        "educacao_financeira",
    )
    return {"contexts": contexts}
```

## Consulta aos dois RAGs

Perguntas multidomínio devem consultar os índices de forma concorrente:

```python
import asyncio


async def retrieve_both(state: AgentState) -> dict:
    app_contexts, financial_contexts = await asyncio.gather(
        retrieve_from_domain(state["query"], "app"),
        retrieve_from_domain(state["query"], "educacao_financeira"),
    )
    return {"contexts": app_contexts + financial_contexts}
```

Também é possível representar esse caso com `Send` e fan-out do LangGraph. Um
nó único com `asyncio.gather` costuma ser suficiente quando há somente duas
bases e ambas usam a mesma infraestrutura.

## Montagem do grafo

O roteador condicional escolhe o nó de recuperação, e todos os caminhos voltam
para a validação de contexto:

```python
from langgraph.graph import END, START, StateGraph


def select_retriever(state: AgentState) -> str:
    routes = {
        "app": "retrieve_app",
        "educacao_financeira": "retrieve_financial_education",
        "ambos": "retrieve_both",
    }
    return routes[state["domain"]]


builder = StateGraph(AgentState)

builder.add_node("classify_domain", classify_domain)
builder.add_node("retrieve_app", retrieve_app)
builder.add_node(
    "retrieve_financial_education",
    retrieve_financial_education,
)
builder.add_node("retrieve_both", retrieve_both)
builder.add_node("validate_context", validate_context)
builder.add_node("generate_answer", generate_answer)
builder.add_node("no_context", no_context_response)

builder.add_edge(START, "classify_domain")
builder.add_conditional_edges(
    "classify_domain",
    select_retriever,
    {
        "retrieve_app": "retrieve_app",
        "retrieve_financial_education": "retrieve_financial_education",
        "retrieve_both": "retrieve_both",
    },
)

for node in (
    "retrieve_app",
    "retrieve_financial_education",
    "retrieve_both",
):
    builder.add_edge(node, "validate_context")

builder.add_conditional_edges(
    "validate_context",
    lambda state: "answer" if state["contexts"] else "no_context",
    {
        "answer": "generate_answer",
        "no_context": "no_context",
    },
)

builder.add_edge("generate_answer", END)
builder.add_edge("no_context", END)

graph = builder.compile()
```

Neste desenho, não existe uma aresta direta entre a classificação e a geração.
Portanto, o modelo gerador não consegue ignorar a recuperação.

## Geração fundamentada

O nó gerador deve receber somente a pergunta e os trechos recuperados. Suas
instruções devem exigir que a resposta:

- seja baseada exclusivamente no contexto recuperado;
- não invente funcionalidades do aplicativo;
- diferencie orientação educacional de recomendação financeira individual;
- reconheça quando os documentos não contêm informação suficiente;
- preserve a origem dos trechos para citações ou auditoria.

Exemplo de montagem do contexto:

```python
def format_contexts(contexts: list[RetrievedContext]) -> str:
    return "\n\n".join(
        f"[fonte={item['domain']}]\n{item['text']}"
        for item in contexts
    )
```

## Ausência de contexto e indisponibilidade

Uma lista vazia não deve liberar uma resposta baseada no conhecimento interno
do modelo. Ela deve produzir uma saída controlada, como:

> Não encontrei essa informação nas bases disponíveis. Tente reformular a
> pergunta ou fornecer mais detalhes.

É útil distinguir dois casos:

- **sem contexto:** a consulta funcionou, mas não retornou trechos relevantes;
- **RAG indisponível:** ocorreu timeout, erro de autenticação ou falha no serviço.

Essa distinção melhora a experiência do usuário e permite métricas operacionais
mais precisas.

## Alternativa: um índice com metadados

Os documentos também podem ficar em um único índice com um metadado como
`domain=app` ou `domain=educacao_financeira`. Nesse caso, o roteador seleciona o
filtro de busca em vez do `index_id`.

Essa alternativa só é adequada quando o serviço de recuperação aceita filtros
de metadados e aplica esses filtros de forma confiável. Com o contrato atual de
consulta por `index_id`, dois índices separados oferecem isolamento mais claro.

## Observabilidade recomendada

Cada execução deve registrar, sem expor conteúdo sensível:

- domínio escolhido;
- índices consultados;
- duração de cada recuperação;
- quantidade de trechos retornados por domínio;
- ocorrência de timeout ou erro;
- caminho percorrido no grafo;
- resposta normal, ausência de contexto ou indisponibilidade.

Também é recomendável avaliar separadamente precisão do roteamento, relevância
dos trechos recuperados e fidelidade da resposta ao contexto.

## Resumo das decisões

1. Use um único agente e dois índices documentais especializados.
2. Classifique a pergunta antes da recuperação.
3. Permita somente os domínios `app`, `educacao_financeira` e `ambos`.
4. Faça a recuperação como nó obrigatório do LangGraph.
5. Consulte os dois índices para perguntas multidomínio ou ambíguas.
6. Não gere resposta normal quando nenhum contexto for recuperado.
7. Preserve o domínio de origem em cada trecho para auditoria e citações.
