# Plano de evolução do MCP financeiro e do Agente Minhas Finanças

<!-- markdownlint-disable MD013 -->

## Objetivo e ponto de partida

> [!IMPORTANT]
> **Fonte Única da Verdade Universal:** A especificação oficial, completa e autoritativa do projeto encontra-se exclusivamente em **[`Documentação-Final-Agent-MF.md`](Documentação-Final-Agent-MF.md)**. Em qualquer dúvida ou divergência, prevalece exclusivamente [`Documentação-Final-Agent-MF.md`](Documentação-Final-Agent-MF.md). **Estruturas imutáveis do sistema:** A estrutura e o conteúdo dos arquivos `.csv` (13 colunas), `.json` ([`data/knowledge/grupos_gfp.json`](data/knowledge/grupos_gfp.json)) e `.md` ([`categorias_transacoes_estruturado.md`](categorias_transacoes_estruturado.md) / [`data/knowledge/descricoes_categorias.md`](data/knowledge/descricoes_categorias.md)) vêm diretamente dos sistemas corporativos e **não podem ser alterados**. Divergências de rótulo entre artefatos (como `CodCategoria = 35` intitulado `"Bar"` no Markdown e `"Bares e Restaurantes"` no CSV) são reconciliadas em código dentro dos providers pelo código numérico canônico e por dicionário de sinônimos.

Ler este plano junto com a **[Documentação Final do Agente Minhas Finanças (`Documentação-Final-Agent-MF.md`)](Documentação-Final-Agent-MF.md)** — que consolida os contratos técnicos das 5 ferramentas MCP, dos dois providers de dados, da memória conversacional, dos 7 cenários sintéticos e da avaliação automatizada. Este plano resume a sequência de entrega em quatro etapas incrementais.

A construção do `ServiceFinanceiro` no `iaa-mcp-mf` é **nova**, aproveitando exclusivamente as regras de domínio e os catálogos do legado (`data/knowledge/grupos_gfp.json` e `categorias_transacoes_estruturado.md`). Não empacotamos o método monolítico legado de 19 parâmetros nem expomos estatísticas avançadas, indicadores compostos ou detector de duplicidades neste MVP.

---

## Alinhamento entre os desenvolvedores

| Responsável | Entregas principais no MVP |
| --- | --- |
| **MCP (`iaa-mcp-mf`)** | Implementar os dois providers desacoplados (`FonteDadosExtrato` e `FonteCategorias`), construir o `ServiceFinanceiro` limpo com 3 tools (`obter_resumo_financeiro`, `consultar_lancamentos`, `explicar_categoria`) e manter o `ServiceRAG` com 2 tools (`consultar_educacao_financeira`, `consultar_faq_minhas_financas`). |
| **Agente (`iaa-agente-mf`)** | Receber `message`, `session_id`, `mci` e `diagnostico: bool = False` no `/chat`, validar o vínculo imutável `session_id -> mci` antes de gravar no grafo (`InMemorySaver`) sob lock por sessão (coordenando expiração TTL com `adelete_thread`), injetar `mci` apenas nas 2 tools financeiras pessoais e persistir o `EvaluationRecord` a cada turno. |
| **Ambos** | Testar os 7 cenários sintéticos (`001.csv` a `007.csv`), validar a reconciliação numérica entre `obter_resumo_financeiro` e `consultar_lancamentos(escopo="consumo")` e executar as jornadas conversacionais centradas em dúvidas humanas reais. |

---

## Fronteiras do fluxo e superfície de 5 ferramentas

```text
POST /chat(message, session_id, mci, diagnostico=False)
  -> Valida vínculo imutável session_id -> mci (rejeita troca de mci antes do grafo)
  -> Adquire lock assíncrono por session_id e recupera histórico no InMemorySaver
  -> Agente (LangGraph) seleciona apenas as tools necessárias para a dúvida do cliente:
     1. obter_resumo_financeiro          [ServiceFinanceiro | injeta mci | FonteDadosExtrato]
     2. consultar_lancamentos            [ServiceFinanceiro | injeta mci | FonteDadosExtrato]
     3. explicar_categoria               [ServiceFinanceiro | sem mci    | FonteCategorias]
     4. consultar_educacao_financeira    [ServiceRAG        | sem mci    | Base RAG]
     5. consultar_faq_minhas_financas    [ServiceRAG        | sem mci    | Base RAG]
  -> Persiste EvaluationRecord (JSONL local) e retorna resposta (com ou sem bloco diagnostico)
```

---

## Schema imutável do CSV (13 colunas) e regras do `FonteDadosExtrato`

Os arquivos [`001.csv`](clientes_sinteticos/001.csv) a [`007.csv`](clientes_sinteticos/007.csv) em [`clientes_sinteticos/`](clientes_sinteticos/) representam diretamente o DataFrame final de 13 colunas:

```text
Descricao,Data,Categoria,Valor,Tipo,Instituicao,CodCategoria,CodGrupo,Ano,Mês,Dia,DiaSemana,MêsNome
```

Na implementação atual do `FonteDadosExtrato` (`LeitorCSVLocal`):

1. Ler `<mci>.csv` com `encoding="utf-8-sig"`.
2. Validar a presença exata das **13 colunas obrigatórias**; se o cabeçalho estiver corrompido (`007.csv`) ou o arquivo não existir, retornar `estado = "indisponivel"` sem prosseguir.
3. Aplicar `df["Descricao"] = df["Descricao"].fillna("")` para que descrições vazias (`005.csv`) recebam o fallback `"(sem descricao)"` e nunca a string `"nan"`.
4. Converter `Data` via `pd.to_datetime(df["Data"], errors="coerce")` e `Valor` via `pd.to_numeric(df["Valor"], errors="coerce")`, contabilizando descartes em `pulos` (`valor_zero`, `data_invalida`, `valor_invalido`).
5. Derivar a direção contábil pelo sinal de `Valor` (`< 0` = `"saida"`, `> 0` = `"entrada"`), resolver `CodGrupo` via [`data/knowledge/grupos_gfp.json`](data/knowledge/grupos_gfp.json) (`0` ou ausente -> `"Sem grupo"`) e preservar `Categoria` como `categoria_csv` ao lado do nome canônico do catálogo.

### Estados de carga (`estado_carga`)

| Estado | Significado operacional | Cenários CSV |
| --- | --- | --- |
| `processado` | Cabeçalho válido de 13 colunas, `>= 1` linha válida e `0` linhas descartadas. | `001.csv`, `002.csv`, `003.csv` |
| `sem_lancamentos_recebidos` | Cabeçalho válido de 13 colunas, `0` linhas lidas (`df.empty == True`). Não equivale a gasto zero. | `004.csv` |
| `inconclusivo` | Houve descarte parcial de linhas inválidas (`005.csv`: 8 lidas, 3 descartadas, 5 válidas) ou descarte de 100% das linhas lidas no pós-processamento (`006.csv`: 2 lidas, 2 descartadas, 0 válidas). | `005.csv`, `006.csv` |
| `indisponivel` | Arquivo ausente ou cabeçalho sem as 13 colunas obrigatórias. | `007.csv` |
| `entrada_invalida` | `mci` vazio/malformado ou argumentos de filtro/período inválidos (`data_inicio > data_fim`). | Validação de entrada |

---

## Sequência de implementação em 4 etapas

### Etapa 1 — Providers de dados + `obter_resumo_financeiro`

1. Implementar `FonteCategorias` lendo [`data/knowledge/grupos_gfp.json`](data/knowledge/grupos_gfp.json) e [`categorias_transacoes_estruturado.md`](categorias_transacoes_estruturado.md) em memória, indexando por código numérico canônico (`CodCategoria`, `CodGrupo`) e sinônimos normalizados (`"Bar"` <-> `"Bares e Restaurantes"` para `CodCategoria = 35`).
2. Implementar `FonteDadosExtrato` (`LeitorCSVLocal`) cumprindo os 5 estados de carga e a janela nominal de referência (`2026-05-01` a `2026-10-17`).
3. Publicar `obter_resumo_financeiro(data_inicio, data_fim, top_n_categorias)` aplicando precedência estrita `CodCategoria > CodGrupo`:
   - **Consumo:** saídas (`Valor < 0`) com `CodCategoria not in (111, 448977, 448978)` (e `CodGrupo not in (12, 13)` quando `CodCategoria` não pertencer ao catálogo).
   - **Entradas consideradas:** créditos (`Valor > 0`) com `CodCategoria not in (111, 448977, 448978)` (e `CodGrupo not in (12, 13)` quando `CodCategoria` não pertencer ao catálogo).
   - **Movimentações patrimoniais e cartão separadas (`escopo="patrimonial"`):** Aplicações (`448977`), Resgates (`448978`) e Pagamento de Fatura (`111`), nunca somados em `total_gastos_consumo` ou `total_entradas`.
4. **Critério de aceite da Etapa 1:**
   - Em `001.csv` para outubro (`2026-10-01` a `2026-10-17`), retornar `total_gastos_consumo = 35.00`, `total_entradas_consideradas = 1000.00`, `resultado_periodo = 965.00`, `total_aplicacoes = 300.00`, `total_resgates = 100.00` e `total_pagamento_fatura = 90.00`.
   - Em `002.csv` e `003.csv`, distinguir zero legítimo de entradas/gastos da ausência de dados (`004.csv`), do descarte parcial/total (`005.csv`, `006.csv`) e da falha estrutural (`007.csv`).

### Etapa 2 — Detalhamento reconciliado (`consultar_lancamentos`) e catálogo (`explicar_categoria`)

1. Publicar `consultar_lancamentos` com `escopo="consumo" | "patrimonial" | "todos"` (**padrão `"consumo"`**).
   - Garantir que `escopo="consumo"` + `natureza="saida"` filtre exatamente o mesmo universo de transações que compõe `total_gastos_consumo` em `obter_resumo_financeiro`, impedindo que Aplicação (`R$ 300,00`) e Pagamento de Fatura (`R$ 90,00`) contradigam o resumo de consumo (`R$ 35,00`).
   - Aceitar listas em `categorias`, `grupos` e `termos_descricao`, filtro por `instituicao` e ordenação por `valor_desc`, `valor_asc`, `data_desc`, `data_asc`, retornando `total_encontrado`, `soma_valores_encontrados`, `soma_saidas_encontradas`, `soma_entradas_encontradas` e `lancamentos_exibidos`.
2. Publicar `explicar_categoria(termo, tipo="auto" | "categoria" | "grupo")` sem `mci`, resolvendo a colisão dos códigos `1` a `14` entre grupos e categorias e informando ambos os nomes (`nome_canonico_catalogo` e `rotulo_extrato_csv`) quando houver divergência entre `.md` e `.csv`.
3. **Critério de aceite da Etapa 2:**
   - Consultar os maiores gastos de outubro em `001.csv` com `escopo="consumo"` retorna apenas `RESTAURANTE TESTE` (`20.00`), `PADARIA TESTE` (`10.00`) e `TRANSPORTE TESTE` (`5.00`), somando `35.00`.
   - Consultar `explicar_categoria(termo="35")` retorna a definição de `"Bar"` do catálogo Markdown junto com o rótulo `"Bares e Restaurantes"` usado no CSV.

### Etapa 3 — Integração no Agente (`ServiceRAG`, `InMemorySaver`, vínculo `mci` e `diagnostico`)

1. Conectar no grafo LangGraph do `iaa-agente-mf` as 3 tools do `ServiceFinanceiro` e as 2 tools do `ServiceRAG` (`consultar_educacao_financeira` e `consultar_faq_minhas_financas`).
2. Configurar `InMemorySaver` (execução em processo único / `workers=1` no MVP), verificação do vínculo `session_table[session_id] == mci` **antes** de gravar mensagens no estado, e `asyncio.Lock()` por `session_id`.
3. Injetar `mci` via closure/wrapper exclusivamente em `obter_resumo_financeiro` e `consultar_lancamentos`.
4. Implementar o parâmetro opcional `diagnostico: bool = False` no `POST /chat` para retornar metadados auditáveis da execução quando solicitado.

### Etapa 4 — Coleta do `EvaluationRecord` e avaliação automatizada (DeepEval + Ragas + Fidelidade Numérica)

1. Persistir um `EvaluationRecord` JSONL por turno com `execution_id`, `session_id`, `mci`, `user_input`, `actual_output`, `tools_called` (com `input_parameters` sem `mci` e `output` estruturado), `retrieval_context` (textos das tools documentais) e `financial_ground_truth` (JSON determinístico das tools financeiras).
2. Executar em pipeline offline os dois adaptadores de avaliação:
   - **DeepEval:** `LLMTestCase` com `ToolCall(name, input_parameters, output)` para `ToolCorrectnessMetric` e `AnswerRelevancyMetric`.
   - **Ragas:** `SingleTurnSample(user_input, response, retrieved_contexts)` para `Faithfulness` e `ResponseRelevancy` em turnos documentais.
   - **Validador determinístico de fidelidade numérica:** confronto direto entre números da resposta final e `financial_ground_truth` + estado de carga.
3. Validar as 4 jornadas conversacionais e os 5 comportamentos humanos documentados no [guia único do desenvolvedor](guia-unico-agente-minhas-financas-versao-desenvolvedor.md).
