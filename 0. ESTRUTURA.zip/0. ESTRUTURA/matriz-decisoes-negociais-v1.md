# Matriz de decisões negociais — Agente Minhas Finanças V1

<!-- markdownlint-disable MD013 -->

Status: proposta consolidada para deliberação negocial. Não é ata de aprovação.

## Critério de leitura

O escopo em estudo contém nove capacidades. A conversa confirma a manutenção
do histórico de seis meses nesta etapa. A distribuição de capacidades na V1
e as regras novas abaixo constituem uma recomendação; a documentação disponível
não comprova sua aprovação pelo negócio.

“Herdada” significa comportamento identificado no produto anterior. Não equivale
a homologação para a V1. “Manter” e “rever” indicam o encaminhamento recomendado,
e não ratificação ou rejeição já realizada.

Responsáveis abaixo são papéis propostos: **Produto MF** é o responsável negocial
do Minhas Finanças; **Dados MF** é o responsável pela fonte de transações;
**Responsável por análises** é quem valida as regras estatísticas e os indicadores;
**Gestor do catálogo** é quem mantém categorias e grupos. Nomes e alçadas ainda
precisam ser indicados.

## Escopo recomendado para a V1 — questão 1

| Capacidade | Situação recomendada na V1 | Condição para disponibilização | Evolução futura |
| --- | --- | --- | --- |
| Histórico financeiro | Incluir como suporte, com informação de cobertura ao cliente | Escopo, atualidade e completude dos dados confirmados | Ampliação do histórico e de fontes |
| Panorama financeiro | Incluir | Base de gasto e receita reconciliada com a fonte | Visões adicionais aprovadas pelo produto |
| Consulta de lançamentos | Incluir | Critérios de busca e natureza dos movimentos confiáveis | Busca por instituição e consolidação de estabelecimentos |
| Composição e evolução | Incluir com comparação entre períodos completos | Cobertura dos meses identificável | Comparação até o mesmo dia e ajuste de sazonalidade |
| Lançamentos atípicos | Incluir sob demanda | Critério estatístico e linguagem ratificados | Alertas proativos e tratamento de sazonalidade |
| Estatísticas dos gastos | Incluir sob demanda | Universo de gastos definido | Gasto mensal típico e análises adicionais |
| Possíveis repetições | Incluir sob demanda | Não confundir registro duplicado da fonte com movimentação distinta | Repetições aproximadas e acompanhamento de resolução |
| Indicadores financeiros | Incluir com escopo restrito | Períodos e denominadores compatíveis; renda válida quando necessária | Renda inferida, avaliação de saúde financeira e metas |
| Explicação de categorias | Incluir | Catálogo vigente e responsável identificados | Sugestões de recategorização, caso aprovadas |

Não há evidência suficiente para declarar qualquer uma delas “efetivamente
disponível na V1” apenas com base neste estudo. A tabela estabelece o escopo
recomendado e as condições de aceite. Se uma condição não for satisfeita, o
resultado dependente dela deve permanecer indisponível, com explicação ao
cliente; ausência de dado não deve ser apresentada como valor zero.

## 1. Histórico financeiro — questões 2, 3, 4, 5, 8 e 9

| Item | Definição e encaminhamento |
| --- | --- |
| Finalidade e significado | Sustentar as análises e informar, quando solicitado, período consultado, fontes cobertas, quantidade de lançamentos e data de atualização conhecida. Quantidade de lançamentos não significa quantidade de compras. |
| Q2 — Relação com o usuário | **Recomendação:** capacidade de suporte que também responde “de que período são meus dados?” e comunica falta ou incompletude de informação. Não precisa apresentar espontaneamente todos os metadados. |
| Q3 — Período | **Confirmado na conversa:** manter seis meses. **Herdado e recomendado para preservação:** mês corrente mais cinco meses anteriores, desde o primeiro dia do mês mais antigo. Não substituir por 180 dias nesta etapa. A cobertura e a atualização reais devem acompanhar o resultado. |
| Q4 — Contas, cartões e instituições | **Pendente:** inventário da cobertura do novo serviço. Incluir somente fontes autorizadas e efetivamente fornecidas. Não afirmar cobertura de todas as contas, cartões ou instituições sem essa confirmação. |
| Q5 — Situação dos lançamentos | **Recomendação:** totais realizados usam movimentos efetivados; pendentes ficam fora. Cancelamentos, correções e estornos seguem a situação financeira validada pela fonte, sem contar versões substituídas duas vezes. A competência do estorno e seu vínculo com a compra ainda exigem decisão. Compras parceladas entram somente conforme os eventos de consumo reconhecidos pela fonte; não somar compra integral e parcelas nem antecipar parcelas futuras. |
| Q8 — Competência | **Herdado:** data do evento fornecida no extrato. **Pendente:** confirmar se significa compra, lançamento ou liquidação para cada tipo de movimento, especialmente cartão e parcelas. Preservar essa data só é suficiente depois de validar seu significado. |
| Q9 — Valores e moedas | **Recomendação:** usar valor e natureza validados pela fonte; valor negativo sozinho não prova estorno. V1 com totais em reais apenas quando o valor em reais for fornecido. Não somar moedas distintas nem estimar câmbio. Apresentar dinheiro com duas casas e preservar precisão no cálculo. Divergências de valor, data ou natureza devem gerar indicação de incompletude, nunca correção presumida. Regras de desempate de arredondamento e reconciliação precisam ser acordadas. |
| Exemplo esperado | “De que período são meus dados?” → “A consulta cobre maio a outubro; outubro está parcial. A fonte informa atualização até o dia 9”, somente se a fonte confirmar essa informação. A última transação encontrada não comprova atualização até aquela data. |
| Herança | Manter seis meses de calendário e a distinção entre período consultado e datas dos lançamentos encontrados. Rever o descarte de registros inválidos sem comunicar impacto sobre a análise. |
| Pendências e responsável | Q4, Q5, Q8 e Q9: **Dados MF** confirma fatos da fonte; **Produto MF** aprova o tratamento financeiro e a comunicação. Cobertura do cartão é condição para interpretar corretamente o panorama. |

## 2. Panorama financeiro — questões 6, 7 e 10

| Item | Definição e encaminhamento |
| --- | --- |
| Finalidade | Mostrar receitas, gastos, resultado e composição por grupo no período informado. |
| Q10 — Significado financeiro | **Proposta de vocabulário:** gasto é débito reconhecido como despesa no universo analisado; receita é crédito reconhecido como rendimento ou receita nesse mesmo universo; resultado é receita menos gasto. Saldo é posição efetiva da conta informada pela fonte e não pode ser deduzido dessa diferença. Poupança efetiva ou patrimônio acumulado não são comprovados pelo resultado. Nem toda saída é gasto e nem toda entrada é receita. |
| Q6 — Transferências próprias | **Herdado:** podem permanecer nos totais. **Recomendação de revisão:** excluir de gasto e receita quando a titularidade própria estiver comprovada pela fonte; preservar na consulta de movimentações. Não inferir titularidade pelo nome ou descrição. Tratamento das transferências de titularidade desconhecida permanece pendente. |
| Q6 — Saques | **Herdado:** entram nas saídas consideradas gasto. **Recomendação de revisão:** apresentar como retirada de dinheiro, separada do consumo identificado. O uso do dinheiro em espécie é desconhecido. O efeito dessa mudança na conciliação com o produto anterior exige aprovação. |
| Q7 — Aplicações, resgates e fatura | **Herdado; recomendar manutenção:** excluir do gasto e da receita e apresentar totais próprios. Perguntar por uma aplicação não transforma a aplicação em gasto. A exclusão da fatura pressupõe que as compras estejam contempladas; se não estiverem, informar consumo incompleto, sem chamar pagamento da fatura de consumo integral. A existência dessa cobertura deve ser comprovada. |
| Inclusões e exceções | Usar movimentos efetivados do período, com classificação e ajustes validados. Sem grupo conhecido, preservar o valor e identificar a falta de grupo. Não chamar todos os débitos remanescentes de consumo sem validar sua natureza. |
| Exemplo esperado | “Como foi meu mês?” → receitas de R$ 8.000, gastos de R$ 5.000 e resultado de R$ 3.000; aplicação de R$ 1.000 e fatura de R$ 2.000 apresentadas separadamente. Valores ilustrativos. Não dizer que o saldo em conta é R$ 3.000. |
| Herança | Manter separação patrimonial e composição por grupo. Recomendar revisão do tratamento automático de saques e transferências próprias e do uso do termo “saldo” para resultado. Nenhuma revisão está aprovada ainda. |
| Pendências e responsável | **Produto MF**, com **Dados MF**, decide Q6 e ratifica Q7/Q10, incluindo estornos, cobertura do cartão e divergências com o panorama anterior. Sem essa definição não há total definitivo de “consumo”. |

## 3. Consulta de lançamentos — questões 11, 12 e 13

| Item | Definição e encaminhamento |
| --- | --- |
| Finalidade e significado | Encontrar movimentos individuais. Total encontrado e quantidade exibida são informações distintas. Valores associados respeitam o critério consultado, inclusive quando o movimento não é consumo. |
| Q11 — Dimensões | **Recomendação V1:** período, categoria, grupo, descrição, faixa de valor e natureza de entrada/saída. Estabelecimento pesquisado pelo texto disponível, sem identidade comercial inferida. Instituição pode ser exibida quando conhecida; seu uso como filtro fica para depois da confirmação de qualidade e cobertura. |
| Q12 — Ordem e quantidade | **Recomendação:** cinco lançamentos por resposta inicial, mostrando quantidade total encontrada. Preservar maior valor absoluto como ordem padrão; pedidos de “maiores gastos” precisam restringir a saídas de gasto. Não substituir “mais recente” por “maior”: ordenação cronológica adicional depende de inclusão expressa no escopo. Expansão da lista deve respeitar a solicitação e um limite a aprovar. |
| Q13 — Incompletude e desconhecidos | Informar “mostrando 5 de 18”. Preservar categorias desconhecidas ou personalizadas como recebidas, sem inventar definição. Se faltar rótulo, comunicar a ausência. Descrições parecidas não são automaticamente o mesmo estabelecimento. |
| Inclusões e exceções | Consulta pode exibir entradas, saídas, saques, aplicações, resgates e faturas conforme o pedido. Categoria e grupo são diferentes; filtros conjuntos restringem o universo e termos alternativos ampliam a correspondência textual. Não afirmar ausência fora da cobertura disponível. |
| Exemplo esperado | “Quais pagamentos acima de R$ 500 encontrei em junho?” → lançamentos correspondentes, com natureza e data; informar quantos existem e quantos foram mostrados. |
| Herança | Manter busca textual, período inclusivo, ordenação por magnitude, preservação dos rótulos e aviso de lista parcial. Filtragem explícita por natureza é uma ampliação proposta e não deve ser apresentada como já herdada. |
| Pendências e responsável | **Produto MF** aprova Q11–Q13, inclusive limite de expansão e ordenações. **Dados MF** confirma confiabilidade de instituição e natureza. |

## 4. Composição e evolução — questões 13, 14, 15 e 16

| Item | Definição e encaminhamento |
| --- | --- |
| Finalidade e significado | Totalizar gastos por grupo, categoria, descrição, data, dia da semana ou mês. Participação é fração do gasto do mesmo recorte; frequência é quantidade de lançamentos. Frequência não confirma assinatura ou recorrência contratual. |
| Q13 — Rankings e descrições | **Herdado; recomendar manutenção:** rankings parciais mostram a participação efetivamente coberta, sem forçar 100%. Total por descrição vem acompanhado da quantidade de lançamentos. Não unificar descrições equivalentes sem uma identificação confiável. |
| Q14 — Comparação temporal | **Recomendação:** comparações de crescimento ou redução usam meses completos, consecutivos e com cobertura equivalente. Meses em andamento aparecem separadamente como acumulado. Comparação até o mesmo dia fica para evolução futura. |
| Q15 — Meses parciais | **Recomendação:** entram em totais e composição do recorte solicitado, claramente identificados. Ficam fora do ranking comparativo padrão de meses e de médias mensais de meses completos. Não extrapolar o mês. Ausência de dados não vale como mês de gasto zero. |
| Q16 — Base anterior zero | **Recomendação:** dizer “sem gasto registrado no mês anterior; R$ X neste mês”, sem percentual de crescimento. Se havia gasto e passou a zero, mostrar redução de 100% somente com cobertura completa e comparável. Zero em ambos significa ausência de gasto observado, não crescimento calculável. |
| Inclusões e exceções | Universo de gastos segue a definição aprovada do panorama. Um mês completo no calendário só é comparável quando sua cobertura também é completa. Não omitir categoria desaparecida nem confundir descrição agregada com transação. |
| Exemplo esperado | “Qual mês teve mais gastos?” → indicar o maior entre os meses completos cobertos; apresentar o mês corrente como parcial e fora desse ranking. “Por que aumentou?” → apontar os grupos que cresceram, sem atribuir motivação ao cliente. |
| Herança | Manter dimensões e percentuais sobre a base real. Recomendar revisão da comparação entre os dois últimos meses com registros quando não forem consecutivos, do uso de mês parcial sem equivalência e da omissão de categorias que passaram a zero. |
| Pendências e responsável | **Produto MF** e **Responsável por análises** aprovam Q14–Q16; **Dados MF** assegura identificação de cobertura. Consolidação de estabelecimentos depende de decisão adicional. |

## 5. Lançamentos atípicos — questões 19 e 20

| Item | Definição e encaminhamento |
| --- | --- |
| Finalidade e significado | Identificar valores distantes dos outros gastos da mesma categoria, no recorte analisado. É evidência estatística descritiva, sem conclusão de fraude, desperdício ou erro. |
| Q19 — Critério | **Herdado; recomendar manutenção na V1:** pelo menos cinco saídas por categoria e afastamento absoluto estritamente superior a dois desvios-padrão populacionais da média. Categoria sem variação não gera alerta. Cinco registros são mínimo de cálculo, não garantia de representatividade ou de detecção. |
| Q19 — Base de comparação | **Herdado:** utiliza a categoria dentro do conjunto filtrado. Não descrever um resultado calculado apenas em agosto como comparação com seis meses completos. Usar seis meses como referência e destacar outro período seria uma nova regra, a deliberar separadamente. |
| Q20 — Baixos e sazonais | **Recomendação mínima:** preservar valores altos e baixos, identificando a direção do afastamento. Não chamar todos de “acima do padrão”. Não aplicar ajuste sazonal na V1; despesas sazonais legítimas podem ser apontadas e devem ser contextualizadas. |
| Inclusões e exceções | Somente gastos de saída válidos, sem movimentação patrimonial, conforme o recorte. Categorias com poucos registros devem ser apresentadas como não avaliadas, não como “sem anomalias”. |
| Exemplo esperado | “Algo incomum em Saúde em agosto?” → “Este lançamento ficou acima dos demais valores de Saúde analisados em agosto; isso não comprova irregularidade”. Informar se a base foi insuficiente. |
| Herança | Recomendar manter os critérios anteriores, sem afirmar que já estão homologados para a V1. Tratamento sazonal e alertas proativos ficam para versões futuras. |
| Pendências e responsável | **Produto MF** e **Responsável por análises** ratificam Q19–Q20, amostra, sensibilidade, direção e linguagem. |

## 6. Estatísticas dos gastos — questões 15, 17 e 18

| Item | Definição e encaminhamento |
| --- | --- |
| Finalidade e significado | Descrever valores individuais de gastos: mediana, metade central dos valores e variabilidade. Não inferir orçamento ou previsão mensal. |
| Q17 — Gasto típico | **Herdado; recomendar manutenção:** “valor típico por lançamento” é a mediana das saídas no recorte. Gasto mensal típico é outra medida e fica fora da V1 recomendada. Pedido ambíguo deve esclarecer a unidade, sem trocar uma medida pela outra. |
| Q18 — Apresentação | **Recomendação:** panorama espontâneo traz totais e composição; estatísticas detalhadas só quando a pergunta exigir valor típico, faixa, média ou variabilidade. Não inserir quartis e desvios em todo resumo. |
| Q15 — Períodos parciais | **Recomendação:** estatísticas por transação podem usar período parcial, informando as datas e a quantidade. Isso não autoriza comparação de gasto mensal típico com meses completos. |
| Inclusões e exceções | Somente gastos válidos. Dispersão por categoria exige cinco lançamentos. Mediana e quartis anteriores não têm esse mesmo mínimo: amostra pequena precisa ser comunicada. Base vazia significa ausência de observações, não gasto típico de zero. |
| Exemplo esperado | “Qual meu gasto típico em Alimentação?” → “A mediana por lançamento foi R$ 85 no período analisado”. “Qual varia mais?” → distinguir variação em reais de variação proporcional ao valor médio. Valores ilustrativos. |
| Herança | Manter mediana, quartis e distinção entre variabilidade absoluta e relativa. Rever a comunicação de zeros devolvidos para conjunto vazio. Não generalizar o mínimo de cinco para todas as estatísticas como se fosse regra antiga. |
| Pendências e responsável | **Produto MF** aprova Q17–Q18; **Responsável por análises** valida comunicação de amostra pequena e adequação das medidas. |

## 7. Possíveis repetições — questões 21 e 22

| Item | Definição e encaminhamento |
| --- | --- |
| Finalidade e significado | Encontrar movimentos de saída com mesma data, descrição e valor. A coincidência não determina se houve cobrança indevida. |
| Q21 — Critério | **Herdado; recomendar manutenção:** coincidência exata e pelo menos duas ocorrências. A fonte precisa distinguir duplicação do mesmo registro de duas movimentações distintas. Parcelas em datas diferentes e assinaturas mensais não são repetição pela regra V1; ocorrências iguais no mesmo dia ainda podem ser legítimas. |
| Q21 — Limite da distinção | Não é possível distinguir definitivamente parcelas, assinaturas e compras iguais apenas por data, descrição e valor. Não prometer essa capacidade; diferenças pequenas e repetições em dias próximos ficam fora da V1 recomendada. |
| Q22 — Valor excedente | **Recomendação:** usar “valor das ocorrências além da primeira”. Se usar “possível valor excedente”, explicar a condição: seria indevido somente se as ocorrências adicionais fossem confirmadas como indevidas. Não dizer “prejuízo” ou “valor a receber”. |
| Inclusões e exceções | Considerar saídas, inclusive aplicações e pagamentos de fatura. Créditos ficam fora. Correções, cancelamentos e estornos dependem da situação validada pela fonte. Total de grupos e soma condicional abrangem toda a busca, mesmo que a lista exibida seja menor. |
| Exemplo esperado | Duas saídas iguais de R$ 39,90 → “Há dois lançamentos de R$ 39,90 com a mesma data e descrição. Uma ocorrência além da primeira corresponde a R$ 39,90; é necessário conferir se ambas são legítimas”. |
| Herança | Manter coincidência exata, inclusão de saídas patrimoniais e totais completos. Não ratificar interpretação de fraude, erro ou restituição automática. |
| Pendências e responsável | **Produto MF** aprova Q21–Q22 e linguagem; **Dados MF** confirma identidade, origem e situação dos movimentos. Se houver mistura de contas sem identificação confiável, não afirmar que uma cobrança foi repetida. |

## 8. Indicadores financeiros — questões 10, 16 e 23 a 27

| Item | Definição e encaminhamento |
| --- | --- |
| Situação na V1 | **Recomendação:** disponibilizar resultado sobre receitas observadas, variações comparáveis e gasto sobre renda declarada para um mês específico. Renda inferida automaticamente, poupança patrimonial e avaliação de saúde financeira ficam fora do escopo recomendado inicial. |
| Q23 — Fonte da renda | **Recomendação:** usar renda mensal líquida declarada pelo cliente, positiva, com referência ao mês analisado e identificação de que é declarada. Sem declaração válida, não publicar percentual de gasto sobre renda. Receitas observadas no extrato permanecem disponíveis e não são automaticamente chamadas de renda mensal. |
| Q24 — Múltiplos salários e irregularidade | **Herdado:** mediana de créditos individuais classificados como salário. **Recomendação de revisão:** não utilizar essa estimativa na V1. Somar recebimentos identificados de um mês permite informar “salários recebidos”, mas não comprova renda habitual. Receitas irregulares não devem ser anualizadas ou convertidas em salário pelo agente. |
| Q25 — Gasto sobre renda | **Recomendação:** gastos de um mês divididos pela renda líquida declarada para esse mês, apresentados em percentual. Não comparar seis meses de gastos com uma renda mensal nem usar denominador zero ou desconhecido. Não significa comprometimento de renda com parcelas de dívidas. |
| Q25 — Poupança implícita | **Recomendação:** denominar “resultado sobre as receitas observadas”: receitas menos gastos, dividido pelas receitas, no mesmo período. Somente com receitas positivas; pode ser negativo. Não comprova dinheiro guardado, rendimento de investimentos ou crescimento patrimonial. Se receitas forem zero, apresentar apenas resultado em reais. |
| Q26 — Parcial ou completo | **Recomendação:** resultado em reais e resultado sobre receitas podem ser acumulados parciais, explicitamente identificados. Gasto sobre renda pode usar gasto acumulado contra renda mensal declarada, com essa distinção textual. Comparações mensais de evolução usam meses completos consecutivos com cobertura equivalente. |
| Q16 — Crescimento sem base | Aplicar a regra de composição: informar valor novo sem percentual quando a base anterior for zero; não comunicar crescimento infinito. |
| Q27 — Conclusões | Permitir “os gastos diminuíram”, “o resultado aumentou” e comparações objetivas sustentadas pelos dados. “Melhorou” só em relação a uma medida ou meta explicitada. Não concluir “saudável”, “gastando demais” ou “situação pior” sem critério de produto ou limite definido pelo cliente. |
| Inclusões e exceções | Bases de gastos e receitas seguem o panorama aprovado. Renda declarada pode divergir das entradas observadas; explicar a diferença, sem substituir uma pela outra silenciosamente. Transferências, estornos e cobertura incompleta podem invalidar interpretações se não forem tratados. |
| Exemplo esperado | Gastos de R$ 3.000 até o dia 9 e renda mensal declarada de R$ 6.000 → “Os gastos registrados até o dia 9 equivalem a 50% da renda mensal que você informou”. Não concluir que poupará os outros 50% no mês. |
| Herança | Manter prioridade da renda declarada, exclusão patrimonial e ausência de indicador sem denominador válido. Recomendar revisão da mediana de salários individuais, do nome “taxa de poupança” e das comparações entre bases incompatíveis. São propostas, não rejeições já aprovadas. |
| Pendências e responsável | **Produto MF** aprova Q23–Q27 e nomenclatura; **Responsável por análises** valida períodos e denominadores. Enquanto isso, esta capacidade não pode ser anunciada como integralmente definida. |

## 9. Explicação de categorias — questões 28 a 31

| Item | Definição e encaminhamento |
| --- | --- |
| Finalidade e significado | Explicar categoria, grupo, inclusões e exclusões do catálogo. Informar a classificação recebida de um lançamento sem atribuir nova classificação por opinião. |
| Q28 — Catálogo | **Herdado:** catálogo de categorias e grupos versionado no produto anterior. **Recomendação:** usá-lo como candidato inicial, condicionado à identificação da versão vigente aprovada pelo Minhas Finanças. O arquivo existente, sozinho, não comprova vigência oficial. |
| Q29 — Desconhecidas e personalizadas | Preservar o rótulo recebido e informar quando não há definição disponível. Não eliminar o lançamento por falta de definição nem inventar grupo. Classificação desconhecida não deve impedir totalização quando natureza e valor são válidos. Se a classificação for necessária para excluir movimento patrimonial, comunicar a limitação. |
| Q30 — Conferência e correção | **Recomendação V1:** permitir sugerir que o cliente confira a categoria ao apontar uma divergência. Não sugerir categoria substituta como correta sem regra aprovada e não efetuar alteração. Sugestão automatizada de recategorização fica para versão futura. |
| Q31 — Governança | **Proposta de responsabilidade:** Produto MF aprova definições e mudanças; Gestor do catálogo mantém versão, vigência e correspondência com a fonte. Nome e alçada ainda não foram informados. |
| Inclusões e exceções | Marca e estabelecimento não são categorias por definição. “Essencial”, “supérfluo” e “fixo” dependem de critério aprovado ou escolha do cliente. Para dizer em qual categoria um estabelecimento aparece, observar seus lançamentos reais. |
| Exemplo esperado | “Por que aparece nesta categoria?” → informar a categoria recebida e sua definição disponível, sem inventar o motivo de classificação. Se houver divergência, sugerir conferência. |
| Herança | Manter distinção entre grupo, categoria e estabelecimento, preservação dos rótulos e proibição de definições inventadas. Sugestão de conferência precisa de ratificação; recategorização não é capacidade herdada. |
| Pendências e responsável | **Produto MF** e **Gestor do catálogo** decidem Q28–Q31, versão inicial, responsáveis, periodicidade e tratamento de categorias personalizadas. |

## Critério de fechamento

Esta matriz cobre as questões 1 a 31. Uma decisão só deve receber o status
“definitiva” depois de registrada pelo responsável com escopo, data e versão.
Para comunicar disponibilidade efetiva na V1, é necessário também confirmar
que as condições de dados e os resultados esperados foram atendidos.

O encaminhamento recomendado é levar as nove capacidades à V1 nos limites desta
matriz, mantendo indisponíveis os resultados que dependam de condições ainda
não confirmadas. Aprovar um comportamento herdado e aceitar uma mudança são
decisões distintas; ambas devem ficar explícitas no fechamento negocial.
