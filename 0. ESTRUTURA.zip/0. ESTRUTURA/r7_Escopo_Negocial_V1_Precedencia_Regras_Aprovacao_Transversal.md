# AGENTE MINHAS FINANÇAS — Escopo Negocial da V1, Precedência de Regras e Aprovação Transversal

## 1. Princípio fundamental

O **AGENTE MINHAS FINANÇAS** deverá possuir um escopo negocial único, aprovado e verificável, que prevaleça sobre interpretações isoladas de documentos, propostas anteriores ou comportamentos herdados do produto original.

O escopo deverá definir:

- Quais capacidades serão efetivamente oferecidas.
- Quais resultados e orientações são permitidos.
- Quais funcionalidades e conteúdos estão autorizados.
- Quais situações exigem esclarecimento, limitação ou impossibilidade.
- Quais áreas possuem autoridade sobre cada domínio.
- Como divergências e mudanças serão resolvidas.

**Regra principal:** nenhuma capacidade, comportamento ou regra deverá ser considerada aprovada para produção apenas porque aparece em um documento de referência, foi descrita em uma simulação ou já existe tecnicamente.

Para fins desta consolidação, devem ser diferenciadas três situações:

| Situação | Significado |
|---|---|
| **Aprovado — decisão negocial consolidada** | Comportamento expressamente estabelecido nas definições construídas até aqui |
| **Pendente de ratificação** | Proposta que depende de decisão formal, documentação autorizada ou aceite de responsável competente |
| **Fora do escopo** | Capacidade expressamente excluída do MVP, salvo futura mudança formal |

A consolidação negocial não equivale à homologação técnica nem à autorização de entrada em produção.

---

## 2. Declaração do núcleo negocial da V1

**As três frentes principais permanecem obrigatórias no escopo do produto:**

| Frente | Compromisso negocial | Limite essencial | Situação |
|---|---|---|---|
| **Consultas e análises financeiras** | Consultar e apresentar informações verificadas sobre movimentações, gastos e sua organização | Não inventar valores, extrapolar cobertura ou produzir análises sem regras aprovadas | Aprovado — escopo principal |
| **Educação financeira** | Explicar conceitos financeiros de caráter geral e informativo | RAG educativo obrigatório; sem prescrição financeira individualizada | Aprovado — escopo principal |
| **Orientação sobre o aplicativo** | Apresentar funcionalidades autorizadas e esclarecer sua utilização | Feature Manifest para recomendações; RAG `navegacao-app` para instruções operacionais | Aprovado — escopo principal |

As três frentes deverão funcionar de forma integrada nas solicitações compostas.

Isso não significa que toda pergunta exigirá executar as três capacidades.

**A integração é conversacional e negocial:** o cliente poderá combinar diferentes necessidades na mesma mensagem, e o agente deverá utilizar somente as fontes pertinentes a cada uma delas.

Não será exigido RAG para uma consulta exclusivamente financeira que possa ser respondida corretamente pelas ferramentas financeiras aprovadas.

### 2.1. Limites comuns

O agente deverá:

1. Atuar exclusivamente sobre dados e capacidades autorizados.
2. Consultar informações financeiras dentro da cobertura efetivamente disponível.
3. Distinguir resultados completos, parciais, inconclusivos e indisponíveis.
4. Utilizar somente o histórico recebido pela IBM, sem memória conversacional persistente própria.
5. Responder a perguntas compostas por necessidade.
6. Reconhecer limitações em vez de inventar respostas.
7. Preservar o caráter não prescritivo da educação financeira.
8. Recomendar funcionalidades somente quando habilitadas no Manifest.
9. Proteger credenciais e informações financeiras.
10. Não executar operações financeiras nem alterações não autorizadas.

---

## 3. Matriz principal de decisões transversais

| Assunto | Decisão negocial | Justificativa | Domínio afetado | Regra que prevalece em conflito | Responsável pela aprovação | Dependências | Situação |
|---|---|---|---|---|---|---|---|
| **1. Três capacidades principais** | Manter gastos, educação financeira e aplicativo no escopo obrigatório da V1 | Preserva a proposta de valor do agente | Escopo geral | Escopo transversal formalmente aprovado | Dono de negócio do agente | Capacidades financeiras, RAGs e Manifest | Aprovado — decisão negocial |
| **2. Nove capacidades financeiras** | Manter as nove como catálogo funcional de referência, sem presumir homologação individual | Evita transformar propostas em compromissos já validados | Financeiro | Matriz específica de escopo financeiro aprovada | Negócio financeiro + dono do agente | Regras financeiras e testes | Pendente de ratificação individual |
| **3. Escopo mínimo financeiro** | Priorizar consultas, resumos, localização de lançamentos, agrupamentos e definições de categorias | Oferece utilidade sem depender inicialmente de interpretações estatísticas avançadas | Financeiro | Escopo mínimo ratificado para a liberação | Negócio financeiro + dono do agente | Integridade, taxonomia e cálculos | Pendente de ratificação formal |
| **4. Análises avançadas** | Não comprometer automaticamente estatísticas interpretativas, atipicidade, repetições e indicadores sem regras aprovadas | Evita conclusões sem critérios financeiros suficientes | Financeiro | Regras específicas de cada análise | Negócio financeiro + especialistas competentes | Métodos, fórmulas e amostras | Pendente |
| **5. Capacidades excluídas** | Não oferecer aconselhamento individual, operações financeiras, previsões exatas ou funcionalidades não autorizadas | Mantém o produto dentro do escopo aprovado | Todos | Política de limites negociais | Dono do agente + áreas competentes | Segurança e conformidade | Fora do escopo |
| **6. Documentos herdados** | Documentos antigos são referência, não autoridade automática | Evita reintroduzir decisões substituídas | Transversal | Decisão posterior formalmente aprovada para o novo agente | Autoridade de escopo | Controle documental | Aprovado — princípio |
| **7. Autoridade para divergências** | Designar autoridade final de escopo, com validação obrigatória das áreas responsáveis | Autores de documentos distintos não podem decidir isoladamente o escopo geral | Governança | Deliberação formal da autoridade designada | Patrocinador ou governança do produto | Designações e alçadas | Pendente |
| **8. Hierarquia entre fontes** | Cada fonte possui autoridade somente sobre seu domínio | Evita uso de documentação inadequada para justificar resultados | Financeiro, RAGs e Manifest | Fonte oficial do domínio; conflitos materiais exigem resolução | Responsáveis pelos domínios | Catálogos e contratos de dados | Aprovado — princípio; fontes pendentes |
| **9. Calendário e fuso** | Utilizar uma referência temporal oficial e confiável, formalmente aprovada | Evita resultados diferentes para a mesma expressão temporal | Conversação e financeiro | Convenção temporal ratificada | Negócio financeiro + produto | Data de referência e regras do serviço | Pendente |
| **10. Linguagem natural** | Aplicar interpretações inequívocas e esclarecer ambiguidades materiais | Evita períodos e critérios escolhidos arbitrariamente | Conversação | Glossário e convenções aprovados | Negócio + experiência | Regras temporais e financeiras | Parcialmente aprovado; convenções pendentes |
| **11. Decisões negociais versus viabilidade** | Aprovar intenção e limites de negócio independentemente da implementação; liberar somente capacidades viáveis e homologadas | Separação entre aprovação conceitual e operação real | Governança e homologação | Dupla validação negocial e técnica | Negócio + responsáveis técnicos | IBM, dados, RAGs e Manifest | Aprovado — princípio |
| **12. Classificação do atendimento** | Distinguir atendimento completo, parcial, não atendimento legítimo e falha | Permite medir qualidade sem exigir respostas impossíveis | Conversação e qualidade | Política de suficiência e atendimento | Negócio + qualidade | Cenários de referência | Aprovado — decisão negocial |
| **13. Capacidade implementada sem regra aprovada** | Não disponibilizar conclusões dependentes da regra pendente | Código existente não autoriza resultado negocial | Financeiro e qualidade | Regra financeira ratificada | Dono da regra + dono do agente | Aprovação e regressão | Aprovado — princípio |
| **14. Responsabilidade pelos catálogos** | Separar propriedade do conteúdo, aprovação negocial e publicação | Evita alterações sem autoridade | Categorias, Manifest e RAGs | Autoridade designada por domínio | Responsáveis pelos produtos e conteúdos | Governança formal | Pendente de designação |
| **15. Mudanças futuras** | Exigir avaliação de impacto, aprovação, atualização documental e homologação proporcional | Evita mudanças silenciosas no comportamento | Todos | Versão aprovada vigente | Autoridade de escopo + donos afetados | Gestão de mudanças | Aprovado — princípio; processo pendente |
| **16. Dependências externas** | Homologar IBM, autorização financeira, fontes documentais e Manifest antes da liberação | A definição negocial depende de entradas confiáveis | Integração e operação | Critérios obrigatórios de homologação | Integração + segurança + negócio | Sistemas externos | Pendente de homologação |
| **17. Documentação completa** | Exigir escopo, responsáveis, regras, exceções e decisões pendentes formalmente resolvidos ou excluídos | Permite aceite verificável | Governança transversal | Baseline negocial formalmente aprovado | Autoridade final de escopo | Aprovação de todas as áreas | Pendente |

**Nenhuma linha pendente deverá ser interpretada como autorização tácita para implementação ou disponibilização.**

---

## 4. Compromisso das nove capacidades financeiras

O inventário funcional anterior define nove ferramentas de referência.

Para reduzir riscos, recomenda-se distinguir o **núcleo financeiro do primeiro MVP** das análises que dependem de critérios adicionais.

Essa separação é uma proposta conservadora de fechamento do escopo e ainda exige ratificação pelo negócio.

| Capacidade de referência | Compromisso proposto para o primeiro MVP | Condições obrigatórias | Situação |
|---|---|---|---|
| `obter_transacoes_cliente` | **Base obrigatória** para consultas financeiras | Autorização, cobertura e integridade comprovadas | Proposto para V1; homologação pendente |
| `obter_resumo_financeiro` | **Núcleo obrigatório**: entradas, gastos e resumos por período | Fórmulas aprovadas; separação de consumo e demais movimentações | Proposto para V1; regras pendentes |
| `consultar_lancamentos` | **Núcleo obrigatório**: localização e consulta de movimentações | Filtros, cobertura e limitações definidos | Proposto para V1; homologação pendente |
| `agrupar_lancamentos` | **Núcleo obrigatório**, limitado a agrupamentos e comparações confiáveis | Taxonomia, períodos e critérios de agregação aprovados | Proposto para V1; regras pendentes |
| `explicar_categoria` | **Núcleo obrigatório** para categorias oficialmente definidas | Catálogo de categorias aprovado | Proposto para V1; catálogo pendente |
| `calcular_estatisticas_gastos` | **Condicional**: não assumir compromisso até ratificação | Definição de medidas e suficiência estatística | Pendente; excluir da liberação inicial se não ratificado |
| `detectar_lancamentos_atipicos` | **Condicional**: não assumir compromisso até ratificação | Método, população de referência e limites de interpretação | Pendente; excluir da liberação inicial se não ratificado |
| `detectar_lancamentos_repetidos` | **Condicional**: não assumir compromisso até ratificação | Critérios de correspondência e tratamento de recorrências legítimas | Pendente; excluir da liberação inicial se não ratificado |
| `calcular_indicadores_financeiros` | **Condicional**: não assumir compromisso até ratificação | Fórmulas, abrangência e significado dos indicadores | Pendente; excluir da liberação inicial se não ratificado |

### 4.1. Decisão recomendada

Para a primeira disponibilização, recomenda-se comprometer o produto com **cinco capacidades financeiras de núcleo**, sendo uma de obtenção de dados e quatro voltadas a análises ou explicações ao cliente.

As quatro capacidades avançadas deverão permanecer fora da liberação inicial enquanto suas regras indispensáveis não estiverem ratificadas.

Isso não significa que devam ser eliminadas do planejamento da V1 ampliada.

Significa apenas que **não deverão ser prometidas aos clientes antes de comprovarem suficiência, correção e conformidade**.

Caso o negócio decida exigir todas as nove capacidades no primeiro lançamento, essa exigência deverá ser registrada formalmente e sua aprovação dependerá da ratificação das regras de cada uma.

**Não cabe ao agente ou à implementação decidir unilateralmente reduzir ou ampliar o compromisso formal da V1.**

---

## 5. Capacidades expressamente fora do MVP

Permanecerão fora do escopo, salvo mudança formal posterior:

| Capacidade ou experiência | Limite |
|---|---|
| Recomendações individualizadas de investimentos | Proibidas |
| Indicação de produtos, alocações e operações financeiras | Proibida |
| Definição de metas pessoais de gastos ou poupança | Proibida |
| Planos personalizados de quitação de dívidas | Proibidos |
| Diagnósticos de comportamento ou saúde financeira | Proibidos sem capacidade e critérios aprovados |
| Confirmação de fraude ou cobrança indevida a partir de indícios | Proibida |
| Previsões exatas de gastos futuros | Fora do escopo |
| Simulações financeiras complexas | Fora do escopo |
| Operações financeiras em nome do cliente | Fora do escopo |
| Alteração automática de categorias | Fora do escopo |
| Configuração de metas ou limites pelo agente | Fora do escopo |
| Criação e alteração de compromissos no App BB pelo agente | Fora do escopo |
| Consultas além da cobertura disponível e autorizada | Não suportadas |
| Comparação com outros clientes | Fora do escopo |
| Recuperação própria de histórico conversacional não recebido da IBM | Fora do escopo |
| Memória conversacional persistente própria | Fora do escopo |

### 5.1. Distinção importante: capacidade do aplicativo versus capacidade do agente

O **Planejamento Financeiro** é uma funcionalidade real do App BB que permite ao próprio cliente criar e acompanhar limites de gastos, conforme as condições do aplicativo.

Entretanto, o AGENTE MINHAS FINANÇAS não deverá configurar limites nem determinar quais valores seriam adequados.

Ele poderá:

- Apresentar brevemente a funcionalidade, se autorizada pelo Feature Manifest.
- Explicar como o cliente pode utilizá-la, com fundamentação no RAG `navegacao-app`.

Isso não significa que o agente executará o planejamento pelo cliente.

### 5.2. Cálculos hipotéticos

A possibilidade de realizar cálculos aritméticos hipotéticos simples foi identificada como proposta negocial, mas ainda não está ratificada como capacidade obrigatória da V1.

Até sua aprovação, não deverá ser apresentada como compromisso do MVP.

Essa pendência não autoriza projeções financeiras nem recomendações personalizadas.

---

## 6. Precedência entre documentos e decisões

A precedência não deverá ser determinada apenas pela data de criação ou pela equipe que produziu o documento.

A regra recomendada é:

**Uma decisão específica, formalmente aprovada para o novo AGENTE MINHAS FINANÇAS, prevalece sobre uma proposta anterior ou regra herdada, desde que respeite normas obrigatórias e as competências das autoridades responsáveis.**

### Hierarquia proposta

| Prioridade | Tipo de regra | Tratamento |
|---|---|---|
| **1** | Obrigações legais, regulatórias e controles obrigatórios de segurança e privacidade | Não podem ser afastados por documentos negociais |
| **2** | Escopo transversal da V1 formalmente aprovado | Determina capacidades, exclusões e limites gerais |
| **3** | Políticas específicas aprovadas por domínio | Detalham regras financeiras, educativas, conversacionais e de aplicativo |
| **4** | Catálogos e documentos oficiais vigentes de cada domínio | Fundamentam informações dentro de suas competências |
| **5** | Documentos anteriores, simulações e propostas herdadas | Servem como referência, sem autoridade para contrariar regras aprovadas |

Essa hierarquia deverá ser ratificada pela governança do produto.

### 6.1. Exemplo — Memória conversacional

**Regra herdada:** carregar transações uma vez e reutilizá-las durante a sessão.

**Decisão atual:** o agente não possui memória conversacional persistente entre requisições.

**Regra que deverá prevalecer:** a decisão atual.

A reutilização de dados durante uma única execução poderá ser permitida, mas não autoriza persistência entre chamadas.

### 6.2. Exemplo — Obrigatoriedade do RAG

**Regra herdada:** toda pergunta deve realizar recuperação documental.

**Decisão atual:** o RAG é obrigatório para explicações educativas e instruções de navegação, conforme suas respectivas fontes.

**Regra que deverá prevalecer:** a decisão atual.

Uma consulta exclusivamente financeira não deverá depender de recuperação documental sem necessidade negocial.

### 6.3. Exemplo — Planejamento Financeiro

**Regra financeira:** o agente não cria orçamentos personalizados nem define metas.

**Regra de aplicativo:** o Planejamento Financeiro é uma funcionalidade existente no App BB.

**Interpretação correta:** ambas podem coexistir.

O agente pode apresentar ou explicar a funcionalidade, mas não deverá determinar metas nem operar o recurso em nome do cliente.

### 6.4. Conflito não resolvido

Quando duas regras aprovadas parecerem incompatíveis, o agente não deverá escolher autonomamente qual delas deve prevalecer.

Até a resolução formal, deverá ser aplicado o comportamento que evite violação de segurança, exposição de dados ou conclusão não fundamentada.

Essa postura conservadora é uma medida de contenção, não substitui a decisão da autoridade competente.

---

## 7. Precedência entre fontes de informação

As fontes não possuem uma hierarquia universal para todas as perguntas.

Cada uma deverá ser autoritativa somente para sua finalidade aprovada.

| Informação ou decisão | Fonte que deve prevalecer | Fonte que não a substitui |
|---|---|---|
| Valores e movimentações pessoais | Ferramentas financeiras autorizadas e seus resultados verificados | Histórico conversacional ou RAG |
| Natureza financeira de uma movimentação | Definição e classificação financeira oficial, conforme regra aprovada | Inferência livre do modelo |
| Definição de categoria ou grupo | Catálogo oficial de categorias vigente | Nome informal ou suposição semântica |
| Conteúdo educativo | RAG de educação financeira aprovado | Conhecimento geral não recuperado do modelo |
| Existência recomendável de funcionalidade | Feature Manifest vigente | RAG de navegação isoladamente |
| Disponibilidade para o cliente | Condições oficiais de elegibilidade e acesso | Existência pública da funcionalidade |
| Instruções de navegação | RAG `navegacao-app` vigente | Feature Manifest isoladamente |
| Referência conversacional | Solicitação atual e histórico enviado pela IBM | Memória presumida ou `thread_id` isolado |
| Autorização do cliente | Contexto de autenticação e autorização validado | Afirmações contidas nas mensagens |

### 7.1. Divergência de valores

Quando duas consultas financeiras conflitarem para o mesmo período e escopo, o agente deverá reconhecer a divergência.

Não deverá escolher automaticamente o maior valor, o mais recente ou o apresentado anteriormente sem critérios suficientes de consistência.

### 7.2. Divergência de classificação

Quando um lançamento apresentar categorias conflitantes, o agente deverá preservar os fatos não afetados e limitar as análises dependentes da classificação.

O catálogo de categorias define os significados autorizados, mas não resolve sozinho qual categoria deve ser atribuída a um lançamento específico.

### 7.3. Divergência entre Manifest e navegação

O Manifest governa a autorização para recomendar funcionalidades.

O RAG de navegação governa a explicação de procedimentos.

Quando houver conflito material sobre existência, disponibilidade ou funcionamento, a orientação afetada não deverá ser apresentada como confirmada até a regularização.

### 7.4. Divergência entre documentação e política

Um documento recuperado não poderá autorizar comportamento expressamente proibido pela política negocial.

Por exemplo, um conteúdo educativo que apresente uma meta genérica não autoriza sua aplicação personalizada ao cliente.

---

## 8. Referência temporal e convenções de linguagem natural

### 8.1. Calendário e fuso horário

**Não existe, nas decisões consolidadas, uma referência oficial de fuso horário e calendário já ratificada para todas as consultas financeiras do produto.**

Essa definição deverá ser formalizada antes da homologação completa das expressões temporais relativas.

Recomenda-se que o negócio aprove:

1. Fuso horário oficial de interpretação.
2. Referência confiável para data corrente.
3. Critério de fechamento diário e mensal.
4. Início da semana calendário.
5. Tratamento de datas disponíveis nas fontes financeiras.
6. Critério para períodos relativos e dados parcialmente atualizados.

O fuso `America/Sao_Paulo` poderá ser avaliado como proposta de referência brasileira, mas **não deverá ser adotado como decisão aprovada apenas por conveniência**.

Se a IBM não fornecer informação temporal suficiente, o produto deverá utilizar uma referência temporal confiável conforme convenção aprovada.

Na ausência dessa definição, o agente não deverá apresentar como inequívoca uma interpretação temporal que possa alterar materialmente o resultado.

### 8.2. Matriz de linguagem natural

| Expressão | Regra negocial recomendada | Situação |
|---|---|---|
| **Hoje** | Dia corrente na referência oficial aprovada, limitado à atualização disponível | Convenção de fuso pendente |
| **Este mês** | Primeiro dia do mês corrente até a data efetivamente coberta | Regra geral consolidada; calendário pendente |
| **Mês passado** | Mês calendário imediatamente anterior | Regra recomendada; ratificação pendente |
| **Semana passada** | Semana calendário anterior, segundo início de semana aprovado | Pendente |
| **Últimos três meses** | Exige definição entre janela móvel e três meses calendário completos | Pendente; esclarecer quando material |
| **Setembro**, sem ano | Utilizar ano explicitado no contexto ou único período compatível; esclarecer se houver alternativas | Princípio consolidado |
| **Recentemente / ultimamente** | Não presumir automaticamente os seis meses disponíveis | Sem intervalo padrão aprovado |
| **Maiores gastos** | Distinguir maiores lançamentos individuais, categorias e grupos | Sem interpretação única aprovada |
| **Gastei muito** | Descrever valores e variações verificadas; não julgar excesso | Aprovado — limite negocial |
| **Meu saldo / minhas economias** | Utilizar apenas conceito financeiro cuja fonte e fórmula estejam aprovadas | Definições específicas pendentes |

### 8.3. Regra na ausência de padrão aprovado

Quando existir uma interpretação inequívoca pelo contexto, ela poderá ser utilizada.

Quando duas interpretações materialmente diferentes permanecerem possíveis, o agente deverá solicitar o esclarecimento indispensável.

**Não deverão ser criadas convenções implícitas apenas para aumentar a taxa de perguntas respondidas.**

---

## 9. Aprovação negocial e homologação técnica

É necessário distinguir duas decisões.

### 9.1. Aprovação negocial

Poderá definir:

- Finalidade do agente.
- Necessidades que serão atendidas.
- Capacidades incluídas ou excluídas.
- Limites de educação financeira.
- Regras de suficiência e comunicação.
- Política de recomendação.
- Critérios de interpretação.
- Responsabilidades e precedência documental.
- Resultados esperados e situações inaceitáveis.

Essas decisões não exigem que todas as capacidades já estejam implementadas.

### 9.2. Homologação técnica e operacional

Será necessária para comprovar:

- Integração efetiva com a IBM.
- Autenticação e autorização válidas.
- Recebimento dos identificadores necessários.
- Completude e confiabilidade dos dados financeiros.
- Funcionamento das capacidades aprovadas.
- Disponibilidade dos RAGs e dos documentos vigentes.
- Utilização do Feature Manifest homologado.
- Tratamento de falhas e timeouts.
- Segurança, privacidade e isolamento de clientes.
- Atendimento aos critérios de qualidade.

**A aprovação negocial define o que o produto poderá fazer. A homologação comprova que ele consegue fazê-lo de maneira segura e correta.**

Nenhuma dessas etapas substitui a outra.

---

## 10. Critérios de atendimento das necessidades

| Classificação | Condição | Avaliação de qualidade |
|---|---|---|
| **Atendida** | Todas as necessidades elegíveis foram resolvidas com evidências suficientes | Adequado |
| **Parcialmente atendida** | Parte das necessidades foi resolvida; as limitações restantes foram comunicadas | Adequado, quando não houver omissão indevida |
| **Esclarecimento necessário** | Informação indispensável não está presente e não pode ser inferida com segurança | Adequado |
| **Não atendida — falta de capacidade** | A necessidade está fora do escopo aprovado | Adequado se o limite for comunicado |
| **Não atendida — dados insuficientes** | Existe capacidade, mas faltam evidências necessárias | Adequado se a limitação for correta |
| **Não atendida — indisponibilidade** | Falha operacional impede obter resultado | Adequado se a falha não for disfarçada |
| **Falha de atendimento** | O agente poderia responder corretamente, mas omitiu, recusou indevidamente ou inventou informações | Inadequado |

### Regra para perguntas compostas

Cada necessidade deverá ser avaliada separadamente.

Uma solicitação não será considerada integralmente atendida apenas porque o agente respondeu sua primeira parte.

Da mesma forma, não deverá ser automaticamente considerada uma falha quando apenas parte puder ser respondida com segurança.

---

## 11. Implementação disponível sem regra financeira ratificada

**Uma capacidade implementada não deverá ser disponibilizada apenas por existir tecnicamente.**

O compromisso negocial dependerá da aprovação de suas regras.

| Situação | Tratamento obrigatório |
|---|---|
| Capacidade implementada e regra aprovada | Submeter à homologação |
| Capacidade implementada, mas fórmula não aprovada | Não disponibilizar o indicador |
| Capacidade implementada, mas método estatístico pendente | Não oferecer conclusão estatística dependente do método |
| Capacidade implementada, mas dados sem cobertura comprovada | Limitar ou impedir conclusões abrangentes |
| Capacidade implementada e documentação conflitante | Não ativar o comportamento afetado até resolução |
| Capacidade implementada e testes insuficientes | Não considerar homologada |
| Capacidade parcialmente homologada | Avaliar liberação restrita somente se houver isolamento seguro e escopo formalmente aprovado |

Uma área técnica não deverá aprovar unilateralmente critérios de negócio, mesmo que os resultados pareçam plausíveis.

---

## 12. Autoridade e responsabilidade pelos seis domínios documentais

Para fins desta consolidação, recomenda-se organizar as aprovações em seis domínios negociais:

1. Suficiência e confiabilidade dos dados.
2. Experiência e continuidade conversacional.
3. Educação financeira e limites de orientação.
4. Funcionalidades e recomendação contextual.
5. Qualidade, segurança e critérios de aprovação.
6. Escopo transversal e precedência de decisões.

Essa organização não pressupõe que os seis documentos já possuam proprietários formalmente designados.

| Documento ou domínio | Autoridade de conteúdo recomendada | Validações necessárias | Situação |
|---|---|---|---|
| **Dados e análises financeiras** | Responsável de negócio financeiro | Donos de dados, taxonomia e qualidade | Pendente de designação |
| **Experiência conversacional** | Responsável de produto/experiência do agente | Negócio financeiro, segurança e qualidade | Pendente de designação |
| **Educação financeira** | Responsável editorial ou educacional designado | Compliance/jurídico quando aplicável | Pendente de designação |
| **Funcionalidades e aplicativo** | Responsável de produto do App BB e gestor do Manifest | Negócio do agente e documentação de navegação | Pendente de designação |
| **Qualidade e segurança** | Responsáveis de qualidade e segurança | Privacidade, negócio e operação | Pendente de designação |
| **Escopo transversal** | Autoridade final de escopo do AGENTE MINHAS FINANÇAS | Aceite das áreas afetadas | Pendente de designação |

### 12.1. Autoridade final para divergências

Recomenda-se designar formalmente **um responsável final pelo escopo negocial do AGENTE MINHAS FINANÇAS**, com alçada para arbitrar divergências entre documentos.

Essa autoridade deverá receber as avaliações dos responsáveis pelos domínios envolvidos.

Entretanto:

- Não poderá afastar obrigações legais e regulatórias.
- Não poderá aprovar acesso indevido a dados.
- Não poderá dispensar controles obrigatórios de segurança.
- Não deverá alterar unilateralmente catálogos pertencentes a outros produtos.
- Não poderá considerar capacidade homologada sem as evidências exigidas.

Divergências com impacto jurídico, de privacidade ou de segurança deverão exigir a validação das áreas competentes.

**A autoridade final ainda precisa ser nominalmente designada pela governança do produto.**

---

## 13. Aprovação dos catálogos e conteúdos

| Artefato | Responsável recomendado pela aprovação | Regra de utilização | Situação |
|---|---|---|---|
| **Catálogo de categorias e grupos** | Dono da taxonomia financeira / negócio financeiro | Fonte oficial para definições e regras de classificação | Pendente |
| **Feature Manifest** | Dono das funcionalidades do App BB + responsável pelo escopo do agente | Autoriza funcionalidades e condições de recomendação | Pendente |
| **RAG de educação financeira** | Curadoria educativa formalmente designada | Fundamenta explicações gerais não prescritivas | Pendente |
| **RAG `navegacao-app`** | Responsável pela documentação vigente do aplicativo | Fundamenta acesso, configuração e utilização | Pendente |
| **Regras de cálculo financeiro** | Negócio financeiro | Define fórmulas, movimentações e interpretações | Pendente |
| **Convenções de linguagem natural** | Produto + negócio financeiro | Define interpretações padrão seguras | Pendente |

O agente não deverá utilizar seu próprio julgamento para substituir aprovações de conteúdo.

A publicação técnica de um catálogo não equivale à autorização negocial de seu uso.

---

## 14. Mudanças futuras e controle de versões

Qualquer mudança material deverá possuir avaliação de impacto antes de entrar em vigor.

### Mudanças sujeitas a aprovação

- Inclusão ou retirada de capacidade.
- Alteração de fórmula ou indicador.
- Mudança de conceito financeiro.
- Alteração de taxonomia.
- Atualização de conteúdo educativo com impacto negocial.
- Mudança de finalidade ou elegibilidade de funcionalidade.
- Modificação de convenção temporal.
- Ampliação de histórico financeiro.
- Inclusão de nova fonte de dados.
- Alteração dos limites de orientação.
- Revisão dos critérios de qualidade e bloqueio.

### Regra de atualização

Toda mudança deverá identificar:

1. O que será alterado.
2. Qual regra anterior será substituída.
3. Qual autoridade aprovou a alteração.
4. Quais documentos e catálogos serão afetados.
5. Quais capacidades dependem da mudança.
6. Quais testes deverão ser refeitos.
7. A partir de quando a nova regra estará vigente.
8. Quais mecanismos permitirão restringir ou reverter a mudança, quando aplicável.

Não deverá existir alteração silenciosa de regras negociais por atualização de documento, prompt, catálogo ou base de conhecimento.

**Uma nova versão não deverá ser considerada automaticamente mais autoritativa do que uma versão aprovada anterior. A autoridade depende de aprovação e vigência formal.**

---

## 15. Dependências externas necessárias à homologação

Antes de considerar o produto apto à homologação final, deverão estar disponíveis as condições essenciais para validar seu comportamento real.

| Dependência | Confirmação necessária | Consequência da ausência |
|---|---|---|
| **IBM watsonx Orchestrate** | Compatibilidade efetiva com Chat Completions e contrato acordado | Não homologar integração |
| **Histórico via `messages`** | Comportamento real com histórico completo, limitado e ausente | Não presumir continuidade indisponível |
| **`X-IBM-THREAD-ID`** | Recebimento e estabilidade conforme requisitos do ambiente | Não homologar rastreabilidade exigida |
| **`X-SENDER-ID`** | Encaminhamento seguro, associação autorizada e proteção do token intermediário | Não liberar consultas financeiras reais |
| **Serviço de transações** | Cobertura, completude, atualização e tratamento de falhas | Não homologar análises dependentes |
| **Regras financeiras** | Fórmulas, classificações e limites ratificados | Não disponibilizar resultados dependentes |
| **Catálogo de categorias** | Fonte e versão oficiais aprovadas | Não homologar explicações ou agrupamentos dependentes |
| **RAG educativo** | Conteúdo aprovado, disponível e suficiente para o escopo | Não liberar explicações educativas não fundamentadas |
| **RAG `navegacao-app`** | Documentação vigente e aprovada | Não liberar instruções operacionais dependentes |
| **Feature Manifest** | Catálogo publicado, elegibilidade e condições vigentes | Não liberar recomendações espontâneas |
| **Segurança e privacidade** | Controles e responsabilidades validados | Não liberar tratamento de dados reais |
| **Critérios de qualidade** | Metas obrigatórias, testes e regras de bloqueio aprovados | Não concluir aceite final |

As dependências deverão ser avaliadas pela função que exercem no produto.

Uma falha documental poderá justificar a suspensão da capacidade educativa ou de navegação sem necessariamente impedir consultas financeiras independentes, desde que os controles comuns permaneçam íntegros.

Falhas compartilhadas de autenticação, autorização ou isolamento entre clientes impedem a operação segura do conjunto afetado.

---

## 16. Critérios para documentação negocial completa

A documentação da V1 somente deverá ser considerada completa e aprovada quando apresentar evidências de que:

| Critério de fechamento | Exigência |
|---|---|
| Escopo geral | Três frentes principais expressamente confirmadas |
| Capacidades financeiras | Inclusões, exclusões e capacidades condicionais ratificadas individualmente |
| Regras financeiras | Fórmulas, classificações e suficiência aprovadas para cada resultado oferecido |
| Educação financeira | Assuntos permitidos e conteúdos autorizados definidos |
| Aplicativo | Catálogo recomendável e documentação de navegação aprovados |
| Continuidade conversacional | Regras de contexto, ambiguidades e atendimento parcial consolidadas |
| Referência temporal | Calendário, fuso e convenções de período aprovados |
| Segurança | Limites de autorização, isolamento e proteção de dados ratificados |
| Qualidade | Critérios de aceite, falhas bloqueantes e metas exigidas definidos |
| Governança | Responsáveis e autoridade final formalmente designados |
| Precedência | Hierarquia documental e resolução de conflitos aprovadas |
| Mudanças | Processo de atualização e retirada formalizado |
| Pendências | Resolvidas ou explicitamente excluídas do escopo liberado |
| Aprovação | Aceite formal das autoridades competentes, com versão identificada |

**Um documento não deverá ser declarado completo apenas porque contém respostas para todas as perguntas.**

A completude exige que as respostas relevantes estejam formalmente aprovadas, que não existam contradições materiais não resolvidas e que todas as dependências indispensáveis estejam identificadas.

### 16.1. Pendências que podem permanecer abertas

Poderão permanecer pendentes decisões sobre funcionalidades futuras ou capacidades expressamente excluídas do primeiro lançamento.

Essas pendências deverão estar identificadas como fora do escopo liberado.

### 16.2. Pendências que impedem o fechamento

Não poderão permanecer indefinidas decisões indispensáveis a uma capacidade ativa, incluindo:

- Fórmulas financeiras necessárias.
- Regras de autorização.
- Cobertura e integridade dos dados.
- Conteúdos documentais obrigatórios.
- Elegibilidade de funcionalidades recomendáveis.
- Calendário e períodos necessários às consultas.
- Autoridade final de aprovação.
- Critérios obrigatórios de aceite.

---

## 17. Declaração objetiva do MVP negocial

### Núcleo já consolidado

O **AGENTE MINHAS FINANÇAS V1** será um assistente conversacional informativo, integrado à IBM, destinado a:

1. **Consultar e explicar dados financeiros autorizados do cliente**, respeitando cobertura, integridade e regras de cálculo aprovadas.
2. **Fornecer educação financeira geral**, fundamentada obrigatoriamente no RAG correspondente e sem recomendar decisões individualizadas.
3. **Orientar sobre funcionalidades do App BB**, apresentando recursos autorizados pelo Feature Manifest e utilizando o RAG de navegação para instruções operacionais.
4. **Atender solicitações simples, compostas e contextuais**, utilizando exclusivamente o histórico disponibilizado pela IBM.
5. **Reconhecer limitações e falhas**, distinguindo resultados completos, parciais, inconclusivos, indisponíveis e fora do escopo.
6. **Avaliar ao final de cada interação a pertinência de uma recomendação de funcionalidade**, sem obrigação de recomendar e sem alterar o contrato externo Chat Completions.
7. **Proteger identidade, credenciais e dados financeiros**, sem acessar informações de outros clientes ou executar operações não autorizadas.

### Detalhamento conservador proposto para o primeiro lançamento

O núcleo financeiro recomendado compreende obtenção de transações, resumos financeiros, consulta de lançamentos, agrupamentos e explicação de categorias, condicionados à ratificação de suas regras.

Análises avançadas de atipicidade, estatísticas interpretativas, possíveis repetições e indicadores financeiros deverão permanecer condicionadas à aprovação específica de métodos e critérios.

As cinco funcionalidades públicas principais do Minhas Finanças poderão integrar o catálogo recomendável, mas sua habilitação depende do Feature Manifest aprovado:

- Agenda Financeira.
- Entradas e Saídas.
- Meus Gastos.
- Planejamento Financeiro.
- Extrato Multibanco.

### Situação da declaração

**O núcleo negocial está consolidado como referência para aprovação. O MVP definitivo ainda depende de ratificação formal do recorte financeiro, dos catálogos, das convenções temporais e da autoridade responsável pelo aceite.**

Não deverá ser declarado aprovado para produção antes da homologação das dependências e dos critérios obrigatórios de qualidade e segurança.

---

## 18. Regra negocial consolidada

> **O AGENTE MINHAS FINANÇAS V1 deverá possuir um escopo negocial único e formalmente aprovado, que estabeleça capacidades oferecidas, limites de atuação, fontes autorizadas, critérios de confiabilidade e responsabilidades de decisão.**
>
> As três frentes principais — consultas financeiras, educação financeira e orientação sobre o aplicativo — permanecerão integradas no escopo do produto.
>
> As nove capacidades financeiras anteriormente identificadas constituem o catálogo funcional de referência, mas sua disponibilização dependerá da ratificação individual das regras e da homologação correspondente. Capacidades sem critérios indispensáveis aprovados não deverão ser prometidas ou ativadas.
>
> Decisões específicas formalmente aprovadas para o novo agente prevalecerão sobre propostas herdadas, respeitadas as obrigações legais, regulatórias e de segurança. Conflitos materiais não deverão ser resolvidos autonomamente pelo modelo.
>
> Cada fonte de informação deverá ser utilizada exclusivamente dentro de sua competência: ferramentas financeiras para dados pessoais, catálogo oficial para categorias, RAG educativo para conceitos, Feature Manifest para funcionalidades recomendáveis e RAG de navegação para procedimentos operacionais.
>
> A interpretação de períodos e expressões ambíguas deverá utilizar convenções negociais aprovadas. Na ausência de regra suficiente, o agente deverá solicitar esclarecimento quando necessário e não inventar referências.
>
> A autoridade final de escopo e os responsáveis pelos catálogos deverão ser formalmente designados. Mudanças futuras deverão possuir aprovação, rastreabilidade e avaliação de impacto.
>
> A documentação negocial somente será considerada concluída quando as decisões essenciais estiverem aprovadas, as divergências materiais resolvidas, os responsáveis identificados e as pendências remanescentes expressamente excluídas do escopo liberado.
>
> **A primeira versão deverá priorizar capacidades comprovadamente úteis, seguras e verificáveis, sem ampliar o escopo apenas porque uma funcionalidade já existe tecnicamente ou foi mencionada em documentação anterior.**

---

*Nota: este documento representa uma consolidação conservadora para decisão de negócio. As recomendações de recorte financeiro, hierarquia documental e governança não substituem a ratificação pelas autoridades competentes. Não há, até aqui, evidência suficiente para declarar o MVP integralmente aprovado, homologado ou autorizado para produção.*