# Capacidades financeiras do Agente Minhas Finanças

<!-- markdownlint-disable MD013 MD024 -->

## Objetivo deste documento

Este documento descreve as capacidades financeiras previstas para o Agente
Minhas Finanças e as regras necessárias para interpretar corretamente seus
resultados.

A análise considera como **definido no produto anterior** aquilo que já possui
comportamento explícito nas regras financeiras, na experiência conversacional
ou nos resultados produzidos. Os pontos classificados como **decisão negocial
pendente** não devem ser tratados como regra definitiva apenas porque existe um
comportamento técnico anterior ou uma proposta de refatoração.

## Visão geral

| Capacidade | Finalidade negocial | Situação |
| --- | --- | --- |
| Disponibilização do histórico financeiro | Tornar acessíveis os últimos seis meses de movimentações do cliente | Parcialmente definida; o período anterior é conhecido, mas o novo serviço exige confirmação de escopo |
| Panorama financeiro | Explicar quanto entrou, quanto foi gasto e como os gastos se distribuem | Definida no produto anterior |
| Consulta de lançamentos | Encontrar movimentações específicas no extrato | Definida no produto anterior, com filtros adicionais ainda sujeitos a decisão |
| Composição e evolução dos gastos | Comparar gastos por grupo, categoria, descrição, data, dia da semana e mês | Definida no produto anterior |
| Lançamentos atípicos | Sinalizar valores diferentes do padrão recente | Regra anterior existente; interpretação negocial precisa ser ratificada |
| Estatísticas dos gastos | Explicar valor típico, faixa central e variabilidade | Definida no produto anterior |
| Possíveis repetições | Encontrar lançamentos idênticos que mereçam conferência | Regra anterior existente; interpretação negocial precisa ser ratificada |
| Indicadores financeiros | Relacionar renda, gastos, poupança implícita e evolução mensal | Parcialmente definida; existem decisões críticas pendentes |
| Explicação de categorias | Explicar o significado das categorias e dos grupos | Definida no produto anterior, com governança futura a confirmar |

## 1. Disponibilização do histórico financeiro

### Nome e finalidade negocial

Disponibilizar ao agente as movimentações financeiras autorizadas do cliente
para que as demais capacidades possam trabalhar sobre uma fonte comum e
consistente.

### Perguntas que viabiliza

Esta capacidade não responde sozinha a uma pergunta financeira. Ela viabiliza
todas as perguntas que dependem do extrato, como:

- “Quanto gastei este mês?”
- “Quais foram minhas maiores despesas?”
- “Tenho lançamentos repetidos?”
- “Como meus gastos evoluíram?”

### Significado das informações apresentadas

- **Período disponível:** intervalo efetivamente coberto pelas transações.
- **Quantidade de lançamentos:** número de movimentações disponíveis para
  análise, sem representar quantidade de compras ou compromissos financeiros.
- **Situação da carga:** informa se os dados estão disponíveis, vazios,
  incompletos ou temporariamente indisponíveis.

### Transações e informações consideradas

**Definido no produto anterior:**

- seis meses de calendário, incluindo o mês corrente;
- início no primeiro dia do mês mais antigo;
- término na data corrente;
- o mês corrente é parcial;
- os lançamentos mantêm data, descrição, valor, natureza de entrada ou saída,
  categoria, grupo e instituição quando disponível.

### Regras e exceções

**Definido no produto anterior:**

- o período completo do extrato é único e não muda quando uma busca ou filtro é
  aplicado;
- o período de uma busca específica deve ser apresentado como período dos
  lançamentos encontrados, nunca como período completo do extrato;
- dados de identidade e autenticação não fazem parte da conversa com o cliente.

### Limitações conhecidas

- o histórico não permite conclusões anteriores aos seis meses disponíveis;
- o mês corrente pode conter poucos dias e não é diretamente comparável a um
  mês completo sem ressalva;
- ausência de transações pode representar ausência real, atraso ou
  indisponibilidade da fonte, dependendo do retorno do serviço.

### Decisões negociais pendentes

- confirmar se o novo serviço manterá seis meses de calendário ou adotará 180
  dias corridos;
- definir quais contas, cartões e instituições compõem o histórico;
- definir o tratamento de lançamentos pendentes, cancelados, estornados ou
  posteriormente corrigidos;
- definir como comunicar carga parcial e indisponibilidade temporária.

## 2. Panorama financeiro

### Nome e finalidade negocial

Apresentar uma visão consolidada da movimentação financeira do cliente em um
período, mostrando receitas, gastos, resultado e composição das despesas.

### Perguntas de clientes

- “Quanto entrou e quanto saiu este mês?”
- “Qual foi meu resultado em junho?”
- “Como foi meu mês?”
- “Quais foram meus principais gastos?”
- “Quanto apliquei, resgatei e paguei de fatura?”

### Significado dos valores

**Definido no produto anterior:**

- **entradas:** créditos tratados como receita no período;
- **gastos:** débitos tratados como consumo ou despesa no período;
- **resultado do período:** entradas menos gastos;
- **composição por grupo:** participação de cada grupo no total de gastos;
- **principais categorias:** categorias com maior valor de gastos;
- **ticket médio:** gasto total dividido pela quantidade de lançamentos de
  saída considerados;
- **percentual coberto pelo ranking:** parcela do gasto representada pelas
  categorias exibidas.

O resultado do período não representa saldo disponível em conta, patrimônio ou
capacidade futura de pagamento.

### Transações consideradas e excluídas

**Definido no produto anterior:**

- entram no total de gastos apenas as saídas tratadas como consumo ou despesa;
- entram no total de receitas apenas as entradas tratadas como receita;
- aplicação, resgate de investimento e pagamento de fatura ficam fora dos
  totais de gastos, receitas e resultado;
- esses movimentos permanecem disponíveis em totais próprios;
- as demais saídas permanecem no conceito de gasto conforme a classificação
  recebida, inclusive transferências e saques que não pertençam aos grupos
  patrimoniais excluídos;
- lançamentos sem grupo conhecido não desaparecem: entram como “Sem grupo”.

### Regras e exceções

**Definido no produto anterior:**

- aplicação é movimentação do próprio dinheiro, não gasto;
- resgate é movimentação do próprio dinheiro, não receita;
- pagamento de fatura não é novo consumo, pois representa a quitação de compras
  que já foram registradas;
- se o cliente perguntar especificamente por aplicação, resgate ou fatura, os
  respectivos valores devem ser apresentados;
- a composição por grupo deve trazer valor e percentual;
- os percentuais dos grupos representam a distribuição do total de gastos e
  fecham 100% após arredondamento;
- rankings parciais não devem ser descritos como se representassem todas as
  categorias;
- valores derivados devem vir calculados pela capacidade financeira, sem conta
  feita durante a elaboração da resposta.

### Limitações conhecidas

- o resultado depende da classificação recebida para cada lançamento;
- um lançamento sem grupo reduz a capacidade explicativa da composição;
- o resultado do mês corrente é parcial;
- o panorama descreve movimentação observada, não orçamento, patrimônio ou
  previsão.
- transferências entre contas do próprio cliente não são identificadas como tal
  pela regra atual e podem permanecer nos gastos;
- saque representa a saída de dinheiro da conta; o uso posterior do dinheiro em
  espécie não está disponível para análise.

### Decisões negociais pendentes

- confirmar se o termo apresentado ao cliente será sempre “resultado do
  período”, evitando “saldo”;
- definir se haverá uma visão adicional de fluxo total da conta que inclua
  aplicação, resgate e fatura, sem chamá-los de gasto ou receita;
- definir se transferências entre contas próprias devem ser excluídas dos gastos
  e quais dados permitem reconhecê-las;
- ratificar o tratamento de saques no conceito de gasto;
- definir quantos grupos ou categorias devem aparecer por padrão na resposta.

## 3. Consulta de lançamentos

### Nome e finalidade negocial

Localizar transações específicas para responder perguntas sobre compras,
recebimentos, estabelecimentos, categorias, grupos, períodos e faixas de valor.

### Perguntas de clientes

- “Quais compras fiz acima de R$ 500?”
- “Quanto gastei com Uber em junho?”
- “Quais Pix aparecem no meu extrato?”
- “Quanto gastei em Farmácias?”
- “Quais foram meus maiores gastos excluindo transferências?”

### Significado dos resultados

**Definido no produto anterior:**

- cada item representa um lançamento individual, com data, descrição, categoria,
  valor, natureza e instituição quando disponível;
- a quantidade total representa todos os lançamentos que atendem ao critério;
- a lista apresentada pode ser apenas uma seleção dos maiores resultados;
- totais associados à consulta representam somente o conjunto filtrado.

### Transações consideradas e excluídas

**Definido no produto anterior:**

- filtros de período incluem as datas inicial e final;
- filtros diferentes são combinados, restringindo progressivamente o resultado;
- vários termos de descrição funcionam como alternativas entre si;
- filtros de valor consideram o valor absoluto, tanto para entradas quanto para
  saídas;
- categorias podem ser incluídas ou excluídas em conjunto;
- movimentações patrimoniais continuam consultáveis, mesmo quando não entram no
  conceito de gasto ou receita.

### Regras e exceções

**Definido no produto anterior:**

- categoria e grupo são conceitos diferentes: grupo reúne várias categorias;
- um estabelecimento ou marca deve ser procurado na descrição do lançamento,
  não tratado automaticamente como categoria;
- uma busca por grupo considera todas as categorias pertencentes ao grupo;
- não se deve afirmar que algo não existe sem executar uma busca com o critério
  correspondente;
- quando a lista for limitada, a resposta deve informar quantos resultados
  existem e quantos estão sendo exibidos;
- uma descrição agregada não pode ser apresentada como lançamento individual;
- nomes de categorias e grupos devem respeitar os rótulos presentes nos dados.

### Limitações conhecidas

- variações de descrição podem exigir sinônimos ou termos alternativos;
- a busca não comprova a identidade real de um estabelecimento;
- listas limitadas não permitem descrever aquilo que ficou fora;
- critérios sem suporte devem ser informados como limitação, nunca convertidos
  em uma falsa ausência.

### Decisões negociais pendentes

- decidir se será possível filtrar explicitamente somente entradas ou somente
  saídas;
- decidir se instituição será um critério de busca;
- definir a ordenação padrão: maior valor, mais recente ou outra opção;
- definir o limite padrão e o máximo de lançamentos exibidos.

## 4. Composição e evolução dos gastos

### Nome e finalidade negocial

Mostrar como os gastos se distribuem e evoluem, permitindo comparações por
categoria, grupo, descrição, data, dia da semana e mês.

### Perguntas de clientes

- “Em qual mês gastei mais?”
- “Em qual dia da semana costumo gastar mais?”
- “Quais categorias mais pesaram?”
- “Onde gasto com mais frequência?”
- “Quais foram os dias de maior gasto?”

### Significado dos valores

**Definido no produto anterior:**

- **total:** soma dos gastos pertencentes ao agrupamento;
- **quantidade:** número de lançamentos de saída no agrupamento;
- **ticket médio:** total dividido pela quantidade de lançamentos;
- **frequência:** quantidade de ocorrências, independentemente do valor;
- **participação:** percentual do gasto do recorte representado pelo grupo;
- **evolução mensal:** valores e participação de cada mês no período analisado.

Maior valor e maior frequência respondem perguntas diferentes. O item mais
frequente não é necessariamente aquele com maior impacto financeiro.

### Transações consideradas e excluídas

**Definido no produto anterior:**

- entram somente saídas tratadas como gasto;
- aplicação, resgate e pagamento de fatura ficam fora das análises de consumo;
- filtros de período, categoria, grupo e descrição são respeitados antes do
  agrupamento;
- lançamentos sem grupo conhecido permanecem em “Sem grupo”.

### Regras e exceções

**Definido no produto anterior:**

- agrupamento por descrição reúne lançamentos com a mesma descrição e deve
  informar quantos lançamentos compõem o total;
- agrupamento por data representa um dia específico;
- agrupamento por dia da semana reúne todas as segundas, terças e assim por
  diante dentro do período;
- agrupamento mensal segue meses de calendário;
- percentuais mensais representam a participação de cada mês no gasto do
  período e fecham 100% após arredondamento;
- o mês corrente deve ser identificado como parcial;
- grupo e categoria não podem ser usados como sinônimos.

### Limitações conhecidas

- descrições textualmente diferentes do mesmo estabelecimento podem aparecer
  em grupos distintos;
- maior gasto em determinado dia ou mês não demonstra causa;
- seis meses são suficientes para observar comportamento recente, mas limitados
  para sazonalidade anual;
- comparar um mês parcial com meses completos pode induzir interpretação errada.

### Decisões negociais pendentes

- definir se o mês corrente parcial participa de rankings mensais;
- definir se comparações devem usar valores acumulados até o mesmo dia de cada
  mês ou apenas meses encerrados;
- definir se haverá consolidação negocial de descrições equivalentes do mesmo
  estabelecimento;
- definir quais dimensões devem ser apresentadas por padrão em um panorama.

## 5. Lançamentos atípicos

### Nome e finalidade negocial

Sinalizar lançamentos de saída cujo valor é significativamente diferente do
comportamento recente observado na mesma categoria.

### Perguntas de clientes

- “Quais gastos fugiram do meu padrão?”
- “Tive alguma compra muito diferente do normal?”
- “Existe algum valor incomum em Alimentação?”
- “Quais gastos merecem minha atenção?”

### Significado dos resultados

**Definido no produto anterior:**

- um lançamento atípico é estatisticamente distante da média dos valores da
  própria categoria;
- a comparação é feita em número de desvios-padrão;
- tanto valores muito acima quanto muito abaixo do padrão podem ser marcados;
- o resultado mostra categoria, valor, data, descrição e grau de afastamento.

Atípico significa diferente do histórico observado. Não significa fraude,
erro, desperdício, gasto inadequado ou comportamento ruim.

### Transações consideradas e excluídas

**Definido no produto anterior:**

- entram somente lançamentos de saída;
- a comparação ocorre dentro da categoria do próprio lançamento;
- aplicação, resgate e pagamento de fatura ficam fora da análise de gasto;
- categorias com menos de cinco lançamentos são ignoradas;
- categorias sem variação de valores não geram alerta.

### Regras e exceções

**Regra existente no produto anterior:**

- um lançamento é marcado quando seu afastamento absoluto supera dois
  desvios-padrão da média da categoria;
- o cálculo considera a população observada no período disponível.

### Limitações conhecidas

- seis meses podem não representar o padrão real de despesas sazonais;
- categorias amplas podem misturar comportamentos diferentes;
- categorias com menos de cinco lançamentos não são avaliadas;
- valores legítimos e esperados podem ser estatisticamente atípicos;
- o método avalia valor, não contexto, recorrência contratual ou intenção.

### Decisões negociais pendentes

- ratificar se dois desvios-padrão e cinco lançamentos são regras de produto;
- decidir se valores excepcionalmente baixos devem aparecer ao cliente;
- definir a linguagem e o nível de destaque do alerta;
- decidir se haverá tratamento específico para despesas sazonais;
- definir se o cliente poderá ajustar sensibilidade ou ocultar categorias.

## 6. Estatísticas dos gastos

### Nome e finalidade negocial

Explicar o comportamento típico dos valores gastos e a regularidade de cada
categoria sem depender apenas de médias.

### Perguntas de clientes

- “Qual é o valor típico dos meus gastos?”
- “Em que faixa ficam normalmente minhas compras?”
- “Qual categoria varia mais?”
- “Meus gastos com Alimentação são regulares?”
- “Qual é o ticket mediano das minhas despesas?”

### Significado dos valores

**Definido no produto anterior:**

- **mediana:** valor central; metade dos lançamentos fica abaixo e metade acima;
- **primeiro quartil:** valor abaixo do qual estão aproximadamente 25% dos
  lançamentos;
- **terceiro quartil:** valor abaixo do qual estão aproximadamente 75% dos
  lançamentos;
- **faixa central:** intervalo entre o primeiro e o terceiro quartil, contendo a
  metade central dos lançamentos;
- **desvio-padrão:** variação dos valores em reais;
- **coeficiente de variação:** variação relativa ao tamanho médio da categoria,
  útil para comparar categorias de valores diferentes.

### Transações consideradas e excluídas

**Definido no produto anterior:**

- entram somente saídas tratadas como gasto;
- aplicação, resgate e pagamento de fatura ficam fora;
- mediana e quartis consideram os lançamentos do recorte solicitado;
- a dispersão por categoria exige pelo menos cinco lançamentos na categoria.

### Regras e exceções

**Definido no produto anterior:**

- resultados monetários são arredondados para centavos;
- uma consulta sem gastos devolve ausência de dados úteis, não uma conclusão de
  estabilidade;
- ao dizer que uma categoria varia mais, deve-se indicar se a comparação usa
  variação em reais ou variação proporcional.

### Limitações conhecidas

- estatísticas descrevem o período observado e não preveem valores futuros;
- uma categoria heterogênea pode produzir uma faixa ampla pouco explicativa;
- cinco ocorrências permitem o cálculo, mas ainda podem representar uma amostra
  limitada;
- a mediana não informa frequência mensal nem recorrência contratual.

### Decisões negociais pendentes

- decidir como comunicar amostra pequena mesmo quando o mínimo de cinco for
  atingido;
- definir qual medida de variabilidade será priorizada na experiência;
- definir se a faixa central será apresentada espontaneamente ou apenas quando
  solicitada.

## 7. Possíveis repetições

### Nome e finalidade negocial

Localizar lançamentos de saída idênticos que possam merecer conferência pelo
cliente.

### Perguntas de clientes

- “Tenho alguma cobrança repetida?”
- “Existem lançamentos iguais no mesmo dia?”
- “Quanto pode ter saído em duplicidade?”
- “Quais repetições tiveram maior impacto?”

### Significado dos resultados

**Definido no produto anterior:**

- um grupo repetido possui a mesma data, a mesma descrição e o mesmo valor;
- quantidade de ocorrências é o número de lançamentos idênticos no grupo;
- valor excedente é o valor das ocorrências além da primeira;
- excedente total soma os valores excedentes de todos os grupos encontrados,
  inclusive os que não aparecem na lista resumida.

O valor excedente representa impacto potencial caso as ocorrências adicionais
sejam indevidas. Ele não confirma cobrança duplicada.

### Transações consideradas e excluídas

**Definido no produto anterior:**

- entram somente lançamentos de saída;
- aplicação e pagamento de fatura também são considerados, pois uma repetição
  nesses movimentos pode representar saída duplicada de dinheiro;
- créditos repetidos não entram nessa análise;
- um lançamento isolado nunca é classificado como repetido.

### Regras e exceções

**Definido no produto anterior:**

- lançamentos idênticos são apresentados como possíveis repetições, nunca como
  fraude ou erro confirmado;
- duas compras legítimas de mesmo valor no mesmo estabelecimento e dia também
  podem ser sinalizadas;
- quantidade total de grupos e impacto potencial devem considerar todos os
  grupos encontrados, não somente os principais exibidos.

### Limitações conhecidas

- a regra não usa autorização, identificador da compra ou confirmação do
  estabelecimento;
- pequenas diferenças na descrição ou no valor impedem a identificação;
- repetições ocorridas em dias diferentes não são detectadas;
- a capacidade não acompanha contestação, estorno ou resolução posterior.

### Decisões negociais pendentes

- ratificar a expressão “possível repetição” e o uso de “valor excedente”;
- decidir se instituição ou identificador transacional devem fazer parte do
  critério;
- decidir se repetições em dias próximos devem ser consideradas;
- definir o tratamento de parcelas, assinaturas e compras legitimamente iguais;
- definir se estornos posteriores eliminam ou apenas contextualizam o alerta.

## 8. Indicadores financeiros

### Nome e finalidade negocial

Relacionar entradas, gastos e renda para ajudar o cliente a compreender seu
nível de comprometimento financeiro e a evolução recente das categorias.

### Perguntas de clientes

- “Quanto da minha renda estou gastando?”
- “Qual é minha taxa de poupança?”
- “Minha situação melhorou?”
- “Qual categoria mais aumentou em relação ao mês anterior?”
- “Minha renda está cobrindo meus gastos?”

### Significado dos indicadores

**Regra existente no produto anterior:**

- **percentual de gasto sobre a renda:** gastos divididos pela renda mensal
  considerada;
- **taxa de poupança implícita:** entradas menos gastos, dividido pelas entradas;
- **variação mensal por categoria:** diferença percentual entre o gasto do mês
  mais recente e o gasto do mês anterior.

A taxa de poupança é chamada de implícita porque deriva das movimentações
observadas. Ela não comprova aumento de patrimônio nem considera recursos fora
do histórico analisado.

### Transações consideradas e excluídas

**Definido no produto anterior:**

- gastos, entradas e variações excluem aplicação, resgate e pagamento de fatura;
- a renda informada pelo cliente tem prioridade quando fornecida;
- na ausência de renda informada, o produto anterior estima renda pela mediana
  dos créditos classificados como salário;
- sem renda válida, o percentual de gasto sobre renda não é calculado;
- sem entradas, a taxa de poupança implícita não é calculada;
- a variação mensal usa as duas competências mensais mais recentes disponíveis.

### Regras e exceções

**Regra existente no produto anterior:**

- categoria sem gasto no mês anterior e com gasto no mês atual produz crescimento
  sem base percentual comparável;
- somente categorias com gasto no mês mais recente entram na comparação;
- o cálculo usa os lançamentos disponíveis, mesmo quando o mês mais recente está
  parcial.

### Limitações conhecidas

- renda identificada no extrato pode não representar toda a renda do cliente;
- a mediana de créditos individuais de salário pode ser inadequada quando há
  múltiplos pagamentos no mesmo mês;
- taxa de poupança implícita é fluxo, não patrimônio acumulado;
- comparar mês parcial com mês completo pode distorcer a variação;
- uma categoria nova não possui base percentual no mês anterior;
- seis meses são insuficientes para avaliar tendência de longo prazo.

### Decisões negociais pendentes

Estas são as decisões mais críticas do estudo:

- definir o período usado no percentual de gasto sobre renda;
- definir se renda deve ser declarada, estimada ou obtida de outra fonte;
- definir como consolidar múltiplos salários no mesmo mês;
- decidir se “taxa de poupança” é o nome adequado ou se deve ser apresentada
  como “resultado financeiro sobre as entradas”;
- decidir se o mês corrente parcial será excluído da variação mensal;
- definir como apresentar categoria nova, para a qual não existe percentual de
  crescimento comparável;
- definir critérios para dizer que a situação “melhorou” ou “piorou”; hoje os
  números permitem comparação, mas não existe uma regra negocial completa para
  esse julgamento.

## 9. Explicação de categorias

### Nome e finalidade negocial

Explicar o significado das categorias e dos grupos usados no Minhas Finanças,
ajudando o cliente a interpretar como seus lançamentos são organizados.

### Perguntas de clientes

- “O que entra em Alimentação?”
- “O que significa Compras Diversas?”
- “Quais categorias fazem parte de Saúde?”
- “Esse lançamento está em qual categoria?”
- “Qual é a diferença entre categoria e grupo?”

### Significado das informações

**Definido no produto anterior:**

- categoria representa a classificação específica exibida no extrato;
- grupo representa um agrupamento mais amplo que pode reunir várias categorias;
- a definição informa o que deve e o que não deve ser incluído;
- a natureza informa se a categoria é normalmente associada a entrada ou saída.

### Transações e informações consideradas

**Definido no produto anterior:**

- a explicação vem do catálogo versionado de categorias;
- o nome exibido no lançamento é preservado;
- o grupo vem da classificação macro disponível para o lançamento;
- o agente não deve renomear nem deduzir uma categoria a partir de opinião
  própria;
- para marcas e estabelecimentos, a categoria deve ser observada nos
  lançamentos encontrados, não presumida por conhecimento geral.

### Regras e exceções

**Definido no produto anterior:**

- grupo e categoria não são sinônimos;
- termos subjetivos, como essencial, supérfluo, fixo ou desnecessário, não são
  categorias oficiais;
- se o cliente quiser um agrupamento subjetivo, ele deve indicar quais
  categorias deseja incluir;
- uma categoria não pode ser declarada ausente sem consulta aos dados do
  cliente;
- categoria desconhecida ou sem definição deve gerar esclarecimento ou
  limitação, não uma definição inventada.

### Limitações conhecidas

- a capacidade explica a classificação, mas não altera o lançamento;
- a qualidade da resposta depende da atualização do catálogo;
- estabelecimentos iguais podem aparecer em categorias diferentes conforme o
  lançamento recebido;
- categorias sem definição detalhada podem ter explicação limitada.

### Decisões negociais pendentes

- definir governança, responsável e periodicidade de atualização do catálogo;
- definir tratamento de categorias personalizadas ou ainda não catalogadas;
- decidir se o agente poderá sugerir correção de categoria, sem executá-la;
- definir como comunicar divergências entre a categoria exibida e a expectativa
  do cliente.

## Regras transversais de interpretação

### Definidas no produto anterior

1. Todo número sobre o cliente deve vir dos dados financeiros disponíveis.
2. Percentuais, médias, diferenças, medianas e demais valores derivados devem
   ser produzidos pela capacidade financeira, não calculados livremente na
   resposta.
3. “Resultado do período” é diferente de saldo em conta e de patrimônio.
4. Aplicação, resgate e pagamento de fatura são movimentações patrimoniais e não
   compõem gasto ou receita, salvo quando o cliente pergunta diretamente por
   esses movimentos.
5. Lista de lançamentos pode ser parcial; quantidade total e limitação devem ser
   comunicadas.
6. Um agregado por descrição pode reunir vários lançamentos e não deve ser
   apresentado como transação individual.
7. Ausência só pode ser afirmada depois de uma consulta que aplique o critério
   solicitado.
8. Período completo do extrato e período dos resultados filtrados são conceitos
   diferentes.
9. Mês corrente parcial deve ser identificado como parcial.
10. Atípico não significa fraude e repetido não significa cobrança indevida.
11. Grupo, categoria, estabelecimento e descrição são conceitos distintos.
12. Agrupamentos subjetivos dependem da definição do cliente.

### Decisões negociais prioritárias

Antes de considerar a especificação concluída, o negócio precisa decidir:

1. a definição exata dos seis meses no novo serviço;
2. o tratamento de mês parcial em comparações e indicadores;
3. a fonte e a regra de consolidação da renda mensal;
4. o nome e a interpretação da taxa de poupança implícita;
5. os critérios de apresentação de atípicos;
6. os critérios de possíveis repetições;
7. o escopo de contas, instituições, cartões, estornos e lançamentos pendentes;
8. a governança do catálogo de categorias;
9. se haverá uma visão separada de fluxo total da conta, incluindo movimentação
   patrimonial;
10. o tratamento de transferências entre contas próprias e de saques;
11. quais julgamentos o agente poderá fazer, como “melhorou”, “piorou”,
    “excessivo” ou “saudável”.

## Capacidades não previstas nesta etapa

O produto anterior não sustenta, por si só:

- previsão de gastos ou renda;
- orçamento e acompanhamento de metas;
- recomendação de investimentos;
- confirmação de fraude ou cobrança indevida;
- comparação com outros clientes;
- avaliação de saúde financeira por referência externa;
- alteração automática de categorias;
- análise confiável de sazonalidade anual;
- explicação causal de por que um gasto ocorreu;
- análise de patrimônio, dívidas ou produtos fora das transações recebidas.
