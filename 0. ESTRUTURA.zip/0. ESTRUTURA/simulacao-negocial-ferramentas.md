# Simulação negocial do assistente financeiro

<!-- markdownlint-disable MD013 MD024 -->

> Todos os nomes, valores e lançamentos desta simulação são fictícios. O
> objetivo é demonstrar como as ferramentas trabalham juntas no LangGraph.

## Cenário

- data da conversa: 9 de outubro de 2026;
- histórico disponível: 1º de maio a 9 de outubro de 2026;
- quantidade de lançamentos: 842;
- renda mensal informada pelo cliente: R$ 8.500,00;
- as transações são carregadas uma vez e reutilizadas durante a sessão.

## 1. Pergunta fácil: resumo do mês

**Cliente:** Quanto entrou e quanto saiu este mês?

### Execução interna

Como esta é a primeira pergunta financeira da sessão, o agente carrega os
dados antes de calcular o resumo.

```text
obter_transacoes_cliente()
```

Resultado simplificado:

```json
{
  "status": "carregado",
  "periodo_inicio": "2026-05-01",
  "periodo_fim": "2026-10-09",
  "quantidade_lancamentos": 842
}
```

Em seguida, o agente solicita o resumo do mês corrente:

```text
obter_resumo_financeiro(
  data_inicio="2026-10-01",
  data_fim="2026-10-09"
)
```

Resultado simplificado:

```json
{
  "total_entrada": "8500.00",
  "total_gastos": "5230.40",
  "resultado": "3269.60",
  "total_aplicacoes": "1000.00",
  "total_resgates": "0.00",
  "total_fatura": "2100.00"
}
```

### Resposta ao cliente

De 1º a 9 de outubro, entraram **R$ 8.500,00** e seus gastos somaram
**R$ 5.230,40**. O resultado do período está positivo em **R$ 3.269,60**.

Além disso, houve **R$ 1.000,00 em aplicações** e **R$ 2.100,00 em pagamento de
fatura**. Esses valores estão separados dos gastos de consumo. Como outubro
ainda está em andamento, o resultado considera somente os lançamentos até o
dia 9.

## 2. Pergunta intermediária: comparação mensal

**Cliente:** Em qual dos últimos seis meses eu gastei mais?

### Execução interna

O extrato já está disponível na sessão. O agente não repete a carga.

```text
agrupar_lancamentos(
  dimensao="mes"
)
```

Resultado simplificado:

| Mês | Gastos |
| --- | ---: |
| Maio | R$ 4.620,00 |
| Junho | R$ 5.080,00 |
| Julho | R$ 4.910,00 |
| Agosto | R$ 6.420,00 |
| Setembro | R$ 5.610,00 |
| Outubro, até o dia 9 | R$ 5.230,40 |

### Resposta ao cliente

Seu maior gasto ocorreu em **agosto, com R$ 6.420,00**. Outubro já soma
R$ 5.230,40, mas ainda é um mês parcial e não deve ser comparado como se
estivesse encerrado.

## 3. Pergunta intermediária composta: causas do maior mês

**Cliente:** E o que mais pesou em agosto?

### Execução interna

O agente combina um agrupamento com a consulta dos maiores lançamentos.

```text
agrupar_lancamentos(
  dimensao="grupo",
  data_inicio="2026-08-01",
  data_fim="2026-08-31",
  top_n=5
)
```

```text
consultar_lancamentos(
  data_inicio="2026-08-01",
  data_fim="2026-08-31",
  limite=3
)
```

Resultados simplificados:

| Grupo | Total |
| --- | ---: |
| Casa | R$ 2.350,00 |
| Alimentação | R$ 1.540,00 |
| Saúde | R$ 1.180,00 |
| Transporte | R$ 780,00 |
| Outros | R$ 570,00 |

Maiores lançamentos individuais:

| Descrição | Grupo | Valor |
| --- | --- | ---: |
| Aluguel Residencial | Casa | R$ 1.800,00 |
| Clínica Vida | Saúde | R$ 1.180,00 |
| Supermercado Central | Alimentação | R$ 620,00 |

### Resposta ao cliente

Em agosto, o grupo que mais pesou foi **Casa, com R$ 2.350,00**, seguido por
**Alimentação, com R$ 1.540,00**, e **Saúde, com R$ 1.180,00**.

Os maiores lançamentos individuais foram o aluguel de R$ 1.800,00, um
lançamento de R$ 1.180,00 na Clínica Vida e uma compra de R$ 620,00 no
Supermercado Central.

## 4. Pergunta difícil: comportamento fora do padrão

**Cliente:** Algum gasto de agosto fugiu do meu padrão?

### Execução interna

```text
detectar_lancamentos_atipicos(
  data_inicio="2026-08-01",
  data_fim="2026-08-31",
  limite=5
)
```

Resultado simplificado:

```json
{
  "quantidade_atipicos": 2,
  "lancamentos": [
    {
      "descricao": "Clinica Vida",
      "categoria": "Servicos de Saude",
      "valor": "1180.00"
    },
    {
      "descricao": "Supermercado Central",
      "categoria": "Supermercado",
      "valor": "620.00"
    }
  ]
}
```

### Resposta ao cliente

Dois lançamentos ficaram acima do comportamento normalmente observado nas
respectivas categorias: **R$ 1.180,00 na Clínica Vida** e **R$ 620,00 no
Supermercado Central**.

Isso significa apenas que os valores foram estatisticamente diferentes do seu
histórico recente. Não indica erro ou fraude.

## 5. Pergunta difícil: possível repetição

**Cliente:** Tem alguma cobrança que pode estar repetida?

### Execução interna

```text
detectar_lancamentos_repetidos(
  data_inicio="2026-05-01",
  data_fim="2026-10-09",
  limite=10
)
```

Resultado simplificado:

```json
{
  "quantidade_grupos": 1,
  "repeticoes": [
    {
      "data": "2026-09-15",
      "descricao": "Streaming Exemplo",
      "valor": "39.90",
      "ocorrencias": 2,
      "valor_excedente": "39.90"
    }
  ]
}
```

### Resposta ao cliente

Encontrei **dois lançamentos de R$ 39,90**, com a mesma descrição e na mesma
data, para Streaming Exemplo. O possível valor repetido é de **R$ 39,90**.

Essa coincidência merece conferência, mas os dados do extrato sozinhos não
confirmam que houve cobrança indevida.

## 6. Pergunta difícil: estatísticas

**Cliente:** Qual é o valor típico dos meus gastos com alimentação?

### Execução interna

```text
calcular_estatisticas_gastos(
  grupo="Alimentacao"
)
```

Resultado simplificado:

```json
{
  "quantidade_lancamentos": 96,
  "mediana": "84.70",
  "percentil_25": "42.30",
  "percentil_75": "156.80"
}
```

### Resposta ao cliente

Considerando 96 lançamentos de alimentação, o valor típico, representado pela
mediana, foi de **R$ 84,70**. Metade dos lançamentos centrais ficou entre
**R$ 42,30 e R$ 156,80**.

## 7. Indicadores financeiros

**Cliente:** Com uma renda de R$ 8.500,00, como está minha situação neste mês?

### Execução interna

```text
calcular_indicadores_financeiros(
  renda_mensal_informada="8500.00",
  data_inicio="2026-10-01",
  data_fim="2026-10-09"
)
```

Resultado simplificado:

```json
{
  "percentual_renda_comprometida": "61.53",
  "taxa_poupanca": "38.47",
  "periodo_parcial": true
}
```

### Resposta ao cliente

Até o dia 9, seus gastos representam **61,53% da renda informada**. A diferença
entre a renda e os gastos equivale a **38,47%**.

Como outubro ainda está em andamento, esses percentuais descrevem apenas o
período atual e poderão mudar com os próximos lançamentos.

## 8. Explicação de categoria

**Cliente:** O que entra em Compras Diversas?

### Execução interna

```text
explicar_categoria(
  categoria="Compras Diversas"
)
```

### Resposta ao cliente

Compras Diversas reúne compras de produtos que não se encaixam de forma mais
específica em outra categoria do seu extrato. A definição também informa os
tipos de compra que devem ser direcionados para categorias mais específicas.

## Resumo da simulação

| Pergunta | Tools executadas |
| --- | --- |
| Quanto entrou e quanto saiu? | `obter_transacoes_cliente` + `obter_resumo_financeiro` |
| Em qual mês gastei mais? | `agrupar_lancamentos` |
| O que mais pesou em agosto? | `agrupar_lancamentos` + `consultar_lancamentos` |
| Algum gasto fugiu do padrão? | `detectar_lancamentos_atipicos` |
| Existe possível repetição? | `detectar_lancamentos_repetidos` |
| Qual é meu gasto típico? | `calcular_estatisticas_gastos` |
| Como estão meus indicadores? | `calcular_indicadores_financeiros` |
| O que entra em uma categoria? | `explicar_categoria` |
