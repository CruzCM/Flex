# Visão negocial da refatoração mínima

<!-- markdownlint-disable MD013 -->

## Resultado esperado

O assistente passará a consultar os últimos seis meses de transações do cliente
e usar esses dados para responder perguntas sobre sua vida financeira. O
cliente não precisará enviar extrato, informar conta ou explicar como seus
dados devem ser carregados.

Na primeira pergunta que depender do extrato, o assistente carregará os dados
do cliente. Durante a mesma sessão, esses dados poderão ser reutilizados nas
perguntas seguintes, evitando novas consultas desnecessárias.

A refatoração preserva as regras financeiras que já existem. O foco da primeira
entrega é conectar a fonte de dados correta e organizar as capacidades atuais
em ferramentas mais claras para o agente.

## Tools finais da primeira entrega

| # | Tool | O que faz para o negócio | Parâmetros informados pelo agente | Resultado entregue |
| ---: | --- | --- | --- | --- |
| 1 | `obter_transacoes_cliente` | Disponibiliza ao assistente os últimos seis meses de movimentações do cliente | Nenhum; a identidade vem automaticamente da sessão autenticada | Período disponível, quantidade de lançamentos e confirmação de que os dados estão prontos para análise |
| 2 | `obter_resumo_financeiro` | Apresenta uma visão geral da situação financeira | Período, quantidade de destaques e inclusão excepcional de movimentações patrimoniais | Entradas, gastos, resultado, principais grupos e categorias; aplicações, resgates e fatura aparecem separadamente |
| 3 | `consultar_lancamentos` | Localiza movimentações específicas no extrato | Período, categoria, grupo, termos da descrição, categorias incluídas ou excluídas, faixa de valor e limite de resultados | Lançamentos encontrados, valores totais e quantidade; informa quando a lista foi limitada |
| 4 | `agrupar_lancamentos` | Compara e ordena os gastos por uma dimensão | Dimensão, período, categoria ou grupo, quantidade de destaques e ordenação | Totais e quantidades por categoria, grupo, descrição, data, dia da semana ou mês |
| 5 | `detectar_lancamentos_atipicos` | Identifica lançamentos que fogem do padrão observado | Período, categoria ou grupo e limite de resultados | Lançamentos atípicos e contexto estatístico da detecção |
| 6 | `calcular_estatisticas_gastos` | Descreve o comportamento típico e a variação dos gastos | Período e categoria ou grupo | Mediana, quartis e dispersão, respeitando a quantidade mínima de dados |
| 7 | `detectar_lancamentos_repetidos` | Localiza possíveis repetições no extrato | Período e limite de resultados | Grupos de lançamentos iguais, número de ocorrências e valor excedente |
| 8 | `calcular_indicadores_financeiros` | Calcula indicadores sobre a relação entre renda e gastos | Período e renda mensal informada pelo cliente, quando houver | Percentual da renda comprometida, taxa de poupança e variação mensal das categorias |
| 9 | `explicar_categoria` | Explica como uma categoria ou grupo do Minhas Finanças é formado | Nome ou código da categoria ou grupo | Definição, exemplos do que entra e do que não entra e relação com o grupo correspondente |

## Parâmetros propostos

Os nomes abaixo representam o contrato entre o agente e cada tool. Parâmetros
opcionais só serão enviados quando forem necessários para responder à pergunta.

### `obter_transacoes_cliente`

Esta tool não terá parâmetros visíveis ao agente.

| Parâmetro interno | Origem | Finalidade |
| --- | --- | --- |
| `sender_id` | Sessão autenticada | Identificar o cliente no serviço de transações |

O `sender_id` não será escrito pelo modelo, solicitado ao cliente ou registrado
no histórico da conversa.

### `obter_resumo_financeiro`

| Parâmetro | Obrigatório | Padrão | Finalidade |
| --- | --- | --- | --- |
| `data_inicio` | Não | Início do período disponível | Primeiro dia considerado no resumo |
| `data_fim` | Não | Final do período disponível | Último dia considerado no resumo |
| `top_n` | Não | `5` | Quantidade de grupos ou categorias em destaque, limitada de 1 a 20 |
| `incluir_movimentacoes_patrimoniais` | Não | `false` | Incluir aplicações, resgates e fatura nos totais somente quando o cliente pedir explicitamente |

Quando uma das datas for informada, a outra também deverá ser informada. Sem
datas, a tool considera todo o histórico disponível de seis meses.

### `consultar_lancamentos`

| Parâmetro | Obrigatório | Padrão | Finalidade |
| --- | --- | --- | --- |
| `data_inicio` | Não | Início do período disponível | Primeiro dia da busca |
| `data_fim` | Não | Final do período disponível | Último dia da busca |
| `categoria` | Não | Todas | Buscar uma categoria específica |
| `grupo` | Não | Todos | Buscar um grupo financeiro, como Alimentação ou Transporte |
| `termos_descricao` | Não | Nenhum | Buscar um ou mais termos presentes na descrição; os termos funcionam como alternativas |
| `categorias_incluir` | Não | Todas | Restringir a busca a um conjunto de categorias |
| `categorias_excluir` | Não | Nenhuma | Remover um conjunto de categorias do resultado |
| `valor_minimo` | Não | Sem mínimo | Menor valor absoluto aceito na busca |
| `valor_maximo` | Não | Sem máximo | Maior valor absoluto aceito na busca |
| `limite` | Não | `10` | Quantidade máxima de lançamentos devolvidos ao agente, limitada de 1 a 50 |

Os filtros utilizados são combinados. Os termos de descrição são a única
exceção: um lançamento pode corresponder a qualquer um dos termos informados.

### `agrupar_lancamentos`

| Parâmetro | Obrigatório | Padrão | Finalidade |
| --- | --- | --- | --- |
| `dimensao` | Sim | — | Agrupar por `categoria`, `grupo`, `descricao`, `data`, `dia_semana` ou `mes` |
| `data_inicio` | Não | Início do período disponível | Primeiro dia da análise |
| `data_fim` | Não | Final do período disponível | Último dia da análise |
| `categoria` | Não | Todas | Analisar somente uma categoria |
| `grupo` | Não | Todos | Analisar somente um grupo financeiro |
| `top_n` | Não | `5` | Quantidade de resultados em destaque, limitada de 1 a 20 |
| `ordenar_por` | Não | `total` | Ordenar por `total` ou `frequencia` quando a dimensão permitir |

### `detectar_lancamentos_atipicos`

| Parâmetro | Obrigatório | Padrão | Finalidade |
| --- | --- | --- | --- |
| `data_inicio` | Não | Início do período disponível | Primeiro dia da análise |
| `data_fim` | Não | Final do período disponível | Último dia da análise |
| `categoria` | Não | Todas | Avaliar somente uma categoria |
| `grupo` | Não | Todos | Avaliar somente um grupo financeiro |
| `limite` | Não | `10` | Quantidade máxima de lançamentos apresentados |

O critério estatístico usado para identificar um lançamento atípico será uma
regra do produto. Ele não será escolhido livremente pelo agente.

### `calcular_estatisticas_gastos`

| Parâmetro | Obrigatório | Padrão | Finalidade |
| --- | --- | --- | --- |
| `data_inicio` | Não | Início do período disponível | Primeiro dia da análise |
| `data_fim` | Não | Final do período disponível | Último dia da análise |
| `categoria` | Não | Todas | Calcular as estatísticas de uma categoria |
| `grupo` | Não | Todos | Calcular as estatísticas de um grupo financeiro |

A resposta deverá informar quando a quantidade de lançamentos for insuficiente
para uma conclusão estatística.

### `detectar_lancamentos_repetidos`

| Parâmetro | Obrigatório | Padrão | Finalidade |
| --- | --- | --- | --- |
| `data_inicio` | Não | Início do período disponível | Primeiro dia da verificação |
| `data_fim` | Não | Final do período disponível | Último dia da verificação |
| `limite` | Não | `10` | Quantidade máxima de grupos repetidos apresentados |

A resposta indicará possíveis repetições. A igualdade de data, descrição e
valor não comprova cobrança indevida ou fraude.

### `calcular_indicadores_financeiros`

| Parâmetro | Obrigatório | Padrão | Finalidade |
| --- | --- | --- | --- |
| `data_inicio` | Não | Início do período disponível | Primeiro dia usado nos indicadores |
| `data_fim` | Não | Final do período disponível | Último dia usado nos indicadores |
| `renda_mensal_informada` | Não | Renda estimada pelas transações | Usar a renda declarada pelo cliente no cálculo dos indicadores |

Sem renda informada ou estimável, a tool devolverá apenas os indicadores que
podem ser calculados com segurança.

### `explicar_categoria`

| Parâmetro | Obrigatório | Padrão | Finalidade |
| --- | --- | --- | --- |
| `categoria` | Sim | — | Identificar a categoria ou grupo por nome, slug ou código |

### Parâmetros internos compartilhados

| Parâmetro | Usado por | Finalidade |
| --- | --- | --- |
| `extrato_id` | Tools 2 a 8 | Recuperar os dados carregados para a sessão sem enviá-los ao modelo |
| Contexto de autenticação | Tool 1 | Autorizar a consulta ao serviço de transações |

Esses parâmetros internos não aparecem no contrato apresentado ao modelo nem
na conversa com o cliente.

## Como o cliente perceberá a mudança

Considerando que as ferramentas farão parte do fluxo LangGraph, o assistente
poderá:

1. acessar automaticamente os seis meses de transações do cliente;
2. responder com valores reais do extrato;
3. localizar lançamentos específicos;
4. apresentar resumos, comparações, padrões e indicadores;
5. manter o contexto financeiro ao longo da conversa;
6. informar com clareza quando não houver dados ou resultados suficientes.

## Escopo preservado

Esta primeira entrega reaproveita os cálculos e as regras atuais. Ela não cria
novos produtos financeiros nem altera a forma como gastos e receitas são
classificados.

Continuam valendo as regras atuais de separação entre consumo e movimentação
patrimonial. Aplicações, resgates e pagamentos de fatura não serão misturados
automaticamente aos gastos de consumo.

## Fora da primeira entrega

Não fazem parte desta refatoração mínima:

- previsão de gastos futuros;
- criação ou acompanhamento de orçamento;
- simulações financeiras;
- recomendação de investimentos;
- comparação com outros clientes;
- alteração automática de categorias;
- ampliação do histórico para além dos seis meses fornecidos pelo serviço.

## Por que nove tools

As nove tools representam operações diferentes: carregar, resumir, localizar,
agrupar, detectar atípicos, calcular estatísticas, detectar repetições, calcular
indicadores e explicar categorias.

Essa separação evita uma tool genérica com vários modos de funcionamento. A
refatoração continua pequena porque as novas tools serão wrappers finos sobre
as funções e cálculos já existentes. A lógica financeira não precisa ser
reescrita para que o agente receba contratos mais claros.
