"""Exporta o projeto inteiro para um arquivo ZIP.

Execute este arquivo diretamente pelo F5 / Run Python.
"""

from __future__ import annotations

import sys
import zipfile
from datetime import datetime
from pathlib import Path
from tkinter import Tk, filedialog, messagebox


PASTAS_IGNORADAS = {
    ".git",
    ".agents",
    "__pycache__",
    ".ipynb_checkpoints",
    ".pytest_cache",
    ".mypy_cache",
}

EXTENSOES_IGNORADAS = {
    ".pyc",
    ".pyo",
}


def raiz_projeto() -> Path:
    return Path(__file__).resolve().parent


def nome_padrao(raiz: Path) -> str:
    agora = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{raiz.name}_{agora}.zip"


def escolher_destino(raiz: Path) -> Path:
    janela = Tk()
    janela.withdraw()
    janela.attributes("-topmost", True)

    caminho = filedialog.asksaveasfilename(
        title="Salvar exportacao do projeto",
        initialdir=str(raiz.parent),
        initialfile=nome_padrao(raiz),
        defaultextension=".zip",
        filetypes=[("Arquivo ZIP", "*.zip")],
    )

    janela.destroy()

    if not caminho:
        raise KeyboardInterrupt("Exportacao cancelada pelo usuario.")

    return Path(caminho).resolve()


def deve_ignorar(caminho: Path, destino: Path) -> bool:
    if caminho.resolve() == destino:
        return True

    if caminho.name in PASTAS_IGNORADAS:
        return True

    if caminho.suffix.lower() in EXTENSOES_IGNORADAS:
        return True

    return False


def arquivos_do_projeto(raiz: Path, destino: Path) -> list[Path]:
    arquivos = []

    for caminho in raiz.rglob("*"):
        if any(parte in PASTAS_IGNORADAS for parte in caminho.parts):
            continue

        if caminho.is_file() and not deve_ignorar(caminho, destino):
            arquivos.append(caminho)

    return sorted(arquivos)


def exportar_zip(raiz: Path, destino: Path) -> int:
    destino.parent.mkdir(parents=True, exist_ok=True)
    arquivos = arquivos_do_projeto(raiz, destino)

    with zipfile.ZipFile(destino, "w", compression=zipfile.ZIP_DEFLATED) as zip_saida:
        for arquivo in arquivos:
            zip_saida.write(arquivo, arquivo.relative_to(raiz))

    return len(arquivos)


def main() -> int:
    raiz = raiz_projeto()

    try:
        destino = escolher_destino(raiz)
        total = exportar_zip(raiz, destino)
    except KeyboardInterrupt:
        return 0
    except Exception as erro:
        messagebox.showerror(
            "Erro ao exportar",
            f"Nao foi possivel exportar o projeto.\n\n{erro}",
        )
        return 1

    messagebox.showinfo(
        "Exportacao concluida",
        f"Projeto exportado com sucesso.\n\nArquivo:\n{destino}\n\nItens incluidos: {total}",
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
