"""Leitura de YAML, validacao e preenchimento de placeholders."""

from __future__ import annotations

import re
import textwrap
from pathlib import Path
from typing import Any, Optional, Sequence, Union

import yaml


PLACEHOLDER_VALIDO_RE = re.compile(
    r"(?<!\{)(?:\{(PH_[A-Z0-9_]+)\}|\{\{(PH_[A-Z0-9_]+)\}\})(?!\})"
)
GRUPO_CHAVES_RE = re.compile(r"\{+[^{}\n]*\}+")
PH_SOLTO_RE = re.compile(r"(?<![A-Z0-9_])PH_[A-Z0-9_]*(?![A-Z0-9_])")


class ErroPlaceholder(ValueError):
    """Erro de template que impede a chamada ao modelo."""


def raiz_projeto(inicio: Optional[Union[str, Path]] = None) -> Path:
    atual = Path(inicio or Path.cwd()).resolve()

    for pasta in [atual] + list(atual.parents):
        if (
            (pasta / "produtos").exists()
            and (pasta / "publicos").exists()
            and (pasta / "prompts").exists()
        ):
            return pasta

    raise RuntimeError("Nao foi possivel localizar a raiz do projeto.")


def limpar_texto(texto: Any) -> Any:
    if not isinstance(texto, str):
        return texto

    return textwrap.dedent(texto).strip()


def listar_yaml(pasta: Union[str, Path], raiz: Optional[Path] = None) -> list[str]:
    diretorio = (raiz or raiz_projeto()) / Path(pasta)

    if not diretorio.exists():
        return []

    return sorted(arquivo.stem for arquivo in diretorio.glob("*.yaml"))


def carregar_yaml(
    pasta: Union[str, Path],
    nome: str,
    raiz: Optional[Path] = None,
) -> dict[str, Any]:
    arquivo = (raiz or raiz_projeto()) / Path(pasta) / f"{nome}.yaml"

    if not arquivo.exists():
        raise FileNotFoundError(f"Arquivo nao encontrado: {arquivo}")

    with arquivo.open(encoding="utf-8") as stream:
        dados = yaml.safe_load(stream)

    if dados is None:
        dados = {}

    if not isinstance(dados, dict):
        raise ValueError(f"YAML invalido: {arquivo}")

    return {chave: limpar_texto(valor) for chave, valor in dados.items()}


def validar_campos(
    dados: dict[str, Any],
    obrigatorios: Sequence[str],
    origem: str,
) -> None:
    faltantes = [campo for campo in obrigatorios if campo not in dados]

    if faltantes:
        raise ValueError(
            f"{origem} sem campos obrigatorios: " + ", ".join(faltantes)
        )


def rotulo(nome: str) -> str:
    return nome.replace("_", " ").title()


def _erro_placeholder(
    *,
    origem: str,
    campo: str,
    etapa: str,
    placeholder: str,
    motivo: str,
    titulo: str = "Template invalido.",
) -> ErroPlaceholder:
    return ErroPlaceholder(
        "\n".join(
            [
                titulo,
                "",
                "Arquivo:",
                str(origem),
                "",
                "Campo:",
                campo,
                "",
                "Etapa:",
                etapa,
                "",
                "Conteudo encontrado:",
                placeholder,
                "",
                "Motivo:",
                motivo,
                "",
                "A chamada ao modelo nao foi realizada.",
            ]
        )
    )


def _motivo_grupo_invalido(grupo: str) -> str:
    abre = len(grupo) - len(grupo.lstrip("{"))
    fecha = len(grupo) - len(grupo.rstrip("}"))
    conteudo = grupo.strip("{}")

    if abre > 2 or fecha > 2:
        return "A forma tolerada aceita somente uma chave externa adicional."
    if conteudo == "PH_" or conteudo.startswith("PH_") and conteudo.strip("_") == "PH":
        return "Nome de placeholder incompleto."
    if conteudo.startswith("ph_") or conteudo.lower().startswith("ph_"):
        return "Use PH_ em letras maiusculas."
    if not conteudo.startswith("PH_"):
        return "Todo placeholder deve comecar por {PH_}."

    return "O nome do placeholder deve conter apenas letras maiusculas, numeros e underscore."


def _fragmento_chaves(texto: str) -> str:
    for indice, caractere in enumerate(texto):
        if caractere in "{}":
            inicio = max(0, indice - 30)
            fim = min(len(texto), indice + 60)
            return texto[inicio:fim].strip()

    return texto[:60].strip()


def _validar_placeholders_texto(
    texto: str,
    *,
    origem: str,
    campo: str,
    etapa: str,
) -> None:
    if not isinstance(texto, str):
        return

    for encontrado in GRUPO_CHAVES_RE.finditer(texto):
        grupo = encontrado.group(0)

        if PLACEHOLDER_VALIDO_RE.fullmatch(grupo):
            continue

        raise _erro_placeholder(
            origem=origem,
            campo=campo,
            etapa=etapa,
            placeholder=grupo,
            motivo=_motivo_grupo_invalido(grupo),
        )

    restante = PLACEHOLDER_VALIDO_RE.sub("", texto)

    if "{" in restante or "}" in restante:
        raise _erro_placeholder(
            origem=origem,
            campo=campo,
            etapa=etapa,
            placeholder=_fragmento_chaves(restante),
            motivo="Estrutura de chaves incompleta ou invalida.",
        )

    ph_solto = PH_SOLTO_RE.search(restante)
    if ph_solto:
        raise _erro_placeholder(
            origem=origem,
            campo=campo,
            etapa=etapa,
            placeholder=ph_solto.group(0),
            motivo="Placeholders devem estar entre chaves no formato {PH_NOME}.",
        )


def placeholders(
    texto: str,
    origem: str = "texto",
    campo: str = "template",
    etapa: str = "Fluxo",
) -> list[str]:
    if not isinstance(texto, str):
        return []

    _validar_placeholders_texto(texto, origem=origem, campo=campo, etapa=etapa)

    nomes = []
    for encontrado in PLACEHOLDER_VALIDO_RE.finditer(texto):
        nomes.append(encontrado.group(1) or encontrado.group(2))

    return sorted(set(nomes))


def _validar_valores(
    nomes: Sequence[str],
    valores: dict[str, Any],
    *,
    origem: str,
    campo: str,
    etapa: str,
) -> None:
    for nome in nomes:
        if nome not in valores or valores[nome] is None:
            raise _erro_placeholder(
                origem=origem,
                campo=campo,
                etapa=etapa,
                placeholder=f"{{{nome}}}",
                motivo="Placeholder sem valor disponivel.",
                titulo="Placeholder sem valor disponivel.",
            )


def preencher(
    texto: str,
    valores: dict[str, Any],
    origem: str = "texto",
    campo: str = "template",
    etapa: str = "Fluxo",
) -> str:
    nomes = placeholders(texto, origem=origem, campo=campo, etapa=etapa)
    _validar_valores(nomes, valores, origem=origem, campo=campo, etapa=etapa)

    def substituir(encontrado: re.Match[str]) -> str:
        nome = encontrado.group(1) or encontrado.group(2)
        valor = valores[nome]
        return "" if valor is None else str(valor)

    saida = PLACEHOLDER_VALIDO_RE.sub(substituir, texto)
    restantes = placeholders(saida, origem=origem, campo=campo, etapa=etapa)

    if restantes:
        raise _erro_placeholder(
            origem=origem,
            campo=campo,
            etapa=etapa,
            placeholder=", ".join(f"{{{nome}}}" for nome in restantes),
            motivo="Ainda ha placeholders sem preenchimento.",
        )

    return saida


def partes_preenchidas(
    texto: str,
    valores: dict[str, Any],
    origem: str = "texto",
    campo: str = "template",
    etapa: str = "Fluxo",
) -> list[dict[str, str]]:
    nomes = placeholders(texto, origem=origem, campo=campo, etapa=etapa)
    _validar_valores(nomes, valores, origem=origem, campo=campo, etapa=etapa)

    partes: list[dict[str, str]] = []
    posicao = 0
    remover_crase_inicial = False

    def normalizar(trecho: str) -> str:
        return re.sub(r"\s+", " ", trecho)

    for encontrado in PLACEHOLDER_VALIDO_RE.finditer(texto):
        fixo = texto[posicao:encontrado.start()]

        if remover_crase_inicial and fixo.startswith("`"):
            fixo = fixo[1:]

        remover_crase_inicial = False

        if fixo.endswith("`"):
            fixo = fixo[:-1]
            remover_crase_inicial = True

        fixo = normalizar(fixo)

        if fixo:
            partes.append({"tipo": "fixo", "texto": fixo})

        nome = encontrado.group(1) or encontrado.group(2)
        partes.append({"tipo": "valor", "texto": normalizar(str(valores[nome]))})
        posicao = encontrado.end()

    fixo = texto[posicao:]

    if remover_crase_inicial and fixo.startswith("`"):
        fixo = fixo[1:]

    fixo = normalizar(fixo)

    if fixo:
        partes.append({"tipo": "fixo", "texto": fixo})

    return partes
