"""Testador local opcional com interface externa compativel com Genera."""

from __future__ import annotations

import copy
import json
import os
import uuid
from typing import Any, Optional


def _url_base() -> str:
    return os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")


def modelos_disponiveis(timeout: int = 5):
    import requests

    response = requests.get(f"{_url_base()}/api/tags", timeout=timeout)
    response.raise_for_status()
    dados = response.json()
    return [item["name"] for item in dados.get("models", []) if item.get("name")]


def _modelo_padrao() -> str:
    configurado = os.getenv("OLLAMA_MODEL")

    if configurado:
        return configurado

    try:
        modelos = modelos_disponiveis()
    except Exception:
        modelos = []

    if "llama3:latest" in modelos:
        return "llama3:latest"

    if modelos:
        return modelos[0]

    return "llama3:latest"


def verificar_disponivel(timeout: int = 5):
    try:
        modelos = modelos_disponiveis(timeout=timeout)
    except Exception as erro:
        raise RuntimeError(
            "O Ollama local nao esta disponivel.\n\n"
            f"Endpoint verificado: {_url_base()}/api/tags\n\n"
            "Inicie o servico local do Ollama antes de executar fluxo_geracao(\"ollama\").\n\n"
            f"Detalhe: {erro}"
        )

    if not modelos:
        raise RuntimeError(
            "O Ollama local esta ativo, mas nenhum modelo foi encontrado.\n\n"
            "Instale ou baixe um modelo antes de executar fluxo_geracao(\"ollama\")."
        )

    configurado = os.getenv("OLLAMA_MODEL")

    if configurado and configurado not in modelos:
        raise RuntimeError(
            "Modelo Ollama configurado nao encontrado.\n\n"
            f"OLLAMA_MODEL: {configurado}\n"
            f"Modelos disponiveis: {', '.join(modelos)}"
        )


class OllamaLocal:
    def __init__(
        self,
        modelo: Optional[str] = None,
        url_base: Optional[str] = None,
        timeout: int = 120,
    ):
        import requests

        self.requests = requests
        self.modelo = modelo or _modelo_padrao()
        self.url_base = (url_base or _url_base()).rstrip("/")
        self.timeout = timeout
        self.conversation_id = str(uuid.uuid4())
        self.messages = []
        self.last_result = None
        self.last_output = None

    def call(
        self,
        prompt,
        system,
        template,
        prompt_params=None,
        temperature=0.7,
        max_tokens=512,
        top_p=1.0,
        frequency_penalty=0.0,
        presence_penalty=0.0,
        best_of=1,
        exibir=False,
        exibir_detalhado=False,
    ):
        mensagens_envio = [
            {"role": "system", "content": system},
            {"role": "user", "content": template},
        ]
        mensagens_envio.extend(copy.deepcopy(self.messages))
        mensagens_envio.append({"role": "user", "content": prompt})

        payload = {
            "model": self.modelo,
            "messages": mensagens_envio,
            "stream": False,
            "options": {
                "temperature": temperature,
                "top_p": top_p,
                "num_predict": max_tokens,
                "frequency_penalty": frequency_penalty,
                "presence_penalty": presence_penalty,
                "best_of": best_of,
            },
        }
        headers = {"Content-Type": "application/json"}

        try:
            response = self.requests.post(
                f"{self.url_base}/api/chat",
                headers=headers,
                json=payload,
                timeout=self.timeout,
            )
            response_status = response.status_code
            response_headers = dict(response.headers)

            try:
                response_body = response.json()
            except Exception:
                response_body = response.text

        except Exception as erro:
            response_status = None
            response_headers = {}
            response_body = {"erro": str(erro)}

        output = None

        try:
            output = response_body["message"]["content"]
        except Exception:
            try:
                output = response_body["response"]
            except Exception:
                output = None

        if output is not None:
            self.messages.append({"role": "user", "content": prompt})
            self.messages.append({"role": "assistant", "content": output})

        resultado = {
            "output": output,
            "request_headers": copy.deepcopy(headers),
            "request_payload": copy.deepcopy(payload),
            "response_status": response_status,
            "response_headers": response_headers,
            "response_body": response_body,
        }

        self.last_result = resultado
        self.last_output = output

        if exibir:
            print(output)

        if exibir_detalhado:
            print(json.dumps(resultado, indent=4, ensure_ascii=False))

        return resultado

    def reset(self):
        self.conversation_id = str(uuid.uuid4())
        self.messages = []
        self.last_result = None
        self.last_output = None

    def historico(self):
        return self.messages

    def exibir_historico(self):
        print(json.dumps(self.messages, indent=4, ensure_ascii=False))

    def ultima_resposta(self):
        return self.last_output

    def ultimo_resultado(self):
        return self.last_result


ollama = OllamaLocal
