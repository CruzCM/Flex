"""Configuracoes editaveis do fluxo."""

from __future__ import annotations


PARAMETROS_ETAPAS = {
    "revisor_textual": {
        "temperature": 0.5,
        "max_tokens": 512,
    },
    "copywriter": {
        "temperature": 0.7,
        "max_tokens": 700,
    },
    "tendencia_cognitiva": {
        "temperature": 0.7,
        "max_tokens": 700,
    },
    "voz_bb": {
        "temperature": 0.5,
        "max_tokens": 700,
    },
    "tagline": {
        "temperature": 0.7,
        "max_tokens": 180,
    },
    "headline": {
        "temperature": 0.7,
        "max_tokens": 120,
    },
    "cta": {
        "temperature": 0.6,
        "max_tokens": 80,
    },
}
