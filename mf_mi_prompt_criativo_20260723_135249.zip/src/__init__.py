"""Pacote do fluxo de prompt criativo."""
