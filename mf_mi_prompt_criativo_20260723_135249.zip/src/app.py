"""Experiencia guiada do notebook."""

from __future__ import annotations

import html
import importlib
import importlib.util
import json
import sys
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


DEPENDENCIAS_BASE = {"yaml": "PyYAML"}
DEPENDENCIAS_OFICIAIS = {
    "dotenv": "python-dotenv",
    "requests": "requests",
    "urllib3": "urllib3",
}
DEPENDENCIAS_OLLAMA = {"requests": "requests"}


try:
    from IPython.display import HTML, Markdown, display
    from IPython import get_ipython
except Exception:
    HTML = None
    Markdown = None
    display = None
    get_ipython = None


@dataclass
class StatusAmbiente:
    raiz: Path
    python: str
    provedor: str
    dependencias_ausentes: list[str] = field(default_factory=list)


def raiz_projeto(inicio: Optional[Path] = None) -> Path:
    atual = Path(inicio or Path.cwd()).resolve()

    for pasta in [atual] + list(atual.parents):
        if (
            (pasta / "produtos").exists()
            and (pasta / "publicos").exists()
            and (pasta / "prompts").exists()
        ):
            return pasta

    raise RuntimeError("Nao foi possivel localizar a raiz do projeto.")


def dependencias_ausentes(dependencias: dict[str, str]) -> list[str]:
    ausentes = []

    for modulo, pacote in dependencias.items():
        if importlib.util.find_spec(modulo) is None:
            ausentes.append(pacote)

    return sorted(set(ausentes))


def normalizar_provedor(provedor: Optional[str]) -> Optional[str]:
    if provedor is None:
        return None

    valor = str(provedor).strip().lower()

    if valor == "ollama":
        return "ollama"

    raise ValueError(
        "Provedor invalido: "
        + str(provedor)
        + "\n\nValores aceitos:\n"
        + "- nenhum argumento, para usar o Genera oficial;\n"
        + '- "ollama", para usar o testador local.'
    )


def preparar_ambiente(provedor: Optional[str]) -> StatusAmbiente:
    raiz = raiz_projeto()

    if str(raiz) not in sys.path:
        sys.path.insert(0, str(raiz))

    dependencias = dict(DEPENDENCIAS_BASE)
    nome_provedor = "Genera oficial"

    if provedor == "ollama":
        dependencias.update(DEPENDENCIAS_OLLAMA)
        nome_provedor = "Ollama local"
    else:
        dependencias.update(DEPENDENCIAS_OFICIAIS)

    return StatusAmbiente(
        raiz=raiz,
        python=".".join(str(parte) for parte in sys.version_info[:3]),
        provedor=nome_provedor,
        dependencias_ausentes=dependencias_ausentes(dependencias),
    )


def resolver_criador_provedor(provedor: Optional[str]) -> Any:
    if provedor is None:
        from .modelos import Genera

        return Genera

    if provedor == "ollama":
        try:
            modulo = importlib.import_module("src.ollama_local")
        except ModuleNotFoundError as erro:
            if erro.name == "src.ollama_local":
                raise RuntimeError(
                    "O testador local Ollama nao esta disponivel.\n\n"
                    "Arquivo esperado:\n"
                    "src/ollama_local.py\n\n"
                    "O fluxo oficial continua disponivel por meio de fluxo_geracao()."
                )
            raise

        if not hasattr(modulo, "ollama"):
            raise RuntimeError(
                "O arquivo src/ollama_local.py deve exportar um objeto chamado ollama."
            )

        if hasattr(modulo, "verificar_disponivel"):
            modulo.verificar_disponivel()

        return getattr(modulo, "ollama")

    raise ValueError("Provedor invalido.")


def em_notebook() -> bool:
    if display is None or get_ipython is None:
        return False

    shell = get_ipython()
    return shell is not None and shell.__class__.__name__ == "ZMQInteractiveShell"


def texto_curto(texto: Any, largura: int = 100) -> str:
    return textwrap.fill(" ".join(str(texto or "").split()), width=largura)


class Visual:
    def aplicar_estilo(self) -> None:
        if not em_notebook() or HTML is None:
            return

        display(
            HTML(
                """
                <style>
                .pc-wrap {
                    max-width: 980px;
                    font-family: Arial, sans-serif;
                    color: #1f2933;
                }
                .pc-hero {
                    border-left: 6px solid #f3c300;
                    padding: 14px 18px;
                    background: #f7f9fc;
                    margin: 8px 0 18px;
                }
                .pc-section {
                    margin: 18px 0 8px;
                    padding-bottom: 4px;
                    border-bottom: 1px solid #d8dee9;
                    font-size: 20px;
                    font-weight: 700;
                }
                .pc-card {
                    border: 1px solid #d8dee9;
                    border-radius: 8px;
                    margin: 10px 0;
                    background: #ffffff;
                }
                .pc-card > summary,
                .pc-final > summary {
                    cursor: pointer;
                    padding: 14px 16px;
                    font-weight: 700;
                    list-style: none;
                }
                .pc-card > summary::-webkit-details-marker,
                .pc-final > summary::-webkit-details-marker {
                    display: none;
                }
                .pc-card > summary:before,
                .pc-final > summary:before {
                    content: "+";
                    display: inline-block;
                    width: 18px;
                    color: #52606d;
                }
                .pc-card[open] > summary:before,
                .pc-final[open] > summary:before {
                    content: "-";
                }
                .pc-card-body,
                .pc-final-body {
                    padding: 0 16px 14px;
                }
                .pc-label {
                    font-size: 12px;
                    font-weight: 700;
                    letter-spacing: .02em;
                    text-transform: uppercase;
                    color: #52606d;
                    margin-bottom: 4px;
                }
                .pc-value {
                    white-space: pre-wrap;
                    line-height: 1.45;
                }
                .pc-muted {
                    color: #52606d;
                    font-size: 13px;
                }
                .pc-final {
                    border: 2px solid #f3c300;
                    border-radius: 8px;
                    margin: 14px 0;
                    background: #fffdf2;
                }
                </style>
                """
            )
        )

    def titulo(self, texto: str, apoio: Optional[str] = None) -> None:
        if em_notebook() and HTML is not None:
            apoio_html = (
                f"<div class='pc-muted'>{html.escape(apoio)}</div>" if apoio else ""
            )
            display(
                HTML(
                    "<div class='pc-wrap pc-hero'>"
                    f"<h1 style='margin:0 0 6px'>{html.escape(texto)}</h1>"
                    f"{apoio_html}"
                    "</div>"
                )
            )
            return

        print("\n" + "=" * 80)
        print(texto.upper())
        if apoio:
            print(apoio)
        print("=" * 80)

    def secao(self, texto: str) -> None:
        if em_notebook() and HTML is not None:
            display(HTML(f"<div class='pc-wrap pc-section'>{html.escape(texto)}</div>"))
            return

        print("\n" + texto.upper())
        print("-" * len(texto))

    def ficha(self, titulo: str, dados: dict[str, Any]) -> None:
        if em_notebook() and HTML is not None:
            partes = []

            for chave, valor in dados.items():
                partes.append(
                    "<div style='margin:10px 0'>"
                    f"<div class='pc-label'>{html.escape(str(chave))}</div>"
                    f"<div class='pc-value'>{html.escape(str(valor or ''))}</div>"
                    "</div>"
                )

            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    + "".join(partes)
                    + "</div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        for chave, valor in dados.items():
            print(f"\n{chave}")
            print(texto_curto(valor))

    def bloco(self, titulo: str, texto: Any) -> None:
        if em_notebook() and HTML is not None:
            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    f"<div class='pc-value'>{html.escape(str(texto or ''))}</div>"
                    "</div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        print(texto_curto(texto))

    def bloco_partes(self, titulo: str, partes: list[dict[str, str]]) -> None:
        if em_notebook() and HTML is not None:
            html_partes = []

            for parte in partes:
                texto = html.escape(parte["texto"])
                html_partes.append(
                    f"<strong>{texto}</strong>"
                    if parte["tipo"] == "fixo"
                    else texto
                )

            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    "<div class='pc-value'>"
                    + "".join(html_partes)
                    + "</div></div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        print(
            "".join(
                f"**{parte['texto']}**"
                if parte["tipo"] == "fixo"
                else parte["texto"]
                for parte in partes
            )
        )

    def final(self, dados: dict[str, Any]) -> None:
        if em_notebook() and HTML is not None:
            partes = []

            for chave, valor in dados.items():
                partes.append(
                    "<div style='margin:12px 0'>"
                    f"<div class='pc-label'>{html.escape(str(chave))}</div>"
                    f"<div class='pc-value'>{html.escape(str(valor or ''))}</div>"
                    "</div>"
                )

            display(
                HTML(
                    "<details class='pc-wrap pc-final'>"
                    "<summary>Resultado final</summary>"
                    "<div class='pc-final-body'>"
                    + "".join(partes)
                    + "</div></details>"
                )
            )
            return

        self.ficha("Resultado final", dados)

    def opcoes(self, opcoes: list[str]) -> None:
        linhas = [
            f"{indice:>2}. {opcao.replace('_', ' ').title()}"
            for indice, opcao in enumerate(opcoes, start=1)
        ]

        if em_notebook() and Markdown is not None:
            display(Markdown("```text\n" + "\n".join(linhas) + "\n```"))
            return

        print("\n".join(linhas))

    def escolher(
        self,
        mensagem: str,
        opcoes: list[str],
        *,
        padrao: Optional[str] = None,
    ) -> str:
        if not opcoes:
            raise ValueError(f"Nenhuma opcao disponivel para: {mensagem}")

        self.opcoes(opcoes)

        indice_padrao = None
        if padrao in opcoes:
            indice_padrao = opcoes.index(padrao) + 1

        while True:
            sufixo = f" [{indice_padrao}]" if indice_padrao else ""
            valor = input(f"{mensagem}{sufixo}: ").strip()

            if not valor and indice_padrao:
                return opcoes[indice_padrao - 1]

            try:
                indice = int(valor)
                if 1 <= indice <= len(opcoes):
                    return opcoes[indice - 1]
            except ValueError:
                if valor in opcoes:
                    return valor

            print("Opcao invalida.")

    def numero(self, mensagem: str, padrao: int) -> int:
        while True:
            valor = input(f"{mensagem} [{padrao}]: ").strip()

            if not valor:
                return padrao

            try:
                numero = int(valor)
                if numero > 0:
                    return numero
            except ValueError:
                pass

            print("Informe um numero inteiro positivo.")

    def decimal(self, mensagem: str, padrao: float) -> float:
        while True:
            valor = input(f"{mensagem} [{padrao}]: ").strip()

            if not valor:
                return padrao

            try:
                numero = float(valor.replace(",", "."))
                if numero >= 0:
                    return numero
            except ValueError:
                pass

            print("Informe um numero decimal maior ou igual a zero.")

    def confirmar(self, mensagem: str, padrao: bool = True) -> bool:
        dica = "S/n" if padrao else "s/N"

        while True:
            valor = input(f"{mensagem} [{dica}]: ").strip().lower()

            if not valor:
                return padrao
            if valor in {"s", "sim", "y", "yes"}:
                return True
            if valor in {"n", "nao", "no"}:
                return False

            print("Responda com sim ou nao.")

    def debug_json(self, titulo: str, dados: dict[str, Any]) -> None:
        conteudo = json.dumps(dados, indent=2, ensure_ascii=False, default=str)

        if em_notebook() and HTML is not None:
            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    "<pre class='pc-value'>"
                    + html.escape(conteudo)
                    + "</pre></div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        print(conteudo)


class Experiencia:
    def __init__(
        self,
        motor: Any,
        status: StatusAmbiente,
        provedor: Optional[str],
    ):
        self.motor = motor
        self.status = status
        self.provedor = provedor
        self.criador_provedor = None
        self.parametros_por_etapa: dict[str, dict[str, Any]] = {}
        self.ui = Visual()

    def rodar(self) -> Any:
        self.ui.aplicar_estilo()
        self.ui.titulo(
            "Prompt Criativo",
            "Experiencia guiada para montar, comparar prompts e gerar mensagens.",
        )
        self.mostrar_status()
        self.criador_provedor = resolver_criador_provedor(self.provedor)
        self.validar_catalogos()

        produto = self.selecionar_produto()
        publico = self.selecionar_publico()
        apresentacao = self.selecionar_apresentacao(produto, publico)
        cenario = self.selecionar_cenario()

        self.ui.secao("Parametros finais")
        limite_tagline = self.ui.numero("Limite de caracteres da tagline", 120)
        limite_headline = self.ui.numero("Limite de caracteres da headline", 60)

        selecao = self.motor.Selecao(
            produto=produto.nome,
            publico=publico.nome,
            apresentacao=apresentacao.nome,
            cenario=cenario.nome,
            limite_tagline=limite_tagline,
            limite_headline=limite_headline,
        )

        if not self.ui.confirmar("Executar pipeline completo", padrao=True):
            contexto, previa = self.motor.contexto_inicial(
                selecao,
                {
                    "produto": produto,
                    "publico": publico,
                    "apresentacao": apresentacao,
                    "cenario": cenario,
                    "tendencias": [
                        self.motor.carregar_tendencia(nome)
                        for nome in self.motor.listar_tendencias()
                    ],
                },
            )
            return {
                "selecao": selecao,
                "contexto": contexto,
                "apresentacao": previa,
                "executado": False,
            }

        resultado = self.motor.rodar_fluxo(
            selecao,
            criador_provedor=self.criador_provedor,
            configurar_chamada=self.configurar_chamada,
            escolher_resultado=self.escolher_resultado,
            ao_resultado_etapa=self.mostrar_etapa_concluida,
        )
        self.mostrar_resultado(resultado)
        return resultado

    def mostrar_status(self) -> None:
        self.ui.secao("Ambiente")
        self.ui.ficha(
            "Status inicial",
            {
                "Raiz": self.status.raiz,
                "Python": self.status.python,
                "Provedor": self.status.provedor,
                "Dependencias ausentes": (
                    ", ".join(self.status.dependencias_ausentes)
                    if self.status.dependencias_ausentes
                    else "Nenhuma"
                ),
                "Instalacao automatica": "Desativada",
            },
        )

    def validar_catalogos(self) -> None:
        erros = self.motor.validar_catalogos()

        if erros:
            self.ui.ficha(
                "Validacao dos catalogos",
                {
                    "Status": "Encontramos ajustes pendentes.",
                    "Erros": "\n".join(erros),
                },
            )
            raise RuntimeError("Catalogos com erros de validacao.")

        self.ui.ficha(
            "Validacao dos catalogos",
            {"Status": "Todos os catalogos foram carregados."},
        )

    def selecionar_produto(self) -> Any:
        self.ui.secao("Produto")
        nome = self.ui.escolher("Escolha o produto", self.motor.listar_produtos())
        produto = self.motor.carregar_produto(nome)
        self.ui.ficha(
            produto.rotulo,
            {
                "Descricao": produto.descricao,
                "Beneficio racional": produto.beneficio_racional,
                "Beneficio emocional": produto.beneficio_emocional,
            },
        )
        return produto

    def selecionar_publico(self) -> Any:
        self.ui.secao("Publico")
        nome = self.ui.escolher("Escolha o publico", self.motor.listar_publicos())
        publico = self.motor.carregar_publico(nome)
        self.ui.ficha(
            publico.rotulo,
            {
                "Descricao": publico.descricao,
                "Necessidade racional": publico.necessidade_racional,
                "Necessidade emocional": publico.necessidade_emocional,
            },
        )
        return publico

    def selecionar_apresentacao(self, produto: Any, publico: Any) -> Any:
        self.ui.secao("Apresentacao")
        nome = self.ui.escolher(
            "Escolha a apresentacao",
            self.motor.listar_apresentacoes(),
        )
        apresentacao = self.motor.carregar_apresentacao(nome)
        previa = apresentacao.montar(produto, publico)

        self.ui.bloco("Template", apresentacao.template)
        self.ui.bloco_partes("Template preenchido", previa["partes"])
        return apresentacao

    def selecionar_cenario(self) -> Any:
        self.ui.secao("Cenario")
        nome = self.ui.escolher("Escolha o cenario", self.motor.listar_cenarios())
        cenario = self.motor.carregar_cenario(nome)
        self.ui.ficha(
            cenario.rotulo,
            {
                "Funcao": cenario.funcao_prompt,
                "Estrutura": cenario.texto_prompt,
            },
        )
        return cenario

    def escolher_resultado(self, etapa: Any, validos: list[Any]) -> str:
        self.ui.secao(f"{etapa.titulo}: comparacao de prompts")

        for resultado in etapa.resultados_prompt:
            titulo = resultado.identificador

            if resultado.opcao:
                titulo = f"{titulo} - {resultado.opcao.replace('_', ' ').title()}"

            self.ui.ficha(
                f"Entrada - {titulo}",
                {
                    "Template preenchido e enviado": resultado.template_preenchido,
                    "System fonte/enviado": resultado.system,
                    "Temperatura": resultado.parametros.get("temperature", ""),
                    "Tokens maximos": resultado.parametros.get("max_tokens", ""),
                },
            )

            if resultado.valido:
                self.ui.ficha(
                    f"Saida - {titulo}",
                    {
                        "Texto gerado": resultado.output,
                    },
                )
            else:
                self.ui.ficha(
                    f"Saida - {titulo}",
                    {
                        "Erro": resultado.erro,
                    },
                )

        opcoes = [resultado.identificador for resultado in validos]
        return self.ui.escolher(
            "Escolha o resultado que deve seguir no fluxo",
            opcoes,
            padrao=opcoes[0],
        )

    def configurar_chamada(
        self,
        etapa: Any,
        prompt: Any,
        opcao: str,
        parametros: dict[str, Any],
    ) -> dict[str, Any]:
        if etapa.id in self.parametros_por_etapa:
            return dict(self.parametros_por_etapa[etapa.id])

        self.ui.secao(f"Parametros da etapa: {etapa.titulo}")
        temperatura = self.ui.decimal(
            "Temperatura",
            float(parametros["temperature"]),
        )
        max_tokens = self.ui.numero(
            "Quantidade maxima de tokens",
            int(parametros["max_tokens"]),
        )

        ajustes = {
            "temperature": temperatura,
            "max_tokens": max_tokens,
        }
        self.parametros_por_etapa[etapa.id] = ajustes
        return dict(ajustes)

    def mostrar_etapa_concluida(self, etapa: Any) -> None:
        selecionado = etapa.resultado_selecionado()

        if selecionado is None:
            return

        if len(etapa.resultados_prompt) == 1:
            self.ui.secao(etapa.titulo)
            titulo = selecionado.prompt.identificador

            if selecionado.opcao:
                titulo = f"{titulo} - {selecionado.opcao.replace('_', ' ').title()}"

            self.ui.ficha(
                f"Entrada - {titulo}",
                {
                    "Opcao": selecionado.opcao.replace("_", " ").title()
                    if selecionado.opcao
                    else "",
                    "Template preenchido e enviado": selecionado.template_preenchido,
                    "System fonte/enviado": selecionado.system,
                    "Temperatura": selecionado.parametros.get("temperature", ""),
                    "Tokens maximos": selecionado.parametros.get("max_tokens", ""),
                },
            )
            self.ui.ficha(
                f"Saida - {titulo}",
                {
                    "Texto gerado": selecionado.output,
                },
            )
            return

        self.ui.ficha(
            f"Escolha registrada - {etapa.titulo}",
            {
                "Prompt selecionado": etapa.prompt_selecionado,
                "Opcao selecionada": etapa.opcao_selecionada or "",
                "Saida escolhida": etapa.saida_selecionada,
            },
        )

    def mostrar_resultado(self, resultado: Any) -> None:
        self.ui.secao("Resultado")
        self.ui.final(
            {
                "Headline": resultado.headline,
                "Tagline": resultado.tagline,
                "CTA": resultado.cta,
                "Resumo institucional": resultado.resumo_institucional,
            }
        )

        self.ui.secao("Historico tecnico")

        for etapa in resultado.etapas:
            self.ui.ficha(
                etapa.titulo,
                {
                    "Prompt selecionado": etapa.prompt_selecionado,
                    "Opcao selecionada": etapa.opcao_selecionada or "",
                    "Entrada comum": etapa.entrada_comum,
                    "Saida selecionada": etapa.saida_selecionada,
                    "Prompts executados": ", ".join(
                        item.identificador for item in etapa.resultados_prompt
                    ),
                },
            )


def fluxo_geracao(provedor: Optional[str] = None) -> Any:
    """Entrada unica chamada pela rotina-principal.ipynb."""

    provedor_normalizado = normalizar_provedor(provedor)
    status = preparar_ambiente(provedor_normalizado)

    if status.dependencias_ausentes:
        raise RuntimeError(
            "Dependencias ausentes: "
            + ", ".join(status.dependencias_ausentes)
            + "\n\nInstale as dependencias do projeto antes de executar o fluxo."
        )

    motor = importlib.import_module("src.motor")

    return Experiencia(
        motor=motor,
        status=status,
        provedor=provedor_normalizado,
    ).rodar()
