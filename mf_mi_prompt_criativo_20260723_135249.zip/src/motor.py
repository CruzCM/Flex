"""Orquestracao do fluxo de geracao."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Optional, Union

from .modelos import (
    Apresentacao,
    Cenario,
    Etapa,
    Produto,
    Prompt,
    Publico,
    Resultado,
    ResultadoEtapa,
    ResultadoPrompt,
    Selecao,
    Tendencia,
)
from .configuracao import PARAMETROS_ETAPAS
from .yaml_utils import carregar_yaml, listar_yaml, preencher, raiz_projeto, validar_campos


CriadorProvedor = Callable[[], Any]
EscolherResultado = Callable[[ResultadoEtapa, list[ResultadoPrompt]], Union[int, str, ResultadoPrompt]]
AoResultadoEtapa = Callable[[ResultadoEtapa], None]
ConfigurarChamada = Callable[[Etapa, Prompt, str, dict[str, Any]], dict[str, Any]]


ETAPAS = [
    Etapa(
        id="revisor_textual",
        titulo="Revisor textual",
        grupo_prompt="1_revisor_textual",
        saida="PH_APRESENTACAO_REVISADA",
        entrada="PH_APRESENTACAO",
        temperature=0.5,
        max_tokens=512,
    ),
    Etapa(
        id="copywriter",
        titulo="Copywriter",
        grupo_prompt="2_copywriter",
        saida="PH_BASE_SEM_VIES",
        entrada="PH_APRESENTACAO_REVISADA",
        temperature=0.7,
        max_tokens=700,
    ),
    Etapa(
        id="tendencia_cognitiva",
        titulo="Tendencia cognitiva",
        grupo_prompt="3_tendencia_cognitiva",
        saida="PH_BASE_COM_VIES",
        entrada="PH_BASE_SEM_VIES",
        temperature=0.7,
        max_tokens=700,
    ),
    Etapa(
        id="voz_bb",
        titulo="Voz Institucional BB",
        grupo_prompt="4_voz_BB",
        saida="PH_BASE_BB",
        entrada="PH_BASE_COM_VIES",
        temperature=0.5,
        max_tokens=700,
    ),
    Etapa(
        id="tagline",
        titulo="Tagline",
        grupo_prompt="5_tagline",
        saida="PH_TEXTO",
        entrada="PH_BASE_BB",
        temperature=0.7,
        max_tokens=180,
    ),
    Etapa(
        id="headline",
        titulo="Headline",
        grupo_prompt="6_headline",
        saida="PH_TITULO",
        entrada="PH_TEXTO",
        temperature=0.7,
        max_tokens=120,
    ),
    Etapa(
        id="cta",
        titulo="CTA",
        grupo_prompt="7_cta",
        saida="PH_TEXTO_CTA",
        entrada="PH_TITULO",
        temperature=0.6,
        max_tokens=80,
    ),
]


def aplicar_parametros_configurados() -> None:
    for etapa in ETAPAS:
        parametros = PARAMETROS_ETAPAS.get(etapa.id, {})

        if "temperature" in parametros:
            etapa.temperature = float(parametros["temperature"])
        if "max_tokens" in parametros:
            etapa.max_tokens = int(parametros["max_tokens"])


aplicar_parametros_configurados()


def _origem(pasta: Union[str, Path], nome: str, raiz: Optional[Path] = None) -> str:
    return str((raiz or raiz_projeto()) / Path(pasta) / f"{nome}.yaml")


def listar_produtos(raiz: Optional[Path] = None) -> list[str]:
    return listar_yaml("produtos", raiz)


def listar_publicos(raiz: Optional[Path] = None) -> list[str]:
    return listar_yaml("publicos", raiz)


def listar_apresentacoes(raiz: Optional[Path] = None) -> list[str]:
    return listar_yaml("apresentacoes", raiz)


def listar_cenarios(raiz: Optional[Path] = None) -> list[str]:
    return listar_yaml("cenarios", raiz)


def listar_tendencias(raiz: Optional[Path] = None) -> list[str]:
    return listar_yaml("tendencias", raiz)


def listar_prompts(grupo: str, raiz: Optional[Path] = None) -> list[str]:
    return listar_yaml(Path("prompts") / grupo, raiz)


def listar_grupos_prompt(raiz: Optional[Path] = None) -> list[str]:
    pasta = (raiz or raiz_projeto()) / "prompts"

    if not pasta.exists():
        return []

    return sorted(item.name for item in pasta.iterdir() if item.is_dir())


def carregar_produto(nome: str, raiz: Optional[Path] = None) -> Produto:
    dados = carregar_yaml("produtos", nome, raiz)
    validar_campos(
        dados,
        ("descricao", "beneficio_racional", "beneficio_emocional"),
        f"Produto '{nome}'",
    )
    return Produto(
        nome=nome,
        descricao=dados["descricao"],
        beneficio_racional=dados["beneficio_racional"],
        beneficio_emocional=dados["beneficio_emocional"],
        origem=_origem("produtos", nome, raiz),
        dados=dados,
    )


def carregar_publico(nome: str, raiz: Optional[Path] = None) -> Publico:
    dados = carregar_yaml("publicos", nome, raiz)
    validar_campos(
        dados,
        ("descricao", "necessidade_racional", "necessidade_emocional"),
        f"Publico '{nome}'",
    )
    return Publico(
        nome=nome,
        descricao=dados["descricao"],
        necessidade_racional=dados["necessidade_racional"],
        necessidade_emocional=dados["necessidade_emocional"],
        origem=_origem("publicos", nome, raiz),
        dados=dados,
    )


def carregar_apresentacao(nome: str, raiz: Optional[Path] = None) -> Apresentacao:
    dados = carregar_yaml("apresentacoes", nome, raiz)
    validar_campos(dados, ("template", "descricao"), f"Apresentacao '{nome}'")
    return Apresentacao(
        nome=nome,
        template=dados["template"],
        descricao=dados["descricao"],
        origem=_origem("apresentacoes", nome, raiz),
        dados=dados,
    )


def carregar_cenario(nome: str, raiz: Optional[Path] = None) -> Cenario:
    dados = carregar_yaml("cenarios", nome, raiz)
    validar_campos(dados, ("texto_prompt", "funcao_prompt"), f"Cenario '{nome}'")
    return Cenario(
        nome=nome,
        texto_prompt=dados["texto_prompt"],
        funcao_prompt=dados["funcao_prompt"],
        exibir_usuario=dados.get("exibir_usuario", ""),
        origem=_origem("cenarios", nome, raiz),
        dados=dados,
    )


def carregar_tendencia(nome: str, raiz: Optional[Path] = None) -> Tendencia:
    dados = carregar_yaml("tendencias", nome, raiz)
    validar_campos(dados, ("texto_prompt", "funcao_prompt"), f"Tendencia '{nome}'")
    return Tendencia(
        nome=nome,
        texto_prompt=dados["texto_prompt"],
        funcao_prompt=dados["funcao_prompt"],
        not_prompt_descricao=dados.get("not_prompt_descricao", ""),
        origem=_origem("tendencias", nome, raiz),
        dados=dados,
    )


def carregar_prompt(grupo: str, nome: str, raiz: Optional[Path] = None) -> Prompt:
    pasta = Path("prompts") / grupo
    dados = carregar_yaml(pasta, nome, raiz)
    validar_campos(dados, ("template", "system"), f"Prompt '{grupo}/{nome}'")
    return Prompt(
        grupo=grupo,
        nome=nome,
        system=dados["system"],
        template=dados["template"],
        versao=str(dados.get("versao", "")),
        origem=_origem(pasta, nome, raiz),
        dados=dados,
    )


def validar_catalogos(raiz: Optional[Path] = None) -> list[str]:
    raiz = raiz or raiz_projeto()
    erros: list[str] = []

    validacoes = [
        (listar_produtos, carregar_produto, "Produto"),
        (listar_publicos, carregar_publico, "Publico"),
        (listar_apresentacoes, carregar_apresentacao, "Apresentacao"),
        (listar_cenarios, carregar_cenario, "Cenario"),
        (listar_tendencias, carregar_tendencia, "Tendencia"),
    ]

    for listar, carregar, nome_tipo in validacoes:
        for nome in listar(raiz):
            try:
                carregar(nome, raiz)
            except Exception as erro:
                erros.append(f"{nome_tipo}/{nome}: {erro}")

    for grupo in listar_grupos_prompt(raiz):
        for nome in listar_prompts(grupo, raiz):
            try:
                carregar_prompt(grupo, nome, raiz)
            except Exception as erro:
                erros.append(f"Prompt/{grupo}/{nome}: {erro}")

    return erros


def carregar_selecao(selecao: Selecao) -> dict[str, Any]:
    return {
        "produto": carregar_produto(selecao.produto),
        "publico": carregar_publico(selecao.publico),
        "apresentacao": carregar_apresentacao(selecao.apresentacao),
        "cenario": carregar_cenario(selecao.cenario),
        "tendencias": [
            carregar_tendencia(nome)
            for nome in listar_tendencias()
        ],
    }


def contexto_inicial(
    selecao: Selecao,
    objetos: Optional[dict[str, Any]] = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    objetos = objetos or carregar_selecao(selecao)
    apresentacao = objetos["apresentacao"].montar(
        objetos["produto"],
        objetos["publico"],
    )

    contexto = {
        "PH_APRESENTACAO": apresentacao["texto"],
        "PH_LIMITE_CARACTER_TEXTO": str(selecao.limite_tagline),
        "PH_LIMITE_CARACTER_TITULO": str(selecao.limite_headline),
    }

    return contexto, apresentacao


def valores_etapa(
    etapa_id: str,
    contexto: dict[str, Any],
    objetos: dict[str, Any],
) -> dict[str, Any]:
    cenario = objetos["cenario"]

    if etapa_id == "revisor_textual":
        return {"PH_APRESENTACAO": contexto["PH_APRESENTACAO"]}
    if etapa_id == "copywriter":
        return {
            "PH_APRESENTACAO_REVISADA": contexto["PH_APRESENTACAO_REVISADA"],
            "PH_CENARIO_FUNCAO": cenario.funcao_prompt,
            "PH_CENARIO_DESCRICAO": cenario.texto_prompt,
        }
    if etapa_id == "voz_bb":
        return {"PH_BASE_COM_VIES": contexto["PH_BASE_COM_VIES"]}
    if etapa_id == "tagline":
        return {
            "PH_BASE_BB": contexto["PH_BASE_BB"],
            "PH_LIMITE_CARACTER_TEXTO": contexto["PH_LIMITE_CARACTER_TEXTO"],
        }
    if etapa_id == "headline":
        return {
            "PH_BASE_BB": contexto["PH_BASE_BB"],
            "PH_TEXTO": contexto["PH_TEXTO"],
            "PH_LIMITE_CARACTER_TITULO": contexto["PH_LIMITE_CARACTER_TITULO"],
        }
    if etapa_id == "cta":
        return {
            "PH_BASE_BB": contexto["PH_BASE_BB"],
            "PH_TITULO": contexto["PH_TITULO"],
            "PH_TEXTO": contexto["PH_TEXTO"],
        }

    raise ValueError(f"Etapa desconhecida: {etapa_id}")


def valores_tendencia(
    contexto: dict[str, Any],
    tendencia: Tendencia,
) -> dict[str, Any]:
    return {
        "PH_BASE_SEM_VIES": contexto["PH_BASE_SEM_VIES"],
        "PH_VIES_FUNCAO": tendencia.funcao_prompt,
        "PH_VIES_DESCRICAO": tendencia.texto_prompt,
    }


def criar_instancia(criador_provedor: CriadorProvedor) -> Any:
    instancia = criador_provedor()

    if not hasattr(instancia, "call"):
        raise TypeError("O provedor deve criar uma instancia com metodo call(...).")

    return instancia


def validar_chamada(chamada: Any, etapa: Etapa, prompt: Prompt) -> str:
    if not isinstance(chamada, dict):
        raise RuntimeError(
            f"Etapa nao concluida: {etapa.titulo}\n\n"
            f"Prompt: {prompt.identificador}\n\n"
            "O provedor nao retornou um dicionario."
        )

    if "output" not in chamada:
        raise RuntimeError(
            f"Etapa nao concluida: {etapa.titulo}\n\n"
            f"Prompt: {prompt.identificador}\n\n"
            "O provedor nao retornou chamada['output']."
        )

    output = chamada["output"]
    detalhe = (
        "\n\nStatus da resposta: "
        + str(chamada.get("response_status"))
        + "\n\nCorpo da resposta:\n"
        + str(chamada.get("response_body"))
    )

    if output is None:
        raise RuntimeError(
            f"Etapa nao concluida: {etapa.titulo}\n\n"
            f"Prompt: {prompt.identificador}\n\n"
            "O provedor retornou output=None."
            + detalhe
        )

    if not isinstance(output, str):
        raise RuntimeError(
            f"Etapa nao concluida: {etapa.titulo}\n\n"
            f"Prompt: {prompt.identificador}\n\n"
            "O provedor retornou output que nao e texto."
        )

    if not output.strip():
        raise RuntimeError(
            f"Etapa nao concluida: {etapa.titulo}\n\n"
            f"Prompt: {prompt.identificador}\n\n"
            "O provedor retornou output vazio."
        )

    return output


def executar_prompt(
    etapa: Etapa,
    prompt: Prompt,
    valores: dict[str, Any],
    criador_provedor: CriadorProvedor,
    configurar_chamada: Optional[ConfigurarChamada] = None,
    opcao: str = "",
) -> ResultadoPrompt:
    entrada = str(valores[etapa.entrada])
    parametros = {
        "temperature": etapa.temperature,
        "max_tokens": etapa.max_tokens,
        "top_p": etapa.top_p,
        "frequency_penalty": etapa.frequency_penalty,
        "presence_penalty": etapa.presence_penalty,
        "best_of": etapa.best_of,
    }

    try:
        template_preenchido = preencher(
            prompt.template,
            valores,
            origem=prompt.origem,
            campo="template",
            etapa=etapa.titulo,
        )
        if configurar_chamada is not None:
            ajustes = configurar_chamada(etapa, prompt, opcao, dict(parametros))
            parametros.update(ajustes or {})

        instancia = criar_instancia(criador_provedor)
        chamada = instancia.call(
            prompt=entrada,
            system=prompt.system,
            template=template_preenchido,
            prompt_params=None,
            temperature=parametros["temperature"],
            max_tokens=parametros["max_tokens"],
            top_p=parametros["top_p"],
            frequency_penalty=parametros["frequency_penalty"],
            presence_penalty=parametros["presence_penalty"],
            best_of=parametros["best_of"],
            exibir=False,
            exibir_detalhado=False,
        )
        output = validar_chamada(chamada, etapa, prompt)
        return ResultadoPrompt(
            prompt=prompt,
            system=prompt.system,
            template_original=prompt.template,
            template_preenchido=template_preenchido,
            entrada=entrada,
            opcao=opcao,
            parametros=dict(parametros),
            output=output,
            bruto=chamada,
        )
    except Exception as erro:
        return ResultadoPrompt(
            prompt=prompt,
            system=prompt.system,
            template_original=prompt.template,
            template_preenchido="",
            entrada=entrada,
            opcao=opcao,
            parametros=dict(parametros),
            erro=str(erro),
        )


def _resolver_escolha(
    etapa: ResultadoEtapa,
    validos: list[ResultadoPrompt],
    escolha: Union[int, str, ResultadoPrompt],
) -> ResultadoPrompt:
    if isinstance(escolha, ResultadoPrompt):
        if escolha in validos:
            return escolha
        raise ValueError("Resultado escolhido nao pertence a etapa.")

    if isinstance(escolha, int):
        indice = escolha - 1
        if 0 <= indice < len(validos):
            return validos[indice]
        raise ValueError("Indice de resultado invalido.")

    escolha_texto = str(escolha).strip()
    for resultado in validos:
        if escolha_texto in {
            resultado.prompt.nome,
            resultado.prompt.identificador,
            resultado.identificador,
            resultado.opcao,
        }:
            return resultado

    raise ValueError(
        "Resultado escolhido invalido para a etapa "
        + etapa.titulo
        + ": "
        + escolha_texto
    )


def _erro_todos_prompts(etapa: ResultadoEtapa) -> RuntimeError:
    partes = [
        f"Nenhuma saida valida foi produzida na etapa: {etapa.titulo}",
        "",
        "Erros por prompt:",
    ]

    for resultado in etapa.resultados_prompt:
        partes.append(f"- {resultado.prompt.identificador}: {resultado.erro}")

    partes.append("")
    partes.append("O contexto da etapa seguinte nao foi atualizado.")
    return RuntimeError("\n".join(partes))


def executar_etapa_tendencias(
    etapa: Etapa,
    contexto: dict[str, Any],
    objetos: dict[str, Any],
    criador_provedor: CriadorProvedor,
    configurar_chamada: Optional[ConfigurarChamada] = None,
) -> ResultadoEtapa:
    nomes_prompt = listar_prompts(etapa.grupo_prompt)

    if len(nomes_prompt) != 1:
        raise RuntimeError(
            "A etapa de tendencia cognitiva deve ter exatamente um prompt tecnico.\n\n"
            f"Pasta: prompts/{etapa.grupo_prompt}\n"
            f"Prompts encontrados: {', '.join(nomes_prompt) or 'nenhum'}\n\n"
            "Para a regra atual, o fluxo gera uma resposta para cada tendencia. "
            "Com mais de um prompt tecnico, o total deixaria de ser exatamente dez."
        )

    prompt = carregar_prompt(etapa.grupo_prompt, nomes_prompt[0])
    tendencias = objetos["tendencias"]

    if not tendencias:
        raise RuntimeError("Nenhuma tendencia cognitiva encontrada.")

    resultado_etapa = ResultadoEtapa(
        id=etapa.id,
        titulo=etapa.titulo,
        entrada_comum=str(contexto["PH_BASE_SEM_VIES"]),
    )

    for tendencia in tendencias:
        valores = valores_tendencia(contexto, tendencia)
        resultado_etapa.resultados_prompt.append(
            executar_prompt(
                etapa,
                prompt,
                valores,
                criador_provedor,
                configurar_chamada=configurar_chamada,
                opcao=tendencia.nome,
            )
        )

    return resultado_etapa


def executar_etapa_prompts(
    etapa: Etapa,
    contexto: dict[str, Any],
    objetos: dict[str, Any],
    criador_provedor: CriadorProvedor,
    configurar_chamada: Optional[ConfigurarChamada] = None,
) -> ResultadoEtapa:
    valores = valores_etapa(etapa.id, contexto, objetos)
    entrada = str(valores[etapa.entrada])
    resultado_etapa = ResultadoEtapa(
        id=etapa.id,
        titulo=etapa.titulo,
        entrada_comum=entrada,
    )
    nomes_prompt = listar_prompts(etapa.grupo_prompt)

    if not nomes_prompt:
        raise RuntimeError(f"Nenhum prompt encontrado para a etapa: {etapa.titulo}")

    for nome_prompt in nomes_prompt:
        prompt = carregar_prompt(etapa.grupo_prompt, nome_prompt)
        resultado_etapa.resultados_prompt.append(
            executar_prompt(
                etapa,
                prompt,
                valores,
                criador_provedor,
                configurar_chamada=configurar_chamada,
            )
        )

    return resultado_etapa


def rodar_fluxo(
    selecao: Selecao,
    criador_provedor: CriadorProvedor,
    escolher_resultado: Optional[EscolherResultado] = None,
    ao_resultado_etapa: Optional[AoResultadoEtapa] = None,
    configurar_chamada: Optional[ConfigurarChamada] = None,
) -> Resultado:
    objetos = carregar_selecao(selecao)
    contexto, apresentacao = contexto_inicial(selecao, objetos)
    resultados: list[ResultadoEtapa] = []

    for etapa in ETAPAS:
        if etapa.id == "tendencia_cognitiva":
            resultado_etapa = executar_etapa_tendencias(
                etapa,
                contexto,
                objetos,
                criador_provedor,
                configurar_chamada=configurar_chamada,
            )
        else:
            resultado_etapa = executar_etapa_prompts(
                etapa,
                contexto,
                objetos,
                criador_provedor,
                configurar_chamada=configurar_chamada,
            )

        validos = resultado_etapa.validos()

        if not validos:
            resultado_etapa.erro = "Nenhuma saida valida foi produzida."
            resultados.append(resultado_etapa)
            raise _erro_todos_prompts(resultado_etapa)

        if len(validos) == 1:
            escolhido = validos[0]
        else:
            if escolher_resultado is None:
                raise RuntimeError(
                    "A etapa possui multiplos resultados validos, "
                    "mas nenhuma funcao de escolha foi fornecida."
                )
            escolhido = _resolver_escolha(
                resultado_etapa,
                validos,
                escolher_resultado(resultado_etapa, validos),
            )

        escolhido.escolhido = True
        resultado_etapa.prompt_selecionado = escolhido.identificador
        resultado_etapa.opcao_selecionada = escolhido.opcao or None
        resultado_etapa.saida_selecionada = str(escolhido.output)
        contexto[etapa.saida] = str(escolhido.output)

        if etapa.id == "tendencia_cognitiva":
            selecao.tendencia = escolhido.opcao
            contexto["PH_TENDENCIA_ESCOLHIDA"] = escolhido.opcao

        resultados.append(resultado_etapa)

        if ao_resultado_etapa is not None:
            ao_resultado_etapa(resultado_etapa)

    return Resultado(
        selecao=selecao,
        apresentacao_visual=apresentacao["visual"],
        apresentacao_texto=apresentacao["texto"],
        placeholders=apresentacao["placeholders"],
        contexto=contexto,
        etapas=resultados,
    )
