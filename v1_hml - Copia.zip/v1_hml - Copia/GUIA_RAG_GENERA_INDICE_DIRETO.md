# GUIA OFICIAL: INTEGRAÇÃO RAG AGENT-OPS COM ÍNDICE DIRETO NO GENERABB

> **Finalidade:** Referência arquitetural e técnica para consumo de bases de conhecimento indexadas (RAG) no GeneraBB diretamente por microsserviços da Esteira AgentOps, **sem criação nem dependência de agentes no GeneraBB**.  
> **Status:** Homologado / Validado com sucesso em runtime.  
> **Aplica-se a:** Microsserviços Python/LangGraph da Esteira AgentOps (ex.: `plg-agent-consult-fin`).

---

## Sumário

1. [Visão Geral e Princípio Arquitetural](#1-visão-geral-e-princípio-arquitetural)
2. [Por que NÃO criar Agente no GeneraBB?](#2-por-que-não-criar-agente-no-generabb)
3. [Diferença entre as APIs do GeneraBB](#3-diferença-entre-as-apis-do-generabb)
4. [Contrato de Requisição e Resposta do Índice Direto](#4-contrato-de-requisição-e-resposta-do-índice-direto)
5. [Configuração no Microsserviço](#5-configuração-no-microsserviço)
6. [Implementação no Código Python](#6-implementação-no-código-python)
7. [Ciclo de Vida e Ambientes (DEV, HML, PRD)](#7-ciclo-de-vida-e-ambientes-dev-hml-prd)
8. [Roteiro de Testes Passo a Passo](#8-roteiro-de-testes-passo-a-passo)
9. [Guia de Resolução de Problemas (Troubleshooting)](#9-guia-de-resolução-de-problemas-troubleshooting)

---

## 1. Visão Geral e Princípio Arquitetural

Na arquitetura moderna de agentes corporativos do Banco do Brasil:

* **O Agente (Cérebro):** Reside no microsserviço da **Esteira AgentOps**, rodando em contêineres OpenShift/Kubernetes, orquestrado via LangGraph, conectado ao Gateway Outbound corporativo (GPT-4o), protegido por guardrails locais e monitorado via OpenTelemetry.
* **A Base de Conhecimento (Memória Vetorial):** Reside no **GeneraBB**, atuando puramente como repositório de busca vetorial/híbrida (OpenSearch) sobre documentos fatiados em *chunks*.

```
+-----------------------------------------------------------------------+
|                         ESTEIRA AGENT-OPS                             |
|  [ Microsserviço Python / LangGraph no OpenShift ]                    |
|  - Orquestração de diálogo (ReAct)                                    |
|  - Chamada ao modelo LLM (Gateway Outbound BB)                        |
|  - Ferramenta de RAG (rag_tool.py)                                    |
+-----------------------------------+-----------------------------------+
                                    |
                                    | HTTPS POST /gateway/core
                                    | Action: "recuperar-contexto-indice"
                                    | Parâmetro: index_id: "idx-..."
                                    v
+-----------------------------------------------------------------------+
|                            GENERABB                                   |
|  [ Motor Central de Índices / OpenSearch ]                            |
|  - Apenas armazenamento e busca vetorial/híbrida                      |
|  - NÃO possui persona, NÃO possui prompt, NÃO executa LLM             |
+-----------------------------------------------------------------------+
```

---

## 2. Por que NÃO criar Agente no GeneraBB?

Criar um agente no GeneraBB apenas para encapsular uma base indexada gera um **grave anti-pattern arquitetural**:

1. **Duplicidade de Agentes em Produção:** Se você criar um agente no GeneraBB, terá que manter dois agentes ativos em produção: o seu agente real no AgentOps (OpenShift) e um "agente fantasma/casca" no GeneraBB apenas para segurar o índice.
2. **Duplo Ciclo de Vida e Burocracia:** Cada promoção de ambiente (Desenvolvimento → Homologação → Produção) exigiria sincronizar a esteira GitOps do microsserviço com os formulários manuais de publicação de agentes na interface do GeneraBB.
3. **Custo e Complexidade Desnecessários:** Manter agentes não utilizados no catálogo do GeneraBB consome recursos de governança, auditoria e gestão de acessos.

> **Regra de Ouro:** A aplicação na Esteira AgentOps precisa **apenas do identificador do índice (`index_id: "idx-..."`)**, consultando o motor de dados do GeneraBB diretamente.

---

## 3. Diferença entre as APIs do GeneraBB

O GeneraBB disponibiliza dois endpoints com contratos completamente distintos:

| Característica | ❌ Rota de Agente (Evitar no AgentOps) | ✅ Rota de Índice Direto (Padrão Homologado) |
| :--- | :--- | :--- |
| **Endpoint** | `POST https://.../gateway/agent` | `POST https://.../gateway/core` |
| **Action** | `"recuperar-contexto"` | **`"recuperar-contexto-indice"`** |
| **Destino** | Consulta um **Agente do Genera** | Consulta o **Índice Vetorial diretamente** |
| **Identificador** | `"agent_id": "nome-do-agente"` | **`"index_id": "idx-nome-do-indice"`** |
| **Localização do ID** | Na raiz do JSON | Dentro de `body.data` |
| **Se passar `idx-...`** | **Retorna 404** ("O agente não foi encontrado") | **Retorna 200 OK** com os trechos recuperados |
| **Exige Agente no Genera?** | Sim, obrigatoriamente | **NÃO**, nenhum agente necessário |

---

## 4. Contrato de Requisição e Resposta do Índice Direto

### 4.1 Requisição (Payload Oficial)

* **URL:** `https://generabb-acs.gbb.servicos.bb.com.br/gateway/core`
* **Método:** `POST`
* **Headers:**

```http
Content-Type: application/json
Accept: application/json
UOR: <SUA_UOR>
X-Client-Id: <SEU_CLIENT_ID_DO_GENERA>
userIdentification: <SUA_MATRICULA_FXXXXXXX>
```

* **Body JSON:**

```json
{
  "action": "recuperar-contexto-indice",
  "body": {
    "data": {
      "input": "Como organizar minhas finanças para montar uma reserva?",
      "context": {
        "query_type": "hybrid",
        "total_context": 5
      },
      "index_id": "idx-mf-edu-fina01-0825"
    }
  }
}
```

#### Parâmetros do Body:
* `action` *(string, obrigatório)*: Deve ser impreterivelmente `"recuperar-contexto-indice"`.
* `body.data.input` *(string, obrigatório)*: O texto ou pergunta para busca semântica.
* `body.data.index_id` *(string, obrigatório)*: O código do índice criado na Gestão de Índices do GeneraBB (inicia com `idx-`).
* `body.data.context.query_type` *(string, opcional)*: `"hybrid"` (recomendado, combina similaridade vetorial + BM25 por palavras-chave).
* `body.data.context.total_context` *(integer, opcional)*: Quantidade máxima de chunks retornados (padrão recomendado: 3 a 5).

---

### 4.2 Resposta (JSON Retornado pelo GeneraBB)

Quando a consulta obtém sucesso, o GeneraBB responde com `HTTP 200`:

```json
{
  "data": {
    "retrieved_contexts": [
      {
        "metadata": {
          "source": "a18.txt"
        },
        "passage_text": "# Chunk ID 018 - Educacao Financeira... Renda extra, como freelas, bicos, vendas...",
        "id": "s19"
      },
      {
        "metadata": {
          "source": "a55.txt"
        },
        "passage_text": "# Chunk ID 055 - Educacao Financeira... Buscar uma fonte de renda extra...",
        "id": "s56"
      }
    ],
    "similarities": [0.032258064, 0.016393442]
  },
  "message": ["Requestfulfilled, document follows"],
  "status": 200
}
```

---

## 5. Configuração no Microsserviço

### 5.1 No `agent_config.yaml`
Apenas as configurações funcionais não secretas:

```yaml
rag:
  enabled: true
  url: "https://generabb-acs.gbb.servicos.bb.com.br/gateway/core"
  user_id: "FXXXXXXX"                  # Matrícula do responsável técnico
  uor: "486611"                        # UOR detentora do índice
  agent_id: "idx-mf-edu-fina01-0825"   # Identificador do índice no GeneraBB
  total_context: 5                     # Quantidade de chunks
  timeout: 20.0
  tool_name: "retrieve_context"
  tool_description: "Consulta a base de conhecimento e recupera trechos relevantes."
```

### 5.2 No arquivo `.env` (Secrets Locais)
Apenas as credenciais secretas (nunca comitar no Git):

```dotenv
# Token de acesso da sua UOR ao GeneraBB (copiado de 'Meus Dados' no Genera)
RAG_CLIENT_ID=eyJhbGciOi...

# AppKey de acesso ao Gateway LLM (GPT-4o) do BB
GATEWAY_OUTBOUND_GW_APP_KEY=fed72428...
```

---

## 6. Implementação no Código Python

### 6.1 `plg_agent_consult_fin/config.py`
A classe de configuração deve refletir o endpoint `/gateway/core`:

```python
@dataclass
class RAGConfig:
    enabled: bool = False
    url: str = "https://generabb-acs.gbb.servicos.bb.com.br/gateway/core"
    uor: str = ""
    user_id: str = ""
    agent_id: str = ""  # Armazena o identificador do índice (idx-...)
    total_context: int = 5
    timeout: float = 20.0
    tool_name: str = "retrieve_context"
    tool_description: str = "Recupera trechos da base de conhecimento indexada."
```

### 6.2 `plg_agent_consult_fin/rag/rag_tool.py`
A montagem do payload e envio para o GeneraBB:

```python
async def _call_gateway(query: str, config: RAGConfig | None = None) -> list[Any]:
    cfg = config or get_config().rag
    client_id = os.environ.get("RAG_CLIENT_ID", "")
    if not cfg.enabled or not client_id or not cfg.agent_id:
        logger.info("RAG indisponível ou incompleto; recuperação não executada")
        return []

    # Payload direcionado exclusivamente ao índice
    payload = {
        "action": "recuperar-contexto-indice",
        "body": {
            "data": {
                "input": query,
                "context": {
                    "query_type": "hybrid",
                    "total_context": cfg.total_context,
                },
                "index_id": cfg.agent_id,
            }
        },
    }

    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "X-Client-Id": client_id,
        "UOR": cfg.uor,
        "userIdentification": cfg.user_id,
    }

    try:
        response = await _get_http_client().post(
            cfg.url,
            json=payload,
            headers=headers,
            timeout=cfg.timeout,
        )
        response.raise_for_status()
        contexts = _extract_contexts(response.json())
        if not contexts:
            logger.warning("RAG não retornou contextos para a consulta")
        return contexts
    except Exception as exc:
        logger.warning("Falha ao consultar o RAG: %s", exc)
    return []
```

---

## 7. Ciclo de Vida e Ambientes (DEV, HML, PRD)

Com a arquitetura de acesso direto ao índice, o ciclo de vida fica desacoplado e simples:

### No AgentOps (OpenShift):
* O microsserviço Python é promovido através das pipelines corporativas padrão:
  * `des-plg-agent-consult-fin` → `hml-plg-agent-consult-fin` → `prd-plg-agent-consult-fin`
* O registro no **Catálogo de IA** da Plataforma BB é único para o microsserviço.

### No GeneraBB:
* Na **Gestão de Índices**, você cadastra a base de conhecimento.
* Os limites de requisição (*rate limits*) por ambiente aplicam-se ao consumo da UOR:
  * **Homologação:** 5 requisições por minuto (padrão de testes).
  * **Produção:** 20 requisições por minuto (expansível via chamado se necessário).
* **Nenhum agente precisa ser criado, versionado ou publicado no GeneraBB.**

---

## 8. Roteiro de Testes Passo a Passo

### Teste 1: Teste direto de conectividade via cURL
Para validar se o GeneraBB e o índice estão respondendo sem precisar ligar o microsserviço:

```bash
curl -X POST "https://generabb-acs.gbb.servicos.bb.com.br/gateway/core" \
  -H "Content-Type: application/json" \
  -H "UOR: 486611" \
  -H "X-Client-Id: $RAG_CLIENT_ID" \
  -H "userIdentification: FXXXXXXX" \
  -d '{
    "action": "recuperar-contexto-indice",
    "body": {
      "data": {
        "input": "O que é Selic?",
        "context": {
          "query_type": "hybrid",
          "total_context": 3
        },
        "index_id": "idx-mf-edu-fina01-0825"
      }
    }
  }'
```
* **Sucesso:** Retorna HTTP `200` com os blocos em `retrieved_contexts`.

---

### Teste 2: Testes unitários locais
Valida a montagem do payload e a extração dos blocos:

```bash
python -m pytest tests/unit/test_rag_tool.py
```
* **Sucesso:** `13 passed in 0.21s`.

---

### Teste 3: Teste integrado de ponta a ponta via Swagger
1. Inicie o servidor:
   ```bash
   python -m plg_agent_consult_fin --host 127.0.0.1 --port 8080
   ```
2. Acesse no navegador: `http://127.0.0.1:8080/docs`
3. Abra a rota `POST /chat`, clique em **Try it out** e envie:
   ```json
   {
     "message": "Como planejar uma reserva de emergência?",
     "session_id": "teste-01"
   }
   ```
4. Observe a resposta:
   * `"tool_calls_made": 1` *(comprova que o RAG foi acionado e buscou dados no índice)*.
   * `"reply"` *(resposta com conteúdo fundamentado nos documentos indexados)*.

---

## 9. Guia de Resolução de Problemas (Troubleshooting)

### Erro 404: "O agente não foi encontrado"
* **Causa:** A chamada está indo para o endpoint errado (`/gateway/agent`) ou com action `"recuperar-contexto"`.
* **Solução:** Corrija a URL para `/gateway/core` e a action para `"recuperar-contexto-indice"`.

### Erro 401: Unauthorized
* **Causa:** O header `X-Client-Id` expirou ou não corresponde à `UOR` informada.
* **Solução:** Acesse o GeneraBB, vá em *Meus Dados*, copie o Client ID atualizado e exporte novamente: `export RAG_CLIENT_ID="novo_token"`.

### Resposta vem com `"tool_calls_made": 0`
* **Causa:** O RAG está desabilitado na configuração.
* **Solução:** Verifique se em `agent_config.yaml` o campo `rag.enabled` está como `true` e reinicie o microsserviço.

### `AttributeError: 'GuardrailsConfig' object has no attribute 'enabled'`
* **Causa:** Resquício de middleware tentando chamar o validador externo Genera Safe sem o atributo na classe de configuração.
* **Solução:** Adicione `enabled: bool = False` na classe `GuardrailsConfig` dentro de `plg_agent_consult_fin/config.py`.
