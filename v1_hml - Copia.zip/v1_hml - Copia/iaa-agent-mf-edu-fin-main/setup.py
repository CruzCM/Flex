# -*- encoding: utf-8 -*-
# Referência: https://packaging.python.org/guides/distributing-packages-using-setuptools/

import io
import re

from setuptools import find_packages, setup

common_requirements = [
    'pytest',
    'pytest-asyncio',
    'httpx>=0.27',
]

dev_requirements = [
    'bandit',
    'flake8',
    'isort',
    'langchain-azure-ai',
] + common_requirements

unit_test_requirements = common_requirements

integration_test_requirements = common_requirements

run_requirements = [
    'fastapi>=0.111.0',
    'uvicorn[standard]>=0.29.0',
    'pydantic>=2.7.0',
    'langgraph>=0.2',
    'langchain-core>=0.2',
    'langchain-openai>=0.1',
    'langchain-azure-ai',
    'langchain-mcp-adapters>=0.2',
    'azure-identity',
    'openai>=1.30',
    'pyyaml>=6.0',
    'httpx>=0.27',
    'typing-extensions>=4.11',
    'requests>=2.31.0',
    'azure-monitor-opentelemetry',
    'opentelemetry-sdk',
    'opentelemetry-distro',
    'opentelemetry-exporter-otlp',
]

with io.open('./iaa_agent_mf_edu_fin/__init__.py', encoding='utf8') as version_f:
    version_match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]",
                              version_f.read(), re.M)
    if version_match:
        version = version_match.group(1)
    else:
        raise RuntimeError("Não foi possível encontrar a string de versão.")

with io.open('README.md', encoding='utf8') as readme:
    long_description = readme.read()

setup(
    name="iaa_agent_mf_edu_fin",
    version=version,
    author="Banco do Brasil S.A.",
    author_email="ditec@bb.com.br",
    packages=find_packages(exclude=['tests', 'tests.*']),
    include_package_data=True,
    url="https://canais.fontes.intranet.bb.com.br/iaa/iaa-agent-mf-edu-fin/iaa-agent-mf-edu-fin",
    license="COPYRIGHT",
    description="Microsserviço de agente de IA baseado em LangGraph com FastAPI, ferramentas MCP, RAG e guardrails.",
    long_description=long_description,
    zip_safe=False,
    install_requires=run_requirements,
    extras_require={
         'dev': dev_requirements,
         'unit': unit_test_requirements,
         'integration': integration_test_requirements,
    },
    python_requires='>=3.11',
    classifiers=[
        'Intended Audience :: Information Technology',
        'Natural Language :: Portuguese (Brazilian)',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3.11'
    ],
    keywords=[],
    entry_points={
        'console_scripts': [
            'iaa_agent_mf_edu_fin = iaa_agent_mf_edu_fin.__main__:main'
        ],
    },
)
