"""semantic_similarity.py - Lightweight local text similarity helpers.

Provides a small abstraction over fuzzy matching libraries for use in
validators that need to catch "similar but not identical" phrasing.
No external API calls.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Iterable

try:
    from rapidfuzz import fuzz  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    fuzz = None


@dataclass(frozen=True)
class SimilarityMatch:
    """Best similarity match against a phrase set."""

    phrase: str
    score: float  # 0..1


def normalize_text(text: str) -> str:
    """Normalize text for robust multilingual fuzzy comparisons."""
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def best_similarity(text: str, phrases: Iterable[str]) -> SimilarityMatch | None:
    """Return the best similarity match in 0..1 against the provided phrases."""
    normalized_text = normalize_text(text)
    if not normalized_text:
        return None

    best_phrase = ""
    best_score = 0.0

    for phrase in phrases:
        normalized_phrase = normalize_text(phrase)
        if not normalized_phrase:
            continue

        if fuzz is not None:
            score = max(
                fuzz.token_set_ratio(normalized_text, normalized_phrase),
                fuzz.partial_ratio(normalized_text, normalized_phrase),
            ) / 100.0
        else:
            score = SequenceMatcher(None, normalized_text, normalized_phrase).ratio()

        if score > best_score:
            best_score = score
            best_phrase = phrase

    if not best_phrase:
        return None

    return SimilarityMatch(phrase=best_phrase, score=best_score)
