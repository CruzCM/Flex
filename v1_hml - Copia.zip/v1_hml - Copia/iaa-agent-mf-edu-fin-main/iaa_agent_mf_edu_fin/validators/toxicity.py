"""toxicity.py - On-premises toxicity detection via weighted keyword/regex scoring.

Scores text 0–1 (1 = high toxicity risk). Categories: profanity, threats,
harassment, hate speech, self-harm. Supports PT-BR and EN patterns.

No external API calls - fully local.
"""

from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Tuple

from iaa_agent_mf_edu_fin.validators import BaseValidator, ValidationResult, ValidatorAction
from iaa_agent_mf_edu_fin.validators.semantic_similarity import best_similarity

# ---------------------------------------------------------------------------
# Categorias locais de padrão (pattern, weight).
# Peso maior representa risco maior; o score final é limitado a 1.0.
# ---------------------------------------------------------------------------

_THREAT_PATTERNS: List[Tuple[re.Pattern, float]] = [
    (re.compile(p, re.IGNORECASE), w)
    for p, w in [
        (r"\b(kill|murder|attack|bomb|shoot|stab|assassinate)\b", 0.7),
        (r"\b(matar|assassinar|explodir|esfaquear|atirar)\b", 0.7),
        (r"\bi['\u2019]?ll\s+(hurt|destroy|end)\s+you\b", 0.8),
        (r"\b(threat|ameaça|ameacar)\b", 0.4),
        (r"\b(vou\s+te\s+matar|vou\s+acabar\s+com\s+voc[eê])\b", 0.8),
    ]
]

_HARASSMENT_PATTERNS: List[Tuple[re.Pattern, float]] = [
    (re.compile(p, re.IGNORECASE), w)
    for p, w in [
        (r"\b(stupid|idiot|moron|dumb|loser|pathetic)\b", 0.3),
        (r"\b(idiota|burro|imbecil|otário|lixo|inútil)\b", 0.3),
        (r"\b(shut\s+up|cala\s+a\s+boca)\b", 0.2),
        (r"\b(you\s+are\s+(worthless|useless|garbage))\b", 0.5),
        (r"\b(voc[eê]\s+[eé]\s+(in[uú]til|lixo|um\s+nada))\b", 0.5),
    ]
]

_HATE_SPEECH_PATTERNS: List[Tuple[re.Pattern, float]] = [
    (re.compile(p, re.IGNORECASE), w)
    for p, w in [
        (r"\b(racist|sexist|homophobic|transphobic)\b", 0.3),
        (r"\b(racista|machista|homofóbico|transfóbico)\b", 0.3),
        (r"\b(all\s+(blacks?|whites?|jews?|muslims?)\s+(should|must|deserve))\b", 0.9),
        (r"\b(inferior\s+race|raça\s+inferior)\b", 0.9),
    ]
]

_SELF_HARM_PATTERNS: List[Tuple[re.Pattern, float]] = [
    (re.compile(p, re.IGNORECASE), w)
    for p, w in [
        (r"\b(how\s+to\s+(kill|harm)\s+(myself|yourself))\b", 0.9),
        (r"\b(como\s+se\s+matar|suicid[aáio])\b", 0.8),
        (r"\b(self[- ]?harm|autolesão|automutilação)\b", 0.6),
        (r"\b(cut\s+(myself|yourself|my\s+wrists?))\b", 0.8),
    ]
]

_ALL_CATEGORIES: Dict[str, List[Tuple[re.Pattern, float]]] = {
    "threats": _THREAT_PATTERNS,
    "harassment": _HARASSMENT_PATTERNS,
    "hate_speech": _HATE_SPEECH_PATTERNS,
    "self_harm": _SELF_HARM_PATTERNS,
}

_SEMANTIC_SEEDS: Dict[str, List[str]] = {
    "threats": [
        "i will destroy you",
        "i am going to end your life",
        "vou acabar com voce",
        "eu vou te eliminar",
    ],
    "harassment": [
        "you are completely useless",
        "you are trash",
        "voce nao serve para nada",
        "cala a boca agora",
    ],
    "hate_speech": [
        "that group is an inferior race",
        "all muslims should be punished",
        "essa e uma raca inferior",
        "todos os judeus deveriam sofrer",
    ],
    "self_harm": [
        "i want to hurt myself",
        "how can i end my own life",
        "quero me machucar",
        "como posso me matar",
    ],
}

_SEMANTIC_CATEGORY_WEIGHT: Dict[str, float] = {
    "threats": 0.6,
    "harassment": 0.35,
    "hate_speech": 0.7,
    "self_harm": 0.7,
}


class ToxicityValidator(BaseValidator):
    # No A0 é executado depois da geração; o tratamento HTTP da saída permanece
    # no middleware e o resultado continua disponível na telemetria.
    """Keyword / regex-based toxicity scorer.

    Score semantics:
        1.0 = maximum toxicity risk detected
        0.0 = clean text

    When ``score > threshold`` the result is ``passed=False``.
    """

    name = "toxicity"
    default_action = ValidatorAction.BLOCK
    threshold = 0.5

    def __init__(
        self,
        semantic_enabled: bool | None = None,
        semantic_threshold: float | None = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        env_enabled = os.getenv("GUARDRAIL_SEMANTIC_ENABLED", "true").lower() == "true"
        self.semantic_enabled = semantic_enabled if semantic_enabled is not None else env_enabled
        self.semantic_threshold = semantic_threshold if semantic_threshold is not None else 0.86

    def _accumulate_regex_matches(self, text: str) -> tuple[float, Dict[str, List[str]]]:
        accumulated = 0.0
        matched_categories: Dict[str, List[str]] = {}

        for category, patterns in _ALL_CATEGORIES.items():
            for pattern, weight in patterns:
                for m in pattern.finditer(text):
                    accumulated += weight
                    matched_categories.setdefault(category, []).append(m.group(0))

        return accumulated, matched_categories

    def _accumulate_semantic_matches(
        self,
        text: str,
        matched_categories: Dict[str, List[str]],
    ) -> tuple[float, Dict[str, Dict[str, float | str]]]:
        if not self.semantic_enabled:
            return 0.0, {}

        added = 0.0
        semantic_matches: Dict[str, Dict[str, float | str]] = {}
        for category, seeds in _SEMANTIC_SEEDS.items():
            if category in matched_categories:
                continue
            match = best_similarity(text, seeds)
            if not match or match.score < self.semantic_threshold:
                continue

            max_weight = _SEMANTIC_CATEGORY_WEIGHT.get(category, 0.4)
            scaled_weight = ((match.score - self.semantic_threshold) / (1 - self.semantic_threshold)) * max_weight
            effective_weight = max(0.0, min(max_weight, scaled_weight))
            added += effective_weight
            matched_categories.setdefault(category, []).append(f"semantic:{match.phrase}")
            semantic_matches[category] = {
                "phrase": match.phrase,
                "score": round(match.score, 3),
            }

        return added, semantic_matches

    def _validate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        if not text.strip():
            return ValidationResult(passed=True, validator_name=self.name, score=0.0)

        accumulated, matched_categories = self._accumulate_regex_matches(text)
        semantic_added, semantic_matches = self._accumulate_semantic_matches(text, matched_categories)
        accumulated += semantic_added

        # Clamp to 0–1 risk range (1 = high toxicity risk)
        score = min(accumulated, 1.0)

        passed = score <= self.threshold
        details = ""
        if matched_categories:
            parts = [f"{cat}: {', '.join(matches)}" for cat, matches in matched_categories.items()]
            details = "; ".join(parts)

        return ValidationResult(
            passed=passed,
            validator_name=self.name,
            score=round(score, 3),
            action=self.default_action if not passed else ValidatorAction.LOG_ONLY,
            details=details,
            metadata={
                "categories": list(matched_categories.keys()),
                "semantic_enabled": self.semantic_enabled,
                "semantic_matches": semantic_matches,
            },
        )
