"""tool_correctness.py - LLM-as-a-Judge validator for tool call correctness.

Evaluates whether the selected tool was appropriate for the user intent,
arguments were coherent with the schema, and the returned result was useful.

Score semantics:
    0.0 = wrong tool / bad arguments / unusable result
    1.0 = correct tool, coherent arguments, and useful result
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Set

from iaa_agent_mf_edu_fin.validators import BaseValidator, ValidationResult, ValidatorAction

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = "You are a strict tool-calling evaluator. Respond only with valid JSON."

_JUDGE_PROMPT = """Evaluate if the chosen tool call is correct for the request.

Return a quality score from 0.0 to 1.0:
- 0.0 = clearly wrong tool choice and/or severe argument/result issues
- 0.3 = likely wrong or major issues that make the call unreliable
- 0.6 = partially correct, with medium issues
- 0.9 = mostly correct, only minor issues
- 1.0 = correct tool, coherent arguments, and useful result

Check all dimensions:
1) Tool selection:
- Is the called tool appropriate for the user request/intent?
- If expected_tool is provided, compare with it.
- If available_tools are provided, judge whether another tool would be better.

2) Argument quality:
- Are arguments semantically coherent with the request?
- Do they appear compatible with the provided schema?

3) Result quality:
- Is the result non-empty and useful?
- Does it look like an error/exception/timeout message?

Respond ONLY with JSON in this exact format:
{{
  "score": <float>,
  "reason": "<brief explanation>",
  "issues": ["<issue1>", "<issue2>"],
  "recommended_tool": "<tool_name_if_better_exists_or_empty>"
}}

---
User request: {user_query}
Planner intent: {intent}
Expected tool (optional): {expected_tool}
Called tool: {tool_name}
Available tools: {available_tools}
Tool schema: {tool_schema}
Tool args: {tool_args}
Tool result (truncated): {tool_result}
"""


def _build_judge_llm():
    """Build a low-temperature LLM instance using the project's LLMFactory."""
    from iaa_agent_mf_edu_fin.config import get_config
    from iaa_agent_mf_edu_fin.llm import LLMFactory

    config = get_config()
    provider = config.llm.provider if hasattr(config, "llm") else "gateway_outbound"
    return LLMFactory.create(provider=provider, temperature=0.0, top_p=1.0)


def _truncate(value: Any, limit: int = 800) -> str:
    """Convert values to compact strings to keep prompts bounded."""
    text = str(value)
    return text if len(text) <= limit else f"{text[:limit]}..."


def _call_llm_judge(payload: Dict[str, Any]) -> tuple[float, Dict[str, Any]]:
    """Call the LLM judge and return (risk_score, metadata)."""
    llm = _build_judge_llm()

    prompt = _JUDGE_PROMPT.format(
        user_query=_truncate(payload.get("user_query", "")),
        intent=_truncate(payload.get("intent", "")),
        expected_tool=_truncate(payload.get("expected_tool", "")),
        tool_name=_truncate(payload.get("tool_name", "")),
        available_tools=_truncate(payload.get("available_tools", [])),
        tool_schema=_truncate(payload.get("tool_schema", {})),
        tool_args=_truncate(payload.get("tool_args", {})),
        tool_result=_truncate(payload.get("tool_result", "")),
    )

    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]
    response = llm.invoke(messages)

    content = response.content if isinstance(response.content, str) else str(response.content)
    parsed = json.loads(content)

    risk_score = max(0.0, min(1.0, float(parsed.get("score", 1.0))))
    reason = str(parsed.get("reason", "")).strip()
    issues = parsed.get("issues", [])
    recommended_tool = str(parsed.get("recommended_tool", "")).strip()

    if not isinstance(issues, list):
        issues = [str(issues)]

    return risk_score, {
        "reason": reason,
        "issues": [str(i) for i in issues],
        "recommended_tool": recommended_tool,
        "method": "llm_as_judge",
    }


class ToolCorrectnessValidator(BaseValidator):
    # Validator preservado para o construtor legado; o A0 não executa Tools.
    """Validates tool invocations via LLM-as-a-Judge risk scoring."""

    name = "tool_correctness"
    default_action = ValidatorAction.LOG_ONLY
    threshold = 0.5

    def __init__(
        self,
        known_tools: Set[str] | None = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._known_tools: Set[str] = known_tools or set()

    def update_known_tools(self, tools: List[Any]) -> None:
        """Update known tool set from LangChain tool objects."""
        self._known_tools = {getattr(t, "name", str(t)) for t in tools}

    def _validate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        if context is None:
            return ValidationResult(
                passed=True,
                validator_name=self.name,
                score=1.0,
                details="no tool context - skipping",
            )

        tool_name = context.get("tool_name", "")
        tool_args = context.get("tool_args", {})
        tool_result = context.get("tool_result", "")

        if not tool_name:
            return ValidationResult(
                passed=True,
                validator_name=self.name,
                score=1.0,
                details="no tool_name in context - skipping",
            )

        payload = {
            "user_query": context.get("user_query", ""),
            "intent": context.get("intent", ""),
            "expected_tool": context.get("expected_tool", ""),
            "tool_name": tool_name,
            "available_tools": sorted(self._known_tools),
            "tool_schema": context.get("tool_schema", {}),
            "tool_args": tool_args,
            "tool_result": tool_result,
        }

        try:
            score, meta = _call_llm_judge(payload)
        except Exception as exc:
            logger.warning("ToolCorrectness LLM judge failed: judge_error")
            return ValidationResult(
                passed=True,
                validator_name=self.name,
                score=1.0,
                details="judge error (fail-open)",
                metadata={"error": "judge_error"},
            )

        passed = score >= self.threshold

        return ValidationResult(
            passed=passed,
            validator_name=self.name,
            score=score,
            action=self.default_action,
            details=f"llm_judge: {meta.get('reason', '')}",
            metadata=meta,
        )
