"""Cliente de índice direto do GeneraBB e wrapper Tool legado.

Variável de ambiente obrigatória:
    RAG_CLIENT_ID  JWT para o header X-Client-Id.
"""

from __future__ import annotations

import logging
import os
import ssl
import time
from typing import Any
from dataclasses import dataclass
from enum import Enum

import httpx
from langchain_core.tools import tool as _tool

from iaa_agent_mf_edu_fin.config import RAGConfig, get_config, rag_config_errors

logger = logging.getLogger(__name__)

# Cliente compartilhado para reutilizar conexões durante o ciclo de vida.
# O pool não é cache de respostas e é fechado no encerramento da aplicação.
_http_client: httpx.AsyncClient | None = None


# Os três estados preservam a diferença entre recuperação válida, ausência documental
# e falha técnica. Uma lista vazia isolada não carrega essa informação.
class RAGResult(str, Enum):
    SUCCESS = "success"
    NO_CONTEXT = "no_context"
    INFRA_ERROR = "infra_error"

@dataclass
class RAGResponse:
    # chunks contém somente textos aceitos pelo parser; error_detail é interno.
    chunks: list[str]
    result: RAGResult
    error_detail: str = ""

def _get_http_client() -> httpx.AsyncClient:
    # O cliente usa a CA configurada localmente e não cria conexão até uma consulta.
    global _http_client
    if _http_client is None:
        ca_bundle = os.environ.get("REQUESTS_CA_BUNDLE")
        ssl_verify: ssl.SSLContext | bool = (
            ssl.create_default_context(cafile=ca_bundle) if ca_bundle else True
        )
        _http_client = httpx.AsyncClient(verify=ssl_verify)
    return _http_client

def _extract_contexts(data: Any) -> RAGResponse:
    # O parser segue exclusivamente data.retrieved_contexts[*].passage_text.
    # Não há fallback heurístico para content, text ou page_content.
    if not isinstance(data, dict):
        return RAGResponse([], RAGResult.INFRA_ERROR, "resposta não é um objeto JSON")

    response_data = data.get("data")
    contexts = response_data.get("retrieved_contexts") if isinstance(response_data, dict) else None
    
    if not isinstance(contexts, list):
        return RAGResponse([], RAGResult.INFRA_ERROR, "data.retrieved_contexts ausente ou inválido")

    chunks: list[str] = []
    for item in contexts:
        # Um item estruturalmente inválido invalida a resposta inteira para evitar
        # transformar erro de contrato em ausência silenciosa de documentação.
        if not isinstance(item, dict) or not isinstance(item.get("passage_text"), str):
            return RAGResponse([], RAGResult.INFRA_ERROR, "item de retrieved_contexts fora do schema esperado")
        passage_text = item["passage_text"].strip()
        if passage_text:
            chunks.append(passage_text)
            
    if not chunks:
        return RAGResponse([], RAGResult.NO_CONTEXT, "Nenhum texto utilizável encontrado no contexto")
        
    return RAGResponse(chunks, RAGResult.SUCCESS)

from opentelemetry import trace
tracer = trace.get_tracer(__name__)

async def close_http_client() -> None:
    """Libera o pool no shutdown e permite novo ciclo de vida da aplicação."""
    global _http_client
    client, _http_client = _http_client, None
    if client is not None:
        await client.aclose()


async def _call_gateway(
    query: str,
    messages: list | None = None,
    total_context: int | None = None,
    *,
    config: RAGConfig | None = None,
) -> RAGResponse:
    """Recupera diretamente do índice e retorna RAGResponse tipado.

    ``messages`` permanece apenas por compatibilidade com o wrapper legado;
    histórico e schema de Tool não entram no payload do A0.
    """
    cfg = config if config is not None else get_config().rag
    started = time.perf_counter()
    # Este span existe independentemente de callbacks de Tool e registra somente
    # resultado, contagem, duração e categorias seguras de erro.
    with tracer.start_as_current_span("RAG.gateway_core", record_exception=False) as span:
        result = RAGResponse([], RAGResult.INFRA_ERROR, "configuration")
        try:
            count = cfg.total_context if total_context is None else total_context
            if rag_config_errors(cfg) or type(count) is not int or count <= 0:
                return result
            # O contrato de índice direto usa index_id dentro de body.data.
            payload = {
                "action": "recuperar-contexto-indice",
                "body": {"data": {
                    "input": query,
                    "context": {"query_type": "hybrid", "total_context": count},
                    "index_id": cfg.resolved_index_id,
                }},
            }
            headers = {
                "accept": "application/json", "Content-Type": "application/json",
                "X-Client-Id": os.environ["RAG_CLIENT_ID"],
                "UOR": cfg.uor, "userIdentification": cfg.user_id,
            }
            resp = await _get_http_client().post(
                cfg.url, json=payload, headers=headers, timeout=cfg.timeout,
            )
            resp.raise_for_status()
            result = _extract_contexts(resp.json())
        # Cada falha de transporte tem categoria própria, sem corpo ou credencial.
        except httpx.TimeoutException:
            result = RAGResponse([], RAGResult.INFRA_ERROR, "timeout")
        except httpx.HTTPStatusError as exc:
            result = RAGResponse([], RAGResult.INFRA_ERROR, f"http_{exc.response.status_code}")
        except httpx.RequestError:
            result = RAGResponse([], RAGResult.INFRA_ERROR, "connection")
        except ValueError:
            result = RAGResponse([], RAGResult.INFRA_ERROR, "invalid_json_or_tls_configuration")
        except Exception:
            result = RAGResponse([], RAGResult.INFRA_ERROR, "internal")
        finally:
            # Apenas categorias e medidas; nunca query, headers, URL ou corpo recebido.
            span.set_attribute("rag.result", result.result.value)
            span.set_attribute("rag.chunk_count", len(result.chunks))
            span.set_attribute("rag.duration_ms", (time.perf_counter() - started) * 1000)
            if result.result == RAGResult.INFRA_ERROR:
                span.set_attribute("rag.error", result.error_detail)
                logger.warning("RAG indisponível: %s", result.error_detail)
        return result

def build_rag_tool():
    """Cria o wrapper Tool legado, acessível somente pelo construtor legado.

    O A0 chama ``_call_gateway`` diretamente e não publica essa Tool ao modelo.
    """
    cfg = get_config().rag
    description = cfg.tool_description or "Recupera contexto documental relevante."

    @_tool(cfg.tool_name, description=description)
    async def _retrieve(query: str, total_context: int = 5) -> list[str]:
        response = await _call_gateway(query, messages=None, total_context=total_context)
        return response.chunks

    return _retrieve

