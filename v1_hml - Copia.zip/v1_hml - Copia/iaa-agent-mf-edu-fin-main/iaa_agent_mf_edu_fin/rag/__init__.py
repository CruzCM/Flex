"""rag/__init__.py - API pública do módulo RAG.

A lógica de recuperação vive em :mod:`iaa_agent_mf_edu_fin.rag.rag_tool`. A
função assíncrona é a API principal; o wrapper LangChain permanece apenas para
compatibilidade transitória com o grafo do baseline.
"""

# Alias público preservado para chamadores Python que não usam o wrapper Tool.
from iaa_agent_mf_edu_fin.rag.rag_tool import _call_gateway as retrieve  # noqa: F401

__all__ = ["retrieve"]
