"""genera_safe_guardrails.py - Guardrail externo LLM-as-judge via curador-iagen.

Falha em aberto: erros de rede ou timeout nunca bloqueiam o tráfego.

Variável de ambiente obrigatória:
    GUARDRAIL_EXTERNAL_CLIENT_ID  Token JWT bearer para o header X-Client-Id.
"""

from __future__ import annotations

import logging
import os
import ssl

import httpx

from iaa_agent_mf_edu_fin.config import get_config

logger = logging.getLogger(__name__)

_http_client: httpx.AsyncClient | None = None


def _get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None:
        ca_bundle = os.environ.get("REQUESTS_CA_BUNDLE")
        ssl_verify: ssl.SSLContext | bool = (
            ssl.create_default_context(cafile=ca_bundle) if ca_bundle else True
        )
        _http_client = httpx.AsyncClient(verify=ssl_verify)
    return _http_client


async def check_external_guardrail(
    message: str,
    messages: list | None = None,
) -> str | None:

    # Genera Safe é opcional e permanece fora do caminho A0 quando desabilitado.
    # Falhas de transporte são fail-open conforme o contrato legado.
    cfg = get_config().guardrails
    client_id = os.environ.get("GUARDRAIL_EXTERNAL_CLIENT_ID", "")

    if not cfg.enabled or not client_id:
        return None

    # O histórico só é enviado quando o consumidor legado o fornece explicitamente.
    payload = {
        "action": "conversar",
        "body": {
            "data": {
                "input": message,
                "context": {"messages": messages or []},
            }
        },
        "agent_id": cfg.agent_id,
    }
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "X-Client-Id": client_id,
        "UOR": cfg.uor,
        "userIdentification": cfg.user_id,
    }

    try:
        client = _get_http_client()
        resp = await client.post(cfg.url, json=payload, headers=headers, timeout=cfg.timeout)
        logger.info("Guardrail[externo]: status recebido %d", resp.status_code)
        resp.raise_for_status()
        data = resp.json()
        if not data.get("allowed", True):
            return data.get("reason", "external_guardrail_rejection")
        if data.get("status") in ("blocked", "rejected", "violation"):
            return data.get("reason", "external_guardrail_rejection")
    except httpx.TimeoutException:
        logger.warning("Guardrail[externo]: timeout - falhando em aberto")
    except httpx.HTTPStatusError as exc:
        logger.warning(
            "Guardrail[externo]: HTTP %d - falhando em aberto", exc.response.status_code
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Guardrail[externo]: internal_error - falhando em aberto")

    return None


async def close_http_client() -> None:
    """Fecha o pool opcional no encerramento, sem alterar a política fail-open."""
    global _http_client
    client, _http_client = _http_client, None
    if client is not None:
        await client.aclose()
