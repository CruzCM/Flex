"""config.py - Carrega e expõe as configurações do agent_config.yaml."""

from __future__ import annotations

import os
import threading
import math
from urllib.parse import urlsplit
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml


# ---------------------------------------------------------------------------
# Data-classes that mirror the YAML schema
# ---------------------------------------------------------------------------


@dataclass
class MCPTransport:
    type: str
    endpoint: str

    @property
    def mcp_url(self) -> str:
        return self.endpoint


@dataclass
class MCPAuthentication:
    type: str = "none"            # "none" | "bearer" | "cert"
    token_env_var: Optional[str] = None   # required when type=bearer
    cert_path: Optional[str] = None       # required when type=cert
    key_path: Optional[str] = None        # required when type=cert


@dataclass
class MCPServer:
    name: str
    description: str
    transport: MCPTransport
    authentication: Optional[MCPAuthentication] = None

    def resolve_token(self) -> Optional[str]:
        """Return the bearer token, or None when authentication is disabled."""
        if self.authentication is None or self.authentication.type != "bearer":
            return None
        if not self.authentication.token_env_var:
            return None
        return os.getenv(self.authentication.token_env_var)


# Preserva servidores MCP configurados mesmo quando a integração estiver desligada.
@dataclass
class MCPConfig:
    enabled: bool = True
    servers: List[MCPServer] = field(default_factory=list)


@dataclass
class GatewayOutboundConfig:
    base_url: str = "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"
    model: str = "cambio-non-prod-gpt4o"
    api_version: str = "2024-12-01-preview"
    max_tokens: int = 4096


# O Genera Safe usa a rota de agente; o RAG consulta diretamente a rota de índice.
_GENERA_AGENT_GATEWAY_URL = "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"
_GENERA_CORE_GATEWAY_URL = "https://generabb-acs.gbb.servicos.bb.com.br/gateway/core"


@dataclass
class GuardrailsConfig:
    enabled: bool = False
    url: str = _GENERA_AGENT_GATEWAY_URL
    user_id: str = ""
    uor: str = ""
    agent_id: str = "agente-curador-iagen"
    timeout: float = 5.0


@dataclass
class RAGConfig:
    # index_id é o contrato atual do índice direto; agent_id só atende legado.
    enabled: bool = False
    url: str = _GENERA_CORE_GATEWAY_URL
    uor: str = ""
    user_id: str = ""
    # index_id é o campo atual; agent_id permanece para configurações legadas.
    index_id: str = ""
    agent_id: str = ""
    total_context: int = 5
    timeout: float = 20.0
    tool_name: str = "retrieve_context"
    tool_description: str = ""

    @property
    def resolved_index_id(self) -> str:
        """Retorna o índice principal ou o identificador legado, nessa ordem."""
        return self.index_id or self.agent_id


# Configuração da fronteira determinística executada antes do RAG.
@dataclass
class ScopeConfig:
    enabled: bool = False
    policy: str = "keyword"
    version: str = ""
    in_scope_terms: List[str] = field(default_factory=list)
    out_of_scope_terms: List[str] = field(default_factory=list)


# Mensagens independentes para os três fast-exits funcionais da V2.
@dataclass
class ResponsesConfig:
    out_of_scope: str = ""
    no_context: str = ""
    unavailable: str = ""


@dataclass
class LLMConfig:
    provider: str = "gateway_outbound"  # gateway_outbound - extensível via LLMFactory.register()
    gateway_outbound: GatewayOutboundConfig = field(default_factory=GatewayOutboundConfig)


@dataclass
class Metadata:
    owner: str
    version: str
    created_at: str


@dataclass
class AgentConfig:
    agent_id: str
    agent_name: str
    deployment: str
    instructions: str
    agent_description: str
    temperature: float
    top_p: float
    mcp: MCPConfig
    metadata: Metadata
    llm: LLMConfig = field(default_factory=LLMConfig)
    guardrails: GuardrailsConfig = field(default_factory=GuardrailsConfig)
    rag: RAGConfig = field(default_factory=RAGConfig)
    scope: ScopeConfig = field(default_factory=ScopeConfig)
    responses: ResponsesConfig = field(default_factory=ResponsesConfig)


def rag_config_errors(cfg: RAGConfig) -> list[str]:
    """Diagnostica requisitos locais do RAG sem testar rede ou credenciais.

    A função verifica presença e formato básico, não autenticação nem disponibilidade
    do GeneraBB; por isso não substitui o teste corporativo do contrato real.
    """
    errors = []
    if cfg.enabled is not True:
        errors.append("rag.enabled")
    for name in ("resolved_index_id", "uor", "user_id"):
        if not isinstance(getattr(cfg, name), str) or not getattr(cfg, name).strip():
            errors.append("rag." + name)
    try:
        url = urlsplit(cfg.url)
        if url.scheme not in ("http", "https") or not url.hostname or url.path != "/gateway/core" or url.username or url.password or url.query or url.fragment:
            errors.append("rag.url")
    except (ValueError, TypeError):
        errors.append("rag.url")
    if type(cfg.total_context) is not int or cfg.total_context <= 0:
        errors.append("rag.total_context")
    if type(cfg.timeout) not in (int, float) or not math.isfinite(cfg.timeout) or cfg.timeout <= 0:
        errors.append("rag.timeout")
    if not os.getenv("RAG_CLIENT_ID", "").strip():
        errors.append("RAG_CLIENT_ID")
    return errors


def a0_config_errors(cfg: AgentConfig, *, operational: bool = True) -> list[str]:
    """Separa contrato local do A0 dos parâmetros necessários para operar.

    ``operational=False`` permite compilar grafos com doubles de teste; readiness
    usa a validação operacional para refletir a configuração incompleta da cópia.
    """
    from iaa_agent_mf_edu_fin.scope_policy import KeywordScopePolicy
    errors = []
    try:
        KeywordScopePolicy.from_config(cfg.scope)
    except (ValueError, TypeError, AttributeError):
        errors.append("scope.policy")
    if not isinstance(cfg.instructions, str) or not cfg.instructions.strip():
        errors.append("instructions")
    replies = [cfg.responses.out_of_scope, cfg.responses.no_context, cfg.responses.unavailable]
    if any(not isinstance(x, str) or not x.strip() for x in replies) or len({str(x).strip() for x in replies}) != 3:
        errors.append("responses")
    if operational:
        errors.extend(rag_config_errors(cfg.rag))
        from iaa_agent_mf_edu_fin.llm import LLMFactory
        if cfg.llm.provider not in LLMFactory._registry:
            errors.append("llm.provider")
        if cfg.llm.provider == "gateway_outbound":
            gw = cfg.llm.gateway_outbound
            if not all(isinstance(x, str) and x.strip() for x in (gw.base_url, gw.model, gw.api_version)):
                errors.append("llm.gateway_outbound")
            if type(gw.max_tokens) is not int or gw.max_tokens <= 0:
                errors.append("llm.max_tokens")
            if not os.getenv("GATEWAY_OUTBOUND_GW_APP_KEY", "").strip():
                errors.append("GATEWAY_OUTBOUND_GW_APP_KEY")
    return errors


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------


def load_agent_config(path: str | Path | None = None) -> AgentConfig:
    """Load *agent_config.yaml* and return a typed :class:`AgentConfig`.

    Args:
        path: Explicit path to the YAML file.  When *None* the function
              looks for ``agent_config.yaml`` next to this file's parent
              directory, then the current working directory.

    Returns:
        A fully populated :class:`AgentConfig` instance.

    Raises:
        FileNotFoundError: When the config file cannot be located.
        ValueError: When required fields are missing in the YAML.
    """
    if path is None:
        # A busca local mantém compatibilidade com execução pelo package ou pelo cwd.
        # Search heuristics: repo root (two levels up) → cwd
        candidates = [
            Path(__file__).parent.parent / "agent_config.yaml",
            Path.cwd() / "agent_config.yaml",
        ]
        for candidate in candidates:
            if candidate.is_file():
                path = candidate
                break
        else:
            raise FileNotFoundError(
                "agent_config.yaml not found. "
                f"Searched: {[str(c) for c in candidates]}"
            )

    with open(path, "r", encoding="utf-8") as fh:
        raw: dict = yaml.safe_load(fh)

    # --- MCP servers: preservados para o construtor legado, sem conexão no carregamento. ---
    mcp_raw = raw.get("mcp", {})
    servers: List[MCPServer] = []
    for srv in mcp_raw.get("servers", []):
        transport_raw = srv.get("transport", {})
        auth_raw = srv.get("authentication", {})
        servers.append(
            MCPServer(
                name=srv["name"],
                description=srv.get("description", ""),
                transport=MCPTransport(
                    type=transport_raw.get("type", "http"),
                    endpoint=transport_raw["endpoint"],
                ),
                authentication=MCPAuthentication(
                    type=auth_raw.get("type", "none"),
                    token_env_var=auth_raw.get("token_env_var"),
                    cert_path=auth_raw.get("cert_path"),
                    key_path=auth_raw.get("key_path"),
                ) if auth_raw else None,
            )
        )

    # --- Metadata ---
    meta_raw = raw.get("metadata", {})
    metadata = Metadata(
        owner=meta_raw.get("owner", ""),
        version=meta_raw.get("version", ""),
        created_at=meta_raw.get("created_at", ""),
    )

    # --- LLM provider ---
    llm_raw = raw.get("llm", {})
    gw_raw = llm_raw.get("gateway_outbound", {})
    llm_config = LLMConfig(
        provider=llm_raw.get("provider", "gateway_outbound"),
        gateway_outbound=GatewayOutboundConfig(
            base_url=gw_raw.get("base_url", "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"),
            model=gw_raw.get("model", "cambio-non-prod-gpt4o"),
            api_version=gw_raw.get("api_version", "2024-12-01-preview"),
            max_tokens=int(gw_raw.get("max_tokens", 4096)),
        ),
    )

    # --- Guardrails ---
    gr_raw = raw.get("guardrails", {})
    guardrails_config = GuardrailsConfig(
        enabled=bool(gr_raw.get("enabled", False)),
        url=gr_raw.get("url", _GENERA_AGENT_GATEWAY_URL),
        user_id=gr_raw.get("user_id", ""),
        uor=str(gr_raw.get("uor", "")),
        agent_id=gr_raw.get("agent_id", "agente-curador-iagen"),
        timeout=float(gr_raw.get("timeout", 5.0)),
    )

    # --- RAG: configuração do índice direto, sem valores secretos no YAML. ---
    rag_raw = raw.get("rag", {})
    rag_config = RAGConfig(
        enabled=bool(rag_raw.get("enabled", False)),
        url=rag_raw.get("url", _GENERA_CORE_GATEWAY_URL),
        uor=str(rag_raw.get("uor", "")),
        user_id=rag_raw.get("user_id", ""),
        index_id=rag_raw.get("index_id", ""),
        agent_id=rag_raw.get("agent_id", ""),
        total_context=int(rag_raw.get("total_context", 5)),
        timeout=float(rag_raw.get("timeout", 20.0)),
        tool_name=rag_raw.get("tool_name", "retrieve_context"),
        tool_description=rag_raw.get("tool_description", ""),
    )

    # --- Scope policy: fronteira determinística antes do RAG. ---
    scope_raw = raw.get("scope", {})
    scope_config = ScopeConfig(
        enabled=bool(scope_raw.get("enabled", False)),
        policy=scope_raw.get("policy", "keyword"),
        version=str(scope_raw.get("version", "")),
        in_scope_terms=list(scope_raw.get("in_scope_terms", [])),
        out_of_scope_terms=list(scope_raw.get("out_of_scope_terms", [])),
    )

    # --- Functional responses: fast-exits externos distintos e configuráveis. ---
    responses_raw = raw.get("responses", {})
    responses_config = ResponsesConfig(
        out_of_scope=responses_raw.get("out_of_scope", ""),
        no_context=responses_raw.get("no_context", ""),
        unavailable=responses_raw.get("unavailable", ""),
    )

    return AgentConfig(
        agent_id=raw["agent_id"],
        agent_name=raw["agent_name"],
        deployment=raw["deployment"],
        instructions=raw["instructions"],
        agent_description=raw["agent_description"],
        temperature=float(raw.get("temperature", 0.7)),
        top_p=float(raw.get("top_p", 1.0)),
        mcp=MCPConfig(
            # Ausência da chave preserva o comportamento anterior: MCP ligado.
            enabled=bool(mcp_raw.get("enabled", True)),
            servers=servers,
        ),
        metadata=metadata,
        llm=llm_config,
        guardrails=guardrails_config,
        rag=rag_config,
        scope=scope_config,
        responses=responses_config,
    )


_config: Optional[AgentConfig] = None
_config_lock = threading.Lock()


def get_config() -> AgentConfig:
    """Singleton thread-safe do AgentConfig."""
    global _config
    if _config is None:
        with _config_lock:
            if _config is None:
                _config = load_agent_config()
    return _config
