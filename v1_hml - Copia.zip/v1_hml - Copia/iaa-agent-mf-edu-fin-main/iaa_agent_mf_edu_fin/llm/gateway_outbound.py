"""gateway_outbound.py - Provedor LLM para o gateway Outbound.

Variável de ambiente obrigatória:
    GATEWAY_OUTBOUND_GW_APP_KEY - chave de autenticação do gateway
"""

from __future__ import annotations

import logging
import os
import ssl
from typing import Any

import httpx

from langchain_core.language_models import BaseChatModel

from iaa_agent_mf_edu_fin.config import get_config
from iaa_agent_mf_edu_fin.llm.base import LLMProvider

_logger = logging.getLogger(__name__)


class _GatewayTransport(httpx.AsyncHTTPTransport):
    """Adapta o contrato do SDK ao Gateway Outbound.

    O transport reescreve o path e injeta parâmetros técnicos; credenciais
    continuam vindo exclusivamente do ambiente de execução.
    """

    def __init__(self, gw_app_key: str, api_version: str = "2024-12-01-preview", **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._gw_app_key = gw_app_key
        self._api_version = api_version

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        new_path = request.url.path.replace("/chat/completions", "/cambio-chat-completion")

        params = dict(request.url.params)
        params["api-version"] = self._api_version

        new_url = request.url.copy_with(path=new_path, params=params)

        headers = {
            k: v for k, v in request.headers.items()
            if k.lower() != "authorization"
        }
        headers["x-application-key"] = self._gw_app_key

        request = request.__class__(
            method=request.method,
            url=new_url,
            headers=headers,
            stream=request.stream,
            extensions=request.extensions,
        )
        return await super().handle_async_request(request)


# Pools criados pelo provider são liberados pelo lifespan da aplicação.
# Eles não armazenam histórico ou respostas do agente.
_clients: list[httpx.AsyncClient] = []


async def close_http_clients() -> None:
    clients, _clients[:] = list(_clients), []
    for client in clients:
        await client.aclose()


class GatewayOutboundProvider(LLMProvider):
    def __init__(self, config=None):
        self._config = config

    def build(self, temperature: float, top_p: float) -> BaseChatModel:
        # O provider só é construído quando o A0 alcança SUCCESS com chunks,
        # ou quando o construtor legado é chamado explicitamente.
        from langchain_openai import ChatOpenAI

        cfg = self._config if self._config is not None else get_config().llm.gateway_outbound
        gw_app_key = os.environ["GATEWAY_OUTBOUND_GW_APP_KEY"]

        ssl_cert_path = os.environ.get("KEY_STORE_CERT_PATH")
        ssl_key_path = os.environ.get("KEY_STORE_KEY_PATH")
        # Prioridade: TRUST_STORE_CA_PATH > REQUESTS_CA_BUNDLE > CAs padrão com verificação.
        ca_path = os.environ.get("TRUST_STORE_CA_PATH") or os.environ.get("REQUESTS_CA_BUNDLE")

        ssl_cert = (ssl_cert_path, ssl_key_path) if ssl_cert_path and ssl_key_path else None

        if ca_path:
            ssl_context = ssl.create_default_context()
            ssl_context.load_verify_locations(cafile=ca_path)
            verify: ssl.SSLContext | bool = ssl_context
        else:
            verify = True

        transport_kwargs: dict = {"verify": verify}
        if ssl_cert:
            transport_kwargs["cert"] = ssl_cert

        http_client = httpx.AsyncClient(
            transport=_GatewayTransport(gw_app_key=gw_app_key, api_version=cfg.api_version, **transport_kwargs),
        )

        _clients.append(http_client)
        return ChatOpenAI(
            base_url=cfg.base_url,
            model=cfg.model,
            api_key="dummy",
            # Uma tentativa por chamada; retry não integra o A0 V2.
            max_retries=0,
            http_async_client=http_client,
            temperature=temperature,
            top_p=top_p,
            max_tokens=cfg.max_tokens,
        )
