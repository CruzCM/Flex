"""factory.py - Instancia o provedor LLM definido em agent_config.yaml.

Para adicionar um novo provedor:
  1. Crie iaa_agent_mf_edu_fin/llm/<nome>.py com classe herdando LLMProvider.
  2. Registre: LLMFactory.register("nome", MinhaClasse)
  3. Atualize agent_config.yaml: llm.provider: "nome"
"""

from __future__ import annotations

from typing import Dict, Type

from langchain_core.language_models import BaseChatModel

from iaa_agent_mf_edu_fin.llm.base import LLMProvider
from iaa_agent_mf_edu_fin.llm.gateway_outbound import GatewayOutboundProvider


class LLMFactory:
    # O registry permite providers adicionais; o A0 instancia somente o provider
    # selecionado pela configuração capturada daquela instância.
    _registry: Dict[str, Type[LLMProvider]] = {
        "gateway_outbound": GatewayOutboundProvider,
    }

    @classmethod
    def register(cls, name: str, provider_cls: Type[LLMProvider]) -> None:
        cls._registry[name] = provider_cls

    @classmethod
    def create(cls, provider: str, temperature: float, top_p: float, *, config=None) -> BaseChatModel:
        if provider not in cls._registry:
            raise ValueError(
                f"Provedor LLM desconhecido '{provider}'. "
                f"Disponíveis: {sorted(cls._registry)}"
            )
        # Mantém o contrato dos providers legados; o gateway aceita configuração explícita.
        provider_cls = cls._registry[provider]
        instance = provider_cls(config.gateway_outbound) if config is not None and provider_cls is GatewayOutboundProvider else provider_cls()
        return instance.build(temperature, top_p)
