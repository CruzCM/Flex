# iaa-agent-mf-edu-fin

> **A0 V2 nesta cópia — VALIDAÇÃO LOCAL.** O fluxo ativo é guardrails → escopo
> determinístico → RAG → judge observacional → geração → validators → guardrails
> de saída. Sem MCP ou Tool Calling; capacidades legadas exigem `AgentFactory.create_legacy`.
> `rag.enabled: false` significa indisponibilidade e readiness 503, sem geração alternativa.
> Consulte [o relatório de entrega](../RELATORIO_A0_V2.md) para aceite, testes, gates e reversão.
> A documentação histórica abaixo preserva exemplos do template legado e de infraestrutura;
> ela não comprova prontidão corporativa nem autoriza conexões a partir deste workspace.

## Comentários de implementação A0 V2

Os comentários no código são organizados por bloco funcional: ordem do grafo,
contratos do state, classificação do RAG, isolamento por configuração, telemetria,
privacidade, lifecycle e separação do caminho legado. Eles explicam responsabilidade,
motivo e restrição; não repetem cada linha.

O fluxo ativo é `guardrails → ScopePolicy → RAG → Context Precision → geração →
validators → guardrails de saída`. O caminho legado com MCP/Tools permanece acessível
somente por `AgentFactory.create_legacy()`. A fixture do RAG é sintética e os resultados
do workspace são `VALIDAÇÃO LOCAL`; contrato real, segurança corporativa, curadoria
humana e prontidão de produção precisam de evidência externa específica.

> **Atenção!**
>
> **Verifique se a versão Python indicada no arquivo "aic.json" é 3.11**
>
> **Configuração inicial de deploy em produção deve ser elaborada manualmente**
>
> A configuração do ambiente de deploy de produção **não é gerada automaticamente** por este template e deve ser elaborada manualmente pela equipe responsável, respeitando as políticas de infraestrutura e segurança vigentes.
>
> Os arquivos `Chart.yaml`, `values.yaml` e `README.md` (Helm chart) com a **configuração inicial esperada** estão disponíveis ao final deste documento, sendo necessário alteração para matrícula correta no campo `custodianteCertificado` em `values.yaml`. Eles podem ser utilizados de forma integral para a primeira versão do deploy, sendo necessária apenas a **ativação do Service** antes da execução - veja a seção [Configuração Inicial do Helm Chart](#configuração-inicial-do-helm-chart).

Microsserviço de agente de IA - agente LLM com suporte a RAG e ferramentas MCP, construído com FastAPI e LangGraph (LangChain).

> **Documentação do pipeline:** <https://fontes.intranet.bb.com.br/aic/publico/atendimento/-/wikis/Pipelines/Python>

---

## Sumário

- [Visão Geral](#visão-geral)
- [Estrutura do Projeto](#estrutura-do-projeto)
- [Endpoints](#endpoints)
- [Configuração do Agente](#configuração-do-agente)
- [Variáveis de Ambiente](#variáveis-de-ambiente)
- [Guardrails](#guardrails)
- [Validators (LLM-as-a-Judge)](#validators-llm-as-a-judge)
- [RAG - Recuperação de Contexto](#rag--recuperação-de-contexto)
- [Ferramentas MCP](#ferramentas-mcp)
- [Executando Localmente](#executando-localmente)
- [Executando com Docker](#executando-com-docker)
- [Testes](#testes)

---

## Visão Geral

Este serviço expõe um agente de IA como um microsserviço REST. Cada requisição é processada pelo agente LangGraph que:

1. Aplica **guardrails de entrada** (tamanho, injeção de prompt, PII, curador externo)
2. Monta o estado inicial com a mensagem do usuário
3. Avalia escopo sem LLM; consulta RAG diretamente para IN_SCOPE/UNDETERMINED.
4. Somente SUCCESS com chunks executa context_precision, uma geração e validators de toxicidade, PII e non_advice; Tool correctness fica no legado.
5. Aplica **guardrails de saída** (lista de bloqueio, redação de PII)
6. Retorna a resposta estruturada

O provedor LLM, as instruções do sistema, a temperatura, o `top_p` e os servidores MCP são todos configuráveis via `agent_config.yaml`, sem necessidade de alterar o código.

---

## Estrutura do Projeto

```
iaa_agent_mf_edu_fin/
├── __init__.py              # Versão do pacote
├── __main__.py              # Entrypoint Uvicorn (python -m iaa_agent_mf_edu_fin)
├── app.py                   # Aplicação FastAPI - todos os endpoints HTTP
├── config.py                # Carregador do agent_config.yaml (dataclasses tipadas)
├── graph.py                 # Agente LangGraph - AgentFactory + ValidatingToolNode
│
├── llm/
│   ├── base.py              # Classe abstrata LLMProvider
│   ├── gateway_outbound.py  # Provedor Gateway Outbound BB (padrão)
│   └── factory.py           # LLMFactory - registro e instanciação de provedores
│
├── rag/
│   └── rag_tool.py          # Ferramenta LangChain para recuperação via gateway Genera BB
│
├── validators/
│   ├── __init__.py          # BaseValidator, ValidationResult, ValidatorAction + OTel instrumentation
│   ├── context_precision.py # LLM-as-a-Judge: relevância dos chunks RAG recuperados
│   ├── non_advice.py        # Detecta conselhos financeiros/jurídicos/médicos (PT-BR + EN)
│   ├── pii_validator.py     # Detecção de PII com validação de checksum CPF/CNPJ
│   ├── semantic_similarity.py # Similaridade semântica por embeddings locais (rapidfuzz)
│   ├── tool_correctness.py  # Valida o uso correto das ferramentas disponíveis
│   └── toxicity.py          # Detecção de toxicidade por regex ponderado (PT-BR + EN)
│
└── utils/
    ├── filter_patterns.py        # Guardrails síncronos: injeção de prompt, PII, blocklist
    ├── genera_safe_guardrails.py # Guardrail externo via curador-iagen (Genera Safe)
    ├── guardrails_middleware.py  # Middleware Starlette que orquestra os guardrails
    └── tracing.py               # Bootstrap OpenTelemetry + Azure Monitor exporter

agent_config.yaml            # Configuração do agente (LLM, MCP, RAG, guardrails, instruções)
tests/
├── conftest.py              # Configuração do sys.path para os testes
├── unit/                    # Testes unitários (config, graph, llm, rag, validators)
└── integration/             # Testes de integração (endpoints FastAPI via ASGI)

Dockerfile                   # Imagem Python 3.11 com uv + OpenTelemetry
requirements.txt             # Dependências de runtime
setup.py                     # Metadados do pacote
.env.example                 # Template de variáveis de ambiente
```

---

## Endpoints

URL base: `http://localhost:8080`

### Agente

| Método | Rota | Descrição |
|--------|------|-----------|
| `POST` | `/chat` | Envia uma mensagem ao agente e recebe a resposta |

**Corpo da requisição** (`/chat`):

```json
{
  "message": "Quais são as diretrizes de IA ética e responsável?",
  "session_id": "sessao-123"
}
```

| Campo | Obrigatório | Descrição |
|-------|-------------|-----------|
| `message` | **Sim** | Mensagem de texto enviada ao agente |
| `session_id` | Não | Identificador opcional da sessão (ecoado na resposta) |

**Corpo da resposta**:

```json
{
  "reply": "As diretrizes de IA ética e responsável incluem...",
  "session_id": "sessao-123",
  "tool_calls_made": 1
}
```

| Campo | Descrição |
|-------|-----------|
| `reply` | Resposta gerada pelo agente |
| `session_id` | Identificador da sessão (mesmo valor enviado na requisição) |
| `tool_calls_made` | Número de ferramentas invocadas durante a resposta |

---

### Observabilidade

| Método | Rota | Descrição |
|--------|------|-----------|
| `GET` | `/health/live` | **Liveness probe** - retorna `200` enquanto o processo estiver em execução |
| `GET` | `/health/ready` | **Readiness probe** - verifica se a configuração está carregada |
| `GET` | `/metrics` | Contadores em processo: total de requisições, uptime, nome do agente |

**Resposta do `/metrics`**:

```json
{
  "uptime_seconds": 3612.5,
  "total_requests": 42,
  "agent_id": "agent-001",
  "agent_name": "Azure LangGraph Agent"
}
```

---

### Documentação da API (gerada automaticamente)

| Método | Rota | Descrição |
|--------|------|-----------|
| `GET` | `/docs` | Swagger UI |
| `GET` | `/redoc` | ReDoc UI |

---

## Configuração do Agente

O comportamento do agente é controlado pelo arquivo `agent_config.yaml` na raiz do projeto. **Nenhuma alteração de código é necessária** para trocar o LLM, as instruções do sistema, a temperatura ou os servidores MCP.

```yaml
agent_id: "agent-001"
agent_name: "Azure LangGraph Agent"
deployment: "azure"

llm:
  provider: "gateway_outbound"  # gateway_outbound (padrão) - extensível via LLMFactory.register()
  gateway_outbound:
    base_url: "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"
    model: "cambio-non-prod-gpt4o"
    api_version: "2024-12-01-preview"
    max_tokens: 4096

instructions: |
  Você é um assistente de IA prestativo. Use as ferramentas disponíveis
  para responder às perguntas dos usuários com precisão.

agent_description: "Descrição do agente exibida no Swagger."
temperature: 0.7
top_p: 0.95

guardrails:
  enabled: false
  url: "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"
  user_id: ""      # ex: F1234567
  uor: ""          # ex: 530652
  agent_id: "agente-curador-iagen"
  timeout: 5.0

rag:
  enabled: false
  url: "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"
  user_id: ""
  uor: ""
  agent_id: ""     # ID do agente RAG no Genera BB
  total_context: 5
  timeout: 10.0
  tool_name: "retrieve_context"
  tool_description: "Recupera contexto relevante para responder a pergunta do usuário."

mcp:
  servers:
    - name: "meu-servidor-mcp"
      description: "Servidor MCP de produção"
      transport:
        type: "http"
        endpoint: "https://meu-mcp.exemplo.com.br/mcp"
      authentication:
        type: "bearer"           # none | bearer | cert
        token_env_var: "MCP_TOKEN"  # nome da variável de ambiente com o token

metadata:
  owner: "time-ia"
  version: "1.0.0"
  created_at: "2026-03-11"
```

### Adicionando um novo provedor LLM

O `LLMFactory` suporta registro de provedores customizados. O único provedor registrado por padrão é `gateway_outbound`:

```python
from iaa_agent_mf_edu_fin.llm.factory import LLMFactory
from iaa_agent_mf_edu_fin.llm.base import LLMProvider

class MeuProvedor(LLMProvider):
    def build(self, temperature: float, top_p: float):
        # retorne um BaseChatModel
        ...

LLMFactory.register("meu-provedor", MeuProvedor)
```

Em seguida, defina `provider: "meu-provedor"` no `agent_config.yaml`.

---

## Variáveis de Ambiente

Copie `.env.example` para `.env` e preencha com os valores reais. **Nunca faça commit do `.env`.**

### Gateway Outbound BB (obrigatórias para o provedor `gateway_outbound`)

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `GATEWAY_OUTBOUND_GW_APP_KEY` | **Sim** | - | AppKey da aplicação registrada no Outbound Gateway BB |

### mTLS - Certificados de autenticação mútua

O Gateway Outbound BB exige autenticação mTLS com certificado cliente. Os certificados são obtidos nas secrets do container provisionado da aplicação.

| Variável | Obrigatória | Descrição |
|----------|-------------|-----------|
| `KEY_STORE_CERT_PATH` | **Sim** | Caminho absoluto para o certificado cliente `.crt` |
| `KEY_STORE_KEY_PATH` | **Sim** | Caminho absoluto para a chave privada `.key` |
| `TRUST_STORE_CA_PATH` | Recomendado | CA do BB para validar o certificado do servidor gateway |
| `REQUESTS_CA_BUNDLE` | Recomendado | Bundle de CAs do sistema |
| `SSL_CERT_FILE` | Recomendado | Alias para `REQUESTS_CA_BUNDLE` (usado por alguns SDKs Python) |

### RAG - Recuperação de Contexto

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `RAG_CLIENT_ID` | Se ativado | - | Token JWT para o header `X-Client-Id` |

> As demais configurações RAG (URL, agent_id, total_context, timeout, user_id, uor) ficam em `agent_config.yaml` na seção `rag:`.

### Guardrails Externos

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `GUARDRAIL_EXTERNAL_CLIENT_ID` | Se ativado | - | Token JWT para o header `X-Client-Id` |

> As demais configurações de guardrail externo (URL, agent_id, timeout, user_id, uor) ficam em `agent_config.yaml` na seção `guardrails:`.

### Guardrails de Entrada/Saída

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `GUARDRAIL_MAX_INPUT_LEN` | Não | `4096` | Tamanho máximo da mensagem em caracteres |
| `GUARDRAIL_BLOCK_PII_INPUT` | Não | `true` | Bloqueia mensagens com PII na entrada |
| `GUARDRAIL_REDACT_PII_OUTPUT` | Não | `true` | Redige PII na resposta do agente |

### Observabilidade e Runtime

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `APPLICATION_INSIGHTS_CONNECTION_STRING` | Não | - | Connection string do Azure Application Insights. Deixe vazio para desabilitar OTel export |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | Não | - | Endpoint OTLP alternativo (ex: coletor local) |
| `SERVICE_NAME` | Não | - | Nome do serviço injetado como dimensão em todas as métricas |
| `DEPLOY_ENV` | Não | - | Ambiente de deploy (`desenv` / `homol` / `prod`) |
| `OTEL_RECORD_CONTENT` | Não | `true` | `false` para omitir conteúdo de mensagens dos traces |
| `HOST` | Não | `0.0.0.0` | Host de escuta do Uvicorn |
| `PORT` | Não | `8080` | Porta de escuta do Uvicorn |
| `LOG_LEVEL` | Não | `info` | Nível de log do Uvicorn |
| `WORKERS` | Não | `1` | Número de workers Uvicorn |

---

## Guardrails

O middleware `GuardrailsMiddleware` protege o endpoint `/chat` em duas etapas:

### Verificações de entrada (em ordem)

| # | Verificação | Comportamento ao reprovar |
|---|-------------|--------------------------|
| 1 | **Tamanho** - mensagem acima de `GUARDRAIL_MAX_INPUT_LEN` | Retorna HTTP 400 `input_too_long` |
| 2 | **Injeção de prompt / jailbreak** - padrões regex conhecidos | Retorna HTTP 400 `prompt_injection` |
| 3 | **PII na entrada** - e-mail, telefone, CPF, CNPJ, cartão, SSN | Retorna HTTP 400 `pii_detected` |
| 4 | **Curador externo** - avaliação pelo agente `curador-iagen` (opcional) | Retorna HTTP 400 `external_guardrail` |

### Verificações de saída

| # | Verificação | Comportamento |
|---|-------------|---------------|
| 5 | **Lista de bloqueio** - frases proibidas na resposta | Substitui a resposta por mensagem genérica |
| 6 | **Redação de PII** - PII detectado na resposta | Substitui tokens por `[EMAIL]`, `[CPF]`, etc. |

> Todos os guardrails externos **falham em aberto** - erros de rede nunca bloqueiam o tráfego.

---

## Validators (LLM-as-a-Judge)

Os validators são executados **dentro do grafo LangGraph**, após cada invocação de ferramenta, via `ValidatingToolNode`. Eles não bloqueiam o fluxo - emitem spans e métricas OpenTelemetry que fluem para o Azure Application Insights automaticamente.

Cada validator herda de `BaseValidator` e implementa `_validate()`. A ação padrão de todos é `LOG_ONLY`.

| Validator | Arquivo | O que avalia |
|-----------|---------|--------------|
| `ContextPrecisionValidator` | `context_precision.py` | Qualidade (relevância) dos chunks retornados pelo RAG - usa LLM-as-a-Judge |
| `ToolCorrectnessValidator` | `tool_correctness.py` | Se a ferramenta invocada pertence ao conjunto registrado e se os argumentos são válidos |
| `ToxicityValidator` | `toxicity.py` | Toxicidade na saída: ameaças, assédio, discurso de ódio, automutilação (PT-BR + EN) |
| `NonAdviceValidator` | `non_advice.py` | Conselhos financeiros, jurídicos ou médicos diretos na resposta (PT-BR + EN) |
| `PIIValidator` | `pii_validator.py` | PII na resposta: e-mail, telefone, CPF (com checksum), CNPJ (com checksum), cartão, SSN |

### Métricas OTel emitidas por validator

| Métrica | Tipo | Descrição |
|---------|------|-----------|
| `validator.invocations` | Counter | Total de invocações por validator |
| `validator.passed` | Counter | Validações aprovadas |
| `validator.failed` | Counter | Validações reprovadas |
| `validator.score` | Histogram | Score de confiança (0–1) |
| `validator.latency_ms` | Histogram | Latência de execução em ms |

---

## RAG - Recuperação de Contexto

Quando `rag.enabled: true` em `agent_config.yaml`, a ferramenta `retrieve_context` (nome configurável via `rag.tool_name`) é adicionada automaticamente ao conjunto de ferramentas do agente. O agente decide autonomamente quando chamá-la com base nas instruções do sistema.

A ferramenta realiza uma chamada `POST` ao gateway Genera BB com a ação `recuperar-contexto` e retorna uma lista de blocos de contexto que são incorporados à resposta do LLM.

Após cada chamada RAG, o `ContextPrecisionValidator` avalia automaticamente a relevância dos chunks recuperados e registra o score como span OTel.

---

## Ferramentas MCP

O agente carrega ferramentas de servidores MCP configurados em `agent_config.yaml`. Se um servidor estiver inacessível no momento da inicialização da requisição, o agente **degrada graciosamente** e opera sem as ferramentas daquele servidor, registrando um aviso nos logs.

Autenticação suportada por servidor MCP:

| Tipo | Configuração |
|------|-------------|
| `none` | Sem autenticação |
| `bearer` | Token lido de variável de ambiente (`token_env_var`) |
| `cert` | Certificado mTLS (`cert_path` + `key_path`) |

---

## Executando Localmente

```bash
# 1. Criar o ambiente virtual
python -m venv .venv && source .venv/bin/activate

# 2. Instalar as dependências
pip install -r requirements.txt
pip install -e .

# 3. Configurar o ambiente
cp .env.example .env
# edite o .env com os valores reais

# 4. Iniciar o serviço
python -m iaa_agent_mf_edu_fin
# ou
uvicorn iaa_agent_mf_edu_fin.app:app --host 0.0.0.0 --port 8080 --reload
```

O Swagger UI estará disponível em: <http://localhost:8080/docs>

---

## Executando com Docker

```bash
# Build e inicialização
cp .env.example .env   # preencha os segredos
docker build --build-arg versao=dev -t iaa-agent:local .
docker run --rm --env-file .env -p 8080:8080 iaa-agent:local

# Verificações rápidas
curl http://localhost:8080/health/live
curl http://localhost:8080/health/ready
curl http://localhost:8080/metrics

# Invocar o agente
curl -s -X POST http://localhost:8080/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Quais são as diretrizes de IA ética e responsável?",
    "session_id": "exemplo-001"
  }' | python3 -m json.tool
```

---

## Testes

```bash
# Instalar dependências de teste
pip install -e ".[unit,integration]"

# Rodar todos os testes
pytest

# Apenas testes unitários
pytest tests/unit/

# Apenas testes de integração
pytest tests/integration/

# Com cobertura
pytest --cov=iaa_agent_mf_edu_fin --cov-report=term-missing
```


---

## Configuração Inicial do Helm Chart

Os arquivos abaixo representam a **configuração inicial esperada** para o deploy em produção. Eles podem ser copiados integralmente para a primeira versão, sendo necessário apenas habilitar o `Service` no `values.yaml` antes da execução (campo `service.enable: true`).

---

### `Chart.yaml`

```yaml
apiVersion: v2
appVersion: "0.0.1"
description: Chart padrão e suas dependências do projeto iaa-agent-mf-edu-fin
name: chart-iaa-agent-mf-edu-fin
version: 0.0.1
dependencies:
- name: dia-chart-agent
  version: 1.0.0
  alias: iaa-agent-mf-edu-fin
  repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/dia

- name: bbcert
  version: ~1.0.7
  repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/psc

- name: idh-operator-chart
  version: 0.0.13
  repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/idh
```

---

### `values.yaml`

```yaml
iaa-agent-mf-edu-fin:
  projetoPiloto: false
  multEnv: false
  service:
    name: iaa-agent-mf-edu-fin
    enable: true
    type: ClusterIP
    ports:
      - name: http
        port: 80
        targetPort: 8080

  # Horizontal Pod Autoscaler
  # https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/
  hpa:
    enable: false
    minReplicas: 2
    maxReplicas: 5
    memory: {}
      # averageUtilization: 70
    cpu: {}
      #averageUtilization: 70

  deployment:
    enable: true
    imagePullSecrets: atfregistry
    replicaCount: 1
    extraLabels: {}
      # key: value
    containers:
      #Informe apenas a Tag da sua imagem que está no ATF (atf.intranet.bb.com.br).
      tag: "0.1.0-SNAPSHOT"
      imagePullPolicy: IfNotPresent
      # command: '[ "sh", "/tmp/cmd.sh" ]'
      environments:
        - name: MP_OPENAPI_SERVERS
          value: https://iaa-agent-mf-edu-fin.iaa.intranet.bb.com.br
        - name: ENABLE_INDEX
          value: index.html
        - name: ENABLE_SWAGGER
          value: "false"
        - name: OTEL_K8S_NODE_IP
          valueFrom:
            fieldRef:
              fieldPath: status.hostIP
        - name: "OTEL_EXPORTER_OTLP_ENDPOINT"
          value: "http://$(OTEL_K8S_NODE_IP):4317"
        ## Adicione essa configuração para desabilitar métricas para certos endpoints
        - name: OTEL_PYTHON_EXCLUDED_URLS
          value: "v1/health/.*,metrics"
        # Se for preciso debugar o OTEL, adicione estas configurações:
        # - name: OTEL_LOG_LEVEL
        #   value: DEBUG
        - name: KEY_STORE_CERT_PATH
          value: /app/certs/tls.crt
        - name: KEY_STORE_KEY_PATH
          value: /app/certs/tls.key
        - name: TRUST_STORE_CA_PATH
          value: /app/certs/ca.crt
        # Trust store usado por bibliotecas Python genéricas (requests, azure-core,
        # httpx, urllib3, etc.) para validar TLS de endpoints externos — como o
        # endpoint Live Metrics do Azure Application Insights, que sai pelo proxy
        # corporativo (MITM) do BB.
        #
        # No OpenShift (UBI/RHEL) o bundle consolidado fica em
        # /etc/pki/tls/certs/ca-bundle.crt (symlink para
        # /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem), já com as CAs do BB.
        # A CA do gateway IDH continua sendo carregada à parte via
        # TRUST_STORE_CA_PATH (acima) no cliente do gateway_outbound, que tem
        # precedência específica para mTLS.
        - name: REQUESTS_CA_BUNDLE
          value: /etc/pki/tls/certs/ca-bundle.crt
        - name: SSL_CERT_FILE
          value: /etc/pki/tls/certs/ca-bundle.crt
      # Se Habilitar o bbcert é necessário mudar a MP_OPENAPI_SERVERS para https
      envFrom:
        - secretRef:
            name: env
      ports: []
      #  - name: http
      #    containerPort: 8080
      resources:
        requests:
          cpu: 50m         # Valor em millicores/millicpu (m)
          memory: 250Mi    # Valor em megabyte (MiB)
        limits:
          cpu: 3001m       # Valor em millicores/millicpu (m)
          memory: 375Mi    # Valor em megabyte (MiB)
      livenessProbe:
        initialDelaySeconds: 30
        periodSeconds: 10
        timeoutSeconds: 10
        failureThreshold: 6
        successThreshold: 1
        httpGet:
          path: "/health/live"
          port: 8080
      readinessProbe:
        initialDelaySeconds: 30
        periodSeconds: 10
        timeoutSeconds: 10
        failureThreshold: 6
        successThreshold: 1
        httpGet:
          path: "/health/ready"
          port: 8080

      volumeMounts:
        - name: tls-certs-volume
          mountPath: /app/certs
          readOnly: true
    volumes:
      - name: tls-certs-volume
        secret:
          secretName: idh-mtls
          items:
            - key: tls.crt
              path: tls.crt
            - key: tls.key
              path: tls.key
            - key: ca.crt
              path: ca.crt

    strategy:
      type: RollingUpdate
      # rollingUpdate:
      #     maxSurge: 1
      #     maxUnavailable: 0
    nodeSelector: {}
    # key: value
    tolerations: []
    #- key: "key"
    #  operator: "Equal"
    #  value: "value"
    #  effect: "NoSchedule"
    hostAliases: []
    # serviceAccountName: service-account
    initContainer:
      enable: false
      image: bb/psc/busybox #será concatenado à atf.intranet.bb.com.br:5001
      tag: "1.31.1"
      imagePullPolicy: IfNotPresent
      #command: '[ "sh", "/tmp/cmd.sh" ]'
      environments: []
      #- name: key
      #  value: "value"
      envFrom: []
      #- configMapRef:
      #    name: app-configmap
      #- secretRef:
      #    name: app-secret
      resources:
        requests:
          cpu: 100m       # Valor em millicores/millicpu (m)
          memory: 250Mi   # Valor em megabyte (MiB)
        limits:
          cpu: 150m       # Valor em millicores/millicpu (m)
          memory: 375Mi   # Valor em megabyte (MiB)
      volumeMounts: []
      #- mountPath: /folder-aplic
      #  name: data

  deploymentCanario:
    enable: false
    deploymentControle: false   # Criação do deployment de controle
    imagePullSecrets: atfregistry
    replicaCount: 1
    extraLabels: {}
      # key: value
    containers:
      tag: "0.0.2"
      imagePullPolicy: IfNotPresent
      # command: '[ "sh", "/tmp/cmd.sh" ]'
      environments: []
      envFrom: []
      ports: []
      livenessProbe: {}
      readinessProbe: {}
      resources:
        requests:
          cpu: 100m         # Valor em millicores/millicpu (m)
          memory: 250Mi     # Valor em megabyte (MiB)
        limits:
          cpu: 150m         # Valor em millicores/millicpu (m)
          memory: 375Mi     # Valor em megabyte (MiB)
      volumeMounts: []
    # serviceAccountName: service-account
    volumes: []
    nodeSelector: {}
    tolerations: []
    strategy: {}
    hostAliases: []
    initContainer:
      enable: false
      image: bb/psc/busybox # path da imagem dentro do atf.intranet.bb.com.br:5001
      tag: "1.31.1"
      imagePullPolicy: IfNotPresent
      #command: '[ "sh", "/tmp/cmd.sh" ]'
      environments: []
      envFrom: []
      resources:
        requests:
          cpu: 100m       # Valor em millicores/millicpu (m)
          memory: 200Mi   # Valor em megabyte (MiB)
        limits:
          cpu: 300m       # Valor em millicores/millicpu (m)
          memory: 200Mi   # Valor em megabyte (MiB)
      volumeMounts: []

  ingress:
    enable: true
    hostname: iaa-agent-mf-edu-fin.iaa.intranet.bb.com.br
    servicePort: 80
    annotations:
      kubernetes.io/ingress.class: ingress-interno-iib
      haproxy.org/timeout-connect: "30s"
      haproxy.org/timeout-server: "1800s"
      haproxy.org/timeout-client: "1800s"
    paths:
      - path: "/"
        backend:
          serviceName: iaa-agent-mf-edu-fin
          servicePort: 80
    tls:
      - secretName: iaa-agent-mf-edu-fin-tls
        hosts:
          - iaa-agent-mf-edu-fin.iaa.intranet.bb.com.br

  ingressExterno:
    enable: false
    hostname: iaa-agent-mf-edu-fin.iaa.intranet.bb.com.br
    path: "/"
    servicePort: 80
    annotations:
      kubernetes.io/ingress.class: nginx-externo
    paths: []
    tls: []

  serviceMonitor:
    enable: false
    monitorNamespace: #xyz-monitor
    labels: {}
      # sigla: xyz # sua sigla!
    endpoints: []
      # - port: http
      #   interval: 10s
      #   path: /metrics
    sampleLimit: 40000

  curio:
    # Consulte a versão do curió mais estável em https://fontes.intranet.bb.com.br/iib/publico/iib-container/iib-curio/iib-curio/-/wikis/home
    enable: false
    tag: "0.9.10"
    environments:
      - name: "CURIO_SIGLA_APLICACAO"
        value: "iaa"
      - name: "CURIO_CACHE_CONFIGURACAO_IIB"
        value: "redis.iib-cache-config"
      - name: "CURIO_CACHE_CONFIGURACAO_IIB_ID"
        value: "iib:configuracao:k8s-integracao"
      - name: "CURIO_IIB_LOG_LEVEL"
        value: "INFO"
     # - name: "CURIO_OP_PROVEDOR"
     #   value: "ATENÇÃO! Houve um erro ao inserir operações automaticamente. Favor inserí-la(s)"
     # - name: "CURIO_OP_CONSUMIDOR"
     #   value: "ATENÇÃO! Houve um erro ao inserir operações automaticamente. Favor inserí-la(s)"
      - name: "KUMULUZEE_LOGS_LOGGERS0_NAME"
        value: "br.com.bb.iaa.curio"
      - name: "CURIO_LOG_LEVEL"
        value: "INFO"
        # Adicione sua chave IDH:
     # - name: "IDH_CHAVE_APLICACAO"
       # valueFrom:
         # secretKeyRef:
           # name: "sigla-nome-servico-iib"
           # key: "idh"
    resources:
      requests:
        cpu: 350m       # Valor em millicores/millicpu (m)
        memory: 250Mi   # Valor em megabyte (MiB)
      limits:
        cpu: 450m       # Valor em millicores/millicpu (m)
        memory: 375Mi   # Valor em megabyte (MiB)
    livenessProbe:
      initialDelaySeconds: 60
      httpGet:
        path: /health/live
        port: 8081
      periodSeconds: 20
      timeoutSeconds: 5
      failureThreshold: 6
      successThreshold: 1
    readinessProbe:
      initialDelaySeconds: 120
      httpGet:
        path: /health/ready
        port: 8081
      periodSeconds: 20
      timeoutSeconds: 5
      failureThreshold: 6
      successThreshold: 1
    volumeMounts: []
      # - mountPath: /folder-aplic
      #   name: folder
    volumes: []
      # - name: folder
      #   emptyDir: {}

  persistenceVolume:
    enable: false
    persistentVolumeClaim: pvc-name
    storageClass: nas-client
    storageSize: 1Gi

  configMaps:
  #   - name: configmap1
  #     data:
  #       file1.sh: |
  #         #!/usr/bin/env bash
  #         echo "Hello world"
  #       file2.ini: |
  #         [BBAPLIC]
  #         Name = bb-aplic
  #         Company = Banco do Brasil S.A.
  #         [bb.com.br]
  #         Team = bb-cloud
  #   - name: configmap2
  #     data:
  #       file3.yaml: |
  #         struct1:
  #           name: bb-aplic
  #           company: Banco do Brasil S.A.
  #         struct2:
  #           team: bb-cloud

  # Lista de conectividade da aplicação
  conectividade: []
  #   - nome: api-xpto                # Nome da conectividade
  #     destino:                      # Lista de destinos que a sua aplicação deve ter acesso.
  #       - url: api.xpto.bb.com.br   # URL ou ip de destino
  #         protocolo: tcp            # Protocolo (TCP ou UDP)
  #         porta:                    # Lista de portas
  #           - 443
  #           - 80
  #       - url: 127.0.0.1
  #         protocolo: tcp
  #         porta:
  #           - 80
  #   - nome: ldap-des
  #     destino:
  #       - url: ldp0pb1.bb.com.br
  #         protocolo: tcp
  #         porta:
  #           - 636

  # Processamento com feature de CPU AVX
  processamentoAVX: false

  # Processamento com feature de GPU
  processamentoGPU: false
  processamentoGPUmem: 3    # Qtd de vcuda-memory / 1 vcuda-memory = 256MiB

  # Acesso ao proxy corporativo cache.bb
  acessoProxy: false

dnsingress:
  urls:
    - hostname: iaa-agent-mf-edu-fin.iaa.intranet.bb.com.br
      ingressClass: ingress-interno-iib

idhmtls:
  enabled: true
  renewTime: 365
  secretName: "idh-mtls"
  nomesAlternativos: []

bbcert:
  enabled: true

  custodianteCertificado:
    # Informe a matricula do funcionário que receberá os e-mails enviados pela
    # PKI BB e pelo Portal OaaS, no formato 'F99999999'.
    matriculaBB: "F99999999"

  # Todos os campos de 'dadosCertificado' são 'imutáveis', não podendo ser alterados
  # após a criação do objeto BBCert, caso seja necessário alterar algum desses
  # dados então crie um novo objeto BBCert e após criação apague o anterior.
  dadosCertificado:
    # 'ambientePKI' indica qual servidor PKI irá assinar esse certificado,
    # valores aceitos "des", "hml" ou "prd".
    ambientePKI: "prd"
    # 'commomName' é a URL principal a ser autenticada neste certificado, por
    # exemplo 'sigla.hm.bb.com.br'.
    commomName: "iaa-agent-mf-edu-fin.iaa.intranet.bb.com.br"
    # 'alternativesNames' é um array de strings, com as URL´s alternativas /
    # adicionais, a serem autenticadas juntamente neste certificado, por exemplo:
    # - "*.sigla.hm.bb.com.br"
    # - "outra-url.sigla.hm.bb.com.br"
    alternativesNames:
      - "*.iaa-agent-mf-edu-fin.iaa.intranet.bb.com.br"
    # 'ttl' determina a validade do certificado, valor máximo e default '365'.
    ttl: 365
    # 'secretNameToExport' indica o nome da Secret onde será armazenado o
    # certificado gerado.
    secretNameToExport: "iaa-agent-mf-edu-fin-tls"

  # A secção de 'autoRenew' trata da renovação automatica do certificado.
  autoRenew:
    # Habilita ou não o controle da renovação pelo BBCert Operator.
    enabled: true
    # 'qtDaysBeforeCertExpirion' indica com quantos dias antes do vencimento o
    # BBCert Operator deve providenciar a renovação do certificado e atualização
    # da Secret
    qtDaysBeforeCertExpirion: 30

```
