"""Unit tests for ContextPrecisionValidator (RAG LLM-as-a-Judge)."""

import pytest

import iaa_agent_mf_edu_fin.validators.context_precision as cp_module
from iaa_agent_mf_edu_fin.validators.context_precision import (
    ContextPrecisionValidator,
    _call_llm_judge,
)


def test_context_precision_no_context_skips():
    validator = ContextPrecisionValidator()

    result = validator.validate("", context=None)

    assert result.passed is True
    assert result.score == pytest.approx(1.0)


def test_context_precision_empty_chunks_fails():
    validator = ContextPrecisionValidator()

    result = validator.validate("", context={"query": "o que e sopro?", "chunks": []})

    assert result.passed is False
    assert result.score == pytest.approx(0.0)
    assert "no chunks" in result.details


def test_context_precision_below_threshold(monkeypatch):
    validator = ContextPrecisionValidator()

    monkeypatch.setattr(
        cp_module,
        "_call_llm_judge",
        lambda query, chunks: (0.1, {"reason": "irrelevante", "method": "llm_as_judge"}),
    )

    result = validator.validate(
        "", context={"query": "clima hoje", "chunks": ["texto sobre fisica quantica"]}
    )

    assert result.passed is False
    assert result.score < validator.threshold


def test_call_llm_judge_parses_direct_json_response(monkeypatch):
    """Template uses json.loads() directly (no markdown-fence stripping)."""
    class _FakeResponse:
        content = '{"score": 0.8, "reason": "relevante"}'

    class _FakeLLM:
        def invoke(self, _messages):
            return _FakeResponse()

    monkeypatch.setattr(cp_module, "_build_judge_llm", lambda: _FakeLLM())
    # Exercita o template real; substituir o prompt esconderia falhas de formatação.

    score, meta = _call_llm_judge("o que e sopro?", ["chunk relevante"])

    assert score == pytest.approx(0.8)
    assert meta["reason"] == "relevante"
    assert meta["chunk_count"] == 1


def test_context_precision_llm_failure_fail_open(monkeypatch):
    validator = ContextPrecisionValidator()

    def _raise(_query, _chunks):
        raise RuntimeError("judge unavailable")

    monkeypatch.setattr(cp_module, "_call_llm_judge", _raise)

    result = validator.validate("", context={"query": "q", "chunks": ["c"]})

    assert result.passed is True
    assert result.score == pytest.approx(0.5)
    assert "judge error" in result.details
