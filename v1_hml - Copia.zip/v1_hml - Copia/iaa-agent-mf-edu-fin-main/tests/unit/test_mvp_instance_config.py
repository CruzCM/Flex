"""Critérios mínimos da Etapa 0 para a instância de educação financeira."""

from pathlib import Path

from iaa_agent_mf_edu_fin.config import load_agent_config


# Estes testes validam o agent_config.yaml usado pela instância, não uma cópia.
_ROOT = Path(__file__).parents[2]


def test_mvp_prompt_is_rag_grounded_and_non_advisory():
    config = load_agent_config(_ROOT / "agent_config.yaml")
    instructions = config.instructions.casefold()

    # O prompt precisa proibir conhecimento externo e aconselhamento personalizado.
    assert "somente os trechos" in instructions
    assert "não complete lacunas" in instructions
    assert "não recomende investimentos" in instructions
    assert "não preste consultoria personalizada" in instructions


def test_mvp_rag_uses_direct_index_contract():
    config = load_agent_config(_ROOT / "agent_config.yaml")

    # O índice direto usa /gateway/core e index_id, sem descrição de Tool ativa.
    assert config.rag.url.endswith("/gateway/core")
    assert config.rag.resolved_index_id == "idx-mf-edu-fin"
    assert config.rag.tool_description == ""


def test_mvp_scope_policy_is_identified_and_versioned():
    config = load_agent_config(_ROOT / "agent_config.yaml")

    # Versão explícita torna alterações futuras de classificação auditáveis.
    assert config.scope.enabled is True
    assert config.scope.policy == "keyword"
    assert config.scope.version == "mf-edu-fin-mvp-v1"


def test_mvp_fast_exit_messages_are_present_and_distinct():
    config = load_agent_config(_ROOT / "agent_config.yaml")
    messages = {
        config.responses.out_of_scope,
        config.responses.no_context,
        config.responses.unavailable,
    }

    # Três causas diferentes não podem compartilhar mensagem vazia ou única.
    assert "" not in messages
    assert len(messages) == 3
