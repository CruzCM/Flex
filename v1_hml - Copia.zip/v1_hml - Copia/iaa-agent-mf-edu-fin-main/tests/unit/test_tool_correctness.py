"""Unit tests for ToolCorrectnessValidator using LLM-as-a-Judge flow."""

import pytest

import iaa_agent_mf_edu_fin.validators.tool_correctness as tc_module
from iaa_agent_mf_edu_fin.validators.tool_correctness import (
    ToolCorrectnessValidator,
    _call_llm_judge,
)


def test_tool_correctness_no_context_skips_with_full_score():
    validator = ToolCorrectnessValidator()

    result = validator.validate("", context=None)

    assert result.passed is True
    assert result.score == pytest.approx(1.0)


def test_tool_correctness_unknown_tool_uses_llm_judge(monkeypatch):
    """Template routes unknown tools through the LLM judge (no deterministic block)."""
    validator = ToolCorrectnessValidator(known_tools={"retrieve_context", "calculator"})

    def _fake_call(payload):
        assert payload["tool_name"] == "invented_tool"
        return 0.1, {
            "reason": "invented_tool is not an appropriate tool.",
            "issues": ["unknown tool"],
            "recommended_tool": "retrieve_context",
            "method": "llm_as_judge",
        }

    monkeypatch.setattr(tc_module, "_call_llm_judge", _fake_call)

    result = validator.validate("", context={"tool_name": "invented_tool"})

    assert result.passed is False
    assert result.score == pytest.approx(0.1)


def test_tool_correctness_llm_judge_quality_below_threshold(monkeypatch):
    validator = ToolCorrectnessValidator(known_tools={"retrieve_context"})

    def _fake_call(payload):  # noqa: ARG001
        return 0.15, {
            "reason": "Tool should have been calculator for arithmetic intent.",
            "issues": ["wrong tool selected"],
            "recommended_tool": "calculator",
            "method": "llm_as_judge",
        }

    monkeypatch.setattr(tc_module, "_call_llm_judge", _fake_call)

    result = validator.validate(
        "",
        context={
            "user_query": "what is 42*9?",
            "intent": "arithmetic",
            "tool_name": "retrieve_context",
            "tool_args": {"query": "42*9"},
            "tool_result": "[]",
        },
    )

    assert result.passed is False
    assert 0.0 < result.score < validator.threshold
    assert result.metadata["recommended_tool"] == "calculator"


def test_call_llm_judge_parses_direct_json_response(monkeypatch):
    """Template uses json.loads() directly (no markdown-fence stripping)."""
    class _FakeResponse:
        content = '{"score": 0.75, "reason": "good", "issues": [], ' \
                  '"recommended_tool": ""}'

    class _FakeLLM:
        def invoke(self, _messages):
            return _FakeResponse()

    monkeypatch.setattr(tc_module, "_build_judge_llm", lambda: _FakeLLM())
    # Template real preserva a detecção de erros de formatação do legado.

    risk_score, meta = _call_llm_judge({"tool_name": "retrieve_context"})

    assert risk_score == pytest.approx(0.75)
    assert meta["reason"] == "good"
    assert meta["method"] == "llm_as_judge"


def test_tool_correctness_llm_failure_fail_open(monkeypatch):
    validator = ToolCorrectnessValidator(known_tools={"retrieve_context"})

    def _raise(_payload):
        raise RuntimeError("judge unavailable")

    monkeypatch.setattr(tc_module, "_call_llm_judge", _raise)

    result = validator.validate("", context={"tool_name": "retrieve_context"})

    assert result.passed is True
    assert result.score == pytest.approx(1.0)
    assert "judge error" in result.details
