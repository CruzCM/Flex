with open('tests/unit/test_rag_tool.py', 'r', encoding='utf-8') as f:
    code = f.read()
code = code.replace('.chunks .chunks', '.chunks')
with open('tests/unit/test_rag_tool.py', 'w', encoding='utf-8') as f:
    f.write(code)
