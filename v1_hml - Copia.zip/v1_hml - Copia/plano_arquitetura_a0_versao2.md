# Arquitetura do Agente A0 Informacional — Versão 2

> [!IMPORTANT]
> **Status: arquitetura final consolidada para o template A0 Informacional baseado em RAG**
>
> Esta versão substitui a Versão 1 como referência arquitetural.
>
> A principal evolução da V2 é a inclusão de uma fronteira **determinística de escopo antes do RAG**, mantendo o template genérico para qualquer agente informacional baseado em recuperação documental.
>
> A arquitetura agora explicita quatro fronteiras:
>
> ```text
> Segurança
> → Escopo
> → Evidência RAG
> → Geração
> ```
>
> A implementação atual de educação financeira é apenas uma instância desse template.

---

# 1. Resumo das diferenças entre V1 e V2

A V1 estabeleceu o núcleo determinístico:

```text
Guardrails
→ RAG obrigatório
→ RAGResult
→ LLM somente com contexto
```

A V2 mantém integralmente esse núcleo, mas adiciona decisões que ainda não estavam formalizadas.

| Tema | V1 | V2 |
|---|---|---|
| Início do pipeline funcional | RAG | `scope_gate_node` |
| Regra do RAG | obrigatório para toda requisição aceita | obrigatório para toda requisição não rejeitada por segurança ou escopo |
| Controle de escopo | não formalizado | obrigatório e determinístico |
| Política de escopo | inexistente | `ScopePolicy`, específica por agente |
| Resultado de escopo | inexistente | `IN_SCOPE`, `OUT_OF_SCOPE`, `UNDETERMINED` |
| Fora de escopo | acabaria confundido com ausência de contexto | resposta própria e fast-exit |
| Casos difíceis de classificar | não definidos | `UNDETERMINED` segue para o RAG |
| Motivos de não resposta | fallback RAG único | três respostas funcionais distintas |
| `NO_CONTEXT` | fallback | resposta específica de ausência documental |
| `INFRA_ERROR` | mesmo fallback de ausência documental | resposta específica de indisponibilidade |
| Público final | não formalizado | Clientes do App na instância atual |
| Consumidor técnico | Orquestrador | permanece Orquestrador |
| SLOs | sem definição | política explícita de não inventar metas |
| Timeouts | comportamento técnico | continuam técnicos/configuráveis, não são SLOs |
| Observabilidade | RAG e validators | passa a incluir também `scope_result` |
| `AgentState` | `messages`, `rag_context`, `rag_result` | adiciona `scope_result` |
| Testes | RAG determinístico | adiciona regressão de escopo e três respostas externas |

A V2 **não desfaz** a decisão de remover Tool Calling. O RAG continua sendo uma etapa sequencial obrigatória para as requisições que chegam à camada de evidência.

---

# 2. Visão executiva

O A0 é um **template de agente informacional** cuja resposta factual é fundamentada exclusivamente em documentação recuperada via RAG.

Ele não é um agente transacional e não deve usar conhecimento paramétrico do LLM como fonte factual independente.

A arquitetura final é:

```text
Requisição
→ Guardrails de entrada
→ Scope Gate determinístico
→ RAG obrigatório quando não houver bloqueio de escopo
→ decisão pelo resultado da recuperação
→ LLM somente quando houver chunks
→ validators pós-LLM
→ Guardrails de saída
→ resposta
```

Em forma resumida:

```mermaid
flowchart TD
    A["POST /chat"] --> B["Guardrails de entrada"]
    B --> C["scope_gate_node"]
    C --> D{"scope_result"}

    D -- "OUT_OF_SCOPE" --> E["OUT_OF_SCOPE_REPLY"]

    D -- "IN_SCOPE" --> F["retrieve_context_node"]
    D -- "UNDETERMINED" --> F

    F --> G["GeneraBB /gateway/core"]
    G --> H["context_precision<br/>observacional"]
    H --> I{"rag_result"}

    I -- "SUCCESS" --> J["llm_node"]
    J --> K["validators pós-LLM"]

    I -- "NO_CONTEXT" --> L["RAG_NO_CONTEXT_REPLY"]
    I -- "INFRA_ERROR" --> M["RAG_UNAVAILABLE_REPLY"]

    E --> N["Guardrails de saída"]
    K --> N
    L --> N
    M --> N

    N --> O["ChatResponse<br/>tool_calls_made = 0"]
```

---

# 3. Natureza genérica do template

Este documento **não define um agente de educação financeira como arquitetura**.

Ele define um template reutilizável:

```text
Agente A0 Informacional
+
domínio configurado
+
ScopePolicy configurada
+
índice RAG configurado
+
prompt configurado
```

Exemplos de possíveis instâncias:

```text
A0 Educação Financeira
A0 Cartões
A0 Seguros
A0 Benefícios
A0 Funcionalidades do App
A0 Atendimento documental de outro domínio
```

Cada agente poderá ter:

- domínio diferente;
- índice diferente;
- taxonomia de escopo diferente;
- prompt diferente;
- resposta de fora de escopo diferente;
- dificuldade diferente para classificar escopo.

A arquitetura não deve codificar o domínio concreto.

---

# 4. Definições da instância atual

A implementação que motivou esta versão possui as seguintes definições:

| Item | Definição atual |
|---|---|
| Domínio | educação financeira |
| Destinatário final do conteúdo | Clientes do App |
| Consumidor técnico da API | Orquestrador |
| `rag.index_id` | `idx-mf-edu-fin` |
| `RAG_CLIENT_ID` | disponível |
| `rag.user_id` | disponível e preenchido |
| `rag.uor` | disponível e preenchido |
| Genera Safe | desativado nesta versão |
| Código do Genera Safe | preservado no template |
| `GUARDRAIL_EXTERNAL_CLIENT_ID` | não requerido enquanto Genera Safe estiver desativado |
| Prompt final | depende de validação negocial; não bloqueia arquitetura |
| `rag.tool_description` | permanece no YAML vazio e comentado |
| Parsing de `retrieved_contexts` | será definido com payload real do GeneraBB |
| Fora de escopo | bloqueio determinístico |
| SLOs de disponibilidade/latência | não definidos; não inventar |

> [!IMPORTANT]
> Esses valores não devem ser confundidos com contratos universais do template.
>
> Em particular, `idx-mf-edu-fin` e o domínio “educação financeira” pertencem somente à instância atual.

---

# 5. Atores e responsabilidades

## 5.1 Orquestrador

Responsável por:

- rotear chamadas para o agente adequado;
- manter estado/histórico conversacional fora do A0;
- enviar a mensagem atual;
- consumir a resposta do A0.

O Orquestrador **não substitui** a proteção local de escopo do agente.

## 5.2 Agente A0

Responsável por:

- aplicar sua fronteira funcional de escopo;
- recuperar documentação;
- distinguir ausência de conteúdo de falha técnica;
- gerar resposta somente com evidência RAG;
- preservar governança de entrada/saída.

## 5.3 Cliente do App

Na instância atual de educação financeira, é o destinatário final do conteúdo produzido.

A distinção é:

```text
Consumidor técnico
→ Orquestrador

Destinatário do conteúdo
→ Cliente do App
```

---

# 6. Escopo da V2

## 6.1 Dentro do escopo

- `ScopePolicy`;
- `ScopeResult`;
- `scope_gate_node`;
- bloqueio determinístico de fora de escopo;
- RAG sequencial obrigatório após a fronteira de escopo;
- `/gateway/core`;
- `index_id`;
- retrocompatibilidade com `agent_id`;
- `RAGResult`;
- `RAGResponse`;
- estado explícito do LangGraph;
- `context_precision`;
- tracing;
- três respostas funcionais de não atendimento;
- atualização de testes;
- contrato HTTP compatível;
- preparação para memória futura;
- política de não inventar SLOs.

## 6.2 Fora do escopo

- memória conversacional nesta entrega;
- alteração do contrato `/chat` para receber histórico;
- agentes transacionais;
- múltiplas Tools;
- MCP;
- re-ranking;
- cache RAG;
- streaming;
- mudança do Orquestrador;
- SLOs quantitativos não aprovados;
- mudança de validators observacionais para enforcement;
- uso de LLM para decidir deterministicamente o escopo;
- taxonomia universal de domínio no template.

---

# 7. Invariantes arquiteturais

## 7.1 Segurança vem antes do domínio

Nenhuma avaliação funcional deve substituir os guardrails HTTP.

```text
Guardrails
→ Scope Gate
```

## 7.2 Fora de escopo não consulta RAG nem LLM

Se:

```text
scope_result = OUT_OF_SCOPE
```

então:

```text
RAG = não executado
LLM = não executado
```

## 7.3 Dúvida de escopo não é bloqueio

Se a política local não consegue determinar inequivocamente que a pergunta está fora:

```text
scope_result = UNDETERMINED
```

e o fluxo segue para RAG.

## 7.4 RAG é obrigatório após a fronteira de escopo

A regra definitiva é:

> **Toda requisição que tenha passado pelos guardrails e não tenha sido deterministicamente rejeitada pela política de escopo deve consultar o RAG antes de qualquer geração pelo LLM.**

## 7.5 Nenhum LLM sem evidência

```text
NO_CONTEXT
INFRA_ERROR
```

não chamam o LLM.

## 7.6 RAG é a fonte factual

O LLM pode:

- sintetizar;
- explicar;
- resumir;
- organizar;
- adaptar linguagem.

Não pode:

- preencher lacunas documentais com conhecimento externo;
- inventar funcionalidades;
- responder factual e autonomamente sem chunks.

## 7.7 Memória futura não será fonte factual

Memória poderá ajudar a entender:

```text
"isso"
"aquilo"
"o mesmo caso"
```

mas os fatos continuam vindo do RAG.

## 7.8 Observadores permanecem observadores

A refatoração não transforma `context_precision` ou validators existentes em mecanismos de bloqueio sem uma decisão arquitetural explícita.

## 7.9 Não inventar requisitos não funcionais

Sem definição formal:

```text
não criar SLO de disponibilidade
não criar SLO de latência
não transformar timeout em SLO
```

---

# 8. Fronteiras do sistema

```mermaid
flowchart LR
    O["Orquestrador"] --> A["Agente A0"]
    A --> G["GeneraBB<br/>/gateway/core"]
    A --> L["LLM"]
    A --> T["Azure / OpenTelemetry"]
```

O A0 permanece stateless nesta versão.

---

# 9. Contrato HTTP externo

## 9.1 Request

```json
{
  "message": "string",
  "session_id": "string | null"
}
```

## 9.2 Response

```json
{
  "reply": "string",
  "session_id": "string | null",
  "tool_calls_made": 0
}
```

## 9.3 Compatibilidade

O schema externo permanece intacto.

A recuperação RAG deixa de ser Tool, portanto:

```text
tool_calls_made = 0
```

## 9.4 Respostas funcionais controladas

Os seguintes resultados continuam sendo processamento bem-sucedido do endpoint:

```text
OUT_OF_SCOPE
NO_CONTEXT
INFRA_ERROR tratado
```

A decisão arquitetural é devolver resposta funcional com:

```text
HTTP 200
```

para os três casos.

Erros de guardrail continuam seguindo a semântica existente da aplicação.

Exceptions técnicas não tratadas continuam sujeitas ao tratamento global e podem resultar em HTTP 500.

---

# 10. Guardrails

## 10.1 Entrada

Antes do LangGraph:

- limite de tamanho;
- prompt injection;
- PII de entrada;
- Genera Safe, quando habilitado.

```mermaid
flowchart TD
    A["POST /chat"] --> B{"Tamanho válido?"}
    B -- "NÃO" --> X1["400 input_too_long"]
    B -- "SIM" --> C{"Prompt seguro?"}
    C -- "NÃO" --> X2["400 prompt_injection"]
    C -- "SIM" --> D{"PII entrada?"}
    D -- "SIM" --> X3["400 pii_detected"]
    D -- "NÃO" --> E{"Genera Safe habilitado?"}
    E -- "NÃO" --> F["AgentGraph.ainvoke"]
    E -- "SIM" --> GS{"Genera Safe passou?"}
    GS -- "NÃO" --> X4["400 external_guardrail"]
    GS -- "SIM" --> F
```

## 10.2 Instância atual

Genera Safe está desativado.

Isso não remove:

- código;
- configuração estrutural;
- capacidade futura de ativação.

## 10.3 Saída

Toda resposta funcional produzida pelo grafo passa pelo middleware de saída:

```text
resposta do LLM
OUT_OF_SCOPE_REPLY
RAG_NO_CONTEXT_REPLY
RAG_UNAVAILABLE_REPLY
```

Mantêm-se:

- blocklist;
- redação de PII;
- demais regras já existentes.

---

# 11. Controle de escopo

## 11.1 Objetivo

Evitar que um agente especializado:

- consulte documentação desnecessariamente;
- gere resposta sobre assunto claramente fora de sua responsabilidade;
- dependa exclusivamente do Orquestrador para proteger sua fronteira funcional.

## 11.2 Posição no pipeline

```text
Guardrails
→ Scope Gate
→ RAG
```

Nunca:

```text
RAG
→ descobrir depois que a pergunta era claramente fora de escopo
```

quando a política local consegue determinar isso de forma objetiva.

---

# 12. `ScopePolicy`

`ScopePolicy` é uma abstração obrigatória do template.

Ela define como a instância decide, de forma não generativa, se uma pergunta pode ser rejeitada por escopo antes do RAG.

Conceitualmente:

```python
class ScopePolicy(Protocol):
    def evaluate(self, message: str) -> "ScopeResult":
        ...
```

A implementação concreta pode variar por agente.

Pode utilizar, por exemplo:

- taxonomia de domínio;
- regras versionadas;
- categorias;
- listas controladas;
- metadados;
- expressões;
- classificadores determinísticos previamente aprovados;
- combinação de regras testáveis.

O template **não deve impor uma taxonomia universal**.

---

# 13. Requisito de determinismo no escopo

O bloqueio de fora de escopo não deve depender de um LLM generativo tomando uma decisão subjetiva.

Motivo:

```text
bloqueio obrigatório
+
LLM probabilístico
=
fronteira instável
```

A política precisa ser:

- versionável;
- testável;
- reproduzível;
- auditável;
- específica do domínio.

Isso não significa que a política conseguirá resolver todos os casos.

Por isso existe `UNDETERMINED`.

---

# 14. `ScopeResult`

```python
from enum import Enum

class ScopeResult(Enum):
    IN_SCOPE = "in_scope"
    OUT_OF_SCOPE = "out_of_scope"
    UNDETERMINED = "undetermined"
```

## 14.1 `IN_SCOPE`

A política possui evidência determinística de que a pergunta pertence ao domínio.

Ação:

```text
seguir para RAG
```

## 14.2 `OUT_OF_SCOPE`

A política possui evidência determinística de que a pergunta não pertence ao domínio.

Ação:

```text
não chamar RAG
não chamar LLM
retornar OUT_OF_SCOPE_REPLY
```

## 14.3 `UNDETERMINED`

A política não consegue decidir com segurança.

Ação:

```text
seguir para RAG
```

Essa decisão é intencional: em caso de dúvida, o template prefere consultar sua fonte documental a bloquear incorretamente uma pergunta potencialmente válida.

---

# 15. Por que não usar somente `IN_SCOPE` / `OUT_OF_SCOPE`

Alguns domínios terão fronteiras simples.

Outros terão fronteiras semânticas difíceis.

Forçar uma decisão binária produziria:

```text
falso OUT_OF_SCOPE
→ bloqueio antes do RAG
→ perda de resposta válida
```

O terceiro estado permite que o template continue genérico.

---

# 16. `scope_gate_node`

## 16.1 Responsabilidade

```text
mensagem atual
→ ScopePolicy.evaluate
→ scope_result
```

## 16.2 Fluxo

```mermaid
flowchart TD
    A["message"] --> B["scope_gate_node"]
    B --> C["ScopePolicy.evaluate"]
    C --> D{"ScopeResult"}
    D -- "IN_SCOPE" --> E["retrieve_context_node"]
    D -- "UNDETERMINED" --> E
    D -- "OUT_OF_SCOPE" --> F["OUT_OF_SCOPE_REPLY"]
```

## 16.3 O que não faz

- não chama RAG;
- não chama LLM;
- não avalia qualidade de chunks;
- não substitui guardrails;
- não usa `context_precision`;
- não decide disponibilidade técnica.

---

# 17. Política de escopo por agente

O template define:

```text
interface
resultado
posição no grafo
semântica
testes esperados
```

Cada instância define:

```text
taxonomia
regras
versão
casos permitidos
casos explicitamente bloqueados
```

Na instância atual:

```text
domínio = educação financeira
```

A taxonomia concreta de educação financeira não é inventada neste documento.

Ela deve ser:

- configurada/implementada;
- versionada;
- testada;
- revisada conforme o domínio evolui.

Casos não cobertos com confiança devem resultar em:

```text
UNDETERMINED
```

---

# 18. RAG obrigatório após escopo

A V2 substitui a frase simplificada:

> “RAG é obrigatório para toda requisição.”

pela regra precisa:

> **RAG é obrigatório para toda requisição que passou pelos guardrails e cujo `scope_result` não seja `OUT_OF_SCOPE`.**

Isso inclui:

```text
IN_SCOPE
UNDETERMINED
```

---

# 19. Por que o RAG não é Tool

Tool Calling é adequado quando existe escolha entre capacidades.

Exemplo:

```text
LLM
├── consultar RAG
├── consultar saldo
├── abrir chamado
└── executar operação
```

No A0:

```text
Scope Gate
→ RAG
→ LLM
```

A recuperação é uma etapa estrutural, não uma escolha do modelo.

Portanto saem do fluxo A0:

- `bind_tools`;
- `tools_condition`;
- `ValidatingToolNode`;
- `ToolMessage` para transportar chunks;
- `AIMessage.tool_calls` para decidir a recuperação;
- `build_rag_tool` como ponto de integração do grafo.

---

# 20. Estado do LangGraph

## 20.1 Estado antigo

```python
class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
```

## 20.2 Estado da V1

```python
class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
    rag_context: List[str]
    rag_result: str
```

## 20.3 Estado da V2

```python
class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
    scope_result: str
    rag_context: List[str]
    rag_result: str
```

## 20.4 Motivo

O projeto usa LangGraph com estado tipado e canais explícitos.

A validação no template confirmou que tentar publicar chaves não declaradas no schema pode produzir:

```text
InvalidUpdateError
```

em runtime.

Assim:

```text
scope_result
rag_context
rag_result
```

devem existir formalmente no `AgentState`.

---

# 21. Semântica do estado

## `messages`

Mensagens utilizadas pelo fluxo.

## `scope_result`

```text
in_scope
out_of_scope
undetermined
```

## `rag_context`

Chunks normalizados:

```python
list[str]
```

## `rag_result`

```text
success
no_context
infra_error
```

---

# 22. Separação entre tipos de domínio e estado

Pode-se manter enums nos módulos responsáveis:

```python
ScopeResult.IN_SCOPE
RAGResult.SUCCESS
```

e publicar valores simples no estado:

```python
"in_scope"
"success"
```

Isso mantém o state simples e serializável.

---

# 23. `RAGResult` e `RAGResponse`

```python
class RAGResult(Enum):
    SUCCESS = "success"
    NO_CONTEXT = "no_context"
    INFRA_ERROR = "infra_error"
```

```python
@dataclass
class RAGResponse:
    chunks: list[str]
    result: RAGResult
    error_detail: str = ""
```

## 23.1 `SUCCESS`

```text
requisição válida
+
um ou mais chunks
```

## 23.2 `NO_CONTEXT`

```text
Genera respondeu corretamente
+
zero chunks
```

## 23.3 `INFRA_ERROR`

Exemplos:

- timeout;
- falha HTTP;
- conexão;
- configuração necessária ausente;
- `RAG_CLIENT_ID` inválido/ausente;
- `index_id` inválido/ausente;
- resposta técnica não processável.

---

# 24. Contrato GeneraBB

## 24.1 Endpoint

```text
/gateway/core
```

## 24.2 Action

```text
recuperar-contexto-indice
```

## 24.3 Payload

```json
{
  "action": "recuperar-contexto-indice",
  "body": {
    "data": {
      "input": "<query>",
      "context": {
        "query_type": "hybrid",
        "total_context": 5
      },
      "index_id": "<index_id>"
    }
  }
}
```

## 24.4 Headers e identificação

Mantêm-se os dados exigidos pelo contrato adotado:

- `RAG_CLIENT_ID`;
- `UOR`;
- `userIdentification` / `user_id`.

Não registrar esses dados sensíveis em claro na telemetria.

## 24.5 Ausências intencionais

Não enviar ao Core:

- histórico de mensagens;
- `agent_id` como identificador primário;
- Tool schema;
- decisões do LLM.

---

# 25. Parsing de `retrieved_contexts`

O envelope conhecido é:

```python
data.get("data", {}).get("retrieved_contexts")
```

A V2 mantém a decisão de **não adivinhar o schema interno**.

Não implementar:

```text
tenta text
senão content
senão page_content
senão str(item)
```

Fluxo aprovado:

```text
chamada real ao /gateway/core
→ captura do JSON bruto
→ documentação do schema
→ parsing explícito
→ fixture baseada no payload real
→ teste unitário
```

A normalização interna continua tendo como alvo:

```python
list[str]
```

---

# 26. `retrieve_context_node`

## 26.1 Responsabilidade

Transformar a query atual em estado RAG.

## 26.2 Pré-condição

Só deve ser alcançado quando:

```text
scope_result = in_scope
```

ou:

```text
scope_result = undetermined
```

Nunca para:

```text
out_of_scope
```

## 26.3 Fluxo interno

```mermaid
flowchart TD
    A["query"] --> B["RAG client"]
    B --> C{"RAGResult"}

    C -- "SUCCESS" --> D["context_precision"]
    D --> E["rag_context = chunks"]
    E --> F["rag_result = success"]

    C -- "NO_CONTEXT" --> G["rag_context = []"]
    G --> H["rag_result = no_context"]

    C -- "INFRA_ERROR" --> I["rag_context = []"]
    I --> J["rag_result = infra_error"]
```

---

# 27. `context_precision`

## 27.1 Natureza

É um validator observacional.

Sua interface atual recebe:

```python
validate(
    text: str,
    context: Dict[str, Any] | None = None
) -> ValidationResult
```

e usa:

```python
context["query"]
context["chunks"]
```

## 27.2 Novo ponto de execução

Depois do retorno de chunks:

```text
Genera
→ parse
→ context_precision
→ estado RAG
```

## 27.3 Não controla o fluxo

Baixa precisão:

```text
não vira OUT_OF_SCOPE
não vira NO_CONTEXT
não vira INFRA_ERROR
não bloqueia LLM nesta versão
```

Gera telemetria.

## 27.4 Fail-open

Falhas internas do judge continuam observacionais conforme o comportamento atual.

---

# 28. Separação entre escopo e precisão

Esses mecanismos não devem ser confundidos.

## Scope Gate

Pergunta:

> “Esta entrada pertence claramente ao domínio configurado para este agente?”

Características:

- antes do RAG;
- determinístico;
- não generativo;
- pode bloquear.

## `context_precision`

Pergunta:

> “Os chunks recuperados parecem relevantes para a query?”

Características:

- depois do RAG;
- observacional;
- atualmente usa judge;
- não bloqueia.

---

# 29. `llm_node`

## 29.1 Pré-condição

```text
rag_result = success
```

## 29.2 Entrada

```text
System instructions
+
mensagem
+
rag_context
```

## 29.3 Não utiliza

- `bind_tools`;
- Tool schema;
- `ToolMessage`;
- `tool_call_id`;
- `AIMessage.tool_calls`.

## 29.4 Invariante

Se o `llm_node` for alcançado sem chunks, a topologia está incorreta.

---

# 30. Prompt

O prompt deve reforçar que:

```text
rag_context = única fonte factual
```

Estrutura conceitual:

```yaml
instructions: |
  Você é um assistente informacional especializado no domínio configurado para este agente.
  Responda SOMENTE com base nas informações recuperadas do contexto RAG fornecido.
  Não utilize conhecimento externo à documentação fornecida.
  Seja claro, objetivo e mantenha o tom definido para o produto.
  Se o contexto não contiver informação suficiente, não invente informações.
```

A redação exata é configurável por agente.

Na instância atual, a versão final será validada com o time negocial.

Isso não bloqueia a implementação técnica.

---

# 31. Validators pós-LLM

Continuam no caminho de sucesso.

Exemplos confirmados no template:

- toxicity;
- PII;
- `non_advice`.

Fluxo:

```text
LLM
→ validators pós-LLM
→ Guardrails de saída
```

Eles não são executados nos fast-exits que não passam pelo LLM.

---

# 32. `tool_correctness`

No A0 determinístico não existe escolha de Tool.

Logo:

```text
tool_correctness
→ não executado no A0
```

O arquivo permanece no template para possíveis agentes baseados em Tool Calling.

Não removê-lo globalmente.

---

# 33. Três motivos externos de não responder

A V2 separa semanticamente três casos.

## 33.1 Fora de escopo

Estado:

```text
scope_result = out_of_scope
```

Resposta:

```text
OUT_OF_SCOPE_REPLY
```

Significado externo:

> o assunto não pertence à responsabilidade deste agente.

## 33.2 Sem documentação

Estado:

```text
rag_result = no_context
```

Resposta:

```text
RAG_NO_CONTEXT_REPLY
```

Significado externo:

> o assunto passou pela fronteira de escopo, mas a base não forneceu documentação suficiente.

## 33.3 Indisponibilidade técnica

Estado:

```text
rag_result = infra_error
```

Resposta:

```text
RAG_UNAVAILABLE_REPLY
```

Significado externo:

> a fonte necessária não pôde ser consultada/processada naquele momento.

---

# 34. Regra de mensagens

Os três casos precisam ter textos distintos.

Entretanto, os textos concretos:

- são configuráveis;
- podem passar por validação negocial;
- não devem expor detalhes internos.

Não expor, por exemplo:

```text
HTTPX timeout
Genera 500
RAG_CLIENT_ID
stack trace
index inválido
```

---

# 35. Semântica HTTP dos fast-exits

Decisão:

| Caso | HTTP |
|---|---:|
| `OUT_OF_SCOPE` | 200 |
| `NO_CONTEXT` | 200 |
| `INFRA_ERROR` tratado pelo fluxo | 200 |

Isso significa que o sistema processou a solicitação e produziu uma resposta funcional controlada.

Não confundir com:

- erro de guardrail;
- request inválido;
- exception não tratada;
- falha de infraestrutura fora do tratamento previsto.

---

# 36. Matriz funcional completa

| Scope | RAG | Chunks | `context_precision` | LLM | Resposta |
|---|---|---:|---|---|---|
| `OUT_OF_SCOPE` | não chama | n/a | não | não | `OUT_OF_SCOPE_REPLY` |
| `IN_SCOPE` | sucesso | >0 | executa | sim | resposta gerada |
| `UNDETERMINED` | sucesso | >0 | executa | sim | resposta gerada |
| `IN_SCOPE` | sucesso | 0 | n/a | não | `RAG_NO_CONTEXT_REPLY` |
| `UNDETERMINED` | sucesso | 0 | n/a | não | `RAG_NO_CONTEXT_REPLY` |
| `IN_SCOPE` | erro | n/a | não | não | `RAG_UNAVAILABLE_REPLY` |
| `UNDETERMINED` | erro | n/a | não | não | `RAG_UNAVAILABLE_REPLY` |
| `IN_SCOPE` | sucesso | >0 | baixa | sim | resposta + telemetria |
| `UNDETERMINED` | sucesso | >0 | baixa | sim | resposta + telemetria |

---

# 37. Observabilidade

## 37.1 Antes da remoção de Tools

O callback LangChain/Azure capturava eventos:

```text
on_tool_start
on_tool_end
```

## 37.2 Depois

Esperado:

```text
AgentGraph
├── scope_gate_node
└── retrieve_context_node
    └── RAG.gateway_core
```

## 37.3 Chamada HTTP ao Genera

Como a chamada `httpx` pura não é coberta pelo Tool callback, usar o tracer OTel/Azure existente:

```python
tracer = get_tracer(__name__)

with tracer.start_as_current_span("RAG.gateway_core"):
    response = await client.post(...)
```

## 37.4 Escopo

A V2 deve observar:

```text
scope.result = in_scope | out_of_scope | undetermined
```

e, quando apropriado:

```text
scope.policy.version
```

sem registrar conteúdo sensível desnecessário.

## 37.5 RAG

Observar:

- duração;
- resultado;
- quantidade de chunks;
- status técnico;
- timeout;
- erros.

## 37.6 Validators

Preservar métricas existentes, incluindo `context_precision`.

---

# 38. SLOs e requisitos não funcionais

## 38.1 Regra

Não inventar SLOs.

Não registrar arbitrariamente:

```text
disponibilidade = 99.9%
p95 = 5s
resposta máxima = 30s
resposta máxima = 60s
```

sem aprovação corporativa.

## 38.2 Timeouts técnicos

Timeout é mecanismo operacional, não SLO.

Faz sentido manter timeout configurável para dependências como:

```text
GeneraBB
LLM
```

Mas:

```text
timeout de 30s
```

não significa:

```text
SLO de 30s
```

## 38.3 Preparação para SLO futuro

A arquitetura deve medir:

- latência end-to-end;
- latência do Scope Gate;
- latência do RAG;
- latência do LLM;
- taxa de resultados RAG;
- taxa de `OUT_OF_SCOPE`;
- erros técnicos.

Quando metas oficiais vierem, dashboards/alertas podem ser construídos sobre essas métricas sem refatorar o desenho principal.

---

# 39. Configuração RAG e retrocompatibilidade

## 39.1 Campo principal

```yaml
rag:
  index_id: ""
```

## 39.2 Campo legado

```yaml
rag:
  agent_id: ""
```

## 39.3 Fallback

```python
index_id = rag_raw.get("index_id", rag_raw.get("agent_id", ""))
```

## 39.4 Precedência

Se ambos existirem:

```text
index_id vence
```

## 39.5 Instância atual

```yaml
rag:
  index_id: "idx-mf-edu-fin"
```

---

# 40. `rag.tool_description`

A regra do template é preservar chaves de configuração mesmo quando deixarem de ser utilizadas pelo A0, caso sua presença seja relevante para schema/esteira/compatibilidade.

Nesta instância:

```yaml
rag:
  tool_description: ""  # Não utilizado no A0: o RAG é um nó obrigatório, não uma Tool.
```

Não participa da execução.

---

# 41. Genera Safe

O código permanece no template.

Na instância atual:

```text
Genera Safe = desativado
```

Consequências:

- não exigir `GUARDRAIL_EXTERNAL_CLIENT_ID` nesta entrega;
- preservar possibilidade futura de ativação;
- não remover o código por limpeza oportunista.

A segurança ativa continua incluindo os mecanismos locais já existentes.

---

# 42. `tool_calls_made`

A implementação atual conta `ToolMessage`.

Com a remoção do RAG como Tool:

```text
ToolMessage RAG = inexistente
```

Logo:

```text
tool_calls_made = 0
```

Decisão:

- manter campo;
- não fingir uma Tool Call;
- atualizar testes.

---

# 43. Memória futura

## 43.1 Nesta versão

Não implementar.

Contrato atual permanece:

```json
{
  "message": "...",
  "session_id": "..."
}
```

## 43.2 Dono da memória

Orquestrador.

## 43.3 Ponto de extensão

Futuramente:

```mermaid
flowchart TD
    A["message"] --> P["prepare_query_node<br/>futuro"]
    M["memory / history"] -.-> P
    P --> S["scope_gate_node"]
    S --> R["retrieve_context_node"]
    R --> L["llm_node"]
```

A preparação de query deve ocorrer antes da avaliação de escopo e da recuperação quando a memória for necessária para interpretar corretamente a pergunta.

## 43.4 Separação conceitual

```text
Memória
→ contexto conversacional

ScopePolicy
→ fronteira funcional

RAG
→ fatos

LLM
→ síntese
```

---

# 44. Arquitetura atual versus V2

## 44.1 Template original

```mermaid
flowchart TD
    A["message"] --> B["LLM"]
    B --> C{"tool_calls?"}
    C -- "SIM" --> D["ValidatingToolNode"]
    D --> E["RAG Tool"]
    E --> F["ToolMessage"]
    F --> B
    C -- "NÃO" --> G["resposta"]
```

## 44.2 V1

```mermaid
flowchart TD
    A["message"] --> B["RAG obrigatório"]
    B --> C{"rag_result"}
    C -- "SUCCESS" --> D["LLM"]
    C -- "NO_CONTEXT" --> E["fallback"]
    C -- "INFRA_ERROR" --> E
```

## 44.3 V2

```mermaid
flowchart TD
    A["message"] --> B["Scope Gate"]
    B --> C{"scope_result"}

    C -- "OUT_OF_SCOPE" --> O["OUT_OF_SCOPE_REPLY"]
    C -- "IN_SCOPE" --> R["RAG obrigatório"]
    C -- "UNDETERMINED" --> R

    R --> D{"rag_result"}
    D -- "SUCCESS" --> L["LLM"]
    D -- "NO_CONTEXT" --> N["RAG_NO_CONTEXT_REPLY"]
    D -- "INFRA_ERROR" --> I["RAG_UNAVAILABLE_REPLY"]
```

---

# 45. Sequência completa — sucesso

```mermaid
sequenceDiagram
    participant U as Cliente do App
    participant O as Orquestrador
    participant M as GuardrailsMiddleware
    participant G as LangGraph
    participant S as Scope Gate
    participant R as RAG Node
    participant BB as GeneraBB
    participant CP as Context Precision
    participant L as LLM
    participant V as Validators

    U->>O: pergunta
    O->>M: POST /chat
    M->>M: guardrails de entrada
    M->>G: AgentGraph.ainvoke
    G->>S: avaliar escopo
    S-->>G: IN_SCOPE ou UNDETERMINED
    G->>R: recuperar contexto
    R->>BB: POST /gateway/core
    BB-->>R: chunks
    R->>CP: query + chunks
    CP-->>R: ValidationResult
    R-->>G: rag_context + success
    G->>L: instructions + pergunta + chunks
    L-->>G: reply
    G->>V: validators pós-LLM
    V-->>G: ValidationResults
    G-->>M: reply
    M->>M: guardrails de saída
    M-->>O: ChatResponse
    O-->>U: resposta
```

---

# 46. Sequência — fora de escopo

```mermaid
sequenceDiagram
    participant O as Orquestrador
    participant M as GuardrailsMiddleware
    participant G as LangGraph
    participant S as Scope Gate

    O->>M: POST /chat
    M->>M: guardrails de entrada
    M->>G: invoke
    G->>S: avaliar escopo
    S-->>G: OUT_OF_SCOPE
    G-->>M: OUT_OF_SCOPE_REPLY
    M->>M: guardrails de saída
    M-->>O: HTTP 200 / ChatResponse
```

O Genera e o LLM não são chamados.

---

# 47. Sequência — sem conteúdo

```mermaid
sequenceDiagram
    participant O as Orquestrador
    participant M as GuardrailsMiddleware
    participant G as LangGraph
    participant R as RAG Node
    participant BB as GeneraBB

    O->>M: POST /chat
    M->>G: invoke
    G->>R: recuperar contexto
    R->>BB: /gateway/core
    BB-->>R: []
    R-->>G: no_context
    G-->>M: RAG_NO_CONTEXT_REPLY
    M->>M: guardrails de saída
    M-->>O: HTTP 200 / ChatResponse
```

---

# 48. Sequência — indisponibilidade

```mermaid
sequenceDiagram
    participant O as Orquestrador
    participant M as GuardrailsMiddleware
    participant G as LangGraph
    participant R as RAG Node
    participant BB as GeneraBB

    O->>M: POST /chat
    M->>G: invoke
    G->>R: recuperar contexto
    R->>BB: /gateway/core
    BB--xR: timeout / HTTP error / falha técnica
    R-->>G: infra_error
    G-->>M: RAG_UNAVAILABLE_REPLY
    M->>M: guardrails de saída
    M-->>O: HTTP 200 / ChatResponse
```

---

# 49. Mudanças por módulo

## `app.py`

- contrato preservado;
- `tool_calls_made` passa a `0`;
- três respostas funcionais continuam entrando no mesmo `ChatResponse`;
- testes de contagem precisam ser atualizados.

## `utils/guardrails_middleware.py`

Arquitetura preservada.

Confirmar regressão para:

- resposta normal;
- fora de escopo;
- ausência documental;
- indisponibilidade tratada.

## `graph.py`

Principal alteração.

Adicionar:

```text
ScopeResult
scope_result no AgentState
scope_gate_node
roteamento de escopo
retrieve_context_node
roteamento RAG
```

Remover do fluxo A0:

```text
tools_condition
ValidatingToolNode
bind_tools
ToolMessage de RAG
tool_correctness
```

## Módulo de política de escopo

A organização física pode seguir as convenções do projeto.

Responsabilidade:

- expor a `ScopePolicy`;
- executar regras determinísticas;
- retornar `ScopeResult`;
- permitir versionamento/testes por domínio.

O template não deve codificar regras de educação financeira diretamente no node genérico.

## `rag/rag_tool.py`

- `/gateway/core`;
- `recuperar-contexto-indice`;
- `RAGResult`;
- `RAGResponse`;
- parsing explícito;
- span HTTP;
- sem wrapper Tool no caminho A0.

## `config.py`

- `index_id`;
- fallback para `agent_id`;
- suportar configurações necessárias para a política de escopo sem impor uma taxonomia universal.

## `validators/context_precision.py`

Sem mudança conceitual interna.

Muda o ponto de chamada.

## `validators/tool_correctness.py`

Permanece no template.

Não executa no A0.

## `utils/tracing.py`

Reutilizado pelo RAG.

Pode registrar informações de escopo conforme convenção existente.

---

# 50. Configuração de escopo

A arquitetura exige uma `ScopePolicy`, mas **não fixa um schema universal de taxonomia**.

Motivo:

```text
domínios simples
≠
domínios complexos
```

O contrato mínimo é:

- política habilitada para o A0;
- versão identificável;
- regras testáveis;
- saída em `ScopeResult`;
- resposta de fora de escopo configurável.

A estrutura exata pode ser definida na implementação respeitando o padrão de configuração do projeto.

---

# 51. Estratégia de implementação

## Fase 1 — preservar baseline

- executar testes atuais;
- registrar failures já existentes;
- não misturar regressões anteriores com a refatoração.

## Fase 2 — defeitos isolados

- remover código morto conhecido no Genera Safe.

## Fase 3 — contratos de domínio

Adicionar:

```text
ScopeResult
RAGResult
RAGResponse
```

e ampliar `AgentState`.

## Fase 4 — Scope Gate

- implementar `ScopePolicy`;
- implementar `scope_gate_node`;
- adicionar roteamento;
- adicionar `OUT_OF_SCOPE_REPLY`.

## Fase 5 — camada RAG

- corrigir endpoint;
- corrigir payload;
- index_id;
- headers;
- tratamento de erros;
- tracing;
- parsing após payload real.

## Fase 6 — grafo determinístico

- ligar Scope Gate ao RAG;
- remover Tool Calling;
- criar roteamento RAG;
- separar respostas `NO_CONTEXT` e `INFRA_ERROR`.

## Fase 7 — validators

- reposicionar `context_precision`;
- manter validators pós-LLM;
- não executar `tool_correctness`.

## Fase 8 — configuração da instância

- `idx-mf-edu-fin`;
- UOR/user_id;
- Genera Safe desativado;
- `tool_description` vazio;
- política de escopo da educação financeira.

## Fase 9 — testes

Atualizar toda a suíte relevante.

## Fase 10 — chamada real ao Genera

- capturar JSON;
- fechar parsing;
- criar fixture;
- validar integração.

## Fase 11 — documentação e regressão

- contrato;
- observabilidade;
- respostas;
- guardrails;
- critérios de aceite.

> [!IMPORTANT]
> Alterações do RAG e do grafo devem chegar juntas a um estado integrável. Não remover a infraestrutura Tool antiga do caminho A0 antes de o novo caminho determinístico estar funcional.

---

# 52. Testes obrigatórios — Scope Gate

## 52.1 Fora de escopo

```text
ScopePolicy → OUT_OF_SCOPE
RAG → não chamado
LLM → não chamado
reply → OUT_OF_SCOPE_REPLY
HTTP → 200
```

## 52.2 Dentro do escopo

```text
ScopePolicy → IN_SCOPE
RAG → chamado
```

## 52.3 Indeterminado

```text
ScopePolicy → UNDETERMINED
RAG → chamado
```

## 52.4 Determinismo

A mesma entrada + mesma versão da política deve produzir o mesmo `ScopeResult`.

## 52.5 Política versionada

Testes devem tornar explícito quando uma mudança de regra altera casos anteriormente classificados.

---

# 53. Testes obrigatórios — RAG

- endpoint `/gateway/core`;
- action;
- payload;
- `index_id`;
- headers;
- ausência de histórico;
- `query_type`;
- `total_context`;
- `SUCCESS`;
- `NO_CONTEXT`;
- `INFRA_ERROR`;
- timeout;
- erro HTTP;
- configuração ausente;
- span `RAG.gateway_core`;
- parsing explícito baseado no payload real.

---

# 54. Testes obrigatórios — grafo

- guardrails precedem grafo;
- Scope Gate precede RAG;
- RAG precede LLM;
- `OUT_OF_SCOPE` não chama RAG;
- `OUT_OF_SCOPE` não chama LLM;
- `UNDETERMINED` chama RAG;
- `NO_CONTEXT` não chama LLM;
- `INFRA_ERROR` não chama LLM;
- `SUCCESS` chama LLM uma vez;
- chunks chegam ao LLM;
- Tool Calling não participa do fluxo;
- `tool_correctness` não executa;
- `context_precision` executa quando há chunks;
- baixa precisão não altera roteamento nesta versão.

---

# 55. Testes obrigatórios — respostas externas

Validar separadamente:

```text
OUT_OF_SCOPE_REPLY
RAG_NO_CONTEXT_REPLY
RAG_UNAVAILABLE_REPLY
```

Para cada uma:

- `HTTP 200`;
- `ChatResponse` válido;
- `tool_calls_made = 0`;
- passa pelos guardrails de saída.

---

# 56. Testes obrigatórios — App e compatibilidade

Atualizar:

```text
test_chat_counts_tool_calls
```

Novo esperado:

```text
tool_calls_made == 0
```

Adicionar integração cobrindo:

- resposta LLM;
- fora de escopo;
- RAG vazio;
- indisponibilidade RAG;
- middleware de saída.

---

# 57. Testes obrigatórios — configuração

## RAG

- `index_id`;
- `agent_id` legado;
- precedência.

## Scope

Testar:

- política carregada;
- versão;
- regras da instância;
- comportamento de `UNDETERMINED`.

A forma concreta depende do mecanismo escolhido para representar a política.

---

# 58. Regressão dos guardrails

Garantir:

- `input_too_long`;
- prompt injection;
- PII de entrada;
- Genera Safe quando habilitado;
- blocklist de saída;
- PII de saída.

Fast-exits funcionais não podem escapar do middleware.

---

# 59. Observabilidade mínima de uma execução

Deve ser possível responder:

1. a entrada passou pelos guardrails?
2. qual foi o `scope_result`?
3. qual versão da política foi usada?
4. o RAG foi chamado?
5. quanto demorou?
6. quantos chunks vieram?
7. qual foi o `rag_result`?
8. `context_precision` executou?
9. o LLM foi chamado?
10. os validators pós-LLM executaram?
11. qual caminho funcional produziu a resposta?
12. a saída passou pelos guardrails?

---

# 60. Métricas recomendadas

Sem criar SLO:

```text
scope.result
scope.out_of_scope.count
scope.undetermined.count

rag.requests
rag.duration
rag.chunks.count
rag.result

context_precision.score

llm.duration
request.duration
```

Evitar dimensões de alta cardinalidade e conteúdo sensível.

---

# 61. Segurança e privacidade de telemetria

Não registrar inadvertidamente:

- `RAG_CLIENT_ID`;
- credenciais;
- headers sensíveis;
- chunks completos;
- PII;
- mensagens completas como atributo de alta cardinalidade;
- detalhes técnicos internos em respostas externas.

---

# 62. Taxonomia da instância de educação financeira

A arquitetura determina que deve existir uma política de escopo.

Ela **não determina quais conceitos específicos pertencem ou não a educação financeira**.

Essa definição deve vir do domínio/negócio e ser transformada em regras versionadas.

A implementação deve incluir testes do tipo:

```text
casos claramente dentro
casos claramente fora
casos fronteiriços → UNDETERMINED
```

Não inventar a taxonomia neste documento.

---

# 63. Público final e linguagem

Na instância atual:

```text
público final = Clientes do App
```

Isso orienta:

- clareza;
- vocabulário;
- tom;
- formato das mensagens;
- fallback.

Não muda:

- a topologia;
- a responsabilidade do Orquestrador;
- a exigência de RAG;
- a proteção de escopo.

---

# 64. Contratos de erro internos versus externos

## Internamente

Distinguir:

```text
scope_result
rag_result
```

## Externamente

Distinguir semanticamente:

```text
fora de escopo
ausência de documentação
indisponibilidade
```

Sem expor causa técnica detalhada.

---

# 65. Decisões rejeitadas

## Gate somente após RAG

Rejeitado como mecanismo principal de escopo porque:

- desperdiça recuperação para entradas claramente fora;
- não satisfaz a decisão de bloqueio determinístico anterior à recuperação.

`context_precision` permanece depois do RAG, mas não é Scope Gate.

## Gate exclusivamente no Orquestrador

Rejeitado para esta versão porque:

- criaria dependência contratual;
- removeria defesa local;
- transferiria a fronteira funcional para outro sistema.

O Orquestrador pode continuar roteando, mas o A0 protege seu próprio domínio.

## Gate binário obrigatório sem `UNDETERMINED`

Rejeitado porque:

- alguns domínios são difíceis;
- aumentaria falsos bloqueios;
- o template precisa funcionar em fronteiras semânticas diferentes.

## LLM-as-a-Judge para bloqueio determinístico

Rejeitado para a fronteira de escopo.

## RAG como Tool

Rejeitado no A0.

## `tool_calls_made = 1` por causa do RAG

Rejeitado.

## Uma mensagem para todos os casos

Rejeitado.

## Misturar `OUT_OF_SCOPE` com `NO_CONTEXT`

Rejeitado.

## Misturar `NO_CONTEXT` com `INFRA_ERROR`

Rejeitado externamente nesta versão.

## Inventar SLOs

Rejeitado.

## Implementar memória agora

Fora de escopo.

## Apagar `tool_correctness` do template

Rejeitado.

## Parsing heurístico de chunks

Rejeitado.

---

# 66. Trade-offs aceitos

## Scope Gate local

Benefícios:

- fast-exit;
- evita RAG desnecessário;
- evita LLM desnecessário;
- protege o domínio localmente.

Custos:

- exige política por agente;
- exige testes;
- pode gerar falsos positivos/negativos.

Mitigação:

```text
UNDETERMINED
```

## Três respostas externas

Benefícios:

- semântica clara;
- melhor experiência;
- melhor diagnóstico.

Custos:

- mais constantes/configuração;
- mais testes.

## RAG determinístico

Benefícios:

- custo menor;
- latência menor;
- menos risco de alucinação;
- caminho previsível.

Custos:

- tracing HTTP explícito;
- validators ligados à Tool precisam ser reposicionados.

---

# 67. Pendências da instância atual

## Resolvidas

- `idx-mf-edu-fin`;
- `RAG_CLIENT_ID`;
- UOR;
- user_id;
- decisão de desativar Genera Safe;
- decisão sobre `tool_description`;
- público final;
- comportamento de fora de escopo;
- política de SLO;
- arquitetura do Scope Gate;
- três motivos externos de não resposta.

## Ainda dependem de evidência/definição específica

### Parsing

Precisa do JSON real de `retrieved_contexts`.

### Prompt

Precisa de validação negocial final.

### ScopePolicy de educação financeira

A arquitetura está fechada, mas as regras/taxonomia concretas da instância precisam ser definidas, versionadas e testadas.

Esses itens não exigem remodelar o template.

---

# 68. Critérios de aceite arquitetural

A V2 estará corretamente implementada quando:

1. Guardrails continuarem antes do grafo funcional.
2. `scope_gate_node` executar antes do RAG.
3. `ScopePolicy` for específica/configurável por agente.
4. `ScopeResult` possuir `IN_SCOPE`, `OUT_OF_SCOPE` e `UNDETERMINED`.
5. `OUT_OF_SCOPE` encerrar sem RAG.
6. `OUT_OF_SCOPE` encerrar sem LLM.
7. `UNDETERMINED` seguir para RAG.
8. `IN_SCOPE` seguir para RAG.
9. RAG executar antes do LLM.
10. `/gateway/core` for utilizado.
11. `recuperar-contexto-indice` for utilizado.
12. `index_id` for o identificador principal.
13. `agent_id` legado continuar aceito como fallback.
14. `AgentState` declarar `scope_result`.
15. `AgentState` declarar `rag_context`.
16. `AgentState` declarar `rag_result`.
17. `NO_CONTEXT` não chamar LLM.
18. `INFRA_ERROR` não chamar LLM.
19. `SUCCESS` chamar LLM com chunks.
20. `context_precision` continuar observacional.
21. baixa precisão não alterar silenciosamente o fluxo.
22. `tool_correctness` não executar no A0.
23. Tool Calling não participar do RAG.
24. HTTP do Genera possuir span explícito.
25. Scope Gate possuir observabilidade suficiente.
26. validators pós-LLM continuarem no caminho de geração.
27. fast-exits passarem pelo middleware de saída.
28. `OUT_OF_SCOPE`, `NO_CONTEXT` e `INFRA_ERROR` terem mensagens distintas.
29. os três fast-exits funcionais retornarem HTTP 200.
30. `tool_calls_made` permanecer no schema com valor `0`.
31. parsing definitivo utilizar schema real.
32. nenhum SLO quantitativo ser inventado.
33. timeouts técnicos não serem documentados como SLO.
34. memória continuar fora do escopo atual.
35. o template permanecer genérico e sem taxonomia fixa de educação financeira.

---

# 69. Arquitetura final completa

```mermaid
flowchart TD
    A["Orquestrador<br/>POST /chat"] --> B["GuardrailsMiddleware<br/>Entrada"]

    B --> S["scope_gate_node<br/>ScopePolicy"]

    S --> SR{"scope_result"}

    SR -- "OUT_OF_SCOPE" --> OOS["OUT_OF_SCOPE_REPLY"]

    SR -- "IN_SCOPE" --> R["retrieve_context_node"]
    SR -- "UNDETERMINED" --> R

    R --> BB["GeneraBB<br/>/gateway/core"]
    BB --> CP["context_precision<br/>observacional"]

    CP --> RR{"rag_result"}

    RR -- "SUCCESS" --> L["llm_node<br/>message + rag_context"]
    L --> V["toxicity / PII / non_advice"]

    RR -- "NO_CONTEXT" --> NC["RAG_NO_CONTEXT_REPLY"]
    RR -- "INFRA_ERROR" --> IE["RAG_UNAVAILABLE_REPLY"]

    OOS --> OUT["GuardrailsMiddleware<br/>Saída"]
    V --> OUT
    NC --> OUT
    IE --> OUT

    OUT --> C["ChatResponse<br/>HTTP 200 nos fast-exits<br/>tool_calls_made = 0"]
```

---

# 70. Regra final do template

A regra arquitetural definitiva do A0 Informacional é:

> **Toda requisição passa primeiro pelas proteções de segurança. Em seguida, uma política determinística e específica do agente pode rejeitar entradas claramente fora de escopo. Toda entrada não rejeitada consulta obrigatoriamente a fonte RAG antes de qualquer geração. O LLM só é acionado quando existe contexto recuperado. Fora de escopo, ausência documental e indisponibilidade técnica são estados distintos e produzem respostas externas distintas, todas preservando os guardrails de saída.**

---

# 71. Estado da decisão

A arquitetura do template está fechada na Versão 2.

A V2 incorpora:

- controle determinístico de escopo;
- capacidade de lidar com domínios difíceis através de `UNDETERMINED`;
- RAG sequencial obrigatório depois do escopo;
- separação completa entre segurança, escopo, evidência e geração;
- três respostas funcionais de não atendimento;
- política explícita de não inventar SLOs;
- todas as decisões técnicas consolidadas na V1.

Na instância atual, a implementação pode avançar.

Os itens ainda específicos de ambiente/domínio — parsing real, prompt final e regras concretas da política de educação financeira — são complementos de configuração/integração e **não exigem nova remodelagem arquitetural**.
