# Arquitetura A0 — fluxo detalhado, observabilidade e registro no Oracle

Este documento mantém o modelo visual da V1: etapas funcionais em caixas e
observabilidade ao lado. O fluxo existente foi confrontado com os arquivos desta
cópia; as caixas verdes de persistência representam uma **proposta ainda não
implementada**. Não foi executada integração com Oracle ou serviços corporativos.

**Estado observado no YAML:** Scope Gate habilitado; RAG, Genera Safe e MCP
desabilitados. Com essa configuração, requisições aceitas pelo escopo chegam ao
adapter RAG, que retorna indisponibilidade sem chamada externa. O caminho de
recuperação, judge e geração está implementado, mas depende da configuração do RAG.

**Decisões para a proposta:** guardar conteúdo original integral, inclusive
entradas bloqueadas; uma linha por chamada; recusar atendimento sem registro
confirmado. A versão do Oracle é desconhecida. `CLOB` com validação `IS JSON` é a
opção provisória para a coluna de detalhes, sujeita à confirmação da versão.

## 1. Fluxo principal

Setas contínuas representam processamento. Ligações sem seta e pontilhadas
relacionam a etapa à instrumentação existente; não são chamadas de negócio.
Persistência de conteúdo integral no Oracle não altera os guardrails da resposta
e não implica enviar esse conteúdo ao OpenTelemetry.

```mermaid
%%{init: {"theme":"base","flowchart":{"htmlLabels":true,"wrappingWidth":620,"nodeSpacing":35,"rankSpacing":45,"padding":22},"themeVariables":{"fontSize":"17px"}}}%%
flowchart TD
    classDef endpoint fill:#f3e5f5,stroke:#4a148c,stroke-width:2px,color:#000
    classDef guardrail fill:#ffebee,stroke:#b71c1c,stroke-width:2px,color:#000
    classDef langgraph fill:#e3f2fd,stroke:#0d47a1,stroke-width:2px,color:#000
    classDef external fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#000
    classDef obs fill:#e0f2f1,stroke:#00695c,stroke-width:2px,stroke-dasharray:5 5,color:#000
    classDef proposed fill:#e8f5e9,stroke:#2e7d32,stroke-width:3px,color:#000
    classDef failure fill:#fff3e0,stroke:#bf360c,stroke-width:2px,color:#000

    API["<b>POST /chat — entrada HTTP</b><br/><br/>message: texto obrigatório da pergunta atual<br/>session_id: texto opcional ou null<br/>Não recebe histórico conversacional<br/>session_id é apenas ecoado na resposta"]:::endpoint

    Register["<b>PROPOSTA · Oracle — registro inicial</b><br/><br/>Camada HTTP externa aos guardrails e ao grafo<br/>Gera interaction_id exclusivo desta chamada<br/>Preserva corpo recebido e mensagem original integral<br/>Extrai session_id quando válido; registra horário de início<br/><br/>INSERT em MF_EDU_FIN_INTERACAO + COMMIT<br/>ESTADO_REGISTRO = INICIADA<br/>Não mantém transação aberta durante RAG ou LLM"]:::proposed
    Registered{"COMMIT inicial<br/>confirmado?"}
    InitialFailure["<b>PROPOSTA · HTTP 503</b><br/><br/>Registro inicial não confirmado<br/>Não executa RAG, judge ou geração<br/>Não há garantia de registro desta tentativa no Oracle"]:::failure

    Middleware["<b>Guardrails de entrada — middleware</b><br/><br/>1. Tamanho: até 4.096 caracteres por padrão<br/>2. Regex de prompt injection e jailbreak<br/>3. Bloqueio de PII, habilitado por padrão:<br/>e-mail, telefone BR/internacional, SSN, cartão, CPF e CNPJ<br/>Regras específicas de CPF/CNPJ verificam dígitos<br/>4. Genera Safe opcional, desligado no YAML<br/>Quando habilitado com credencial, consulta política externa;<br/>falhas e timeouts permitem continuar<br/><br/>Rejeição: HTTP 400 com error, code e detail"]:::guardrail
    InputFailure["<b>Entrada recusada ou contrato inválido</b><br/><br/>HTTP 400: guardrail_violation e motivo<br/>HTTP 422: erro de validação do contrato<br/>Não entra no grafo<br/>Na proposta, finaliza o registro antes de devolver o erro"]:::failure
    Contract["<b>Contrato HTTP e preparação do estado</b><br/><br/>FastAPI/Pydantic valida JSON e tipos de ChatRequest<br/>Após validação, o handler incrementa total_requests<br/>Cria uma HumanMessage com a pergunta atual<br/>session_id não entra no AgentState<br/><br/>Invoca AgentGraph sem memória persistida"]:::endpoint
    MidObs["<b>Observabilidade do middleware</b><br/><br/>Span: guardrails.middleware.chat<br/>Métricas: guardrail.requests, guardrail.blocked,<br/>guardrail.redactions, guardrail.latency_ms<br/><br/>Atributos conforme o caminho:<br/>guardrail.blocked, guardrail.blocked_layer,<br/>guardrail.blocked_code, guardrail.output_redacted,<br/>guardrail.latency_ms<br/><br/>Bloqueio de PII de entrada não chama _record_block;<br/>não incrementa guardrail.blocked atualmente"]:::obs

    Scope["<b>scope_gate_node — decisão de domínio</b><br/><br/>KeywordScopePolicy configurada no YAML<br/>Normaliza caixa, acentos e pontuação<br/>Termo interno tem precedência sobre termo externo<br/>Sem correspondência: UNDETERMINED<br/>Não usa LLM para classificar<br/>Zera rag_context e rag_result antes da recuperação"]:::langgraph
    ScopeObs["<b>Observabilidade de escopo</b><br/><br/>Span: ScopePolicy.evaluate<br/>Atributos: scope.result, scope.policy_version"]:::obs
    CondScope{"scope_result"}
    OOS["<b>OUT_OF_SCOPE — resposta configurada</b><br/><br/>Usa cfg.responses.out_of_scope<br/>Não consulta RAG nem chama judge ou gerador<br/>Resposta funcional HTTP 200"]:::langgraph

    Retrieve["<b>retrieve_context_node — adapter RAG</b><br/><br/>Valida habilitação, parâmetros e credencial<br/><b>YAML atual: rag.enabled = false</b><br/>Configuração inválida retorna INFRA_ERROR<br/>sem consulta externa<br/><br/>Com configuração válida, chama o GeneraBB<br/>Não usa Tool Calling ou MCP"]:::langgraph
    Genera["<b>GeneraBB — POST /gateway/core</b><br/><br/>action: recuperar-contexto-indice<br/>input: pergunta atual; query_type: hybrid<br/>index_id configurado: idx-mf-edu-fin<br/>total_context: 5; timeout: 20 segundos<br/><br/>Lê data.retrieved_contexts e passage_text<br/>Aceita textos não vazios; estrutura inválida é erro<br/>Contrato e disponibilidade externos não validados"]:::external
    RAGObs["<b>Observabilidade RAG</b><br/><br/>Span: RAG.gateway_core<br/>Atributos: rag.result, rag.chunk_count,<br/>rag.duration_ms, rag.error quando houver erro<br/><br/>O span também cobre falha de configuração<br/>A chamada externa pode não ter ocorrido"]:::obs
    CondRAG{"rag_result"}
    NoCtx["<b>NO_CONTEXT — ausência documental</b><br/><br/>Estrutura válida, sem texto utilizável<br/>Usa cfg.responses.no_context<br/>Não chama judge nem gerador<br/>Resposta funcional HTTP 200"]:::langgraph
    ErrCtx["<b>INFRA_ERROR — indisponibilidade</b><br/><br/>Configuração, transporte, HTTP, timeout ou schema inválido<br/>Usa cfg.responses.unavailable<br/>Não chama judge nem gerador<br/>Resposta funcional HTTP 200"]:::langgraph

    Precision["<b>context_precision_node — LLM judge</b><br/><br/>Executa somente depois de rag_result = SUCCESS<br/>Avalia pergunta e até 500 caracteres por chunk<br/>Usa o provider configurado, temperature 0 e top_p 1<br/>Score de 0 a 1; limiar atual 0,3<br/><br/>Observacional: score baixo ou falha do judge<br/>não bloqueia geração nem reclassifica o RAG"]:::langgraph
    PrecisionObs["<b>Observabilidade do judge</b><br/><br/>Span: validate.context_precision<br/>Atributos: validator.name, validator.passed,<br/>validator.score, validator.action, validator.duration_ms<br/>Também emite as métricas comuns de validators"]:::obs
    LLM["<b>llm_call — geração</b><br/><br/>Exige SUCCESS e chunks não vazios<br/>Provider: gateway_outbound<br/>Modelo configurado: cambio-non-prod-gpt4o<br/>Envia instruções + DOCUMENTOS_JSON + pergunta<br/>Prompt orienta fundamentação nos documentos<br/><br/>Exige AIMessage sem tool_calls<br/>Retorno incompatível usa cfg.responses.unavailable<br/>Nenhuma ferramenta solicitada é executada"]:::langgraph
    LLMObs["<b>Observabilidade da geração</b><br/><br/>Span: LLM.generate<br/>Atributos: llm.result, llm.duration_ms<br/>Esses atributos não comprovam tokens ou custo"]:::obs
    PostVal["<b>Validators pós-LLM — quando há texto</b><br/><br/>toxicity: ameaças, assédio, ódio e autolesão<br/>non_advice: aconselhamento financeiro, jurídico e médico<br/>pii: dados pessoais e identificadores<br/><br/>Resultados são observacionais no A0<br/>Mesmo action = block não aplica bloqueio neste caminho<br/>Tool Correctness é usado somente no legado"]:::langgraph
    PostValObs["<b>Observabilidade dos validators</b><br/><br/>Spans: validate.toxicity, validate.non_advice, validate.pii<br/>Atributos: validator.name, validator.passed,<br/>validator.score, validator.action<br/><br/>Métricas: validator.invocations, validator.passed,<br/>validator.failed, validator.score, validator.latency_ms<br/>Duração síncrona é métrica;<br/>o span não recebe validator.duration_ms"]:::obs

    ResponseBody["<b>Montagem de ChatResponse</b><br/><br/>reply: geração ou resposta funcional configurada<br/>session_id: valor recebido ou null<br/>tool_calls_made: sempre 0"]:::endpoint
    OutGuard["<b>Guardrails de saída — HTTP 200 em JSON</b><br/><br/>1. Blocklist: padrões de exposição de system prompt,<br/>atuação irrestrita ou afirmação de ignorar diretrizes<br/>Se corresponder, substitui reply por recusa fixa<br/><br/>2. Se não houver correspondência na blocklist:<br/>mascara PII, quando habilitado, com marcadores<br/>EMAIL, PHONE, SSN, CARD, CPF e CNPJ<br/>Preserva os demais campos da resposta"]:::guardrail
    GraphError["<b>Erro de execução — HTTP 500</b><br/><br/>Handler trata exceções da invocação do grafo<br/>e prepara detalhe genérico de erro interno<br/>Não passa pelo tratamento de saída de HTTP 200"]:::failure
    OutObs["<b>Observabilidade da saída</b><br/><br/>Usa o mesmo span guardrails.middleware.chat<br/>Blocklist: guardrail.blocked e atributos do bloqueio<br/>Mascaramento: guardrail.redactions<br/>e atributo guardrail.output_redacted<br/>Não cria outro span de middleware"]:::obs

    Finalize["<b>PROPOSTA · Oracle — finalização</b><br/><br/>Mesma interaction_id, incluindo respostas 400, 422 e 500<br/>Preserva conteúdo original do modelo quando produzido<br/>Guarda corpo HTTP final após guardrails de saída<br/>Consolida avaliações e erros em DETALHES_JSON<br/><br/>UPDATE + COMMIT; ESTADO_REGISTRO = FINALIZADA<br/>RESULTADO distingue resposta, bloqueio e falha<br/>Exige confirmação antes de liberar a resposta preparada"]:::proposed
    Finalized{"COMMIT final<br/>confirmado?"}
    FinalFailure["<b>PROPOSTA · HTTP 503</b><br/><br/>Finalização não confirmada<br/>Não libera a resposta funcional produzida<br/>Registro inicial confirmado, mas o resultado final<br/>pode ficar sem persistência confirmada"]:::failure
    Resp["<b>Resposta HTTP registrada — envio ao cliente</b><br/><br/>200: reply, session_id, tool_calls_made = 0<br/>400, 422 ou 500: corpo de erro correspondente<br/><br/>Registro comprova a resposta preparada pelo servidor<br/>Não comprova recebimento pelo cliente"]:::endpoint

    API --> Register --> Registered
    Registered -->|Não| InitialFailure
    Registered -->|Sim| Middleware
    Middleware -->|Bloqueio| InputFailure
    Middleware -->|Sem bloqueio| Contract
    Middleware -.- MidObs
    Contract -->|Inválido| InputFailure
    Contract -->|Válido| Scope
    Contract -->|Exceção na invocação do grafo| GraphError
    Scope --> CondScope
    Scope -.- ScopeObs
    CondScope -->|OUT_OF_SCOPE| OOS
    CondScope -->|IN_SCOPE ou UNDETERMINED| Retrieve
    Retrieve -->|Configuração válida| Genera
    Retrieve -->|Configuração inválida| CondRAG
    Genera --> CondRAG
    Retrieve -.- RAGObs
    CondRAG -->|NO_CONTEXT| NoCtx
    CondRAG -->|INFRA_ERROR| ErrCtx
    CondRAG -->|SUCCESS| Precision
    Precision -.- PrecisionObs
    Precision --> LLM
    LLM -.- LLMObs
    LLM -->|AIMessage compatível| PostVal
    LLM -->|Retorno incompatível| ResponseBody
    PostVal -.- PostValObs
    OOS --> ResponseBody
    NoCtx --> ResponseBody
    ErrCtx --> ResponseBody
    PostVal --> ResponseBody
    ResponseBody --> OutGuard
    OutGuard -.- OutObs
    OutGuard --> Finalize
    InputFailure --> Finalize
    GraphError --> Finalize
    Finalize --> Finalized
    Finalized -->|Não| FinalFailure
    Finalized -->|Sim| Resp
```

### Limites e comportamento da persistência proposta

- O registro envolve o ciclo HTTP completo de `/chat`, inclusive a preparação de
  erros. Na implementação futura, sua posição deve capturar também respostas
  produzidas pelo tratamento de exceções; não basta colocá-lo dentro do grafo.
- A coleta de resultados deve usar contexto exclusivo da requisição. Os
  validators atuais retornam avaliações que o A0 não consolida em um registro;
  essa coleta ainda precisa ser implementada, sem usar globais entre usuários.
- O primeiro commit registra a entrada; o segundo registra o desfecho. Queda do
  processo entre ambos pode deixar `INICIADA`. Esse estado não prova erro nem
  sucesso, apenas ausência de finalização registrada.
- Falha de confirmação de commit pode ter resultado incerto: o banco pode ter
  confirmado antes da conexão cair. Eventuais tentativas de persistência devem
  usar a mesma `interaction_id`, sem duplicar a linha ou repetir a geração.
- Sem outro armazenamento durável, as tentativas recusadas enquanto o Oracle
  está indisponível e o conteúdo produzido antes de uma falha de finalização
  podem não ser recuperáveis. A decisão adotada é **não atender sem registro**;
  não é uma garantia de conservar toda tentativa recebida durante uma queda.
- A resposta de contingência HTTP 503 não tem persistência garantida se o Oracle
  estiver indisponível. `HTTP_STATUS` representa a resposta preparada e registrada,
  não uma confirmação de entrega ao cliente.
- Conteúdo original integral permanece no registro de auditoria; os guardrails
  continuam tratando a resposta entregue. Não copiar headers de autenticação,
  App Keys ou tokens operacionais para os detalhes. O corpo original pode conter
  dados sensíveis enviados pelo próprio usuário, conforme a decisão de preservá-lo.
- A nova dependência pode impedir atendimento quando o banco falhar. Isso é uma
  alteração de disponibilidade intencional da proposta, ainda inexistente no código.

## 2. Tabela e coluna JSON — proposta

Uma linha representa uma chamada HTTP recebida, inclusive chamadas repetidas com
o mesmo `session_id`. `interaction_id` identifica a chamada; `session_id` permite
agrupamento, mas não implica memória conversacional. Não será gerada uma sessão
fictícia quando o campo não vier na requisição.

```mermaid
%%{init: {"theme":"base","flowchart":{"htmlLabels":true,"wrappingWidth":680,"padding":26,"rankSpacing":45},"themeVariables":{"fontSize":"17px"}}}%%
flowchart TD
    classDef proposed fill:#e8f5e9,stroke:#2e7d32,stroke-width:3px,color:#000
    classDef detail fill:#e3f2fd,stroke:#0d47a1,stroke-width:2px,color:#000

    Table["<b>PROPOSTA · MF_EDU_FIN_INTERACAO</b><br/><br/><b>Identificação</b><br/>INTERACTION_ID — VARCHAR2 de 36 caracteres, PK, UUID<br/>SESSION_ID — VARCHAR2 opcional, tamanho a definir<br/>TRACE_ID — VARCHAR2 de 32 caracteres, opcional<br/><br/><b>Acompanhamento</b><br/>INICIADA_EM — TIMESTAMP WITH TIME ZONE, obrigatório<br/>FINALIZADA_EM — TIMESTAMP WITH TIME ZONE, opcional<br/>ESTADO_REGISTRO — VARCHAR2 de 20: INICIADA ou FINALIZADA<br/>RESULTADO — VARCHAR2 de 40, classificação do desfecho<br/>HTTP_STATUS — NUMBER de 3 dígitos, quando conhecido<br/>DURACAO_MS — NUMBER, até a preparação da finalização<br/><br/><b>Conteúdo original e resposta final</b><br/>REQUISICAO_ORIGINAL — BLOB, corpo recebido sem alteração<br/>MENSAGEM_ORIGINAL — CLOB, message quando extraível como texto<br/>RESPOSTA_MODELO_ORIGINAL — CLOB, conteúdo antes dos guardrails<br/>RESPOSTA_HTTP_FINAL — CLOB, corpo JSON final, inclusive erros<br/><br/><b>Detalhes extensíveis</b><br/>DETALHES_JSON — provisoriamente CLOB com CHECK IS JSON"]:::proposed

    Json["<b>DETALHES_JSON — estrutura versionada</b><br/><br/>schema_version: versão do formato<br/>conteudo: modo integral; formato da resposta original do modelo<br/>requisicao: método, rota, contrato válido e correlação externa<br/>configuracao: versão da aplicação, ambiente, política e prompt<br/>guardrails_entrada: regras, resultados e motivo do bloqueio<br/>escopo: executado, classificação e versão da política<br/>rag: execução, chamada externa, resultado, índice, chunks e duração<br/>judge: execução, score, limiar, aprovação, justificativa e duração<br/>llm: execução, provider, modelo, uso informado e duração<br/>validators: lista com nome, score, aprovação e ação indicada<br/>guardrails_saida: blocklist, substituição e mascaramento de PII<br/>erro: etapa e categoria técnica, quando houver<br/>extras: extensões futuras com nomes definidos"]:::detail

    Rules["<b>Regras de preenchimento</b><br/><br/>Mensagem e resposta ficam nas colunas CLOB<br/>Não duplicar esses textos no JSON<br/>Conteúdo do modelo em blocos: serializar integralmente<br/>e indicar o formato, sem resumir o texto<br/><br/>Etapa não percorrida: executado = false<br/>Medição desconhecida: null, nunca zero inventado<br/>Sem geração: RESPOSTA_MODELO_ORIGINAL = null<br/>Contrato inválido pode ter MENSAGEM_ORIGINAL = null<br/>FINALIZADA também pode representar bloqueio ou erro"]:::detail

    Table --> Json --> Rules
```

O `BLOB` preserva o corpo HTTP recebido pela aplicação, inclusive bytes que não
formem JSON ou texto válido; não é uma captura de rede nem inclui os headers.
Os CLOBs de mensagem e resposta facilitam consultas. Para respostas do modelo
em blocos, a coluna original preserva a lista serializada, identificada no JSON.

O contrato atual não limita o tamanho de `session_id`. Seu tamanho físico deve
ser decidido antes do DDL, sem introduzir truncamento silencioso ou um novo limite
de API por acidente. Campos só conhecidos no final ficam nulos no insert inicial.

### Classificação do resultado

| RESULTADO | Significado |
|---|---|
| `RESPONDIDA` | Resposta gerada pelo caminho normal, sem substituição por blocklist. |
| `FORA_ESCOPO` | Resposta funcional de fora de escopo. |
| `SEM_CONTEXTO` | Recuperação válida sem documentação utilizável. |
| `INDISPONIVEL` | Configuração/falha do RAG ou resposta incompatível do modelo. |
| `BLOQUEADA_ENTRADA` | Guardrail interrompeu o processamento. |
| `SUBSTITUIDA_SAIDA` | Blocklist substituiu o texto de saída. |
| `REQUISICAO_INVALIDA` | Contrato HTTP inválido. |
| `ERRO_INTERNO` | Erro de execução convertido em resposta de erro. |

Quando a blocklist substituir uma resposta funcional, `SUBSTITUIDA_SAIDA` terá
precedência na coluna; a classificação anterior ficará em
`guardrails_saida.resultado_anterior`. Mascaramento de PII será registrado no JSON
sem apagar o resultado funcional. Esses critérios são novos contratos da proposta.

### Exemplo de JSON: RAG desligado na configuração

Exemplo ilustrativo, não extraído de uma execução. Os `null` indicam valores a
preencher quando houver evidência; os tempos e versões não foram inventados.

```json
{
  "schema_version": 1,
  "conteudo": {
    "modo": "integral",
    "mascaramento_na_persistencia": false,
    "formato_resposta_modelo": null
  },
  "requisicao": {
    "metodo": "POST",
    "rota": "/chat",
    "contrato_valido": true,
    "correlacao_externa": null
  },
  "configuracao": {
    "versao_aplicacao": null,
    "ambiente": null,
    "versao_prompt": null,
    "scope_policy_version": "mf-edu-fin-mvp-v1"
  },
  "guardrails_entrada": {
    "regras": [
      { "nome": "tamanho", "executado": true, "aprovado": true },
      { "nome": "prompt_injection", "executado": true, "aprovado": true },
      { "nome": "pii", "executado": true, "aprovado": true },
      { "nome": "genera_safe", "executado": false, "motivo": "desabilitado" }
    ],
    "bloqueado": false
  },
  "escopo": {
    "executado": true,
    "resultado": "in_scope",
    "policy_version": "mf-edu-fin-mvp-v1"
  },
  "rag": {
    "executado": true,
    "chamada_externa_realizada": false,
    "resultado": "infra_error",
    "erro": "configuration",
    "index_id": "idx-mf-edu-fin",
    "chunk_count": 0,
    "chunks": [],
    "duracao_ms": null
  },
  "judge": { "executado": false, "motivo": "rag_sem_success" },
  "llm": { "executado": false, "motivo": "rag_sem_success" },
  "validators": [],
  "guardrails_saida": {
    "executado": true,
    "blocklist_correspondeu": false,
    "resposta_substituida": false,
    "pii_mascarada": false,
    "resultado_anterior": null
  },
  "erro": { "etapa": "rag", "categoria": "configuration" },
  "extras": {}
}
```

Com RAG bem-sucedido, `rag.chunks` conterá os textos integrais utilizados. O
adapter atual conserva `passage_text`, sem IDs documentais: não preencher IDs,
referências ou scores de recuperação que ele não fornece. O judge avalia somente
os primeiros 500 caracteres de cada chunk; a geração recebe os chunks completos.
Tokens só serão preenchidos quando informados pelo provider, sem custo estimado
ou medição inventada. A versão de prompt também exige uma identificação futura;
ela não existe hoje como campo dedicado do YAML.

Índices iniciais sugeridos: chave primária em `INTERACTION_ID`, índice temporal em
`INICIADA_EM` e índice composto em `(SESSION_ID, INICIADA_EM)`. Índices em JSON e
outros campos dependerão das consultas efetivas. Retenção, permissões de leitura
e capacidade para os textos integrais continuam por definir; não há prazo ou
dimensionamento corporativo comprovado nesta cópia.

Para Oracle 19c, a documentação admite JSON em `CLOB`, com constraint `IS JSON`.
Oracle 21c dispõe de tipo JSON nativo quando o parâmetro `compatible` permite.
Essas referências sustentam as alternativas, não identificam a versão disponível
para este agente: [Oracle 19c — armazenamento JSON](https://docs.oracle.com/en/database/oracle/oracle-database/19/adjsn/overview-of-storage-and-management-of-JSON-data.html)
e [Oracle 21c — JSON nativo](https://docs.oracle.com/en/database/oracle/oracle-database/21/adjsn/json-in-oracle-database.html).

## 3. Rotas operacionais e destino da telemetria

Essas rotas não são interações conversacionais e ficam fora da tabela proposta.
`/metrics` não é um guardrail e não expõe os instrumentos OTel do fluxo principal.

```mermaid
%%{init: {"theme":"base","flowchart":{"htmlLabels":true,"wrappingWidth":580,"padding":24,"rankSpacing":40},"themeVariables":{"fontSize":"17px"}}}%%
flowchart TD
    classDef endpoint fill:#f3e5f5,stroke:#4a148c,stroke-width:2px,color:#000
    classDef obs fill:#e0f2f1,stroke:#00695c,stroke-width:2px,color:#000
    API["<b>Rotas operacionais existentes</b><br/><br/>Não percorrem o grafo de conversa<br/>Não passam pelos guardrails específicos de POST /chat"]:::endpoint
    Metrics["<b>GET /metrics — JSON operacional</b><br/><br/>uptime_seconds: tempo do processo<br/>total_requests: entradas no handler de /chat<br/>agent_id e agent_name: identidade configurada<br/><br/>Não inclui bloqueios anteriores ao handler<br/>Contagem em memória, local ao processo<br/>Não é formato Prometheus nem consulta ao Oracle"]:::obs
    Live["<b>GET /health/live</b><br/><br/>HTTP 200 com status alive<br/>Indica que a aplicação respondeu<br/>Não consulta dependências externas"]:::obs
    Ready["<b>GET /health/ready</b><br/><br/>Verifica configuração operacional e grafo compilado<br/>HTTP 200 ou 503 conforme requisitos locais<br/>Com RAG desligado, configuração não está pronta<br/>Hoje não testa Oracle, RAG, LLM ou Collector"]:::obs
    OTel["<b>OpenTelemetry — exportação independente</b><br/><br/>Instrumentos do fluxo usam providers do runtime<br/>Docker prevê opentelemetry-instrument no início<br/>OTLP para Collector conforme ambiente<br/>Exporter Azure adicional de traces é opcional<br/><br/>Chegada ao backend: NÃO VALIDADO CORPORATIVAMENTE<br/>OTel não substitui a persistência obrigatória no Oracle"]:::obs
    API --> Metrics
    API --> Live
    API --> Ready
```

## 4. Base da refatoração e limites da evidência

| Arquivo observado | Evidência utilizada |
|---|---|
| [app.py](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/app.py) | Contrato HTTP, eco de session_id, tratamento de exceções do grafo e rotas operacionais. |
| [graph.py](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/graph.py) | Ordem escopo → RAG → decisão → judge → geração; validators observacionais e legado separado. |
| [guardrails_middleware.py](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/guardrails_middleware.py) | Bloqueios de entrada, tratamento de saída e instrumentos do middleware. |
| [filter_patterns.py](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/filter_patterns.py) | Padrões locais de injection, PII e blocklist. |
| [rag_tool.py](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/rag/rag_tool.py) | Configuração antes da chamada, parsing de passage_text e classificação do RAG. |
| [validators](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/validators/__init__.py) | Nomes reais das métricas e diferença entre atributos síncronos e assíncronos. |
| [context_precision.py](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/validators/context_precision.py) | Judge observacional, limiar e limite de conteúdo por chunk. |
| [agent_config.yaml](iaa-agent-mf-edu-fin-main/agent_config.yaml) | RAG e Genera Safe desligados, política de escopo, índice e modelo configurados. |
| [tracing.py](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/tracing.py) | Exporter Azure opcional de traces, dependente do provider e da configuração. |

A refatoração corrige o modelo anterior, que posicionava o judge antes da decisão
do RAG, usava nomes de variáveis/scopes como se fossem nomes de métricas e omitia
`tool_calls_made` na resposta. Preserva o estilo visual, a topologia do A0 e a
distinção entre bloqueios efetivos e avaliações observacionais.

A inclusão de persistência atende às decisões do usuário e está identificada
como proposta. Uma alternativa mais conservadora seria apenas anexar um bloco
Oracle, mas isso não explicitaria os caminhos de erro e os dois commits. Nenhum
arquivo da aplicação, dependência, configuração de deploy ou tabela foi alterado.

**Limite:** leitura e conferência locais não comprovam implantação, execução do
build, exportação de telemetria ou integração externa. Oracle, GeneraBB, Gateway
Outbound e destinos OTel permanecem **NÃO VALIDADOS CORPORATIVAMENTE**.
