# Entrega A0 Informacional V2 — validação local

Data: 2026-09-29, referência do workspace. Cópia: `C:\Users\manue\Docs\MF_EDU_FIN\v1_hml`.
Aplicação: `iaa-agent-mf-edu-fin-main/`. **Entrega local implementada: 215 testes aprovados
em Python 3.11.9; compilação sintática concluída. Aceite corporativo e prontidão para
produção: NÃO VALIDADOS CORPORATIVAMENTE.**

## 1. Fontes e limite da evidência

O plano único fornecido pelo usuário orienta esta execução. A SRS
`especificacao_requisitos_a0_versao2.md`, a arquitetura
`plano_arquitetura_a0_versao2.md`, os nove prompts e a memória `etapa_01.md` foram
preservados. A memória refere-se à `v0`; não comprova esta `v1_hml`.
O guia `GUIA_RAG_GENERA_INDICE_DIRETO.md` sustenta a implementação documental do
parser, não sua conformidade com um serviço real desta instância.

Não foi utilizado Git nem foram identificados branch/commit ativos. Não houve
consulta a sistemas corporativos, leitura de credenciais fora do projeto,
build da imagem corporativa, execução de workflow, release, deploy ou sondagem
de rede corporativa. A instalação pública de bibliotecas foi a única atividade
de rede necessária. Nenhum serviço substituto, cluster ou réplica foi criado.

Testes utilizam ASGITransport, MockTransport, modelos controlados e exportador
OTel em memória. Comprovam o comportamento desta cópia sob esses controles;
não comprovam disponibilidade, autenticação, contrato vigente, respostas factuais
de um modelo real ou tratamento de dados pelos serviços externos.

## 2. Baseline efetivamente observado

O estado encontrado divergia do diagnóstico histórico do plano: já havia
`RAGResult`, `RAGResponse`, canais adicionais em `AgentState`, nós determinísticos,
interface assíncrona parcial do judge e `create_legacy`. Contudo:

- `create` ainda tentava MCP e construía Tool RAG; nós liam o singleton global.
- Context precision executava depois da geração e seu template real ainda tinha
  chaves JSON não escapadas; teste substituía o template.
- `SUCCESS` vazio seguia para ausência documental; exceptions podiam levar texto
  sensível a resultados, logs e spans; readiness só verificava configuração carregada/grafo.
- O conftest substituía o pacote Azure por MagicMock global e não bloqueava rede.
- Havia Python 3.13.5 com parte das dependências e Python 3.11.9 sem dependências.
  `pytest`, embora ausente no diagnóstico histórico, estava disponível na `.venv` 3.13.
- `Dockerfile` declara 3.11.6; `aic.json`, 3.11; `setup.py`, `>=3.11`.
  A declaração histórica de 3.8 na SRS não descreve esses arquivos atuais.
- Helm local declara `/health/live` e `/health/ready`, porta 8080 e tag `0.1.0`.
  Workflows referenciam componentes compartilhados: só a referência foi observada.

Antes das edições foram preservados os arquivos de fonte/testes/configuração em
`evidencias_a0_v2/baseline.zip`, com hashes em `baseline_sha256.json`.
Os originais de `.gitignore` e `.dockerignore` foram acrescentados antes de editá-los.

## 3. Comportamento entregue

```text
guardrails de entrada → scope_gate_node
  OUT_OF_SCOPE → mensagem out_of_scope
  IN_SCOPE / UNDETERMINED → retrieve_context_node
    NO_CONTEXT → mensagem no_context
    INFRA_ERROR / resultado inconsistente → mensagem unavailable
    SUCCESS com chunks → context_precision_node → llm_call → validators
todos os resultados funcionais → guardrails de saída → HTTP 200
```

`AgentFactory.create` é exclusivamente A0; `create_legacy` é a entrada explícita
para MCP/Tools. Não há fallback automático. O cliente MCP é importado somente
pelo caminho legado; `ValidatingToolNode`, wrapper Tool RAG, tool_correctness,
Genera Safe e suas configurações continuam disponíveis.

Cada grafo captura uma cópia da configuração. A política MVP permanece keyword,
normalizada, versionada e com precedência de termo interno em mensagens mistas;
ausência de correspondência permanece UNDETERMINED. Não há taxonomia de educação
financeira fixa no código do template. Prompt, corpus, taxonomia e mensagens MVP
foram reutilizados sem alteração de conteúdo.

O RAG usa `/gateway/core`, `recuperar-contexto-indice`, busca híbrida,
`index_id` prioritário e fallback `agent_id`, identificação e timeout configuráveis.
Não envia histórico nem schema de Tool. Apenas `data.retrieved_contexts[*].passage_text`
é aceito: lista vazia/textos brancos são NO_CONTEXT; qualquer item inválido invalida
a resposta inteira como INFRA_ERROR. Desligamento, falta de configuração, timeout,
falha HTTP/conexão, JSON/estrutura inválidos também são INFRA_ERROR.

Geração recebe instruções, documentos serializados em bloco delimitado separado
e a pergunta atual. Há uma chamada geradora por sucesso, com retries do provider
desativados, e um judge separado, assíncrono, anterior à geração. Score baixo ou
falha do judge não bloqueiam. SUCCESS vazio/inconsistente não chama modelos.
Uma resposta inesperada do modelo contendo tool_calls é convertida em indisponibilidade,
sem executar ferramentas. Não foram adicionados memória, cache de respostas,
streaming, retry, metas de SLO ou infraestrutura paralela. Reuso de clientes/modelos
é gerenciamento de recursos, não armazenamento de conversa ou de respostas.

Toxicity, non_advice e PII mantêm seus cálculos e semântica observacional pós-LLM;
enforcement de saída continua no middleware. Os três fast-exits atravessam esse
middleware, inclusive redação de PII. Bloqueio de entrada permanece 400, estruturas
inválidas testadas retornam 422 e exceptions não tratadas retornam 500 genérico.
`session_id` é ecoado; `tool_calls_made` permanece no schema e vale zero.

Liveness é local. Readiness verifica grafo e campos operacionais localmente, com
diagnósticos por nomes de campos, sem valores sensíveis ou chamadas remotas.
Não verifica validade de credenciais/certificados, conectividade nem contrato externo.
`/metrics` preserva uptime_seconds, total_requests, agent_id e agent_name.

A configuração entregue conserva `rag.enabled: false`, UOR/user_id vazios e
MCP/Genera Safe desligados. Assim, perguntas internas/indeterminadas recebem
unavailable; readiness retorna 503. Isso é comportamento intencional da cópia
incompleta, não indicação de que o ambiente corporativo está indisponível.

## 4. Justificativas de todas as alterações

Paths abaixo são relativos à aplicação. Cada grupo inclui seus comentários em
português: explicam a decisão e evitam documentar um fluxo anterior como ativo.

| Grupo/arquivos | Necessidade agora | Compatibilidade preservada ou afetada | Alternativa mais conservadora |
|---|---|---|---|
| `graph.py` | Tornar recuperação determinística, eliminar MCP/Tools do A0, isolar instâncias, mover judge antes da geração e controlar estados inconsistentes. | HTTP/state preservados; construção LLM passa a ser tardia; legado fica explícito. | Somente desligar MCP no YAML não impediria sua execução por outra configuração, nem corrigiria ordem/isolamento. |
| `config.py`, `scope_policy.py` | Diagnosticar configuração insuficiente e rejeitar política/termos, prompt ou mensagens inválidos. | Loader legado continua disponível; A0 exige sua configuração própria; readiness incompleta passa a 503. | Verificar só presença do objeto reproduziria falso ready; não se inventaram exigências de autenticação corporativa. |
| `rag/rag_tool.py` | Recuperação tipada por instância, classificação segura, payload explícito, span independente e fechamento do pool. | Parser documental e wrapper legado preservados; assinatura aceita messages mas nunca os envia. | Retornar somente chunks perderia distinção técnica; nenhuma heurística de campos foi adicionada. |
| `llm/factory.py`, `llm/gateway_outbound.py` | Usar configuração da mesma instância, fechar pools e garantir uma tentativa por chamada. | Providers registrados continuam com build antigo; gateway recebe configuração opcional; retries automáticos deixam de ocorrer. | Manter singleton misturaria instâncias; manter retry implícito contrariaria a chamada única. |
| `validators/context_precision.py`, `validators/__init__.py` | Corrigir prompt real, preservar interface síncrona e instrumentar transporte assíncrono; não exportar texto livre. | Score, threshold, ação e fail-open preservados; detalhes livres deixam de ser atributos OTel. | Mudar somente o teste esconderia o defeito; executar invoke síncrono no A0 manteria transporte incompatível. |
| `validators/tool_correctness.py` | Mesmo defeito de chaves JSON encontrado no judge legado; sanitização da falha. | Capacidade legada preservada e exercitada com ToolNode real/local; continua fora do A0. | Apenas guardar arquivo quebrado não preservaria capacidade útil; não foi redesenhado o judge. |
| `app.py` | Contagem zero, readiness local coerente, encerramento de recursos e logs sem session_id/exception livre. | Rotas, schemas, eco de session_id e métricas mantidos; logs deixam de expor identificador de alta cardinalidade. | Apenas mascarar chunks deixaria identifiers e exceptions expostos; não foi criado sistema de métricas novo. |
| `utils/guardrails_middleware.py` | Encaminhar estruturas inválidas à validação HTTP e retirar conteúdo livre dos logs. | Regras de entrada/saída mantidas; tipos inválidos passam a 422 em vez de falha do middleware. | Converter tipos para string esconderia requests inválidos. |
| `utils/genera_safe_guardrails.py`, `utils/tracing.py` | Fechar pool opcional, respeitar desativação explícita do SDK e sanitizar erros. | Genera Safe preserva fail-open; exporter Azure continua configurável. | Remover integrações seria mais invasivo e impediria reutilização. |
| `tests/conftest.py` | Impedir rede e exportadores herdados antes da coleta, substituindo MagicMock global do pacote Azure. | Doubles explícitos e ASGI/MockTransport funcionam; DNS/conexões reais falham. Socketpair interno do asyncio Windows é a única exceção local, restrita ao loopback durante sua construção. | Apenas mockar chamadas previstas não impediria acessos acidentais. |
| `tests/unit/test_a0_v2.py` | Demonstrar invariantes com grafo, adapter, middleware e validators reais sob fronteiras controladas. | Acrescenta aceite local sem alterar lógica para satisfazer testes. | Testar só nós isolados não demonstraria integração/ordem/fast-exits. |
| `tests/unit/test_app.py`, `test_graph.py`, `test_rag_tool.py`, `test_context_precision.py`, `test_tool_correctness.py`, `test_gateway_outbound_provider.py` | Ajustar expectativas A0, manter regressão legada, testar classificações, prompt real e ausência de retries. | Testes antigos relevantes mantidos; contratos V1 de Tool count/ready foram substituídos pelo V2. | Manter asserts apenas de lista vazia/patch de template produziria falsos positivos. |
| `tests/unit/test_config.py` | Corrigir escrita de fixtures com acentos em Windows para UTF-8, conforme loader. | Conteúdo da fixture inalterado. | Depender de encoding do shell tornaria o teste não reproduzível. |
| `tests/fixtures/README.md`, `README.md`, comentário em `agent_config.yaml` | Corrigir proveniência sintética da fixture e distinguir fluxo ativo de referência histórica. | JSON da fixture e valores funcionais do YAML preservados; conteúdo histórico mantido. | Deixar a expressão “sanitizada” atribuiria origem real não demonstrada. |
| `.gitignore`, `.dockerignore` | Excluir `.deps311`, temporários e evidências locais do versionamento/contexto da imagem; Dockerfile contém COPY . /app. | Não modifica imagem base, manifests, requirements ou configuração de execução. | Não excluir copiaria bibliotecas Windows e arquivos de teste/rollback para a imagem. |
| Este relatório e `evidencias_a0_v2/` | Rastreabilidade, comandos, resultados, hashes, diff e reversão sem Git. | Normativos e memória histórica preservados; `.deps311` serve só à verificação local. | Resultado verbal sem artefatos não sustentaria aceite reproduzível. |

## 5. Execuções e reprodução

Todas as execuções listadas são **VALIDAÇÃO LOCAL**. Artefatos ficam em
`iaa-agent-mf-edu-fin-main/evidencias_a0_v2/`.

| Execução | Resultado e evidência |
|---|---|
| Coleta inicial após bloqueio de rede | Falhou: pasta antiga `pytest_temp` inacessível e ausência de langchain_azure_ai. `baseline_testes.txt`. Não foi validação bem-sucedida. |
| Primeira regressão 3.13 | O bloqueio de sockets inicialmente também impedia o socketpair interno do asyncio no Windows. Corrigida a exceção estritamente local; falhas registradas em `primeira_regressao.txt`. |
| Segunda regressão 3.13 | 133 aprovados/20 falhas: expectativas legadas, fixtures sem UTF-8 e pacote langchain_openai ausente. `segunda_regressao.txt`. Não equivale a aceite 3.11. |
| Dependências públicas 3.11 | Instaladas em `.deps311`; `dependencias311.txt`, `runtime311.json`, `dependencias311.lock.txt`. Requirements/setup existentes não foram alterados. |
| Primeira coleta 3.11 | Falhou no import eager de MCP/pywintypes a partir de diretório target; import MCP passou a ser restrito ao legado. `regressao311.txt`. Import/integracão real MCP não foi validado. |
| Regressão intermediária 3.11 | 206 aprovados/1 falha: SDK desativado também desativava o provider em memória do teste. O teste passou a habilitar somente esse provider. `regressao311b.txt`. |
| Direcionados V2 | 54 aprovados naquele checkpoint, `direcionados.txt`. Cobertura foi ampliada depois. |
| Suíte final | **215 passed**, zero falhas/skips, `testes_finais.txt` e `junit_final.xml`. |
| Compilação | `python311 -m compileall -q iaa_agent_mf_edu_fin tests`, exit code 0. Não é type checking nem build de imagem. |

Versões executadas: Python 3.11.9; pytest 9.1.1; pytest-asyncio 1.4.0;
FastAPI 0.142.1; Pydantic 2.13.5; httpx 0.28.1; LangGraph 1.2.12;
langchain-core/langchain-openai 1.6.6; opentelemetry-sdk 1.45.0.
O lock de evidência registra toda a resolução local, sem impor novos pins ao produto.

Reexecutar da pasta da aplicação, em PowerShell, usando as dependências já instaladas:

```powershell
$pythonA0 = 'C:/Users/manue/AppData/Local/Programs/Python/Python311/python.exe'
$env:PYTHONPATH = Join-Path (Get-Location) '.deps311'
$env:PYTHONUTF8 = '1'
& $pythonA0 -m pytest tests -q -p no:cacheprovider --junitxml=evidencias_a0_v2/junit_reexecucao.xml
& $pythonA0 -m compileall -q iaa_agent_mf_edu_fin tests
```

O comando executado na suíte final usou ainda `--basetemp=.pytest-a0-acceptance`.
Na reprodução acima foi omitido para não remover uma pasta temporária já existente.
O conftest neutraliza credenciais/exportadores herdados e bloqueia rede antes da
importação da aplicação. Não iniciar o serviço real com credenciais corporativas.

Caso as bibliotecas locais precisem ser reinstaladas, usar pasta target vazia,
com Python 3.11, removendo influência de índices configurados:

```powershell
$env:PIP_CONFIG_FILE = 'NUL'
$env:PIP_INDEX_URL = 'https://pypi.org/simple'
$env:PIP_EXTRA_INDEX_URL = ''
& $pythonA0 -m pip --isolated install --index-url https://pypi.org/simple --no-cache-dir --target .deps311 -r evidencias_a0_v2/dependencias311.lock.txt
```

A instalação original solicitou pytest, pytest-asyncio, fastapi, pyyaml, httpx,
langgraph, langchain-openai, langchain-mcp-adapters, opentelemetry-sdk e rapidfuzz.
O runtime da suíte não inclui o pacote opcional langchain_azure_ai nem os exporters
corporativos: configuração do callback foi testada com double e exportação de spans
próprios com SDK real em memória. Instalação integral de requirements, distribuição
via setup.py, imagem Linux, instrumentação automática e entrega ao backend Azure/OTLP
permanecem não verificadas.

## 6. Matriz CA-001 a CA-036

“LOCAL” significa evidência nesta cópia com integrações controladas; nenhuma linha
representa aceite corporativo. Prefixo `V2` refere-se a `tests/unit/test_a0_v2.py`.
Os demais arquivos referidos ficam em `tests/unit/`.

| CA | Resultado | Evidência e limite |
|---|---|---|
| CA-001 | LOCAL | V2 `test_entry_guard_blocks_before_real_scope`, `test_http_real_graph_guardrails_order`; regressão de middleware. |
| CA-002 | LOCAL | START → scope; teste de fora de escopo sem nenhuma integração e casos de ordem. |
| CA-003 | LOCAL | V2 `test_two_instances_and_concurrent_request_isolation`, política capturada por grafo. |
| CA-004 | LOCAL | ScopeResult e corpus em `test_scope_policy.py`: três estados. |
| CA-005 | LOCAL | V2 `test_out_of_scope_never_loads_mcp_tools_rag_or_llm`. |
| CA-006 | LOCAL | Mesmo teste: factory LLM não chamada. |
| CA-007 | LOCAL | V2 `test_order_success_low_score_and_judge_failure`, caso indeterminado. |
| CA-008 | LOCAL | Mesmo teste, casos dentro e misto. |
| CA-009 | LOCAL | Ordem RAG → judge → geração → validators, sem chamada prévia do modelo. |
| CA-010 | LOCAL | V2 `test_real_http_payload_and_index_precedence`, path exato via MockTransport. |
| CA-011 | LOCAL | Mesmo teste: action exata no JSON. |
| CA-012 | LOCAL | Mesmo teste: index_id vence agent_id. |
| CA-013 | LOCAL | Mesmo teste: fallback legado. |
| CA-014 | LOCAL | Schema AgentState e resultado do grafo contêm scope_result. |
| CA-015 | LOCAL | Schema AgentState e recuperação contêm rag_context. |
| CA-016 | LOCAL | Schema AgentState e roteamento contêm rag_result. |
| CA-017 | LOCAL | V2 `test_no_generation_without_consistent_success`, NO_CONTEXT. |
| CA-018 | LOCAL | Mesmo teste, INFRA_ERROR; configuração desligada exercita adapter real. |
| CA-019 | LOCAL | Uma chamada geradora em SUCCESS; entrada delimitada verificada. Não prova fidelidade factual de modelo real. |
| CA-020 | LOCAL | Judge real com transporte double, falha observacional e span próprio. |
| CA-021 | LOCAL | Score 0.1 não bloqueia nem altera RAGResult; execução geradora comprovada no cenário controlado. |
| CA-022 | LOCAL | Grafo ativo sem ToolNode/bind_tools/MCP; legado testado por entrada separada. |
| CA-023 | LOCAL | V2 `test_telemetry_exports_only_safe_measures`: RAG.gateway_core, resultado, count e duração em SDK real/memória. |
| CA-024 | LOCAL | Ordem toxicity/non_advice/PII testada; testes semânticos existentes preservados. |
| CA-025 | LOCAL | V2 `test_fast_exit_output_is_actually_redacted`, três caminhos; geração passa pela saída. |
| CA-026 | LOCAL | Config exige três strings distintas/não vazias; `test_mvp_instance_config.py` verifica conteúdo MVP. Aprovação formal pendente. |
| CA-027 | LOCAL | V2 `test_http_real_graph_guardrails_order`: HTTP 200 em cada fast-exit. |
| CA-028 | LOCAL | Mesmo teste e `test_app.py`: schema, session_id e zero Tools. |
| CA-029 | PENDENTE — GATE-001 | Parser estrito e fixture sintética documentais testados. Não existe payload real aplicável para comprovar schema real. |
| CA-030 | LOCAL | Inspeção das mudanças/documentação: nenhum SLO inventado; timeout é parâmetro técnico. |
| CA-031 | LOCAL | Sem checkpointer/store/cache; estados separados e concorrentes; HTTP inicializa só mensagem atual. |
| CA-032 | LOCAL | V2 `test_operational_endpoints_local_and_lifecycle` e `test_app.py`: live 200 sem rede. |
| CA-033 | LOCAL | Mesmo teste: ready 200 com configuração controlada completa, 503 sem requisitos; ausência de grafo mantém 503. |
| CA-034 | LOCAL | Campos JSON originais de metrics preservados e testados. |
| CA-035 | LOCAL; corporativo pendente | 215 testes em Python 3.11.9 e manifests locais 3.11. Imagem/esteira/runtime implantado não inspecionados. |
| CA-036 | LOCAL | Duas políticas/índices simultâneos, config copiada e nenhuma taxonomia fixa no código. |

## 7. Rastreabilidade adicional

| Requisitos | Implementação/evidência |
|---|---|
| RF-001–006, RN-001–004, RNF-001/010 | Middleware, ScopePolicy e grafo; CA-001–008/036; corpus MVP sem alteração. |
| RF-007–010, RN-005–008, RNF-007/011 | Adapter tipado, gates de geração e judge assíncrono; CA-009–021/029. |
| RF-009, RN-006 | Prompt RAG-only e dados delimitados demonstrados localmente. Fundamentação de respostas reais continua dependendo de avaliação externa de conteúdo. |
| RF-011–013, RN-010/011 | Validators, três respostas e middleware de saída; CA-024–027. |
| RF-014–017, INT-001/002/004/005, RNF-002–005 | Contratos HTTP, estado novo por request, probes e metrics; CA-014–016/028/031–034. |
| RF-018, INT-006, RNF-006 | Spans ScopePolicy.evaluate, RAG.gateway_core, LLM.generate e validate.*; middleware mede duração total; teste de sentinelas em conteúdo, motivo do judge e credencial. |
| RF-019, INT-003 | Payload/documentação e precedência/fallback de índice; CA-010–013. |
| RF-020, RNF-004/005 | Readiness/configuração local sem sondagem; live independente. |
| RN-009, RNF-012 | A0 sem MCP/Tools; não foram alteradas dependências do produto; legado explícito e testado. |
| RN-012, RNF-008 | Timeout preservado e documentação sem metas quantitativas. |
| RN-013/014, RNF-009/010 | Sem memória; configuração por instância; runtime local 3.11. |
| RN-015 | Parser documental conservador; comprovação real continua no GATE-001. |

Telemetria própria usa `scope.result`, `scope.policy_version`, `rag.result`,
`rag.chunk_count`, `rag.duration_ms`, `llm.result`, `llm.duration_ms` e medidas
`validator.*`; a duração total continua em `guardrail.latency_ms`.
Callback Azure recebe `enable_content_recording=False`, mesmo se OTEL_RECORD_CONTENT
estiver true. O teste não inspeciona infraestrutura externa, instrumentadores
adicionais, retenção ou políticas efetivas do backend.

## 8. Gates e continuidade corporativa

| Gate | Estado nesta entrega | Evidência necessária para fechar | Responsável externo (papel; pessoa a designar) |
|---|---|---|---|
| GATE-001 | ABERTO; parser documental + testes sintéticos | Payload real sanitizado, projeto/ambiente/data/origem/contrato identificados, exemplo vazio e casos de erro aplicáveis; aprovação do parser e fixture correspondente. | Responsável pela integração GeneraBB + backend do agente. |
| GATE-002 | ABERTO; prompt MVP autorizado para desenvolvimento | Versão/hash e aprovação negocial formal do prompt da instância. | Responsável negocial/produto de educação financeira. |
| GATE-003 | ABERTO; política/corpus MVP integrados | Aceite funcional formal da versão, taxonomia, precedência de temas mistos, corpus e tratamento de indeterminados. | Produto/domínio + QA funcional autorizado. |
| GATE-004 | ABERTO; três mensagens MVP autorizadas | Aprovação formal independente dos três textos e de sua configuração. | Responsável negocial/conteúdo do agente. |

As ações seguintes são procedimento para o responsável autorizado no ambiente
corporativo. **Não foram executadas e não autorizam conexão a partir desta cópia.**

1. Identificar projeto, ambiente, branch/commit, release e configuração candidata.
   Confrontar o diff/manifest desta entrega com a base corporativa; não presumir
   equivalência da cópia. Fechar os gates com evidências versionadas aplicáveis.
2. Configurar a instância: scope habilitado/versionado, prompt e mensagens aprovados,
   endpoint core aplicável, index_id (agent_id só como fallback), UOR, user_id,
   total_context e timeout; provider/modelo/URL/API version do LLM. Os valores reais
   devem vir do responsável, sem completar lacunas com exemplos do repositório.
3. Provisionar RAG_CLIENT_ID, App Key e material TLS pelos mecanismos corporativos
   autorizados. Não gravar valores em código, logs ou relatório. Confirmar requisitos
   de mTLS/CA com o contrato aplicável; readiness local não os autentica.
4. Ativar `rag.enabled: true` somente com configuração/evidência correspondentes.
   MCP permanece fora do caminho A0 independentemente de sua configuração.
   Genera Safe é opcional e preservado, com decisão própria e sem exigir ativação.
5. Pelo processo autorizado, verificar artefato/imagem por digest, Python efetivo,
   dependências, configuração montada e versão da política. Os manifests locais
   alinhados a 3.11 não comprovam o que está implantado. Registrar build/CI/deploy
   correlacionados; workflows compartilhados não foram inspecionados aqui.
6. No ambiente autorizado, validar payload/headers/contrato real; executar casos
   dentro/fora/indeterminado, ausência documental, indisponibilidade e sucesso.
   Conferir uma recuperação estrutural, uma geração, judge observacional, proteção
   de saída, session_id e contagem zero. Avaliar fidelidade factual das respostas
   reais ao corpus aprovado, sem inferi-la dos doubles locais.
7. Verificar liveness/readiness/metrics e recepção dos spans no backend efetivo,
   sem captura de conteúdo, headers sensíveis ou exceptions livres. Confirmar
   comportamento dos instrumentadores/exporters reais. Durações observadas não
   constituem SLO aprovado.
8. Antes da promoção, registrar responsáveis e plano de reversão para imagem e
   configuração aprovadas. Se precisar reverter, comparar o estado efetivo e usar
   versão/digest/configuração anteriores compatíveis. Não apontar o A0 automaticamente
   para `create_legacy`; isso mudaria a arquitetura e exige decisão específica.

## 9. Reversão local e artefatos

`baseline.zip` contém os originais dos arquivos preexistentes modificados;
`baseline_sha256.json` identifica seu conteúdo. `alteracoes.json` lista paths com
hash anterior/atual e arquivos novos. `alteracoes.patch` é diff unificado para revisão.
Não existe garantia de reversão por Git nesta cópia.

Procedimento local, **não executado**:

1. Parar somente eventual processo local desta aplicação e conferir se houve edições
   posteriores pelos hashes atuais em `alteracoes.json`. Se houver divergência,
   reconciliar manualmente antes de sobrescrever.
2. Restaurar do zip apenas os arquivos preexistentes listados como alterados,
   verificando que cada destino absoluto permanece dentro da pasta da aplicação.
   Não extrair conteúdo de caminho externo nem restaurar indiscriminadamente toda a árvore.
3. Se for desejado desfazer integralmente esta entrega, remover somente o arquivo novo
   `tests/unit/test_a0_v2.py` após comparação do hash. O relatório/evidências podem
   permanecer como histórico; removê-los não é necessário para reverter a aplicação.
4. `.deps311` e `.pytest-a0-*` são artefatos descartáveis de validação, não runtime do
   produto. Sua exclusão opcional exige conferência do caminho absoluto. A pasta
   preexistente inacessível `pytest_temp` não foi modificada.
5. Conferir hashes contra o baseline. A reversão retorna ao estado parcial encontrado,
   inclusive seus defeitos conhecidos; não comprova correção nem prontidão corporativa.

A entrega local está concluída. Permanecem externos os quatro gates, o contrato real,
respostas reais do modelo, instalação/build completos, imagem/configuração implantadas,
instrumentação/exportação corporativa e qualquer aceite de produção.

## 10. Passagem de documentação por blocos

Após a implementação funcional, foi aplicada uma segunda passagem exclusiva de
comentários e documentação. Ela cobre `graph.py`, o adapter RAG, configuração,
política de escopo, app/lifecycle, guardrails, tracing, provider LLM, validators,
testes e fixtures. Os comentários explicam responsabilidade, motivo, restrição,
compatibilidade legada e limite da evidência; não repetem cada linha nem alteram
contratos ou decisões do fluxo.

Essa passagem foi verificada novamente com:

```text
Python 3.11.9 -m pytest tests -q -p no:cacheprovider --basetemp=.pytest-a0-comments
215 passed in 3.95s
Python 3.11.9 -m compileall -q iaa_agent_mf_edu_fin tests
exit code 0
```

Os artefatos `baseline_sha256.json` e `alteracoes.json` registram o estado da
primeira entrega funcional, anterior a esta passagem exclusivamente documental;
eles não devem ser usados como hash final dos comentários adicionados. O resultado
funcional permaneceu igual, confirmado pela suíte acima.
