# Etapa 01 — Baseline executável e contratos preservados

Data da execução: 2026-09-29. Workspace: `C:\Users\manue\Docs\MF_EDU_FIN\v0`.
Não existe memória de etapa anterior. Este registro descreve esta cópia local;
branch, commit, imagem implantada e estado corporativo não foram verificados.

## 1. Fontes, autoridade e limites

1. `especificacao_requisitos_a0_versao2.md`, SRS 2.0, lido integralmente, normativo.
2. `plano_arquitetura_a0_versao2.md`, arquitetura V2, lido integralmente.
3. Prompt da Fase 01 fornecido nesta conversa, que delimita esta macroetapa.
4. Código, testes, configuração e manifests presentes no workspace.

Os dois documentos normativos são read-only. Git não foi utilizado e nenhum
arquivo de CI/CD foi alterado. Leitura de workflows locais comprova somente a
configuração declarada; não comprova execução nem o comportamento dos workflows
compartilhados. Nenhuma operação corporativa foi executada.

Esta cópia é uma réplica para estudo e desenvolvimento, criada para tentar
reproduzir o código corporativo sob as limitações do workspace. Ela não tem
garantia de equivalência com a versão corporativa ativa, seus serviços, suas
credenciais, sua infraestrutura ou seus componentes compartilhados. Os
resultados desta etapa são evidências locais da cópia analisada.

O SRS descreve evidência histórica: ausência de pytest e `aic.json` com Python
3.8. Nesta sessão, pytest está disponível e `aic.json` contém 3.11. Isso não altera
o SRS nem comprova qual configuração está ativa no ambiente corporativo.

## 2. Estado antes da fase — BASELINE OBSERVADO

### Package, runtime e comandos

- Aplicação: `iaa-agent-mf-edu-fin-main/`.
- Package/import: `iaa_agent_mf_edu_fin`; versão em `__init__.py`: `0.1.0.dev0`.
- API ASGI: `iaa_agent_mf_edu_fin.app:app`.
- Entrypoint: `python -m iaa_agent_mf_edu_fin`; console script com o mesmo nome,
  declarado em `setup.py`, aponta para `iaa_agent_mf_edu_fin.__main__:main`.
- `__main__.py`: Uvicorn, host padrão `0.0.0.0`, porta 8080, um worker;
  não configura reload. A execução diagnóstica usou loopback e porta 18081.
- `setup.py`: `python_requires='>=3.11'`, classificador 3.11. Não existe
  `pyproject.toml` nesta cópia. O mínimo declarado não fixa o minor em 3.11.
- `Dockerfile`: imagem corporativa
  `docker.binarios.intranet.bb.com.br/bb/dev/dev-python:3.11.6`, venv `/app/.venv`,
  instalação com `uv pip install -r /app/requirements.txt` e
  `opentelemetry-bootstrap -a install`; inicia `opentelemetry-instrument`
  seguido de `python -m iaa_agent_mf_edu_fin`. Imagem não construída/testada.
- `aic.json`: `versaoPython=3.11`, `publicarPacoteEImagem=true`. Valores herdados
  do início desta fase; nenhum deles foi alterado ou validado contra a esteira.
- `.venv/Scripts/python.exe`: CPython 3.13.5, efetivamente executado.
  `pyvenv.cfg` registra criação em outro diretório. Importação nesta sessão
  resolveu o package desta cópia, não daquele caminho histórico.
- Python 3.11.9 encontrado posteriormente em
  `C:\Users\manue\AppData\Local\Programs\Python\Python311\python.exe`.
  Não estava no PATH nem listado por `py -0p`; inicialmente sem pytest/FastAPI.

Dependências efetivamente usadas nos testes em 3.13.5:

| Biblioteca | Versão |
|---|---|
| FastAPI / Starlette | 0.141.1 / 1.7.0 |
| Pydantic / httpx | 2.13.5 / 0.28.1 |
| LangGraph / langchain-core | 1.2.12 / 1.6.5 |
| pytest / pytest-asyncio | 9.1.1 / 1.4.0 |
| Uvicorn | 0.54.0 |

`requirements.txt` e `setup.py` não são equivalentes: o primeiro exige
LangGraph >=1.0.0, inclui `langchain>=1.0.0` e `rapidfuzz>=3.9`; o segundo
declara LangGraph >=0.2 e inclui `requests`. Não foram harmonizados nesta fase.
O helper de similaridade tem fallback local quando rapidfuzz não é importável.

### CI/CD e deploy declarados

- `.github/workflows/ci.yaml`: push em `main`, `fix/**`, `feat/**`, `feature/**`
  e disparo manual; chama `aic-workflow-python/.../workflow.yml@v2`. Autodeploy
  des/hom é condicionado a outputs do CI e chama workflow compartilhado @v1.
- `Jenkinsfile`: biblioteca compartilhada; build/empacotamento/publicação
  declarados como habilitados, testes unitários/integrados como desabilitados.
  Coexistência dos arquivos não comprova qual rota executa.
- `.github/workflows/copilot-setup-steps.yaml`: somente checkout declarado;
  não constitui evidência de instalação/testes do serviço.
- Deploy local: `deploy-iaa-agent-mf-edu-fin-cloud-homologacao/values.yaml`.
  Service habilitado, `envFrom` aponta para Secret `env`, tag `0.1.0-SNAPSHOT`,
  custodiante `F6745399`. Probes `/health/live` e `/health/ready` usam porta 8080.
  Secret e imagem não foram consultadas. Nome da pasta não comprova branch.
- Workflow de deploy local chama `aic-workflow-deploy-cloud/.../deploy.yaml@v1`.
  Destino observado pelo Argo CD, estado GitOps e imagem efetiva desconhecidos.

### HTTP e segurança

`app.py` declara:

| Schema | Campos e comportamento observado |
|---|---|
| ChatRequest | `message: str` obrigatório; `session_id: str ou null`, padrão null |
| ChatResponse | `reply: str` obrigatório; `session_id: str ou null`; `tool_calls_made: int`, padrão 0 |
| MetricsResponse | `uptime_seconds: float`, `total_requests: int`, `agent_id: str`, `agent_name: str` |

Não há `min_length`/`max_length` no schema de `message`. String vazia é aceita.
Campos extras são ignorados pelo modelo; histórico enviado como campo extra
não entra no grafo. O limite de entrada está no middleware, por número de
caracteres: `GUARDRAIL_MAX_INPUT_LEN`, padrão 4096, carregado na importação.

Guardrails envolvem POST exatamente em `/chat`, antes do handler/grafo:
tamanho → injection/jailbreak → PII → Genera Safe opcional → handler →
blocklist de saída → redação de PII. PII de entrada e redação de saída são
habilitadas por padrão. A suíte existente cobre habilitação/desabilitação,
bloqueio externo controlado, blocklist e redação.

Genera Safe está desabilitado no YAML. O código retorna sem chamar HTTP se
desabilitado ou sem client ID e falha em aberto nos erros tratados. Esta cópia
termina em `return None`; não foi encontrado trecho posterior de código morto
a remover nessa função. Não foi feita limpeza oportunista.

Resultados HTTP medidos via ASGI, com doubles nas dependências:

| Entrada / situação | Resultado observado |
|---|---|
| Mensagem válida | 200, reply controlado, session_id ecoado |
| `message` ausente | 422 |
| JSON malformado | 422 |
| `session_id` numérico com mensagem válida | 422 |
| `message` null/número/booleano/lista/objeto | 500, texto `Internal Server Error` |
| String vazia / 4096 caracteres | 200 |
| 4097 caracteres | 400, `input_too_long`, grafo não compilado/chamado |
| Injection ou PII de teste | 400 com código próprio, antes do grafo |
| Exception do LLM/grafo | 500 JSON, `detail: Erro interno do servidor.` |
| PII no reply controlado | 200 com `[EMAIL]` |

**Defeito preexistente:** o middleware executa `len(message)` e filtros de string
antes do Pydantic, sem validar o tipo. Por isso o 422 não pode ser generalizado
para toda entrada estrutural inválida. O modelo isolado rejeita os cinco tipos;
na API, o middleware produz 500 antes dele. Testes de caracterização desse 500
registram o defeito e deverão mudar junto com uma correção futura autorizada.

Não existe handler global customizado para toda exception nesta aplicação.
Há um `try/except` ao redor de `graph.ainvoke` em `/chat`, que converte o erro
em HTTPException 500 genérica. Erros do middleware ficam fora desse bloco.
Não foi declarado contrato JSON universal de erro com base no caso do grafo.

`/health/live` retorna 200/alive sem consultar configuração/grafo/remotos.
`/health/ready` usa `get_config()` e `graph._compiled`: 503 se config falha ou
grafo está ausente; 200/ready se ambos estão disponíveis. Não verifica chave,
índice RAG ou conectividade. Configuração é singleton em memória; readiness
não implica releitura/validação do YAML em toda chamada.
`/metrics` lê configuração e contador local; `/chat` incrementa o contador ao
entrar no handler, inclusive quando a execução do grafo falha.

### Grafo, RAG e estado

Topologia **BASELINE OBSERVADO**, mantida nesta fase:

```text
Guardrails de entrada → llm_call
  ├─ sem tool_calls → END
  └─ com tool_calls → ValidatingToolNode → check_rag_context
       ├─ último ToolMessage vazio ou "[]" → RAG_EMPTY_REPLY → END
       └─ conteúdo → llm_call
→ Guardrails de saída
```

- `AgentState` declara somente `messages`, com reducer `add_messages`.
- `AgentFactory.create` busca ferramentas MCP, adiciona RAG Tool quando habilitada
  e executa `bind_tools`. O LLM decide se usa a ferramenta; não há Scope Gate.
- Validators toxicity/non_advice/PII executam em respostas do LLM com texto.
  `tool_correctness` e `context_precision` executam após ToolMessages.
- Context precision usa judge LLM síncrono; erros são fail-open, score neutro.
  O wrapper registra resultados sem usá-los para mudar o state/roteamento.
- `tool_calls_made` conta ToolMessages. O teste existente comprova **1** quando
  há um ToolMessage. Zero no novo teste sem ToolMessage não fecha CA-028 V2.
- O adapter RAG desta cópia **já** possui `RAGResult`/`RAGResponse`, ação
  `recuperar-contexto-indice` e `index_id`. Nada disso foi criado nesta fase.
- O YAML já aponta para `/gateway/core`, mas o default `_GENERA_GATEWAY_URL`
  usado por `RAGConfig`/loader continua `/gateway/agent`.
- `index_id` não vazio vence; caso vazio, usa `_legacy_agent_id`. O YAML tem
  `index_id`, `uor` e `user_id` vazios. Não se comprovou configuração corporativa.
- `_call_gateway` distingue SUCCESS, NO_CONTEXT e INFRA_ERROR, mas a Tool
  retorna apenas `res.chunks`; o grafo perde a distinção entre vazio e erro.
- `_extract_text` tenta `text`, `content`, `page_content`, depois `str(item)`.
  Trata-se de heurística efetivamente inspecionada, incompatível com o parser
  definitivo exigido pela V2/GATE-001. A fixture sintética existente não fecha o gate.
- Cliente `httpx.AsyncClient` reutilizado em variável de módulo, timeout RAG
  configurável (10 s no YAML); timeout Genera Safe 5 s. Não são SLOs.
- LLM não tem timeout/retry configurados explicitamente pelo projeto; defaults
  das dependências não foram promovidos a requisitos. Nenhum retry foi adicionado.

Não foi encontrada persistência conversacional: `builder.compile()` sem
checkpointer/store; invocação recebe somente a mensagem atual; session_id não
é passado como thread_id. Teste com o mesmo grafo/sessão e duas requisições
comprova mensagens isoladas e `checkpointer is None`. Singletons de config,
cliente HTTP, grafo e métricas não são memória conversacional. Não foram
adicionados cache, memória, MCP, streaming ou nova persistência.

### Logging, tracing e dependências externas

- Logs de `/chat` contêm session_id, duração e quantidade de tools; exceptions
  usam `logger.exception`, com traceback no log do servidor.
- Middleware e validators têm spans/contadores/histogramas OTel. Validators
  registram `details[:512]`; isso exige avaliação de conteúdo sensível posterior.
- Azure tracer é condicional a `APPLICATION_INSIGHTS_CONNECTION_STRING` e
  tem `OTEL_RECORD_CONTENT=true` por padrão. Há risco de conteúdo em telemetria;
  não se certificou RNF-006. Exportação Azure não foi habilitada/testada.
- `utils/tracing.py` tem divergência entre nome da variável na docstring e no
  código; o código efetivo usa `APPLICATION_INSIGHTS_CONNECTION_STRING`.
- Não há span HTTP explícito `RAG.gateway_core` no adapter atual.
- Dependências: Gateway Outbound (chave `GATEWAY_OUTBOUND_GW_APP_KEY`, certificados
  quando configurados), Genera RAG (`RAG_CLIENT_ID` e parâmetros), MCP local
  configurado em localhost:9000, Genera Safe opcional, telemetria quando habilitada.
- Startup real: tentativa MCP falhou e foi tolerada; depois faltou a chave do
  Gateway, com KeyError. Isso impediu o startup completo. Importar o módulo
  com sucesso não comprova startup, conectividade ou geração real.

## 3. Alterações e justificativas

| Arquivo / artefato | Alteração | Necessidade agora | Preserva / impacto | Alternativa conservadora |
|---|---|---|---|---|
| `iaa-agent-mf-edu-fin-main/tests/unit/test_baseline_fase01.py` | Criado, 20 casos parametrizados | Cobrir lifespan, isolamento, validação estrutural e probes além dos doubles de grafo existentes | Zero mudança de produção; testes marcam legado explicitamente; IDs curtos tornam relatórios legíveis | Só registrar inspeção; insuficiente para reproduzir os contratos pedidos |
| `etapa_01.md` | Criado | Memória obrigatória, evidências, comandos e rastreabilidade | Documentos normativos intactos | Resposta na conversa não substitui memória autossuficiente |
| `.venv-fase01-311/` dentro da aplicação | Ambiente gerado por `venv`, utilizado e removido ao final | Validar o minor normativo sem substituir a `.venv` recebida | Artefato temporário; remoção evita inclusão no build, pois `.dockerignore` exclui somente `.venv` | Deixar execução 3.11 pendente |

Nenhum arquivo de produção, dependência declarada, configuração, CI/CD ou deploy
foi modificado/removido. Pytest pode gerar `__pycache__`; cacheprovider foi
desabilitado. Não houve refatoração ou correção funcional excepcional.

**DECISÕES TÉCNICAS:** seguir o padrão pytest/httpx/AsyncMock existente; exercitar
lifespan e grafo compilado reais com doubles somente de LLM/MCP/guardrail externo;
bloquear e verificar ausência de uso dos transports HTTP síncrono/assíncrono nos
novos testes; manter explicitamente a caracterização dos defeitos atuais.
Essa instrumentação não equivale a validar todos os SDKs em rede corporativa.

**Decisões arquiteturais preservadas:** target segurança → escopo → RAG → geração
condicionada; stateless; contratos e endpoints; ausência de SLO inventado;
nenhuma ativação antecipada da topologia final.

**Decisões não tomadas:** schema real dos chunks, taxonomia, prompt/textos finais,
valor correto de publicação da esteira, remoção MCP, correção do middleware,
reorganização de validators, pins de dependências, credenciais e release.

## 4. Comandos canônicos e resultados

Os comandos PowerShell abaixo partem do diretório da aplicação:

```powershell
Set-Location -LiteralPath 'C:\Users\manue\Docs\MF_EDU_FIN\v0\iaa-agent-mf-edu-fin-main'
```

### Build/importação/ambiente

| ID | Comando | Esperado | Obtido | Status |
|---|---|---|---|---|
| B01 | `.\.venv\Scripts\python.exe --version` | Identificar runtime real | Python 3.13.5 | OK |
| B02 | `.\.venv\Scripts\python.exe -m pip check` | Dependências instaladas consistentes | `No broken requirements found.` | OK |
| B03 | Comando de importação abaixo | Import local e schema carregados | Package local 0.1.0.dev0, schemas e versões registrados | OK |
| B04 | `.\.venv\Scripts\python.exe -m iaa_agent_mf_edu_fin --help` | CLI carregável | Opções host/port/workers/log-level, exit 0 | OK |
| B05 | `.\.venv\Scripts\python.exe -m iaa_agent_mf_edu_fin --host 127.0.0.1 --port 18081` | Startup concluído | Exit 1, KeyError da chave do Gateway após falha MCP tolerada | FALHOU |
| B06 | Build da imagem corporativa | Imagem Python 3.11 executável | Não executado; registry/credenciais e Docker runtime não validados | NÃO EXECUTADO |

Comando B03 efetivamente executado:

```powershell
.\.venv\Scripts\python.exe -c "import sys, importlib.metadata as m; import iaa_agent_mf_edu_fin as p; from iaa_agent_mf_edu_fin.app import app, ChatRequest, ChatResponse; print('runtime=',sys.version); print('executable=',sys.executable); print('package=',p.__file__); print('version=',p.__version__); print('distribution=',m.distribution('iaa_agent_mf_edu_fin').locate_file('')); print('libraries=',{n:m.version(n) for n in ['fastapi','pydantic','starlette','httpx','langgraph','langchain-core','pytest','pytest-asyncio','uvicorn']}); print('ChatRequest=',ChatRequest.model_json_schema()); print('ChatResponse=',ChatResponse.model_json_schema())"
```

### Suíte e regressão

| ID | Comando | Esperado | Obtido | Status |
|---|---|---|---|---|
| T01, antes | `.\.venv\Scripts\python.exe -m pytest -q -p no:cacheprovider` | Executar suíte original | 135 aprovados, 0 falhos, 6.65 s | OK |
| T02, direcionado | `.\.venv\Scripts\python.exe -m pytest tests/unit/test_baseline_fase01.py -v -p no:cacheprovider` | Caracterizar contratos/startup com doubles | 20 aprovados, 0 falhos, 1.17 s; antes de abreviar IDs de parametrização | OK |
| T03, depois | `.\.venv\Scripts\python.exe -m pytest -q -p no:cacheprovider` | Regressão original + novos testes | 155 aprovados, 0 falhos, 3.41 s | OK |

Nenhum failure da suíte original foi encontrado nesta sessão. Isso não significa
ausência de defeitos: os novos casos identificaram os 500 do middleware.
`tests/integration/test_dummy.py` contém somente exemplo aritmético; seu sucesso
não valida integração corporativa. Tempos acima são medições, não SLOs.

### Testes direcionados: objetivo, entrada/double, esperado e obtido

Todos os casos abaixo executam por T02, e novamente por T03. Prefixo dos nomes:
`tests/unit/test_baseline_fase01.py::`. Os transports HTTP externos são bloqueados
e recebem assert de zero chamadas. LLM retorna resposta sintética, MCP retorna
lista vazia, guardrail externo retorna None. Nenhum payload real Genera foi criado.

| Teste | Objetivo / entrada | Esperado | Obtido | Status |
|---|---|---|---|---|
| `test_startup_controlado_compila_grafo_real` | lifespan real, LLM/MCP doubles | Grafo compilado, checkpointer None, ready 200, zero geração | Igual | OK |
| `test_probes_e_metrics_antes_do_startup_sem_http_externo` | Grafo ainda ausente, GET nos 3 endpoints | live 200, ready 503, metrics 200 com 4 campos | Igual | OK |
| `test_readiness_com_config_invalida_nao_afeta_liveness` | get_config lança ValueError | ready 503 e live 200 | Igual | OK |
| `test_chat_grafo_real_isola_mensagens_da_mesma_sessao` | Duas mensagens/sessão idêntica, LLM double | 200, echo sessão, cada chamada só system + pergunta atual | Igual, checkpointer None | OK |
| `test_422_estrutural_confirmado_sem_chamar_llm` (2) | Campo ausente / sessão numérica | 422, zero LLM | Igual | OK |
| `test_legado_tipo_invalido_no_middleware_retorna_500` (5) | null, número, booleano, lista, objeto | Caracterizar defeito 500 antes de LLM | Igual; não é aceite de comportamento desejado | OK |
| `test_json_malformado_retorna_422` | Corpo `{` | 422, zero LLM | Igual | OK |
| `test_guardrails_bloqueiam_antes_da_compilacao` (3) | 4097 chars, injection, email sintético | 400/código específico sem compilar/chamar grafo | Igual | OK |
| `test_limites_aceitos_pelo_baseline` (2) | Vazia e 4096 chars | 200, uma chamada LLM double | Igual | OK |
| `test_saida_do_grafo_real_passa_pela_redacao` | Reply com email sintético | 200, email substituído por `[EMAIL]` | Igual | OK |
| `test_erro_llm_retorna_500_sem_detalhe_interno` | LLM double lança RuntimeError | 500 JSON genérico | Igual | OK |
| `test_schema_preservado_e_campos_extras_ignorados` | Schemas, tipos inválidos, extra history | Campos preservados, modelo rejeita tipos, extra não vira histórico | Igual | OK |

A suíte original também cobre blocklist de saída, PII, Genera Safe fail-open,
contagem de ToolMessage, adapter RAG com fixtures sintéticas, configuração e
validators. Não foram declarados fast-exits V2 validados por esses testes.

### Ambiente Python 3.11

Comandos de preparação executados nesta fase, na raiz da aplicação:

```powershell
& 'C:\Users\manue\AppData\Local\Programs\Python\Python311\python.exe' -m venv .venv-fase01-311
.\.venv-fase01-311\Scripts\python.exe -m pip install -r requirements.txt pytest pytest-asyncio
```

As duas tentativas de instalação no sandbox ficaram sem progresso conclusivo
e foram interrompidas. A segunda usou o comando abaixo, posteriormente repetido
com autorização fora do sandbox e concluído com exit 0:

```powershell
.\.venv-fase01-311\Scripts\python.exe -m pip --disable-pip-version-check --no-input --timeout 15 --retries 0 install -r requirements.txt pytest pytest-asyncio -v
```

Não se atribui uma causa interna definitiva à paralisação inicial; a evidência
é que a execução autorizada instalou as dependências. As opções timeout/retries
acima pertencem ao instalador, não à aplicação, e não são SLO.

| ID | Comando | Esperado | Obtido | Status |
|---|---|---|---|---|
| B07 | Instalação autorizada acima | Dependências de runtime e testes instaladas em ambiente isolado | `Successfully installed`, exit 0 | OK |
| B08 | `.\.venv-fase01-311\Scripts\python.exe -m pip --disable-pip-version-check check` | Consistência das dependências instaladas | `No broken requirements found.` | OK |
| B09 | Importação abaixo | Runtime 3.11 e package desta cópia importável | Python 3.11.9, package local 0.1.0.dev0, exit 0 | OK |
| T04 | `.\.venv-fase01-311\Scripts\python.exe -m pytest -q -p no:cacheprovider` no sandbox | Executar os 155 testes | 115 aprovados, 40 erros de setup, 5.20 s; PermissionError em `AppData/Local/Temp/pytest-of-manue` | FALHOU |
| T05 | Mesmo comando T04, repetido com autorização fora do sandbox | Executar a suíte inteira sem bloqueio da pasta temporária | 155 aprovados, 0 falhos/erros, 3.96 s | OK |
| B10 | `.\.venv-fase01-311\Scripts\python.exe -m iaa_agent_mf_edu_fin --host 127.0.0.1 --port 18081` | Startup real concluído | Exit 1, KeyError `GATEWAY_OUTBOUND_GW_APP_KEY`, após falha MCP tolerada | FALHOU; classificação causal: BLOQUEADO POR AMBIENTE |

Comando B09 efetivamente executado:

```powershell
.\.venv-fase01-311\Scripts\python.exe -c "import sys, importlib.metadata as m; import iaa_agent_mf_edu_fin as p; from iaa_agent_mf_edu_fin.app import app; print('runtime=',sys.version); print('package=',p.__file__); print('version=',p.__version__); print('libraries=',{n:m.version(n) for n in ['fastapi','pydantic','starlette','httpx','langgraph','langchain-core','pytest','pytest-asyncio','uvicorn','langchain','openai']})"
```

As nove bibliotecas listadas na tabela inicial tiveram as mesmas versões no
ambiente 3.11. Também foram observados `langchain=1.4.3` e `openai=3.20.0` nesse
ambiente novo. Não foi inferida igualdade de todas as dependências entre as
duas venvs nem equivalência com a imagem corporativa 3.11.6.

Os 20 testes direcionados fazem parte dos 155 aprovados em T05. Nenhum código
precisou ser corrigido entre T04 e T05: os 40 erros foram de permissão de setup,
não falhas de assertions funcionais. O sucesso posterior não apaga essa tentativa.

Ao final, a pasta temporária foi removida após conferir seu caminho absoluto
exato e o encerramento dos processos de instalação/startup identificados.
`Test-Path` confirmou sua ausência. A `.venv` original foi preservada.
O ambiente removido pode ser recriado pelos comandos desta seção; não continha
dados da aplicação. Se repetir o procedimento, não incluir essa pasta temporária
no contexto do Docker, pois ela não está coberta pela `.dockerignore` atual.

## 5. Rastreabilidade de requisitos e critérios

`ATENDIDO` abaixo significa atendido no escopo local observado/testado da Fase 01,
nunca aceite integral da futura V2 ou da implantação corporativa.

| Requisito | Classificação | Evidência / limite | CA relacionado e situação |
|---|---|---|---|
| RF-001 | ATENDIDO | Middleware antes do grafo, bloqueios com zero LLM e sem compilação | CA-001 confirmado no baseline |
| RF-014 | ATENDIDO | Request/response/session_id/campo tool_calls_made preservados | CA-028 parcial: valor não é sempre zero |
| INT-001 | ATENDIDO | Schemas e caminho HTTP controlado | CA-028 parcial pela semântica V2 |
| RNF-003 | PARCIALMENTE ATENDIDO | Campos compatíveis; zero obrigatório V2 ainda ausente | CA-028 parcial |
| RF-015 | NÃO ABORDADO NESTA FASE | Continua contagem de ToolMessage | CA-028 não fechado |
| RF-016 | ATENDIDO | Endpoints disponíveis via ASGI | CA-032/033/034 confirmados no baseline controlado |
| INT-005 | ATENDIDO | Mesmos 3 endpoints e campos metrics | CA-032/033/034, sem validação no cluster |
| RF-017 | ATENDIDO | Inspeção de compile/invoke + teste de duas requisições | CA-031 confirmado no baseline |
| RNF-002 | ATENDIDO | Nenhum checkpointer/persistência conversacional observado | CA-031 |
| RF-020 | PARCIALMENTE ATENDIDO | Checa config/grafo localmente; não valida parâmetros novos do RAG | CA-033 baseline OK, target parcial |
| RNF-004 | ATENDIDO | Liveness local, inclusive com get_config falhando | CA-032 |
| RNF-005 | ATENDIDO | Handler readiness sem request externo nos testes | CA-033; não equivale a saúde remota |
| RNF-009 | PARCIALMENTE ATENDIDO | Manifests locais 3.11 e 155 testes aprovados em 3.11.9; imagem ativa não verificada | CA-035 local confirmado, corporativo pendente |
| RN-012 | ATENDIDO | Timeouts explicitamente técnicos | CA-030 |
| RNF-008 | PARCIALMENTE ATENDIDO | RAG/Safe configuráveis; timeout LLM não exposto explicitamente | CA-030 respeitado, sem inventar SLO |
| RN-001 | PARCIALMENTE ATENDIDO | Guardrails precedem baseline; Scope Gate ainda inexistente | CA-001 baseline, CA-002 futuro |
| RF-012 | PARCIALMENTE ATENDIDO | Saída normal protegida; fast-exits V2 ainda ausentes | CA-025 futuro |
| RNF-006 | NÃO ABORDADO NESTA FASE | Riscos de session_id, details e content recording documentados, sem correção | Aceite de privacidade pendente |
| RF-018 / INT-006 | NÃO ABORDADO NESTA FASE | Span explícito RAG ausente | CA-023 futuro |

RF-002 a RF-011, RF-013, RF-019; RN-002 a RN-011, RN-013 a RN-015;
INT-002 a INT-004; RNF-001, RNF-007, RNF-010 a RNF-012: **NÃO ABORDADO NESTA
FASE** para implementação/aceite V2. Inspeções de partes já existentes não fecham
esses requisitos. Não introduzir dependências opcionais continua sendo restrição
respeitada, embora o baseline já tenha MCP.

CA-002 a CA-027, CA-029 e CA-036 não são declarados atendidos nesta fase.
CA-030 e CA-031 foram preservados; CA-035 depende também do runtime corporativo.

## 6. Gates e divergências

| Gate | Estado | Evidência necessária | Efeito nesta fase |
|---|---|---|---|
| GATE-001 | ABERTO | Schema/payload real sanitizado, fixture e parser explícito | Não bloqueia caracterização local; parser definitivo BLOQUEADO POR GATE |
| GATE-002 | ABERTO | Prompt aprovado pelo negócio | Não bloqueia testes com resposta sintética |
| GATE-003 | ABERTO | Taxonomia/versionamento/corpus da política de educação financeira | Nenhuma política inventada |
| GATE-004 | ABERTO | Três textos negociais finais aprovados | Nenhum texto final inventado |

Os gates bloqueiam aceite formal/promoção produtiva da instância, não proíbem
validação não produtiva. Falta de chave local é falha de ambiente, não um novo
GATE normativo inventado.

Divergências conhecidas, com destino posterior explícito:

1. Grafo LLM-first/Tool Calling; AgentState só messages; sem Scope Gate nem os
   três fast-exits. Não antecipar ativação final, reservada à Fase 05 do plano
   de macroetapas fornecido pelo usuário.
2. Contagem de ToolMessage ainda pode ser >0; CA-028 V2 permanece parcial.
3. Parser heurístico existente contraria V2; depende do GATE-001, não corrigido.
4. RAGResult/RAGResponse/index_id já existem nesta cópia, apesar do estado
   histórico documentado. A próxima fase deve inspecionar/reaproveitar, não duplicar.
5. YAML usa core mas default do loader usa agent; índice/identificadores vazios;
   wrapper Tool oculta a distinção NO_CONTEXT/INFRA_ERROR.
6. MCP já está configurado e participa do startup; incompatível com o alvo A0,
   preservado somente como baseline nesta etapa.
7. Runtime da `.venv` é 3.13.5; manifests locais já 3.11. Validação adicional
   passou em ambiente isolado 3.11.9. Publicação de imagem, runtime corporativo
   e execução efetiva da esteira não foram validados.
8. 500 em tipos inválidos antes de Pydantic; ausência de handler global JSON.
9. Readiness não valida índice/chave; 200 local não prova saúde de Genera/LLM.
10. Logs/session_id/content recording e ausência do span HTTP explícito exigem
    trabalho posterior; exporter não exercitado nesta sessão.
11. Prompt/YAML ainda falam de funcionalidades do App e Tool; não comprovam
    aprovação do domínio de educação financeira.
12. Numeração: a arquitetura §51 tem 11 passos; os prompts atuais usam outra
    divisão. O prompt desta tarefa define a Fase 01 e adia ativação à Fase 05.
    `prompts/prompt_fase_02.md` identifica a próxima macroetapa como "Tipos,
    estado e configuração da V2"; ela não foi executada.

## 7. Aplicabilidade, instalação e migração

| Ambiente | Classificação | Procedimento e limite |
|---|---|---|
| Local/WSL | OBRIGATÓRIO | Executar baseline/testes; evidência obtida em Windows, WSL não executado |
| Pegwin | APLICÁVEL | Repetir instalação/testes se houver shell POSIX e Python 3.11; ambiente não acessado |
| OpenShift | RECOMENDADO | Validar imagem/runtime/startup/probes em ambiente autorizado; não há alteração de produção a migrar nesta fase |

**Migração isolada da Fase 01: NÃO NECESSÁRIA.** Entregáveis são testes e memória;
não há correção de runtime para promover. Isso não autoriza release do baseline
atual nem implica que ele seja a implementação final V2.

Procedimento copiável WSL; também utilizável em Pegwin somente se ele disponibilizar
shell POSIX/Python 3.11. Substituir o diretório pelo local real dessa cópia:

```bash
cd "<DIRETORIO_DO_WORKSPACE>/iaa-agent-mf-edu-fin-main"
python3.11 -m venv .venv-fase01-311
.venv-fase01-311/bin/python -m pip install -r requirements.txt pytest pytest-asyncio
.venv-fase01-311/bin/python -m pip check
.venv-fase01-311/bin/python -c "import sys; import iaa_agent_mf_edu_fin as p; from iaa_agent_mf_edu_fin.app import app; print(sys.version); print(p.__file__); print(p.__version__)"
.venv-fase01-311/bin/python -m pytest -q -p no:cacheprovider
```

Instalação do package/extras declarada no projeto, **NÃO EXECUTADA** nesta fase:

```bash
.venv-fase01-311/bin/python -m pip install -e ".[unit,integration]"
```

Rodar na raiz do projeto já torna o package importável; instalar editable não foi
necessário para a suíte. Não sobrescrever uma venv existente sem verificar sua
origem. Para instalação corporativa, usar índice/CA autorizados pelo ambiente;
`pip.conf` do workspace aponta para índice corporativo e certificado relativo,
mas não foi assumido como configuração efetiva do pip local.

Startup POSIX, depois de disponibilizar configuração/credenciais por mecanismo
aprovado (não inserir tokens no documento):

```bash
.venv-fase01-311/bin/python -m iaa_agent_mf_edu_fin --host 127.0.0.1 --port 8080
```

Em outro terminal do mesmo ambiente, com o servidor efetivamente iniciado:

```bash
curl -i http://127.0.0.1:8080/health/live
curl -i http://127.0.0.1:8080/health/ready
curl -i http://127.0.0.1:8080/metrics
```

Para OpenShift, somente diagnóstico de workload já existente e autorizado;
namespace, pod, container e deployment precisam ser informados pelo operador.
Os comandos abaixo não foram executados:

```bash
oc -n "<NAMESPACE>" get deployment "<DEPLOYMENT>" -o yaml
oc -n "<NAMESPACE>" get pod "<POD>" -o jsonpath='{.status.containerStatuses[*].imageID}'
oc -n "<NAMESPACE>" logs "<POD>" -c "<CONTAINER>" --tail=100
oc -n "<NAMESPACE>" exec "<POD>" -c "<CONTAINER>" -- /app/.venv/bin/python --version
oc -n "<NAMESPACE>" port-forward "pod/<POD>" 18081:8080
```

Com o port-forward ativo, em outro terminal:

```bash
curl -i http://127.0.0.1:18081/health/live
curl -i http://127.0.0.1:18081/health/ready
curl -i http://127.0.0.1:18081/metrics
```

O caminho `/app/.venv/bin/python` vem do Dockerfile observado; confirmar se a
imagem ativa corresponde a ele. Logs podem conter session_id/dados internos;
sanitizar antes de compartilhar. Nenhum `oc apply/delete/patch/scale` ou mudança
de Secret/ConfigMap/Deployment foi preparado/executado. Alterações corporativas
exigem autorização explícita. LLM/RAG reais permanecem NÃO EXECUTADO.

## 8. Rollback

Não houve alteração em arquivo de produção; não é necessário reverter runtime.
Para desfazer somente esta fase, retirar o novo arquivo de testes e arquivar
`etapa_01.md`, após confirmar que não receberam trabalho posterior. Essa reversão
dos entregáveis não foi executada. A pasta gerada `.venv-fase01-311` já foi
removida como limpeza do ambiente temporário, após validar seu caminho e o fim
dos processos da validação. Não remover `.venv`, configurações ou mudanças anteriores.

Não se presume Git, snapshot, backup nem `oc rollout undo`. Não há rollback de
cluster nesta entrega. Artefatos de teste podem ser recriados pelos comandos
registrados, enquanto o histórico das evidências deve ser preservado.

## 9. Auditoria final e próxima fase

Pendências antes de declarar execução real: chave/configuração autorizadas do
Gateway, startup completo e imagem corporativa efetiva; RAG real com
identificação/índice e gates da instância nas fases correspondentes.
Python 3.11 foi testado localmente, mas não dentro da imagem corporativa.

A comparação SHA-256 realizada após a criação dos entregáveis encontrou
**88 arquivos originais inalterados**, zero removidos e somente dois novos:
esta memória e `tests/unit/test_baseline_fase01.py`. A comparação excluiu venvs,
`__pycache__` e `.pytest_cache`. Incluiu os documentos normativos, código,
configuração e CI/CD. Depois dessa comparação, somente esta memória recebeu
os resultados finais; o ambiente temporário foi removido. Na retomada, o hash
do novo teste continuava
`B8AEB4C77F8ED75900CE86210A4B20D629C30BB03813C3D05148469FEBB1ED53`.

A auditoria confrontou implementação, SRS, arquitetura e prompt da Fase 01.
Não há memória anterior. As divergências estão enumeradas na seção 6;
nenhuma delas foi convertida silenciosamente em aceite V2. O estado funcional
final é o mesmo baseline recebido, agora com caracterização reproduzível.

```text
FASE 01 — Baseline executável e contratos preservados

Implementação: OK
Validação local: FALHOU
Pronta para migração: NÃO
Validação corporativa: NÃO EXECUTADA
Gates relacionados: ABERTOS
```

`Implementação: OK` refere-se ao levantamento, testes e memória exigidos nesta
fase. `Validação local: FALHOU` agrega a tentativa de startup real sem chave;
a classificação causal dessa ocorrência é `BLOQUEADO POR AMBIENTE`: a falha
decorreu da ausência de credencial/configuração corporativa e não comprova uma
falha equivalente no ambiente corporativo. Isso não significa falha na suíte:
155 testes passaram em cada um dos runtimes 3.13.5 e 3.11.9, incluindo startup
controlado com doubles. `Pronta para migração: NÃO` indica que não há implantação
real validada; migração isolada destes entregáveis é **NÃO NECESSÁRIA**, pois não
houve mudança de produção.

**ETAPA 01 BLOQUEADA — EXISTEM CRITÉRIOS PENDENTES PARA STARTUP REAL.**
O levantamento e os testes controlados estão concluídos. Para remover essa
pendência operacional, executar startup com a chave/configuração autorizadas
e registrar o resultado, sem solicitar ou gravar secrets nesta memória.
Os gates da V2 continuam abertos e não foram usados para bloquear estes testes.

Próxima fase: 02 — Tipos, estado e configuração da V2, conforme prompt próprio.
Não iniciada. A Fase 01 não adicionou nem ativou topologia futura.
