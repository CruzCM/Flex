# PROMPT — IMPLEMENTAÇÃO DA FASE 08

## Identificação

**Fase:** 08  
**Nome:** Fechamento dos gates da instância de educação financeira  
**Objetivo principal:** executar exclusivamente esta macroetapa da implementação A0 Informacional V2.  
**Risco:** alto e dependente de evidência externa; esta fase não pode fabricar insumos  
**Etapa anterior:** `etapa_07.md`

> Este prompt deve ser executado isoladamente. Não avance para a fase seguinte.


## Fontes obrigatórias e ordem de autoridade

Antes de alterar qualquer arquivo, leia integralmente e trate como fontes de verdade, nesta ordem:

1. `especificacao_requisitos_a0_versao2.md` — fonte normativa para implementação, testes e aceite.
2. `plano_arquitetura_a0_versao2.md` — fonte das decisões, invariantes, restrições e justificativas arquiteturais.
3. ``etapa_07.md`` — estado validado herdado da fase anterior, quando existir.
4. Código-fonte, testes, configuração, pipeline e documentação do workspace — baseline observado.
5. Decisões técnicas estritamente necessárias para implementar esta fase.

`especificacao_requisitos_a0_versao2.md` e `plano_arquitetura_a0_versao2.md` são **read-only**. Não os altere.

O código atual é baseline, não target. Não preserve automaticamente comportamento legado contrário à V2. Se houver conflito entre baseline e SRS/arquitetura, registre a divergência e implemente o target normativo. Se a divergência impedir uma implementação segura, pare somente a decisão afetada, apresente evidência e não modifique os documentos normativos para acomodar o código.

Quando uma conclusão vier apenas do código atual, identifique-a como `BASELINE OBSERVADO`. Quando for decisão de implementação e não requisito, identifique-a como `DECISÃO TÉCNICA`.



## Invariantes do target V2 que esta fase não pode contradizer

A sequência abaixo é o **estado final alvo**, não uma afirmação de que todas as etapas já existem nesta fase:

```text
Guardrails de entrada
→ Scope Gate determinístico
→ RAG para toda entrada não rejeitada por escopo
→ LLM somente em SUCCESS com chunks
→ validators pós-LLM quando houver geração
→ Guardrails de saída
```

Nas Fases 1 a 4, preserve o baseline executável enquanto prepara componentes do target; **não antecipe a ativação da topologia completa**, reservada à Fase 5. Nenhuma alteração intermediária pode criar uma direção incompatível com os invariantes finais.

Regras obrigatórias do estado final:

- `OUT_OF_SCOPE` não chama RAG nem LLM.
- `IN_SCOPE` segue para RAG.
- `UNDETERMINED` segue para RAG.
- `NO_CONTEXT` não chama LLM.
- `INFRA_ERROR` não chama LLM.
- RAG é fonte factual; o LLM não preenche lacunas documentais com conhecimento externo.
- `context_precision` é observacional e fail-open; score baixo não altera o roteamento.
- Tool Calling não decide se o RAG será consultado no A0 V2.
- `tool_calls_made` permanece no contrato e vale `0` no A0 V2.
- O A0 permanece stateless nesta entrega.
- MCP, memória, cache, retry e streaming não devem ser introduzidos sem decisão adicional.
- Nenhum SLO quantitativo deve ser inventado.
- Não invente schema de `retrieved_contexts`, taxonomia de educação financeira, prompt final nem textos negociais finais.



### Gates e critérios prioritários

- `GATE-001` — schema real de `retrieved_contexts`.
- `GATE-002` — prompt final aprovado.
- `GATE-003` — ScopePolicy/taxonomia de educação financeira aprovada.
- `GATE-004` — três mensagens finais aprovadas.
- `CA-029` depende de GATE-001.
- `CA-036` deve continuar válido: a taxonomia pertence à instância, não ao template.
- Revalidar `RF-009`, `RF-013`, `RN-006`, `RN-010`, `RN-014`, `RN-015`.



## Disciplina de execução

Implemente **somente esta fase**.

Antes de editar, apresente resumidamente:

1. arquivos/componentes relevantes encontrados;
2. estado atual observado;
3. diferenças para o target desta fase;
4. arquivos que pretende criar/modificar/remover;
5. riscos;
6. requisitos/CA/GATE relacionados;
7. o que ficará deliberadamente para fases posteriores.

Prefira mudanças pequenas, portáveis, testáveis e reversíveis. Não faça refatorações oportunistas.

Se uma preparação para uma fase futura for estritamente necessária, implemente somente a estrutura mínima, deixe-a inativa quando aplicável e registre claramente que ela não satisfaz antecipadamente a fase futura.

Não invente resultado de comando, teste, endpoint, log, payload ou ambiente.



## Escopo específico da Fase 8

Esta fase **não cria conteúdo de negócio**. Ela integra e valida evidências aprovadas fornecidas externamente.

Trate cada gate de forma independente.

### 8.1 GATE-001 — `retrieved_contexts`

Só fechar se houver:
- payload real obtido de ambiente autorizado;
- payload sanitizado;
- schema interno identificável;
- evidência de que corresponde ao contrato atual `/gateway/core`.

Então:
1. documentar o schema na memória da etapa;
2. criar fixture raw sanitizada;
3. implementar parser explícito;
4. normalizar para `list[str]`;
5. testar `SUCCESS`, `NO_CONTEXT` e formato inválido;
6. fechar `CA-029`.

Não adicionar cascata heurística de campos.

### 8.2 GATE-002 — prompt final

Só integrar texto que tenha sido explicitamente fornecido/aprovado.
- preservar grounding exclusivo no RAG;
- não enfraquecer as invariantes do SRS;
- registrar versão/origem da aprovação quando disponível.

Se não houver aprovação: `BLOQUEADO POR GATE`.

### 8.3 GATE-003 — ScopePolicy educação financeira

Só implementar regras concretas se houver taxonomia/regras/corpus aprovados.
- versionar;
- criar testes de `IN_SCOPE`, `OUT_OF_SCOPE`, `UNDETERMINED`;
- manter política no perfil da instância, nunca no node genérico;
- não converter caso fronteiriço em bloqueio por palpite.

Se os insumos forem incompletos, não preencher lacunas.

### 8.4 GATE-004 — mensagens finais

Só configurar os três textos se forem explicitamente aprovados:
- OUT_OF_SCOPE;
- NO_CONTEXT;
- INFRA_ERROR.

Validar distinção, segurança e ausência de detalhe técnico.

### Regra de fechamento

Para cada gate, registre:
- evidência recebida;
- origem;
- artefato incorporado;
- testes;
- status `OPEN/CLOSED`.

Mocks, exemplos, respostas do modelo ou fixtures inventadas nunca fecham gate.



## Fora do escopo da Fase 8

Não:

- inventar qualquer evidência que falte;
- redesenhar o template;
- alterar as quatro fronteiras da arquitetura;
- expandir domínio de educação financeira por conta própria;
- criar novo SLO;
- resolver divergência corporativa sem acesso/evidência;
- considerar deploy em homologação como aprovação negocial automática.



## Validação obrigatória

Após implementar, execute tudo que for possível no ambiente atual.

Registre separadamente:

### Build/importação
- comando;
- esperado;
- obtido;
- status.

### Testes automatizados
- comando;
- quantidade quando disponível;
- aprovados;
- falhos;
- status.

### Testes direcionados desta fase
Para cada teste:
- objetivo;
- entrada/double utilizado;
- comando;
- esperado;
- obtido;
- status.

### Regressão relevante
Execute os testes necessários para demonstrar que contratos que deveriam permanecer não foram quebrados.

Status permitidos:

```text
OK
FALHOU
NÃO EXECUTADO
BLOQUEADO POR GATE
```

Nunca marque `OK` sem evidência.



## Validações específicas

Quando cada gate puder ser fechado:

### GATE-001
- parser contra fixture real sanitizada;
- itens válidos → chunks normalizados;
- vazio → `NO_CONTEXT`;
- formato incompatível → `INFRA_ERROR`/erro técnico conforme contrato;
- nenhuma heurística silenciosa.

### GATE-002
- prompt carregado da fonte/configuração prevista;
- grounding preservado;
- testes de que LLM só recebe contexto em `SUCCESS`.

### GATE-003
- corpus aprovado cobre casos dentro/fora/fronteira;
- determinismo para mesma versão;
- fronteira retorna `UNDETERMINED` quando assim definido;
- template continua reutilizável.

### GATE-004
- três chaves preenchidas;
- mensagens distintas;
- fast-exits corretos;
- guardrails de saída preservados;
- nenhum detalhe técnico exposto.

Se um gate não possuir evidência, não tente “terminar” a fase artificialmente: registre-o como aberto e deixe a Fase 9 bloqueada para aceite de produção.



## Aplicabilidade por ambiente

Ao final, classifique:

| Ambiente | Classificação permitida |
|---|---|
| Local/WSL | `OBRIGATÓRIO`, `APLICÁVEL`, `NÃO APLICÁVEL` |
| Pegwin | `APLICÁVEL`, `MESMO PROCEDIMENTO DO WSL`, `NÃO APLICÁVEL` |
| OpenShift | `OBRIGATÓRIO`, `RECOMENDADO`, `NÃO NECESSÁRIO`, `BLOQUEADO POR GATE` |

Só forneça comandos específicos quando houver valor real de validação.

Para WSL/Pegwin/OpenShift:
- use comandos copiáveis;
- descubra o diretório/package/comandos reais no workspace antes de escrevê-los;
- use placeholders para valores corporativos desconhecidos;
- não invente namespaces, deployments, routes, registries, URLs internas, tokens ou secrets.

Não execute automaticamente operações mutáveis/destrutivas em infraestrutura corporativa (`oc apply`, `oc delete`, `oc patch`, `oc scale`, alterações de Secret/ConfigMap/Deployment etc.). Pode preparar os comandos, mas marque que exigem autorização explícita.

O arquivo de memória da fase é a fonte canônica dos comandos. Se os repetir na resposta, reproduza exatamente os mesmos comandos.


### Classificação esperada de migração desta fase

`OBRIGATÓRIA` para evidências que dependem do ambiente corporativo (especialmente GATE-001) e para validação final da instância; aprovações negociais continuam externas ao código.


## Rollback

Defina como retornar ao estado anterior desta fase.

- Prefira rollback por código/configuração versionada.
- Não suponha disponibilidade de Git, snapshot, backup ou `oc rollout undo` sem evidência.
- Se depender de ambiente corporativo, use placeholders e indique exatamente o que precisa ser conhecido.



## Arquivo obrigatório de memória

Ao final, crie `etapa_08.md`.

Ele deve ser autossuficiente e conter:

1. identificação da fase;
2. documentos utilizados;
3. requisitos `RF/RN/INT/RNF` abordados;
4. critérios `CA` relacionados;
5. `GATE` relacionados;
6. estado antes da fase;
7. arquivos criados/modificados/removidos;
8. resumo do diff;
9. decisões técnicas tomadas;
10. decisões arquiteturais preservadas;
11. decisões explicitamente **não** tomadas;
12. validações executadas;
13. resultados `OK/FALHOU/NÃO EXECUTADO/BLOQUEADO POR GATE`;
14. problemas e limitações;
15. pendências;
16. divergências entre código e SRS/arquitetura;
17. estado final do sistema;
18. aplicabilidade e procedimento de migração corporativa;
19. rollback;
20. próxima fase, sem executá-la.

Também registre a rastreabilidade de cada requisito desta fase como:
`ATENDIDO`, `PARCIALMENTE ATENDIDO`, `NÃO ABORDADO NESTA FASE` ou `BLOQUEADO POR GATE`.



## Auditoria final e regra de parada

Antes de encerrar, compare:

```text
implementação realizada
↔ especificacao_requisitos_a0_versao2.md
↔ plano_arquitetura_a0_versao2.md
↔ memória da etapa anterior
↔ requisitos desta fase
↔ critérios de aceite desta fase
```

Liste qualquer divergência conhecida.

Apresente o quadro final:

```text
FASE 08 — Fechamento dos gates da instância de educação financeira

Implementação: OK / PARCIAL / FALHOU
Validação local: OK / FALHOU / NÃO EXECUTADA
Pronta para migração: SIM / NÃO
Validação corporativa: OK / FALHOU / NÃO EXECUTADA
Gates relacionados: ABERTOS / FECHADOS / N/A
```

Finalize com uma condição coerente, por exemplo:

- `ETAPA 08 PRONTA PARA MIGRAÇÃO/VALIDAÇÃO CORPORATIVA`
- `ETAPA 08 BLOQUEADA — EXISTEM CRITÉRIOS PENDENTES`
- `ETAPA 08 VALIDADA LOCALMENTE — MIGRAÇÃO ISOLADA NÃO NECESSÁRIA`

Depois **PARE**. Não implemente a Fase 09.

