# Prompts de implementação — A0 Informacional V2

Estes arquivos devem ser executados **um de cada vez**, na ordem:

1. `prompt_fase_01.md` — Baseline executável e contratos preservados
2. `prompt_fase_02.md` — Tipos, estado e configuração da V2
3. `prompt_fase_03.md` — ScopePolicy e Scope Gate
4. `prompt_fase_04.md` — Adaptador RAG V2
5. `prompt_fase_05.md` — Refatoração da topologia LangGraph
6. `prompt_fase_06.md` — Validators, guardrails e respostas funcionais
7. `prompt_fase_07.md` — Compatibilidade operacional e observabilidade
8. `prompt_fase_08.md` — Fechamento dos gates da instância
9. `prompt_fase_09.md` — Regressão completa e aceite

Em toda fase, disponibilize no workspace:

- `especificacao_requisitos_a0_versao2.md`;
- `plano_arquitetura_a0_versao2.md`;
- o código atualizado;
- `etapa_<N-1>.md` a partir da Fase 2.

A fase deve gerar `etapa_<N>.md` e parar. Não envie os nove prompts ao implementador de uma vez.
