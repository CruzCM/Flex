# PROMPT — IMPLEMENTAÇÃO DA FASE 05

## Identificação

**Fase:** 05  
**Nome:** Refatoração da topologia LangGraph  
**Objetivo principal:** executar exclusivamente esta macroetapa da implementação A0 Informacional V2.  
**Risco:** muito alto; esta é a principal mudança estrutural do projeto  
**Etapa anterior:** `etapa_04.md`

> Este prompt deve ser executado isoladamente. Não avance para a fase seguinte.


## Fontes obrigatórias e ordem de autoridade

Antes de alterar qualquer arquivo, leia integralmente e trate como fontes de verdade, nesta ordem:

1. `especificacao_requisitos_a0_versao2.md` — fonte normativa para implementação, testes e aceite.
2. `plano_arquitetura_a0_versao2.md` — fonte das decisões, invariantes, restrições e justificativas arquiteturais.
3. ``etapa_04.md`` — estado validado herdado da fase anterior, quando existir.
4. Código-fonte, testes, configuração, pipeline e documentação do workspace — baseline observado.
5. Decisões técnicas estritamente necessárias para implementar esta fase.

`especificacao_requisitos_a0_versao2.md` e `plano_arquitetura_a0_versao2.md` são **read-only**. Não os altere.

O código atual é baseline, não target. Não preserve automaticamente comportamento legado contrário à V2. Se houver conflito entre baseline e SRS/arquitetura, registre a divergência e implemente o target normativo. Se a divergência impedir uma implementação segura, pare somente a decisão afetada, apresente evidência e não modifique os documentos normativos para acomodar o código.

Quando uma conclusão vier apenas do código atual, identifique-a como `BASELINE OBSERVADO`. Quando for decisão de implementação e não requisito, identifique-a como `DECISÃO TÉCNICA`.



## Invariantes do target V2 que esta fase não pode contradizer

A sequência abaixo é o **estado final alvo**, não uma afirmação de que todas as etapas já existem nesta fase:

```text
Guardrails de entrada
→ Scope Gate determinístico
→ RAG para toda entrada não rejeitada por escopo
→ LLM somente em SUCCESS com chunks
→ validators pós-LLM quando houver geração
→ Guardrails de saída
```

Nas Fases 1 a 4, preserve o baseline executável enquanto prepara componentes do target; **não antecipe a ativação da topologia completa**, reservada à Fase 5. Nenhuma alteração intermediária pode criar uma direção incompatível com os invariantes finais.

Regras obrigatórias do estado final:

- `OUT_OF_SCOPE` não chama RAG nem LLM.
- `IN_SCOPE` segue para RAG.
- `UNDETERMINED` segue para RAG.
- `NO_CONTEXT` não chama LLM.
- `INFRA_ERROR` não chama LLM.
- RAG é fonte factual; o LLM não preenche lacunas documentais com conhecimento externo.
- `context_precision` é observacional e fail-open; score baixo não altera o roteamento.
- Tool Calling não decide se o RAG será consultado no A0 V2.
- `tool_calls_made` permanece no contrato e vale `0` no A0 V2.
- O A0 permanece stateless nesta entrega.
- MCP, memória, cache, retry e streaming não devem ser introduzidos sem decisão adicional.
- Nenhum SLO quantitativo deve ser inventado.
- Não invente schema de `retrieved_contexts`, taxonomia de educação financeira, prompt final nem textos negociais finais.



### Requisitos e critérios prioritários

- `RF-002` a `RF-009`.
- `RF-014`, `RF-015`, `RF-017`, `RF-019`.
- `RN-001` a `RN-009`.
- `INT-004`.
- `RNF-002`, `RNF-003`, `RNF-010`, `RNF-012`.
- `CA-002` a `CA-019`, `CA-022`, `CA-028`, `CA-031`, `CA-036`.
- `GATE-001` e `GATE-003` podem continuar abertos; use doubles/configuração conservadora para testes e não os feche.



## Disciplina de execução

Implemente **somente esta fase**.

Antes de editar, apresente resumidamente:

1. arquivos/componentes relevantes encontrados;
2. estado atual observado;
3. diferenças para o target desta fase;
4. arquivos que pretende criar/modificar/remover;
5. riscos;
6. requisitos/CA/GATE relacionados;
7. o que ficará deliberadamente para fases posteriores.

Prefira mudanças pequenas, portáveis, testáveis e reversíveis. Não faça refatorações oportunistas.

Se uma preparação para uma fase futura for estritamente necessária, implemente somente a estrutura mínima, deixe-a inativa quando aplicável e registre claramente que ela não satisfaz antecipadamente a fase futura.

Não invente resultado de comando, teste, endpoint, log, payload ou ambiente.



## Escopo específico da Fase 5

Substituir a topologia A0 baseada em Tool Calling pela topologia determinística da V2.

Target obrigatório:

```text
Guardrails HTTP de entrada
→ scope_gate_node
→ branch por ScopeResult
   OUT_OF_SCOPE → fast-exit
   IN_SCOPE/UNDETERMINED → retrieve_context_node
→ branch por RAGResult
   SUCCESS + chunks → llm_node
   NO_CONTEXT → fast-exit
   INFRA_ERROR → fast-exit
→ validators pós-LLM no caminho de geração
→ Guardrails HTTP de saída
```

Implementar:

1. ligar o `scope_gate_node` ao grafo ativo;
2. adicionar `retrieve_context_node` usando o adaptador da Fase 4;
3. publicar `scope_result`, `rag_context`, `rag_result` no `AgentState`;
4. garantir que apenas `SUCCESS` com pelo menos um chunk chega ao LLM;
5. passar `rag_context` explicitamente ao LLM/prompt;
6. remover do caminho A0:
   - `bind_tools` para RAG;
   - `tools_condition`;
   - `ValidatingToolNode` como executor do RAG;
   - decisão por `AIMessage.tool_calls`;
   - `ToolMessage` como transporte de chunks;
7. preservar componentes genéricos fora do fluxo A0 quando tiverem utilidade para outros perfis; não fazer limpeza global sem necessidade;
8. manter contrato `/chat`;
9. alterar a contagem para `tool_calls_made = 0`, sem ToolMessage fictício;
10. manter stateless;
11. se `GATE-003` estiver aberto, usar somente policy conservadora/double explicitamente não-final em testes/ambiente não produtivo;
12. se `GATE-001` estiver aberto, mocks do grafo devem operar na fronteira `RAGResponse`, não em payload raw inventado.

O projeto deve terminar esta fase com a **nova topologia ativa**, mesmo que os conteúdos específicos da instância ainda estejam bloqueados por gates.



## Fora do escopo da Fase 5

Não:

- fechar taxonomia, prompt, mensagens ou parser real;
- reposicionar/implementar em profundidade `context_precision` além do mínimo necessário para manter o grafo compilável (isso é Fase 6);
- alterar sem necessidade health/metrics;
- adicionar memória;
- apagar infraestrutura genérica de Tool Calling de todo o template;
- adicionar mecanismos transacionais.



## Validação obrigatória

Após implementar, execute tudo que for possível no ambiente atual.

Registre separadamente:

### Build/importação
- comando;
- esperado;
- obtido;
- status.

### Testes automatizados
- comando;
- quantidade quando disponível;
- aprovados;
- falhos;
- status.

### Testes direcionados desta fase
Para cada teste:
- objetivo;
- entrada/double utilizado;
- comando;
- esperado;
- obtido;
- status.

### Regressão relevante
Execute os testes necessários para demonstrar que contratos que deveriam permanecer não foram quebrados.

Status permitidos:

```text
OK
FALHOU
NÃO EXECUTADO
BLOQUEADO POR GATE
```

Nunca marque `OK` sem evidência.



## Validações específicas

Com spies/mocks, provar:

- guardrails HTTP continuam antes do grafo;
- Scope Gate precede RAG;
- `OUT_OF_SCOPE` não chama RAG;
- `OUT_OF_SCOPE` não chama LLM;
- `IN_SCOPE` chama RAG;
- `UNDETERMINED` chama RAG;
- RAG precede LLM;
- `SUCCESS` + chunks chama LLM exatamente uma vez;
- `NO_CONTEXT` não chama LLM;
- `INFRA_ERROR` não chama LLM;
- chunks chegam ao LLM;
- Tool Calling não participa da recuperação;
- `tool_calls_made == 0`;
- `session_id` e schema `/chat` permanecem;
- state possui os canais declarados;
- nenhum checkpointer/memória foi introduzido.

Atualize testes antigos que afirmavam que RAG deveria ser Tool. Não mantenha testes obsoletos apenas para fazer a suíte passar.



## Aplicabilidade por ambiente

Ao final, classifique:

| Ambiente | Classificação permitida |
|---|---|
| Local/WSL | `OBRIGATÓRIO`, `APLICÁVEL`, `NÃO APLICÁVEL` |
| Pegwin | `APLICÁVEL`, `MESMO PROCEDIMENTO DO WSL`, `NÃO APLICÁVEL` |
| OpenShift | `OBRIGATÓRIO`, `RECOMENDADO`, `NÃO NECESSÁRIO`, `BLOQUEADO POR GATE` |

Só forneça comandos específicos quando houver valor real de validação.

Para WSL/Pegwin/OpenShift:
- use comandos copiáveis;
- descubra o diretório/package/comandos reais no workspace antes de escrevê-los;
- use placeholders para valores corporativos desconhecidos;
- não invente namespaces, deployments, routes, registries, URLs internas, tokens ou secrets.

Não execute automaticamente operações mutáveis/destrutivas em infraestrutura corporativa (`oc apply`, `oc delete`, `oc patch`, `oc scale`, alterações de Secret/ConfigMap/Deployment etc.). Pode preparar os comandos, mas marque que exigem autorização explícita.

O arquivo de memória da fase é a fonte canônica dos comandos. Se os repetir na resposta, reproduza exatamente os mesmos comandos.


### Classificação esperada de migração desta fase

`RECOMENDADA` e geralmente um checkpoint importante para validação corporativa, pois muda a topologia central.


## Rollback

Defina como retornar ao estado anterior desta fase.

- Prefira rollback por código/configuração versionada.
- Não suponha disponibilidade de Git, snapshot, backup ou `oc rollout undo` sem evidência.
- Se depender de ambiente corporativo, use placeholders e indique exatamente o que precisa ser conhecido.



## Arquivo obrigatório de memória

Ao final, crie `etapa_05.md`.

Ele deve ser autossuficiente e conter:

1. identificação da fase;
2. documentos utilizados;
3. requisitos `RF/RN/INT/RNF` abordados;
4. critérios `CA` relacionados;
5. `GATE` relacionados;
6. estado antes da fase;
7. arquivos criados/modificados/removidos;
8. resumo do diff;
9. decisões técnicas tomadas;
10. decisões arquiteturais preservadas;
11. decisões explicitamente **não** tomadas;
12. validações executadas;
13. resultados `OK/FALHOU/NÃO EXECUTADO/BLOQUEADO POR GATE`;
14. problemas e limitações;
15. pendências;
16. divergências entre código e SRS/arquitetura;
17. estado final do sistema;
18. aplicabilidade e procedimento de migração corporativa;
19. rollback;
20. próxima fase, sem executá-la.

Também registre a rastreabilidade de cada requisito desta fase como:
`ATENDIDO`, `PARCIALMENTE ATENDIDO`, `NÃO ABORDADO NESTA FASE` ou `BLOQUEADO POR GATE`.



## Auditoria final e regra de parada

Antes de encerrar, compare:

```text
implementação realizada
↔ especificacao_requisitos_a0_versao2.md
↔ plano_arquitetura_a0_versao2.md
↔ memória da etapa anterior
↔ requisitos desta fase
↔ critérios de aceite desta fase
```

Liste qualquer divergência conhecida.

Apresente o quadro final:

```text
FASE 05 — Refatoração da topologia LangGraph

Implementação: OK / PARCIAL / FALHOU
Validação local: OK / FALHOU / NÃO EXECUTADA
Pronta para migração: SIM / NÃO
Validação corporativa: OK / FALHOU / NÃO EXECUTADA
Gates relacionados: ABERTOS / FECHADOS / N/A
```

Finalize com uma condição coerente, por exemplo:

- `ETAPA 05 PRONTA PARA MIGRAÇÃO/VALIDAÇÃO CORPORATIVA`
- `ETAPA 05 BLOQUEADA — EXISTEM CRITÉRIOS PENDENTES`
- `ETAPA 05 VALIDADA LOCALMENTE — MIGRAÇÃO ISOLADA NÃO NECESSÁRIA`

Depois **PARE**. Não implemente a Fase 06.

