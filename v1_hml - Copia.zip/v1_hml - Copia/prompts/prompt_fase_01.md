# PROMPT — IMPLEMENTAÇÃO DA FASE 01

## Identificação

**Fase:** 01  
**Nome:** Baseline executável e contratos preservados  
**Objetivo principal:** executar exclusivamente esta macroetapa da implementação A0 Informacional V2.  
**Risco:** baixo a médio; risco principal é confundir baseline com target ou corrigir legado fora de hora  
**Etapa anterior:** não existe etapa anterior; use o estado inicial do workspace

> Este prompt deve ser executado isoladamente. Não avance para a fase seguinte.


## Fontes obrigatórias e ordem de autoridade

Antes de alterar qualquer arquivo, leia integralmente e trate como fontes de verdade, nesta ordem:

1. `especificacao_requisitos_a0_versao2.md` — fonte normativa para implementação, testes e aceite.
2. `plano_arquitetura_a0_versao2.md` — fonte das decisões, invariantes, restrições e justificativas arquiteturais.
3. `não existe etapa anterior; use o estado inicial do workspace` — estado validado herdado da fase anterior, quando existir.
4. Código-fonte, testes, configuração, pipeline e documentação do workspace — baseline observado.
5. Decisões técnicas estritamente necessárias para implementar esta fase.

`especificacao_requisitos_a0_versao2.md` e `plano_arquitetura_a0_versao2.md` são **read-only**. Não os altere.

O código atual é baseline, não target. Não preserve automaticamente comportamento legado contrário à V2. Se houver conflito entre baseline e SRS/arquitetura, registre a divergência e implemente o target normativo. Se a divergência impedir uma implementação segura, pare somente a decisão afetada, apresente evidência e não modifique os documentos normativos para acomodar o código.

Quando uma conclusão vier apenas do código atual, identifique-a como `BASELINE OBSERVADO`. Quando for decisão de implementação e não requisito, identifique-a como `DECISÃO TÉCNICA`.



## Invariantes do target V2 que esta fase não pode contradizer

A sequência abaixo é o **estado final alvo**, não uma afirmação de que todas as etapas já existem nesta fase:

```text
Guardrails de entrada
→ Scope Gate determinístico
→ RAG para toda entrada não rejeitada por escopo
→ LLM somente em SUCCESS com chunks
→ validators pós-LLM quando houver geração
→ Guardrails de saída
```

Nas Fases 1 a 4, preserve o baseline executável enquanto prepara componentes do target; **não antecipe a ativação da topologia completa**, reservada à Fase 5. Nenhuma alteração intermediária pode criar uma direção incompatível com os invariantes finais.

Regras obrigatórias do estado final:

- `OUT_OF_SCOPE` não chama RAG nem LLM.
- `IN_SCOPE` segue para RAG.
- `UNDETERMINED` segue para RAG.
- `NO_CONTEXT` não chama LLM.
- `INFRA_ERROR` não chama LLM.
- RAG é fonte factual; o LLM não preenche lacunas documentais com conhecimento externo.
- `context_precision` é observacional e fail-open; score baixo não altera o roteamento.
- Tool Calling não decide se o RAG será consultado no A0 V2.
- `tool_calls_made` permanece no contrato e vale `0` no A0 V2.
- O A0 permanece stateless nesta entrega.
- MCP, memória, cache, retry e streaming não devem ser introduzidos sem decisão adicional.
- Nenhum SLO quantitativo deve ser inventado.
- Não invente schema de `retrieved_contexts`, taxonomia de educação financeira, prompt final nem textos negociais finais.



### Requisitos e critérios prioritários

Nesta fase, **não tente satisfazer a nova topologia**. O objetivo é estabelecer evidência confiável do ponto de partida e preservar contratos que a V2 manda manter.

Mapeie e verifique principalmente:

- `RF-001` / `CA-001` — posição e comportamento atual dos guardrails de entrada.
- `RF-014`, `INT-001`, `RNF-003`, `CA-028` — contrato `/chat`.
- `RF-016`, `INT-005`, `CA-032`, `CA-033`, `CA-034` — `/health/live`, `/health/ready`, `/metrics`.
- `RF-017`, `RNF-002`, `CA-031` — stateless.
- `RF-020`, `RNF-005`, `CA-033` — readiness local.
- `RNF-004` — liveness sem dependência externa.
- `RNF-009`, `CA-035` — Python 3.11 como target normativo, distinguindo evidência inconsistente dos manifests ativos.
- `RN-012`, `RNF-008`, `CA-030` — timeout técnico não é SLO.

Nesta fase, esses IDs podem ficar apenas **confirmados no baseline** ou **parcialmente atendidos**. Não declare CA da arquitetura futura como atendido só porque o baseline foi inspecionado.



## Disciplina de execução

Implemente **somente esta fase**.

Antes de editar, apresente resumidamente:

1. arquivos/componentes relevantes encontrados;
2. estado atual observado;
3. diferenças para o target desta fase;
4. arquivos que pretende criar/modificar/remover;
5. riscos;
6. requisitos/CA/GATE relacionados;
7. o que ficará deliberadamente para fases posteriores.

Prefira mudanças pequenas, portáveis, testáveis e reversíveis. Não faça refatorações oportunistas.

Se uma preparação para uma fase futura for estritamente necessária, implemente somente a estrutura mínima, deixe-a inativa quando aplicável e registre claramente que ela não satisfaz antecipadamente a fase futura.

Não invente resultado de comando, teste, endpoint, log, payload ou ambiente.



## Escopo específico da Fase 1

1. Identificar package/entrypoint real desta cópia.
2. Identificar `Dockerfile`, `setup.py`/`pyproject`, `aic.json`, CI e runtime declarado.
3. Registrar qualquer divergência (inclusive Python 3.11 target versus `aic.json` observado).
4. Descobrir e registrar os comandos reais de instalação, importação, startup e pytest.
5. Executar a suíte existente se o ambiente permitir; registrar failures preexistentes.
6. Inspecionar e testar, quando possível:
   - `POST /chat`;
   - `/health/live`;
   - `/health/ready`;
   - `/metrics`.
7. Confirmar schema de `ChatRequest` e `ChatResponse`, inclusive comportamento de validação estrutural; só normatizar `422` se houver evidência.
8. Confirmar limite de entrada, guardrails existentes, tratamento global de exceptions e saída.
9. Registrar topologia LangGraph atual, `AgentState`, uso de Tool Calling, `ToolMessage`, RAG atual e contagem `tool_calls_made`.
10. Confirmar estado atual de logging/tracing e dependências externas.
11. Não alterar `plano_arquitetura_a0_versao2.md` nem `especificacao_requisitos_a0_versao2.md`.

Mudanças de código nesta fase devem ser excepcionais e limitadas a tornar o baseline executável/testável sem mudar comportamento funcional. Qualquer correção necessária deve ser explicitamente justificada.



## Fora do escopo da Fase 1

Não implementar ainda:

- `ScopeResult`, `RAGResult`, `RAGResponse`;
- novo `AgentState`;
- `ScopePolicy` ou `scope_gate_node`;
- `/gateway/core`;
- `index_id`;
- nova topologia;
- três fast-exits;
- repositionamento de validators;
- novas métricas V2;
- parser de `retrieved_contexts`;
- qualquer gate da instância.



## Validação obrigatória

Após implementar, execute tudo que for possível no ambiente atual.

Registre separadamente:

### Build/importação
- comando;
- esperado;
- obtido;
- status.

### Testes automatizados
- comando;
- quantidade quando disponível;
- aprovados;
- falhos;
- status.

### Testes direcionados desta fase
Para cada teste:
- objetivo;
- entrada/double utilizado;
- comando;
- esperado;
- obtido;
- status.

### Regressão relevante
Execute os testes necessários para demonstrar que contratos que deveriam permanecer não foram quebrados.

Status permitidos:

```text
OK
FALHOU
NÃO EXECUTADO
BLOQUEADO POR GATE
```

Nunca marque `OK` sem evidência.



## Validações específicas

No mínimo, tente obter evidência para:

- importação/startup da aplicação;
- suíte atual de testes;
- `GET /health/live`;
- `GET /health/ready`;
- `GET /metrics`;
- schema/validação de `/chat`;
- um caminho controlado de `/chat` se for possível sem depender de segredo externo;
- ausência de persistência/checkpointer;
- package e runtime efetivamente utilizados.

Se serviços externos impedirem `/chat`, registre `NÃO EXECUTADO` ou use doubles somente se já houver padrão de testes no projeto. Não masque falha de ambiente como sucesso funcional.



## Aplicabilidade por ambiente

Ao final, classifique:

| Ambiente | Classificação permitida |
|---|---|
| Local/WSL | `OBRIGATÓRIO`, `APLICÁVEL`, `NÃO APLICÁVEL` |
| Pegwin | `APLICÁVEL`, `MESMO PROCEDIMENTO DO WSL`, `NÃO APLICÁVEL` |
| OpenShift | `OBRIGATÓRIO`, `RECOMENDADO`, `NÃO NECESSÁRIO`, `BLOQUEADO POR GATE` |

Só forneça comandos específicos quando houver valor real de validação.

Para WSL/Pegwin/OpenShift:
- use comandos copiáveis;
- descubra o diretório/package/comandos reais no workspace antes de escrevê-los;
- use placeholders para valores corporativos desconhecidos;
- não invente namespaces, deployments, routes, registries, URLs internas, tokens ou secrets.

Não execute automaticamente operações mutáveis/destrutivas em infraestrutura corporativa (`oc apply`, `oc delete`, `oc patch`, `oc scale`, alterações de Secret/ConfigMap/Deployment etc.). Pode preparar os comandos, mas marque que exigem autorização explícita.

O arquivo de memória da fase é a fonte canônica dos comandos. Se os repetir na resposta, reproduza exatamente os mesmos comandos.


### Classificação esperada de migração desta fase

normalmente `RECOMENDADA` somente se a Fase 1 corrigir algo necessário ao baseline; se for apenas levantamento/validação, pode ser `NÃO NECESSÁRIA`.


## Rollback

Defina como retornar ao estado anterior desta fase.

- Prefira rollback por código/configuração versionada.
- Não suponha disponibilidade de Git, snapshot, backup ou `oc rollout undo` sem evidência.
- Se depender de ambiente corporativo, use placeholders e indique exatamente o que precisa ser conhecido.



## Arquivo obrigatório de memória

Ao final, crie `etapa_01.md`.

Ele deve ser autossuficiente e conter:

1. identificação da fase;
2. documentos utilizados;
3. requisitos `RF/RN/INT/RNF` abordados;
4. critérios `CA` relacionados;
5. `GATE` relacionados;
6. estado antes da fase;
7. arquivos criados/modificados/removidos;
8. resumo do diff;
9. decisões técnicas tomadas;
10. decisões arquiteturais preservadas;
11. decisões explicitamente **não** tomadas;
12. validações executadas;
13. resultados `OK/FALHOU/NÃO EXECUTADO/BLOQUEADO POR GATE`;
14. problemas e limitações;
15. pendências;
16. divergências entre código e SRS/arquitetura;
17. estado final do sistema;
18. aplicabilidade e procedimento de migração corporativa;
19. rollback;
20. próxima fase, sem executá-la.

Também registre a rastreabilidade de cada requisito desta fase como:
`ATENDIDO`, `PARCIALMENTE ATENDIDO`, `NÃO ABORDADO NESTA FASE` ou `BLOQUEADO POR GATE`.



## Auditoria final e regra de parada

Antes de encerrar, compare:

```text
implementação realizada
↔ especificacao_requisitos_a0_versao2.md
↔ plano_arquitetura_a0_versao2.md
↔ memória da etapa anterior
↔ requisitos desta fase
↔ critérios de aceite desta fase
```

Liste qualquer divergência conhecida.

Apresente o quadro final:

```text
FASE 01 — Baseline executável e contratos preservados

Implementação: OK / PARCIAL / FALHOU
Validação local: OK / FALHOU / NÃO EXECUTADA
Pronta para migração: SIM / NÃO
Validação corporativa: OK / FALHOU / NÃO EXECUTADA
Gates relacionados: ABERTOS / FECHADOS / N/A
```

Finalize com uma condição coerente, por exemplo:

- `ETAPA 01 PRONTA PARA MIGRAÇÃO/VALIDAÇÃO CORPORATIVA`
- `ETAPA 01 BLOQUEADA — EXISTEM CRITÉRIOS PENDENTES`
- `ETAPA 01 VALIDADA LOCALMENTE — MIGRAÇÃO ISOLADA NÃO NECESSÁRIA`

Depois **PARE**. Não implemente a Fase 02.

