# PROMPT — IMPLEMENTAÇÃO DA FASE 06

## Identificação

**Fase:** 06  
**Nome:** Validators, guardrails e respostas funcionais  
**Objetivo principal:** executar exclusivamente esta macroetapa da implementação A0 Informacional V2.  
**Risco:** alto; consolida fast-exits e segurança de saída sem poder inventar textos negociais  
**Etapa anterior:** `etapa_05.md`

> Este prompt deve ser executado isoladamente. Não avance para a fase seguinte.


## Fontes obrigatórias e ordem de autoridade

Antes de alterar qualquer arquivo, leia integralmente e trate como fontes de verdade, nesta ordem:

1. `especificacao_requisitos_a0_versao2.md` — fonte normativa para implementação, testes e aceite.
2. `plano_arquitetura_a0_versao2.md` — fonte das decisões, invariantes, restrições e justificativas arquiteturais.
3. ``etapa_05.md`` — estado validado herdado da fase anterior, quando existir.
4. Código-fonte, testes, configuração, pipeline e documentação do workspace — baseline observado.
5. Decisões técnicas estritamente necessárias para implementar esta fase.

`especificacao_requisitos_a0_versao2.md` e `plano_arquitetura_a0_versao2.md` são **read-only**. Não os altere.

O código atual é baseline, não target. Não preserve automaticamente comportamento legado contrário à V2. Se houver conflito entre baseline e SRS/arquitetura, registre a divergência e implemente o target normativo. Se a divergência impedir uma implementação segura, pare somente a decisão afetada, apresente evidência e não modifique os documentos normativos para acomodar o código.

Quando uma conclusão vier apenas do código atual, identifique-a como `BASELINE OBSERVADO`. Quando for decisão de implementação e não requisito, identifique-a como `DECISÃO TÉCNICA`.



## Invariantes do target V2 que esta fase não pode contradizer

A sequência abaixo é o **estado final alvo**, não uma afirmação de que todas as etapas já existem nesta fase:

```text
Guardrails de entrada
→ Scope Gate determinístico
→ RAG para toda entrada não rejeitada por escopo
→ LLM somente em SUCCESS com chunks
→ validators pós-LLM quando houver geração
→ Guardrails de saída
```

Nas Fases 1 a 4, preserve o baseline executável enquanto prepara componentes do target; **não antecipe a ativação da topologia completa**, reservada à Fase 5. Nenhuma alteração intermediária pode criar uma direção incompatível com os invariantes finais.

Regras obrigatórias do estado final:

- `OUT_OF_SCOPE` não chama RAG nem LLM.
- `IN_SCOPE` segue para RAG.
- `UNDETERMINED` segue para RAG.
- `NO_CONTEXT` não chama LLM.
- `INFRA_ERROR` não chama LLM.
- RAG é fonte factual; o LLM não preenche lacunas documentais com conhecimento externo.
- `context_precision` é observacional e fail-open; score baixo não altera o roteamento.
- Tool Calling não decide se o RAG será consultado no A0 V2.
- `tool_calls_made` permanece no contrato e vale `0` no A0 V2.
- O A0 permanece stateless nesta entrega.
- MCP, memória, cache, retry e streaming não devem ser introduzidos sem decisão adicional.
- Nenhum SLO quantitativo deve ser inventado.
- Não invente schema de `retrieved_contexts`, taxonomia de educação financeira, prompt final nem textos negociais finais.



### Requisitos e critérios prioritários

- `RF-010`, `RF-011`, `RF-012`, `RF-013`.
- `INT-002`.
- `RN-005`, `RN-006`, `RN-007`, `RN-010`, `RN-011`.
- `RNF-006`, `RNF-007`.
- `CA-017` a `CA-021`, `CA-024`, `CA-025`, `CA-026`, `CA-027`.
- `GATE-004` permanece aberto até textos aprovados.
- `GATE-002` permanece aberto até prompt final aprovado.



## Disciplina de execução

Implemente **somente esta fase**.

Antes de editar, apresente resumidamente:

1. arquivos/componentes relevantes encontrados;
2. estado atual observado;
3. diferenças para o target desta fase;
4. arquivos que pretende criar/modificar/remover;
5. riscos;
6. requisitos/CA/GATE relacionados;
7. o que ficará deliberadamente para fases posteriores.

Prefira mudanças pequenas, portáveis, testáveis e reversíveis. Não faça refatorações oportunistas.

Se uma preparação para uma fase futura for estritamente necessária, implemente somente a estrutura mínima, deixe-a inativa quando aplicável e registre claramente que ela não satisfaz antecipadamente a fase futura.

Não invente resultado de comando, teste, endpoint, log, payload ou ambiente.



## Escopo específico da Fase 6

1. Localizar a implementação real de validators no workspace.
2. Implementar/ativar `context_precision` conforme o target da V2:
   - executa somente quando existem chunks;
   - recebe query + chunks;
   - é observacional;
   - é fail-open;
   - score baixo não muda `RAGResult` nem branch.
3. Se `context_precision` já existir, reposicioná-lo do fluxo de Tool para o fluxo após recuperação.
4. Se não existir nesta base, implementar somente o contrato necessário definido por SRS/arquitetura, reutilizando padrões existentes; não importar infraestrutura antiga desnecessária.
5. Garantir validators pós-LLM exigidos pelo target no caminho de geração. Verifique o que realmente existe antes de assumir nomes/componentes.
6. `tool_correctness`:
   - se existir no template, preservar;
   - não executar no A0;
   - se não existir na base ativa, não criá-lo apenas para deixá-lo inativo.
7. Garantir que os três fast-exits passem pelo middleware/guardrails de saída:
   - OUT_OF_SCOPE;
   - NO_CONTEXT;
   - INFRA_ERROR.
8. Usar as três chaves independentes de configuração criadas na Fase 2.
9. Enquanto `GATE-004` estiver aberto, **não commitar textos negociais inventados como finais**. Testes podem injetar strings controladas distintas.
10. Enquanto `GATE-002` estiver aberto, não inventar prompt final. Preservar somente as instruções técnicas mínimas de grounding já normatizadas e marcar o conteúdo negocial como pendente.
11. Garantir HTTP 200 e `ChatResponse` válido para os três fast-exits tratados.
12. Não expor detalhes técnicos em resposta externa.



## Fora do escopo da Fase 6

Não:

- aprovar/redigir por conta própria os textos finais;
- aprovar prompt de negócio;
- mudar ScopePolicy;
- implementar parser raw sem GATE-001;
- alterar health/metrics além do necessário;
- transformar validator em guardrail/enforcement não previsto.



## Validação obrigatória

Após implementar, execute tudo que for possível no ambiente atual.

Registre separadamente:

### Build/importação
- comando;
- esperado;
- obtido;
- status.

### Testes automatizados
- comando;
- quantidade quando disponível;
- aprovados;
- falhos;
- status.

### Testes direcionados desta fase
Para cada teste:
- objetivo;
- entrada/double utilizado;
- comando;
- esperado;
- obtido;
- status.

### Regressão relevante
Execute os testes necessários para demonstrar que contratos que deveriam permanecer não foram quebrados.

Status permitidos:

```text
OK
FALHOU
NÃO EXECUTADO
BLOQUEADO POR GATE
```

Nunca marque `OK` sem evidência.



## Validações específicas

Testar:

- chunks → `context_precision` executa;
- falha do judge/evaluator → fail-open;
- score baixo → LLM continua quando `RAGResult=SUCCESS`;
- `NO_CONTEXT`/`INFRA_ERROR` não executam `context_precision` quando não há chunks;
- validators pós-LLM executam apenas no caminho de geração;
- `tool_correctness` não executa no A0;
- cada fast-exit usa chave de resposta distinta;
- valores de teste distintos permanecem distintos externamente;
- cada fast-exit retorna HTTP 200;
- `session_id` preservado;
- `tool_calls_made=0`;
- todos passam pelo guardrail de saída;
- PII/blocklist de saída continua funcionando;
- respostas externas não incluem stack trace, status interno, credential ou `index_id`.



## Aplicabilidade por ambiente

Ao final, classifique:

| Ambiente | Classificação permitida |
|---|---|
| Local/WSL | `OBRIGATÓRIO`, `APLICÁVEL`, `NÃO APLICÁVEL` |
| Pegwin | `APLICÁVEL`, `MESMO PROCEDIMENTO DO WSL`, `NÃO APLICÁVEL` |
| OpenShift | `OBRIGATÓRIO`, `RECOMENDADO`, `NÃO NECESSÁRIO`, `BLOQUEADO POR GATE` |

Só forneça comandos específicos quando houver valor real de validação.

Para WSL/Pegwin/OpenShift:
- use comandos copiáveis;
- descubra o diretório/package/comandos reais no workspace antes de escrevê-los;
- use placeholders para valores corporativos desconhecidos;
- não invente namespaces, deployments, routes, registries, URLs internas, tokens ou secrets.

Não execute automaticamente operações mutáveis/destrutivas em infraestrutura corporativa (`oc apply`, `oc delete`, `oc patch`, `oc scale`, alterações de Secret/ConfigMap/Deployment etc.). Pode preparar os comandos, mas marque que exigem autorização explícita.

O arquivo de memória da fase é a fonte canônica dos comandos. Se os repetir na resposta, reproduza exatamente os mesmos comandos.


### Classificação esperada de migração desta fase

`RECOMENDADA`, pois altera comportamento funcional visível e segurança de saída; promoção continua bloqueada por GATE-002/GATE-004.


## Rollback

Defina como retornar ao estado anterior desta fase.

- Prefira rollback por código/configuração versionada.
- Não suponha disponibilidade de Git, snapshot, backup ou `oc rollout undo` sem evidência.
- Se depender de ambiente corporativo, use placeholders e indique exatamente o que precisa ser conhecido.



## Arquivo obrigatório de memória

Ao final, crie `etapa_06.md`.

Ele deve ser autossuficiente e conter:

1. identificação da fase;
2. documentos utilizados;
3. requisitos `RF/RN/INT/RNF` abordados;
4. critérios `CA` relacionados;
5. `GATE` relacionados;
6. estado antes da fase;
7. arquivos criados/modificados/removidos;
8. resumo do diff;
9. decisões técnicas tomadas;
10. decisões arquiteturais preservadas;
11. decisões explicitamente **não** tomadas;
12. validações executadas;
13. resultados `OK/FALHOU/NÃO EXECUTADO/BLOQUEADO POR GATE`;
14. problemas e limitações;
15. pendências;
16. divergências entre código e SRS/arquitetura;
17. estado final do sistema;
18. aplicabilidade e procedimento de migração corporativa;
19. rollback;
20. próxima fase, sem executá-la.

Também registre a rastreabilidade de cada requisito desta fase como:
`ATENDIDO`, `PARCIALMENTE ATENDIDO`, `NÃO ABORDADO NESTA FASE` ou `BLOQUEADO POR GATE`.



## Auditoria final e regra de parada

Antes de encerrar, compare:

```text
implementação realizada
↔ especificacao_requisitos_a0_versao2.md
↔ plano_arquitetura_a0_versao2.md
↔ memória da etapa anterior
↔ requisitos desta fase
↔ critérios de aceite desta fase
```

Liste qualquer divergência conhecida.

Apresente o quadro final:

```text
FASE 06 — Validators, guardrails e respostas funcionais

Implementação: OK / PARCIAL / FALHOU
Validação local: OK / FALHOU / NÃO EXECUTADA
Pronta para migração: SIM / NÃO
Validação corporativa: OK / FALHOU / NÃO EXECUTADA
Gates relacionados: ABERTOS / FECHADOS / N/A
```

Finalize com uma condição coerente, por exemplo:

- `ETAPA 06 PRONTA PARA MIGRAÇÃO/VALIDAÇÃO CORPORATIVA`
- `ETAPA 06 BLOQUEADA — EXISTEM CRITÉRIOS PENDENTES`
- `ETAPA 06 VALIDADA LOCALMENTE — MIGRAÇÃO ISOLADA NÃO NECESSÁRIA`

Depois **PARE**. Não implemente a Fase 07.

