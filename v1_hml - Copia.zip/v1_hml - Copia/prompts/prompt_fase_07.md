# PROMPT — IMPLEMENTAÇÃO DA FASE 07

## Identificação

**Fase:** 07  
**Nome:** Compatibilidade operacional e observabilidade  
**Objetivo principal:** executar exclusivamente esta macroetapa da implementação A0 Informacional V2.  
**Risco:** médio a alto; risco de quebrar operação embora o fluxo funcional esteja correto  
**Etapa anterior:** `etapa_06.md`

> Este prompt deve ser executado isoladamente. Não avance para a fase seguinte.


## Fontes obrigatórias e ordem de autoridade

Antes de alterar qualquer arquivo, leia integralmente e trate como fontes de verdade, nesta ordem:

1. `especificacao_requisitos_a0_versao2.md` — fonte normativa para implementação, testes e aceite.
2. `plano_arquitetura_a0_versao2.md` — fonte das decisões, invariantes, restrições e justificativas arquiteturais.
3. ``etapa_06.md`` — estado validado herdado da fase anterior, quando existir.
4. Código-fonte, testes, configuração, pipeline e documentação do workspace — baseline observado.
5. Decisões técnicas estritamente necessárias para implementar esta fase.

`especificacao_requisitos_a0_versao2.md` e `plano_arquitetura_a0_versao2.md` são **read-only**. Não os altere.

O código atual é baseline, não target. Não preserve automaticamente comportamento legado contrário à V2. Se houver conflito entre baseline e SRS/arquitetura, registre a divergência e implemente o target normativo. Se a divergência impedir uma implementação segura, pare somente a decisão afetada, apresente evidência e não modifique os documentos normativos para acomodar o código.

Quando uma conclusão vier apenas do código atual, identifique-a como `BASELINE OBSERVADO`. Quando for decisão de implementação e não requisito, identifique-a como `DECISÃO TÉCNICA`.



## Invariantes do target V2 que esta fase não pode contradizer

A sequência abaixo é o **estado final alvo**, não uma afirmação de que todas as etapas já existem nesta fase:

```text
Guardrails de entrada
→ Scope Gate determinístico
→ RAG para toda entrada não rejeitada por escopo
→ LLM somente em SUCCESS com chunks
→ validators pós-LLM quando houver geração
→ Guardrails de saída
```

Nas Fases 1 a 4, preserve o baseline executável enquanto prepara componentes do target; **não antecipe a ativação da topologia completa**, reservada à Fase 5. Nenhuma alteração intermediária pode criar uma direção incompatível com os invariantes finais.

Regras obrigatórias do estado final:

- `OUT_OF_SCOPE` não chama RAG nem LLM.
- `IN_SCOPE` segue para RAG.
- `UNDETERMINED` segue para RAG.
- `NO_CONTEXT` não chama LLM.
- `INFRA_ERROR` não chama LLM.
- RAG é fonte factual; o LLM não preenche lacunas documentais com conhecimento externo.
- `context_precision` é observacional e fail-open; score baixo não altera o roteamento.
- Tool Calling não decide se o RAG será consultado no A0 V2.
- `tool_calls_made` permanece no contrato e vale `0` no A0 V2.
- O A0 permanece stateless nesta entrega.
- MCP, memória, cache, retry e streaming não devem ser introduzidos sem decisão adicional.
- Nenhum SLO quantitativo deve ser inventado.
- Não invente schema de `retrieved_contexts`, taxonomia de educação financeira, prompt final nem textos negociais finais.



### Requisitos e critérios prioritários

- `RF-016`, `RF-018`, `RF-020`.
- `INT-005`, `INT-006`.
- `RN-012`.
- `RNF-004`, `RNF-005`, `RNF-006`, `RNF-008`, `RNF-009`.
- `CA-023`, `CA-030`, `CA-032`, `CA-033`, `CA-034`, `CA-035`.



## Disciplina de execução

Implemente **somente esta fase**.

Antes de editar, apresente resumidamente:

1. arquivos/componentes relevantes encontrados;
2. estado atual observado;
3. diferenças para o target desta fase;
4. arquivos que pretende criar/modificar/remover;
5. riscos;
6. requisitos/CA/GATE relacionados;
7. o que ficará deliberadamente para fases posteriores.

Prefira mudanças pequenas, portáveis, testáveis e reversíveis. Não faça refatorações oportunistas.

Se uma preparação para uma fase futura for estritamente necessária, implemente somente a estrutura mínima, deixe-a inativa quando aplicável e registre claramente que ela não satisfaz antecipadamente a fase futura.

Não invente resultado de comando, teste, endpoint, log, payload ou ambiente.



## Escopo específico da Fase 7

Preservar e validar a superfície operacional depois da refatoração.

### `/health/live`
- deve continuar local;
- HTTP 200 enquanto processo vivo;
- não deve chamar GeneraBB, LLM ou outras dependências externas.

### `/health/ready`
- deve permanecer local;
- validar configuração carregada e grafo compilado;
- adaptar validação RAG para `index_id` principal e fallback legado quando aplicável;
- validar configurações obrigatórias da V2 sem fazer request externo;
- não transformar indisponibilidade do Genera/LLM em readiness remoto.

### `/metrics`
- preservar JSON;
- preservar pelo menos os campos observados no SRS:
  - `uptime_seconds`;
  - `total_requests`;
  - `agent_id`;
  - `agent_name`;
- adicionar métricas V2 apenas quando coerente com o mecanismo real existente, sem trocar o formato para Prometheus por iniciativa própria.

### Tracing/telemetria
- confirmar `RAG.gateway_core`;
- observar `scope_result`, `rag_result`, duração/contagem quando tecnicamente compatível;
- preservar OpenTelemetry/Azure Monitor existentes;
- não registrar chunks, secrets ou PII;
- não depender de Tool callback para o RAG.

### Runtime
- Python 3.11 é target normativo;
- inspecionar manifests realmente ativos;
- se `aic.json` desta cópia continuar em 3.8, não alterá-lo cegamente: determine se é arquivo ativo da esteira. Se houver evidência suficiente de que é ativo, alinhe-o conforme SRS; se não houver, registre a inconsistência como bloqueio/pendência de promoção.
- não inventar imagem base; preservar a imagem corporativa ativa se compatível com Python 3.11.

Não criar SLOs nem retry.



## Fora do escopo da Fase 7

Não:

- fechar os quatro gates de negócio/integração;
- trocar sistema de métricas;
- habilitar Sonar/SAST;
- introduzir autenticação nova;
- adicionar dependências externas aos health checks;
- alterar políticas de retenção não evidenciadas;
- redesenhar CI sem necessidade.



## Validação obrigatória

Após implementar, execute tudo que for possível no ambiente atual.

Registre separadamente:

### Build/importação
- comando;
- esperado;
- obtido;
- status.

### Testes automatizados
- comando;
- quantidade quando disponível;
- aprovados;
- falhos;
- status.

### Testes direcionados desta fase
Para cada teste:
- objetivo;
- entrada/double utilizado;
- comando;
- esperado;
- obtido;
- status.

### Regressão relevante
Execute os testes necessários para demonstrar que contratos que deveriam permanecer não foram quebrados.

Status permitidos:

```text
OK
FALHOU
NÃO EXECUTADO
BLOQUEADO POR GATE
```

Nunca marque `OK` sem evidência.



## Validações específicas

Provar:

- `/health/live` funciona com rede/dependências externas indisponíveis;
- `/health/ready` não chama Genera nem LLM;
- readiness falha de forma coerente quando configuração local obrigatória está inválida;
- `/metrics` continua JSON e contém campos existentes;
- métricas novas não quebram consumidores existentes;
- tracing do RAG existe;
- telemetria não contém secret/PII/chunk completo em testes inspecionáveis;
- timeout continua configurável e não é chamado de SLO;
- runtime/manifests têm evidência registrada;
- suíte operacional/regressão passa.



## Aplicabilidade por ambiente

Ao final, classifique:

| Ambiente | Classificação permitida |
|---|---|
| Local/WSL | `OBRIGATÓRIO`, `APLICÁVEL`, `NÃO APLICÁVEL` |
| Pegwin | `APLICÁVEL`, `MESMO PROCEDIMENTO DO WSL`, `NÃO APLICÁVEL` |
| OpenShift | `OBRIGATÓRIO`, `RECOMENDADO`, `NÃO NECESSÁRIO`, `BLOQUEADO POR GATE` |

Só forneça comandos específicos quando houver valor real de validação.

Para WSL/Pegwin/OpenShift:
- use comandos copiáveis;
- descubra o diretório/package/comandos reais no workspace antes de escrevê-los;
- use placeholders para valores corporativos desconhecidos;
- não invente namespaces, deployments, routes, registries, URLs internas, tokens ou secrets.

Não execute automaticamente operações mutáveis/destrutivas em infraestrutura corporativa (`oc apply`, `oc delete`, `oc patch`, `oc scale`, alterações de Secret/ConfigMap/Deployment etc.). Pode preparar os comandos, mas marque que exigem autorização explícita.

O arquivo de memória da fase é a fonte canônica dos comandos. Se os repetir na resposta, reproduza exatamente os mesmos comandos.


### Classificação esperada de migração desta fase

`OBRIGATÓRIA` ou fortemente `RECOMENDADA` antes de produção, porque health, metrics, tracing e manifests precisam ser comparados no ambiente corporativo.


## Rollback

Defina como retornar ao estado anterior desta fase.

- Prefira rollback por código/configuração versionada.
- Não suponha disponibilidade de Git, snapshot, backup ou `oc rollout undo` sem evidência.
- Se depender de ambiente corporativo, use placeholders e indique exatamente o que precisa ser conhecido.



## Arquivo obrigatório de memória

Ao final, crie `etapa_07.md`.

Ele deve ser autossuficiente e conter:

1. identificação da fase;
2. documentos utilizados;
3. requisitos `RF/RN/INT/RNF` abordados;
4. critérios `CA` relacionados;
5. `GATE` relacionados;
6. estado antes da fase;
7. arquivos criados/modificados/removidos;
8. resumo do diff;
9. decisões técnicas tomadas;
10. decisões arquiteturais preservadas;
11. decisões explicitamente **não** tomadas;
12. validações executadas;
13. resultados `OK/FALHOU/NÃO EXECUTADO/BLOQUEADO POR GATE`;
14. problemas e limitações;
15. pendências;
16. divergências entre código e SRS/arquitetura;
17. estado final do sistema;
18. aplicabilidade e procedimento de migração corporativa;
19. rollback;
20. próxima fase, sem executá-la.

Também registre a rastreabilidade de cada requisito desta fase como:
`ATENDIDO`, `PARCIALMENTE ATENDIDO`, `NÃO ABORDADO NESTA FASE` ou `BLOQUEADO POR GATE`.



## Auditoria final e regra de parada

Antes de encerrar, compare:

```text
implementação realizada
↔ especificacao_requisitos_a0_versao2.md
↔ plano_arquitetura_a0_versao2.md
↔ memória da etapa anterior
↔ requisitos desta fase
↔ critérios de aceite desta fase
```

Liste qualquer divergência conhecida.

Apresente o quadro final:

```text
FASE 07 — Compatibilidade operacional e observabilidade

Implementação: OK / PARCIAL / FALHOU
Validação local: OK / FALHOU / NÃO EXECUTADA
Pronta para migração: SIM / NÃO
Validação corporativa: OK / FALHOU / NÃO EXECUTADA
Gates relacionados: ABERTOS / FECHADOS / N/A
```

Finalize com uma condição coerente, por exemplo:

- `ETAPA 07 PRONTA PARA MIGRAÇÃO/VALIDAÇÃO CORPORATIVA`
- `ETAPA 07 BLOQUEADA — EXISTEM CRITÉRIOS PENDENTES`
- `ETAPA 07 VALIDADA LOCALMENTE — MIGRAÇÃO ISOLADA NÃO NECESSÁRIA`

Depois **PARE**. Não implemente a Fase 08.

