# PROMPT — IMPLEMENTAÇÃO DA FASE 09

## Identificação

**Fase:** 09  
**Nome:** Regressão completa e aceite  
**Objetivo principal:** executar exclusivamente esta macroetapa da implementação A0 Informacional V2.  
**Risco:** alto como gate de qualidade; não deve introduzir features novas  
**Etapa anterior:** `etapa_08.md`

> Este prompt deve ser executado isoladamente. Não avance para a fase seguinte.


## Fontes obrigatórias e ordem de autoridade

Antes de alterar qualquer arquivo, leia integralmente e trate como fontes de verdade, nesta ordem:

1. `especificacao_requisitos_a0_versao2.md` — fonte normativa para implementação, testes e aceite.
2. `plano_arquitetura_a0_versao2.md` — fonte das decisões, invariantes, restrições e justificativas arquiteturais.
3. ``etapa_08.md`` — estado validado herdado da fase anterior, quando existir.
4. Código-fonte, testes, configuração, pipeline e documentação do workspace — baseline observado.
5. Decisões técnicas estritamente necessárias para implementar esta fase.

`especificacao_requisitos_a0_versao2.md` e `plano_arquitetura_a0_versao2.md` são **read-only**. Não os altere.

O código atual é baseline, não target. Não preserve automaticamente comportamento legado contrário à V2. Se houver conflito entre baseline e SRS/arquitetura, registre a divergência e implemente o target normativo. Se a divergência impedir uma implementação segura, pare somente a decisão afetada, apresente evidência e não modifique os documentos normativos para acomodar o código.

Quando uma conclusão vier apenas do código atual, identifique-a como `BASELINE OBSERVADO`. Quando for decisão de implementação e não requisito, identifique-a como `DECISÃO TÉCNICA`.



## Invariantes do target V2 que esta fase não pode contradizer

A sequência abaixo é o **estado final alvo**, não uma afirmação de que todas as etapas já existem nesta fase:

```text
Guardrails de entrada
→ Scope Gate determinístico
→ RAG para toda entrada não rejeitada por escopo
→ LLM somente em SUCCESS com chunks
→ validators pós-LLM quando houver geração
→ Guardrails de saída
```

Nas Fases 1 a 4, preserve o baseline executável enquanto prepara componentes do target; **não antecipe a ativação da topologia completa**, reservada à Fase 5. Nenhuma alteração intermediária pode criar uma direção incompatível com os invariantes finais.

Regras obrigatórias do estado final:

- `OUT_OF_SCOPE` não chama RAG nem LLM.
- `IN_SCOPE` segue para RAG.
- `UNDETERMINED` segue para RAG.
- `NO_CONTEXT` não chama LLM.
- `INFRA_ERROR` não chama LLM.
- RAG é fonte factual; o LLM não preenche lacunas documentais com conhecimento externo.
- `context_precision` é observacional e fail-open; score baixo não altera o roteamento.
- Tool Calling não decide se o RAG será consultado no A0 V2.
- `tool_calls_made` permanece no contrato e vale `0` no A0 V2.
- O A0 permanece stateless nesta entrega.
- MCP, memória, cache, retry e streaming não devem ser introduzidos sem decisão adicional.
- Nenhum SLO quantitativo deve ser inventado.
- Não invente schema de `retrieved_contexts`, taxonomia de educação financeira, prompt final nem textos negociais finais.



### Escopo normativo

Revalidar **todos** os requisitos e critérios aplicáveis do SRS, com foco em:

- `RF-001` a `RF-020`;
- `RN-001` a `RN-015`;
- `INT-001` a `INT-006`;
- `RNF-001` a `RNF-012`;
- `CA-001` a `CA-036`;
- `GATE-001` a `GATE-004`.

Esta fase não deve “consertar requisitos” modificando SRS/arquitetura.



## Disciplina de execução

Implemente **somente esta fase**.

Antes de editar, apresente resumidamente:

1. arquivos/componentes relevantes encontrados;
2. estado atual observado;
3. diferenças para o target desta fase;
4. arquivos que pretende criar/modificar/remover;
5. riscos;
6. requisitos/CA/GATE relacionados;
7. o que ficará deliberadamente para fases posteriores.

Prefira mudanças pequenas, portáveis, testáveis e reversíveis. Não faça refatorações oportunistas.

Se uma preparação para uma fase futura for estritamente necessária, implemente somente a estrutura mínima, deixe-a inativa quando aplicável e registre claramente que ela não satisfaz antecipadamente a fase futura.

Não invente resultado de comando, teste, endpoint, log, payload ou ambiente.



## Escopo específico da Fase 9

Executar a regressão e produzir evidência de aceite.

1. Ler `etapa_08.md` e verificar o status real dos quatro gates.
2. Se qualquer gate obrigatório estiver aberto:
   - a suíte técnica pode ser executada;
   - o template pode ser considerado tecnicamente implementado;
   - **não declarar a instância aceita/promovível para produção**.
3. Executar suíte completa.
4. Executar testes direcionados de:
   - segurança/guardrails;
   - Scope Gate;
   - determinismo;
   - RAG adapter;
   - `SUCCESS/NO_CONTEXT/INFRA_ERROR`;
   - grafo;
   - LLM condicionado;
   - `context_precision`;
   - validators pós-LLM;
   - fast-exits;
   - `/chat`;
   - `tool_calls_made=0`;
   - state;
   - configuração;
   - `/health/live`;
   - `/health/ready`;
   - `/metrics`;
   - tracing/telemetria;
   - privacidade.
5. Validar ausência de:
   - RAG como Tool no caminho A0;
   - LLM chamado sem chunks;
   - `OUT_OF_SCOPE` chamando RAG;
   - parser heurístico;
   - taxonomia genérica embutida no template;
   - memória/MCP/cache/retry/streaming adicionados;
   - secrets/chunks/PII em telemetria;
   - SLO inventado.
6. Validar compatibilidade externa do `/chat`.
7. Validar runtime/manifests conforme evidência ativa.
8. Produzir matriz final `CA-001..CA-036` com status e evidência.
9. Produzir matriz final dos GATEs.
10. Registrar quaisquer testes não executados no ambiente corporativo.

Não introduza nova funcionalidade nesta fase. Se encontrar defeito, faça a correção mínima necessária, reexecute o conjunto afetado e registre o diff como correção de aceite.



## Fora do escopo da Fase 9

Não:

- criar requisito novo;
- mudar arquitetura;
- ampliar escopo;
- fechar gate por inferência;
- habilitar funcionalidades opcionais;
- fazer refatoração estética;
- declarar produção pronta com gates abertos ou validações obrigatórias não executadas.



## Validação obrigatória

Após implementar, execute tudo que for possível no ambiente atual.

Registre separadamente:

### Build/importação
- comando;
- esperado;
- obtido;
- status.

### Testes automatizados
- comando;
- quantidade quando disponível;
- aprovados;
- falhos;
- status.

### Testes direcionados desta fase
Para cada teste:
- objetivo;
- entrada/double utilizado;
- comando;
- esperado;
- obtido;
- status.

### Regressão relevante
Execute os testes necessários para demonstrar que contratos que deveriam permanecer não foram quebrados.

Status permitidos:

```text
OK
FALHOU
NÃO EXECUTADO
BLOQUEADO POR GATE
```

Nunca marque `OK` sem evidência.



## Validações específicas

Além da suíte completa, produzir checklist/evidência para cada `CA-001` a `CA-036`.

Executar, quando o ambiente permitir:

- testes unitários;
- integração;
- startup/container;
- endpoints operacionais;
- fluxo `/chat` com doubles e, quando autorizado, dependências reais;
- observabilidade;
- validação OpenShift relevante.

Classifique cada CA como:
- `OK`;
- `FALHOU`;
- `NÃO EXECUTADO`;
- `BLOQUEADO POR GATE`.

A conclusão de aceite deve distinguir:

```text
TEMPLATE V2 TECNICAMENTE IMPLEMENTADO
INSTÂNCIA EDUCAÇÃO FINANCEIRA ACEITA
INSTÂNCIA PRONTA PARA PRODUÇÃO
```

Esses três estados não são equivalentes.



## Aplicabilidade por ambiente

Ao final, classifique:

| Ambiente | Classificação permitida |
|---|---|
| Local/WSL | `OBRIGATÓRIO`, `APLICÁVEL`, `NÃO APLICÁVEL` |
| Pegwin | `APLICÁVEL`, `MESMO PROCEDIMENTO DO WSL`, `NÃO APLICÁVEL` |
| OpenShift | `OBRIGATÓRIO`, `RECOMENDADO`, `NÃO NECESSÁRIO`, `BLOQUEADO POR GATE` |

Só forneça comandos específicos quando houver valor real de validação.

Para WSL/Pegwin/OpenShift:
- use comandos copiáveis;
- descubra o diretório/package/comandos reais no workspace antes de escrevê-los;
- use placeholders para valores corporativos desconhecidos;
- não invente namespaces, deployments, routes, registries, URLs internas, tokens ou secrets.

Não execute automaticamente operações mutáveis/destrutivas em infraestrutura corporativa (`oc apply`, `oc delete`, `oc patch`, `oc scale`, alterações de Secret/ConfigMap/Deployment etc.). Pode preparar os comandos, mas marque que exigem autorização explícita.

O arquivo de memória da fase é a fonte canônica dos comandos. Se os repetir na resposta, reproduza exatamente os mesmos comandos.


### Classificação esperada de migração desta fase

`OBRIGATÓRIA` para o aceite de produção da instância, incluindo validações corporativas que não possam ser reproduzidas localmente.


## Rollback

Defina como retornar ao estado anterior desta fase.

- Prefira rollback por código/configuração versionada.
- Não suponha disponibilidade de Git, snapshot, backup ou `oc rollout undo` sem evidência.
- Se depender de ambiente corporativo, use placeholders e indique exatamente o que precisa ser conhecido.



## Arquivo obrigatório de memória

Ao final, crie `etapa_09.md`.

Ele deve ser autossuficiente e conter:

1. identificação da fase;
2. documentos utilizados;
3. requisitos `RF/RN/INT/RNF` abordados;
4. critérios `CA` relacionados;
5. `GATE` relacionados;
6. estado antes da fase;
7. arquivos criados/modificados/removidos;
8. resumo do diff;
9. decisões técnicas tomadas;
10. decisões arquiteturais preservadas;
11. decisões explicitamente **não** tomadas;
12. validações executadas;
13. resultados `OK/FALHOU/NÃO EXECUTADO/BLOQUEADO POR GATE`;
14. problemas e limitações;
15. pendências;
16. divergências entre código e SRS/arquitetura;
17. estado final do sistema;
18. aplicabilidade e procedimento de migração corporativa;
19. rollback;
20. próxima fase, sem executá-la.

Também registre a rastreabilidade de cada requisito desta fase como:
`ATENDIDO`, `PARCIALMENTE ATENDIDO`, `NÃO ABORDADO NESTA FASE` ou `BLOQUEADO POR GATE`.



## Auditoria final e regra de parada

Antes de encerrar, compare:

```text
implementação realizada
↔ especificacao_requisitos_a0_versao2.md
↔ plano_arquitetura_a0_versao2.md
↔ memória da etapa anterior
↔ requisitos desta fase
↔ critérios de aceite desta fase
```

Liste qualquer divergência conhecida.

Apresente o quadro final:

```text
FASE 09 — Regressão completa e aceite

Implementação: OK / PARCIAL / FALHOU
Validação local: OK / FALHOU / NÃO EXECUTADA
Pronta para migração: SIM / NÃO
Validação corporativa: OK / FALHOU / NÃO EXECUTADA
Gates relacionados: ABERTOS / FECHADOS / N/A
```

Finalize com uma condição coerente, por exemplo:

- `ETAPA 09 PRONTA PARA MIGRAÇÃO/VALIDAÇÃO CORPORATIVA`
- `ETAPA 09 BLOQUEADA — EXISTEM CRITÉRIOS PENDENTES`
- `ETAPA 09 VALIDADA LOCALMENTE — MIGRAÇÃO ISOLADA NÃO NECESSÁRIA`

Depois **PARE**. Não inicie trabalho adicional fora do escopo deste SRS sem nova instrução.

