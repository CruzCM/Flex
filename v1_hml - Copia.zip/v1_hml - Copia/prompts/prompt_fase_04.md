# PROMPT — IMPLEMENTAÇÃO DA FASE 04

## Identificação

**Fase:** 04  
**Nome:** Adaptador RAG V2  
**Objetivo principal:** executar exclusivamente esta macroetapa da implementação A0 Informacional V2.  
**Risco:** alto; muda contrato externo de recuperação e classificação de falhas, com GATE-001 ainda aberto  
**Etapa anterior:** `etapa_03.md`

> Este prompt deve ser executado isoladamente. Não avance para a fase seguinte.


## Fontes obrigatórias e ordem de autoridade

Antes de alterar qualquer arquivo, leia integralmente e trate como fontes de verdade, nesta ordem:

1. `especificacao_requisitos_a0_versao2.md` — fonte normativa para implementação, testes e aceite.
2. `plano_arquitetura_a0_versao2.md` — fonte das decisões, invariantes, restrições e justificativas arquiteturais.
3. ``etapa_03.md`` — estado validado herdado da fase anterior, quando existir.
4. Código-fonte, testes, configuração, pipeline e documentação do workspace — baseline observado.
5. Decisões técnicas estritamente necessárias para implementar esta fase.

`especificacao_requisitos_a0_versao2.md` e `plano_arquitetura_a0_versao2.md` são **read-only**. Não os altere.

O código atual é baseline, não target. Não preserve automaticamente comportamento legado contrário à V2. Se houver conflito entre baseline e SRS/arquitetura, registre a divergência e implemente o target normativo. Se a divergência impedir uma implementação segura, pare somente a decisão afetada, apresente evidência e não modifique os documentos normativos para acomodar o código.

Quando uma conclusão vier apenas do código atual, identifique-a como `BASELINE OBSERVADO`. Quando for decisão de implementação e não requisito, identifique-a como `DECISÃO TÉCNICA`.



## Invariantes do target V2 que esta fase não pode contradizer

A sequência abaixo é o **estado final alvo**, não uma afirmação de que todas as etapas já existem nesta fase:

```text
Guardrails de entrada
→ Scope Gate determinístico
→ RAG para toda entrada não rejeitada por escopo
→ LLM somente em SUCCESS com chunks
→ validators pós-LLM quando houver geração
→ Guardrails de saída
```

Nas Fases 1 a 4, preserve o baseline executável enquanto prepara componentes do target; **não antecipe a ativação da topologia completa**, reservada à Fase 5. Nenhuma alteração intermediária pode criar uma direção incompatível com os invariantes finais.

Regras obrigatórias do estado final:

- `OUT_OF_SCOPE` não chama RAG nem LLM.
- `IN_SCOPE` segue para RAG.
- `UNDETERMINED` segue para RAG.
- `NO_CONTEXT` não chama LLM.
- `INFRA_ERROR` não chama LLM.
- RAG é fonte factual; o LLM não preenche lacunas documentais com conhecimento externo.
- `context_precision` é observacional e fail-open; score baixo não altera o roteamento.
- Tool Calling não decide se o RAG será consultado no A0 V2.
- `tool_calls_made` permanece no contrato e vale `0` no A0 V2.
- O A0 permanece stateless nesta entrega.
- MCP, memória, cache, retry e streaming não devem ser introduzidos sem decisão adicional.
- Nenhum SLO quantitativo deve ser inventado.
- Não invente schema de `retrieved_contexts`, taxonomia de educação financeira, prompt final nem textos negociais finais.



### Requisitos e critérios prioritários

- `RF-007`, `RF-018`, `RF-019`.
- `INT-003`, `INT-006`.
- `RN-005`, `RN-012`, `RN-015`.
- `RNF-008`, `RNF-011`.
- `CA-010`, `CA-011`, `CA-012`, `CA-013`, `CA-023`.
- `CA-029` permanece bloqueado por `GATE-001` até payload real.
- `GATE-001` permanece aberto nesta fase, salvo se evidência real já tiver sido fornecida explicitamente.



## Disciplina de execução

Implemente **somente esta fase**.

Antes de editar, apresente resumidamente:

1. arquivos/componentes relevantes encontrados;
2. estado atual observado;
3. diferenças para o target desta fase;
4. arquivos que pretende criar/modificar/remover;
5. riscos;
6. requisitos/CA/GATE relacionados;
7. o que ficará deliberadamente para fases posteriores.

Prefira mudanças pequenas, portáveis, testáveis e reversíveis. Não faça refatorações oportunistas.

Se uma preparação para uma fase futura for estritamente necessária, implemente somente a estrutura mínima, deixe-a inativa quando aplicável e registre claramente que ela não satisfaz antecipadamente a fase futura.

Não invente resultado de comando, teste, endpoint, log, payload ou ambiente.



## Escopo específico da Fase 4

Construir o adaptador RAG V2 como integração **não-Tool**:

1. Separar a lógica de recuperação da decoração/wrapper LangChain Tool existente.
2. Implementar chamada a `/gateway/core`.
3. Usar `action = recuperar-contexto-indice`.
4. Construir payload com:
   - `input`;
   - `context.query_type = hybrid`;
   - `context.total_context` configurável;
   - `index_id`.
5. Não enviar histórico, Tool schema ou decisões do LLM.
6. Aplicar `RAG_CLIENT_ID`, UOR e identificação do usuário conforme contrato/configuração efetivamente existente.
7. Preservar `httpx.AsyncClient`/ciclo de vida seguro conforme padrão atual, evitando criar cliente novo por request se o baseline já reutiliza.
8. Preservar timeout configurável; não criar retry.
9. Classificar:
   - timeout/HTTP/conexão/config inválida/formato não processável → `INFRA_ERROR`;
   - resposta tecnicamente válida sem chunks → `NO_CONTEXT`;
   - resposta válida com chunks → `SUCCESS`.
10. Criar span explícito equivalente a `RAG.gateway_core` reutilizando tracing existente.
11. Não registrar credenciais, PII, headers sensíveis ou chunks completos.
12. Se o antigo `build_rag_tool` ainda for necessário para manter o baseline executável até a Fase 5, preserve-o temporariamente como camada de compatibilidade claramente marcada; a nova lógica principal deve ficar fora da Tool.
13. Não implemente parsing heurístico.

### Tratamento obrigatório de GATE-001

O envelope conhecido é `data.data.retrieved_contexts`, porém o schema interno dos itens não foi comprovado.

Antes de `GATE-001`:
- teste construção de request;
- teste classificação de erros;
- teste transporte usando stub/mock do parser ou do retorno normalizado;
- teste `RAGResponse`;
- **não crie fixture raw fictícia** para representar o Genera real;
- não declare `CA-029` atendido.

Se um payload real sanitizado estiver disponível no workspace, valide se ele é evidência explicitamente fornecida para GATE-001 antes de utilizá-lo.



## Fora do escopo da Fase 4

Não:

- reescrever ainda toda a topologia do LangGraph;
- inventar campos internos de `retrieved_contexts`;
- criar retry;
- transformar timeout em SLO;
- inventar URL/secret corporativo;
- definir ScopePolicy de educação financeira;
- fechar GATE-001 sem payload real;
- remover globalmente `tool_correctness` ou infraestrutura reutilizável por outros agentes.



## Validação obrigatória

Após implementar, execute tudo que for possível no ambiente atual.

Registre separadamente:

### Build/importação
- comando;
- esperado;
- obtido;
- status.

### Testes automatizados
- comando;
- quantidade quando disponível;
- aprovados;
- falhos;
- status.

### Testes direcionados desta fase
Para cada teste:
- objetivo;
- entrada/double utilizado;
- comando;
- esperado;
- obtido;
- status.

### Regressão relevante
Execute os testes necessários para demonstrar que contratos que deveriam permanecer não foram quebrados.

Status permitidos:

```text
OK
FALHOU
NÃO EXECUTADO
BLOQUEADO POR GATE
```

Nunca marque `OK` sem evidência.



## Validações específicas

Testar com doubles:

- URL/path `/gateway/core`;
- action correta;
- payload híbrido;
- `total_context` configurável;
- `index_id` principal e fallback carregado previamente;
- ausência de histórico;
- headers sem expor valores em logs;
- timeout → `INFRA_ERROR`;
- erro HTTP → `INFRA_ERROR`;
- configuração ausente → `INFRA_ERROR`, nunca `NO_CONTEXT`;
- resposta válida sem contexto → `NO_CONTEXT` quando essa condição puder ser simulada sem inventar schema;
- parser/normalizador stubado retornando chunks → `SUCCESS`;
- span `RAG.gateway_core`;
- nenhuma dependência de callback de Tool para observar a chamada.



## Aplicabilidade por ambiente

Ao final, classifique:

| Ambiente | Classificação permitida |
|---|---|
| Local/WSL | `OBRIGATÓRIO`, `APLICÁVEL`, `NÃO APLICÁVEL` |
| Pegwin | `APLICÁVEL`, `MESMO PROCEDIMENTO DO WSL`, `NÃO APLICÁVEL` |
| OpenShift | `OBRIGATÓRIO`, `RECOMENDADO`, `NÃO NECESSÁRIO`, `BLOQUEADO POR GATE` |

Só forneça comandos específicos quando houver valor real de validação.

Para WSL/Pegwin/OpenShift:
- use comandos copiáveis;
- descubra o diretório/package/comandos reais no workspace antes de escrevê-los;
- use placeholders para valores corporativos desconhecidos;
- não invente namespaces, deployments, routes, registries, URLs internas, tokens ou secrets.

Não execute automaticamente operações mutáveis/destrutivas em infraestrutura corporativa (`oc apply`, `oc delete`, `oc patch`, `oc scale`, alterações de Secret/ConfigMap/Deployment etc.). Pode preparar os comandos, mas marque que exigem autorização explícita.

O arquivo de memória da fase é a fonte canônica dos comandos. Se os repetir na resposta, reproduza exatamente os mesmos comandos.


### Classificação esperada de migração desta fase

`RECOMENDADA` para validar conectividade/configuração; fechamento real do GATE-001 só será `OBRIGATÓRIO` em ambiente autorizado com payload real.


## Rollback

Defina como retornar ao estado anterior desta fase.

- Prefira rollback por código/configuração versionada.
- Não suponha disponibilidade de Git, snapshot, backup ou `oc rollout undo` sem evidência.
- Se depender de ambiente corporativo, use placeholders e indique exatamente o que precisa ser conhecido.



## Arquivo obrigatório de memória

Ao final, crie `etapa_04.md`.

Ele deve ser autossuficiente e conter:

1. identificação da fase;
2. documentos utilizados;
3. requisitos `RF/RN/INT/RNF` abordados;
4. critérios `CA` relacionados;
5. `GATE` relacionados;
6. estado antes da fase;
7. arquivos criados/modificados/removidos;
8. resumo do diff;
9. decisões técnicas tomadas;
10. decisões arquiteturais preservadas;
11. decisões explicitamente **não** tomadas;
12. validações executadas;
13. resultados `OK/FALHOU/NÃO EXECUTADO/BLOQUEADO POR GATE`;
14. problemas e limitações;
15. pendências;
16. divergências entre código e SRS/arquitetura;
17. estado final do sistema;
18. aplicabilidade e procedimento de migração corporativa;
19. rollback;
20. próxima fase, sem executá-la.

Também registre a rastreabilidade de cada requisito desta fase como:
`ATENDIDO`, `PARCIALMENTE ATENDIDO`, `NÃO ABORDADO NESTA FASE` ou `BLOQUEADO POR GATE`.



## Auditoria final e regra de parada

Antes de encerrar, compare:

```text
implementação realizada
↔ especificacao_requisitos_a0_versao2.md
↔ plano_arquitetura_a0_versao2.md
↔ memória da etapa anterior
↔ requisitos desta fase
↔ critérios de aceite desta fase
```

Liste qualquer divergência conhecida.

Apresente o quadro final:

```text
FASE 04 — Adaptador RAG V2

Implementação: OK / PARCIAL / FALHOU
Validação local: OK / FALHOU / NÃO EXECUTADA
Pronta para migração: SIM / NÃO
Validação corporativa: OK / FALHOU / NÃO EXECUTADA
Gates relacionados: ABERTOS / FECHADOS / N/A
```

Finalize com uma condição coerente, por exemplo:

- `ETAPA 04 PRONTA PARA MIGRAÇÃO/VALIDAÇÃO CORPORATIVA`
- `ETAPA 04 BLOQUEADA — EXISTEM CRITÉRIOS PENDENTES`
- `ETAPA 04 VALIDADA LOCALMENTE — MIGRAÇÃO ISOLADA NÃO NECESSÁRIA`

Depois **PARE**. Não implemente a Fase 05.

