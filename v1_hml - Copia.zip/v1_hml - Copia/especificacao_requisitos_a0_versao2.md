# Especificação de Requisitos de Software (SRS)
## Agente A0 Informacional — Versão 2

> **Status:** normativo para implementação, testes e aceite  
> **Versão do SRS:** 2.0  
> **Idioma:** português do Brasil  
> **Data da evidência desta edição:** 2026-09-29  
> **Artefato complementar:** plano_arquitetura_a0_versao2.md

---

## 1. Controle documental e precedência

| Campo | Valor |
|---|---|
| Documento | Especificação de Requisitos de Software do Agente A0 Informacional |
| Versão | 2.0 |
| Status | Normativo para implementação, testes e aceite |
| Público | Desenvolvedores, testadores, operadores e agentes de IA |
| Escopo | Template A0 reutilizável e perfil da instância de educação financeira |
| Data da evidência | 2026-09-29 |
| Fonte arquitetural | plano_arquitetura_a0_versao2.md |
| Fonte do baseline | código, configuração, testes e documentação presentes no workspace |

A precedência documental é:

1. Este SRS é a fonte normativa para implementação, testes e aceite.
2. O Plano de Arquitetura A0 Informacional V2 é a fonte das decisões, invariantes, restrições e justificativas arquiteturais das quais este SRS deriva.
3. O código atual é somente o baseline observado. Ele não define o comportamento futuro quando divergir da V2.
4. README, testes, pipeline e configurações podem evidenciar o baseline, mas não substituem decisões arquiteturais aprovadas.

O SRS não pode contrariar silenciosamente a arquitetura. Qualquer decisão adicional deve ser identificada, justificada e rastreada na matriz de decisões.

---

## 2. Classificação das informações e limites da evidência

Todo conteúdo normativo deste documento deve ser interpretado conforme uma das quatro categorias:

| Categoria | Significado |
|---|---|
| **REQUERIDO PELA V2** | comportamento exigido pela arquitetura aprovada e convertido em requisito verificável |
| **BASELINE OBSERVADO** | comportamento encontrado no workspace durante a inspeção |
| **INFERÊNCIA** | conclusão derivada de evidência parcial; não é requisito por si só |
| **GATE / EVIDÊNCIA PENDENTE** | item que precisa de evidência ou decisão específica antes do aceite da instância |

Quando algo não estiver comprovado, o documento deve usar **NÃO EVIDENCIADO** ou classificá-lo como gate. Nenhuma ausência de informação deve ser preenchida por hipótese apresentada como fato.

Limitações da evidência desta edição:

- Os metadados Git não estavam disponíveis/verificáveis na cópia do workspace usada na inspeção.
- A suíte não foi executada nesta sessão porque o ambiente de inspeção não possuía o módulo pytest instalado. O projeto declara pytest e a pipeline prevê testes, mas esse resultado de runtime não foi validado aqui.
- O payload real do campo retrieved_contexts do GeneraBB não está disponível no workspace. O parser definitivo depende de GATE-001.
- A taxonomia concreta de educação financeira, o prompt final e os textos negociais das respostas de fast-exit não foram fornecidos.

---

## 3. Objetivo

O sistema deve implementar um template de agente informacional baseado em recuperação documental (RAG) que:

1. proteja a entrada e a saída por guardrails;
2. aplique uma fronteira de escopo determinística e específica do agente;
3. consulte obrigatoriamente a fonte RAG para toda entrada que não tenha sido rejeitada por escopo;
4. acione o LLM somente quando existirem chunks recuperados;
5. diferencie fora de escopo, ausência documental e indisponibilidade técnica;
6. preserve o contrato HTTP e os endpoints operacionais existentes;
7. ofereça rastreabilidade suficiente para implementação, testes, operação e aceite.

O template não é um agente transacional e não usa conhecimento paramétrico do LLM como fonte factual independente.

---

## 4. Público e atores

### 4.1 Público deste documento

- Desenvolvedores responsáveis pela refatoração do projeto atual.
- Testadores responsáveis pela suíte unitária, integração e aceite.
- Agentes de IA que receberão este SRS como contexto normativo de implementação.
- Operadores responsáveis por configuração, telemetria e promoção.

### 4.2 Atores do sistema

| Ator | Responsabilidade |
|---|---|
| Orquestrador | roteia chamadas, mantém histórico fora do A0, envia a mensagem atual e consome a resposta |
| Agente A0 | aplica escopo, recupera documentação, gera somente com evidência e preserva guardrails |
| Cliente do App | destinatário final do conteúdo na instância de educação financeira |
| GeneraBB | fornece contexto documental por /gateway/core |
| LLM | sintetiza e organiza chunks; não é a fonte factual |
| OpenTelemetry/Azure Monitor | registra tracing e métricas sem expor dados sensíveis |

---

## 5. Glossário

| Termo | Definição |
|---|---|
| A0 | template de agente informacional orientado a RAG |
| Scope Gate | fronteira funcional antes do RAG |
| ScopePolicy | política determinística específica de cada agente |
| ScopeResult | resultado do Scope Gate: IN_SCOPE, OUT_OF_SCOPE ou UNDETERMINED |
| RAG | recuperação de contexto documental |
| RAGResult | resultado técnico/semântico da recuperação: SUCCESS, NO_CONTEXT ou INFRA_ERROR |
| chunk | unidade textual normalizada do contexto recuperado |
| fast-exit | caminho funcional que não chama o LLM |
| baseline | comportamento observado no código ou na documentação atual |
| instância | configuração concreta do template para um domínio |
| gate | evidência ou decisão necessária para o aceite da instância |

---

## 6. Template versus instância

### 6.1 Template A0 Informacional

O template define:

- fronteiras de segurança, escopo, evidência e geração;
- contratos de estado;
- contratos HTTP e RAG;
- estados e roteamento;
- requisitos de observabilidade;
- critérios de teste e aceite.

O template não fixa:

- uma taxonomia universal;
- um índice documental universal;
- um prompt universal;
- mensagens negociais universais;
- regras de domínio codificadas diretamente no node genérico.

### 6.2 Instância A0 Educação Financeira

A instância atual possui:

| Item | Valor normativo da instância |
|---|---|
| Domínio | educação financeira |
| Público final | Clientes do App |
| Consumidor técnico | Orquestrador |
| Índice RAG | idx-mf-edu-fin |
| RAG_CLIENT_ID | fornecido pelo ambiente, sem valor no SRS |
| UOR | fornecido pelo ambiente/configuração |
| user_id | fornecido pelo ambiente/configuração |
| Genera Safe | não obrigatório/ativo nesta entrega |
| Taxonomia de escopo | GATE-003 |
| Prompt final | GATE-002 |
| Mensagens finais | GATE-004 |
| Schema de retrieved_contexts | GATE-001 |

---

## 7. Arquitetura funcional normativa

O fluxo obrigatório é:

~~~text
POST /chat
→ Guardrails de entrada
→ Scope Gate determinístico
→ RAG obrigatório para entradas não rejeitadas
→ decisão pelo RAGResult
→ LLM somente quando houver contexto
→ validators pós-LLM
→ Guardrails de saída
→ ChatResponse
~~~

Regra central:

> Toda requisição passa primeiro pelas proteções de segurança. Em seguida, uma política determinística e específica do agente pode rejeitar entradas claramente fora de escopo. Toda entrada não rejeitada consulta obrigatoriamente a fonte RAG antes de qualquer geração. O LLM só é acionado quando existe contexto recuperado.

Representação canônica:

~~~mermaid
flowchart TD
    A["POST /chat"] --> B["Guardrails de entrada"]
    B --> C["scope_gate_node"]
    C --> D{"scope_result"}
    D -- "OUT_OF_SCOPE" --> E["OUT_OF_SCOPE_REPLY"]
    D -- "IN_SCOPE" --> F["retrieve_context_node"]
    D -- "UNDETERMINED" --> F
    F --> G["GeneraBB /gateway/core"]
    G --> H["context_precision observacional"]
    H --> I{"rag_result"}
    I -- "SUCCESS com chunks" --> J["llm_node"]
    J --> K["validators pós-LLM"]
    I -- "NO_CONTEXT" --> L["RAG_NO_CONTEXT_REPLY"]
    I -- "INFRA_ERROR" --> M["RAG_UNAVAILABLE_REPLY"]
    E --> N["Guardrails de saída"]
    K --> N
    L --> N
    M --> N
    N --> O["ChatResponse"]
~~~

---

## 8. Escopo

### 8.1 Dentro do escopo

- ScopePolicy, ScopeResult e scope_gate_node.
- Bloqueio determinístico de entradas claramente fora de escopo.
- RAG sequencial obrigatório depois do Scope Gate.
- Endpoint GeneraBB /gateway/core.
- action recuperar-contexto-indice.
- index_id e fallback legado por agent_id.
- RAGResult e RAGResponse.
- AgentState explícito.
- context_precision observacional.
- Três respostas funcionais distintas.
- Tracing HTTP explícito do RAG.
- Preservação dos contratos HTTP e endpoints operacionais.
- Testes, regressão, configuração e rastreabilidade.
- Preparação para memória futura sem implementar memória.
- Política de não inventar SLOs.

### 8.2 Fora do escopo

- Memória conversacional nesta entrega.
- Alteração do contrato /chat para receber histórico.
- Agentes transacionais.
- RAG como Tool no fluxo A0.
- Múltiplas Tools, MCP ou Tool Calling no fluxo A0.
- Re-ranking, cache RAG, streaming e nova infraestrutura de persistência.
- Mudança do Orquestrador.
- SLOs quantitativos não aprovados.
- Uso de LLM generativo para decidir deterministicamente o escopo.
- Taxonomia universal de domínio.
- Habilitação de Sonar, SAST ou mudanças de pipeline sem decisão adicional.

---

## 9. Identificadores normativos

Os requisitos devem utilizar identificadores estáveis:

| Prefixo | Tipo |
|---|---|
| RF | requisito funcional |
| RN | regra de negócio |
| INT | interface ou integração |
| RNF | requisito não funcional |
| CA | critério de aceite |
| GATE | gate de aceite da instância |

Cada requisito possui, nesta especificação, título, enunciado verificável, origem/evidência, método de verificação e relação de aceite. Justificativas de mudanças são consolidadas na Seção 31.

---

## 10. Requisitos funcionais

| ID | Título | Enunciado verificável | Origem/evidência | Verificação |
|---|---|---|---|---|
| RF-001 | Guardrails de entrada | O sistema deve executar guardrails de entrada antes do fluxo do LangGraph. | REQUERIDO PELA V2; baseline do middleware | Teste de ordem e bloqueio |
| RF-002 | Scope Gate | O sistema deve executar scope_gate_node depois dos guardrails e antes do RAG. | REQUERIDO PELA V2 | Teste de topologia |
| RF-003 | Política de escopo | O Scope Gate deve delegar a avaliação a uma ScopePolicy específica/configurável por agente. | REQUERIDO PELA V2 | Teste com políticas controladas |
| RF-004 | Resultado de escopo | A avaliação deve produzir IN_SCOPE, OUT_OF_SCOPE ou UNDETERMINED. | REQUERIDO PELA V2 | Teste unitário de contrato |
| RF-005 | Fast-exit de escopo | OUT_OF_SCOPE deve produzir resposta própria sem chamar RAG nem LLM. | REQUERIDO PELA V2 | Mocks de RAG e LLM |
| RF-006 | RAG obrigatório | IN_SCOPE e UNDETERMINED devem chamar o RAG antes de qualquer geração. | REQUERIDO PELA V2 | Teste de roteamento |
| RF-007 | Resultado da recuperação | O nó RAG deve preservar SUCCESS, NO_CONTEXT e INFRA_ERROR. | REQUERIDO PELA V2 | Testes de adapter e grafo |
| RF-008 | Geração condicionada | O LLM só deve ser chamado quando RAGResult=SUCCESS e houver pelo menos um chunk. | REQUERIDO PELA V2 | Testes de pré-condição |
| RF-009 | Fonte factual | A resposta factual deve ser fundamentada no rag_context recebido. | REQUERIDO PELA V2 | Teste de prompt e resposta |
| RF-010 | Context precision | context_precision deve executar com query e chunks quando houver chunks e não deve controlar o fluxo. | REQUERIDO PELA V2 | Teste observacional/fail-open |
| RF-011 | Validators pós-LLM | Validators pós-LLM devem continuar no caminho de geração. | REQUERIDO PELA V2; parte confirmada no baseline | Teste de invocação |
| RF-012 | Guardrails de saída | Resposta gerada, OUT_OF_SCOPE, NO_CONTEXT e INFRA_ERROR devem passar pelos guardrails de saída. | REQUERIDO PELA V2 | Testes de middleware |
| RF-013 | Respostas distintas | O sistema deve permitir configurações independentes para out_of_scope, no_context e unavailable. | REQUERIDO PELA V2 | Teste de configuração |
| RF-014 | Contrato /chat | O endpoint deve preservar request, response, session_id e tool_calls_made. | REQUERIDO PELA V2; baseline | Teste HTTP |
| RF-015 | tool_calls_made | A resposta A0 V2 deve retornar tool_calls_made=0 sem criar ToolMessage fictício. | REQUERIDO PELA V2 | Teste da aplicação |
| RF-016 | Endpoints operacionais | O serviço deve preservar /health/live, /health/ready e /metrics. | Decisão de compatibilidade desta especificação; baseline observado | Teste de regressão |
| RF-017 | Stateless | O A0 não deve persistir histórico ou memória conversacional nesta entrega. | REQUERIDO PELA V2 | Inspeção e teste de state |
| RF-018 | Observabilidade do RAG | A chamada HTTP ao GeneraBB deve ter tracing explícito independente de callbacks de Tool. | REQUERIDO PELA V2 | Teste de span/mocking |
| RF-019 | Configuração legada | O carregamento deve priorizar index_id e aceitar agent_id como fallback legado. | REQUERIDO PELA V2 | Teste de precedência |
| RF-020 | Readiness local | /health/ready deve verificar configuração e grafo localmente sem consultar GeneraBB ou LLM. | REQUERIDO PELA V2 e compatibilidade; baseline observado | Teste sem rede |

### 10.1 Relação dos requisitos funcionais com o aceite

| Requisito | Critério de aceite relacionado |
|---|---|
| RF-001 | CA-001 |
| RF-002 a RF-006 | CA-002 a CA-008 |
| RF-007 a RF-010 | CA-009 a CA-021 |
| RF-011 a RF-013 | CA-024 a CA-027 |
| RF-014 a RF-016 | CA-028, CA-032 a CA-034 |
| RF-017 | CA-031 |
| RF-018 | CA-023 |
| RF-019 | CA-012 e CA-013 |
| RF-020 | CA-033 |

---

## 11. Regras de negócio

| ID | Regra |
|---|---|
| RN-001 | Segurança vem antes do domínio: guardrails de entrada precedem Scope Gate. |
| RN-002 | OUT_OF_SCOPE não consulta RAG nem LLM. |
| RN-003 | Dúvida de escopo não é bloqueio: UNDETERMINED segue para RAG. |
| RN-004 | Toda entrada não rejeitada por segurança ou escopo consulta RAG antes do LLM. |
| RN-005 | NO_CONTEXT e INFRA_ERROR não chamam o LLM. |
| RN-006 | O LLM não pode preencher lacunas documentais com conhecimento externo. |
| RN-007 | Context precision é observacional e score baixo não altera silenciosamente o roteamento. |
| RN-008 | O RAG é etapa estrutural, não escolha do LLM. |
| RN-009 | O A0 não usa MCP, Tool Calling ou múltiplas Tools no fluxo V2. |
| RN-010 | Mensagens de OUT_OF_SCOPE, NO_CONTEXT e INFRA_ERROR devem ser semanticamente distintas. |
| RN-011 | Resposta funcional controlada retorna HTTP 200; isso não se confunde com erro de guardrail ou exception não tratada. |
| RN-012 | Timeouts técnicos não são SLOs. |
| RN-013 | Memória futura pode auxiliar interpretação, mas fatos continuam vindo do RAG. |
| RN-014 | O template não contém taxonomia universal de domínio. |
| RN-015 | Parsing de retrieved_contexts deve ser explícito e baseado no schema real. |

---

## 12. Interfaces HTTP

### 12.1 POST /chat

Entrada normativa:

~~~json
{
  "message": "string",
  "session_id": "string | null"
}
~~~

Requisitos:

- message é obrigatório.
- session_id é opcional.
- O agente permanece stateless.
- O session_id recebido é ecoado conforme o contrato atual.

Saída normativa:

~~~json
{
  "reply": "string",
  "session_id": "string | null",
  "tool_calls_made": 0
}
~~~

tool_calls_made permanece no schema por compatibilidade, mas deve ser zero no A0 V2.

### 12.2 Semântica de status

| Situação | Status normativo |
|---|---:|
| OUT_OF_SCOPE | 200 |
| NO_CONTEXT | 200 |
| INFRA_ERROR tratado pelo grafo | 200 |
| Guardrail de entrada | 400 conforme contrato existente |
| Request estrutural inválido | comportamento do FastAPI/Pydantic somente se confirmado por evidência; caso contrário, pendente |
| Exception não tratada | 500 conforme tratamento global existente |

### 12.3 Endpoints operacionais

#### GET /health/live

Deve permanecer local, sem dependências remotas, e retornar:

~~~json
{
  "status": "alive"
}
~~~

com HTTP 200 enquanto o processo estiver em execução.

#### GET /health/ready

Deve verificar localmente:

- configuração carregada;
- grafo compilado;
- parâmetros locais necessários para a instância.

Não deve executar request ao GeneraBB ou ao LLM.

#### GET /metrics

Deve continuar retornando JSON e preservar, no mínimo:

~~~text
uptime_seconds
total_requests
agent_id
agent_name
~~~

Métricas adicionais são permitidas sem remoção ou alteração incompatível dos campos existentes.

---

## 13. Interfaces de domínio e estado

### 13.1 ScopePolicy

Contrato lógico:

~~~python
class ScopePolicy(Protocol):
    def evaluate(self, message: str) -> ScopeResult:
        ...
~~~

A implementação concreta pode ser síncrona ou assíncrona conforme o projeto, desde que preserve determinismo, versionamento, testes e auditabilidade.

### 13.2 ScopeResult

~~~python
class ScopeResult(Enum):
    IN_SCOPE = "in_scope"
    OUT_OF_SCOPE = "out_of_scope"
    UNDETERMINED = "undetermined"
~~~

### 13.3 RAGResult

~~~python
class RAGResult(Enum):
    SUCCESS = "success"
    NO_CONTEXT = "no_context"
    INFRA_ERROR = "infra_error"
~~~

### 13.4 RAGResponse

~~~python
@dataclass
class RAGResponse:
    chunks: list[str]
    result: RAGResult
    error_detail: str = ""
~~~

### 13.5 AgentState

~~~python
class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
    scope_result: str
    rag_context: List[str]
    rag_result: str
~~~

Os valores publicados no state devem ser simples e serializáveis, por exemplo:

~~~text
in_scope
out_of_scope
undetermined
success
no_context
infra_error
~~~

---

## 14. Integração GeneraBB

### 14.1 Contrato

~~~text
Endpoint: /gateway/core
Action: recuperar-contexto-indice
~~~

Payload lógico:

~~~json
{
  "action": "recuperar-contexto-indice",
  "body": {
    "data": {
      "input": "<query>",
      "context": {
        "query_type": "hybrid",
        "total_context": 5
      },
      "index_id": "<index_id>"
    }
  }
}
~~~

total_context deve ser configurável. O exemplo 5 representa a configuração atual documentada, não um SLO ou limite universal.

### 14.2 Identificação e headers

O cliente deve utilizar os dados exigidos pelo contrato vigente:

- RAG_CLIENT_ID;
- UOR;
- userIdentification e/ou user_id, conforme o contrato de integração adotado.

O SRS não contém valores reais de credenciais, UOR ou user_id.

### 14.3 Ausências intencionais

Não enviar ao Core:

- histórico de mensagens;
- decisões do LLM;
- Tool schema;
- agent_id como identificador primário quando index_id estiver disponível.

### 14.4 Cliente HTTP

O baseline técnico observado utiliza httpx.AsyncClient e timeout configurável. A V2 exige que o cliente preserve:

- timeout configurável;
- classificação de timeout e erro HTTP como INFRA_ERROR;
- reuso seguro do cliente conforme ciclo de vida adotado.

Retry não é requisito desta versão.

### 14.5 Parsing

O envelope conhecido é:

~~~python
data.get("data", {}).get("retrieved_contexts")
~~~

O tipo interno de cada item ainda é GATE-001. O parser definitivo não pode adivinhar campos nem converter item desconhecido em string silenciosamente.

### 14.6 Requisitos de interface e integração

| ID | Título | Enunciado verificável | Origem/evidência | Verificação | Aceite |
|---|---|---|---|---|---|
| INT-001 | Contrato /chat | O endpoint deve aceitar message e session_id e retornar reply, session_id e tool_calls_made. | V2 e baseline | Teste HTTP | CA-028 |
| INT-002 | Status funcional | OUT_OF_SCOPE, NO_CONTEXT e INFRA_ERROR tratado devem retornar HTTP 200 com ChatResponse válido. | V2 | Teste de fast-exits | CA-027 |
| INT-003 | Contrato GeneraBB | A recuperação deve usar /gateway/core, recuperar-contexto-indice, index_id e payload documentado. | V2 | Teste do adapter | CA-010 a CA-013 |
| INT-004 | State do grafo | O estado deve expor scope_result, rag_context e rag_result além de messages. | V2 | Teste de schema | CA-014 a CA-016 |
| INT-005 | Endpoints operacionais | /health/live, /health/ready e /metrics devem permanecer disponíveis e compatíveis. | Decisão de compatibilidade | Teste de regressão | CA-032 a CA-034 |
| INT-006 | Tracing do RAG | A chamada ao GeneraBB deve criar span explícito equivalente a RAG.gateway_core. | V2 | Teste de tracing | CA-023 |

---

## 15. Configuração

### 15.1 RAG

Configuração lógica:

~~~yaml
rag:
  enabled: true
  index_id: ""
  agent_id: ""
  total_context: 5
  timeout: 20.0
  tool_description: ""
~~~

Regras:

- index_id é o campo principal.
- agent_id é fallback legado.
- Quando os dois existirem, index_id vence.
- tool_description permanece vazio/não utilizado no A0, pois o RAG não é Tool.
- Valores de secrets não podem ser armazenados no SRS.

### 15.2 Respostas

Contrato lógico recomendado:

~~~yaml
responses:
  out_of_scope: ""
  no_context: ""
  unavailable: ""
~~~

Os valores finais são GATE-004. A configuração deve exigir três entradas semanticamente distintas, sem expor detalhes internos.

### 15.3 Scope

O template deve exigir uma ScopePolicy habilitada, identificável e versionada, mas não impõe um schema universal para a taxonomia.

O perfil da instância pode usar YAML, código, banco ou outro mecanismo aprovado, desde que preserve:

- versão identificável;
- regras determinísticas;
- saída em ScopeResult;
- testes;
- auditabilidade.

### 15.4 Runtime e dependências

O requisito normativo do SRS para esta versão é Python 3.11.

O workspace desta inspeção contém evidências divergentes: Docker usa a imagem corporativa bb/dev/dev-python:3.11.6, setup.py declara python_requires >=3.11, enquanto o aic.json observado declara versaoPython=3.8. Portanto, Python 3.11 é requisito normativo, mas o alinhamento efetivo do aic.json não foi validado nesta cópia e deve ser confirmado antes da promoção.

O SRS não inventa novos pins de bibliotecas. A implementação deve manter as dependências compatíveis com:

- FastAPI;
- Pydantic;
- LangGraph/LangChain;
- httpx;
- PyYAML;
- OpenTelemetry/Azure Monitor;
- Gateway Outbound do LLM.

---

## 16. Startup e operação

### 16.1 Baseline observado

O workspace observado utiliza:

~~~text
opentelemetry-instrument
→ python -m iaa_agent_mf_edu_fin
→ uvicorn.run(...)
~~~

com defaults observados:

~~~text
host = 0.0.0.0
port = 8080
workers = 1
reload = false
~~~

A instrução de elaboração mencionou plg_agent_consult_fin e python:3.11-slim, mas esses identificadores não foram encontrados nesta cópia. Eles não são tratados como baseline confirmado. O nome efetivo do pacote e a imagem corporativa devem ser confirmados na base ativa antes do release.

### 16.2 Não-SLO

Defaults de Uvicorn, timeout de RAG e timeout de dependências são mecanismos técnicos. Não são metas de disponibilidade ou latência.

---

## 17. Segurança e privacidade

### 17.1 Entrada

Preservar os mecanismos efetivamente existentes:

- limite de tamanho;
- detecção de prompt injection/jailbreak;
- detecção de PII;
- guardrail externo somente quando explicitamente habilitado.

### 17.2 Saída

Todos os caminhos funcionais passam por:

- blocklist existente;
- redação de PII;
- demais regras vigentes do middleware.

### 17.3 Telemetria

É proibido registrar inadvertidamente:

- RAG_CLIENT_ID;
- credenciais;
- headers sensíveis;
- chunks completos;
- PII;
- stack traces em mensagens externas;
- conteúdo de alta cardinalidade sem necessidade.

O risco observado de session_id em logs deve ser tratado como item operacional a avaliar, mas não é convertido silenciosamente em mudança arquitetural desta entrega.

---

## 18. Observabilidade

O A0 deve preservar OpenTelemetry e o exporter configurado para Azure Monitor/Application Insights quando habilitado.

A recuperação RAG não pode depender de callbacks de Tool para ser observada. Deve existir span explícito equivalente a:

~~~text
RAG.gateway_core
~~~

Devem estar observáveis, sem conteúdo sensível desnecessário:

~~~text
scope.result
scope.policy.version
rag.result
rag.duration
rag.chunks.count
context_precision.score
llm.duration
request.duration
~~~

O SRS não impõe metas quantitativas de SLO. A arquitetura deve apenas produzir medições que permitam defini-las futuramente.

---

## 19. Requisitos não funcionais

| ID | Requisito verificável | Verificação |
|---|---|---|
| RNF-001 | O fluxo de escopo deve ser determinístico para a mesma entrada e versão de política. | Teste de repetição |
| RNF-002 | O agente deve permanecer stateless nesta entrega. | Inspeção de state e teste de isolamento |
| RNF-003 | O contrato /chat deve permanecer compatível com o schema definido. | Teste HTTP |
| RNF-004 | /health/live não deve depender de serviços externos. | Teste com rede indisponível |
| RNF-005 | /health/ready deve executar verificação local. | Teste sem chamada externa |
| RNF-006 | Telemetria não deve expor secrets, PII ou chunks completos. | Inspeção e teste de atributos |
| RNF-007 | context_precision deve falhar em aberto conforme a arquitetura. | Teste de falha do judge |
| RNF-008 | Timeouts devem permanecer configuráveis e não ser declarados como SLO. | Inspeção de configuração/documento |
| RNF-009 | O runtime normativo desta versão é Python 3.11. | Verificação de manifests/imagem |
| RNF-010 | O template deve permitir políticas e índices diferentes por agente. | Teste com duas configurações |
| RNF-011 | Configuração ausente ou inválida deve ser classificada como falha de configuração, não como NO_CONTEXT. | Teste do RAG adapter |
| RNF-012 | Nenhuma dependência opcional de MCP, memória ou cache deve ser introduzida nesta versão. | Inspeção de dependências e grafo |

---

## 20. Matriz funcional

| Scope | RAG | Chunks | context_precision | LLM | Resposta |
|---|---|---:|---|---|---|
| OUT_OF_SCOPE | não chama | n/a | não | não | OUT_OF_SCOPE |
| IN_SCOPE | SUCCESS | >0 | executa | sim | resposta gerada |
| UNDETERMINED | SUCCESS | >0 | executa | sim | resposta gerada |
| IN_SCOPE | NO_CONTEXT | 0 | n/a | não | NO_CONTEXT |
| UNDETERMINED | NO_CONTEXT | 0 | n/a | não | NO_CONTEXT |
| IN_SCOPE | INFRA_ERROR | n/a | não | não | INFRA_ERROR |
| UNDETERMINED | INFRA_ERROR | n/a | não | não | INFRA_ERROR |
| IN_SCOPE | SUCCESS | >0 | baixa | sim | resposta + telemetria |
| UNDETERMINED | SUCCESS | >0 | baixa | sim | resposta + telemetria |

---

## 21. Mensagens externas

### 21.1 OUT_OF_SCOPE

Deve informar que a solicitação não pertence ao domínio atendido pelo agente.

### 21.2 NO_CONTEXT

Deve informar que o assunto passou pela fronteira de escopo, mas a base não forneceu documentação suficiente.

### 21.3 INFRA_ERROR

Deve informar que a fonte necessária não pôde ser consultada ou processada naquele momento.

As mensagens devem ser:

- distintas;
- configuráveis;
- independentes da lógica de infraestrutura;
- seguras para o usuário final.

Não devem expor timeout, status HTTP do Genera, credencial, index_id ou stack trace.

---

## 22. Gates da instância

| ID | Gate | Evidência necessária | Bloqueia | Não bloqueia |
|---|---|---|---|---|
| GATE-001 | Schema real de retrieved_contexts | payload real sanitizado, documentação do schema, fixture e teste de parser | aceite e promoção da instância | interfaces, mocks e testes do grafo |
| GATE-002 | Prompt final | redação aprovada pelo time negocial | aceite de conteúdo e promoção da instância | implementação do fluxo genérico |
| GATE-003 | ScopePolicy de educação financeira | taxonomia, versão, regras e corpus de testes | aceite funcional da instância e promoção | implementação da interface e políticas de teste |
| GATE-004 | Mensagens finais | três textos aprovados e configurados | aceite de conteúdo e promoção | implementação das chaves e testes de distinção |

Gates abertos não impedem implementação, testes, mocks, fixtures ou implantação não produtiva necessária à validação. Gates abertos impedem aceite formal e promoção/release da instância para produção.

---

## 23. Matriz de gaps do baseline

| Baseline observado | Estado alvo V2 | Categoria |
|---|---|---|
| Grafo atual começa no LLM e usa ToolNode para recuperação | Scope Gate e RAG sequencial antes do LLM | BASELINE OBSERVADO → REQUERIDO PELA V2 |
| AgentState observado contém somente messages | State deve declarar scope_result, rag_context e rag_result | BASELINE OBSERVADO → REQUERIDO PELA V2 |
| RAG atual pode devolver lista de chunks sem preservar resultado semântico/técnico no state | RAGResponse e RAGResult devem preservar SUCCESS, NO_CONTEXT e INFRA_ERROR | BASELINE OBSERVADO → REQUERIDO PELA V2 |
| O contrato final de retrieved_contexts não foi comprovado | Parser explícito baseado em payload real | GATE-001 |
| Fora de escopo não possui fronteira determinística | ScopePolicy e scope_gate_node | REQUERIDO PELA V2 |
| Ausência e indisponibilidade precisam ser separadas externamente | Três respostas funcionais distintas | REQUERIDO PELA V2 |
| tool_calls_made é derivado de ToolMessage no baseline | Campo permanece, valor A0 V2 é zero | REQUERIDO PELA V2 |
| RAG como Tool não pertence à topologia V2 | RAG como etapa estrutural | REQUERIDO PELA V2 |
| Observabilidade da recuperação não pode depender de callback de Tool | Span explícito RAG.gateway_core | REQUERIDO PELA V2 |
| Configuração principal do RAG deve ser index_id | index_id com fallback agent_id | REQUERIDO PELA V2 |
| Readiness deve acompanhar a configuração nova sem fazer chamadas remotas | checagem local de config/grafo/index | REQUERIDO PELA V2 |
| O workspace desta inspeção apresenta evidência divergente de runtime | Python 3.11 é requisito normativo; alinhamento efetivo de aic.json não foi confirmado | EVIDÊNCIA INCONSISTENTE |

Não se deve descrever o baseline como “parsing heurístico” ou “resultado RAG descartado” sem demonstrar exatamente o comportamento. A descrição normativa é que o contrato final e a propagação de estados ainda precisam ser fechados pela V2.

---

## 24. Matriz de alterações e justificativas

| Alteração | Por que é necessária | Preserva | Impacto/quebra | Alternativa conservadora |
|---|---|---|---|---|
| Adicionar ScopePolicy e Scope Gate | proteger a fronteira funcional antes do custo do RAG/LLM | guardrails e contrato HTTP | altera a topologia interna | deixar o Orquestrador decidir; rejeitada porque remove defesa local |
| Remover RAG como Tool do fluxo A0 | RAG é etapa obrigatória, não escolha do modelo | contrato /chat e tool_calls_made | remove bind_tools/ToolMessage do caminho A0 | manter Tool Calling; rejeitada pela V2 |
| Adicionar ScopeResult ao state | representar IN_SCOPE, OUT_OF_SCOPE e UNDETERMINED | serialização simples do state | amplia schema interno | esconder decisão fora do grafo; rejeitada por perda de rastreabilidade |
| Adicionar RAGResult/RAGResponse ao state | separar ausência documental de falha técnica | mensagem externa e guardrails | exige novos branches/testes | fallback único; rejeitada por semântica incorreta |
| Usar index_id com fallback agent_id | alinhar com /gateway/core e preservar compatibilidade | configurações legadas | muda precedência | usar agent_id sempre; rejeitada pela V2 |
| Criar três mensagens configuráveis | comunicar causas externas diferentes | HTTP 200 e ChatResponse | adiciona configuração e testes | mensagem única; rejeitada pela V2 |
| Adicionar span RAG.gateway_core | recuperar observabilidade sem Tool callback | OTel existente | adiciona tracing explícito | depender de callback de Tool; rejeitada pela topologia |
| Preservar endpoints operacionais | evitar quebra de operação durante refatoração | health/metrics atuais | exige regressão de endpoints | removê-los do SRS; rejeitada por compatibilidade |

---

## 25. Testes obrigatórios

### 25.1 Scope Gate

- OUT_OF_SCOPE não chama RAG nem LLM.
- IN_SCOPE chama RAG.
- UNDETERMINED chama RAG.
- A mesma entrada e versão produzem o mesmo ScopeResult.
- Política versionada torna mudanças de classificação explícitas.

### 25.2 RAG

- Endpoint, action, payload e headers corretos.
- index_id e fallback agent_id.
- query_type hybrid e total_context.
- ausência de histórico.
- SUCCESS, NO_CONTEXT, INFRA_ERROR.
- timeout, HTTP error, configuração ausente e formato não processável.
- span RAG.gateway_core.
- parser raw somente após GATE-001.

### 25.3 Grafo

- Guardrails precedem Scope Gate.
- Scope Gate precede RAG.
- RAG precede LLM.
- SUCCESS com chunks chama LLM uma vez.
- NO_CONTEXT e INFRA_ERROR não chamam LLM.
- chunks chegam ao LLM.
- Tool Calling não participa da recuperação.
- context_precision executa com chunks e não altera o roteamento.
- validators pós-LLM executam somente no caminho de geração.

### 25.4 HTTP e middleware

- As três respostas funcionais retornam HTTP 200.
- Cada resposta possui ChatResponse válido.
- session_id é preservado.
- tool_calls_made é zero.
- Todos os fast-exits passam pelos guardrails de saída.
- Guardrails de entrada preservam a semântica existente.

### 25.5 Operação

- /health/live retorna 200 sem rede.
- /health/ready verifica configuração/grafo localmente.
- /metrics preserva campos existentes e aceita métricas novas.

### 25.6 Configuração e segurança

- Mensagens são independentes.
- Secrets não aparecem em logs/traces.
- PII e chunks completos não aparecem na telemetria.
- Genera Safe opcional não vira dependência obrigatória.
- MCP, memória e cache não são ativados no A0 V2.

---

## 26. Critérios de aceite

| ID | Critério |
|---|---|
| CA-001 | Guardrails continuam antes do fluxo funcional. |
| CA-002 | scope_gate_node executa antes do RAG. |
| CA-003 | ScopePolicy é específica/configurável por agente. |
| CA-004 | ScopeResult possui os três estados normativos. |
| CA-005 | OUT_OF_SCOPE termina sem RAG. |
| CA-006 | OUT_OF_SCOPE termina sem LLM. |
| CA-007 | UNDETERMINED segue para RAG. |
| CA-008 | IN_SCOPE segue para RAG. |
| CA-009 | RAG executa antes do LLM. |
| CA-010 | /gateway/core é utilizado. |
| CA-011 | recuperar-contexto-indice é utilizado. |
| CA-012 | index_id é o identificador principal. |
| CA-013 | agent_id legado é aceito como fallback. |
| CA-014 | AgentState declara scope_result. |
| CA-015 | AgentState declara rag_context. |
| CA-016 | AgentState declara rag_result. |
| CA-017 | NO_CONTEXT não chama LLM. |
| CA-018 | INFRA_ERROR não chama LLM. |
| CA-019 | SUCCESS com chunks chama LLM. |
| CA-020 | context_precision permanece observacional. |
| CA-021 | Score baixo não bloqueia silenciosamente. |
| CA-022 | Tool Calling não decide o RAG. |
| CA-023 | RAG possui tracing explícito. |
| CA-024 | Validators pós-LLM continuam no caminho de geração. |
| CA-025 | Fast-exits passam pelo middleware de saída. |
| CA-026 | Existem três respostas configuráveis e distintas. |
| CA-027 | Os três fast-exits retornam HTTP 200. |
| CA-028 | tool_calls_made permanece no schema com valor zero. |
| CA-029 | Parser definitivo usa schema real. |
| CA-030 | Nenhum SLO quantitativo é inventado. |
| CA-031 | Memória permanece fora da entrega. |
| CA-032 | /health/live permanece funcional. |
| CA-033 | /health/ready permanece local e funcional. |
| CA-034 | /metrics permanece disponível e compatível. |
| CA-035 | Python 3.11 é o runtime normativo, sujeito à confirmação dos manifests ativos. |
| CA-036 | O template permanece genérico e sem taxonomia fixa de educação financeira. |

---

## 27. Matriz de rastreabilidade

| Decisão arquitetural | Requisitos | Testes/aceite |
|---|---|---|
| Segurança antes do domínio | RF-001, RN-001, RNF-004 | testes de middleware, CA-001 |
| Scope Gate antes do RAG | RF-002 a RF-006, RN-002 a RN-004 | testes de topologia, CA-002 a CA-008 |
| RAG estrutural | RF-007 a RF-009, RN-005 a RN-009 | testes RAG/grafo, CA-009 a CA-019 |
| State explícito | RF-007, INT-004 | testes de schema, CA-014 a CA-016 |
| Contrato GeneraBB | RF-006, RF-007, RF-019, INT-003 | testes do adapter, CA-010 a CA-013 |
| Três resultados externos | RF-013, RN-010, INT-002 | testes fast-exit, CA-026/CA-027 |
| Observabilidade sem Tool callback | RF-018, INT-006, RNF-006 | testes de span, CA-023 |
| Compatibilidade HTTP | RF-014 a RF-016, INT-001, INT-005, RNF-003 | testes HTTP/operacionais, CA-028/CA-032 a CA-034 |
| Não inventar SLOs | RN-012, RNF-008 | revisão documental, CA-030 |
| Template genérico | RF-003, RN-014, RNF-010 | testes com políticas/índices distintos, CA-036 |

---

## 28. Pendências e limitações de evidência

### Confirmado pela arquitetura

- Topologia de segurança, escopo, RAG e geração.
- Estados de escopo e RAG.
- Contrato GeneraBB alvo.
- Separação semântica dos três fast-exits.
- Ausência de memória nesta entrega.
- Ausência de SLOs inventados.

### Não evidenciado ou pendente

- Schema real de retrieved_contexts.
- Taxonomia e corpus da ScopePolicy de educação financeira.
- Prompt final aprovado.
- Textos finais das três respostas.
- Valores reais de secrets, UOR e user_id.
- Commit/branch de origem da cópia inspecionada.
- Resultado de execução da suíte nesta sessão.
- Alinhamento efetivo do aic.json ativo com Python 3.11, pois o arquivo observado contém 3.8.
- Imagem final ativa, pois a cópia observada usa imagem corporativa bb/dev/dev-python:3.11.6 e não python:3.11-slim.

---

## 29. Regras para agentes de IA implementadores

O agente de IA que usar este SRS deve:

1. tratar a V2 como target e o código como baseline;
2. não reconstruir decisões arquiteturais já fechadas;
3. não inventar schema de payload, taxonomia, prompt, mensagens ou SLO;
4. implementar interfaces e testes com doubles quando um gate estiver aberto;
5. registrar qualquer nova decisão fora deste SRS;
6. preservar os contratos HTTP e endpoints operacionais;
7. distinguir erro técnico de ausência documental;
8. não chamar LLM sem chunks;
9. não usar LLM para bloqueio determinístico de escopo;
10. nunca registrar secrets, PII ou chunks completos por conveniência;
11. relatar explicitamente quando uma validação de runtime não tiver sido executada;
12. não considerar um teste ou exemplo isolado como prova do sistema inteiro.

---

## 30. Itens proibidos

É proibido, nesta versão:

- implementar parsing heurístico de retrieved_contexts;
- inventar taxonomia de educação financeira;
- inventar prompt ou textos negociais finais;
- usar RAG como Tool no A0;
- criar ToolMessage fictício para tool_calls_made;
- chamar LLM em NO_CONTEXT ou INFRA_ERROR;
- tratar UNDETERMINED como OUT_OF_SCOPE;
- usar LLM generativo como Scope Gate determinístico;
- expor secrets, PII, chunks ou stack traces em telemetria/resposta;
- criar SLO quantitativo sem aprovação;
- transformar timeout em SLO;
- adicionar MCP, memória, cache, retry ou streaming sem decisão adicional;
- declarar como baseline confirmado algo que o workspace não comprovou.

---

## 31. Regra final

O Agente A0 Informacional V2 deve executar:

~~~text
Segurança
→ Escopo determinístico
→ Evidência RAG
→ Geração condicionada
~~~

Toda entrada não rejeitada por segurança ou escopo deve consultar o RAG antes de qualquer geração. O LLM somente pode sintetizar contexto recuperado. Fora de escopo, ausência documental e indisponibilidade técnica são estados distintos, com respostas distintas e guardrails de saída preservados.

O template deve continuar reutilizável. A instância de educação financeira só pode ser aceita e promovida quando GATE-001, GATE-002, GATE-003 e GATE-004 estiverem fechados com evidência rastreável.
