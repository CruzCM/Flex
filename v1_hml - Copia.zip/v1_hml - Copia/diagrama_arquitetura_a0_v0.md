# Diagrama da Arquitetura A0 (Com Telemetria e Guardrails)

Este diagrama reflete o fluxo de processamento validado localmente, detalhando as regras de segurança, o controle de escopo, a recuperação (RAG) e a malha completa de observabilidade (Métricas e Spans do OpenTelemetry) atrelada a cada etapa funcional.

```mermaid
flowchart TD
    %% Estilização do Diagrama
    classDef endpoint fill:#f3e5f5,stroke:#4a148c,stroke-width:2px,color:#000
    classDef guardrail fill:#ffebee,stroke:#b71c1c,stroke-width:2px,color:#000
    classDef langgraph fill:#e3f2fd,stroke:#0d47a1,stroke-width:2px,color:#000
    classDef external fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#000
    classDef obs fill:#e0f2f1,stroke:#00695c,stroke-width:2px,stroke-dasharray: 5 5,color:#000

    %% ==========================================
    %% 1. ENTRADA E MIDDLEWARE HTTP
    %% ==========================================
    API["<b>API REST: POST /chat</b><br/>Input: { message, session_id }"]:::endpoint
    
    APIObs["<b>Métricas de Saúde (app.py)</b><br/>Rota: GET /metrics<br/>- uptime_seconds<br/>- total_requests"]:::obs
    API -.- APIObs

    Middleware["<b>Guardrails de Entrada (Middleware)</b><br/>1. Limite de Tamanho (4096)<br/>2. Anti-Injeção/Jailbreak<br/>3. Bloqueio de PII na Entrada<br/>4. Genera Safe (Desligado)<br/><br/><i>Em caso de bloqueio:<br/>Retorna HTTP 400 com <b>Mensagem Segura</b> fixa</i>"]:::guardrail
    
    MidObs["<b>Observabilidade Middleware</b><br/><u>Métricas OTel:</u><br/>agent.guardrails.requests / blocks / redactions / latency<br/><u>Span OTel:</u> <b>guardrails.middleware.chat</b><br/><i>Attrs: blocked, blocked_layer, blocked_code, output_redacted, latency_ms</i>"]:::obs
    
    API --> Middleware
    Middleware -.- MidObs

    %% ==========================================
    %% 2. ESCOPO (LangGraph)
    %% ==========================================
    Scope["<b>Nó: scope_gate_node</b><br/>Executa: KeywordScopePolicy.evaluate()"]:::langgraph
    
    ScopeObs["<b>Observabilidade de Escopo</b><br/><u>Span OTel:</u> <b>ScopePolicy.evaluate</b><br/><i>Attrs: scope.result, scope.policy_version</i>"]:::obs
    
    Middleware --> Scope
    Scope -.- ScopeObs

    CondScope{"Qual o<br/>scope_result?"}
    Scope --> CondScope

    OOS["<b>Fast-Exit: OUT_OF_SCOPE</b><br/>(Bloqueio direto antes do RAG)<br/><br/><i>Injeta <b>Mensagem Segura</b> configurada:<br/>(cfg.responses.out_of_scope)</i>"]:::langgraph
    CondScope -- "OUT_OF_SCOPE" --> OOS

    %% ==========================================
    %% 3. RECUPERAÇÃO DE CONTEXTO (RAG)
    %% ==========================================
    Retrieve["<b>Nó: retrieve_context_node</b><br/>Chama infraestrutura de RAG"]:::langgraph
    CondScope -- "IN_SCOPE<br/>UNDETERMINED" --> Retrieve
    
    Genera["<b>API do Genera BB</b><br/>(/gateway/core)"]:::external
    Retrieve --> Genera
    
    RAGObs["<b>Observabilidade RAG</b><br/><u>Span OTel:</u> <b>RAG.gateway_core</b><br/><i>Attrs: rag.result, rag.chunk_count, rag.duration_ms, rag.error</i>"]:::obs
    Retrieve -.- RAGObs

    Precision["<b>Nó: context_precision_node</b><br/>Executa: ContextPrecisionValidator<br/>(LLM-Juiz)"]:::langgraph
    PrecisionObs["<b>Observabilidade Validador (Precisão)</b><br/><u>Span OTel:</u> <b>validate.context_precision</b><br/><i>Attrs: validator.passed, score, action, duration_ms</i>"]:::obs
    
    Genera --> Precision
    Precision -.- PrecisionObs

    CondRAG{"Qual o<br/>rag_result?"}
    Precision --> CondRAG

    NoCtx["<b>Fast-Exit: NO_CONTEXT</b><br/><i>Injeta <b>Mensagem Segura</b> configurada:<br/>(cfg.responses.no_context)</i>"]:::langgraph
    ErrCtx["<b>Fast-Exit: INFRA_ERROR</b><br/><i>Injeta <b>Mensagem Segura</b> configurada:<br/>(cfg.responses.unavailable)</i>"]:::langgraph
    CondRAG -- "NO_CONTEXT" --> NoCtx
    CondRAG -- "INFRA_ERROR" --> ErrCtx

    %% ==========================================
    %% 4. LLM E VALIDADORES
    %% ==========================================
    LLM["<b>Nó: llm_call</b><br/>Chama modelo: gateway_outbound"]:::langgraph
    
    LLMObs["<b>Observabilidade LLM</b><br/><u>Span OTel:</u> <b>LLM.generate</b><br/><i>Attrs: llm.result, llm.duration_ms</i>"]:::obs
    
    CondRAG -- "SUCCESS" --> LLM
    LLM -.- LLMObs

    PostVal["<b>Validadores Pós-LLM</b><br/>- ToxicityValidator<br/>- NonAdviceValidator<br/>- PIIValidator"]:::langgraph
    
    PostValObs["<b>Observabilidade Validadores Internos</b><br/><u>Métricas OTel:</u> agent.validators.(validation_counter, pass_counter, fail_counter, score_histogram, validation_latency)<br/><u>Spans OTel:</u> <b>validate.{nome_do_validador}</b><br/><i>Attrs: validator.passed, score, action, duration_ms</i>"]:::obs
    
    LLM --> PostVal
    PostVal -.- PostValObs

    %% ==========================================
    %% 5. SAÍDA (MIDDLEWARE)
    %% ==========================================
    OutGuard["<b>Guardrails de Saída (Middleware)</b><br/>1. Blocklist de Saída <br/><i>(Substitui texto infrator por <b>Mensagem Segura</b>)</i><br/><br/>2. Redação de PII ([CPF], etc)"]:::guardrail
    OutGuard -.- MidObs
    
    OOS --> OutGuard
    NoCtx --> OutGuard
    ErrCtx --> OutGuard
    PostVal --> OutGuard

    Resp["<b>Resposta Final (HTTP 200)</b><br/>Output: { reply, session_id }"]:::endpoint
    OutGuard --> Resp
```
