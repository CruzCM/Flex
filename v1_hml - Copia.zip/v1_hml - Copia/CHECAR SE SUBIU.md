  ### 1. Como verificar o status do Domínio no Argo CD

  A verificação do domínio não é feita na caixa do Ingress padrão, mas sim em um recurso customizado do banco chamado DnsIngress (ou com a sigla DI). É nela que o banco executa a automação para registrar o
  seu domínio na rede.

  Se você clicar na caixa do DnsIngress e for até o final da aba Live Manifest:

  • No ambiente de Desenvolvimento: Você vai ver o erro de infraestrutura: description: Falha ao executar... Erro: ErrImagePull.
  • No ambiente de Homologação: Você vai ver a mensagem de sucesso: description: Container apb executado com sucesso.
  ──────
  ### 2. Como testar via Insomnia

  Baseado no Catálogo de IAs, a configuração no Insomnia é extremamente simples e não exige configuração manual de certificados, pois o Gateway faz essa ponte.

  1. Método e URL:
      • Crie uma nova requisição do tipo POST.
      • URL: https://iaa-agent-mf-edu-fin.ai-interno.api.hm.bb.com.br/v1/chat
  2. Autenticação (App Key):
      • O Catálogo de IAs gerou a seguinte chave para o ambiente HML: c0c0ec20e62f47f98edbd41f7dabb243.
      • Na aba Query do Insomnia (ou diretamente na URL), adicione o parâmetro:
          • Name: gw-dev-app-key
          • Value: c0c0ec20e62f47f98edbd41f7dabb243

  3. Body:
      • Vá na aba Body, escolha o formato JSON e envie o payload que o seu agente espera. Exemplo:
        {
          "message": "Olá",
          "session_id": "123"
        }

  4. Envio:
      • Envie a requisição. O Gateway validará a chave e fará a ponte segura (mTLS) até o seu agente.

  ──────
  ### 3. Como habilitar e acessar o Swagger

  Sim, é possível acessar o Swagger diretamente pela URL interna (https://agent-mf-edu-fin.iaa.hm.bb.com.br), mas por padrão ele fica desligado no seu código.

  No manifesto do seu Argo CD, a variável de ambiente está definida assim:

    - name: ENABLE_SWAGGER
      value: 'false'

  Passo a passo para ligar o Swagger:

  1. Vá no repositório de deploy do seu projeto.
  2. No arquivo values.yaml, procure pela seção de variáveis de ambiente (env ou configuração similar).
  3. Altere o valor de ENABLE_SWAGGER para "true".
  4. Faça o commit/push e aguarde o Argo CD sincronizar a mudança.
  5. Após o deploy, estando conectado na VPN do banco, abra o navegador e acesse a sua URL interna acrescida do caminho da documentação (geralmente https://agent-mf-edu-fin.iaa.hm.bb.com.br/docs ou /swagger).
  ──────
  ### 4. Como testar via cURL no WSL

  O comando curl no WSL fará exatamente a mesma coisa que o Insomnia, passando a chave de aplicação diretamente na URL e enviando o JSON no corpo da requisição.

  Aqui está o comando completo (você pode copiar, colar no terminal do WSL e dar Enter):

    curl -X POST "https://iaa-agent-mf-edu-fin.ai-interno.api.hm.bb.com.br/v1/chat?gw-dev-app-key=c0c0ec20e62f47f98edbd41f7dabb243" \
         -H "Content-Type: application/json" \
         -d '{
               "message": "Olá, me ajude a organizar minhas finanças"
             }'

  Entendendo os parâmetros:

  • -X POST: Define que é uma requisição do tipo POST (conforme exigido pelo Catálogo de IAs).
  • URL e Query String: A URL contém o parâmetro ?gw-dev-app-key=... no final, que é a sua credencial para passar pelo Gateway. As aspas duplas (") em volta da URL inteira são obrigatórias no WSL/Linux para
  evitar que o terminal corte o comando no caractere ?.
  • -H "Content-Type: application/json": Avisa à API que o corpo da requisição é um JSON.
  • -d '{ ... }': É o corpo da requisição. Lembre-se de adaptar as chaves do JSON ("message") para o formato exato que o seu código Python espera receber.

------

  É exatamente assim que funciona:

  1. Se o cliente tiver alguma transação Agro no período, o código identifica isso e marca o cliente com a flag
  FL_TEM_MOV_AGRO = 'S'.
  2. Essa flag significa exatamente isso: "Este cliente possui transação Agro no período".
  3. Tendo essa coluna pronta, ele pode ser removido do radar a qualquer momento apenas aplicando esse filtro.

  A única observação importante é que o notebook em si não faz a exclusão final (ele não roda o WHERE FL_TEM_MOV_AGRO
  = 'N'). O papel do notebook radar_massivo_v9_r4.ipynb é justamente calcular e entregar a flag preenchida na tabela
  de resultados

  Assim, a tabela final é entregue com todos os clientes, e quem for consumir esses dados (um painel, uma API ou
  outro analista) tem o poder de aplicar o filtro FL_TEM_MOV_AGRO = 'N' para remover essas pessoas da base. Você
  entendeu perfeitamente a mecânica!

------------

 Pelo código desta cópia, as métricas efetivamente usadas são estas:

   Métrica da lista                                       Situação                                           Como é medida
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Context Precision                                      Ativa no caminho A0 quando o RAG retorna chunks    LLM-as-a-Judge, score de 0 a 1, limiar 0,3, apenas observacional
  ─────────────────────────────────────────────────────  ─────────────────────────────────────────────────  ────────────────────────────────────────────────────────────────────────
   Toxicity                                               Ativa após a geração                               Validator local baseado em padrões e similaridade
  ─────────────────────────────────────────────────────  ─────────────────────────────────────────────────  ────────────────────────────────────────────────────────────────────────
   NonAdvice                                              Ativa após a geração                               Detecta aconselhamento indevido
  ─────────────────────────────────────────────────────  ─────────────────────────────────────────────────  ────────────────────────────────────────────────────────────────────────
   PII Leakage                                            Ativa após a geração                               Validator PIIValidator; a saída também passa por redação no middleware
  ─────────────────────────────────────────────────────  ─────────────────────────────────────────────────  ────────────────────────────────────────────────────────────────────────
   Detect Jailbreak                                       Ativa como guardrail de entrada                    Detecta prompt injection/jailbreak; contabiliza bloqueios
  ─────────────────────────────────────────────────────  ─────────────────────────────────────────────────  ────────────────────────────────────────────────────────────────────────
   Tool Correctness                                       Apenas no fluxo legado                             Não é executada no A0 V2
  ─────────────────────────────────────────────────────  ─────────────────────────────────────────────────  ────────────────────────────────────────────────────────────────────────
   Tool Call Success / Efficiency / Output Utilization    Não implementadas no A0                            O A0 retorna tool_calls_made = 0

  As demais da lista — Answer Relevance, Average Precision, Context Recall, Context Relevance, Faithfulness, Hallucination, Usefulness, BLEU, ROUGE, METEOR, Hit Rate, Reciprocal Rank, F1, Exact Match, Bias etc.
  — não são calculadas atualmente.

  O ponto mais importante sobre o RAG é este: hoje usamos Context Precision, mas ela avalia a relevância dos chunks depois da recuperação. Ela não mede a qualidade da ordenação do índice nem comprova recall.
  Portanto:

  - Context Precision: usada, via judge LLM.
  - Context Recall: não usada.
  - Context Relevance: não usada como métrica independente.
  - Average Precision / Reciprocal Rank / Hit Rate: não usadas.
  - Faithfulness / Hallucination: não implementadas como métricas independentes.

  Além do score de context_precision, o RAG gera estes sinais de telemetria no span RAG.gateway_core:

  - rag.result: success, no_context ou infra_error;
  - rag.chunk_count: quantidade de chunks válidos;
  - rag.duration_ms: duração da chamada;
  - rag.error: somente categoria técnica segura em caso de erro.

  Esses sinais são atributos de tracing OpenTelemetry. Eles não aparecem no endpoint JSON /metrics, que atualmente expõe somente uptime_seconds, total_requests, agent_id e agent_name.

  Também existem métricas operacionais do middleware:

  - guardrail.requests;
  - guardrail.blocked;
  - guardrail.redactions;
  - guardrail.latency_ms.

  E métricas genéricas dos validators:

  - validator.invocations;
  - validator.passed;
  - validator.failed;
  - validator.score;
  - validator.latency_ms.

  O validator identifica o tipo pelo atributo validator.name, por exemplo context_precision, toxicity, non_advice ou pii.

  Há duas limitações relevantes:

  1. Nesta configuração, rag.enabled está false. Portanto, a instrumentação está implementada e testada localmente, mas a chamada RAG não ocorre na configuração atual; a readiness fica não pronta e o fluxo
     retorna indisponibilidade.

  2. Não há periodicidade configurada no código. As métricas são emitidas por requisição; a frequência de análise — diária, semanal, mensal ou sob demanda — precisa ser definida pelo processo operacional.

  Para o formulário, a seleção tecnicamente sustentada pelo código seria:

  - Context Precision;
  - Toxicity;
  - NonAdvice;
  - PII Leakage;
  - Detect Jailbreak.

  Tool Correctness só deve ser marcado se o formulário abranger também o construtor legado, pois ele não participa do A0 V2.

  Sobre curadoria humana, o código comprova mecanismos automatizados, mas não comprova revisão humana total, por amostragem ou sob demanda. Essa escolha depende do processo operacional e dos responsáveis. A
  implementação atual não contém nomes de funcionários nem agenda de curadoria.

  Referências: RAG adapter (iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/rag/rag_tool.py:90), Context Precision (iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/validators/context_precision.py:130), métricas
  dos validators (iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/validators/__init__.py:35) e métricas dos guardrails (iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/guardrails_middleware.py:35).
  ----------------------------------------------------------------

  • Para testar oficialmente, é necessário sair da validação local e executar um plano controlado no ambiente corporativo autorizado. Os 215 testes locais comprovam apenas esta cópia do código; não comprovam
  contrato, autenticação, imagem implantada, disponibilidade do GeneraBB ou comportamento do Gateway LLM.

  O procedimento mínimo é:

  1. Fechar as evidências de configuração

     Confirmar, no ambiente e na versão implantada:
      - commit, imagem e digest;
      - Python efetivo 3.11;
      - dependências instaladas;
      - agent_config.yaml montado;
      - scope.enabled, versão da política e corpus aprovado;
      - prompt e três mensagens aprovados;
      - rag.enabled: true;
      - index_id, UOR, user_id, timeout e total_context;
      - credenciais e certificados fornecidos por secret manager corporativo.

     Os valores reais não devem ser colocados no código, nos testes ou no relatório.

  2. Fechar o GATE-001 do RAG

     Obter um payload real sanitizado, identificando projeto, ambiente, data, origem e contrato. Confirmar especialmente:
      - endpoint /gateway/core;
      - action recuperar-contexto-indice;
      - posição de data.retrieved_contexts;
      - campo passage_text;
      - resposta vazia;
      - item estruturalmente inválido;
      - timeout;
      - HTTP 4xx/5xx;
      - erro de conexão e JSON inválido.

     Sem essa evidência, o parser está apenas baseado na documentação disponível.

  3. Executar testes funcionais reais

     Com um índice de homologação e dados controlados, executar pelo menos:
      - pergunta fora do escopo;
      - pergunta dentro do escopo com contexto;
      - pergunta indeterminada com contexto;
      - ausência documental;
      - indisponibilidade do RAG;
      - contexto estruturalmente inválido;
      - resposta gerada fundamentada nos chunks;
      - score baixo de Context Precision;
      - falha do judge;
      - tentativa de prompt injection;
      - entrada com PII;
      - saída com PII;
      - conteúdo de aconselhamento indevido;
      - preservação de session_id;
      - tool_calls_made = 0.

     Confirmar que OUT_OF_SCOPE não chama RAG nem LLM e que NO_CONTEXT/INFRA_ERROR não chamam geração.

  4. Validar as métricas do RAG no backend real

     Não basta o span existir no código. É preciso confirmar no Application Insights, collector ou backend corporativo efetivamente usado que chegam:
      - span RAG.gateway_core;
      - rag.result;
      - rag.chunk_count;
      - rag.duration_ms;
      - categoria de rag.error, quando aplicável;
      - validator.name = context_precision;
      - validator.score;
      - validator.passed;
      - duração do judge;
      - LLM.generate e sua duração.

     Também é necessário verificar que não aparecem query completa, chunks, PII, tokens, headers, credenciais ou stack traces.

     Atualmente o sistema mede Context Precision, mas não mede Context Recall, Average Precision, Hit Rate ou Reciprocal Rank. Para homologar essas métricas adicionais seria necessário definir um conjunto de
     perguntas com respostas/chunks relevantes esperados e implementar os cálculos correspondentes.

  5. Validar guardrails e segurança

     O time autorizado de Cibersegurança deve validar a efetividade dos guardrails, conforme o requisito citado no formulário e a IN-423. Isso deve abranger:
      - prompt injection e jailbreak;
      - PII;
      - conteúdo proibido;
      - aconselhamento financeiro indevido;
      - redação de saída;
      - comportamento fail-open/fail-closed dos componentes externos.

     A implementação local não substitui essa aprovação.

  6. Validar operação

     No ambiente corporativo, verificar:
      - /health/live sem dependência externa;
      - /health/ready com configuração válida;
      - /metrics;
      - coleta efetiva de traces e métricas;
      - ausência de conteúdo sensível;
      - fechamento/reuso de clientes HTTP;
      - comportamento após restart;
      - logs e alertas;
      - configuração de rollback.

  7. Formalizar aceite

     Registrar evidências para cada CA-001 a CA-036, fechar os quatro gates e obter responsáveis formais para:
      - contrato RAG;
      - prompt;
      - política/corpus de escopo;
      - mensagens funcionais;
      - segurança;
      - curadoria humana;
      - operação e rollback.

     A periodicidade de curadoria e monitoramento também precisa ser definida formalmente. O código emite sinais por requisição, mas não define se a análise será diária, semanal ou sob demanda.

  O resultado oficial só deve ser declarado quando houver evidência do ambiente implantado, contrato real do RAG, telemetria observada no backend corporativo, validação de segurança e aprovações dos quatro
  gates. Até lá, a classificação correta permanece NÃO VALIDADO CORPORATIVAMENTE.


  ------------------

  O trabalho local já está concluído: implementação, comentários, documentação e 215 testes aprovados. Para eu encerrar também a parte de aceite oficial, preciso destas informações:

  1. Escopo do encerramento
      - Finalizar somente a entrega local; ou
      - Finalizar também o aceite corporativo/homologação.

  2. GATE-001 — contrato RAG
      - Payload real sanitizado do GeneraBB;
      - ambiente, origem, data e versão do contrato;
      - confirmação do campo data.retrieved_contexts[*].passage_text.

     Não envie tokens, certificados ou credenciais.

  3. GATE-002 — prompt
      - versão aprovada;
      - responsável negocial;
      - evidência ou referência da aprovação.

  4. GATE-003 — escopo
      - confirmação da versão da política;
      - responsável pelo domínio;
      - aceite do corpus e das regras de casos indeterminados/mistos.

  5. GATE-004 — mensagens
      - confirmação das três mensagens finais;
      - responsável pela aprovação de conteúdo.

  6. Ambiente de execução
      - branch/commit;
      - imagem e digest;
      - confirmação do Python 3.11;
      - configuração implantada;
      - confirmação de que o RAG foi ativado no ambiente autorizado.

  7. Segurança e operação
      - aprovação dos guardrails pelo time responsável;
      - backend de observabilidade usado;
      - confirmação de que RAG.gateway_core, rag.result, rag.chunk_count, rag.duration_ms e context_precision foram recebidos sem conteúdo sensível;
      - plano e versão de rollback.

  8. Curadoria
      - escolher: total, por amostragem ou sob demanda;
      - periodicidade;
      - nomes e funções dos responsáveis.

----------------------------------

       ### 🏠 São Guardrails On-premises (Locais):

  Toda a execução dessas regras acontece internamente, sem sair do servidor ou fazer chamadas a outras APIs pela
  rede.

  • Limite de Tamanho da Entrada: Apenas checa a quantidade de caracteres na memória.
  • Anti-Injeção e Jailbreak: Usa uma lista de Expressões Regulares locais (ex: checando palavras como "ignore
  instructions", "jailbreak", etc).
  • Bloqueio e Redação de PII: Identifica CPFs, CNPJs e emails via padrões textuais e validadores matemáticos (módulo
  11) dentro do próprio código.
  • Blocklist de Saída: Outra lista local de expressões proibidas.
  • Validadores de Aconselhamento e Toxicidade: Utilizam padrões locais e cálculos embutidos de similaridade
  semântica para avaliar o risco na resposta.

  ### 🌐 NÃO é On-premises (Rede Externa):

  • Guardrail Externo / Genera Safe: Este é o único guardrail que envia ativamente a mensagem para fora do contexto
  da aplicação. O código usa a biblioteca httpx para fazer um "POST" de rede HTTP e consultar um serviço externo
  chamado curador-iagen.

  Portanto, a estratégia adotada no código analisado concentra o maior volume de detecção (PII, toxicidade,
  aconselhamento, injeções básicas) de forma 100% autossuficiente e on-premises, deixando apenas a verificação do
  Genera Safe condicionada ao funcionamento da rede externa.

────────────────────────────────────────────────────────────
> liste novamente todos

  Com base na validação local do código, aqui está a lista completa de todos os guardrails e de todas as métricas
  configurados no projeto, agora categorizados corretamente pela forma como operam.

  ### 🛡️ Todos os Guardrails

  Operação On-premises (100% Locais no Código)
  Estes guardrails não dependem de internet, APIs externas ou rede para funcionar:

  1. Limite de Tamanho da Entrada (input_too_long): Rejeita mensagens que ultrapassam um certo tamanho limite (padrão
  de 4096 caracteres).
  2. Anti-Injeção e Jailbreak (prompt_injection): Bloqueia entradas de usuário contendo padrões que tentem manipular
  o prompt ou o sistema (ex: tentar fazer o agente ignorar instruções).
  3. Bloqueio de PII na Entrada (pii_detected): Impede a entrada de mensagens que contenham Informações Pessoais
  (Emails, SSN, Cartões de Crédito, Telefones, CPFs e CNPJs), utilizando validações matemáticas para documentos
  brasileiros.
  4. Blocklist de Saída (output_blocklist): Impede que respostas geradas contendo frases ou padrões proibidos
  definidos internamente cheguem ao usuário, substituindo o texto por uma recusa padrão.
  5. Redação de PII na Saída (pii_redaction): Oculta automaticamente os dados pessoais gerados na resposta do modelo,
  substituindo-os por placeholders (como [CPF] ou [EMAIL]).
  6. Validador de Aconselhamento (NonAdviceValidator): Monitora a saída gerada para detectar se o modelo está dando
  conselhos inapropriados nas áreas médica, financeira ou legal, analisando similaridade semântica e padrões de texto.
  7. Validador de Toxicidade (ToxicityValidator): Avalia se o texto contém conteúdo nocivo, como ameaças, assédio,
  discurso de ódio ou incentivo à automutilação.

  Operação Externa (Depende de Rede)
  8. Guardrail Externo / Genera Safe (external_guardrail): Único guardrail que encaminha a mensagem para um avaliador
  fora da aplicação (serviço curador-iagen). Ele atua no modelo fail-open, ou seja, se a conexão cair, a mensagem do
  usuário não fica bloqueada.
  ──────
  ### 📊 Todas as Métricas

  Métricas Públicas da API (Endpoint GET /metrics)
  Métricas básicas sobre o estado do serviço:

  1. uptime_seconds: Segundos em que a aplicação se encontra ativa.
  2. total_requests: Quantidade total de requisições enviadas ao endpoint /chat.
  3. agent_id: O ID identificador do agente atual.
  4. agent_name: O nome descritivo do agente.

  Métricas Operacionais Internas (OpenTelemetry via Middleware)
  Métricas de observabilidade exportadas diretamente do funcionamento dos guardrails:
  5. guardrail.requests (Counter): Total absoluto de requisições de chat processadas e analisadas pelo middleware de
  segurança.
  6. guardrail.blocked (Counter): Total de intervenções/bloqueios realizados. Esta métrica carrega dados detalhados
  (dimensões) sobre se o bloqueio ocorreu na entrada ou na saída, e qual regra (code) o causou.
  7. guardrail.redactions (Counter): Quantidade de vezes em que a regra de Redação de PII precisou atuar para
  anonimizar uma resposta do modelo.
  8. guardrail.latency_ms (Histogram): Registro do tempo de processamento gasto exclusivamente pela esteira de
  guardrails a cada requisição (latência da segurança).



 Não, o RAG não ficou sem métricas. Com base na validação do código local, as métricas e a observabilidade do RAG foram apenas reestruturadas e melhoradas com o uso do OpenTelemetry (OTel), e divididas em
  dois processos distintos dentro e fora da estrutura antiga de ferramentas (Tools):

  ### 1. Métricas Operacionais (Fora do formato antigo de Tool)

  No fluxo principal atual (conhecido no código como A0 determinístico), o RAG parou de ser invocado pelo modelo como uma "ferramenta" (no ToolNode do LangGraph). Em vez disso, ele virou um nó estrutural
  fixo (retrieve_context_node).

  Por causa disso, as métricas de operação foram embutidas diretamente no cliente de rede (_call_gateway dentro do rag_tool.py). A cada requisição, ele cria um bloco de rastreamento do OpenTelemetry (Span
  chamado "RAG.gateway_core") que registra:

  • rag.result: Se deu sucesso, se voltou vazio (no_context) ou se houve erro técnico (infra_error).
  • rag.chunk_count: Quantos fragmentos de texto úteis foram retornados.
  • rag.duration_ms: O tempo exato de resposta da API do RAG.
  • rag.error: O motivo detalhado em caso de falha (ex: timeout, connection, http_503).

  ### 2. Métricas de Qualidade (Ainda dentro do LangGraph)

  A métrica que avalia se os documentos recuperados pelo RAG são realmente bons e úteis para a pergunta do usuário continua atrelada ao grafo, mas de uma forma muito mais segura.

  O código implementa um nó dedicado no LangGraph chamado context_precision_node (que executa o ContextPrecisionValidator). Esse nó usa uma técnica chamada LLM-as-a-judge (um LLM atuando como juiz) para ler
  o texto recuperado e gerar uma métrica de precisão (Context Precision).

  A grande mudança aqui é que essa métrica qualitativa passou a ser apenas observacional. O código deixa claro que, mesmo que o LLM-juiz falhe (por lentidão ou erro), o grafo apenas gera um aviso nos logs
  ("Context precision indisponível: judge_error") e deixa o fluxo principal seguir em frente, não bloqueando a resposta para o usuário.

  Resumindo: O RAG está amplamente monitorado. As métricas de performance/infraestrutura foram coladas diretamente na chamada de rede (via OpenTelemetry), enquanto a métrica de qualidade/precisão continua
  dentro do LangGraph, rodando de forma assíncrona para não quebrar o robô se houver algum erro de avaliação.
  
  -----

    Status da Validação: NÃO VALIDADO CORPORATIVAMENTE / BLOQUEADO POR AMBIENTE.

  O que foi verificado localmente: Procurei por manifestos de infraestrutura (Helm charts, arquivos YAML de Kubernetes/OpenShift) no workspace atual para determinar exatamente como o deploy é feito. Eles não
  estão presentes nesta cópia do projeto.
  O que permanece desconhecido: O método exato de injeção no ambiente corporativo (por exemplo, se vocês usam Argo CD, HashiCorp Vault, ExternalSecrets ou outro pipeline automatizado para criar esses
  recursos no OpenShift).

  Apesar dessa limitação, com base nas anotações encontradas localmente no arquivo .env.example e na arquitetura padrão do OpenShift, a recomendação técnica para o cadastro é a seguinte:

  ### 1. Devem ser cadastrados como Secrets (Segredos)

  O OpenShift exige que dados sensíveis fiquem isolados em recursos do tipo Secret. No .env.example, há a indicação explícita de que os arquivos de mTLS são "Obtidos nas secrets do container provisionado da
  aplicação".

  • Certificados mTLS e CA: Os conteúdos físicos dos arquivos apontados por KEY_STORE_CERT_PATH, KEY_STORE_KEY_PATH e TRUST_STORE_CA_PATH devem virar Secrets montados como volumes (arquivos físicos) dentro
  do container.
  • Chaves e Tokens: O GATEWAY_OUTBOUND_GW_APP_KEY, RAG_CLIENT_ID, GUARDRAIL_EXTERNAL_CLIENT_ID e a APPLICATION_INSIGHTS_CONNECTION_STRING devem ser cadastrados em Secrets e mapeados como variáveis de
  ambiente no Pod.

  ### 2. Podem ser cadastrados como ConfigMaps ou no manifesto do Deployment

  Variáveis que apenas dizem respeito à parametrização não-secreta da aplicação e do container podem ir em um ConfigMap ou diretamente nas diretivas de env do Deployment:

  • SERVICE_NAME e DEPLOY_ENV (Tags de observabilidade).
  • Os caminhos estáticos para os arquivos: as próprias variáveis KEY_STORE_CERT_PATH, KEY_STORE_KEY_PATH, TRUST_STORE_CA_PATH, bem como o REQUESTS_CA_BUNDLE e SSL_CERT_FILE (que apontam para diretórios
  dentro do Linux do container, como /etc/ssl/certs/...). O conteúdo é secreto, mas o caminho (string) não é.

  Para realizar esse cadastro no ambiente real, você dependerá do fluxo de infraestrutura corporativa aprovado pelo seu time (via repositório GitOps ou solicitação de provisionamento), o qual não consigo
  auditar daqui.

------------

 Para esta cópia do projeto, o caminho principal é exportar traces e métricas por OTLP para um Collector. A imagem já inicia a aplicação com opentelemetry-instrument, conforme o iaa-agent-mf-edu-fin-main/
  Dockerfile:69.

  ### Variáveis recomendadas

   Variável                       Valor sugerido                      Função
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   OTEL_SERVICE_NAME              iaa-agent-mf-edu-fin                Nome padrão do recurso OpenTelemetry
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   SERVICE_NAME                   iaa-agent-mf-edu-fin                Nome acrescentado pelo próprio código às métricas
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   DEPLOY_ENV                     hml                                 Ambiente acrescentado às métricas
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   OTEL_EXPORTER_OTLP_ENDPOINT    http://<collector>:4317             Destino do Collector
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   OTEL_EXPORTER_OTLP_PROTOCOL    grpc                                Torna explícito que a porta 4317 usa OTLP/gRPC
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   OTEL_TRACES_EXPORTER           otlp                                Exporta traces
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   OTEL_METRICS_EXPORTER          otlp                                Exporta métricas
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   OTEL_LOGS_EXPORTER             none                                Evita exportar logs automaticamente; use otlp se isso for desejado
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   OTEL_PYTHON_EXCLUDED_URLS      health/live,health/ready,metrics    Exclui as rotas operacionais da instrumentação automática
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   OTEL_SDK_DISABLED              false ou ausente                    Mantém o SDK habilitado
  ─────────────────────────────  ──────────────────────────────────  ────────────────────────────────────────────────────────────────────
   OTEL_LOG_LEVEL                 error; temporariamente debug        Verbosidade interna do OTel

  OTEL_K8S_NODE_IP não é uma variável padrão do OpenTelemetry. É apenas um auxiliar do Kubernetes para construir o endpoint usando o IP do nó.

  A configuração em deploy-iaa-agent-mf-edu-fin-cloud-homologacao/values.yaml:42 pode ficar assim:

  environments:
    - name: OTEL_K8S_NODE_IP
      valueFrom:
        fieldRef:
          fieldPath: status.hostIP

    - name: OTEL_EXPORTER_OTLP_ENDPOINT
      value: "http://$(OTEL_K8S_NODE_IP):4317"

    - name: OTEL_EXPORTER_OTLP_PROTOCOL
      value: "grpc"

    - name: OTEL_TRACES_EXPORTER
      value: "otlp"

    - name: OTEL_METRICS_EXPORTER
      value: "otlp"

    - name: OTEL_LOGS_EXPORTER
      value: "none"

    - name: OTEL_SERVICE_NAME
      value: "iaa-agent-mf-edu-fin"

    - name: SERVICE_NAME
      value: "iaa-agent-mf-edu-fin"

    - name: DEPLOY_ENV
      value: "hml"

    - name: OTEL_PYTHON_EXCLUDED_URLS
      value: "health/live,health/ready,metrics"

  O valor atual v1/health/.*,metrics não corresponde às rotas reais /health/live e /health/ready. Além disso, a variável exclui instrumentação dessas URLs, não apenas métricas, como sugere o comentário do
  arquivo. Essa é a semântica documentada pela instrumentação automática Python.

  ### Application Insights direto

  Há uma inconsistência no projeto:

  - A variável oficial da Azure é APPLICATIONINSIGHTS_CONNECTION_STRING, sem sublinhado entre APPLICATION e INSIGHTS. Documentação da Microsoft.
  - O código desta cópia lê APPLICATION_INSIGHTS_CONNECTION_STRING, com sublinhado, em iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/tracing.py:31 e iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/
    graph.py:46.

  Sem alteração de código, a solução conservadora é manter a connection string no Secret com o nome oficial e criar um alias para o nome esperado pela aplicação:

  environments:
    - name: APPLICATION_INSIGHTS_CONNECTION_STRING
      valueFrom:
        secretKeyRef:
          name: env
          key: APPLICATIONINSIGHTS_CONNECTION_STRING

  envFrom:
    - secretRef:
        name: env

  Assim, os dois nomes ficam disponíveis, usando o mesmo valor armazenado no Secret. Não coloque a connection string literalmente no values.yaml.

  Nesse projeto, a exportação direta para Azure envia somente traces. As métricas continuam saindo por OTLP, conforme iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/tracing.py:34. Se o Collector já
  encaminha traces ao mesmo Application Insights, habilitar também o exporter direto pode gerar duplicidade; isso está NÃO VALIDADO CORPORATIVAMENTE, pois depende da configuração externa do Collector.

  OTEL_RECORD_CONTENT pode ser removida da configuração: o callback atual força enable_content_recording=False, independentemente dessa variável.

  Todas essas variáveis devem existir antes de iniciar o processo, pois várias são lidas durante a importação dos módulos. Depois de alterá-las, é necessário reiniciar o pod/processo.

  A análise do código e dos manifestos é uma VALIDAÇÃO LOCAL. O endpoint $(OTEL_K8S_NODE_IP):4317, o Collector e a chegada dos dados ao backend corporativo permanecem NÃO VALIDADOS CORPORATIVAMENTE. Também
  identifiquei uma connection string literal em DEPLOY HML.txt; não reproduzi o valor e recomendo tratar esse arquivo histórico como material sensível.


  -------------------

    ### 1. RAG (Recuperação de Contexto) - rag_tool.py

  • Span: RAG.gateway_core (Rastreia a chamada direta à API do Genera BB)
  • Atributos salvos neste Span:
      • rag.result: Resultado final (ex: success, no_context, infra_error).
      • rag.chunk_count: Quantidade de trechos (documentos) aproveitáveis retornados.
      • rag.duration_ms: Tempo total da requisição em milissegundos.
      • rag.error: Detalhe da categoria do erro (somente preenchido quando ocorre falha de infraestrutura).


  ### 2. LLM (Geração de Texto) - graph.py

  • Span: LLM.generate (Rastreia o tempo e o sucesso da chamada ao modelo fundacional)
  • Atributos salvos neste Span:
      • llm.result: Status da chamada (success ou error).
      • llm.duration_ms: Tempo total de inferência do modelo em milissegundos.


  ### 3. Validação de Escopo (Scope Policy) - graph.py

  • Span: ScopePolicy.evaluate (Rastreia a validação de palavras-chave / tópicos)
  • Atributos salvos neste Span:
      • scope.result: Resultado da política (ex: se passou ou se foi considerado fora de escopo).
      • scope.policy_version: A versão da política textual utilizada (ex: mf-edu-fin-mvp-v1).


  ### 4. Guardrails (Proteções Externas) - guardrails_middleware.py

  • Métricas Agregadas (Metrics):
      • agent.guardrails.requests: Contador de quantas requisições passaram pelo middleware de proteção.
      • agent.guardrails.blocks: Contador de interrupções/bloqueios.
      • agent.guardrails.redactions: Contador de edições/redações (ex: ofuscação de PII) feitas na resposta.
      • agent.guardrails.latency: Histograma do tempo de resposta do serviço de guardrail.
  • Span: guardrails.middleware.chat
  • Atributos salvos neste Span:
      • guardrail.blocked: Se a requisição/resposta foi bloqueada (True).
      • guardrail.blocked_layer: Qual camada acionou o bloqueio.
      • guardrail.blocked_code: Qual foi o código/motivo específico do bloqueio.
      • guardrail.output_redacted: Indica se houve remoção de dados sensíveis na saída (True).
      • guardrail.latency_ms: Tempo de resposta pontual deste guardrail.


  ### 5. Validadores Internos Genéricos - validators/__init__.py

  • Métricas Agregadas (Metrics):
      • agent.validators.validation_counter: Contador de total de validações acionadas.
      • agent.validators.validation_pass_counter: Contador de validações bem-sucedidas.
      • agent.validators.validation_fail_counter: Contador de validações que falharam.
      • agent.validators.validation_score_histogram: Histograma das notas/scores calculadas pelos validadores.
      • agent.validators.validation_latency: Histograma do tempo de processamento dos validadores internos.
  • Span: validate.{nome_do_validador} (O nome da Trace varia dinamicamente de acordo com a classe do validador sendo executada).
  • Atributos salvos neste Span:
      • validator.passed: Booleano indicando se a verificação passou.
      • validator.score: Pontuação de confiança gerada pela verificação.
      • validator.action: Qual foi a ação resultante (ex: rejeitar, aprovar).
      • validator.duration_ms: Duração do validador específico.


  (Observação: O código também garante que os textos dos usuários (inputs), histórico de chat e respostas puras não sejam adicionados aos logs e Spans por segurança/privacidade. Apenas métricas de telemetria
  baseadas em volume, tempo e categorias de erro são exportadas).

  -----------------

   ### 🎯 O que você precisa selecionar da lista:

  1. Context Precision
      • Onde está no código: O nó context_precision_node no LangGraph executa o ContextPrecisionValidator usando um LLM-juiz para avaliar a qualidade dos trechos recuperados pelo RAG.
  2. Tool Correctness
      • Onde está no código: O ToolCorrectnessValidator está instanciado no graph.py dentro do bloco ValidatingToolNode (usado para avaliar a exatidão das invocações de ferramentas).
  3. Toxicity
      • Onde está no código: O ToxicityValidator roda imediatamente após a resposta do LLM para procurar discursos de ódio, ameaças e assédio.
  4. NonAdvice
      • Onde está no código: O NonAdviceValidator atua junto com a toxicidade para penalizar se o agente estiver dando conselhos regulados (médicos, jurídicos ou financeiros).
  5. PII Leakage
      • Onde está no código: O projeto usa o PIIValidator nativo (com cálculos de módulo 11 para CPF/CNPJ) tanto para bloquear PII na entrada quanto para fazer a "Redação" (máscara) na saída do LLM.
  6. Detect Jailbreak
      • Onde está no código: Implementado no guardrails_middleware.py sob a função check_injection, que barra comandos maliciosos como "ignore instructions" ou "DAN".
  7. Topic Adherence
      • Onde está no código: Implementado pela KeywordScopePolicy (o famoso Scope Gate). Essa etapa testa deterministicamente se o usuário está perguntando sobre o "tópico" correto (Educação Financeira)
      antes de acionar o RAG.


  (A lista que você colou também possui métricas técnicas como Regex Match e String Presence, que descrevem mecanicamente como a Blocklist de Saída e o Anti-Injeção funcionam no código).
  ──────
  ### 🔍 Existe alguma no código que NÃO está na sua lista?

  Sim. A sua lista é focada exclusivamente em métricas de avaliação qualitativa de Inteligência Artificial, mas o código deste projeto também monitora Métricas Operacionais (Não-Funcionais) de sistema, que
  não aparecem na sua listagem. São elas:

  • Tamanho de Entrada (Input Length Limit): Regra de segurança estrutural que corta payloads com mais de 4096 caracteres antes do processamento.
  • Latência de Processamento (Latency): O código exporta histogramas explícitos (rag.duration_ms, llm.duration_ms, guardrail.latency_ms) via OpenTelemetry para medir gargalos de tempo.
  • Custo/Tamanho de Contexto (chunk_count): Mede o volume exato de fragmentos de texto recuperados da API do Genera BB por requisição.
  • Guardrail Externo / Content Moderation API: A integração com o Genera Safe (o juiz externo opcional) é um bloqueio corporativo centralizado, e não uma métrica calculada individualmente pelo modelo.


---

• Quando tiver a resposta real do Genera, coloque um exemplo JSON na pasta tests/fixtures/. Eu criaria um arquivo separado, como generabb_resposta_real_sanitizada.json, preservando o exemplo sintético atual.

  Retire credenciais e dados sensíveis, mas preserve nomes dos campos, tipos, listas e níveis do JSON. Informe também ambiente, data, operação chamada e status HTTP, para sabermos a qual contrato o exemplo
  pertence.

  Os três pontos do projeto são:

   Onde                                                                                                   Para que serve
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   iaa-agent-mf-edu-fin-main/tests/fixtures                                                               Guardar exemplos de respostas para comparação e testes locais
  ─────────────────────────────────────────────────────────────────────────────────────────────────────  ───────────────────────────────────────────────────────────────
   rag_tool.py — _extract_contexts (iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/rag/rag_tool.py:54)    Interpretar o retorno do Genera e extrair os textos
  ─────────────────────────────────────────────────────────────────────────────────────────────────────  ───────────────────────────────────────────────────────────────
   iaa-agent-mf-edu-fin-main/tests/unit/test_rag_tool.py:113                                              Verificar localmente se o retorno é interpretado corretamente

  Hoje o parser espera exatamente este caminho:

  {
    "data": {
      "retrieved_contexts": [
        {
          "passage_text": "Trecho recuperado do documento"
        }
      ]
    }
  }

  O comportamento atual é:

  - Textos válidos e não vazios → SUCCESS.
  - Lista vazia ou somente textos em branco → NO_CONTEXT.
  - Estrutura diferente ou item inválido → INFRA_ERROR.

  Campos adicionais podem existir, mas atualmente o parser aproveita apenas passage_text; IDs, fontes e scores não são preservados.

  Salvar o arquivo sozinho não executa a conferência. Depois, precisamos fazer o teste ler esse exemplo, comparar com o parser e só ajustar o código se houver divergência. Idealmente, traga exemplos de sucesso,
  ausência de contexto e erro.

  A fixture atual é sintética, conforme seu README. Um retorno real permitirá verificar a compatibilidade local com aquele exemplo; não comprovará sozinho toda a integração corporativa. Nada foi alterado.

---


• Sim: nesta configuração, o judge usa o mesmo modelo cambio-non-prod-gpt4o, pelo mesmo Gateway Outbound. São chamadas separadas, com prompts e parâmetros diferentes.

  O papel do judge é avaliar: “Os trechos recuperados pelo RAG são relevantes e suficientes para responder à pergunta?” Ele executa antes da geração, portanto não avalia a resposta final do agente.

   Característica        Judge                                                Gerador da resposta
  ━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Modelo configurado    cambio-non-prod-gpt4o                                cambio-non-prod-gpt4o
  ────────────────────  ───────────────────────────────────────────────────  ────────────────────────────────────────────────────
   Entrada               Pergunta + primeiros 500 caracteres de cada chunk    Instruções do agente + chunks completos + pergunta
  ────────────────────  ───────────────────────────────────────────────────  ────────────────────────────────────────────────────
   Saída esperada        JSON com nota e justificativa                        Resposta ao usuário
  ────────────────────  ───────────────────────────────────────────────────  ────────────────────────────────────────────────────
   temperature           0.0                                                  0.7
  ────────────────────  ───────────────────────────────────────────────────  ────────────────────────────────────────────────────
   top_p                 1.0                                                  0.95

  Essa separação está em iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/graph.py:177. Não existe hoje uma configuração de modelo exclusiva para o judge.

  Onde está o prompt?

  Em iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/validators/context_precision.py:27, diretamente no Python, em duas constantes:

  - _SYSTEM_PROMPT: instrui o modelo a ser um avaliador preciso e responder somente JSON válido.
  - _JUDGE_PROMPT: define os critérios de avaliação e recebe {query} e {chunks}.

  O prompt pede uma nota segundo esta escala:

   Nota de referência    Interpretação pedida
  ━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   1.0                   Contexto diretamente relevante e suficiente
  ────────────────────  ───────────────────────────────────────────────────
   0.7                   Majoritariamente relevante, com pequenas lacunas
  ────────────────────  ───────────────────────────────────────────────────
   0.4                   Parcialmente relevante, sem responder diretamente
  ────────────────────  ───────────────────────────────────────────────────
   0.1                   Majoritariamente irrelevante ou enganoso
  ────────────────────  ───────────────────────────────────────────────────
   0.0                   Sem relação com a pergunta

  São referências; o modelo pode retornar valores intermediários. O prompt instructions do agent_config.yaml é usado pelo gerador, não por esse judge.

  Qual é o contrato de saída?

  O conteúdo textual esperado na resposta do LLM é:

  {
    "score": 0.85,
    "reason": "Os trechos explicam como organizar o orçamento, mas não detalham a revisão mensal."
  }

  Esse exemplo é ilustrativo. O código transforma a resposta em um ValidationResult, equivalente a:

  {
    "validator_name": "context_precision",
    "score": 0.85,
    "passed": true,
    "action": "log_only",
    "details": "llm_judge",
    "metadata": {
      "reason": "Os trechos explicam como organizar o orçamento, mas não detalham a revisão mensal.",
      "chunk_count": 2,
      "method": "llm_as_judge_async"
    }
  }

  O passed é calculado pelo código: score >= 0.3. O LLM não precisa devolver esse campo.

  Há uma diferença entre o contrato solicitado e o efetivamente exigido pelo parser:

  - O JSON é solicitado pelo prompt; não há schema de saída estruturada imposto nessa chamada.
  - O parser aceita JSON puro ou cercado por blocos Markdown.
  - Converte score para número e limita o valor ao intervalo de 0 a 1.
  - score ausente resulta em 0.0; reason ausente resulta em texto vazio.
  - JSON inválido resulta em score = 0.0 e reason = "parse_error".
  - Se a chamada ao judge lançar uma exceção, o validator retorna score = 0.5, passed = true e sinaliza judge_error. Essa nota é um fallback técnico, não uma avaliação do modelo.

  O resultado não bloqueia a geração. Mesmo com nota baixa ou falha do judge, o fluxo continua. A nota e a aprovação vão para a telemetria; a justificativa fica nos metadados do resultado, mas atualmente o
  grafo não a persiste nem a envia como atributo OTel.

  Portanto, context_precision hoje é uma avaliação global do contexto por LLM, não uma medição por chunk nem uma comprovação de que a resposta final será correta. E, com rag.enabled: false no YAML atual, esse
  caminho não é alcançado. O modelo acima está confirmado na configuração local; sua execução corporativa não foi validada.