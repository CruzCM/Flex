# Fundamentos de IA e LLMs para Programadores

**Autoria:** Erick Wendel  
**Recorte deste arquivo:** do **Módulo 05: Inteligência artificial na Web — Capítulo 1: Algoritmos Genéticos** até o final do conteúdo textual do material.

> Conversão para Markdown com alteração editorial mínima: remoção apenas de cabeçalhos repetitivos de classificação (`Público`), recomposição de linhas quebradas pelo PDF e aplicação de hierarquia Markdown a módulos, capítulos, subtítulos e listas.

## Sumário

- [Módulo 05: Inteligência artificial na Web](#modulo-05-inteligencia-artificial-na-web)
  - [Capítulo 1: Algoritmos Genéticos](#modulo-05-inteligencia-artificial-na-web-capitulo-1-algoritmos-geneticos)
  - [Capítulo 2: Como funcionam LLMs: transformers, embeddings, attention](#modulo-05-inteligencia-artificial-na-web-capitulo-2-como-funcionam-llms-transformers-embeddings-attention)
  - [Capítulo 3: Como funciona inteligencia artificial na Web com Web AI](#modulo-05-inteligencia-artificial-na-web-capitulo-3-como-funciona-inteligencia-artificial-na-web-com-web-ai)
  - [Capítulo 4: Demo 02 - Web AI Multi Modal](#modulo-05-inteligencia-artificial-na-web-capitulo-4-demo-02-web-ai-multi-modal)
- [Módulo 06: Prompt Engineering](#modulo-06-prompt-engineering)
  - [Capítulo 1: Como escrever prompts que realmente geram boas respostas](#modulo-06-prompt-engineering-capitulo-1-como-escrever-prompts-que-realmente-geram-boas-respostas)
  - [Capítulo 2: Padrão TOON e JSON para Prompts](#modulo-06-prompt-engineering-capitulo-2-padrao-toon-e-json-para-prompts)
- [Módulo 07: Ferramentas de IA para acelerar sua vida como Dev](#modulo-07-ferramentas-de-ia-para-acelerar-sua-vida-como-dev)
  - [Capítulo 1: História e visão geral do Cursor, Comparando VSCode, Windsurf e Cursor](#modulo-07-ferramentas-de-ia-para-acelerar-sua-vida-como-dev-capitulo-1-historia-e-visao-geral-do-cursor-comparando-vscode-windsurf-e-cursor)
  - [Capítulo 2: O que são agentes de IA e como eles tomam decisões em etapas](#modulo-07-ferramentas-de-ia-para-acelerar-sua-vida-como-dev-capitulo-2-o-que-sao-agentes-de-ia-e-como-eles-tomam-decisoes-em-etapas)
- [Módulo 08: MCPs e Automação para Devs](#modulo-08-mcps-e-automacao-para-devs)
  - [Capítulo 1: O que são MCPs (Model Context Protocol) e como conectam IA com APIs/serviço](#modulo-08-mcps-e-automacao-para-devs-capitulo-1-o-que-sao-mcps-model-context-protocol-e-como-conectam-ia-com-apis-servico)
  - [Capítulo 2: Usando IA para: Gerar testes automatizados](#modulo-08-mcps-e-automacao-para-devs-capitulo-2-usando-ia-para-gerar-testes-automatizados)
  - [Capítulo 3: Usando IA para: Navegar em sites e extrair informações](#modulo-08-mcps-e-automacao-para-devs-capitulo-3-usando-ia-para-navegar-em-sites-e-extrair-informacoes)
  - [Capítulo 4: Usando IA para: Consultar documentações atualizadas](#modulo-08-mcps-e-automacao-para-devs-capitulo-4-usando-ia-para-consultar-documentacoes-atualizadas)
  - [Capítulo 5: Usando IA para: Colher dados de Telemetria de apps](#modulo-08-mcps-e-automacao-para-devs-capitulo-5-usando-ia-para-colher-dados-de-telemetria-de-apps)
- [Módulo 09: Modelos open-source vs. proprietários](#modulo-09-modelos-open-source-vs-proprietarios)
  - [Capítulo 1: Vantagens e desvantagens de modelos abertos e fechados](#modulo-09-modelos-open-source-vs-proprietarios-capitulo-1-vantagens-e-desvantagens-de-modelos-abertos-e-fechados)
  - [Capítulo 2: Como rodar modelos localmente com Ollama](#modulo-09-modelos-open-source-vs-proprietarios-capitulo-2-como-rodar-modelos-localmente-com-ollama)
  - [Capítulo 3: Como usar OpenRouter para orquestrar vários modelos](#modulo-09-modelos-open-source-vs-proprietarios-capitulo-3-como-usar-openrouter-para-orquestrar-varios-modelos)
- [Módulo 10: RAG, embeddings e busca semântica](#modulo-10-rag-embeddings-e-busca-semantica)
  - [Capítulo 1: O que é RAG (Retrieval-Augmented Generation) e por que ele é tão importante](#modulo-10-rag-embeddings-e-busca-semantica-capitulo-1-o-que-e-rag-retrieval-augmented-generation-e-por-que-ele-e-tao-importante)
  - [Capítulo 2: O que são Embeddings e Vector Databases](#modulo-10-rag-embeddings-e-busca-semantica-capitulo-2-o-que-sao-embeddings-e-vector-databases)
  - [Capítulo 3: Projeto: Criando o primeiro RAG com JavaScript e Neo4j](#modulo-10-rag-embeddings-e-busca-semantica-capitulo-3-projeto-criando-o-primeiro-rag-com-javascript-e-neo4j)

---

<!-- SOURCE_START -->
<!-- Página 51 do PDF -->
<a id="modulo-05-inteligencia-artificial-na-web"></a>
## Módulo 05: Inteligência artificial na Web

<a id="modulo-05-inteligencia-artificial-na-web-capitulo-1-algoritmos-geneticos"></a>
### Capítulo 1: Algoritmos Genéticos

Neste capítulo, exploramos os algoritmos genéticos como uma forma alternativa e fascinante de aprendizado de máquina. Esses algoritmos são inspirados na evolução biológica e são uma excelente maneira de encontrar soluções criativas para problemas complexos, especialmente quando não se tem uma resposta clara de como resolver determinada tarefa.

#### Inteligência artificial além do básico

Durante o módulo, vimos como usar IA para automatizar jogos como o Duck Hunt. Mas ali, a IA apenas reconhecia objetos na tela e apontava onde achava que estava o alvo. Não havia aprendizado de verdade, apenas reconhecimento. Para que uma IA realmente aprenda a vencer um jogo, entramos em outro tipo de abordagem: o aprendizado por reforço.

Essa é uma forma poderosa de aprendizado em que o algoritmo aprende por tentativa e erro, sendo recompensado por acertos e penalizado por erros. Um exemplo clássico é o jogo da cobrinha, onde a IA ganha pontos ao comer frutas e perde ao colidir com a parede ou com o próprio corpo. A cada movimento, ela recebe uma pontuação e aprende com isso.

#### O que são algoritmos genéticos

Os algoritmos genéticos seguem uma lógica diferente. Em vez de aprender sequencialmente, eles trabalham com uma população de soluções candidatas. Cada solução é avaliada, e as melhores são selecionadas para gerar novas soluções por meio de cruzamento e mutação.

Imagine que você é um inventor tentando criar a melhor roda para um carro. Você gera vários carros com formas e tamanhos diferentes e os coloca para rodar em uma pista. Aqueles que andam mais longe, mais rápido e com mais estabilidade são considerados melhores. Então você mistura as características <!-- Página 52 do PDF --> dos melhores carros e gera uma nova geração de carros. Esse processo é repetido várias vezes, com pequenas mutações introduzidas a cada nova geração.

#### Simulações e criatividade inesperada

O resultado desse processo pode ser surpreendente. Os carros gerados muitas vezes possuem formas incomuns que um humano jamais teria projetado, mas funcionam incrivelmente bem dentro dos critérios de avaliação. Isso acontece porque a evolução prioriza desempenho, não estética.

Na prática, você pode testar isso em simuladores que rodam no próprio navegador, onde é possível acompanhar a evolução de geração em geração. A cada nova geração, os resultados melhoram, os "carros" se adaptam melhor à pista, e o algoritmo vai encontrando soluções mais eficientes sem nenhuma instrução direta de como fazer isso.

#### Parâmetros e ajustes

Durante a simulação, você pode controlar parâmetros como taxa de mutação, gravidade, formato do terreno e outros fatores. Esses ajustes impactam diretamente a evolução dos indivíduos. Uma taxa de mutação muito alta pode gerar resultados imprevisíveis e ineficazes, enquanto uma mutação muito baixa pode causar estagnação, sem inovação.

O segredo está no equilíbrio: mutações suficientes para explorar novas possibilidades, mas com controle para manter o que já funciona bem. Esse tipo de ajuste fino é essencial em projetos de IA evolutiva.

#### Casos de uso e inspiração

O uso de algoritmos genéticos vai muito além de jogos. Eles são aplicáveis em problemas de engenharia, logística, design de circuitos, otimização de processos e muito mais. Existem casos em que AIs aprenderam a estacionar carros sozinhas, inclusive fazendo balizas com drift, tudo graças a esse tipo de algoritmo.

<!-- Página 53 do PDF --> Outro exemplo inspirador foi apresentado em uma conferência no Brasil, onde um algoritmo genético foi usado para ensinar uma IA a jogar o jogo do dinossauro do Chrome. A IA aprendeu a pular e se esquivar dos obstáculos sozinha, sem nenhuma instrução específica. Isso demonstra o potencial criativo dos algoritmos genéticos.

#### Diferenças com aprendizado por reforço

A principal diferença entre os algoritmos genéticos e o aprendizado por reforço está na forma como aprendem. O aprendizado por reforço envolve um agente que toma decisões sequenciais para maximizar uma recompensa acumulada ao longo do tempo. Já os algoritmos genéticos lidam com populações inteiras de soluções, avaliando, cruzando e mutando indivíduos até chegar à melhor solução.

Enquanto um foca na tomada de decisão passo a passo, o outro foca na evolução de candidatos simultaneamente.

#### Considerações finais

Com os algoritmos genéticos, você viu como é possível aplicar princípios de evolução natural para resolver problemas de forma criativa e eficiente. Trata-se de um campo fascinante que, mesmo com conceitos simples, oferece resultados incríveis e aplicações reais no mundo da tecnologia.

Recomendo que você explore os links indicados na aula e experimente ferramentas interativas baseadas nesses algoritmos. Brinque com os parâmetros, observe os resultados e imagine como essas técnicas poderiam ser aplicadas em problemas do seu dia a dia ou em desafios do mercado.

Nos vemos na próxima aula!

<a id="modulo-05-inteligencia-artificial-na-web-capitulo-2-como-funcionam-llms-transformers-embeddings-attention"></a>
### Capítulo 2: Como funcionam LLMs: transformers, embeddings, attention

<!-- Página 54 do PDF --> Neste capítulo, mergulhamos nos fundamentos das Large Language Models (LLMs), explicando como funcionam internamente tecnologias como o ChatGPT, Gemini e outras. O foco aqui é desvendar os principais componentes que tornam essas IAs tão poderosas: tokenização, embeddings, arquitetura transformer, attention e sampling.

#### O que são LLMs?

LLM é a sigla para "Large Language Model" ou Modelo de Linguagem de Grande Escala. Esses modelos são treinados com quantidades massivas de texto para aprender padrões da linguagem humana e gerar respostas coerentes. O termo GPT, como em ChatGPT, significa "Generative Pre-trained Transformer", e cada parte dessa sigla tem papel fundamental:

- Generative: o modelo é gerador de texto.
- Pre-trained: antes de responder perguntas, ele é treinado com muitos textos.
- Transformer: é a arquitetura de rede neural que torna tudo isso possível.

#### 1. Tokenização

Antes de um texto ser processado, ele é quebrado em unidades menores chamadas tokens. Esses tokens não são necessariamente palavras; podem ser partes de palavras, espaços, sinais de pontuação, etc. O modelo trabalha com esses tokens em vez de palavras completas, pois são mais eficientes para representar a linguagem.

Um ponto importante: uma palavra pode conter vários tokens. Por isso, quando um modelo limita um prompt a 4.000 tokens, isso não significa 4.000 palavras, e sim unidades menores.

#### 2. Embeddings

Uma vez que o texto é tokenizado, cada token é transformado em um vetor de números. Esses vetores, chamados de embeddings, representam o significado das palavras no contexto.

<!-- Página 55 do PDF --> Palavras que aparecem em contextos semelhantes acabam com embeddings semelhantes. Por exemplo:

- "Carro" e "veículo" costumam aparecer em frases similares e têm embeddings próximos.
- "Médico" e "hospital" não são sinônimos, mas aparecem juntos com frequência, e por isso têm relação semântica.

Essas representações vetoriais permitem que o modelo compreenda nuances como:

- Rei - Homem + Mulher = Rainha
- Paris - França + Itália = Roma

Esses cálculos funcionam porque relações semânticas recorrentes são transformadas em direções no espaço vetorial.

#### 3. Transformers e o mecanismo de Attention

Com os tokens convertidos em embeddings, o próximo passo é processar essas informações com a arquitetura Transformer. Essa é uma das maiores revoluções da IA moderna.

O Transformer utiliza um mecanismo chamado Self-Attention, que permite ao modelo considerar todas as palavras do contexto ao interpretar ou gerar cada token. Por exemplo, na frase:

"A Maria contou para a Ana que ela foi promovida."

O token "ela" pode se referir tanto à Maria quanto à Ana. O mecanismo de Attention ajuda o modelo a determinar qual referência faz mais sentido, considerando o contexto completo.

O Transformer também corrige limitações de modelos antigos, como a dificuldade em lidar com frases longas e o processamento sequencial. Ele processa todos os tokens em paralelo e entende relações de longa distância.

<!-- Página 56 do PDF --> Adicionalmente, o modelo adiciona positional encodings aos embeddings, já que os vetores por si só não carregam informação de ordem. Assim, frases como "o cachorro mordeu o homem" e "o homem mordeu o cachorro" são corretamente interpretadas.

#### 4. Probabilidades e Decoding

Depois que o Transformer processa os embeddings, ele gera uma lista de probabilidades para os próximos tokens possíveis.

Por exemplo, se a frase for:

"O céu é..."

O modelo pode atribuir:

- azul: 55%
- nublado: 18%
- claro: 10%
- bonito: 7%

Com base nessas probabilidades, o modelo escolhe um token. O método de escolha depende de parâmetros como:

- Temperature: define o grau de aleatoriedade. Valores baixos geram respostas mais determinísticas (menos criativas), valores altos aumentam a variedade.
- Top-K: limita a escolha aos K tokens mais prováveis.
- Top-P (nucleus sampling): soma as probabilidades até atingir um limiar, como 90%, e escolhe dentro desse subconjunto.

Esses parâmetros influenciam diretamente a qualidade e variedade das respostas geradas pela IA.

#### 5. Geração passo a passo (Sampling)

A IA não gera todo o texto de uma vez. Ela gera token por token, recalculando o contexto a cada nova palavra. Esse processo se chama sampling.

<!-- Página 57 do PDF --> A cada nova iteração:

1. A IA analisa o texto gerado até o momento.
2. Calcula a probabilidade dos próximos tokens.
3. Escolhe um novo token.
4. Adiciona esse token ao contexto.

Esse ciclo se repete até atingir o fim da resposta. Quanto maior o texto, maior o custo computacional.

#### Alucinações e Limitações

O modelo não sabe o que é verdade ou mentira. Ele apenas gera o token mais provável dado o contexto. Quando falta informação ou o prompt é ambíguo, ele pode gerar afirmações falsas que soam convincentes.

Para reduzir essas alucinações, é importante:

- Fornecer contexto completo.
- Permitir respostas do tipo "não sei".
- Evitar prompts que pressionem por certeza absoluta.

#### Considerações finais

Entender como funcionam as LLMs ajuda a tirar melhor proveito delas, tanto na escrita de prompts quanto na interpretação dos resultados. Conhecendo os mecanismos internos como tokenização, embeddings, attention e sampling, você consegue:

- Reduzir custos otimizando prompts.
- Ajustar parâmetros para obter resultados mais precisos ou criativos.
- Criar experiências mais robustas com APIs de IA.

Com esse conhecimento, você está pronto para avançar para experimentações práticas e aplicações mais sofisticadas. Te vejo na próxima aula!

<!-- Página 58 do PDF -->
<a id="modulo-05-inteligencia-artificial-na-web-capitulo-3-como-funciona-inteligencia-artificial-na-web-com-web-ai"></a>
### Capítulo 3: Como funciona inteligencia artificial na Web com Web AI

Neste capítulo, exploramos como a inteligência artificial está sendo integrada diretamente nos navegadores, permitindo que modelos de linguagem e outras funcionalidades avancadas sejam executados localmente na máquina do usuário. Trata-se de uma mudança de paradigma significativa, abrindo caminho para a chamada Web 4.0.

#### A Web 4.0 e a IA no navegador

A chamada Web 4.0 representa uma nova geração da internet, na qual a inteligência artificial é nativa ao navegador. Isso significa que, em vez de depender de servidores remotos para processar IA, as aplicações podem rodar diretamente na máquina do usuário. Modelos como o Gemma do Google e o DeepSeek já estão sendo utilizados dessa forma.

Essa abordagem traz benefícios claros:

- Não é necessário enviar dados dos usuários para servidores externos.
- A performance é aceitável, mesmo em aplicações mais complexas.
- A execução local garante maior privacidade.

#### Desvantagens e desafios

Apesar das vantagens, ainda existem entraves significativos:

- Os modelos são pesados: o Gemma possui cerca de 2.5GB e o DeepSeek, 1.3GB.
- O tempo de download pode comprometer a experiência, especialmente em dispositivos móveis.
- Nem todo navegador está preparado para essa funcionalidade de forma nativa.

#### APIs experimentais e o futuro

<!-- Página 59 do PDF --> O Google vem investindo em APIs experimentais que buscam integrar modelos como o Gemini Nano diretamente ao navegador. Com isso, ao instalar o navegador, o modelo já viria embarcado, eliminando a necessidade de downloads futuros. Algumas dessas APIs já estão disponíveis em versões do Chrome e do Chrome Canary.

Funções já disponíveis:

- Tradução de texto.
- Identificação de idioma.
- Resumo de conteúdo.
- Prompt para interação com LLMs.

Todas essas funcionalidades já podem ser executadas localmente, gratuitamente e com bom desempenho.

#### Exemplo prático: executando uma LLM no navegador

A demonstração criada nesta aula mostra como é simples utilizar uma LLM diretamente no navegador, utilizando apenas um arquivo HTML com JavaScript.

O processo é:

1. Habilitar as funcionalidades experimentais no navegador.
2. Criar um prompt inicial com contexto.
3. Configurar parâmetros como temperature e topK para controlar a criatividade e variedade das respostas.
4. Executar a API languageModel.create() passando os parâmetros.
5. Processar a resposta usando streaming token por token.

Esse modelo responde diretamente dentro do navegador, sem conexão com servidores externos, e permite experimentar diferentes comportamentos conforme a temperatura e o topK escolhidos.

#### Testando diferentes configurações

Ao manipular os parâmetros temperature e topK, é possível observar a diferença no comportamento da IA:

- <!-- Página 60 do PDF --> Com temperature próximo de 0, a resposta tende a ser mais previsível.
- Com valores mais altos, a IA tende a ser mais criativa.
- O topK define quantos candidatos ao próximo token são considerados.

Por exemplo:

- Pergunta: "O céu é..."
- Com temperature=0, a resposta quase sempre será "azul".
- Com temperature=2 e topK=10, a resposta pode variar para "vasto", "ilimitado", "cheio de estrelas", etc.

#### Validação de similaridade semântica

Relembrando conceitos anteriores, também foi testada a capacidade de razão semântica do modelo, por exemplo:

- Prompt: "Rei - homem + mulher = ?"
- Resultado: "Rainha"

Esse tipo de raciocínio mostra como os embeddings estão funcionando por trás da IA, mesmo no ambiente do navegador.

#### Conclusão

Com os avanços em Web AI, estamos entrando em uma nova era da computação, onde IA não depende mais da nuvem. Modelos embutidos nos navegadores oferecem maior controle, privacidade e independência.

A Web 4.0, como foi chamada aqui, é a visão de um futuro onde os navegadores se tornam os verdadeiros sistemas operacionais, capazes de executar IA de forma nativa, gratuita e descentralizada. Se você é desenvolvedor, agora é a hora de experimentar e integrar essas ferramentas aos seus projetos.

<a id="modulo-05-inteligencia-artificial-na-web-capitulo-4-demo-02-web-ai-multi-modal"></a>
### Capítulo 4: Demo 02 - Web AI Multi Modal

<!-- Página 61 do PDF --> Neste capítulo, mergulhamos nas capacidades multimodais das novas APIs de Web AI. O foco é demonstrar como modelos de linguagem embarcados nos navegadores podem agora lidar com diferentes tipos de entrada, como texto, áudio e imagem, tudo rodando localmente, sem conexão com servidores externos.

#### A Web de agentes inteligentes

Estamos presenciando o nascimento da Web 4.0, onde agentes inteligentes embarcados nos navegadores serão parte integrante da experiência digital. A ideia é simples e revolucionária: permitir que os sites ofereçam assistentes inteligentes que interajam diretamente com os visitantes, sem a necessidade de navegar por várias páginas ou enviar dados para servidores remotos.

A Google está liderando essa transformação com APIs que possibilitam a execução local de modelos como o Gemini Nano. E, recentemente, essas APIs passaram a aceitar entradas multimodais.

#### O que é multimodalidade?

Multimodalidade é a capacidade de um sistema de IA de lidar com diferentes tipos de dados: texto, imagem, áudio, entre outros. A IA não apenas entende esses formatos, mas também é capaz de relacionar conteúdos entre eles.

Por exemplo:

Enviar uma imagem e perguntar o que está nela.

Enviar um áudio e pedir a transcrição.

Combinar texto e imagem no mesmo prompt para uma resposta contextualizada.

#### Demonstração prática

Na demonstração feita em aula, um projeto chamado "Exemplo 05 - Web AI Multimodal" foi apresentado. Esse projeto é capaz de:

Processar imagens de pessoas, animais e cenários.

<!-- Página 62 do PDF --> Descrever conteúdos das imagens com alto grau de precisão.

Transcrever documentos, como um cartão CNPJ, para texto.

O mais impressionante é que tudo isso ocorre 100% offline, no navegador do usuário.

#### Como funciona

O funcionamento da IA multimodal depende de algumas etapas:

Verificação do ambiente: o navegador precisa ser compatível (por enquanto, apenas Chrome).

Inicialização do modelo: assim que a página carrega, o modelo é baixado localmente.

Recebimento de inputs: imagem, áudio ou texto.

Processamento do dado: o arquivo é convertido em formato binário (blob).

Geração de resposta: a IA interpreta os dados e responde conforme o prompt.

#### Resultados impressionantes

Alguns testes mostraram como a IA consegue:

Identificar pessoas em fotos e descrever elementos como roupas, objetos e contexto da cena.

Processar uma imagem de um documento e extrair campos como CNPJ, nome da empresa, endereço, telefone e status.

Trabalhar com diferentes parâmetros de temperature e topK para ajustar o nível de criatividade da resposta.

Por exemplo, uma imagem com um homem, um laptop e um cachorro foi descrita corretamente como um ambiente relaxante ao entardecer.

#### Tradução e compatibilidade com idiomas

<!-- Página 63 do PDF --> Apesar de a API funcionar em português para prompts de texto, os recursos multimodais (imagem e áudio) ainda apresentavam melhores resultados em inglês. Para contornar isso, foi usada uma API de tradução embutida:

Input em português → traduzido para inglês.

Processado pela IA.

Output em inglês → traduzido de volta para português.

Esse processo de ida e volta é transparente ao usuário e ocorre rapidamente.

#### Casos de uso

Os exemplos apresentados demonstram potencial para aplicações como:

Acessibilidade, com leitura de imagens e transcrição de áudio.

Processamento de documentos offline.

Sites com assistentes visuais e auditivos.

Isso amplia o escopo de aplicação de IA no front-end, especialmente para dispositivos móveis.

#### Considerações finais

A capacidade de executar IA multimodal no navegador muda completamente a forma como pensamos sobre web apps. Agora, é possível criar assistentes que veem, ouvem e respondem, com desempenho aceitável e sem comprometer a privacidade.

Estamos no limiar de uma nova geração de experiências digitais, e você já pode experimentar essas tecnologias hoje mesmo. O futuro da IA na web é local, privado, multimodal e acessível.

<a id="modulo-06-prompt-engineering"></a>
## Módulo 06: Prompt Engineering

<!-- Página 64 do PDF -->
<a id="modulo-06-prompt-engineering-capitulo-1-como-escrever-prompts-que-realmente-geram-boas-respostas"></a>
### Capítulo 1: Como escrever prompts que realmente geram boas respostas

Neste capítulo, vamos entender por que tantas pessoas ainda enfrentam dificuldades em extrair bons resultados de ferramentas de inteligência artificial como o ChatGPT. Seja por frustração com alucinações, respostas erradas ou pela necessidade de repetir a tarefa diversas vezes, o problema geralmente está na formulação dos prompts.

Aqui, trago uma introdução prática e direta sobre como melhorar seus prompts com base em conceitos fundamentais da engenharia de prompt, sem precisar mergulhar ainda nos aspectos mais avançados.

#### Por que a IA alucina?

A IA não pensa como um humano. Ela não é determinística; ela trabalha prevendo a próxima palavra mais provável com base no contexto que recebeu. Quando o prompt está mal formulado, o modelo tenta adivinhar o que você quer, o que abre espaço para erros. Surgem as chamadas "alucinações": o modelo inventa dados, mistura contextos ou responde com muita segurança mesmo sem ter informação suficiente.

Exemplo: ao perguntar "Quem é Eric Wendel?", a IA poderia misturar dados verdadeiros com falsas informações, como dizer que ele é autor de livros de Java, o que não corresponde à realidade.

#### Reduzindo Alucinações com Prompts Estruturados

Para evitar essas falhas, apresento aqui uma estrutura de prompt inspirada em um famoso estudo da Anthropic. Essa estrutura se baseia em 10 blocos que ajudam a guiar o modelo com clareza:

1. Contexto da tarefa: Defina o perfil da IA. Exemplo: "Você é Joe, um coach de carreira especializado em transição para a área de tecnologia".
2. <!-- Página 65 do PDF --> Tom de voz: Estilo de comunicação. Formal? Empático? Didático? Isso influencia a forma como o modelo se expressa.
3. Fonte da verdade: Insira documentos, regras, tabelas ou qualquer material de referência que sirva como base factual para a resposta. Isso evita que a IA se baseie em dados genéricos da internet.
4. Contrato operacional: Regras de comportamento. Exemplo: "Se não tiver certeza, diga que não sabe. Se faltar dado, solicite informações." Isso cria um "protocolo" de segurança para a IA.
5. Exemplos: Mostre padrões de entrada e saída. Isso ancora a resposta esperada, define formato, estrutura e o que fazer quando faltar algum campo.
6. Histórico do usuário: Em aplicações mais robustas, esse campo traz o que já foi dito pelo usuário para manter consistência.
7. Pedido claro: Qual é a tarefa? Não confunda contexto com a demanda. Dê uma instrução objetiva.
8. Incentivo ao raciocínio: Peça para validar ou revisar antes de responder, se fizer sentido. Em tarefas complexas, pode ajudar a IA a refletir.
9. Formato da resposta: JSON, texto corrido, tabela? Especifique.
10. Restrições e validação: Limites de caracteres, idioma de resposta, obrigatoriedade de campos, e o que fazer quando um dado não estiver disponível.

#### Dicas práticas anti-alucinação

Um checklist que uso com frequência:

- Sempre inclua o papel da IA.
- Forneça documentos ou dados reais, mesmo que em texto simples.
- Peça para a IA não inventar, e sim dizer que não tem informação.
- Oriente o modelo a fazer perguntas quando o pedido for incompleto.
- Para ambiguidades, oriente a listar opções e pedir uma escolha.

#### Exemplos práticos

Se você pede: "Crie um plano de carreira pra mim", o modelo pode alucinar porque não sabe:

- <!-- Página 66 do PDF --> Qual é sua área.
- Qual seu nível atual.
- Quais seus objetivos.

Um prompt melhor seria: "Você é um consultor de carreira. Meu objetivo é migrar para a área de desenvolvimento backend em Java. Tenho experiência com banco de dados e sou formado em engenharia. Crie um plano de carreira para três anos com foco em empresas de tecnologia."

#### Considerações finais

Prompts bem escritos economizam tempo, reduzem retrabalho e aumentam a precisão das respostas. Essa estrutura é uma base poderosa para qualquer pessoa que deseje usar IAs com mais eficiência, especialmente em contextos profissionais.

Nos próximos módulos, vamos aprofundar ainda mais em engenharia de prompt. Mas com o que você aprendeu aqui, já é possível evitar os erros mais comuns e tirar o máximo das IAs que você já usa no dia a dia.

<a id="modulo-06-prompt-engineering-capitulo-2-padrao-toon-e-json-para-prompts"></a>
### Capítulo 2: Padrão TOON e JSON para Prompts

Neste capítulo, vamos entender como estruturar prompts de forma mais eficiente e como isso pode melhorar tanto a precisão quanto a economia de tokens. Exploramos dois formatos principais: o tradicional JSON Prompt e o novo formato conhecido como TOON (Token Oriented Object Notation).

#### LLMs gostam de dados estruturados

Apesar da impressão de que estamos conversando com um humano, LLMs são algoritmos treinados para prever tokens com base em entrada textual. Isso significa que, quanto mais estruturada for essa entrada, melhor o modelo consegue processar e responder.

<!-- Página 67 do PDF --> O JSON Prompt surge como uma solução natural: é familiar, estruturado, previsível e integrável com ferramentas que desenvolvedores já usam, como Zod, Ajv e Yup.

#### Vantagens do JSON Prompt

Redução de ambiguidade: Campos separados evitam misturas de regras e instruções.

Previsibilidade de integração: Mais fácil validar saídas e gerar re-prompts automáticos.

Padronização para times e pipelines: Permite versionar, reutilizar e automatizar prompts com mais segurança.

Redução indireta de tokens: Embora JSON puro possa consumir mais tokens por causa da sintaxe, a padronização e prevenção de erros economizam em correções e retrabalho.

#### Estrutura sugerida para JSON Prompt

meta: nome, versão, idioma, papel da IA.

context: dados de referência ou informações base.

task: a tarefa desejada.

constraints: regras e limites.

output: formato esperado de resposta.

Essa separação ajuda a IA a entender com clareza o que deve ser feito e como.

#### TOON: a versão compacta para economia de tokens

TOON (Token Oriented Object Notation) surgiu com o objetivo de reduzir o custo em tokens, simplificando a estrutura sintática do JSON. Ele remove aspas, chaves e outros símbolos, deixando apenas a estrutura essencial.

Exemplo de ganho:

<!-- Página 68 do PDF --> Lista de 6 itens em JSON: 367 tokens.

Lista de 6 itens em TOON: 339 tokens.

Com listas maiores, o ganho cresce exponencialmente, chegando a diferenças de mais de 140 tokens por prompt.

#### JSON bem estruturado ainda é competitivo

Mesmo com a proposta enxuta do TOON, um JSON bem modelado, especialmente quando representa dados tabulares, pode atingir eficiências próximas ou melhores. Um array de colunas e linhas elimina redundância de chaves e ainda continua sendo JSON válido, com toda a vantagem do ecossistema (validação, parsing, logging).

Exemplo:

JSON tabular: 26 tokens.

TOON equivalente: 35 tokens.

#### Quando usar cada um

JSON Prompt:

Quando precisa integrar com APIs.

Quando precisa validar saída com esquemas.

Quando é importante manter compatibilidade com ferramentas existentes.

TOON:

Quando a prioridade é máxima economia de tokens.

Quando a estrutura é simples e bem controlada.

Em pipelines onde o parsing customizado é aceitável.

#### Cuidados com TOON

<!-- Página 69 do PDF --> Exige aprendizado de novo formato.

Não suportado por ferramentas comuns.

Pode trazer mais complexidade na integração.

#### Conclusão

O uso de JSON estruturado é hoje uma das melhores práticas para obter respostas mais precisas, previsíveis e com menos alucinações. O TOON vem como alternativa interessante em cenários muito específicos onde a economia de tokens é essencial.

Minha recomendação é clara: comece com JSON. Estruture bem, otimize seu prompt, use esquemas de validação. Isso já resolve grande parte dos problemas de integração com LLMs. TOON pode ser explorado mais adiante, quando houver maturidade na implementação.

No próximo capítulo, veremos como colocar tudo isso em prática para construir assistentes que realmente funcionam em ambiente de produção.

<a id="modulo-07-ferramentas-de-ia-para-acelerar-sua-vida-como-dev"></a>
## Módulo 07: Ferramentas de IA para acelerar sua vida como Dev

<a id="modulo-07-ferramentas-de-ia-para-acelerar-sua-vida-como-dev-capitulo-1-historia-e-visao-geral-do-cursor-comparando-vscode-windsurf-e-cursor"></a>
### Capítulo 1: História e visão geral do Cursor, Comparando VSCode, Windsurf e Cursor

Estamos vivenciando uma verdadeira revolução na forma como interagimos com os editores de código. O que antes era apenas um ambiente para digitar comandos se transformou em um ecossistema de execução de agentes de inteligência artificial. Neste capítulo, vamos explorar a história e proposta do Cursor, e compará-lo com dois concorrentes de peso: o VS Code e o Windsurf.

#### O VS Code como base

<!-- Página 70 do PDF --> Tanto o Cursor quanto o Windsurf são forks do VS Code. E isso não é coincidência. O VS Code se consolidou como um padrão da indústria por seu ecossistema maduro, extensões, temas, debugger integrado, terminal e suporte a Git. Ele virou o "Chrome" dos editores, e empresas viram a oportunidade de não reinventar a roda: aproveitar essa base sólida e adicionar camadas de IA.

#### Cursor: o fork AI First

O Cursor é um editor criado pela empresa Hemisphere em 2022, com uma abordagem totalmente voltada para IA desde o início. Não é apenas um VS Code com assistente embutido. Ele foi pensado para ser um ambiente de desenvolvimento assistido por IA, com foco em produtividade.

O investimento no Cursor foi massivo: US$ 2,3 bilhões levantados em uma única rodada, com valor de mercado chegando a US$ 29,3 bilhões. Essa dimensão chamou a atenção global, e é explicada pelo fato de que o Cursor e seus similares atacam diretamente o custo mais alto da indústria de software: o tempo de desenvolvimento.

#### Windsurf: outra aposta forte

O Windsurf também é um fork do VS Code, criado pela equipe do Codium, que ficou conhecida pelo plugin Kodi, uma alternativa ao autocomplete do GitHub Copilot. Ele teve uma proposta similar ao Cursor, integrando IA como protagonista do editor.

Seus números também impressionam: US$ 150 milhões captados com valuação de US$ 1,2 bilhão. A OpenAI chegou a considerar comprar o Windsurf por US$ 3 bilhões, mas o acordo não foi concretizado. Mesmo assim, o projeto ganhou força e é hoje usado em larga escala.

#### Diferenças práticas no uso

Apesar das diferenças nas propostas, muitos desenvolvedores não percebem uma grande distinção entre o uso cotidiano do VS Code e do Windsurf. Os atalhos, extensões e a aparência geral são praticamente os mesmos.

<!-- Página 71 do PDF --> O que muda é a profundidade da integração com IA. No VS Code, por exemplo, o recurso de chat com IA inclui três agentes nativos:

- ASCII: para perguntas rápidas e explicação de código.
- EDIT: para modificações controladas com base em guias.
- PLAN: para criação de planos de implementação antes da execução.

Após o plano aprovado, entra em ação o AGENT, que executa as tarefas com autonomia, iterando conforme o contexto e ferramentas disponíveis. Esse agente é muito utilizado por desenvolvedores em tarefas do dia a dia.

#### Agentes customizáveis

Uma das funcionalidades mais avançadas é a criação de agentes customizados no VS Code. A ideia é definir personas com tarefas repetitivas que fazem parte do ciclo de desenvolvimento. Esses agentes podem:

- Validar testes.
- Verificar boas práticas.
- Operar com modelos diferentes.
- Ter acesso restrito a ferramentas.

Na prática, eles funcionam como sub-prompts pré-definidos que executam tarefas específicas com escopo bem limitado.

#### Prompt vs. Editor

Ao longo do curso, o autor compartilhou uma experiência pessoal ao criar um aplicativo usando uma plataforma de Prompt-to-App (como Lovable). Apesar do início promissor, o app logo apresentou falhas graves por falta de segurança, validação e estrutura de código. Foi necessário migrar o projeto para o VS Code e reescrevê-lo com boas práticas.

Esse exemplo reforça a importância de usar editores como VS Code, Cursor ou Windsurf, que oferecem:

- Controle sobre o código.
- Revisão e testes.
- <!-- Página 72 do PDF --> Auditoria.
- Integração com ferramentas de CI/CD.

#### Conclusão

Estamos diante de uma nova geração de editores, onde a IA deixa de ser um acessório e passa a ser o centro da experiência. O Cursor se destaca como um dos principais expoentes dessa tendência, mas tanto o Windsurf quanto o VS Code estão na mesma corrida para transformar o ambiente de desenvolvimento em um verdadeiro cockpit de produtividade assistida.

Para este curso, recomenda-se fortemente o uso de um editor com IA integrada. Independentemente da escolha entre VS Code, Cursor ou Windsurf, o que importa é manter o controle, aplicar boas práticas e explorar o potencial dos agentes inteligentes com responsabilidade.

<a id="modulo-07-ferramentas-de-ia-para-acelerar-sua-vida-como-dev-capitulo-2-o-que-sao-agentes-de-ia-e-como-eles-tomam-decisoes-em-etapas"></a>
### Capítulo 2: O que são agentes de IA e como eles tomam decisões em etapas

Neste capítulo, vamos entender o que realmente são agentes de IA, como eles funcionam na prática e por que estão revolucionando a forma como desenvolvemos software. Diferente de apenas gerar respostas em linguagem natural, os agentes têm um ciclo de vida estruturado, composto por decisão, execução e validação.

#### A limitação das LLMs isoladas

Modelos de linguagem (LLMs) são excelentes em prever a próxima palavra ou token com base no contexto textual. No entanto, elas não sabem executar comandos, abrir arquivos, rodar testes ou validar seus próprios resultados. Por isso, surgiram os agentes de IA: sistemas que usam uma LLM como motor de decisão, acoplados a ferramentas, ciclos de execução e observação dos resultados.

<!-- Página 73 do PDF -->
#### O ciclo de um agente

Um agente transforma o prompt em uma tarefa concreta por meio de um ciclo composto por:

- Entendimento do objetivo.
- Planejamento da execução.
- Seleção de ferramentas.
- Ação.
- Observação do resultado.
- Correção de erros.
- Entrega final com evidências.

Esse ciclo garante que a tarefa não seja apenas imaginada, mas executada e validada. Assim, deixa-se de apenas conversar com a IA para realmente resolver um problema.

#### Agentes não são exclusivos de editores

Apesar de muitos agentes serem integrados a editores como VS Code, nada impede que estejam em qualquer lugar: back-ends, pipelines de CI, bots de suporte, sistemas de observabilidade, etc. O ambiente e as ferramentas é que mudam, mas o conceito é o mesmo.

#### A mentalidade de desenvolvedor

Para que um agente seja eficaz, ele precisa pensar como um desenvolvedor experiente:

- Planeja em etapas pequenas.
- Define critérios de aceitação.
- Cria plano de execução.
- Sabe quando algo está concluído.

Essa abordagem evita loops infinitos e desperdício de tokens, pois cada passo é validado antes de seguir para o próximo.

#### Escolha inteligente de ferramentas

<!-- Página 74 do PDF --> O coração de um agente está na capacidade de escolher a ferramenta certa para cada tarefa:

- Ler código? Ferramenta de leitura de arquivos.
- Validar comportamento? Teste automatizado.
- Garantir estilo? Linter ou formatador.
- Buscar API? Integração com Swagger ou documentação.
- Ver banco de dados? Cliente de consulta SQL.

Esse raciocínio é o mesmo que desenvolvedores usam no dia a dia. O diferencial é a autonomia para executar isso.

#### Iteração com base em feedback

Um bom agente não apenas gera uma resposta. Ele:

1. Age.
2. Observa o que aconteceu.
3. Compara com a expectativa.
4. Corrige se for necessário.

Esse ciclo de feedback é o que traz a sensação de que a IA "acertou de primeira", pois ela teve a chance de ajustar antes de te mostrar o resultado final.

#### Agentes como papéis especializados

Agentes também podem ser divididos em papéis com responsabilidades específicas:

- Planner: cria o plano.
- Implementer: escreve e edita código.
- Reviewer: analisa os diffs e aponta riscos.
- QA: valida fluxo fim a fim.
- Docs Agent: escreve README e changelog.
- Ops Agent: monitora e sugere mitigacão de incidentes.

Essa segmentação permite controle fino de permissões e reduz riscos.

<!-- Página 75 do PDF -->
#### Como evitar alucinação: Spec Driven Development

Agentes falham quando a tarefa está mal definida. Buracos no prompt são preenchidos com "chutes". Para resolver isso, usamos a técnica de Spec Driven Development:

Uma boa "spec" (especificação) deve incluir:

- Contexto: stack, ambiente, dependências.
- Requisitos: o que deve estar presente.
- Não-requisitos: o que deve ser evitado.
- Critérios de aceite: como saber se está pronto.
- Contrato: formato da API, shape da resposta.
- Plano de testes: como validar a funcionalidade.

Isso é fundamental para que o agente saiba quando parar e como validar o sucesso.

#### Um fluxo profissional com agentes

1. Defina a especificação (spec).
2. Crie os agentes com papéis definidos.
3. Execute cada etapa com validação.
4. Integre os resultados com testes automatizados.

O resultado é um fluxo de trabalho sem caos, com consistência e alta qualidade.

#### Conclusão

Agentes de IA não são apenas LLMs com plugins. São sistemas completos com controle de execução, planejamento e validação. Usar agentes não é mais opcional em projetos sérios: é uma forma de transformar sua produtividade e escalar com qualidade. E como sempre, o segredo está na engenharia de prompt. Ela é a base para construir agentes que funcionam de verdade.

<a id="modulo-08-mcps-e-automacao-para-devs"></a>
## Módulo 08: MCPs e Automação para Devs

<!-- Página 76 do PDF -->
<a id="modulo-08-mcps-e-automacao-para-devs-capitulo-1-o-que-sao-mcps-model-context-protocol-e-como-conectam-ia-com-apis-servico"></a>
### Capítulo 1: O que são MCPs (Model Context Protocol) e como conectam IA com APIs/serviço

Neste capítulo, vamos explorar uma das inovações mais relevantes na integração entre inteligência artificial e sistemas reais: o Model Context Protocol, ou simplesmente MCP. Trata-se de um padrão criado para conectar modelos de linguagem com APIs, arquivos, bancos de dados e qualquer outra fonte de dados ou serviço.

#### O que é MCP?

O MCP foi anunciado pela Anthropic em novembro de 2024 como um protocolo aberto (open source) para integrar assistentes de IA com fontes de dados externas. A ideia central é que você possa simplesmente plugar servidores MCP prontos em um cliente compatível, como o VS Code, e a IA passará a utilizar essas integrações automaticamente, sem necessidade de codificação adicional.

Imagine pedir para a IA buscar um resumo das alterações solicitadas em um pull request, sugerir correções, aplicar os ajustes, escrever testes e comitar tudo automaticamente. Ou então, pedir que envie um e-mail diretamente pela API do Gmail. Tudo isso se torna viável com o uso de MCPs.

#### Como um MCP funciona

Um servidor MCP expõe três componentes fundamentais:

1. Tools (ferramentas): ações que a IA pode executar, como "listar palestras", "criar arquivo", "executar consulta SQL".
2. Resources (recursos): dados usados como contexto, como conteúdo de arquivos, logs ou esquemas de banco de dados.
3. Prompts: templates e estruturas que ajudam a IA a formular comandos adequados para usar essas ferramentas.

Esses elementos são descritos por schemas padronizados. A IA, ao interpretar o prompt do usuário, identifica qual tool melhor se encaixa com base no nome, <!-- Página 77 do PDF --> descrição e parâmetros esperados. É exatamente como um desenvolvedor humano: entende o problema e seleciona a função mais adequada.

#### Um exemplo prático: servidor MCP pessoal

O professor compartilhou a criação de um servidor MCP pessoal que expõe uma API com informações sobre palestras, posts e vídeos que ele publicou. Para isso, ele:

- Estruturou a API.
- Gerou um SDK automático via GraphQL.
- Criou testes automatizados com Node.js Test Runner.
- Publicou o pacote no npm.

Com isso, qualquer pessoa pode instalar essa integração e consultá-la diretamente da IA no editor, como o VS Code.

#### Benefícios do MCP

- Redução de alucinação: a IA acessa dados reais em vez de inventar informações.
- Extensibilidade: basta instalar novos servidores MCP para adicionar funcionalidades.
- Modularidade: você pode combinar múltiplas fontes em uma mesma interação.

Exemplo: perguntar quais foram as palestras do Eric em 2024, resumir a mais recente e enviar por e-mail.

#### Como as LLMs escolhem as ferramentas

As LLMs não contêm uma lógica de if-else para decidir qual ferramenta usar. Elas aprendem a selecionar a melhor opção com base na similaridade entre o prompt e a descrição da tool. Tools com nomes claros (ex: readFile) e descrições objetivas são priorizadas.

Além disso, a IA costuma preferir:

- <!-- Página 78 do PDF --> Ações não destrutivas (como ler e listar) antes de escrever ou deletar.
- Tools com schemas de parâmetro bem definidos.

Modelos mais avançados conseguem executar sequências de chamadas: usar uma tool, analisar o resultado, e então chamar outra tool com base nessa resposta.

#### Casos de uso do mundo real

O professor mostrou exemplos de MCPs usados na prática, como:

- MCP do GitHub: listar PRs, revisar código, abrir PR.
- MCP do Playwright: criar testes e navegar em sites.
- MCP do Grafana: buscar dados de monitoramento.
- MCP de e-mail da Resend: gerar e enviar e-mails direto do editor.

Esses MCPs são plugados via arquivos de configuração (mcp.json) no VS Code ou outro editor compatível. Basta apontar para o servidor e fornecer as credenciais. A partir disso, a IA já está apta a usar essas integrações no seu fluxo de trabalho.

#### JSON Schema e validação

Cada tool define um JSON Schema para os parâmetros de entrada. A LLM precisa gerar um JSON válido para que a chamada seja executada. Se o schema não for atendido, a execução falha, e o modelo pode tentar novamente.

Isso traz um controle forte e previsibilidade para a interação entre IA e ferramentas, algo essencial para uso em ambientes de produção.

#### Conclusão

O MCP representa um salto na evolução da IA aplicada: sair do texto e entrar na ação concreta. Com ele, a IA não apenas responde, mas age com base em dados reais, seguindo padrões claros e seguros.

Esse tipo de integração deve se tornar cada vez mais comum, especialmente em ambientes corporativos onde segurança, auditabilidade e produtividade <!-- Página 79 do PDF --> caminham lado a lado. MCP é o "USB" das ferramentas para a era das LLMs: plug and play com poder real.

<a id="modulo-08-mcps-e-automacao-para-devs-capitulo-2-usando-ia-para-gerar-testes-automatizados"></a>
### Capítulo 2: Usando IA para: Gerar testes automatizados

Neste capítulo, vamos demonstrar na prática como utilizar inteligência artificial, via MCP do Playwright, para gerar testes automatizados com qualidade e rapidez. O objetivo é claro: eliminar desculpas e tornar obrigatória a entrega de software com testes desde o início.

#### O contexto da demonstração

Toda a demo foi feita em um repositório vazio no VS Code. Utilizando apenas prompts estruturados e integração com agentes de IA, foi possível:

- Criar o projeto com o Playwright.
- Gerar um arquivo de teste base.
- Executar os testes.
- Ajustar falhas automaticamente.
- Integrar com GitHub Actions.

A ferramenta principal foi o servidor MCP do Playwright, que permite que a IA interaja com o navegador de forma autônoma e gere os scripts necessários.

#### Como a IA executa os testes

A IA usa o MCP para se comunicar com o navegador via comandos como:

- Abrir página.
- Preencher formulários.
- Submeter dados.
- Verificar resultados.
- Validar campos e erros.
<!-- Página 80 do PDF --> Tudo isso é feito com base em prompts simples e objetivos, sem necessidade de codificação manual.

#### Etapas do fluxo automatizado

1. Inicialização do projeto: o prompt inicial define como a estrutura deve ser criada. O agente instala dependências, configura navegadores (ex: apenas Chromium) e valida se o ambiente está operacional com um teste inicial.
2. Criação de estrutura de CI/CD: outro prompt gera automaticamente o arquivo de workflow do GitHub Actions, integrando a execução dos testes com o repositório.
3. Mapeamento da página: a IA navega na página, identifica os elementos, campos de formulário, listas e botões.
4. Geração dos testes: baseado em prompts com objetivos genéricos (ex: validar submissão, verificar atualização da lista), a IA gera scripts que utilizam as funcionalidades do Playwright.
5. Execução e ajustes: os testes são rodados, e em caso de falhas, a IA ajusta automaticamente o código até que tudo passe.

#### Agente inteligente e interação com o browser

Durante a execução, a IA decide se deve abrir o Chrome em modo visível ou headless. Com base nos logs e nos resultados das interações, ela ajusta os comandos, modifica seletores e reescreve os testes conforme necessário.

Os relatórios visuais do Playwright ajudam a entender o que foi feito, e cada prompt executado pode ser reusado, refinado e testado com diferentes modelos, como GPT-5.

#### Vantagens da abordagem

- Produtividade: criação de testes com zero linha de código escrita manualmente.
- Padronização: estrutura inicial e CI gerados de forma uniforme.
- <!-- Página 81 do PDF --> Validação real: os testes realmente rodam, são validados e documentados.
- Redução de erros: agentes ajustam automaticamente falhas comuns.
- Acesso facilitado: integração com editores e execução via comandos visuais.

#### Recomendação profissional

Para times de desenvolvimento modernos, essa abordagem representa uma mudança de paradigma. Ferramentas como o Playwright MCP integradas com agentes inteligentes tornam obsoleta a desculpa de que "não deu tempo de escrever teste".

A execução da IA mostra que com poucos prompts bem definidos é possível obter:

- Testes com cobertura significativa.
- Validação de casos críticos.
- Integração com pipeline de entrega.

#### Conclusão

Automatizar testes com IA é uma realidade acessível. A combinação entre prompt engineering, servidores MCP e agentes inteligentes abre caminho para um desenvolvimento mais robusto, validado e com foco em qualidade desde o início.

Se você ainda não utiliza IA para gerar testes, este é o momento ideal para começar. O impacto na produtividade, qualidade do software e tranquilidade na entrega é imediato e comprovado.

<a id="modulo-08-mcps-e-automacao-para-devs-capitulo-3-usando-ia-para-navegar-em-sites-e-extrair-informacoes"></a>
### Capítulo 3: Usando IA para: Navegar em sites e extrair informações

<!-- Página 82 do PDF --> Neste capítulo, demonstro como a inteligência artificial, por meio de ferramentas como o Playwright MCP, está revolucionando a forma como interagimos com páginas web. Com alguns prompts simples, é possível automatizar completamente tarefas como preenchimento de formulários, extração de informações e navegação entre seções de sites, sem escrever uma linha de código.

#### Cenário prático: o problema dos formulários repetitivos

Quem participa com frequência de eventos sabe o quão desgastante é preencher várias vezes os mesmos dados pessoais em formulários diferentes. Esse foi meu ponto de partida. Utilizei o Playwright MCP dentro do VS Code para automatizar esse processo com base nas informações do meu perfil em uma plataforma de eventos que reúne minhas palestras em diversos idiomas.

#### Passo a passo da automação com Playwright MCP

1. Configuração do MCP: No VS Code, configurei o agente de IA apontando para o MCP do Playwright. Esse agente é capaz de navegar em páginas reais, clicar em elementos, preencher campos e muito mais. O JSON de configuração é colado no painel do agente e adaptado conforme as extensões instaladas no navegador.
2. Conexão com o navegador: Com a extensão Playwright MCP Bridge instalada no Chrome, foi possível permitir que a IA interagisse diretamente com as abas abertas. Isso é essencial para cenários que exigem autenticação ou sessão logada.
3. Execução dos comandos: A partir de um prompt como "Navegue no site ericwendel.com e me resuma o que existe aí", a IA se conectou ao navegador, abriu a página, percorreu as seções e começou a coletar dados.
4. Preenchimento automatizado de formulário: Com o contexto da página obtido, o agente acessou um formulário real da comunidade Node.br e iniciou o preenchimento automático com dados retirados do site do Sessionize, onde mantenho meu perfil como palestrante.
5. <!-- Página 83 do PDF --> Gerenciamento de contexto e continuidade: A IA manteve o contexto em memória, mesmo após múltiplas interações. Por exemplo, quando faltaram dados como telefone ou e-mail, o agente solicitou diretamente essa informação, ajustou o que precisava e continuou preenchendo.
6. Alternando palestras e refinando prompts: Foi possível trocar a palestra automaticamente, limpar o formulário e repetir o processo com outro conteúdo. Essa interatividade permite personalizar os resultados com prompts refinados e mais objetivos.

#### Benefícios observados

- Eficiência: tarefas demoradas e repetitivas são eliminadas.
- Precisão: a IA extrai dados diretamente da fonte, reduzindo erros manuais.
- Escalabilidade: o mesmo fluxo pode ser reaproveitado para dezenas de formulários.
- Integração local: é possível rodar modelos de IA localmente com ferramentas como o Olyama, economizando custos com tokens.

#### Execução local e open source

Uma parte avançada da aula mostrou como rodar o mesmo tipo de automação usando modelos locais. Usei o modelo QuenCoder de 30 bilhões de parâmetros via a plataforma Tome, que integra modelos open source com servidores MCP. Mesmo com poder computacional limitado, foi possível executar tarefas de navegação e extração com qualidade satisfatória.

#### Considerações finais

Este tipo de integração é um divisor de águas. A IA, combinada com servidores MCP e extensões no navegador, é capaz de agir como um verdadeiro agente digital, navegando, preenchendo, interagindo e aprendendo com o ambiente online.

<!-- Página 84 do PDF --> Para desenvolvedores web, profissionais de dados ou qualquer pessoa que lide com tarefas repetitivas em páginas web, essa é uma revolução silenciosa, mas extremamente poderosa.

Com o aprimoramento constante dos modelos e da engenharia de prompts, fica cada vez mais claro que automatizar processos não é mais uma opção distante: é uma realidade presente, acessível e altamente produtiva.

<a id="modulo-08-mcps-e-automacao-para-devs-capitulo-4-usando-ia-para-consultar-documentacoes-atualizadas"></a>
### Capítulo 4: Usando IA para: Consultar documentações atualizadas

Um dos maiores desafios no uso de LLMs no dia a dia é lidar com informações desatualizadas. Modelos de linguagem como GPT ou Claude são treinados até uma certa data, e a partir dali não aprendem mais, a menos que a gente forneça dados recentes. Isso se torna um problema quando APIs, bibliotecas ou frameworks mudam de versão, e o modelo segue sugerindo códigos antigos, quebrados ou incompatíveis.

Foi justamente para resolver esse problema que surgiu o Context-7, um servidor MCP criado com o objetivo de fornecer documentação atualizada, precisa e diretamente da fonte para o modelo de linguagem.

O que é o Context-7

O Context-7 é um servidor que indexa documentações completas de projetos reais, como Next.js, BetterOff, Node.js, Prisma, entre outros. Ele consegue puxar os trechos mais relevantes da documentação no momento da execução do prompt e inserir automaticamente no contexto que será processado pela IA. Com isso, o modelo passa a gerar códigos e respostas baseadas em versões atuais das ferramentas.

Diferença no fluxo de desenvolvimento

Sem o Context-7, a prática comum é colar blocos enormes da documentação manualmente no prompt, mandar links e reexplicar o setup a cada tentativa. Isso <!-- Página 85 do PDF --> consome tokens, torna o processo caro e ainda propenso a erros. Com o Context-7, o prompt fica muito mais leve, porque o servidor MCP faz a seleção dos trechos precisos e enxutos automaticamente.

Exemplo prático: criando uma aplicação com Next.js e BetterOff

Na demonstração, o objetivo foi criar uma aplicação fullstack usando Next.js como framework e BetterOff para autenticação com GitHub. A persistência de dados foi feita com SQLite, facilitando o ambiente local.

Para isso, o prompt usado foi bem estruturado:

- Definiu que o agente é um desenvolvedor fullstack experiente.
- Deixou claro que o Context-7 deve ser usado obrigatoriamente.
- Descreveu passo a passo o que a aplicação precisa conter.
- Pediu para criar o projeto na pasta PromptMD.

Integração do Context-7 no VS Code

O processo de integração foi simples:

1. Criação da API Key no painel do Context-7.
2. Configuração do arquivo mcp.json com a chave.
3. Habilitação das tools queryDocs e resolveLibrary no agente.
4. Execução do prompt diretamente no VS Code.

A partir disso, o agente começou a interagir com o Context-7, consultando a documentação do Next.js, do BetterOff e de outras ferramentas necessárias, sempre trazendo apenas o essencial para a tarefa.

Benefícios claros

- Precisão: o código gerado está sempre alinhado com a versão atual da ferramenta.
- Menor custo: prompts menores, menos tokens, menos tentativas.
- Segurança: reduz drasticamente erros por uso de métodos obsoletos.
- Produtividade: o agente consegue criar uma aplicação funcional do zero com um único prompt.
<!-- Página 86 do PDF --> Execução final da aplicação

Ao final da execução:

- O projeto foi criado com npm init usando Next.js.
- Dependências foram instaladas automaticamente.
- O banco local SQLite foi inicializado e migrado.
- O fluxo de login com GitHub foi configurado.
- O projeto rodou localmente na porta 3000.

O agente utilizou o Context-7 para buscar documentação e exemplos de integração com autenticação, banco de dados e configurações do Next.js. Todo o processo foi guiado por esse prompt inicial, e a IA foi capaz de completar as tarefas sem necessidade de correções manuais.

#### Considerações finais

O Context-7 representa um novo patamar no uso de IA para desenvolvimento. Ele garante que os modelos estejam alinhados com o estado atual do mundo, evitando erros comuns de alucinação e desatualização. Isso torna o uso de LLMs mais confiável, mais eficiente e muito mais poderoso.

Se você ainda não usa um servidor MCP como o Context-7 nos seus projetos, este é o momento ideal para começar.

<a id="modulo-08-mcps-e-automacao-para-devs-capitulo-5-usando-ia-para-colher-dados-de-telemetria-de-apps"></a>
### Capítulo 5: Usando IA para: Colher dados de Telemetria de apps

Neste capítulo, exploro como colocar a inteligência artificial para atuar como uma verdadeira detetive digital, utilizando dados de telemetria para investigar falhas em aplicações. O foco é usar AI para interpretar traces, logs e métricas, correlacionando tudo isso em tempo real para produzir relatórios automatizados e precisos.

#### A dor de quem trabalha com bugs intermitentes

<!-- Página 87 do PDF --> Quem já lidou com sistemas em produção sabe: bugs que aparecem e somem são um pesadelo. Logs isolados nem sempre ajudam, e reproduzir o erro pode ser inviável. É aqui que a telemetria entra como solução: ela permite registrar tudo que está acontecendo na aplicação por meio de métricas, logs e traces, entregando uma visão detalhada do comportamento do sistema.

#### A infraestrutura da aula

Utilizei uma aplicação chamada Aluminus, já preparada para emitir dados de telemetria. A instrumentação foi feita com OpenTelemetry, que é hoje o padrão mais adotado para coleta unificada de telemetria.

Esses dados foram enviados para:

- Prometheus: coleta e armazena métricas de performance.
- Grafana Tempo: armazena os traces.
- Grafana Loki: centraliza os logs.
- Grafana: visualiza e correlaciona os sinais em painéis interativos.

Tudo foi orquestrado com Docker Compose para simular um ambiente real de produção.

#### O papel do Grafana MCP e da IA

Para transformar esses dados em conhecimento acionável, utilizei um servidor MCP conectado ao Grafana. Com isso, um agente de IA integrado ao VS Code foi capaz de fazer investigações reais com base em um único prompt: "Estou recebendo erro 500 neste endpoint, descubra o motivo e gere um relatório."

#### Como funciona a investigação automatizada

1. Coleta de métricas: a IA acessa o Prometheus e verifica, por exemplo, que todos os requests estão retornando erro 500.
2. Exploração de logs: acessa o Grafana Loki para analisar os logs relacionados, identificando mensagens de erro.
3. Tracing: consulta o Grafana Tempo para reconstruir a cadeia de chamadas e localizar gargalos.
4. <!-- Página 88 do PDF --> Correlação dos sinais: cruza os dados das três fontes e descobre que o problema está relacionado a um vazamento de conexões com o banco de dados.

O mais incrível é que a IA executa toda essa análise sem acesso ao código- fonte. Ela atua apenas com base nos dados expostos pelas ferramentas de telemetria.

#### Diagnóstico e relatório final

O agente gerou um relatório estruturado com:

- Nome do endpoint afetado.
- Tempo de resposta das requisições.
- Stack trace com falha na conexão com o banco.
- Causa raiz: múltiplas conexões sendo criadas a cada requisição, sem reutilização.
- Linhas suspeitas de código onde o leak ocorre (mesmo sem ter acessado o repositório).

#### Impacto e aplicação real

Essa prática foi usada para resolver um problema real de vulnerabilidade na minha infraestrutura em produção. O poder de usar IA com telemetria permitiu encontrar e explicar rapidamente falhas graves de performance.

#### Por que usar essa abordagem?

- Redução do tempo de investigação: uma tarefa que levaria horas pode ser feita em minutos.
- Precisão no diagnóstico: evita achismos e foca nos dados concretos.
- Menor dependência do código-fonte: ideal para sistemas legados ou desconhecidos.
- Alta integração com ferramentas do mercado: funciona com tecnologias amplamente utilizadas.

#### Considerações finais

<!-- Página 89 do PDF --> Colocar a IA para trabalhar com telemetria é o futuro da observabilidade. Ferramentas gratuitas e poderosas estão à nossa disposição, como Grafana, OpenTelemetry e Prometheus. Integradas a agentes inteligentes via MCP, transformam dados brutos em diagnósticos claros, rápidos e confiáveis.

Se você ainda está usando logs manuais e debugging tradicional, considere experimentar essa abordagem. O ganho de produtividade e clareza é imediato e vale cada segundo investido na configuração inicial.

<a id="modulo-09-modelos-open-source-vs-proprietarios"></a>
## Módulo 09: Modelos open-source vs. proprietários

<a id="modulo-09-modelos-open-source-vs-proprietarios-capitulo-1-vantagens-e-desvantagens-de-modelos-abertos-e-fechados"></a>
### Capítulo 1: Vantagens e desvantagens de modelos abertos e fechados

Neste capítulo, exploro com profundidade as diferenças entre modelos de linguagem abertos e fechados, com base na minha experiência ao buscar alternativas menos restritivas e mais controláveis para o uso de IA no dia a dia. A reflexão parte de uma situação concreta: uma simples dúvida sobre como funciona um emulador de videogame levou a uma cadeia de descobertas sobre os limites dos modelos populares e a abertura para o universo dos modelos open source.

#### Modelos Abertos: o que realmente significa?

No mundo dos LLMs, "aberto" raramente significa o mesmo que em projetos open source tradicionais. Em geral, quando falamos de modelos abertos estamos nos referindo a modelos que permitem o download e execução local ("open weights"), mas não necessariamente com acesso ao pipeline de treinamento ou à base de dados utilizada.

Sites como o Olyama.com são bons exemplos disso. Com comandos simples, como olhama pull e olhama serve, você pode baixar modelos como o LLaMA 3.0 da Meta, o Gemma do Google ou o GPT OSS da OpenAI e executá-los <!-- Página 90 do PDF --> localmente, inclusive offline. Alguns desses modelos estão marcados como "sem censura", permitindo explorações mais livres.

#### Vantagens dos Modelos Abertos

- Custo Reduzido: para quem já possui infraestrutura local (como um PC gamer com boas GPUs), é possível prototipar sem custos de API.
- Privacidade e Controle: ao rodar localmente, você elimina a necessidade de enviar dados sensíveis a terceiros. Isso é essencial para quem lida com informação confidencial.
- Customização: é possível ajustar o modelo ao seu caso de uso, aplicar fine-tuning, criar variantes especializadas e integrar em produtos sem limitações externas.
- Independência de Fornecedor: você não depende das decisões de negócio de empresas como OpenAI ou Google, que podem mudar regras, limites ou preços de uma hora para outra.

#### Desvantagens dos Modelos Abertos

- Infraestrutura Custosa: manter um ambiente local com suporte a modelos grandes é caro. Requer placas de vídeo potentes, refrigeração, energia, distribuição e monitoramento.
- Manutenção Complexa: é preciso cuidar de atualizações, compatibilidades, segurança e escalabilidade. Isso demanda tempo e conhecimento.
- Limitações Legais: modelos como o LLaMA possuem licenças restritivas, limitando uso comercial em certos contextos. A legalidade do uso pode variar conforme o porte da sua empresa.
- Falta de Filtros: modelos "sem censura" podem gerar respostas perigosas, imprecisas ou inapropriadas. Isso exige governança e cuidado redobrado, especialmente em aplicações voltadas a clientes finais.

#### Modelos Fechados: por que ainda fazem sentido?

<!-- Página 91 do PDF --> Apesar dos benefícios dos modelos abertos, os modelos fechados, como os da OpenAI, Google e Anthropic, ainda são a melhor escolha para muitos cenários empresariais. Eles oferecem:

- Qualidade superior: os modelos de ponta em benchmarks ainda são, em geral, fechados.
- Facilidade de uso: basta uma API key para começar. Toda infraestrutura e atualização ficam por conta do fornecedor.
- Escalabilidade garantida: é possível atender milhões de usuários sem se preocupar com distribuição de carga.
- Suporte e estabilidade: contratos comerciais garantem SLA, segurança e conformidade legal.

Hoje, muitos desenvolvedores optam por hubs de IA que permitem trocar dinamicamente de modelo conforme o uso e o perfil de tarefa, pagando apenas por aquilo que realmente utilizam.

#### Reflexão Final

Se você está explorando IA para uso pessoal, testes locais ou prototipagem, modelos abertos oferecem um universo de possibilidades, desde que você tenha estrutura e conhecimento para mantê-los. Já para ambientes empresariais, com necessidades de escalabilidade, conformidade e confiabilidade, os modelos fechados ainda têm grande vantagem.

O mais importante é entender que nenhum dos dois caminhos é universalmente melhor. O segredo está em conhecer os limites e benefícios de cada um e escolher o modelo mais alinhado ao seu contexto técnico, financeiro e legal.

<a id="modulo-09-modelos-open-source-vs-proprietarios-capitulo-2-como-rodar-modelos-localmente-com-ollama"></a>
### Capítulo 2: Como rodar modelos localmente com Ollama

Neste capítulo, compartilho minha experiência pessoal com o Ollama, uma ferramenta extremamente acessível e poderosa para baixar, gerenciar e <!-- Página 92 do PDF --> executar modelos de linguagem de forma local, sem necessidade de conexão com servidores externos. Ao longo do capítulo, explico o funcionamento da ferramenta, suas possibilidades, desafios e a prática de utilização com foco em programadores interessados em IA.

#### O que é o Ollama?

O Ollama é uma aplicação que funciona em MacOS, Windows e Linux, com uma interface simples e uma API HTTP por trás, permitindo integrações com qualquer aplicativo. Criado em cima do ecossistema da Meta e dos modelos LLaMA, o Ollama ganhou destaque a partir de julho de 2023. Seu grande diferencial está na facilidade de uso: com comandos simples como ollama pull e ollama serve, é possível baixar e executar modelos localmente.

O Ollama possui um amplo catálogo de modelos, incluindo modelos gerais, de código e modelos multimodais, que permitem entradas combinadas de texto e imagem.

#### Benefícios do Ollama

- Execução local e offline: ideal para automações, scripts, testes e estudos.
- Gratuito: não exige pagamento por tokens.
- Compatibilidade com vários modelos: LLaMA, GPT OSS, Gemma, entre outros.
- Interface amigável e terminal integrável: permite integração com curl, scripts shell, editores e servidores MCP.

#### Limitações

Apesar das vantagens, o Ollama não é indicado para uso em produção. Ele executa apenas um prompt por vez, demanda muitos recursos da máquina local e não oferece alta concorrência. Em ambientes com necessidades de escalabilidade e baixa latência, ferramentas como VLLM são mais apropriadas.

#### Parâmetros, Contexto e Quantização

<!-- Página 93 do PDF --> Para entender o comportamento dos modelos, explico três conceitos importantes:

- Parâmetros: representam os pesos do modelo, ou seja, o que ele aprendeu. Mais parâmetros geralmente indicam maior capacidade, mas também mais exigência computacional. Exemplos: modelos 20B (bilhões de parâmetros) e 120B.
- Tamanho de contexto: define quantos tokens (palavras, frases, comandos) podem ser processados por vez. Por exemplo, 32k, 128k ou até 1M tokens.
- Quantização: processo de reduzir o tamanho do modelo, substituindo a representação numérica dos pesos. Modelos quantizados usam menos memória e rodam mais rápido, com uma leve perda de qualidade.

Sufixos como Q4F32__1 indicam os esquemas de quantização aplicados (ex.: pesos em 4 bits, ativações em 32 bits). Isso permite rodar modelos de 20B com apenas 16GB de RAM.

#### Experimentação com Curl e Interface HTTP

Mostro como é simples criar scripts que utilizam o Ollama via terminal. Com a API HTTP, podemos fazer requisições curl para enviar prompts e receber respostas em JSON. Isso permite integração com qualquer sistema, inclusive para automação local.

A execução pode usar endpoints compatíveis com a API da OpenAI, o que facilita portar aplicações existentes para o Ollama.

#### Modelos com ou sem censura

Exploro a diferença entre modelos censurados e modelos "sem censura". Enquanto alguns modelos limitam respostas que envolvem temas sensíveis, outros não impõem filtros. Isso pode ser útil em ambientes de pesquisa ou estudo, mas exige responsabilidade, especialmente em aplicações de uso geral.

#### Integração com Jan AI

<!-- Página 94 do PDF --> Apresento o Jan AI, uma aplicação desktop open source que permite usar modelos locais com funcionalidades semelhantes ao ChatGPT, incluindo assistentes, historórico, banco vetorial, file system e integração com MCPs.

O Jan AI suporta modelos de várias fontes (OpenRouter, Hugging Face, Ollama, etc.) e permite configurar o MCP localmente, o que viabiliza interação com arquivos do sistema, navegação web, e uso em projetos pessoais.

#### Jan AI no Editor de Código

Demonstro como integrar o Jan AI no editor de código para usar modelos locais em atividades como geração de código, refatoramento e revisão. Basta adicionar o provedor Ollama e selecionar o modelo desejado. Assim, mesmo modelos pequenos podem ajudar no dia a dia sem qualquer custo.

#### Considerações Finais

Rodar modelos localmente com o Ollama é uma excelente alternativa para programadores que desejam explorar IA de forma econômica e independente. Apesar das limitações em ambientes de produção, para prototipagem, automação local e estudo, a experiência é incrível.

Ao dominar ferramentas como Ollama e Jan AI, você potencializa suas aplicações de IA, reduz custos e ganha liberdade para experimentar. O segredo está em compreender as limitações de hardware, escolher modelos adequados ao seu cenário e aplicar boas práticas de prompt engineering.

<a id="modulo-09-modelos-open-source-vs-proprietarios-capitulo-3-como-usar-openrouter-para-orquestrar-varios-modelos"></a>
### Capítulo 3: Como usar OpenRouter para orquestrar vários modelos

Neste capítulo, compartilho como utilizo o OpenRouter para orquestrar diferentes modelos de linguagem em um único ponto de integração. A motivação para isso veio da dificuldade de manter várias integrações simultâneas com APIs de <!-- Página 95 do PDF --> diferentes fornecedores, cada uma com seu SDK, formatos, limitações e custos distintos.

#### Por que usar um orquestrador?

Quando você começa a usar diferentes modelos (como OpenAI, Google, Anthropic, etc.), percebe que o trabalho de integração vira um caos: diversas API keys, SDKs, regras, dashboards de billing espalhados e um risco real de vendor lock-in. Com um orquestrador como o OpenRouter, tudo isso é centralizado.

OpenRouter é uma API unificada, compatível com o padrão da OpenAI, que permite trocar de modelo ou provedor por configuração, sem alterar a lógica da aplicação. Isso muda completamente o jogo para aplicações reais, oferecendo flexibilidade, escalabilidade e manutenção simplificada.

#### Funcionalidades do OpenRouter

- Fallback automático: se um modelo falha, ele tenta outro automaticamente.
- Roteamento por custo ou desempenho: você define suas prioridades (como latência ou preço) e ele escolhe.
- Cobrança consolidada: um único billing, mesmo que você use modelos de diferentes provedores.
- Modelos gratuitos: muitos modelos não exigem cartão de crédito.
- Compatibilidade com padrões: APIs, formatos e autenticação semelhantes ao da OpenAI.

#### Como Começar

#### O processo é simples:

1. Acesse o site do OpenRouter.
2. Crie uma conta gratuita.
3. Navegue pelos modelos disponíveis, aplicando filtros como "100% Free".
4. Gere sua API Key e configure variáveis de ambiente como OPENROUTER_KEY e outras.
<!-- Página 96 do PDF --> Com a chave gerada, você pode começar a testar modelos gratuitos com controle total.

#### Casos de uso reais e modelos

Durante a aula, usei o modelo Gemma 27B, que possui 27 bilhões de parâmetros e um desempenho interessante para tarefas gerais de linguagem. Mesmo sendo gratuito, ele entregou respostas surpreendentes.

Outros modelos também estão disponíveis, como o LLaMA 2, Mistral e modelos menores como 4B ou 2B que podem ser utilizados até no navegador.

Você pode classificar modelos por tipo (texto, imagem, embeddings) e por custo. A maioria dos modelos multimodais e de embeddings ainda não possui opções gratuitas, mas isso pode mudar com o tempo.

#### Cuidados com a segurança

Durante a demonstração, destaquei a importância de manter as chaves de API fora do controle de versão. Um erro comum é subir o arquivo de configuração para o GitHub e expor a chave. O OpenRouter tem mecanismos de segurança para invalidar chaves vazadas automaticamente, mas o ideal é sempre proteger esses dados.

#### Integrações Bring Your Own Key (BYOK)

Além dos modelos já disponibilizados, é possível plugar suas próprias chaves da OpenAI, Anthropic, entre outros. Isso permite manter o controle sobre sua cota enquanto aproveita os benefícios do orquestrador.

#### Conclusão

Usar o OpenRouter é uma excelente estratégia para quem deseja liberdade na escolha de modelos, economia de custos e simplicidade na integração com aplicações reais. Para protótipos, testes e até mesmo alguns usos em produção, ele se mostra uma solução robusta e acessível.

<!-- Página 97 do PDF --> Recomendo fortemente que você experimente o OpenRouter nos seus projetos, explore diferentes modelos e construa sua própria arquitetura de IA sem amarras.

<a id="modulo-10-rag-embeddings-e-busca-semantica"></a>
## Módulo 10: RAG, embeddings e busca semântica

<a id="modulo-10-rag-embeddings-e-busca-semantica-capitulo-1-o-que-e-rag-retrieval-augmented-generation-e-por-que-ele-e-tao-importante"></a>
### Capítulo 1: O que é RAG (Retrieval-Augmented Generation) e por que ele é tão importante

Neste capítulo, explico em detalhes o conceito de RAG (Retrieval-Augmented Generation), por que ele é essencial na arquitetura de sistemas com LLMs, como ele funciona e de que forma se diferencia de outras abordagens como fine-tuning e MCP.

#### A Essência do RAG

O RAG é uma arquitetura que adiciona um passo fundamental antes da geração de resposta por uma LLM: a busca de informação externa relevante. Ou seja, em vez do modelo depender apenas do que foi aprendido durante o seu treinamento, ele passa a contar com informações injetadas dinamicamente no contexto.

Isso permite que a LLM gere respostas com base em dados atualizados, privados ou específicos de um domínio, algo que seria inalcançável apenas com os dados embutidos em seus parâmetros.

#### Memória Paramétrica vs. Não Paramétrica

#### RAG se apoia em dois tipos de memória:

Memória paramétrica: é o conhecimento aprendido durante o treinamento e codificado nos pesos do modelo.

<!-- Página 98 do PDF --> Memória não paramétrica: é uma base de dados externa, pesquisável, que geralmente utiliza um índice vetorial para identificar trechos relevantes para cada pergunta.

O conceito de RAG surgiu formalmente em 2020 com um paper que consolidou essa ideia de combinar os dois tipos de memória para melhorar a precisão das respostas.

#### O Problema da Ausência de Contexto

Para entender o valor do RAG, precisamos lembrar como um transformer funciona: ele prediz o próximo token com base no contexto atual. Se o contexto fornecido não contém a informação correta, o modelo tende a completar a resposta com base em padrões aprendidos, o que pode gerar erros ou alucinações.

Com o RAG, em vez de tentar confiar na memória do modelo, garantimos que o contexto contenha os trechos certos na hora certa. Isso muda o jogo.

#### Como Funciona na Prática

#### A aplicação do RAG se divide em duas fases:

#### Indexação:

Coletamos fontes de dados como documentos, tickets, códigos, tabelas, PDFs.

Esses dados são divididos em pedaços coerentes (chunks).

Cada pedaço recebe um embedding (vetor numérico) e é armazenado em um banco vetorial.

#### Consulta:

O usuário envia uma pergunta.

A pergunta também é convertida em embedding.

O sistema busca os embeddings mais similares no banco vetorial.

<!-- Página 99 do PDF --> Os trechos mais relevantes são injetados no prompt para a LLM.

Assim, a resposta gerada está fundamentada em informação real e contextualizada.

#### Casos Reais de Uso

Imagine um chatbot corporativo que responde a perguntas sobre procedimentos internos, postmortems, diagnósticos ou código legado. Com RAG, o sistema busca e injeta apenas os trechos relevantes desses documentos, sem necessidade de treinar novamente o modelo.

Exemplo clássico: o usuário pergunta "Por que o endpoint /checkout está dando erro 500?". O sistema, usando embeddings, busca trechos de runbooks, incidentes e código e injeta isso no prompt, possibilitando uma resposta fundamentada, com base em evidências.

#### Diferença entre RAG, MCP e Fine-Tuning

RAG: é o método de buscar informação relevante antes de responder. Ele melhora a qualidade sem alterar os pesos do modelo.

MCP (Model Context Protocol): é um protocolo de integração que permite que o modelo acesse ferramentas externas, como buscadores, editores, sistemas de arquivos. Pode ser usado como canal para o RAG, mas não é um método de recuperação em si.

Fine-tuning: é o processo de ajustar os pesos do modelo com novos exemplos. A memória se torna permanente, mas exige custo, tempo e conhecimento para treinar.

Dar contexto com RAG é diferente de treinar. O modelo apenas usa as informações enquanto estão no prompt. Ao final da interação, esse conhecimento é descartado, diferente do que ocorre com fine-tuning.

#### Considerações Finais

<!-- Página 100 do PDF --> RAG é uma das formas mais poderosas de tornar LLMs realmente úteis em cenários corporativos. Permite acesso a conhecimento privado, atualizações constantes e evita a alucinação por falta de contexto. A chave está no uso eficiente de embeddings e em um banco vetorial bem estruturado.

Nos próximos capítulos, vamos explorar na prática como esses embeddings funcionam e como você pode construir seu primeiro sistema RAG do zero. Se você quer aumentar a precisão, reduzir erros e integrar conhecimento real no seu sistema de IA, dominar RAG é essencial.

<a id="modulo-10-rag-embeddings-e-busca-semantica-capitulo-2-o-que-sao-embeddings-e-vector-databases"></a>
### Capítulo 2: O que são Embeddings e Vector Databases

Quando falamos de inteligência artificial hoje em dia, a primeira imagem que surge na mente da maioria das pessoas é a de um chatbot respondendo perguntas de forma articulada. No entanto, por trás dessa interface interativa e sofisticada, existe um componente muito mais fundamental e menos glamouroso: os embeddings e a busca por similaridade. Esses são os verdadeiros motores que tornam as soluções de IA realmente úteis e relevantes para os usuários.

Neste capítulo, quero mostrar de maneira prática como isso funciona. A proposta é apresentar a mecânica que sustenta o funcionamento de sistemas de IA, sem truques ou aparências polidas, e sem a interferência de modelos generativos. Vamos explorar o conceito de embeddings, como eles são gerados, armazenados e utilizados em buscas por similaridade dentro de um banco de dados vetorial, utilizando o Neo4j.

#### Entendendo Busca por Similaridade

Diferente do comando Ctrl+F usado para encontrar palavras exatas em documentos, a busca por similaridade trabalha com o sentido e não com a forma literal das palavras. Ao transformar trechos de texto em vetores (os embeddings), conseguimos identificar similaridades sem depender de palavras idênticas. Dois <!-- Página 101 do PDF --> textos com significados parecidos, mesmo que escritos com palavras distintas, serão representados por vetores próximos no espaço vetorial.

Imagine que você quer saber o que é backpropagation, ou como uma rede neural ajusta os pesos, ou ainda como funciona um gradiente descendente. Mesmo que esses termos específicos não estejam na transcrição de uma aula, um sistema baseado em embeddings é capaz de encontrar trechos relevantes onde esses conceitos são explicados com outras palavras.

Embeddings são representações numéricas que codificam o significado de um texto. Podemos imaginá-los como um mapa em que ideias semelhantes estão geograficamente próximas. Quando fazemos uma consulta, o sistema apenas faz os cálculos matemáticos para determinar quais vetores estão mais próximos do vetor da consulta.

#### O Papel do Neo4j como Banco Vetorial

Apesar de ser conhecido como um banco de dados de grafos, o Neo4j também funciona excelentemente como um vector database. Nele, armazenamos os pedaços de texto (chunks) como nós do grafo, e os embeddings como propriedades desses nós. Criamos um índice vetorial que permite consultas por similaridade, retornando os trechos mais relevantes de acordo com a proximidade dos vetores.

Uma das vantagens desse tipo de abordagem é a possibilidade de enriquecer os dados. Cada chunk pode ter metadados associados, como o título da aula, a seção, o minuto do vídeo e outros. Isso possibilita consultas mais estáveis e resultados com maior contextualização.

#### Geração Local de Embeddings

Para essa experiência, utilizei a biblioteca Transformer.js para gerar os embeddings localmente. Isso significa que conseguimos fazer tudo sem depender de chaves de API, sem usar Docker e sem sobrecarregar a máquina. Tudo funciona em Node.js puro.

<!-- Página 102 do PDF --> O fluxo é simples: pegamos uma transcrição de aula em PDF, quebramos em pedaços menores (chunks), geramos embeddings desses pedaços e armazenamos no Neo4j. Em seguida, é possível realizar perguntas e visualizar os trechos mais semelhantes com base apenas na similaridade vetorial. É o puro funcionamento do mecanismo de RAG (Retrieval-Augmented Generation), mas sem a parte de "generation" ainda.

#### Da Teoria à Prática

Durante a prática, usei um exemplo com uma transcrição de aula sobre tensores. Peguei o arquivo PDF e, através de uma pipeline local, transformei o texto em chunks e gerei os embeddings para cada um. Cada trecho foi indexado no Neo4j com metadados. Em seguida, executei consultas como "o que é one hot encoding?" ou "como treinar uma rede neural?". Mesmo sem essas frases exatas na transcrição, o sistema foi capaz de retornar parágrafos altamente relevantes.

Esse processo deixa claro que a busca por similaridade é um componente essencial para a IA moderna. Antes mesmo de um modelo generativo responder algo, ele precisa de um contexto relevante, e esse contexto é fornecido por um mecanismo como esse.

#### Conclusão

A compreensão profunda de embeddings e vector databases é vital para qualquer desenvolvedor que deseje trabalhar com sistemas de IA mais robustos e confiáveis. Eles são a espinha dorsal das aplicações baseadas em RAG e são o elo entre o armazenamento eficiente e a inteligência contextual das respostas. No próximo capítulo, vamos conectar esse mecanismo de embeddings com um modelo de linguagem para realizar respostas completas, fechando o ciclo do RAG com geração de linguagem natural.

<a id="modulo-10-rag-embeddings-e-busca-semantica-capitulo-3-projeto-criando-o-primeiro-rag-com-javascript-e-neo4j"></a>
### Capítulo 3: Projeto: Criando o primeiro RAG com JavaScript e Neo4j

<!-- Página 103 do PDF --> Neste capítulo, compartilho como criei meu primeiro projeto completo de RAG utilizando JavaScript e Neo4j. A proposta foi transformar uma transcrição de aula em uma base consultável, capaz de responder perguntas com base em busca por similaridade, antes mesmo de usar modelos generativos.

Comecei o projeto com a leitura e preparação do conteúdo em formato PDF. Dividi a transcrição em pedaços coerentes, chamados de chunks, cada um representando um trecho com sentido completo. Em seguida, utilizei a biblioteca transformer.js para gerar os embeddings localmente. Isso significa que não dependi de serviços externos, chaves de API ou infraestrutura pesada — tudo rodando localmente, de forma leve e eficiente.

Esses embeddings, que são vetores numéricos representando o significado de cada chunk, foram armazenados em um banco vetorial dentro do Neo4j. Cada chunk ficou associado a metadados como o minuto da aula, o nome do arquivo e a posição no texto. Isso trouxe não apenas contexto, mas também a possibilidade de organizar e refinar as buscas posteriormente.

Na segunda fase do projeto, implementei uma etapa de consulta por similaridade. O sistema converte as perguntas em embeddings, compara com os armazenados no Neo4j e retorna os trechos mais próximos. Essa etapa permitiu criar um sistema de memória não paramétrica, fundamental para o funcionamento do RAG, garantindo que o modelo receba sempre o contexto certo antes de gerar qualquer resposta.

A construção dessa base deixou claro o quanto a engenharia de dados é essencial para IA. O modelo só é bom quando alimentado com dados relevantes e bem estruturados. Ter controle sobre os embeddings, sobre os metadados e sobre a forma como os trechos são indexados me deu autonomia para criar uma arquitetura de IA verdadeiramente útil.

Finalizo este capítulo com a certeza de que dominar esse tipo de projeto é o passo mais importante para qualquer desenvolvedor que queira levar IA a sério. Com esse tipo de estrutura, podemos alimentar modelos com conhecimento real, atualizado e alinhado ao nosso domínio. E o melhor: sem depender de soluções prontas ou fechadas.

<!-- SOURCE_END -->
