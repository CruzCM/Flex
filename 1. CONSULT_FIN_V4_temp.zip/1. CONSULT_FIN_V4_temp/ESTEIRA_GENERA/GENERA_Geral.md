# Visão Geral — Genera BB
## O que é o Genera BB
O Genera BB é a plataforma A2B2 do EmpresaBB para criação, gestão e implementação de assistentes e agentes de IA generativa corporativa. Com uma interface intuitiva, acessível e moderna, organizada em módulos de Home, Engenharia de Prompt, Gestão de Agentes, Marketplace e Experimentação de Chat, o Genera BB facilita a experiência de uso tanto para usuários iniciantes quanto para equipes técnicas.

A plataforma oferece fluxos simplificados e maior integração com os serviços internos do Banco, ampliando o potencial de automação com IA generativa de forma segura e padronizada.

💡 Dica: conheça a Plataforma do Genera BB.

## Para que serve
- Desenvolver assistentes de IA personalizados, como bots de atendimento, suporte interno ou automação de tarefas corporativas;
- Criar e testar prompts por meio do módulo de Engenharia de Prompt, com versionamento e controle de descrições;
- Gerenciar agentes de ponta a ponta — com ou sem RAG, no formato Watson Like, orquestrados (Beta) ou via Agent Harness — incluindo configuração de índice, prompt, serviço, rate limit, ambiente e camada de segurança GeneraSafe;
- Explorar e reaproveitar soluções prontas no Marketplace (extensões, agentes, MCPs, skills, instruções e soluções Genera BB);
- Experimentar rapidamente os agentes criados no módulo de Experimentação de Chat, antes de publicá-los;
- Facilitar a adoção de IA generativa com governança centralizada, alinhada aos padrões da DITEC e da A2B2; e
- Promover autonomia, rastreabilidade e escalabilidade no desenvolvimento de soluções com IA dentro do BB, sem depender de ferramentas externas.
## Objetivo principal
Oferecer uma plataforma segura, acessível e padronizada para experimentar, desenvolver, testar e aplicar IA generativa de forma integrada aos sistemas e fluxos do EmpresaBB — da criação do prompt até a publicação do agente em produção.

## Público-alvo
O Genera BB é indicado para:

- Equipes que buscam automação inteligente para tarefas repetitivas;
- Áreas que lidam com grandes volumes de dados e precisam de respostas contextualizadas com agilidade, inclusive com bases de conhecimento indexadas (RAG);
- Times que querem incorporar IA generativa a processos internos, mantendo o controle sobre os dados e o ciclo de vida dos agentes;
- Unidades que buscam soluções seguras, padronizadas e com governança, sem expor dados a plataformas de terceiros; e
- Desenvolvedores que desejam estender seus editores e fluxos de trabalho com extensões e MCPs disponíveis no Marketplace.
## Principais funcionalidades
- Criação de assistentes e agentes de IA corporativos, com ou sem uso de bases indexadas (RAG), diretamente na Home da plataforma;
- Geração de imagens e soluções de texto a partir de prompts, também acessíveis pela Home;
- Criação e conexão de MCPs (Model Context Protocol), conectando agentes e assistentes a ferramentas, dados e sistemas externos de forma padronizada;
- Interface amigável e redesenhada, com novos fluxos de configuração, publicação e testes;
- Engenharia de prompts com versionamento e teste integrado, incluindo histórico de versões (v1, v2, v3...) e descrições reutilizáveis;
- Gestão de agentes por categoria: Agente com ou sem RAG, Agente Orquestrador (Beta) e Agent Harness, com visualização de agentes legado;
- Indexação de bases de conhecimento internas com múltiplas opções de segmentação;
- Controle de acesso e permissões por UOR, além de parâmetros como rate limit e ambiente (ex.: Homologação);
- Camada de segurança GeneraSafe, para avaliação de segurança, ética, vieses e ataques de injeção de prompt nas interações com os agentes semânticos;
- Marketplace de recursos reutilizáveis, com seis categorias: Extensões do VS Code, Agentes, MCP, Skills, Instruções e Soluções Genera BB, para acelerar novas iniciativas;
- Monitoramento e auditoria das interações, com foco em segurança, rastreabilidade e conformidade; e
- Experimentação de chat, permitindo testar os agentes criados antes da publicação.

# Integrar agentes com sistemas externos
## Visão geral
Esta documentação explica como integrar agentes do Genera BB em sistemas internos utilizando API REST.

Nesta seção, você vai aprender:

- Como funciona a integração via API;
- Quais headers são obrigatórios;
- Como estruturar requisições;
- Como enviar imagens ao agente (consumo multimodal);
- Como recuperar contextos do agente;
- Como gerenciar índices via API (coletar, indexar, trocar e acompanhar);
- Como consumir a API usando certificado (CA Bundle); e
- Quais são os limites de uso.
## Quando usar integração
Use integração quando precisar:

- Embutir agentes em sistemas internos;
- Criar interfaces customizadas;
- Automatizar fluxos de conversação; e
- Integrar microsserviços com agentes generativos.
💡 Dica: Para uso manual e exploratório, utilize a Experimentação de Chat do Genera BB.

## Como funciona a integração
A integração acontece via API REST, seguindo este fluxo:

- Seu sistema envia uma requisição HTTP POST;
- O Genera autentica a chamada (Client ID + UOR);
- O agente processa o input; e
- A API retorna a resposta em JSON.
Os componentes principais da integração são:

- Requisição POST com payload JSON (ou multipart/form-data, no caso de upload de arquivos e imagens);
- Headers de autenticação obrigatórios; e
- Endpoint unificado para todos os agentes.

# Integrar agentes com sistemas externos
## Visão geral
Esta documentação explica como integrar agentes do Genera BB em sistemas internos utilizando API REST.

Nesta seção, você vai aprender:

- Como funciona a integração via API;
- Quais headers são obrigatórios;
- Como estruturar requisições;
- Como enviar imagens ao agente (consumo multimodal);
- Como recuperar contextos do agente;
- Como gerenciar índices via API (coletar, indexar, trocar e acompanhar);
- Como consumir a API usando certificado (CA Bundle); e
- Quais são os limites de uso.
## Quando usar integração
Use integração quando precisar:

- Embutir agentes em sistemas internos;
- Criar interfaces customizadas;
- Automatizar fluxos de conversação; e
- Integrar microsserviços com agentes generativos.
💡 Dica: Para uso manual e exploratório, utilize a Experimentação de Chat do Genera BB.

## Como funciona a integração
A integração acontece via API REST, seguindo este fluxo:

- Seu sistema envia uma requisição HTTP POST;
- O Genera autentica a chamada (Client ID + UOR);
- O agente processa o input; e
- A API retorna a resposta em JSON.
Os componentes principais da integração são:

- Requisição POST com payload JSON (ou multipart/form-data, no caso de upload de arquivos e imagens);
- Headers de autenticação obrigatórios; e
- Endpoint unificado para todos os agentes.
## Autorização e permissões
### Client ID
O Client ID identifica sua aplicação consumidora. Confira a seguir suas características principais:

| Atributo | Descrição |
| --- | --- |
| Pertence a | UOR (não ao usuário ou agente) |
| Criação | Automática no primeiro acesso da UOR |
| Compartilhamento | Todos os usuários da mesma UOR usam o mesmo Client ID |
### UOR
O header UOR deve:

- Ser a mesma vinculada ao Client ID; e
- Corresponder à UOR autorizada no agente.
⚠️ Atenção: Inconsistência entre Client ID e UOR retorna erro de autorização.

### Permissão da UOR no agente
Mesmo com Client ID válido, sua UOR precisa estar autorizada no agente. Se ela não tiver permissão:

- A integração será bloqueada; e
- Você deve solicitar a liberação à equipe responsável pelo agente.
### Onde obter os valores dos headers
Os valores de UOR, X-Client-Id e userIdentification são obtidos em Meus dados, no menu superior da Plataforma do Genera BB. As mesmas credenciais utilizadas na chamada via API de um agente específico também podem ser consultadas na aba Integração do agente, dentro da Gestão de Agentes.

Para acessar os valores, siga os passos a seguir:

Passo 1. Na tela inicial do Genera BB, clique em Meus dados, no menu superior;

Passo 2. No modal exibido, confira os campos a seguir:

| Campo no modal | Header correspondente | Descrição |
| --- | --- | --- |
| Chave | userIdentification | Sua matrícula, usada para rastreabilidade e auditoria |
| UOR | UOR | Número da UOR vinculada ao seu Client ID |
| Client ID | X-Client-Id | Token que identifica sua aplicação consumidora |
Passo 3. Clique no botão Copiar ao lado do campo Client ID para copiá-lo integralmente; e
Passo 4. Clique no botão Entendi para fechar o modal.

💡 Dica: O Client ID é um token longo — utilize o botão de cópia para evitar erros de transcrição.

💡 Dica: Consulte também a documentação de integração de agentes no portal TechBB.

## Headers da requisição
### Obrigatórios
| Header | Função |
| --- | --- |
| X-Client-Id | Identifica a aplicação consumidora |
| UOR | Valida a organização autorizada |
| Content-Type | application/json para requisições comuns, ou multipart/form-data para upload de arquivos/imagens |
```text
Exemplo de headers obrigatórios
X-Client-Id: 
UOR: 
Content-Type: application/json
```
### Recomendado
#### userIdentification
O header userIdentification recebe a matrícula da pessoa que está usando o sistema.

Ele não é obrigatório, mas é fortemente recomendado para:

- Rastreabilidade de acessos;
- Auditoria de uso; e
- Observabilidade do sistema.
```text
userIdentification: 
```
## Estrutura da requisição
### Endpoint
```text
POST https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent
```
### Payload JSON básico
```json
{
"action": "conversar",
"body": {
  "data": {
    "input": "Qual é o saldo da conta?",
    "context": {
      "messages": []
    }
  }
},
"agent_id": "nome-do-agente"
}
```
### Campos obrigatórios
| Campo | Tipo | Descrição |
| --- | --- | --- |
| action | String | Operação executada (ex.: "conversar") |
| body.data.input | String | Texto enviado ao agente |
| agent_id | String | Identificador do agente |
| context.messages | Array | Histórico de mensagens (pode estar vazio) |
### Exemplo de integração básica
cURL
```bash
curl -X POST \
'https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent' \
-H 'accept: application/json' \
-H 'X-Client-Id: ' \
-H 'UOR: ' \
-H 'userIdentification: ' \
-H 'Content-Type: application/json' \
-d '{
  "action": "conversar",
  "body": {
    "data": {
      "input": "Qual é o saldo da conta?",
      "context": {
        "messages": []
      }
    }
  },
  "agent_id": "nome-do-agente"
}'
```
### Configuração avançada (opcional)
#### Payload com parâmetros adicionais
Use este formato apenas se o prompt do agente possuir parâmetros adicionais.

```json
{
"action": "conversar",
"body": {
  "data": {
    "input": "Analise o cliente 12345",
    "context": {
      "messages": []
    },
    "prompt_params": {
      "cliente_id": "12345",
      "tipo_analise": "credito"
    },
    "config": {
      "temperature": 0.8,
      "max_tokens": 1000
    }
  }
},
"agent_id": "nome-do-agente"
}
```
#### Campos opcionais
| Campo | Tipo | Descrição |
| --- | --- | --- |
| prompt_params | Object | Parâmetros customizados do prompt |
| config.temperature | Number | Controla criatividade (0.0 a 1.0) |
| config.max_tokens | Number | Tamanho máximo da resposta |
### Envio de imagens (consumo multimodal)
Agentes configurados com modelo multimodal podem receber uma imagem como parte do input, além do texto. Diferente das demais operações — que usam Content-Type: application/json —, esta chamada usa multipart/form-data, pois combina um arquivo binário com um payload JSON no mesmo request.

#### Endpoint
```text
POST https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent/upload
```
#### Headers obrigatórios
| Header | Valor | Observação |
| --- | --- | --- |
| Content-Type | multipart/form-data | Definido automaticamente pelo cliente HTTP ao usar --form; não fixar boundary manualmente |
| UOR | Sua UOR | Deve corresponder à UOR do X-Client-Id |
| X-Client-Id | Token da aplicação | Obtido em Meus dados |
| userIdentification | Matrícula | Recomendado para rastreabilidade e auditoria |
#### Campos do formulário (--form)
| Campo | Tipo | Obrigatório | Descrição |
| --- | --- | --- | --- |
| action | string | Sim | Operação a executar (conversar) |
| file | binary | Sim | Arquivo de imagem. Formatos aceitos: .png, .jpg, .jpeg |
| payload | JSON (string) | Sim | Contém body.data (input, context, config) e agent_id — mesma estrutura usada nas demais requisições ao agente |
⚠️ Atenção: O campo payload deve ser enviado como string JSON válida dentro do form-data — não como um objeto JSON solto no corpo da requisição, como ocorre em Content-Type: application/json.

#### Estrutura interna do payload
| Campo | Tipo | Obrigatório | Descrição |
| --- | --- | --- | --- |
| body.data.input | string | Sim | Texto/pergunta relacionada à imagem enviada |
| body.data.context.messages | array | Sim | Histórico de mensagens (pode ser []) |
| body.data.context.total_context | number | Opcional | Quantidade de contextos recuperados da base, se o agente usar RAG (Retrieval-Augmented Generation) |
| body.data.config.temperature | number (0.0–1.0) | Opcional | Controla aleatoriedade da resposta |
| body.data.config.max_tokens | number | Opcional | Limite de tokens da resposta |
| agent_id | string | Sim | Identificador do agente configurado com modelo multimodal |
#### Exemplo de requisição (cURL)
```bash
curl --request POST \
--url https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent/upload \
--header 'UOR: ' \
--header 'X-Client-Id: ' \
--header 'userIdentification: ' \
--form 'action=conversar' \
--form 'file=@./sua-imagem.png;type=image/png' \
--form 'payload={
  "body": {
    "data": {
      "input": "O que é a imagem?",
      "context": {
        "messages": [],
        "total_context": 1
      },
      "config": {
        "temperature": 0.5,
        "max_tokens": 100
      }
    }
  },
  "agent_id": "nome-do-agente"
}'
```
⚠️ Atenção: Não defina --header 'Content-Type: multipart/form-data' manualmente ao usar --form no cURL — o próprio cliente gera o header com o boundary correto. Fixar o header manualmente sem o boundary invalida o parsing do multipart no servidor.

💡 Dica: O parâmetro ;type=image/png no campo file é opcional, mas recomendado para garantir que o servidor identifique corretamente o Content-Type da imagem, especialmente em pipelines automatizados onde a extensão do arquivo pode não refletir o tipo real.

#### Pré-requisitos do agente
Antes de enviar imagens, confirme que o agente:

- Está configurado com um modelo multimodal compatível (verifique na aba de configuração do agente no Genera BB);
- Possui agent_id válido e ativo; e
- Tem a UOR chamadora autorizada.
Se o agente não for multimodal, a imagem é ignorada silenciosamente — a API retorna resposta apenas com base no input textual, sem erro explícito. Por isso, sempre valide a configuração do agente antes de depurar falhas de interpretação de imagem.

#### Erros específicos deste endpoint
| Cenário | Comportamento |
| --- | --- |
| file ausente | 400 Bad Request — campo obrigatório não enviado |
| Formato de imagem não suportado | 400 Bad Request ou erro de parsing no file |
| payload mal formatado (JSON inválido dentro da string) | 400 Bad Request |
| Agente não multimodal | 200 OK, porém a resposta ignora o conteúdo da imagem |
| Tamanho de arquivo excedido | 413 Payload Too Large (verifique o limite vigente com a equipe Genera) |
### Recuperação de contexto
A funcionalidade de Recuperação de Contexto retorna os trechos mais similares da base do agente, sem gerar resposta conversacional. Essa funcionalidade é vinculada a um agente específico e utiliza o campo action com o valor "recuperar-contexto" no payload.

#### Quando usar
Use recuperação de contexto para:

- Validar quais contextos o agente está buscando;
- Testar similaridade antes de conversar; e
- Auditar o comportamento do agente.
#### Estrutura da requisição
##### Mudanças necessárias
Para usar essa funcionalidade, ajuste o payload conforme os passos a seguir:

Passo 1. Altere action para "recuperar-contexto"; e

Passo 2. Adicione total_context dentro de context.

#### Exemplo de payload
```json
{
"action": "recuperar-contexto",
"body": {
  "data": {
    "input": "qual IN fala sobre cartão de crédito?",
    "context": {
      "messages": [],
      "total_context": 10
    }
  }
},
"agent_id": "nome-do-agente"
}
```
#### Parâmetros
| Campo | Obrigatório | Descrição |
| --- | --- | --- |
| action | Sim | Deve ser "recuperar-contexto" |
| total_context | Sim | Quantidade de contextos similares retornados |
| input | Sim | Texto para cálculo de similaridade |
### Gestão de índices via API
Além de conversar com o agente, a API permite coletar, indexar, trocar e acompanhar o processamento de bases de conhecimento (índices), diretamente por integração — sem passar pela interface da plataforma.

⚠️ Atenção: A API não permite excluir dados de um índice existente. Apenas atualizações são suportadas, mantendo o mesmo index_id durante o processo de reindexação.

#### Coletar corpus
Envie o arquivo .zip com o conteúdo que será indexado.

```bash
curl --request POST \
--url https://generabb-acs.gbb.servicos.bb.com.br/gateway/core/upload \
--header 'Content-Type: multipart/form-data' \
--header 'UOR: ' \
--header 'X-Client-Id: ' \
--header 'userIdentification: ' \
--form action=coletar-corpus \
--form file=@/home/user/Downloads/952-2.zip \
--form index_id=idx-tst-001
```
#### Indexar corpus
Após coletar o corpus, dispare o processamento de indexação informando o serviço de embeddings, o vetor de armazenamento e a modalidade de indexação.

```bash
curl --request POST \
--url https://generabb-acs.gbb.servicos.bb.com.br/gateway/core \
--header 'Content-Type: application/json' \
--header 'UOR: ' \
--header 'X-Client-Id: ' \
--header 'userIdentification: ' \
--data '{
      "action": "indexar-corpus",
      "body": {
          "index_id": "idx-tst-001",
          "service": "AZURE_EMBEDDINGS_API_700_TPM",
          "vector_store": "opensearch",
          "indexing_modality": "vanilla",
          "segment_size": 450,
          "splitter": {
              "method": "RecursiveCharacterTextSplitter",
              "chunk_overlap": 0.1,
              "separators": [
                  "\n\n",
                  "\n",
                  "."
              ]
          }
      }
  }'
Copy
```
#### Exemplos de configuração de indexação
##### 1. Segmentação por caracteres (RecursiveCharacterTextSplitter)
Segmenta o conteúdo em chunks usando RecursiveCharacterTextSplitter, com segment_size 450 e 10% de overlap.

```json
{
  "index_id": "idx-001",
  "service": "AZURE_EMBEDDINGS_API_700_TPM",
  "vector_store": "opensearch",
  "indexing_modality": "vanilla",
  "segment_size": 450,
  "splitter": {
      "method": "RecursiveCharacterTextSplitter",
      "chunk_overlap": 0.1,
      "separators": ["\n\n", "\n", "."]
  }
}
```
##### 2. Segmentação por cabeçalhos Markdown (MarkdownHeaderTextSplitter)
Segmenta o conteúdo em chunks usando MarkdownHeaderTextSplitter e divide com base em cabeçalhos, com segment_size 300 e 20% de overlap. Nesta modalidade, os títulos e subtítulos do documento são preservados como metadados do segmento, o que facilita identificar de qual seção do arquivo a informação foi extraída.

```json
{
  "index_id": "idx-002",
  "service": "AZURE_EMBEDDINGS_API_700_TPM",
  "vector_store": "opensearch",
  "indexing_modality": "vanilla",
  "segment_size": 300,
  "splitter": {
      "method": "MarkdownHeaderTextSplitter",
      "chunk_overlap": 0.2,
      "separators": ["\n\n", "\n"],
      "headers_to_split_on": [["#", "Introdução"], ["##", "Detalhes"]]
  }
}
```
##### 3. Diretório de arquivos variados (simple-directory-reader)
Indexa todos os arquivos de um diretório em chunks de até 2.000 tokens, com 50 tokens de overlap. Não permite is_reader_mode=True.

```json
{
  "index_id": "idx-003",
  "service": "AZURE_EMBEDDINGS_API_700_TPM",
  "vector_store": "opensearch",
  "indexing_modality": "simple-directory-reader",
  "max_tokens_per_chunk": 2000,
  "overlap_tokens": 50
}
```
##### 4. Modo leitor externo (file + is_reader_mode)
Indexa arquivos individuais usando um leitor externo (is_reader_mode=True) e define quais Instruções Normativas (INs) serão processadas. Nesse modo, não é necessário fazer upload — você pode enviar apenas a requisição de indexação.

```json
{
  "index_id": "idx-004",
  "service": "AZURE_EMBEDDINGS_API_700_TPM",
  "vector_store": "opensearch",
  "indexing_modality": "file",
  "is_reader_mode": true,
  "in_numbers": [1, 3]
}
```
💡 Dica: Cabeçalhos e separadores são dinâmicos — os exemplos acima ilustram o formato, mas você define os valores conforme a estrutura do seu conteúdo. Os campos chunk_overlap, segment_size e max_tokens_per_chunk também são parametrizáveis, respeitando o limite máximo do serviço de embeddings utilizado (veja a tabela a seguir).

#### Serviços de embeddings disponíveis
O limite máximo de segment_size e max_tokens_per_chunk é o max_tokens do serviço utilizado:

| Serviço | max_tokens | embedding_dimension |
| --- | --- | --- |
| AZURE_EMBEDDINGS_API_700_TPM | 8.192 | 1.536 |
| IBM_WATSONX_MULTILINGUAL_E5_LARGE_WX_TEXT_EMBEDDING | 512 | 1.024 |
| IBM_WATSONX_GRANITE_278M_MULTILINGUAL_WX_TEXT_EMBEDDING | 512 | 768 |
| IBM_WATSONX_SLATE_125M_ENGLISH_WX_TEXT_EMBEDDING | 512 | 768 |
#### Acompanhar o processo de indexação
Utilize o task_id retornado na requisição de indexação para consultar o andamento do processamento.

```bash
curl --request POST \
--url https://generabb-acs.gbb.servicos.bb.com.br/gateway/core \
--header 'Content-Type: application/json' \
--header 'UOR: ' \
--header 'X-Client-Id: ' \
--header 'userIdentification: ' \
--data '{
  "action": "acompanhar-indexacao",
  "params": {
      "task_id": "task_id retornado na 2ª requisição"
  }
}'
Copy
```
#### Trocar o índice de um agente
Também é possível trocar o índice vinculado a um agente diretamente pela API, sem passar pela interface do Genera BB.

💡 Dica: Consulte também a documentação de como criar agente com ou sem RAG.

```bash
curl -X 'POST' \
'https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent' \
-H 'accept: application/json' \
-H 'X-Client-Id: ' \
-H 'UOR: ' \
-H 'userIdentification: ' \
-H 'Content-Type: application/json' \
-d '{
    "action": "atualizar-agente",
    "body": {
          "index_id": "idx-teste"
    },
    "params": {
          "agent_id": "nome-do-agente"
    }
 }'
Copy
```
### Perguntas frequentes
#### A API permite a gestão dos dados no índice do OpenSearch, incluindo recuperação e deleção de dados?
Na funcionalidade Gestão de Índice é possível apenas atualizar a base de dados anexando um novo arquivo e disparando uma nova indexação — mantendo o mesmo index_id. Não é possível excluir dados de um índice via API.

#### É possível a inclusão de metadados no processo de indexação?
Sim, dependendo do método de divisão (splitter) utilizado. Com MarkdownHeaderTextSplitter, títulos e subtítulos do Markdown (#, ##, ###) são preservados como metadados de cada segmento, o que ajuda a identificar a origem da informação extraída.

#### É possível trocar índices pela API do Genera? Tem algum payload de exemplo?
Sim. Utilize a requisição com action: "atualizar-agente" mostrada anteriormente, informando o novo index_id no body e o agent_id correspondente em params.

### Limites de requisição (rate limits)
#### Ambientes
| Ambiente | Limite padrão |
| --- | --- |
| Homologação | 5 requisições/minuto |
| Produção | 20 requisições/minuto |
⚠️ Atenção: Todos os agentes começam em homologação. Após a publicação em produção, o limite aumenta automaticamente.

#### Solicitação de aumento
Para solicitar o aumento de limite, siga os passos a seguir:

Passo 1. Garanta que o agente está em produção;

Passo 2. Abra uma issue no repositório do Genera BB; e

Passo 3. Justifique a necessidade do aumento.

### Erros comuns
#### 401 Unauthorized
Este erro pode ser causado por:

- Client ID inválido;
- UOR incorreta ou inconsistente com o Client ID; ou
- UOR sem permissão no agente.
Para resolver, siga os passos a seguir:

Passo 1. Verifique se o Client ID está correto;

Passo 2. Confirme que a UOR corresponde ao Client ID; e

Passo 3. Solicite permissão à equipe responsável pelo agente.

#### 429 Too Many Requests
Este erro indica que o limite de requisições por minuto foi excedido.

Para evitá-lo, implemente controle de concorrência e retry exponencial:

```python
import time
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

retry_strategy = Retry(
  total=3,
  backoff_factor=2,
  status_forcelist=[429, 500, 502, 503, 504]
)
Copy
```
#### 400 Bad Request
Este erro pode ser causado por:

agent_id inválido ou ausente;
input vazio; ou
Payload JSON malformado.
Para resolver, valide o payload antes de enviar:

```python
def validar_payload(payload):
  if "agent_id" not in payload:
      raise ValueError("agent_id é obrigatório")
  if not payload["body"]["data"]["input"]:
      raise ValueError("input não pode estar vazio")
```
#### 413 Payload Too Large
Este erro indica que o tamanho do arquivo enviado (imagem ou corpus) excede o limite aceito pelo endpoint.

Para resolver, siga os passos a seguir:

Passo 1. Verifique o limite vigente com a equipe responsável pelo Genera BB;

Passo 2. Comprima ou redimensione o arquivo antes do envio; e

Passo 3. Para corpus grandes, avalie dividir o conteúdo em múltiplos arquivos indexados sob o mesmo index_id.

### Consumo via certificado (CA Bundle)
Em alguns ambientes — máquinas fora da rede corporativa completa, contêineres, pipelines de CI/CD ou ambientes de desenvolvimento sem os certificados corporativos pré-instalados — a chamada HTTPS ao Gateway do Genera BB pode falhar por falta de confiança na cadeia de certificados. Nesses casos, é possível indicar explicitamente um bundle de certificados (CA Bundle) para validar a conexão TLS.

#### Quando usar
Use essa abordagem quando:

- Sua máquina não possui o certificado da AC do EmpresaBB instalado no repositório de confiança do sistema operacional;
- Você está rodando o script em um ambiente containerizado/CI sem os certificados corporativos pré-instalados; ou
- Está enfrentando erros de SSL (SSLError, CERTIFICATE_VERIFY_FAILED) ao chamar o Gateway.
#### Obtendo o certificado público
Caso não tenha o certificado localmente, baixe o certificado público AC Raiz v3 no repositório oficial de Infraestrutura de Chaves Públicas (PKI) do EmpresaBB.

Na seção Chaves Públicas, clique em AC Raiz v3 para baixar o certificado.

💡 Dica: O repositório também disponibiliza outras chaves (AC Raiz v5, AC Raiz AD v1, ACs intermediárias, entre outras) e as respectivas Listas de Certificados Revogados (LCR). Para o consumo do Gateway do Genera BB, o certificado AC Raiz v3 é suficiente na maioria dos casos.

Depois de baixado, adicione (concatene) o certificado ao seu arquivo local de CA Bundle (ex.: /etc/ssl/certs/ca-certificates.crt), ou aponte a variável CA_BUNDLE do script diretamente para o caminho do certificado baixado.

```python
Exemplo de script (Python)
import os

from dotenv import load_dotenv
import requests

load_dotenv()

CA_BUNDLE = "/etc/ssl/certs/ca-certificates.crt"

os.environ["SSL_CERT_FILE"] = CA_BUNDLE
os.environ["REQUESTS_CA_BUNDLE"] = CA_BUNDLE

url = os.getenv("GATEWAY_URL")

payload = {
  "action": "conversar",
  "body": {
      "data": {
          "input": "Oi, em que poderia me ajudar?",
          "context": {"messages": []},
          "config": {
              "temperature": 0.8,
              "max_tokens": 1000
          }
      }
  },
  "agent_id": "nome-do-agente"
}

headers = {
  "Content-Type": "application/json",
  "UOR": os.getenv("UOR_ID"),
  "useridentification": os.getenv("USER_ID"),
  "x-client-id": os.getenv("X_CLIENT_ID")
}

response = requests.post(url, json=payload, headers=headers, verify=CA_BUNDLE)

print(response.json())
Copy
```
#### Variáveis de ambiente (.env)
| Variável | Descrição |
| --- | --- |
| GATEWAY_URL | Endpoint do Gateway (ex.: https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent) |
| UOR_ID | Sua UOR |
| USER_ID | Sua matrícula (userIdentification) |
| X_CLIENT_ID | Client ID da aplicação |
⚠️ Atenção: Não versione o arquivo .env com credenciais reais — mantenha-o fora do controle de versão (.gitignore).

#### Observações
- Caso não tenha o certificado localmente, utilize o certificado público AC Raiz v3 disponível no repositório de chaves públicas do BB;
Tela do repositório de chaves públicas do BB, com a seção Chaves Públicas e o item AC Raiz v3 disponível para download

- O parâmetro verify do requests aceita tanto True/False quanto o caminho para um arquivo de CA Bundle — passar o caminho do arquivo garante que a verificação use exatamente a cadeia de certificados desejada; e
- Definir SSL_CERT_FILE e REQUESTS_CA_BUNDLE como variáveis de ambiente também cobre bibliotecas HTTP que não recebem verify explicitamente (ex.: chamadas indiretas feitas por outras dependências).
#### Exemplos em outras linguagens
```python
Python (requests)
import requests

url = "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"
headers = {
  "X-Client-Id": "",
  "UOR": "",
  "userIdentification": "",
  "Content-Type": "application/json"
}
payload = {
  "action": "conversar",
  "body": {
      "data": {
          "input": "Qual é o saldo?",
          "context": {"messages": []}
      }
  },
  "agent_id": "nome-do-agente"
}

response = requests.post(url, json=payload, headers=headers)
print(response.json())
```
##### Envio de imagem (multipart) em Python
```python
import requests
import json

url = "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent/upload"
headers = {
  "X-Client-Id": "",
  "UOR": "",
  "userIdentification": ""
  # Não definir Content-Type manualmente: requests define o boundary automaticamente
}
payload = {
  "body": {
      "data": {
          "input": "O que é a imagem?",
          "context": {"messages": [], "total_context": 1},
          "config": {"temperature": 0.5, "max_tokens": 100}
      }
  },
  "agent_id": "nome-do-agente"
}

files = {
  "file": ("sua-imagem.png", open("sua-imagem.png", "rb"), "image/png")
}
data = {
  "action": "conversar",
  "payload": json.dumps(payload)
}

response = requests.post(url, headers=headers, files=files, data=data)
print(response.json())
Copy
```
##### Java (HttpClient)
```java
import java.net.http.*;
import java.net.URI;

HttpClient client = HttpClient.newHttpClient();
String json = """
{
"action": "conversar",
"body": {
  "data": {
    "input": "Qual é o saldo?",
    "context": {"messages": []}
  }
},
"agent_id": "nome-do-agente"
}
""";

HttpRequest request = HttpRequest.newBuilder()
  .uri(URI.create("https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"))
  .header("X-Client-Id", "")
  .header("UOR", "")
  .header("Content-Type", "application/json")
  .POST(HttpRequest.BodyPublishers.ofString(json))
  .build();

HttpResponse response = client.send(request,
  HttpResponse.BodyHandlers.ofString());
```
##### Node.js (Axios)
```javascript
const axios = require('axios');

const url = 'https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent';
const headers = {
'X-Client-Id': '',
'UOR': '',
'Content-Type': 'application/json'
};
const data = {
action: 'conversar',
body: {
  data: {
    input: 'Qual é o saldo?',
    context: { messages: [] }
  }
},
agent_id: 'nome-do-agente'
};

axios.post(url, data, { headers })
.then(response => console.log(response.data))
.catch(error => console.error(error));
```
##### Envio de imagem (multipart) em Node.js
```javascript
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

const url = 'https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent/upload';
const form = new FormData();

form.append('action', 'conversar');
form.append('file', fs.createReadStream('./sua-imagem.png'), {
contentType: 'image/png'
});
form.append('payload', JSON.stringify({
body: {
  data: {
    input: 'O que é a imagem?',
    context: { messages: [], total_context: 1 },
    config: { temperature: 0.5, max_tokens: 100 }
  }
},
agent_id: 'nome-do-agente'
}));

axios.post(url, form, {
headers: {
  ...form.getHeaders(), // define Content-Type com boundary correto
  'X-Client-Id': '',
  'UOR': '',
  'userIdentification': ''
}
})
.then(response => console.log(response.data))
.catch(error => console.error(error));
```
### Boas práticas
#### Segurança
- Nunca exponha o Client ID no frontend;
- Sempre faça chamadas pelo backend; e
- Armazene credenciais com segurança (Vault, Secrets Manager).
#### Observabilidade
- Registre logs de requisição e resposta;
- Monitore a taxa de erro por agente; e
- Acompanhe o tempo médio de resposta.
#### Resiliência
- Implemente retry exponencial;
- Configure timeout (recomendado: 30 segundos); e
- Use circuit breaker para falhas consecutivas.

# Agent Harness
## Visão Geral
O Agent Harness é uma camada de integração que permite conectar ao GeneraBB agentes desenvolvidos e executados em ambientes externos. Esses agentes podem, opcionalmente, ser construídos com frameworks como o LangChain. Essa camada oferece acesso controlado aos recursos do GeneraBB, às ferramentas nativas, a servidores MCP e a Skills, sem exigir que o agente seja desenvolvido ou publicado como um agente nativo da plataforma.

## Pré-requisitos
- Possuir perfil de Assessor ou Contratado de TI;
- Possuir papel de acesso ALMFD<SIGLA>;
- Possuir uma chave de API (API Key) válida.
## Passos para acessar o Agent Harness
Para acessar o Agent Harness, siga os passos a seguir:

Passo 1. Acesse o GeneraBB;

Passo 2. No menu lateral, selecione a opção Gestão de agentes;

Passo 3. Selecione a aba Agent Harness, ao lado das abas Agente com ou sem RAG e Agente Orquestrador (Beta).

Tela inicial do Agent Harness, com a Chave de API e o exemplo de configuração com Langchain

## Chave de API
A chave de API (API Key) é utilizada para autenticar o seu agente externo junto ao GeneraBB.

⚠️ Atenção: Utilize a chave de API apenas para autenticar o seu agente externo junto ao GeneraBB. Não compartilhe essa chave com terceiros nem a utilize para outras finalidades.

Para consultar e gerenciar a sua chave, siga os passos a seguir:

Passo 1. Na tela do Agent Harness, localize o campo Chave de API. O status indica se a chave está Ativa e em quantos dias ela expira;

Passo 2. Clique no botão Copiar, ao lado da chave, para copiá-la;
⚠️ Atenção: Por segurança, a chave é exibida uma única vez. Copie e guarde-a em local seguro antes de sair da tela.

Passo 3. Caso precise gerar uma nova chave, clique no botão GERAR NOVA CHAVE;

Passo 4. Consulte o campo Limite de requisições por minuto, que exibe o limite padrão configurado (50 requisições por minuto). Para solicitar ampliação desse limite, entre em contato com o time de suporte, pelo link disponibilizado na tela.

## Exemplo de configuração com Langchain
O Agent Harness disponibiliza um exemplo pronto de integração via Langchain, com quatro arquivos que devem ser copiados para o projeto no IDE de sua preferência.

Tela inicial do Agent Harness, menu para identificar as variáveis de consumo

Para reaproveitar o exemplo no seu projeto, siga os passos a seguir:

Passo 1. No main.py, adicione sua chave de API no campo [sua-chave] e o código do modelo escolhido no campo [seu-modelo] para conectar seu agente;

Passo 2. Utilize os botões Copiar ou Baixar, no canto superior direito de cada arquivo, para reaproveitar o conteúdo em seu projeto.
### main.py
Arquivo principal do agente, responsável por carregar as variáveis de ambiente, configurar o certificado SSL, definir o prompt de sistema e conectar aos servidores MCP configurados.

```python
import asyncio
import json
import os

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI

load_dotenv()

os.environ["SSL_CERT_FILE"] = "/etc/ssl/certs/ca-certificates.crt"

SYSTEM_PROMPT = """
Você é um assistente capaz de interagir com as ferramentas MCP disponíveis.
""".strip()

def expand_env(obj):
  if isinstance(obj, dict):
      return {k: expand_env(v) for k, v in obj.items()}

  if isinstance(obj, list):
      return [expand_env(v) for v in obj]

  if isinstance(obj, str):
      return os.path.expandvars(obj)

  return obj

async def load_mcp_tools(config_file="mcp.json"):
  with open(config_file, encoding="utf-8") as fp:
      config = expand_env(json.load(fp))

  servers = {}

  for name, server in config["servers"].items():
      server = dict(server)

      transport = server.pop("type", None)

      if transport:
          server["transport"] = transport

      servers[name] = server

  client = MultiServerMCPClient(servers)

  return await client.get_tools()

async def main():
  tools = await load_mcp_tools()

  agent = create_agent(
      model=ChatOpenAI(
          model="gpt-5.4",
          api_key=os.getenv("API_KEY"),
          base_url="https://genai.genera.bb.com.br/v1",
      ),
      tools=tools,
      system_prompt=SYSTEM_PROMPT,
  )

  while True:
      pergunta = input("\nPergunta: ").strip()

      if pergunta.lower() in {"sair", "exit"}:
          break

      resultado = await agent.ainvoke(
          {
              "messages": [
                  {
                      "role": "user",
                      "content": pergunta,
                  }
              ]
          }
      )

      print(f"\nResposta:\n{resultado['messages'][-1].content}")

if __name__ == "__main__":
  asyncio.run(main())
Copy
```
### requirements.txt
Lista as dependências necessárias para executar o agente com Langchain e a integração via MCP.

```text
langchain
langchain-openai
langchain-mcp-adapters
python-dotenv
```
### mcp.json
Define os servidores MCP que o agente irá consumir, incluindo a URL de acesso e os cabeçalhos (headers) necessários para autenticação em cada servidor.

```json
{
"servers": {
  "genera-bb-mcp-server": {
    "type": "http",
    "url": "https://mcp-server-genera-bb.ai.api.hm.bb.com.br/v1/mcp",
    "headers": {
      "gw-dev-app-key": "${GW_DEV_APP_KEY}",
      "x-uor-id": "${X_UOR_ID}",
      "x-client-id": "${X_CLIENT_ID}"
    }
  },
  "aic-kanbanize-mcp-server": {
    "type": "http",
    "url": "https://kanbanize-mcp-server.aic.servicos.bb.com.br/mcp",
    "headers": {
      "bmap-api-token": "${BMAP_API_TOKEN}",
      "bmap-user-email": "${BMAP_USER_EMAIL}"
    }
  }
}
}
Copy
```
⚠️ Atenção: Substitua as variáveis ${GW_DEV_APP_KEY}, ${X_UOR_ID}, ${X_CLIENT_ID}, ${BMAP_API_TOKEN} e ${BMAP_USER_EMAIL} pelas credenciais e identificadores da sua aplicação.

### .env
Arquivo de variáveis de ambiente utilizado pelo main.py e pelo mcp.json para armazenar a chave de API e as credenciais de autenticação dos servidores MCP.

```dotenv
BASE_URL="https://genai.genera.bb.com.br/v1"
API_KEY=""
X_CLIENT_ID=""
X_UOR_ID=""
GW_DEV_APP_KEY=""
BMAP_API_TOKEN=""
BMAP_USER_EMAIL=""
```
⚠️ Atenção: Preencha os valores de API_KEY, X_CLIENT_ID, X_UOR_ID, GW_DEV_APP_KEY, BMAP_API_TOKEN e BMAP_USER_EMAIL com as credenciais e identificadores da sua aplicação. Não compartilhe este arquivo nem o versione em repositórios públicos. A variável GW_DEV_APP_KEY está disponível acessando o .env dentro do GeneraBB.

Tela inicial do Agent Harness, menu informação .env

## Modelo de Linguagem (LLM)
Escolha um modelo de linguagem e copie o identificador correspondente para o campo model="" do arquivo main.py do seu agente.

Para escolher e aplicar o modelo, siga os passos a seguir:

Passo 1. Na seção Modelo de Linguagem (LLM), avalie os modelos disponíveis e sua finalidade;

Passo 2. Clique no botão Copiar, ao lado do identificador do modelo desejado, para copiá-lo;
Passo 3. Cole o identificador copiado no campo model="" do seu main.py.

Os modelos disponíveis são:

- GPT-5.4 (gpt-5.4): modelo para codificação, análise e geração de respostas longas;
- Llama-3.1-8B (llama-3.1-8b-Instruct): modelo para conversação, respostas rápidas e instruções gerais.
Além dos modelos listados, você pode:

- Clicar em ACESSAR MARKETPLACE DO GENERA BB para explorar outros MCPs, agentes, skills e instruções da Plataforma A2B2;
- Clicar em ACESSAR MARKETPLACE DO TECHBB para explorar recursos disponibilizados pelo TechBB;
- Criar seus próprios MCPs por meio da esteira de criação de AgentOps.
Pronto! Com a chave de API, os arquivos de configuração e o modelo escolhido, seu agente externo já pode se conectar ao GeneraBB e aos servidores MCP disponíveis.

# Genera Safe
## O que é o Genera Safe?
O Genera Safe é um mecanismo de proteção da funcionalidade Gestão de Agentes, que adiciona camadas de segurança e controle ao comportamento dos agentes.

Ele utiliza a técnica LLM as a Judge, na qual um modelo de linguagem avalia as respostas geradas por outro, funcionando como um revisor automático e inteligente.

Ao ativar o Genera Safe, políticas de segurança (guardrails) são aplicadas automaticamente, com possibilidade de personalização conforme o contexto de uso. Essas políticas incluem:

- Regras de risco pré-configuradas;
- Controles de vieses no comportamento do agente;
- Bloqueios de conteúdos sensíveis ou proibidos, de acordo com a política de segurança vigente.
💡 Guardrails são restrições aplicadas a modelos de linguagem para evitar saídas inseguras ou indesejadas. Elas podem atuar em diferentes estágios: antes da entrada do usuário (validação), durante a geração (restrições em tempo real) e após a resposta (filtragem de saída).

Essa funcionalidade é indicada para cenários em que o agente precisa operar com maior responsabilidade, previsibilidade e controle.

## Como usar o Genera Safe?
Existem três formas de utilizar o Genera Safe:

- Criar um agente do tipo Genera Safe;
- Adicionar o Genera Safe como camada de proteção em um agente já existente;
- Criar um novo agente (com RAG ou sem RAG) e, nas configurações finais, habilitar o Genera Safe como camada de proteção.
A seguir, confira as instruções para cada uma dessas formas:

### 1. Criar um Agente Tipo Genera Safe
Um agente do tipo Genera Safe que avalia e protege outros agentes. Ele analisa as perguntas enviadas e as respostas geradas, aplicando verificações de segurança, risco e conformidade antes que o conteúdo seja entregue ao usuário.

Esse tipo de agente não executa tarefas diretamente nem utiliza base de conhecimento própria. Sua função é validar e controlar o comportamento de outros agentes, ajudando a evitar respostas inadequadas, sensíveis ou fora das políticas definidas.

Confira a seguir como criar um:

Passo 1. No menu lateral, acesse Gestão de Agentes;

Passo 2. Clique no botão Novo Agente;

Passo 3. Na tela Tipo de Agente, selecione a opção GeneraSafe, como na imagem a seguir:

print da tela de Tipo de Agente com a opção GeneraSafe selecionada

Passo 4. Na tela Prompt, clique no botão Avançar;

Um prompt configurado com o Genera Safe é criado automaticamente. Você pode editá-lo depois, se necessário. Para isso, confira a documentação de Engenharia de Prompt. O nome do prompt segue o padrão: \<nome_do_prompt\>-genera-safe.

Passo 5. Na tela Informações adicionais, configure o agente preenchendo os campos a seguir:

- ID do Agente: nome pelo qual você irá localizar o agente dentro da plataforma Genera BB.
- Modelo GenAI: selecione o modelo de IA que será utilizado pelo agente para gerar respostas e executar tarefas. Esse modelo influencia diretamente o comportamento, a capacidade de compreensão e a qualidade das respostas do agente.
- UOR permitidas: informe os números das UORs nas quais o agente ficará disponível. Após digitar cada número, pressione vírgula (,) para que a UOR seja adicionada. Você pode informar várias UORs. Essa configuração não pode ser alterada depois.
- Agente Público: selecione a opção caso queira que o agente seja visível para todos os usuários.
Confira na imagem a seguir um exemplo preenchido:

print da tela de configuração do agente preenchido

Por fim, clique no botão Finalizar. O agente será criado e já estará disponível para Experimentação de Chat.

### 2. Adicionar o Genera Safe em um agente (com ou sem RAG) já existente
Você pode ativar o Genera Safe como uma camada de proteção extra em um agente seu que já existe. Para isso, confira as instruções a seguir:

#### Pré-requisitos:
- Ter um Agente com ou sem RAG já criado.
#### Ativar o Genera Safe em um Agente já criado
Passo 1. No menu lateral da plataforma Genera BB, acesse Gestão de Agentes e pesquise o agente com ou sem RAG que você quer configurar;

Passo 2. Clique no botão de edição ao lado do agente;

Passo 3. Marque a opção que indica Genera Safe, como na imagem a seguir:

tela de ativação do genera safe

Passo 4. Clique no botão "Editar" para salvar as configurações.

💡 Um novo prompt é criado automaticamente, com a proteção Genera Safe aplicada.

#### O que acontece após ativar o Genera Safe:
- Um prompt derivado do seu anterior é gerado automaticamente;

- O nome do prompt segue o padrão: <nome_do_prompt>-genera-safe;

- Esse novo prompt utiliza como base o template oficial Genera Safe v4 — mantido e atualizado pela equipe responsável pelo GeneraBB da Plataforma A2B2.

Tela de pesquisa de agentes com opção Genera Safe

### 3. Ativar o Genera Safe na criação de um novo Agente com ou Sem RAG
Ao criar um novo Agente com ou sem RAG, você pode ativar o Genera Safe nas configurações finais dele.

Passo 1. Acesse a documetação de como criar um Agente com ou Sem Rag e siga as instruções para criar o seu Agente;

Passo 2. Na última etapa de configuração, você pode ativar o Genera Safe selecionando a opção Ativar Genera Safe, como no exemplo da imagem a seguir:

print da tela de configuraçao de agente com ou sem rag com a caixa e habilitar genera safe habilidada

Pronto!

## Regras e Taxonomias do Genera Safe
Cada prompt com Genera Safe inclui automaticamente um conjunto obrigatório de regras de segurança.

Para cada regra, o sistema exibe:

- Uma descrição clara da regra;
- Um exemplo obrigatório de uso correto;
- Um exemplo de conteúdo que será bloqueado caso viole a regra.
Confira a seguir um exemplo de regras definidas:

Tela de Taxonomias

## O que acontece em caso de violação?
Quando o usuário envia uma solicitação com conteúdo proibido (como temas relacionados a armas químicas ou discurso de ódio):

- O agente bloqueia a resposta automaticamente;
- Em vez disso, ele informa qual regra foi violada.
Confira um exemplo na imagem a seguir:

Exemplo de violação

## Gestão das Regras de Segurança
Você pode gerenciar todas as regras aplicadas ao agente com liberdade total. Ao acessar o prompt protegido com Genera Safe, é possível:

- Visualizar as regras de segurança ativas;
- Editar descrições ou exemplos de cada regra;
- Criar novas regras personalizadas;
- Excluir regras que não se aplicam ao seu contexto.
Essa flexibilidade permite que você adapte o comportamento do agente às necessidades específicas da sua área, garantindo segurança sem perder eficiência.

Para editar seu prompt, acesse a seção Engenharia de Prompt no menu lateral. Confira a documentação oficial sobre Engenharia de Prompt no Genera BB
