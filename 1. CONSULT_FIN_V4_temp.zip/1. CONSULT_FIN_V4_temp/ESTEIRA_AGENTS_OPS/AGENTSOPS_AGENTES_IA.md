# ESTEIRA AGENT-OPS

# Introdução
Esta documentação apresenta a oferta corporativa de Agente de Inteligência Artificial (IA), descrevendo seu conceito, objetivos e capacidades no contexto do EmpresaBB.

## Definição de Agente de IA
Um Agente de IA é um sistema de inteligência artificial projetado para executar tarefas de forma autônoma ou semiautônoma, operando com mínima supervisão ou intervenção humana. O agente é capaz de perceber informações do ambiente, interpretar objetivos, tomar decisões e executar ações de maneira coordenada e contextualizada.

Para isso, os agentes utilizam modelos generativos, ferramentas especializadas e mecanismos de memória e contexto, permitindo compreender situações complexas, manter continuidade ao longo do tempo e determinar a melhor ação a ser tomada em cada etapa da tarefa. Essa abordagem possibilita que o agente atue de forma mais flexível, adaptativa e orientada a objetivos, indo além de simples automações reativas.

Para mais informações, consulte a IN 1230, principalmente item 10.5.

## Objetivo da solução
A oferta corporativa de Agente de IA foi concebida para permitir que equipes autorizadas criem, configurem e operem agentes de forma padronizada, segura e alinhada às diretrizes institucionais. Os agentes podem atuar de forma isolada ou em cooperação com outros agentes, compartilhando informações, estado e resultados, de modo a viabilizar soluções mais robustas e cenários de maior complexidade.

O objetivo da solução é viabilizar o uso institucional de Agentes de IA, promovendo eficiência operacional, reuso de capacidades, escalabilidade e governança. Ao fornecer uma base estruturada para criação de agentes, a solução reduz o esforço de desenvolvimento, evita implementações pontuais e garante consistência na forma como os agentes são utilizados nos diversos domínios de negócio.

A solução também assegura que os agentes operem sob princípios de segurança, rastreabilidade e conformidade, possibilitando controle das ações executadas, auditoria dos resultados e alinhamento com normas internas e externas.

## Funcionalidades principais do Agente de IA
- Execução de tarefas de forma autônoma ou semiautônoma
- Tomada de decisão baseada em objetivos, contexto e restrições
- Uso integrado de modelos generativos, ferramentas e memória
- Persistência de contexto para continuidade operacional
- Comunicação e cooperação entre múltiplos agentes
- Integração com sistemas e serviços corporativos
- Registro e rastreabilidade das ações executadas
## Exemplos de uso
- Agentes para apoio a processos internos e operacionais
- Agentes para análise, síntese e geração de informações
- Agentes para coordenação de fluxos complexos envolvendo múltiplas etapas
- Agentes especializados por domínio de negócio, atuando de forma cooperativa
## Jornada do usuário
Para criar e operar um Agente de IA, siga a jornada abaixo:

- Solicitação de Agente de IA — Como solicitar a criação da oferta no Tech.bb
- Estrutura do Projeto — O que você recebe após o provisionamento e como configurar o repositório
- Desenvolvimento do Agente — Como desenvolver o agente utilizando LangGraph
- Implementação de RAG — Como implementar RAG
- Release e Deploy — Como realizar o deploy nos ambientes de desenvolvimento, homologação e produção

# Solicitação de Agente de IA
Esta documentação orienta como utilizar a oferta de criação de Agente de IA, incluindo os papéis de acesso necessários e referências técnicas para o desenvolvimento de Agente de IA.

## Requisitos
### Para solicitar
Para acessar a oferta de Agente de IA no Tech.bb, você deve ter o papel de acesso ALMFD\<SIGLA\>, onde \<SIGLA\> corresponde à sigla de domínio no qual será provisionada a instância.

### Para aprovação
Em caráter temporário, a aprovação da Oferta de Agente de IA deverá ser realizada pelo papel DEVMSAPV, cuja atribuição é restrita aos Gerentes Executivos e aos Gerentes Gerais da DITEC.

## Passo a passo
- Acessar oferta no Tech.bb
- Preencher o formulário da oferta
### 1. Acessar oferta no Tech.bb
A oferta de criação de Agente de IA está disponível na plataforma interna do desenvolvedor em Tech.bb - Oferta de Agente de IA.

### 2. Preencher o formulário da oferta
Na página da oferta de Agente de IA, siga as instruções abaixo para o correto preenchimento dos campos necessários:

Passo 1. Preencha os dados da solicitação com as seguintes informações:

- Sigla na qual o projeto será criado.

- UOR mantenedora deve ser a equipe responsável pela criação e manutenção do Agente de IA.

- Matrícula do gerente responsável no formato FXXXXXXX.

- Nome deve identificar de forma sucinta e objetiva o propósito Agente de IA.

Preencher os dados da solicitação

Categoria do Agente se refere ao LLM utilizado pelo agente, podendo ser:

- Desenvolvedor para suporte e atividades de desenvolvimento de software;
- Padrão para assuntos diversos.
- Descrição do Agente de IA contendo o que o agente pode ou não fazer, seu escopo de atuação, aplicações de uso e funcionalidades integradas.

⚠️ Atenção: A descrição deve ser precisa e abrangente para que os agentes e outros sistemas agênticos possam identificar claramente seu uso e aplicabilidade.

Abrangência de uso se refere a escopo de atuação do agente no ambiente corporativo e sua criticidade, podendo ser:

- Cliente Externo caso seja voltado para consumo por clientes externos e clientes finais do Banco;
- Corporativo para aplicações em soluções corporativas de diferentes departamentos e sistemas;
- Departamental para consumo interno por um time, equipe ou sistema específico.
Funcionalidade do Agente se refere ao tipo de função que o agente exerce dentro de um sistema agêntico ou isoladamente. Escolha uma das opções dentre as possibilidades oferecidas:

- Agente Especialista: Fornece informações ou realiza ações dentro de um domínio definido, atuando de forma independente ou coordenada com outros agentes.
- Orquestrador/Planejador: Coordena múltiplos agentes; decompõe objetivos, cria planos, chama subagentes e sincroniza fluxos.
- Observador/Monitor de Eventos: Reage a gatilhos (logs, filas, webhooks).
- Avaliador/Guardião: Verificador de segurança, conformidade, qualidade, ou 'second pair of eyes' sobre outros agentes.
Nível de Autonomia e Poder Decisório se refere ao grau da capacidade do agente de tomar decisões de forma autônoma e a participação de um humano no processo decisório. Escolha dentre uma das opções:

- A0 – Informativo e/ou Recomendador: IA Não autônoma - Humano totalmente no controle. A IA fornece informações, análises ou recomendações, mas não executa ações. Ex.: assistente explicativo, FAQ, elaborador de texto, recomendação de produto.
- A1 – Executor com Humano no Circuito (HITL): IA Semiautônoma - Humano aprova em pontos críticos. A IA executa ações dentro de limites definidos, com validação humana em pontos críticos. Ex.: execução automática de pagamentos até valor máximo.
- A2 – Executor e Decisor Autônomo Pleno: IA autônoma - Humano não participa da execução. IA toma decisões e executa ações sozinha integralmente. Humano pode monitorar e intervir caso identifique problemas. Ex.: bloqueio de transações suspeitas em tempo real.
Preencher os dados da solicitação

RAG (Retrieval Augmented Generation) é uma técnica de aprimoramento das respostas de um agente de IA que utiliza uma base de conhecimento integrada ao agente. Caso opte por utilizar RAG no agente, indique isso neste campo e consulte a documentação institucional correspondente sobre implementação de RAG.

Fonte de dados responda se o agente estará integrado a alguma base de dados, indicando nos campos seguintes as Fontes de Dados Não Estruturado, Fontes de Dados Estruturados, Nível de Confidencialidade dos Dados e se Trata Dados Pessoais ou Sensíveis, caso haja uso de dados pessoais ou sensíveis deverá ser indicado também o Número ITDP.

Escopo de Acesso a Ferramentas e Sistemas se refere a quais tipos de ferramentas que o agente tem acesso ou pode afetar. Assinale a opção mais adequada:

- Restrito ao ambiente do agente: Não acessa outros sistemas.
- Acesso a Sandboxes: Acesso apenas a ambientes isolados (sandbox), para execução de código ou análise de dados. Não podem afetar nenhum outro sistema.
- Acesso Limitado a Sistemas Internos: Pode acessar ferramentas internas à organização, com capacidade limitada para leitura, pesquisa e recuperação de informações.
- Acesso Amplo a Sistemas Internos: Pode acessar ferramentas internas à organização, com capacidade de modificar dados dentro do sistema, como atualizar banco de dados ou realizar transação financeira.
- Acesso a Sistemas Externos: Pode acessar ferramentas que permitem acessar serviços externos, como recuperação e atualização de dados por meio de APIs predefinidas para terceiros.
Passo 2. Confirme as informações inseridas e clique em AVANÇAR:

Preencher os dados da solicitação

Passo 3. Preencha o nome e grupo da instância com as seguintes informações:

- Nome da instância deve iniciar com agent- e seguir o padrão agent-instancia-de-exemplo. Após a criação do microsserviço, a sigla indicada anteriormente será incluída como prefixo da instância (ex: abc-agent-instancia-de-exemplo);

- Grupo de recursos no qual a instância será criada. Preferencialmente todos Agentes de IA de uma mesma sigla devem ser criados em um mesmo grupo de recursos, caso este não exista, ele pode ser criado no momento da solicitação clicando em CRIAR NOVO GRUPO DE RECURSOS.

Passo 4. Confirme as informações inseridas e clique em AVANÇAR:

Preencher nome e grupo da instância

Passo 5. Confirme as informações na tela de resumo e clique em SOLICITAR:

Resumo da solicitação Resumo da solicitação

Passo 6. Sua solicitação de Agente de IA ficará pendente de aprovação:

Solicitação pendente

Passo 7. e deverá ser aprovada pelo responsável conforme indicado nos Requisitos:

Aprovação de solicitação

Passo 8. Acompanhe o provisionamento e clique em ACESSAR RECURSO para visualizar as informações da instância criada.

Caso tenha necessidade de suporte na solicitação de Agente de IA, solicite via issue utilizando o template Agentes de IA - Oferta de Agente de IA e assinalando a opção Suporte para solicitação da oferta de Agente de IA no Tech.bb.

Com a solicitação do Agente de IA concluída e os provisionamentos realizados com sucesso você pode seguir para os próximos passos.

## Próximos passos
- Estrutura do projeto
## Referências técnicas
- LangGraph Oficial
- Casos de uso com LangGraph
- Padrões de orquestração de agentes de IA - Microsoft
- Conceitos de IA - OpenAI
## Suporte
Caso tenha necessidade de suporte na criação de Agente de IA após a solicitação da oferta, solicite via issue utilizando o template Agentes de IA - Oferta de Agente de IA e assinalando a opção Suporte para criação de Agente de IA após solicitação da oferta.

# Estrutura do Projeto
Esta documentação descreve o que o usuário recebe após a aprovação da solicitação de Agente de IA, incluindo os recursos provisionados, a estrutura do repositório e as configurações iniciais necessárias para o desenvolvimento.

⚠️ Antes de continuar: certifique-se de que a solicitação de Agente de IA foi aprovada e provisionada com sucesso.

## O que você recebe após o provisionamento
Após a aprovação e o provisionamento da oferta de Agente de IA, os seguintes recursos são disponibilizados:

- Repositório de código (codebase e deploy) no GitLab, contendo o template Python com a estrutura base do agente;
- Instrumentação de Deploy (Argo CD e OpenShift) com os ambientes de desenvolvimento, homologação e produção pré-configurados;
- Instância do serviço visível em Instâncias da Esteira de criação de Agentes de IA.
⚠️ Atenção: O repositório é criado inicialmente no GitLab. Para utilizar a esteira corporativa de CI/CD Python, é necessário solicitar a migração para o GitHub, conforme descrito na etapa de solicitação.

## Estrutura de branches
O repositório é criado com as seguintes branches:

| Branch | Conteúdo |
| --- | --- |
| master (ou main) | Template completo com a estrutura base do Agente de IA |
| develop | Branch de desenvolvimento - inicialmente vazia |
💡 Dica: Após a migração para o GitHub, utilize a branch develop para o desenvolvimento do agente. A branch main contém o template original e serve como referência.

## Estrutura de pastas do template
O template Python do Agente de IA utiliza o framework LangGraph e possui a seguinte estrutura base:

```text
-agent-/
├── __init__.py              # Versão da imagem
├── __main__.py              # Entrypoint Uvicorn (python -m -agent-)
├── app.py                   # Aplicação FastAPI - todos os endpoints HTTP
├── config.py                # Carregador do agent_config.yaml (dataclasses tipadas)
├── graph.py                 # Agente LangGraph - AgentFactory + ValidatingToolNode
│
├── llm/
│   ├── base.py              # Classe abstrata LLMProvider
│   ├── gateway_outbound.py  # Provedor Gateway Outbound BB (padrão)
│   └── factory.py           # LLMFactory - registro e instanciação de provedores
│
├── rag/
│   └── rag_tool.py          # Ferramenta LangChain para recuperação via gateway Genera BB
│
├── validators/
|   └── ...                  # Validações de qualidade do modelo
│
└── utils/
  └── ...                 # Configurações de guardrails e telemetria
tests/
└── ...                      # Testes unitários e de integração
agent_config.yaml            # Configuração do agente (LLM, MCP, RAG, guardrails, instruções)

Dockerfile                   # Imagem Python 3.11
requirements.txt             # Dependências de runtime
setup.py                     # Metadados do pacote
.env.example                 # Template de variáveis de ambiente
```
⚠️ Importante: A estrutura acima é uma referência do template. Verifique a versão atual do template no repositório recebido, pois pode haver atualizações.

## Configurações iniciais
Após receber o repositório, as seguintes configurações devem ser realizadas antes de iniciar o desenvolvimento:

### 1. Migrar o repositório para o GitHub
Como o Agente de IA é provisionado com repositório no Gitlab, você precisa solicitar a migração do repositório criado para o GitHub via oferta na plataforma interna do desenvolvedor em Tech.bb - Oferta de migração de repositório para o GitHub.

Preencha o formulário com as informações solicitadas referentes a sua gerência e UOR, assim como os dados do projeto criado anteriormente. Seu repositório será migrado para o GitHub e configurado para a esteira corporativa de CI/CD Python.

⚠️ Aviso: Após a migração ao Github é executado uma automação que altera a configuração "versaoPython": "3.11", para "versaoPython": "3.8", no arquivo aic.json gerando conflitos de pacotes ao realizar o processo de build, verifique a versão apontada no arquivo sendo 3.11 a versão correta.

### 2. Vincular o agente ao catálogo de IA e obtenção da App Key
Em alinhamento com critérios de segurança e integração, a comunicação com o agente de IA deve sempre passar por um gateway que implementa observabilidade, segurança e valida autorizações de consumo das ferramentas disponíveis, o mesmo ocorre com o consumo do agente diretamente pelos canais internos e externos. Para permitir tal integração entre componentes de uma solução baseada em agentes de IA, cada microsserviço do tipo agente deve estar sempre vinculado ao catálogo de IA, conforme a documentação disponível em Documentação do Catálogo de IA, assim como é possível consultar nossas orientações em Cadastro do Catálogo de IA.

⚠️ Importante: Esta etapa contempla a criação e obtenção da App Key referente ao Agente, cujo qual é necessário para as próximas etapas.

### 4. Solicitar consumo do agente à API provedora do LLM
Para obtenção da variável de ambiente "GATEWAY_OUTBOUND_GW_APP_KEY", cujo qual é crítica para o funcionamento do agente, deve-se utilizar a mesma App Key do passo anterior, e esta deve estar autorizada ao consumo da API Azure AI Foundry - LLMS AGENTES IA (17703978), sendo necessário solicitação de autorização à equipe IA Generativa Avançada.

Esta variável é responsável pelo acesso ao gateway outbound que provê os modelos de LLM disponíveis no momento, sendo possível consultar os endpoints dos modelos na API referenciada.

### 5. Obtenção dos certificados idh-mtls
Os certificados idh-mtls são gerados automaticamente no deploy do container, é possível conferir e obter os certificados a partir das Secrets do container ao realizar do deploy do agente. Para gerar o certificado não é necessário que o deploy tenha uma imagem válida ou finalizada, é possível gerar o certificado com o primeiro deploy desde que esteja ativo no values o idh-mtls

Confira a seguir os passos para baixar os certificados:

- Passo 1. No painel do seu projeto no OpenShift, acesse o menu lateral Secrets;

- Passo 2. Localize a secret idh-mtls na lista; e

- Passo 3. Na tela de detalhes, faça o download dos arquivos ca.crt, tls.crt e tls.key.

⚠️ Importante: Os certificados são distintos por ambiente.

### 6. Configurar as variáveis de ambiente
As variáveis de ambiente e secrets necessários para o funcionamento do agente são:

| Variável | Obtenção |
| --- | --- |
| GATEWAY_OUTBOUND_GW_APP_KEY | Credenciais no catálogo de aplicação |
| KEY_STORE_CERT_PATH | Certificados idh-mtls, arquivo ca.crt |
| KEY_STORE_KEY_PATH | Certificados idh-mtls, arquivo tls.crt |
| TRUST_STORE_CA_PATH | Certificados idh-mtls, arquivo tls.key |
As variáveis referentes ao certificado idh-mtls já são configuradas no provisionamento do agente, sendo necessário apenas a inserção do GATEWAY_OUTBOUND_GW_APP_KEY nas Secrets do container.

Recomenda-se que seja configurado um único envFrom no values de deploy com o nome env, cujo qual pode ser inserido todas variáveis de ambiente obrigatórias e opcionais. Esta configuração encontra-se comentada no values de deploy.

Assim como há outras variáveis opcionais, cujo quais podem ser conferidas em env.example e no README.md do repositório.

## Próximos passos
- Desenvolvimento do Agente de IA

# Desenvolvimento do Agente de IA
Esta documentação orienta como desenvolver um Agente de IA a partir do template recebido, incluindo a estrutura de código, configuração de ferramentas, testes locais e integração com MCP Servers.

⚠️ Antes de continuar: certifique-se de que o repositório foi configurado conforme descrito em Estrutura do Projeto e que a migração para o GitHub foi concluída.

## Visão geral do desenvolvimento
O template de Agente de IA utiliza o framework LangGraph para definição de fluxos agênticos. O desenvolvimento consiste em:

- Desenvolvimento local
- Chamada do agente através do gateway(cURL)
## 1. Desenvolvimento local
Para conferir o funcionamento do agente em desenvolvimento local, deve-se seguir os seguintes passos:

```bash
# 1. Criar o ambiente virtual
python -m venv .venv && source .venv/bin/activate

# 2. Instalar as dependências
pip install -r requirements.txt
pip install -e .

# 3. Configurar o ambiente
cp .env.example .env
# edite o .env com os valores adequado

# ⚠️ Importante: a variável GATEWAY_OUTBOUND_GW_APP_KEY obrigatória para execução local.

# 4. Iniciar o serviço
python -m _agent_
```
O Swagger UI estará disponível em: http://localhost:8080/docs, onde é possível enviar solicitações ao agentes na opções Try it out em /chat.

## 2. Chamada do agente através do gateway (cURL)
EM BREVE
## Suporte
Caso tenha necessidade de suporte no desenvolvimento de Agente de IA, solicite via issue utilizando o template Agentes de IA - Oferta de Agente de IA e assinalando a opção Suporte para criação de Agente de IA após solicitação da oferta.

# Implementação de RAG
## Introdução
Esta documentação apresenta como implementar e configurar o uso de RAG (Retrieval-Augmented Generation) em agentes criados a partir da oferta corporativa de Agente de Inteligência Artificial (IA).

Ao final desta leitura, você será capaz de:

- Entender o conceito de RAG;
- Criar uma base de conhecimento indexada no GeneraBB;
- Configurar o agente para utilização do recurso;
- Adicionar as credenciais necessárias no projeto.
## Definição de RAG
### O que é RAG
RAG (Retrieval-Augmented Generation ou Geração Aumentada por Recuperação) é uma abordagem de inteligência artificial generativa que combina:

- Modelos de linguagem;
- Recuperação de informações externas;
- Busca semântica;
- Contextualização dinâmica de respostas.
Essa abordagem permite que o agente consulte informações externas antes de gerar respostas.

As fontes podem incluir:

- Documentações;
- APIs;
- Bases corporativas;
- Repositórios internos.
Durante a geração da resposta, o modelo utiliza informações recuperadas dessas fontes para complementar o conhecimento pré-treinado e produzir respostas mais contextualizadas.

### Benefícios do uso de RAG
A utilização de RAG permite:

- Respostas mais contextualizadas;
- Redução de alucinações;
- Atualização dinâmica do conhecimento;
- Melhor aderência ao domínio corporativo;
- Utilização de informações especializadas e verificáveis.
### Como o RAG funciona
O fluxo de funcionamento do RAG normalmente envolve:

- Recebimento da solicitação da pessoa usuária;
- Busca semântica em bases indexadas;
- Recuperação de conteúdos relevantes;
- Envio do contexto recuperado ao modelo de linguagem;
- Geração da resposta contextualizada.
Para viabilizar esse processo, o RAG utiliza:

- Modelos de linguagem;
- Embeddings vetoriais;
- Busca semântica;
- Integrações com bases externas;
- Mecanismos de recuperação de contexto.
### Considerações sobre arquitetura e custos
A implementação de RAG adiciona complexidade operacional à solução.

Os principais impactos incluem:

- Maior consumo computacional;
- Infraestrutura vetorial;
- Busca semântica em tempo real;
- Aumento de latência;
- Custos adicionais de processamento.
Além disso, fatores como:

- Volume de documentos indexados;
- Frequência de consultas;
- Tempo de resposta esperado;
- Quantidade de chamadas ao modelo;
impactam diretamente o dimensionamento da solução.

Por isso, avalie cuidadosamente o equilíbrio entre:

- Qualidade das respostas;
- Desempenho;
- Eficiência financeira;
- Escalabilidade da arquitetura.
## Pré-requisitos
Antes de iniciar a implementação do RAG, verifique se você possui:

- Acesso ao GeneraBB;
- Permissão para gestão de índices;
- Acesso ao repositório do agente;
- Permissão para alteração de secrets;
- Client ID autorizado para consumo do serviço.
Para mais informações, consulte a IN 1230, principalmente item 11.5.5.2.

## Passo a passo
- Criar base de conhecimento indexada no GeneraBB
- Atualizar configuração do agente
- Incluir Client ID nas secrets do projeto
### 1. Criar base de conhecimento indexada no GeneraBB
Confira como criar uma base de conhecimento indexada que será utilizada pelo agente durante o processo de recuperação de contexto do RAG.

#### Passo a passo
Passo 1. Acesse a interface do GeneraBB.

Passo 2. No menu lateral em Serviços, selecione a opção Gestão de Agentes;

Passo 3. Clique em Gestão de índice.

Passo 4. Siga o processo de criação da base de conhecimento indexada conforme a documentação do GeneraBB, disponível na seção:

Etapa 2 - Indexação da Base de Conhecimento (Somente Agentes com RAG)
⚠️ Atenção: Não é necessário criar um agente com RAG diretamente no GeneraBB. Nesta etapa, você precisa apenas criar a base de conhecimento indexada.

### 2. Atualizar configuração do agente
Confira a seguir como habilitar o uso do RAG na configuração do agente.

#### Passo a passo
Passo 1. Preencha as informações necessárias no repositório do agente para habilitação do RAG:

No arquivo agent_config.yaml na raiz do projeto, preencha os campos de RAG conforme exemplo abaixo:

```yaml
rag:
  enabled: true
  url: "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"
  uor: "XXXXXX"
  user_id: "FXXXXXXX"
  agent_id: "idx-exemplo" 
  total_context: 5
  timeout: 20.0
```
#### Descrição dos parâmetros
| Parâmetro | Descrição |
| --- | --- |
| enabled | Habilita ou desabilita o uso do RAG |
| url | Endpoint utilizado para comunicação com o serviço |
| uor | Unidade Organizacional responsável |
| user_id | Identificador da pessoa usuária |
| agent_id | Identificador da base indexada criada no GeneraBB |
| total_context | Quantidade máxima de contextos recuperados |
| timeout | Tempo máximo de resposta da requisição em segundos |
⚠️ Atenção:

Valide se o agent_id corresponde exatamente ao índice criado no GeneraBB.

### 3. Incluir Client ID nas secrets do projeto
Confira a seguir como adicionar as credenciais necessárias para autenticação do serviço de RAG.

#### Passo a passo
Passo 1. Copie o Client ID do GeneraBB clicando em Meus dados no canto superior direito da tela

Passo 2. Cole o Client ID no arquivo .env na raiz do projeto na chave RAG_CLIENT_ID

Passo 3. Inclua uma nova secret dentro de env no OpenShift do microsserviço com chave RAG_CLIENT_ID e valor igual ao Client ID copiado

## Suporte
Caso tenha necessidade de suporte na implementação de RAG para Agente de IA após a solicitação da oferta, solicite via issue utilizando o template Agentes de IA - Oferta de Agente de IA e assinalando a opção Suporte para implementação de RAG para Agente de IA.

## Próximos passos
- Release e Deploy do Agente de IA	

# Implementação de RAG
## Introdução
Esta documentação apresenta como implementar e configurar o uso de RAG (Retrieval-Augmented Generation) em agentes criados a partir da oferta corporativa de Agente de Inteligência Artificial (IA).

Ao final desta leitura, você será capaz de:

- Entender o conceito de RAG;
- Criar uma base de conhecimento indexada no GeneraBB;
- Configurar o agente para utilização do recurso;
- Adicionar as credenciais necessárias no projeto.
## Definição de RAG
### O que é RAG
RAG (Retrieval-Augmented Generation ou Geração Aumentada por Recuperação) é uma abordagem de inteligência artificial generativa que combina:

- Modelos de linguagem;
- Recuperação de informações externas;
- Busca semântica;
- Contextualização dinâmica de respostas.
Essa abordagem permite que o agente consulte informações externas antes de gerar respostas.

As fontes podem incluir:

- Documentações;
- APIs;
- Bases corporativas;
- Repositórios internos.
Durante a geração da resposta, o modelo utiliza informações recuperadas dessas fontes para complementar o conhecimento pré-treinado e produzir respostas mais contextualizadas.

### Benefícios do uso de RAG
A utilização de RAG permite:

- Respostas mais contextualizadas;
- Redução de alucinações;
- Atualização dinâmica do conhecimento;
- Melhor aderência ao domínio corporativo;
- Utilização de informações especializadas e verificáveis.
### Como o RAG funciona
O fluxo de funcionamento do RAG normalmente envolve:

- Recebimento da solicitação da pessoa usuária;
- Busca semântica em bases indexadas;
- Recuperação de conteúdos relevantes;
- Envio do contexto recuperado ao modelo de linguagem;
- Geração da resposta contextualizada.
Para viabilizar esse processo, o RAG utiliza:

- Modelos de linguagem;
- Embeddings vetoriais;
- Busca semântica;
- Integrações com bases externas;
- Mecanismos de recuperação de contexto.
### Considerações sobre arquitetura e custos
A implementação de RAG adiciona complexidade operacional à solução.

Os principais impactos incluem:

- Maior consumo computacional;
- Infraestrutura vetorial;
- Busca semântica em tempo real;
- Aumento de latência;
- Custos adicionais de processamento.
Além disso, fatores como:

- Volume de documentos indexados;
- Frequência de consultas;
- Tempo de resposta esperado;
- Quantidade de chamadas ao modelo;
impactam diretamente o dimensionamento da solução.

Por isso, avalie cuidadosamente o equilíbrio entre:

- Qualidade das respostas;
- Desempenho;
- Eficiência financeira;
- Escalabilidade da arquitetura.
## Pré-requisitos
Antes de iniciar a implementação do RAG, verifique se você possui:

- Acesso ao GeneraBB;
- Permissão para gestão de índices;
- Acesso ao repositório do agente;
- Permissão para alteração de secrets;
- Client ID autorizado para consumo do serviço.
Para mais informações, consulte a IN 1230, principalmente item 11.5.5.2.

## Passo a passo
- Criar base de conhecimento indexada no GeneraBB
- Atualizar configuração do agente
- Incluir Client ID nas secrets do projeto
### 1. Criar base de conhecimento indexada no GeneraBB
Confira como criar uma base de conhecimento indexada que será utilizada pelo agente durante o processo de recuperação de contexto do RAG.

#### Passo a passo
Passo 1. Acesse a interface do GeneraBB.

Passo 2. No menu lateral em Serviços, selecione a opção Gestão de Agentes;

Passo 3. Clique em Gestão de índice.

Passo 4. Siga o processo de criação da base de conhecimento indexada conforme a documentação do GeneraBB, disponível na seção:

Etapa 2 - Indexação da Base de Conhecimento (Somente Agentes com RAG)
⚠️ Atenção: Não é necessário criar um agente com RAG diretamente no GeneraBB. Nesta etapa, você precisa apenas criar a base de conhecimento indexada.

### 2. Atualizar configuração do agente
Confira a seguir como habilitar o uso do RAG na configuração do agente.

#### Passo a passo
Passo 1. Preencha as informações necessárias no repositório do agente para habilitação do RAG:

No arquivo agent_config.yaml na raiz do projeto, preencha os campos de RAG conforme exemplo abaixo:

```yaml
rag:
  enabled: true
  url: "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"
  uor: "XXXXXX"
  user_id: "FXXXXXXX"
  agent_id: "idx-exemplo" 
  total_context: 5
  timeout: 20.0
```
#### Descrição dos parâmetros
| Parâmetro | Descrição |
| --- | --- |
| enabled | Habilita ou desabilita o uso do RAG |
| url | Endpoint utilizado para comunicação com o serviço |
| uor | Unidade Organizacional responsável |
| user_id | Identificador da pessoa usuária |
| agent_id | Identificador da base indexada criada no GeneraBB |
| total_context | Quantidade máxima de contextos recuperados |
| timeout | Tempo máximo de resposta da requisição em segundos |
⚠️ Atenção:

Valide se o agent_id corresponde exatamente ao índice criado no GeneraBB.

### 3. Incluir Client ID nas secrets do projeto
Confira a seguir como adicionar as credenciais necessárias para autenticação do serviço de RAG.

#### Passo a passo
Passo 1. Copie o Client ID do GeneraBB clicando em Meus dados no canto superior direito da tela

Passo 2. Cole o Client ID no arquivo .env na raiz do projeto na chave RAG_CLIENT_ID

Passo 3. Inclua uma nova secret dentro de env no OpenShift do microsserviço com chave RAG_CLIENT_ID e valor igual ao Client ID copiado

## Suporte
Caso tenha necessidade de suporte na implementação de RAG para Agente de IA após a solicitação da oferta, solicite via issue utilizando o template Agentes de IA - Oferta de Agente de IA e assinalando a opção Suporte para implementação de RAG para Agente de IA.

## Próximos passos
- Release e Deploy do Agente de IA

# Cadastro no Catálogo de IA da Plataforma BB
Nesta seção, você aprende a cadastrar um Agente de IA ou um MCP no Catálogo de IA da Plataforma BB, etapa por etapa.

⚠️ Atenção: Este roteiro é específico para o cadastro na esteira de agentOps. Para outros tipos de cadastramento, consulte a documentação oficial de criação do seu produto de IA.

## Acessando o Catálogo de IA
Confira a seguir os passos para chegar até o Catálogo de IA:

Passo 1. Acesse a Plataforma BB;

Passo 2. Navegue até Tecnologia > Construção > Catálogo > IA; e

Passo 3. Clique no botão NOVO RECURSO DE IA na tela inicial do catálogo.

Menu do Catálogo de IA

## Iniciando o cadastro do item
O assistente de cadastro do Catálogo de IA organiza o fluxo em sete etapas:

- Classificação;
- Dados básicos;
- URL Identificador;
- Responsáveis negociais;
- Integração com ITSM;
- Segurança; e
- Confirmação.
Confira a seguir o detalhamento de cada etapa.

## Etapa 1 - Classificação
Na tela de classificação, selecione o tipo de solução que está sendo cadastrada:

- Agente de IA; ou
- MCP.
💡 Dica: A diferença entre as telas de cadastro aparece na seleção do tipo de solução.

### Caso 1 - Cadastro de Agente de IA
Para cadastro de Agente, selecione a opção Agente e Usa credencial interna para microsserviço do BB.

#### Como a comunicação acontece no caso de Agente de IA
Confira a seguir as formas de comunicação disponíveis:

- Credencial: normalmente usada para comunicação de agente para agente e agente para MCP, sem necessidade de credencial do usuário;
- OpenAM: para casos em que a comunicação usa credencial de usuário interno do BB; e
- OAuth: para casos em que a comunicação usa credencial de usuário externo.
⚠️ Atenção: O caminho acima funciona para a maioria dos casos, mas pode não se enquadrar em todos os cenários. Se você tiver dúvidas sobre autenticação, fluxo de integração ou forma de consumo, procure o time de integração, responsável pelo Catálogo de IA, antes de concluir o cadastro.

### Caso 2 - Cadastro de MCP
Para cadastro de MCP, selecione a opção MCP e Uso por agente criado pelo BB.

#### Como a comunicação acontece no caso de MCP
Confira a seguir as formas de comunicação disponíveis:

- Copilot: uso em cenários em que o MCP é acessado via Copilot;
- Uso por agente: comunicação direta do agente com o MCP; e
- Demais usos: integrações e fluxos fora do contexto de agente, quando o padrão de consumo for diferente.
⚠️ Atenção: Se o MCP tiver forma diferente de consumo, autenticação ou integração, procure o time de integração, responsável pelo Catálogo de IA, para entender o cenário e evitar um cadastro que não reflita o uso real da solução.

## Etapa 2 - Dados básicos
Preencha as informações principais do item:

- Nome: nome claro e objetivo do item, identificando a finalidade da solução;
- Sigla: sigla da equipe, solução ou domínio responsável;
- Descrição: explique de forma objetiva para que a solução serve, qual problema resolve e qual escopo de uso é esperado;
- Categoria: selecione qual categoria faz mais sentido com a solução; e
- Sub-categoria: selecione qual sub-categoria faz mais sentido com a solução.
Observações importantes desta etapa:

- Os campos com * são obrigatórios;
- Mantenha o nome curto e objetivo; e
- Se a sigla não estiver disponível, use a opção de solicitação de inclusão na própria tela.
⚠️ Atenção: A descrição deve ser clara, porque ela será usada para entendimento do item por usuários e pelos times de suporte.

### Aplicação provedora e recurso
Preencha as informações da aplicação e dos recursos, referentes à aplicação criada na oferta:

- Aplicação provedora: selecione a aplicação provedora; e
- Recurso: informe o endpoint da aplicação. O padrão é o método POST e a URL /chat, mas isso pode mudar de acordo com a aplicação.
## Etapa 3 - URL Identificador
Preencha a informação a seguir:

Identificador na URL: escolha o identificador que será usado na URL. Ele deve ser um nome simplificado do nome da solução.
Observações importantes desta etapa:

- Use letras minúsculas;
- Não use espaços;
- Separe palavras com hífen (-); e
- Evite acentos e caracteres especiais.
O identificador deve ser curto e fácil de reconhecer na URL.

## Etapa 4 - Responsáveis negociais
Preencha os dados de quem serão os responsáveis negociais da solução:

UOR da Gestão Negocial: insira a UOR dos responsáveis pela solução.
O sistema preenche o nome da UOR automaticamente após você informar uma UOR válida. Depois de preencher, valide se o nome retornado corresponde ao time correto.

## Etapa 5 - Integração com ITSM
Preencha as informações a seguir, nesta ordem:

- Grupo de atribuição: selecione o grupo de atribuição adequado;
- Serviço ITSM: selecione o serviço que melhor se adequa; e
- Oferta de serviço ITSM: selecione a oferta que melhor se adequa.
💡 Dica: Se o grupo ou o serviço escolhido alterar as opções disponíveis, revise a oferta antes de avançar.

## Etapa 6 - Segurança
Preencha a informação a seguir:

Indicador de transação monetária: selecione se a solução pode efetivar operação monetária de crédito ou débito no BB.
Marque Sim apenas quando houver possibilidade de efetivar transação monetária.

## Etapa 7 - Confirmação
Confira a seguir os passos para concluir o cadastro:

Passo 1. Revise todas as informações preenchidas, principalmente classificação, aplicação provedora, endpoint, identificador de URL e UOR;

Passo 2. Volte à etapa correspondente para corrigir qualquer informação incorreta; e

Passo 3. Clique no botão SALVAR para concluir o cadastro.

## Validação e publicação
Depois de concluir o cadastro, valide se o item está cadastrado corretamente.

Se a solução estiver pronta para uso, a mesma será gerada com o estado Em cadastramento, promova através do catálogo no menu AÇÕES para o ambiente de Desenvolvimento, Homologação ou Produção, conforme a rotina do projeto.

⚠️ Atenção: Para editar a API após a publicação, versione-a e retorne-a ao estado de cadastramento antes de fazer alterações.

## Autorizando aplicações consumidoras
Nos detalhes da API, acesse Segurança e Autorizações e verifique as configurações a seguir:

Confira a seguir os passos para autorizar uma aplicação consumidora:

Passo 1. Em Segurança e Autorizações, acesse Aplicações consumidoras;

Passo 2. Clique no botão CONSULTAR APLICAÇÕES;

Passo 3. Localize a aplicação e clique no ícone de gerenciamento; e

Passo 4. No modal Gerenciar Consumidor, clique no botão AUTORIZAR.

Após a autorização, a aplicação aparecerá na lista com o estado 100 – Autorizado.

## Consultando as credenciais (App Key)
No Catálogo de Aplicações, abra sua aplicação, acesse Credenciais e selecione o ambiente (Desenvolvimento, Homologação ou Produção) para visualizar a AppKey.

Com isso, o cadastro da no catálogo e a vinculação à aplicação estão concluídos, cujo qual está em conformidade com o gateway interno da Plataforma BB.

⚠️ Atenção: O registro no catálogo de IA deve estar minimamente no ambiente de desenvolvimento para que a App Key seja gerada com sucesso.

## Boas práticas de cadastro
Para manter o Catálogo de IA consistente e fácil de consultar, siga estas recomendações:

- Use nomes objetivos e padronizados;
- Descreva com clareza o objetivo da solução e o que ela não faz;
- Diferencie bem Agente de IA de MCP;
- Vincule sempre a aplicação responsável correta;
- Revise a categoria e os dados de governança antes de publicar; e
- Atualize o cadastro quando houver mudança de responsável, escopo ou arquitetura.
## Próximos passos
- Continuar configurações do agente em estrutura do projeto
