# ESTEIRA AGENTS OPS - MCP

# Introdução
Esta documentação explica o que é um MCP Server e como criá-lo por meio da solução corporativa do EmpresaBB.

## Visão geral da Solução de MCP Server
Um MCP Server (Model Context Protocol Server) é um componente de software projetado para centralizar, padronizar e controlar a comunicação entre aplicações cliente e múltiplos provedores de serviços, geralmente relacionados a IA generativa, orquestração de recursos ou automação.

Ele funciona como uma camada intermediária entre sistemas consumidores e serviços externos, oferecendo uma interface unificada para operações complexas.

## Objetivo da solução
O objetivo desta solução é oferecer uma oferta padronizada e acessível para a criação e implementação de MCP Servers, permitindo que usuários autorizados desenvolvam seus próprios MCPs a partir de um template oficial previamente definido.

Essa oferta tem como finalidade:

- Acelerar o desenvolvimento de novos MCPs, fornecendo uma base estruturada, testada e alinhada às melhores práticas do protocolo MCP;
- Garantir padronização, tanto na arquitetura quanto na forma de expor ações, recursos e capacidades, reduzindo inconsistências entre implementações;
- Simplificar o processo de criação, abstraindo complexidades técnicas e disponibilizando um ponto de partida estável para múltiplos cenários de negócio;
- Promover governança e segurança, assegurando que todas as instâncias criadas sigam diretrizes de conformidade, controle de acesso e auditoria;
- Aumentar a autonomia dos usuários, permitindo que equipes internas criem MCPs personalizados conforme suas necessidades específicas, sem depender de implementações ad hoc ou acopladas a provedores;
- Facilitar integração com sistemas corporativos, ao oferecer um modelo uniforme para comunicação com serviços internos e plataformas externas.
Em essência, a solução estabelece um ecossistema padronizado para construção de servidores MCP, garantindo agilidade, consistência e escalabilidade no desenvolvimento de novas capacidades baseadas no Model Context Protocol.

## Jornada do usuário
Para criar e operar um MCP Server, siga a jornada abaixo:

- Solicitação de MCP Server — Como solicitar a criação da oferta no Tech.bb
- Estrutura do Projeto — O que você recebe após o provisionamento e como configurar o repositório
- Desenvolvimento do MCP Server — Como desenvolver tools, resources e prompts utilizando FastMCP
- Release e Deploy — Como realizar o deploy nos ambientes de desenvolvimento, homologação e produção

# Solicitação de MCP Server
Esta documentação orienta como utilizar a oferta de criação de MCP Server, incluindo os papéis de acesso necessários e referências técnicas para o desenvolvimento de MCP Server.

## Requisitos
### Para solicitar
Para acessar a oferta de MCP Server no Tech.bb, você deve ter o papel de acesso ALMFD\<SIGLA\>, onde \<SIGLA\> corresponde à sigla de domínio no qual será provisionada a instância.

### Para aprovação
Em caráter temporário, a aprovação da Oferta de MCP Server deverá ser realizada pelo papel DEVMSAPV, cuja atribuição é restrita aos Gerentes Executivos e aos Gerentes Gerais da DITEC.

## Passo a passo
- Acessar oferta no Tech.bb
- Preencher o formulário da oferta
- Solicitar migração de repositório python para o GitHub (opcional)
- Criar API vinculada ao MCP Server
### 1. Acessar oferta no Tech.bb
A oferta de criação de MCP Server está disponível na plataforma interna do desenvolvedor em Tech.bb - Oferta de MCP Server.

### 2. Preencher o formulário da oferta
Na página da oferta de MCP Server, siga as instruções abaixo para o correto preenchimento dos campos necessários:

Passo 1. Preencha os dados da solicitação com as seguintes informações:

- Sigla na qual o projeto será criado;

- Descrição do microsserviço do MCP Server contendo as ferramentas, recursos e prompts disponibilizados.

- ⚠️ Atenção: A descrição deve ser precisa e abrangente para que os agentes e outros serviços que consomem este MCP Server possam identificar claramente seu uso e aplicabilidade.

- Nome deve identificar de forma sucinta e objetiva o propósito do MCP Server;

- UOR mantenedora deve ser a equipe responsável pela criação e manutenção do MCP Server.

Preencher os dados da solicitação

Passo 2. Preencha o nome e grupo da instância com as seguintes informações:

- Nome da instância deve iniciar com mcp- e seguir o padrão mcp-instancia-de-exemplo. Após a criação do microsserviço, a sigla indicada anteriormente será incluída como prefixo da instância (ex: abc-mcp-instancia-de-exemplo);

- Grupo de recursos no qual a instância será criada. Preferencialmente todos MCP Servers de uma mesma sigla devem ser criados em um mesmo grupo de recursos, caso este não exista, ele pode ser criado no momento da solicitação clicando em CRIAR NOVO GRUPO DE RECURSOS.

Preencher nome e grupo da instância

Passo 3. Confirme as informações na tela de resumo e clique em SOLICITAR:

Confirmar as informações e solicitar criação do MCP Server

Passo 4. Acompanhe o provisionamento e clique em ACESSAR RECURSO para visualizar as informações da instância criada:

Tela de provisionamento da instância de MCP Server

Passo 5. Na tela seguinte serão exibidos os detalhes da instância de MCP Server criada:

Tela de detalhamento da instância de MCP Server

Caso tenha necessidade de suporte na solicitação de MCP Server, solicite via issue utilizando o template Agentes de IA - MCP Server e assinalando a opção Suporte para solicitação da oferta de MCP Server no Tech.bb.

### 3. Solicitar migração de repositório Python para o GitHub (opcional)
Caso tenha optado pela criação de MCP Server com template Python, você precisa solicitar a migração do repositório criado no GitLab para o GitHub via oferta na plataforma interna do desenvolvedor em Tech.bb - Oferta de migração de repositório para o GitHub.

Preencha o formulário com as informações solicitadas referentes a sua gerência e UOR, assim como os dados do projeto criado anteriormente. Seu repositório será migrado para o GitHub e configurado para a esteira corporativa de CI/CD python.

Caso tenha optado pelo template Java, o repositório já será criado no GitHub, dispensando esta etapa de migração. Acesse pelo link disponível na oferta.

### 4. Criar API vinculada ao MCP Server
Em alinhamento com critérios de segurança e integração, a integração do MCP Server com outras ferramentas corporativas deve sempre passar por um gateway que implementa observabilidade e valida autorizações de consumo e provimento das ferramentas disponíveis, o mesmo ocorre com o consumo do MCP Server diretamente pelos canais internos e externos ou por um Agente de IA. Para permitir tal integração entre componentes de uma solução baseada em agentes de IA, cada microsserviço do tipo MCP Server deve estar sempre vinculado a uma API cadastrada no Catálogo de APIs conforme a documentação disponível em Documentação do Catálogo de APIs.

Siga as instruções na documentação indicada para criação de API vinculada ao MCP Server, incluindo os recursos disponibilizados pelo MCP Server para consumo do mesmo e respectivas autorizações para as ferramentas consumidas pelo MCP Server.

## Referências técnicas
- Documentação oficial do FastMCP
- LangChain Academy
## Suporte
Caso tenha necessidade de suporte na criação de MCP Server após a solicitação da oferta, solicite via issue utilizando o template Agentes de IA - MCP Server e assinalando a opção Suporte para criação de MCP Server após solicitação da oferta.

## Próximos passos
- Estrutura do projeto

# Estrutura do Projeto
Esta documentação descreve o que o usuário recebe após a aprovação da solicitação de MCP Server, incluindo os recursos provisionados, a estrutura do repositório e as configurações iniciais necessárias para o desenvolvimento.

⚠️ Antes de continuar: certifique-se de que a solicitação de MCP Server foi aprovada e provisionada com sucesso.

## O que você recebe após o provisionamento
Após a aprovação e o provisionamento da oferta de MCP Server, os seguintes recursos são disponibilizados:

- Repositório de código (codebase) contendo o template com a estrutura base do MCP Server;
- Deploy (Argo CD) com os ambientes de desenvolvimento, homologação e produção pré-configurados;
- Instância do serviço visível na Gestão de Serviços Tecnológicos.
⚠️ Atenção: O repositório pode ser criado com template Python ou template Java, conforme a opção selecionada na oferta.

| Template | Repositório criado em | Migração necessária |
| --- | --- | --- |
| Python | GitLab | Sim — Solicitar migração clicando no link abaixo |
| Java | GitHub | Não — Repositório criado direto no GitHub |
⚠️ Atenção: Caso o template escolhido seja em Python, é necessário solicitar migração para o GitHub

## Estrutura de branches
O repositório é criado com as seguintes branches:

| Branch | Conteúdo |
| --- | --- |
| master (ou main) | Template completo com a estrutura base do MCP Server |
| develop | Branch de desenvolvimento — inicialmente vazia |
💡 Dica: Utilize a branch develop para o desenvolvimento do MCP Server. A branch master/main contém o template original e serve como referência.

## Estrutura de pastas do template (Python)
O template Python do MCP Server utiliza o framework FastMCP e possui a seguinte estrutura base:

```text
-mcp-/
├── app/
│   ├── __init__.py
│   ├── main.py                  # Ponto de entrada da aplicação
│   ├── server/
│   │   ├── __init__.py
│   │   ├── mcp_server.py        # Definição do MCP Server (FastMCP)
│   │   ├── tools.py             # Ferramentas (tools) expostas pelo MCP
│   │   ├── resources.py         # Recursos (resources) expostos pelo MCP
│   │   └── prompts.py           # Prompts disponibilizados pelo MCP
│   └── config/
│       └── settings.py          # Configurações e variáveis de ambiente
├── tests/
│   └── ...                      # Testes unitários e de integração
├── chart/
│   └── ...                      # Configuração do chart para deploy (Helm)
├── requirements.txt             # Dependências Python
├── Dockerfile                   # Imagem do container
├── README.md                    # Documentação do projeto
└── .github/
  └── workflows/               # Pipelines CI/CD (GitHub Actions)
```
⚠️ Importante: A estrutura acima é uma referência do template Python. Para o template Java, consulte a documentação no README.md do repositório recebido. Verifique sempre a versão atual do template, pois pode haver atualizações.

## Configurações iniciais
Após receber o repositório, as seguintes configurações devem ser realizadas antes de iniciar o desenvolvimento:

### 1. Migrar o repositório para o GitHub (se Python)
Caso tenha optado pelo template Python e ainda não tenha realizado, solicite a migração para o GitHub. Para o template Java, o repositório já estará no GitHub.

### 2. Verificar o chart de deploy
O diretório chart/ contém as configurações de deploy via Helm/Argo CD. Verifique se:

- O chart está configurado com o gateway obrigatório;
- As variáveis de ambiente necessárias estão definidas;
- Os endpoints expostos estão corretos.
⚠️ Atenção: O chart obriga o tráfego a passar pelo gateway corporativo. Não é possível acessar o container diretamente — todas as requisições devem passar pelo gateway.

### 3. Configurar variáveis de ambiente
As variáveis de ambiente e secrets necessários para o funcionamento do MCP Server devem ser configurados conforme a documentação do template no README.md do repositório.

## Acompanhamento via Gestão de Serviços Tecnológicos
O status do provisionamento e os detalhes da instância criada podem ser acompanhados pela Gestão de Serviços Tecnológicos, onde é possível verificar:

- Se o provisionamento foi concluído com sucesso;
- Os recursos associados à instância;
- Eventuais erros ocorridos durante o processo.
## Próximos passos
- Desenvolvimento do MCP Server

# Desenvolvimento do MCP Server
Esta documentação orienta como desenvolver um MCP Server a partir do template recebido, incluindo a implementação de ferramentas (tools), recursos (resources), prompts e testes locais.

⚠️ Antes de continuar: certifique-se de que o repositório foi configurado conforme descrito em Estrutura do Projeto e que a migração para o GitHub foi concluída (se template Python).

## Visão geral do desenvolvimento
O template de MCP Server utiliza o framework FastMCP para exposição de ferramentas, recursos e prompts seguindo o protocolo MCP (Model Context Protocol). O desenvolvimento consiste em:

- Configurar o ambiente de desenvolvimento local
- Implementar ferramentas (tools)
- Implementar recursos (resources)
- Implementar prompts
- Configurar variáveis de ambiente e secrets
- Executar testes locais
### 1. Configurar o ambiente de desenvolvimento local
Para desenvolver localmente com o template Python, configure o ambiente:

```bash
# Criar e ativar o ambiente virtual
python3 -m venv .venv
source .venv/bin/activate

# Instalar dependências
pip install -r requirements.txt
```
💡 Dica: Recomenda-se utilizar Python 3.11+ para compatibilidade com o template. Para o template Java, consulte o README.md do repositório para instruções específicas.

### 2. Implementar ferramentas (tools)
As ferramentas são funções que o MCP Server expõe para serem invocadas por agentes ou outras aplicações consumidoras. Elas são definidas em app/server/tools.py:

```python
from fastmcp import FastMCP

mcp = FastMCP("meu-mcp-server")

@mcp.tool()
def consultar_dados(query: str) -> str:
  """Consulta dados a partir de uma query fornecida."""
  # Implementação da ferramenta
  return resultado
```
⚠️ Atenção: As ferramentas devem ter docstrings claras e descritivas, pois os agentes consumidores utilizam essas descrições para identificar quando e como invocar cada ferramenta. A descrição do MCP Server informada na oferta também deve refletir as ferramentas disponíveis.

### 3. Implementar recursos (resources)
Os recursos representam dados ou informações que o MCP Server disponibiliza para leitura. Eles são definidos em app/server/resources.py:

```python
@mcp.resource("dados://meu-recurso")
def obter_recurso() -> str:
  """Retorna os dados do recurso solicitado."""
  return dados
```
Os recursos permitem que agentes acessem informações de forma padronizada, sem necessidade de invocar ferramentas.

### 4. Implementar prompts
Os prompts são templates pré-definidos que o MCP Server oferece para orientar o uso de suas capacidades. Eles são definidos em app/server/prompts.py:

```python
@mcp.prompt()
def prompt_analise(contexto: str) -> str:
  """Prompt para análise de dados com contexto fornecido."""
  return f"Analise os seguintes dados considerando o contexto: {contexto}"
```
### 5. Configurar variáveis de ambiente e secrets
As configurações do MCP Server são gerenciadas em app/config/settings.py. As variáveis de ambiente sensíveis devem ser configuradas como secrets no repositório GitHub e injetadas via pipeline CI/CD.

- Variáveis comuns:

| Variável | Descrição |
| --- | --- |
| MCP_SERVER_NAME | Nome identificador do MCP Server |
| MCP_SERVER_PORT | Porta de exposição do serviço |
| DATABASE_URL | URL de conexão com banco de dados (se aplicável) |
| LOG_LEVEL | Nível de log da aplicação |
⚠️ Importante: Nunca armazene secrets diretamente no código-fonte. Utilize variáveis de ambiente ou o gerenciador de secrets do GitHub.

### 6. Executar testes locais
Antes de submeter o código, execute os testes locais para validar o funcionamento do MCP Server:

```bash
# Executar testes unitários
pytest tests/

# Executar o MCP Server localmente
python -m app.main
```
💡 Dica: Recomenda-se criar testes para cada ferramenta (tool), recurso (resource) e prompt exposto pelo MCP Server. Valide as respostas e os formatos de saída.

## Referências técnicas
- Documentação oficial do FastMCP
- LangChain Academy
- Especificação do protocolo MCP
## Suporte
Caso tenha necessidade de suporte no desenvolvimento de MCP Server, solicite via issue utilizando o template Agentes de IA - MCP Server e assinalando a opção Suporte para criação de MCP Server após solicitação da oferta.

## Próximos passos
- Release e Deploy do MCP Server

# Release e Deploy
⚠️ Atenção: A validação do Selo Cloud para MCP Server está sendo atualizada para incluir a regra do chart customizado dia-chart-mcp substituindo a verificação do bb-aplic.

Esta documentação descreve o processo de release e deploy de um MCP Server, incluindo o pipeline de CI/CD, o deploy via Argo CD nos ambientes de desenvolvimento, homologação e produção, e as configurações obrigatórias do chart.

⚠️ Antes de continuar: certifique-se de que o desenvolvimento do MCP Server foi concluído e que os testes locais foram executados com sucesso.

## Visão geral do processo de deploy
O fluxo de deploy do MCP Server segue as etapas abaixo:

- Commitar e enviar o código para o GitHub
- Pipeline CI/CD (GitHub Actions)
- Configurar o chart de deploy
- Deploy via Argo CD
- Configurar o Catálogo de API
- Promover entre ambientes
### 1. Commitar e enviar o código para o GitHub
Após concluir o desenvolvimento e os testes locais, envie o código para o repositório GitHub na branch develop:

```bash
git add .
git commit -m "feat: implementação do MCP Server"
git push origin develop
```
💡 Dica: Utilize conventional commits para manter um histórico organizado.

### 2. Pipeline CI/CD (GitHub Actions)
Ao enviar o código para o GitHub, o pipeline de CI/CD é executado automaticamente via GitHub Actions. O pipeline realiza:

- Build da imagem Docker do MCP Server;
- Execução dos testes automatizados;
- Push da imagem para o registry corporativo;
- Atualização do chart com a nova versão.
⚠️ Atenção: Caso o pipeline falhe, verifique os logs na aba Actions do repositório GitHub para identificar o erro.

### 3. Configurar o chart de deploy
O diretório chart/ do repositório contém as configurações de deploy via Helm. Antes do primeiro deploy, verifique os seguintes pontos:

- O gateway corporativo está configurado corretamente no chart;
- As variáveis de ambiente e secrets estão definidas nos valores do chart;
- Os endpoints expostos pelo MCP Server estão corretos;
- Os limites de recursos (CPU, memória) estão adequados.
⚠️ Importante: O chart obriga que todo o tráfego passe pelo gateway corporativo. Não é possível acessar o container diretamente. Se a aplicação possui o chart corporativo, deve-se utilizar obrigatoriamente o gateway.

### 4. Deploy via Argo CD
O deploy do MCP Server é gerenciado pelo Argo CD, que sincroniza o estado do cluster com as configurações do repositório. Os ambientes disponíveis são:

| Ambiente | Descrição |
| --- | --- |
| Desenvolvimento | Ambiente para testes iniciais e validação |
| Homologação | Ambiente para validação pré-produção |
| Produção | Ambiente final de operação |
O deploy no ambiente de desenvolvimento ocorre automaticamente após o pipeline de CI/CD. Para homologação e produção, é necessário promover manualmente.

### 5. Configurar o Catálogo de API
Para que o MCP Server seja acessível via gateway, é necessário configurar a API no Catálogo de API corporativo conforme a Documentação do catálogo de API. Consulte a documentação correspondente para:

- Criar a API como aplicação interna;
- Configurar a comunicação interna de microsserviços;
- Definir o RI (Resource Indicator) — que substitui o acesso direto via DNS;
- Criar o recurso com as URLs expostas (endpoint POST);
- Promover a API entre os ambientes (cadastramento → desenvolvimento → homologação → produção).
⚠️ Atenção: Para o MCP Server, a configuração no catálogo de API será sempre como comunicação interna de microsserviços. A configuração incorreta do catálogo de API impede o funcionamento do MCP Server. Siga a documentação do Catálogo de API cuidadosamente.

### 6. Promover entre ambientes
A promoção entre ambientes segue o fluxo:

```text
Desenvolvimento → Homologação → Produção
```
Para cada promoção:

- Valide o funcionamento do MCP Server no ambiente atual;
- Promova a versão no Argo CD;
- Promova a API correspondente no Catálogo de API;
- Valide o funcionamento no novo ambiente.
⚠️ Importante: Ao realizar alterações no MCP Server já promovido, é necessário versionar e promover novamente em cada ambiente.

## Acompanhamento
O status do deploy e dos recursos provisionados pode ser acompanhado por:

- Argo CD — para verificar a sincronização e o estado dos pods;
- Gestão de Serviços Tecnológicos — para verificar a instância e os recursos associados;
- GitHub Actions — para verificar o status dos pipelines de CI/CD.
## Suporte
Caso tenha necessidade de suporte no deploy de MCP Server, solicite via issue utilizando o template Agentes de IA - MCP Server e assinalando a opção Suporte para criação de MCP Server após solicitação da oferta.

# Cadastro no Catálogo de APIs da Plataforma BB
Nesta seção, você aprende a criar e vincular uma API no Catálogo de APIs da Plataforma BB, garantindo que a aplicação seja registrada corretamente e validada pelo gateway interno.

Este guia contém as informações a seguir:

- Como acessar o Catálogo de APIs;
- Como criar a API pelo assistente de criação;
- Como vincular a aplicação à API;
- Como evoluir a API para os ambientes;
- Como configurar segurança, autorizações e credenciais;
- Como obter os certificados para execução local; e
- Como testar a API com cURL.
## Pré-requisitos
Antes de iniciar, certifique-se de que você possui:

- Acesso à Plataforma BB com perfil adequado para criação de APIs;
- Uma aplicação já cadastrada no Catálogo de Aplicações da Plataforma BB;
- Informações de integração com o ITSM (IT Service Management — gestão de serviços de TI): grupo de atribuição, serviço e oferta; e
- UOR de Contato Negocial responsável pela API.
## 1. Acessando o Catálogo de APIs
Confira a seguir os passos para acessar o Catálogo de APIs:

Passo 1. Na Plataforma BB, acesse o menu lateral Construção e, dentro da seção Catálogo, clique em APIs;

Menu da Plataforma BB

Passo 2. Clique no botão NOVA API.

Catálogo de APIs

## 2. Criando a API - Passo a passo do assistente
O assistente de criação é composto por 6 etapas: Classificação, Dados básicos, Identificador da URL, Responsável negocial, Integração com ITSM e Confirmação. Confira a seguir como preencher cada etapa.

### Etapa 1 - Classificação
Na pergunta "Qual é o uso da API?", selecione:

- Uso por aplicações internas do BB.

### Etapa 2 - Dados básicos: Finalidade
Na pergunta "Qual a finalidade da API que você quer criar?", selecione:

- Para a comunicação entre microsserviços, sem utilizar operação IIB.

Em seguida, preencha os campos de identificação da API:

- Sigla: sigla da sua equipe/sistema;
- Nome: nome claro e conciso que indique a finalidade da API. Deve ser único, preferencialmente iniciado por substantivo, sem siglas ou termos técnicos; e
- Descrição: descreva de forma objetiva o propósito da API e as funcionalidades que ela expõe (até 500 caracteres).
💡 Dica: Consulte as dicas (ícone ℹ) ao lado de cada campo.

### Etapa 3 - Identificador da URL
Informe o identificador da API na URL. Ele define a base do path dos endpoints, no formato:

```text
https://api.bb.com.br//v1/recurso
```
O identificador deve seguir as regras a seguir:

- Somente letras minúsculas;
- Sem espaços;
- Palavras separadas por hífen (-); e
- Sem acentos ou caracteres especiais.
### Etapa 4 - Responsável negocial
Informe a UOR de Contato Negocial responsável pela API. O sistema preenche o nome da UOR automaticamente após a busca.

### Etapa 5 - Integração com ITSM
Preencha as informações para integração com o ITSM:

- Grupo de atribuição;
- Serviço ITSM; e
- Oferta.
### Etapa 6 - Confirmação
Revise os dados de Classificação, Dados básicos, Identificador na URL, Responsável negocial e Integração com ITSM. Use o ícone de edição para corrigir os dados, se necessário. Clique no botão CRIAR.

## 3. Vinculando a Aplicação à API
Acesse os detalhes da API no catálogo. Na seção RECURSOS, clique no botão ADICIONAR RECURSO.

O assistente de criação de recurso é composto por 5 etapas: Informações Iniciais, Relacionamentos, Contratos, Segurança e Confirmação. Confira a seguir como preencher cada etapa.

### Etapa 1 - Informações Iniciais
Preencha as informações do novo recurso:

- Nome do recurso de API: inicie com verbo no infinitivo, descrevendo a funcionalidade exposta. Seja específico e evite termos técnicos complexos (ex.: "Consultar lançamentos por período");
- Sigla do Sistema: sigla da equipe responsável; e
- Descrição: descrição objetiva da funcionalidade do recurso.
### Etapa 2 - Relacionamentos
Confira a seguir os passos para vincular a aplicação provedora ao recurso:

Passo 1. Clique no botão SELECIONAR APLICAÇÃO para vincular sua aplicação existente (ou CRIAR NOVA APLICAÇÃO, se necessário);

Passo 2. No campo Recurso na aplicação provedora, selecione o método HTTP (em geral POST) e informe o endpoint da aplicação (ex.: /mcp);

Passo 3. Em API, selecione a API criada anteriormente; e

Passo 4. Em Recurso exposto aos consumidores da API, informe o path que será exposto externamente.

💡 Dica: Se as URLs ainda não estiverem cadastradas, informe-as no modal para os ambientes de Desenvolvimento, Homologação e Produção.

### Etapa 3 - Contratos
Defina os schemas de Requisição e Resposta. Esta etapa é opcional.

### Etapa 4 - Segurança
Mantenha a restrição de acesso ativada (toggle ligado). Confirme que o gateway selecionado é Interno e que a restrição está configurada como Sim.

### Etapa 5 - Confirmação
Revise as configurações e conclua a criação do recurso. Após criar o recurso, visualize as informações completas: aplicação provedora, método, endpoint, URLs por ambiente e URLs finais na API.

## 4. Evoluindo a API para os ambientes
Acesse o menu AÇÕES nos detalhes da API e selecione a opção de promoção. Promova até Homologação (HML) para validar antes de produção.

⚠️ Atenção: para editar a API após a publicação, versione-a e retorne-a ao estado de cadastramento antes de fazer alterações.

## 5. Segurança, Autorizações e Credenciais
### 5.1 - Verificando as configurações de segurança
Nos detalhes da API, acesse Segurança e Autorizações e verifique as configurações: Restrição de Acesso, mTLS (TLS mútuo, autenticação com certificados nos dois lados da conexão), Validar Certificado Intermediário, Enviar Certificado Cliente, Utiliza Proxy, Utiliza App-key e Token de Atendimento.

### 5.2 - Autorizando aplicações consumidoras
Confira a seguir os passos para autorizar uma aplicação consumidora:

Passo 1. Em Segurança e Autorizações, acesse Aplicações consumidoras e clique no botão CONSULTAR APLICAÇÕES;

Passo 2. Localize a aplicação e clique no ícone de gerenciamento; e

Passo 3. No modal Gerenciar Consumidor, clique no botão AUTORIZAR.

Após a autorização, a aplicação aparecerá na lista com o estado 100 – Autorizado.

### 5.3 - Consultando as credenciais (App Key)
No Catálogo de Aplicações, abra sua aplicação, acesse Credenciais e selecione o ambiente (Desenvolvimento, Homologação ou Produção) para visualizar a AppKey.

Com isso, o cadastro da API e a vinculação à aplicação estão concluídos, e a API está em conformidade com o gateway interno da Plataforma BB.

## 6. Obtendo os certificados para execução local
Para fazer chamadas locais pelo gateway, você precisa de:

- App Key: obtida no Catálogo de Aplicações da Plataforma BB para o ambiente respectivo, conforme descrito na seção anterior; e
- Certificados mTLS: obtidos nas secrets do container do ambiente selecionado. Os certificados estão na secret idh-mtls.
Confira a seguir os passos para baixar os certificados:

Passo 1. No painel do seu projeto no OpenShift, acesse o menu lateral Secrets;

Passo 2. Localize a secret idh-mtls na lista; e

Passo 3. Na tela de detalhes, faça o download de ca.crt, tls.crt e tls.key.

## 7. Testando a API com cURL
Com os certificados e a App Key, use os guias abaixo para validar as aplicações em HML (Homologação):

| Aplicação | Guia de referência |
| --- | --- |
| Servidor MCP (BBMCPServer) | Testando com cURL |
Os guias contêm a sequência completa de chamadas, resultados reais validados em HML, referência de flags e tabela de certificados.

Com esses pontos validados, prossiga com o desenvolvimento e a disponibilização da aplicação.

## Próximos passos
- Teste a API com cURL no guia do MCP Corporativo BB (HML);
- ⚠️ Informação não disponível — inserir segundo link relevante (ex.: guia do Catálogo de Aplicações ou de promoção de ambientes).

# Testando com cURL – MCP Corporativo BB (HML)
Nesta seção, você encontra os comandos curl para teste e documentação do servidor MCP (Model Context Protocol) via Streamable HTTP + mTLS IDH, validados no ambiente de Homologação (HML).

O transporte usa JSON-RPC 2.0 com respostas em text/event-stream — o formato SSE (Server-Sent Events).

## Variáveis de ambiente
Defina as variáveis a seguir antes de executar qualquer bloco deste guia:

```bash
CERT_DIR=""
MCP_BASE_URL=""
APP_KEY=""
COOKIES=/tmp/mcp-session-cookies.txt
```
⚠️ Atenção: este servidor MCP gerencia sessão via cookies HTTP (não via header Mcp-Session-Id).

- Use -c "$COOKIES" ao chamar initialize para salvar o cookie de sessão;
- Use -b "$COOKIES" em todas as chamadas subsequentes para reutilizá-lo;
- Chamar tools/call (ou qualquer método) sem sessão válida faz o servidor não responder, resultando em timeout 9504 do API Gateway; e
- A flag -N é obrigatória para leitura de SSE; sem ela, o curl bufferiza a stream e a conexão pode travar.
## Fluxo obrigatório do protocolo MCP
O protocolo MCP exige que as chamadas sigam a ordem abaixo:

```text
1. initialize          → handshake + negociação de capacidades
2. notifications/initialized → confirma que o cliente está pronto (sem resposta esperada)
3. tools/list          → descobre as ferramentas disponíveis
4. tools/call          → invoca uma ferramenta específica
5. resources/list      → (opcional) lista recursos expostos pelo servidor
6. prompts/list        → (opcional) lista prompts pré-definidos
```
## 1. initialize (handshake)
Primeira chamada obrigatória. Negocia versão do protocolo e capacidades. Use -c "$COOKIES" para salvar o cookie de sessão retornado pelo servidor.

```bash
curl -N \
-X POST "${MCP_BASE_URL}" \
-c "${COOKIES}" \
--cert   "${CERT_DIR}/mcp-idh-hml-tls.crt" \
--key    "${CERT_DIR}/mcp-idh-hml-tls.key" \
--cacert "${CERT_DIR}/mcp-idh-hml-ca.crt" \
-H "gw-dev-app-key: ${APP_KEY}" \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-d '{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "protocolVersion": "2025-03-26",
    "capabilities": {},
    "clientInfo": {
      "name": "curl-test",
      "version": "1.0.0"
    }
  }
}'
Copy
```

```text
event: message
data: {"jsonrpc":"2.0","id":1,"result":{"protocolVersion":"2025-03-26","capabilities":{...},"serverInfo":{"name":"BBMCPServer","version":"3.4.2"}}}
```
Resultado real (HML):

```text
event: message
data: {"jsonrpc":"2.0","id":1,"result":{"protocolVersion":"2025-03-26","capabilities":{"experimental":{},"logging":{},"prompts":{"listChanged":true},"resources":{"subscribe":false,"listChanged":true},"tools":{"listChanged":true},"extensions":{"io.modelcontextprotocol/ui":{}}},"serverInfo":{"name":"BBMCPServer","version":"3.4.2"}}}
```
## 2. notifications/initialized
Notifica o servidor que o cliente concluiu a inicialização. Esta chamada não retorna resposta (HTTP 200 com body vazio).

```bash
curl -N \
-X POST "${MCP_BASE_URL}" \
-b "${COOKIES}" -c "${COOKIES}" \
--cert   "${CERT_DIR}/mcp-idh-hml-tls.crt" \
--key    "${CERT_DIR}/mcp-idh-hml-tls.key" \
--cacert "${CERT_DIR}/mcp-idh-hml-ca.crt" \
-H "gw-dev-app-key: ${APP_KEY}" \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-d '{
  "jsonrpc": "2.0",
  "method": "notifications/initialized"
}'
Copy
```
## 3. tools/list
Lista todas as ferramentas disponíveis no servidor MCP.

```bash
curl -N \
-X POST "${MCP_BASE_URL}" \
-b "${COOKIES}" -c "${COOKIES}" \
--cert   "${CERT_DIR}/mcp-idh-hml-tls.crt" \
--key    "${CERT_DIR}/mcp-idh-hml-tls.key" \
--cacert "${CERT_DIR}/mcp-idh-hml-ca.crt" \
-H "gw-dev-app-key: ${APP_KEY}" \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-d '{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/list"
}'
Copy
```
### Resultado real (HML) - tools disponíveis (12 ferramentas):

| Ferramenta | Descrição |
| --- | --- |
| ping | Verifica se o servidor responde. Retorna pong. |
| ola_mundo | Retorna uma saudação com o nome informado. |
| somar_numeros | Soma dois números inteiros. |
| ler_equipe_do_pdf | Lê um PDF e extrai a lista de integrantes da equipe. |
| sortear_pagante_almoco | Sorteia quem paga o almoço com pontuação aleatória. |
| sortear_com_protecao | Sorteia o pagante aplicando proteção a quem pagou recentemente. |
| excluir_ultimo_pagante | Remove da lista quem pagou na última rodada. |
| gerar_excel_resultado | Gera arquivo .xlsx com o resultado do sorteio. |
| gerar_pdf_equipe | Gera PDF estilizado com perfil e integrantes da equipe. |
| imprimir_resultado_sorteio | Lê o Excel do sorteio e imprime relatório visual no terminal. |
| registrar_historico | Persiste o resultado do sorteio em arquivo JSON de histórico. |
| formatar_aviso_teams | Formata mensagem pronta para colar no Teams ou Slack. |
## 4. tools/call
⚠️ Atenção: o passo initialize (seção 1) deve ter sido executado nesta sessão de terminal e o arquivo $COOKIES deve conter um cookie válido. Sem isso, o servidor não responde e o API Gateway retorna erro 9504 (timeout).

Invoca uma ferramenta específica com os argumentos requeridos pelo seu inputSchema. Substitua "nome-da-ferramenta" e "arguments" pelos valores retornados em tools/list.

```bash
curl -N \
-X POST "${MCP_BASE_URL}" \
-b "${COOKIES}" -c "${COOKIES}" \
--cert   "${CERT_DIR}/mcp-idh-hml-tls.crt" \
--key    "${CERT_DIR}/mcp-idh-hml-tls.key" \
--cacert "${CERT_DIR}/mcp-idh-hml-ca.crt" \
-H "gw-dev-app-key: ${APP_KEY}" \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-d '{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "nome-da-ferramenta",
    "arguments": {
      "parametro1": "valor1"
    }
  }
}'
Copy
```
### Exemplos por ferramenta (substitua o bloco -d no comando acima):

#### ping - sem argumentos:

```json
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"ping","arguments":{}}}
```
#### Resposta:

```text
event: message
data: {"jsonrpc":"2.0","id":3,"result":{"content":[{"type":"text","text":"pong"}],"isError":false}}
```
#### ola_mundo:

```json
{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"ola_mundo","arguments":{"nome":"Equipe DIA"}}}
```
#### Resposta:

```text
event: message
data: {"jsonrpc":"2.0","id":4,"result":{"content":[{"type":"text","text":"Olá, Equipe DIA!"}],"isError":false}}
```
#### somar_numeros:

```json
{"jsonrpc":"2.0","id":5,"method":"tools/call","params":{"name":"somar_numeros","arguments":{"a":42,"b":58}}}
```
#### Resposta:

```text
event: message
data: {"jsonrpc":"2.0","id":5,"result":{"content":[{"type":"text","text":"100"}],"structuredContent":{"result":100},"isError":false}}
```
## 5. resources/list (opcional)
Lista os recursos estáticos ou dinâmicos expostos pelo servidor.

```bash
curl -v -N \
-X POST "${MCP_BASE_URL}" \
-b "${COOKIES}" -c "${COOKIES}" \
--cert   "${CERT_DIR}/mcp-idh-hml-tls.crt" \
--key    "${CERT_DIR}/mcp-idh-hml-tls.key" \
--cacert "${CERT_DIR}/mcp-idh-hml-ca.crt" \
-H "gw-dev-app-key: ${APP_KEY}" \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-w "\n\n--- HTTP %{http_code} ---\n" \
-d '{
  "jsonrpc": "2.0",
  "id": 6,
  "method": "resources/list"
}'
Copy
```
### Resultado real (HML):

```text
event: message
data: {"jsonrpc":"2.0","id":6,"result":{"resources":[{"name":"obter_info","uri":"exemplo://info","description":"Retorna informações básicas sobre o serviço de exemplo.","mimeType":"application/json"}]}}
```
## 6. prompts/list (opcional)
Lista os prompts pré-definidos disponíveis no servidor.

```bash
curl -v -N \
-X POST "${MCP_BASE_URL}" \
-b "${COOKIES}" -c "${COOKIES}" \
--cert   "${CERT_DIR}/mcp-idh-hml-tls.crt" \
--key    "${CERT_DIR}/mcp-idh-hml-tls.key" \
--cacert "${CERT_DIR}/mcp-idh-hml-ca.crt" \
-H "gw-dev-app-key: ${APP_KEY}" \
-H "Content-Type: application/json" \
-H "Accept: application/json, text/event-stream" \
-w "\n\n--- HTTP %{http_code} ---\n" \
-d '{
  "jsonrpc": "2.0",
  "id": 7,
  "method": "prompts/list"
}'
Copy
```
### Resultado real (HML):

```text
event: message
data: {"jsonrpc":"2.0","id":7,"result":{"prompts":[{"name":"saudar","description":"Gera um prompt de saudação personalizado.","arguments":[{"name":"nome","required":true}]}]}}
```
## Referência de flags curl
Consulte na tabela a seguir o propósito de cada flag utilizada nos comandos deste guia:

| Flag | Propósito |
| --- | --- |
| -N | Desativa o buffer de saída - essencial para leitura de SSE em tempo real |
| -v | Exibe handshake TLS, headers enviados e recebidos |
| --cert / --key | Certificado e chave do cliente para autenticação mTLS |
| --cacert | Valida o certificado do servidor contra a CA interna do BB |
| -H "gw-dev-app-key" | Chave de acesso obrigatória exigida pelo API Gateway |
| -c "$COOKIES" | Salva cookies de sessão retornados pelo servidor |
| -b "$COOKIES" | Reenvia os cookies de sessão nas chamadas subsequentes |
| -w "..." | Instrumentação inline: código HTTP e tempo de resposta |
## Certificados utilizados (HML)
Consulte na tabela a seguir o uso de cada arquivo de certificado:

| Arquivo | Uso |
| --- | --- |
| mcp-idh-hml-tls.crt | Certificado público do cliente (mTLS) |
| mcp-idh-hml-tls.key | Chave privada do cliente (mTLS) |
| mcp-idh-hml-ca.crt | Autoridade certificadora - valida o servidor |
Configure CERT_DIR com o caminho local onde os certificados estão armazenados.

## Formato de erro JSON-RPC 2.0
Quando o servidor retorna erro, o campo error substitui result:

```json
{
"jsonrpc": "2.0",
"id": 1,
"error": {
  "code": -32600,
  "message": "Invalid Request",
  "data": "..."
}
}
```
Consulte na tabela a seguir o significado de cada código:

| Código | Significado |
| --- | --- |
| -32700 | Parse error - JSON inválido |
| -32600 | Invalid Request - payload fora do schema JSON-RPC |
| -32601 | Method not found - método não suportado pelo servidor |
| -32602 | Invalid params - argumentos incorretos |
| -32603 | Internal error - falha interna no servidor MCP |
## Erros do API Gateway BB
Erros gerados pelo gateway antes de chegar ao servidor MCP:

```json
{
"detail": "O serviço subjacente não respondeu no tempo esperado",
"errorCode": "9504",
"bbMsg": { "categoria": "SISTEMA", "tipo": "ERRO" }
}
Copy
```
Consulte na tabela a seguir a causa provável de cada código:

| Código | Causa provável |
| --- | --- |
| 9504 | Timeout do gateway (504): sessão não inicializada (cookie inválido/ausente), flag -N ausente no curl, ou serviço MCP indisponível |
| 4401 / 401 | APP_KEY inválida ou não cadastrada no Catálogo de APIs |
| 4403 / 403 | Certificado mTLS não autorizado para o recurso |
## Próximos passos
- Confira o guia de cadastro e vinculação de API no Catálogo de APIs;
- ⚠️ Informação não disponível — inserir segundo link relevante (ex.: guia de resolução de problemas ou canal de suporte).
