# DICIONARIO GLOBAL DO PROJETO - `plg-agent-consult-fin`

> **Finalidade:** indice tecnico e arquitetural central do workspace.  
> **Workspace:** `C:\Users\manue\.0_PROG\UAN\1. CONSULT_FIN_V2`  
> **Baseline:** 10/09/2026  
> **Status do documento:** versao final do levantamento local  
> **Escopo:** codigo do agente, testes, build, deploy de homologacao, wiki e referencias operacionais.

Este arquivo responde principalmente a tres perguntas:

1. **Onde fica?** Localiza codigo, configuracao, teste ou documento por assunto.
2. **O que faz?** Resume a responsabilidade de cada arquivo relevante.
3. **Como se conecta?** Mostra os fluxos entre API, LangGraph, LLM, MCP, RAG, guardrails, telemetria e deploy.

O workspace e um snapshot sem metadados Git locais. Branch, commit e historico nao podem ser confirmados a partir desta copia.

---

## Sumario

1. [Como consultar este dicionario](#1-como-consultar-este-dicionario)
2. [Visao global](#2-visao-global)
3. [Indice por assunto](#3-indice-por-assunto)
4. [Estrutura do workspace](#4-estrutura-do-workspace)
5. [Catalogo do codigo-fonte](#5-catalogo-do-codigo-fonte)
6. [Catalogo de configuracao, build e CI](#6-catalogo-de-configuracao-build-e-ci)
7. [Catalogo de testes](#7-catalogo-de-testes)
8. [Catalogo de deploy](#8-catalogo-de-deploy)
9. [Catalogo documental](#9-catalogo-documental)
10. [Fluxos de execucao](#10-fluxos-de-execucao)
11. [Contratos HTTP](#11-contratos-http)
12. [Dicionario de configuracao](#12-dicionario-de-configuracao)
13. [Dependencias e acoplamentos](#13-dependencias-e-acoplamentos)
14. [Operacao local e verificacao](#14-operacao-local-e-verificacao)
15. [Estado tecnico consolidado](#15-estado-tecnico-consolidado)
16. [Indice de pendencias conhecidas](#16-indice-de-pendencias-conhecidas)
17. [Regras de manutencao deste indice](#17-regras-de-manutencao-deste-indice)

---

## 1. Como consultar este dicionario

### Ordem de confiabilidade

Quando houver divergencia, use esta precedencia:

1. Codigo executavel em `plg-agent-consult-fin-main/plg_agent_consult_fin/`.
2. Configuracao ativa em `agent_config.yaml`, `Dockerfile` e `deploy-.../values.yaml`.
3. Testes automatizados em `tests/`.
4. `README.md`, wiki e documentos operacionais.
5. Snapshots, exemplos, baseline anterior e especificacoes de sistemas externos.

### Convencoes

| Marcador | Significado |
|---|---|
| **Ativo** | Participa da execucao, build ou deploy atual. |
| **Suporte** | Teste, configuracao ou documentacao diretamente relacionada ao ativo. |
| **Referencia** | Material de consulta; nao e importado nem executado pelo agente. |
| **Historico** | Evidencia de estado anterior; pode estar desatualizada. |
| **Duplicado** | Copia local identica a outro conjunto de arquivos. |

---

## 2. Visao global

O `plg-agent-consult-fin` e um microsservico Python 3.11 que expoe uma API FastAPI e executa um agente ReAct em LangGraph. O agente usa um modelo corporativo via Gateway Outbound BB, descobre ferramentas em um servidor MCP e pode adicionar uma ferramenta RAG do Genera BB. Guardrails HTTP protegem entrada e saida; validadores internos registram sinais de qualidade e seguranca via OpenTelemetry.

### Componentes principais

| Camada | Tecnologia | Ponto inicial |
|---|---|---|
| API | FastAPI / Pydantic | `plg_agent_consult_fin/app.py` |
| Processo | Uvicorn | `plg_agent_consult_fin/__main__.py` |
| Orquestracao | LangGraph | `plg_agent_consult_fin/graph.py` |
| Modelo | LangChain `ChatOpenAI` | `llm/gateway_outbound.py` |
| Ferramentas | MCP `streamable_http` | `graph.py` + `agent_config.yaml` |
| Recuperacao | Genera BB RAG | `rag/rag_tool.py` |
| Seguranca HTTP | Middleware + regex + Genera Safe | `utils/guardrails_middleware.py` |
| Avaliacao | Validadores locais e LLM-as-a-Judge | `validators/` |
| Observabilidade | OpenTelemetry + Azure Monitor opcional | `utils/tracing.py` |
| Container | Imagem corporativa Python 3.11.6 | `Dockerfile` |
| Deploy | Helm / OpenShift / GitHub Actions | `deploy-plg-agent-consult-fin-cloud-homologacao/` |

### Numeros do snapshot

| Item | Quantidade |
|---|---:|
| Modulos Python de aplicacao | 23 |
| Linhas Python de aplicacao | 2.145 |
| Arquivos Python na arvore de testes | 18 |
| Linhas Python de testes | 1.676 |
| Funcoes de teste | 142 |
| Testes unitarios declarados | 141 |
| Testes de integracao reais | 0 |
| Placeholder de integracao | 1 |
| Paginas na wiki local | 6 |

---

## 3. Indice por assunto

| Quero encontrar... | Comece por | Consulte tambem |
|---|---|---|
| Inicializacao do servico | `plg_agent_consult_fin/__main__.py` | `Dockerfile`, `setup.py` |
| Rotas e schemas HTTP | `plg_agent_consult_fin/app.py` | `tests/unit/test_app.py` |
| Fluxo do agente | `plg_agent_consult_fin/graph.py` | `agent_config.yaml`, `tests/unit/test_graph.py` |
| Instrucoes do sistema | `agent_config.yaml` -> `instructions` | `graph.py` -> `llm_call` |
| Configuracao tipada | `plg_agent_consult_fin/config.py` | `tests/unit/test_config.py` |
| Gateway LLM e mTLS | `llm/gateway_outbound.py` | `.env.example`, `Dockerfile` |
| Troca ou registro de LLM | `llm/factory.py` | `llm/base.py` |
| Descoberta de tools MCP | `graph.py` -> `AgentFactory.create` | `agent_config.yaml` -> `mcp.servers` |
| MCP oficial Consultor PJ | `plg-agent-consult-fin.wiki/MCP-Server-Oficial-Consultor-PJ.md` | `Desenvolvimento-Local-com-MCP.md` |
| MCP + DB2 / metricas MPE | `plg-agent-consult-fin.wiki/Integracao-MCP-db2-Metricas-MPE.md` | `MCP-Server-Oficial-Consultor-PJ.md` |
| RAG no Genera BB | `rag/rag_tool.py` | `agent_config.yaml` -> `rag`, `ESTEIRA_GENERA/GENERA_Geral.md` |
| Guardrails de entrada e saida | `utils/guardrails_middleware.py` | `utils/filter_patterns.py` |
| Guardrail externo Genera Safe | `utils/genera_safe_guardrails.py` | `agent_config.yaml` -> `guardrails` |
| CPF, CNPJ e demais PII | `utils/filter_patterns.py` | `validators/pii_validator.py` |
| Toxicidade e aconselhamento | `validators/toxicity.py`, `validators/non_advice.py` | `validators/semantic_similarity.py` |
| Qualidade de tools e RAG | `validators/tool_correctness.py`, `validators/context_precision.py` | `graph.py` -> `ValidatingToolNode` |
| Traces e metricas OTel | `utils/tracing.py`, `validators/__init__.py` | `Dockerfile`, `values.yaml` |
| Variaveis de ambiente | `.env.example` | secao 12 deste arquivo |
| Dependencias Python | `requirements.txt` | `setup.py` |
| Testes | `tests/unit/` | secao 7 deste arquivo |
| Build e publicacao | `.github/workflows/ci.yaml` | `Jenkinsfile`, `aic.json` |
| Deploy em homologacao | `deploy-.../values.yaml` | `Chart.yaml`, `.github/workflows/cd.yaml` |
| Certificados de entrada e saida | `deploy-.../values.yaml` | `.env.example`, wiki `Home.md` |
| Historico de validacao em DES | `plg-agent-consult-fin.wiki/validacao-agente-des-e-jornada-mcp.md` | snapshots `ambiente_consult_fin/` |
| Ambiente WSL/Pengwin | `AMBIENTE_PENGWIN/guia-pengwin-wsl-corporativo.md` | `ambiente_pengwin.md` |
| Regras da esteira AgentOps | `ESTEIRA_AGENTS_OPS/AGENTSOPS_AGENTES_IA.md` | `AGENTSOPS_MCP.md` |
| Integracao geral com Genera | `ESTEIRA_GENERA/GENERA_Geral.md` | codigo em `rag/` e `utils/genera_safe_guardrails.py` |
| Riscos e inconsistencias | secao 16 deste arquivo | arquivos indicados em cada item |

---

## 4. Estrutura do workspace

```text
1. CONSULT_FIN_V2/
|-- MAPA_TECNICO_PROJETO.md
|-- plg-agent-consult-fin-main/
|   |-- plg_agent_consult_fin/       # aplicacao Python
|   |-- tests/                       # testes unitarios e placeholder de integracao
|   |-- ambiente_consult_fin/        # evidencias e referencias historicas
|   |-- .github/workflows/           # CI e preparacao do Copilot
|   |-- agent_config.yaml            # configuracao funcional do agente
|   |-- Dockerfile                   # imagem de runtime
|   |-- requirements.txt             # dependencias usadas no container
|   `-- setup.py                     # pacote Python e extras de desenvolvimento
|-- deploy-plg-agent-consult-fin-cloud-homologacao/
|   |-- Chart.yaml
|   |-- values.yaml
|   |-- .github/workflows/cd.yaml
|   `-- deploy-plg-agent-consult-fin-cloud-homologacao/  # copia duplicada
|-- plg-agent-consult-fin.wiki/      # memoria tecnica do produto e do MCP
|-- ESTEIRA_AGENTS_OPS/              # referencia corporativa de agentes e MCP
|-- ESTEIRA_GENERA/                  # referencia corporativa do Genera BB
`-- AMBIENTE_PENGWIN/                # referencia de ambiente WSL corporativo
```

Nao existe mais a antiga subpasta duplicada `plg-agent-consult-fin-main/plg-agent-consult-fin-main/`. A duplicacao remanescente esta apenas no repositorio de deploy.

---

## 5. Catalogo do codigo-fonte

Raiz: `plg-agent-consult-fin-main/plg_agent_consult_fin/`

### 5.1 Nucleo da aplicacao

| Arquivo | Papel | Usado por / conecta-se a |
|---|---|---|
| `__init__.py` | Define `__version__ = '0.1.1'`. | `setup.py` extrai daqui a versao do pacote. |
| `__main__.py` | Le argumentos de host, porta, workers e log level; configura logs; inicia Uvicorn. | Entry point do container, `python -m` e console script. |
| `app.py` | Cria a FastAPI, schemas Pydantic, lifespan e rotas `/chat`, `/metrics`, `/health/live`, `/health/ready`. | Chama `graph`; instala `GuardrailsMiddleware`; inicializa Azure Monitor. |
| `config.py` | Modela o YAML em dataclasses, localiza `agent_config.yaml` e mantem singleton thread-safe. | Consumido por praticamente todas as camadas. |
| `graph.py` | Descobre tools MCP, adiciona RAG, cria LLM, monta e compila o grafo ReAct, executa validadores. | Nucleo de orquestracao chamado por `app.py`. |

### 5.2 Provedores LLM

Diretorio: `plg_agent_consult_fin/llm/`

| Arquivo | Papel | Elementos centrais |
|---|---|---|
| `__init__.py` | Fachada publica do pacote. | Exporta `LLMProvider` e `LLMFactory`. |
| `base.py` | Contrato abstrato de provedores. | `LLMProvider.build(temperature, top_p)`. |
| `factory.py` | Registro e criacao de provedores por nome. | `LLMFactory.register`, `LLMFactory.create`; provedor ativo `gateway_outbound`. |
| `gateway_outbound.py` | Cria `ChatOpenAI` para o Gateway Outbound BB. | `_GatewayTransport` troca a rota por `/cambio-chat-completion`, inclui `api-version` e `x-application-key`, remove `Authorization` e configura mTLS. |

### 5.3 RAG

Diretorio: `plg_agent_consult_fin/rag/`

| Arquivo | Papel | Elementos centrais |
|---|---|---|
| `__init__.py` | Interface auxiliar de recuperacao direta. | Reexporta uma funcao `retrieve` sobre `_call_gateway`; nao e usada internamente. |
| `rag_tool.py` | Integra o Genera BB como tool LangChain. | `_call_gateway`, `build_rag_tool`; acao `recuperar-contexto`; retorno `retrieved_contexts`; politica fail-open com lista vazia. |

### 5.4 Guardrails e observabilidade

Diretorio: `plg_agent_consult_fin/utils/`

| Arquivo | Papel | Elementos centrais |
|---|---|---|
| `__init__.py` | Marca o pacote de utilitarios. | Sem logica ativa. |
| `filter_patterns.py` | Regras locais para injection, PII e vazamento de prompt. | Checksums CPF/CNPJ, `contains_pii`, `redact_pii`, `check_injection`, `check_output_blocklist`. |
| `genera_safe_guardrails.py` | Cliente assincrono do curador Genera Safe. | Acao `conversar`; usa `X-Client-Id`, `UOR` e `userIdentification`; falha em aberto. |
| `guardrails_middleware.py` | Intercepta somente `POST /chat` e protege entrada/saida. | Limite de tamanho, injection, PII, curador externo, blocklist, redacao e metricas OTel. |
| `tracing.py` | Adiciona exportador de traces do Azure Monitor quando configurado. | `configure_azure_monitor`, `get_tracer`, `get_meter`; metricas permanecem no pipeline OTLP. |

### 5.5 Validadores

Diretorio: `plg_agent_consult_fin/validators/`

| Arquivo | Papel | Tipo / acao declarada |
|---|---|---|
| `__init__.py` | Framework comum, spans e metricas. | `BaseValidator`, `ValidationResult`, `ValidatorAction`, `ValidatorPipeline`. |
| `semantic_similarity.py` | Similaridade fuzzy local com RapidFuzz. | Suporte a toxicidade e non-advice; sem chamada externa. |
| `toxicity.py` | Detecta ameaca, assedio, odio e automutilacao em PT-BR/EN. | Risco; threshold `0.5`; declara `BLOCK`. |
| `non_advice.py` | Detecta aconselhamento financeiro, juridico e medico direto. | Risco; threshold `0.5`; declara `BLOCK`. |
| `pii_validator.py` | Detecta e classifica PII, inclusive CPF/CNPJ com checksum. | Risco; threshold `0.01`; declara `BLOCK`. |
| `context_precision.py` | Avalia relevancia dos chunks RAG com LLM-as-a-Judge. | Qualidade; threshold `0.3`; `LOG_ONLY`. |
| `tool_correctness.py` | Avalia escolha, argumentos e resultado de tool com LLM-as-a-Judge. | Qualidade; threshold `0.5`; `LOG_ONLY`. |

Os cinco validadores sao instanciados em `graph.py`. Toxicidade, aconselhamento e PII rodam apos cada resposta textual do LLM; tool correctness roda apos cada `ToolMessage`; context precision roda somente para a tool cujo nome coincide com `rag.tool_name`.

---

## 6. Catalogo de configuracao, build e CI

Raiz: `plg-agent-consult-fin-main/`

| Arquivo | Classe | Funcao no projeto |
|---|---|---|
| `agent_config.yaml` | **Ativo** | Fonte declarativa de identidade, prompt, LLM, MCP, RAG, guardrail externo e metadados. |
| `.env.example` | **Suporte** | Inventario de variaveis para execucao local; nao e carregado automaticamente pelo codigo. |
| `requirements.txt` | **Ativo** | Dependencias instaladas no container pelo `uv`. |
| `setup.py` | **Ativo** | Metadados do pacote, dependencias de instalacao, extras e console script. |
| `Dockerfile` | **Ativo** | Constroi runtime Python 3.11.6, venv, instrumentacao OTel e comando de inicializacao. |
| `.github/workflows/ci.yaml` | **Ativo** | Build Python reutilizavel e autodeploy para desenvolvimento/homologacao. |
| `.github/workflows/copilot-setup-steps.yaml` | **Suporte** | Prepara ambiente automatizado de desenvolvimento/Copilot. |
| `Jenkinsfile` | **Ativo/legado** | Pipeline AIC Jenkins; build e publicacao ligados, testes e Sonar desligados. |
| `aic.json` | **Ativo** | Parametros da esteira AIC: Python 3.11, validacao estatica e publicacao. |
| `bbconfig.yaml` | **Ativo** | Referencias de arquitetura corporativa cloud e seguranca. |
| `pip.conf` | **Ativo** | Configuracao do indice Python corporativo. |
| `sonar-project.properties` | **Suporte** | Parametros do Sonar; a execucao esta desabilitada no Jenkinsfile atual. |
| `.flake8` | **Suporte** | Regras de lint. |
| `.dockerignore` | **Ativo** | Exclusoes do contexto de build Docker. |
| `.gitignore` | **Suporte** | Exclusoes esperadas para Git. |
| `create_release.sh` | **Suporte** | Automacao de criacao de release/tag conforme o template. |
| `README.md` | **Suporte** | Guia geral de arquitetura, execucao e configuracao; contem trechos que devem ser confrontados com o codigo. |
| `CHANGELOG.md` | **Historico** | Estrutura de changelog ainda centrada em `0.1.0-SNAPSHOT`. |
| `LICENSE` | **Referencia** | Termos de copyright/licenciamento. |
| `chamando_genera_endpoint_diretamente.md` | **Referencia** | Exemplo isolado de chamada direta ao Genera; nao participa do runtime. |

---

## 7. Catalogo de testes

Raiz: `plg-agent-consult-fin-main/tests/`

### 7.1 Indice da suite

| Arquivo | Testes | Escopo |
|---|---:|---|
| `conftest.py` | - | Inclui a raiz do projeto no `sys.path`. |
| `unit/test_app.py` | 13 | Rotas, schemas, erros, `session_id`, blocos de conteudo e contagem de tools. |
| `unit/test_config.py` | 15 | YAML, defaults, MCP/auth, RAG, guardrails e singleton. |
| `unit/test_context_precision.py` | 5 | Skip, chunks vazios, threshold, parse do judge e fail-open. |
| `unit/test_dummy.py` | 4 | Boilerplate do template; nao valida regra do produto. |
| `unit/test_filter_patterns.py` | 28 | Injection, PII, checksums CPF/CNPJ, redacao e blocklist. |
| `unit/test_gateway_outbound_provider.py` | 8 | Reescrita de URL, headers, API version, CA e certificados. |
| `unit/test_genera_safe_guardrails.py` | 12 | Ativacao, headers, respostas e falhas do curador externo. |
| `unit/test_graph.py` | 8 | Configuracao MCP, compilacao com/sem tools, RAG e singleton. |
| `unit/test_guardrails_middleware.py` | 17 | Bloqueios de entrada, curador, redacao e passagem de respostas. |
| `unit/test_llm_factory.py` | 4 | Registro, criacao, override e provedor desconhecido. |
| `unit/test_pii_validator_risk_scale.py` | 3 | Escala de risco e CPF invalido. |
| `unit/test_rag_tool.py` | 15 | Configuracao, payload, retorno, erros e metadados da tool. |
| `unit/test_semantic_validators.py` | 4 | Similaridade semantica de toxicidade e aconselhamento. |
| `unit/test_tool_correctness.py` | 5 | Skip, score, judge, recomendacao e fail-open. |
| `integration/test_dummy.py` | 1 | Placeholder do template; nao executa integracao real. |
| `unit/__init__.py`, `integration/__init__.py` | - | Marcadores de pacote. |

### 7.2 Leitura correta do status

- A existencia de 142 funcoes nao significa que a suite esteja aprovada.
- A sintaxe de todos os modulos e testes foi validada com `compileall` em 10/09/2026.
- O `pytest` nao foi executado nesta consolidacao porque o ambiente local nao possui `pytest` nem as dependencias do projeto instaladas.
- A integracao real Agent -> MCP -> DB2 e descrita na wiki, mas nao esta automatizada em `tests/integration/` deste repositorio.

---

## 8. Catalogo de deploy

Raiz: `deploy-plg-agent-consult-fin-cloud-homologacao/`

| Arquivo | Papel |
|---|---|
| `Chart.yaml` | Chart Helm `chart-agent-consult-fin` v`0.0.1`; depende de `dia-chart-agent`, `bbcert` e `idh-operator-chart`. |
| `values.yaml` | Valores ativos de homologacao: Service, Deployment, probes, recursos, ingress, certificados e integracoes opcionais. |
| `.github/workflows/cd.yaml` | Aciona workflow corporativo de deploy em branches `cloud/*` e variantes `cloud-d[2-9]/*`. |
| `README.md` | Orientacoes do repositorio de deploy. |
| `deploy-plg-agent-consult-fin-cloud-homologacao/` | **Duplicado:** contem copias SHA-256 identicas dos quatro arquivos acima. |

### 8.1 Valores operacionais atuais

| Item | Valor observado |
|---|---|
| Ambiente representado | Homologacao |
| Tag da imagem | `0.1.1` |
| Replicas | `1` |
| Service | `ClusterIP`, porta `80` -> `8080` |
| Liveness | `GET :8080/health/live` |
| Readiness | `GET :8080/health/ready` |
| Ingress interno | `agent-consultor-fin.plg.hm.bb.com.br` |
| TLS de entrada | Secret `plg-agent-consult-fin-tls` |
| mTLS de saida | Secret `idh-mtls` em `/app/certs` |
| CPU request / limit | `50m` / `3001m` |
| Memoria request / limit | `250Mi` / `375Mi` |
| HPA | Desabilitado |
| ServiceMonitor | Desabilitado |
| Curio | Desabilitado |
| Ingress externo | Desabilitado |

---

## 9. Catalogo documental

### 9.1 Wiki do projeto

Raiz: `plg-agent-consult-fin.wiki/`

| Arquivo | Use para |
|---|---|
| `Home.md` | Visao operacional do agente, deploy, mTLS, secrets e validacoes. |
| `Desenvolvimento-Local-com-MCP.md` | Subir harness MCP local, ajustar transporte, executar nativo/Docker e diagnosticar CNPJ vs. PII. |
| `MCP-Server-Oficial-Consultor-PJ.md` | Arquitetura Factory do MCP oficial, ferramentas PJ, validacao E2E e deploy nos clusters. |
| `Integracao-MCP-db2-Metricas-MPE.md` | Modelo de integracao DB2, repositories, DTOs, services, tools MPE, testes e checklist de nova tool. |
| `validacao-agente-des-e-jornada-mcp.md` | Linha do tempo de validacao do agente em DES e da jornada corporativa do MCP. |
| `Glossario-IA-Agentica-Consultor-PF-PJ.md` | Vocabulario de IA agentica, dominio financeiro e plataforma. |

Os documentos registram momentos diferentes da evolucao. Status de endpoint, aprovacao ou deploy deve ser confirmado no ambiente antes de uso operacional.

### 9.2 Referencias AgentOps, Genera e Pengwin

| Arquivo | Classe | Conteudo |
|---|---|---|
| `ESTEIRA_AGENTS_OPS/AGENTSOPS_AGENTES_IA.md` | **Referencia** | Oferta de agente, estrutura de projeto, desenvolvimento, RAG, catalogo de IA e autorizacoes. |
| `ESTEIRA_AGENTS_OPS/AGENTSOPS_MCP.md` | **Referencia** | Oferta e jornada corporativa de MCP Server. |
| `ESTEIRA_GENERA/GENERA_Geral.md` | **Referencia** | Gateway Genera, headers, payloads, RAG, indices, limites, erros, certificados, harness e Genera Safe. |
| `AMBIENTE_PENGWIN/ambiente_pengwin.md` | **Referencia** | Manual geral do Pengwin, WSL, CLI e ferramentas corporativas. |
| `AMBIENTE_PENGWIN/guia-pengwin-wsl-corporativo.md` | **Referencia** | Preparacao pratica do ambiente corporativo WSL/Pengwin. |

### 9.3 Evidencias e referencias locais

Raiz: `plg-agent-consult-fin-main/ambiente_consult_fin/`

| Arquivo | Classe | Conteudo |
|---|---|---|
| `BASELINE_V0_CONSULT_FIN.md` | **Historico** | Baseline anterior de engenharia reversa. |
| `resumo-workspace.md` | **Historico** | Resumo do workspace e infraestrutura observados. |
| `# ARGO 1.txt` a `# ARGO 4.txt` | **Historico** | Capturas de manifests/estado do ArgoCD. |
| `endpoint consult.txt` | **Referencia** | Material de endpoint do agente/consulta. |
| `endpoint MCP.txt` | **Referencia** | Material de endpoint do MCP. |
| `endpoint assessor.txt` | **Referencia externa** | OpenAPI de um servico de Assistente Financeiro; nao ha chamada a ele no codigo atual. |
| `Catalogo de IAs.txt` | **Referencia** | Registro auxiliar do catalogo corporativo. |

---

## 10. Fluxos de execucao

### 10.1 Inicializacao

```text
Docker/CLI
  -> python -m plg_agent_consult_fin
  -> __main__.py configura logging e Uvicorn
  -> importa app.py
  -> carrega agent_config.yaml via get_config()
  -> configura Azure Monitor, se houver connection string
  -> lifespan chama graph.compile()
  -> AgentFactory descobre tools MCP
  -> adiciona a tool RAG, se habilitada
  -> cria o LLM no Gateway Outbound
  -> compila o StateGraph
  -> readiness passa a responder "ready"
```

### 10.2 Requisicao de chat

```mermaid
sequenceDiagram
    actor Cliente
    participant M as GuardrailsMiddleware
    participant A as FastAPI app.py
    participant G as LangGraph graph.py
    participant L as Gateway Outbound LLM
    participant T as Tools MCP/RAG
    participant V as Validators/OTel

    Cliente->>M: POST /chat
    M->>M: tamanho, injection, PII, Genera Safe
    alt entrada bloqueada
        M-->>Cliente: HTTP 400 guardrail_violation
    else entrada aceita
        M->>A: request
        A->>G: ainvoke(messages)
        G->>L: system prompt + mensagens
        L-->>G: AIMessage
        G->>V: toxicity, non_advice, PII
        opt LLM solicitou tool
            G->>T: tools/call ou recuperar-contexto
            T-->>G: ToolMessage
            G->>V: tool_correctness e, para RAG, context_precision
            G->>L: mensagens + resultado da tool
            L-->>G: resposta final
        end
        G-->>A: estado final
        A-->>M: ChatResponse
        M->>M: blocklist e redacao de PII
        M-->>Cliente: HTTP 200 JSON
    end
```

### 10.3 Topologia LangGraph

Com ferramentas:

```text
START -> llm_call -> tools_condition -> tools -> llm_call -> ... -> END
```

Sem ferramentas:

```text
START -> llm_call -> END
```

### 10.4 Limites de estado

- `AgentState` contem apenas `messages`.
- Cada chamada HTTP cria um estado com um unico `HumanMessage` novo.
- `session_id` e devolvido ao cliente, mas nao indexa memoria, checkpoint ou historico.
- O historico existe apenas dentro dos ciclos de tools de uma mesma requisicao.

---

## 11. Contratos HTTP

### `POST /chat`

Entrada:

```json
{
  "message": "Pergunta do usuario",
  "session_id": "opcional"
}
```

Saida `200`:

```json
{
  "reply": "Resposta do agente",
  "session_id": "opcional",
  "tool_calls_made": 0
}
```

Erros relevantes:

| Status | Origem | Formato principal |
|---|---|---|
| `400` | Guardrail | `error`, `code`, `detail` |
| `422` | Pydantic/FastAPI | Erro de validacao do request |
| `500` | Execucao do grafo | `detail: "Erro interno do servidor."` |

### Endpoints operacionais

| Metodo e rota | Resposta | Observacao |
|---|---|---|
| `GET /health/live` | `{"status":"alive"}` | Apenas confirma processo vivo. |
| `GET /health/ready` | `{"status":"ready"}` ou `503` | Verifica config carregada e grafo compilado. |
| `GET /metrics` | JSON com uptime, requests e identidade | Nao e endpoint Prometheus text exposition. |
| `GET /docs` | Swagger UI | Habilitado no codigo FastAPI. |
| `GET /redoc` | ReDoc | Habilitado no codigo FastAPI. |

---

## 12. Dicionario de configuracao

### 12.1 `agent_config.yaml`

| Chave | Uso | Estado atual |
|---|---|---|
| `agent_id` | Identificador funcional e metrica `/metrics`. | `agent-001` |
| `agent_name` | Titulo da API, tracer e metrica. | `Azure LangGraph Agent` |
| `deployment` | Metadado de ambiente/plataforma. | `azure` |
| `instructions` | `SystemMessage` inserida antes do primeiro `llm_call`. | Assistente generico com uso de tools. |
| `agent_description` | Descricao OpenAPI. | LangGraph + MCP em Azure. |
| `temperature`, `top_p` | Parametros de amostragem do LLM. | `0.7`, `0.95` |
| `llm.provider` | Nome resolvido por `LLMFactory`. | `gateway_outbound` |
| `llm.gateway_outbound.*` | URL, modelo, API version e max tokens. | HML / GPT-4o corporativo / 4096 |
| `mcp.servers[]` | Servidores e transporte para descoberta de tools. | Um servidor interno, `streamable_http`, sem auth. |
| `rag.enabled` | Inclui a tool RAG no grafo. | `false` |
| `rag.*` | Gateway, identidade, timeout, quantidade e descricao da tool. | Estrutura presente, identidade vazia. |
| `guardrails.enabled` | Habilita consulta ao curador externo. | `false` |
| `guardrails.*` | Gateway, agente curador, identidade e timeout. | Estrutura presente, identidade vazia. |
| `metadata.*` | Owner, versao e data declarativa. | Versao `0.1.0`. |

### 12.2 Variaveis de ambiente

| Variavel | Obrigatoriedade | Consumidor | Finalidade |
|---|---|---|---|
| `GATEWAY_OUTBOUND_GW_APP_KEY` | Obrigatoria para criar o LLM | `llm/gateway_outbound.py` | Header `x-application-key`. |
| `KEY_STORE_CERT_PATH` | Necessaria para mTLS | `llm/gateway_outbound.py` | Certificado cliente. |
| `KEY_STORE_KEY_PATH` | Necessaria para mTLS | `llm/gateway_outbound.py` | Chave privada cliente. |
| `TRUST_STORE_CA_PATH` | Recomendada/esperada no cluster | `llm/gateway_outbound.py` | CA prioritaria do Gateway Outbound. |
| `REQUESTS_CA_BUNDLE` | Opcional | LLM, RAG e Genera Safe | CA alternativa e validacao de clientes HTTP. |
| `SSL_CERT_FILE` | Opcional | Bibliotecas que respeitam a variavel | Trust store geral; nao e lida diretamente pelo codigo. |
| `RAG_CLIENT_ID` | Obrigatoria se RAG ativo | `rag/rag_tool.py` | `X-Client-Id` no Genera. |
| `GUARDRAIL_EXTERNAL_CLIENT_ID` | Obrigatoria se curador ativo | `utils/genera_safe_guardrails.py` | `X-Client-Id` no Genera Safe. |
| `GUARDRAIL_MAX_INPUT_LEN` | Opcional | middleware | Default `4096`. |
| `GUARDRAIL_BLOCK_PII_INPUT` | Opcional | middleware | Default `true`. |
| `GUARDRAIL_REDACT_PII_OUTPUT` | Opcional | middleware | Default `true`. |
| `GUARDRAIL_SEMANTIC_ENABLED` | Opcional | toxicidade e non-advice | Default `true`. |
| `APPLICATION_INSIGHTS_CONNECTION_STRING` | Opcional | `graph.py`, `utils/tracing.py` | Traces para Azure Monitor e callback LangChain. |
| `OTEL_RECORD_CONTENT` | Opcional | `graph.py` | Default `true`; controla registro de conteudo no tracer Azure AI. |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | Operacional no cluster | auto-instrumentacao | Collector OTLP. |
| `OTEL_SERVICE_NAME` | Definida no Dockerfile | OpenTelemetry | Nome do servico OTel. |
| `SERVICE_NAME`, `DEPLOY_ENV` | Opcionais | middleware e validadores | Dimensoes extras de metricas. |
| `MCP token_env_var` | Condicional a auth bearer | `config.py`, `graph.py` | Header `Authorization: Bearer`. |

O codigo nao usa `python-dotenv`. Criar `.env` por si so nao exporta as variaveis para o processo; o shell, Docker `--env-file`, orquestrador ou secret manager precisa injeta-las.

### 12.3 Metricas emitidas

| Metrica | Origem | Significado |
|---|---|---|
| `guardrail.requests` | middleware | Requisicoes `/chat` avaliadas. |
| `guardrail.blocked` | middleware | Bloqueios registrados por regra/camada. |
| `guardrail.redactions` | middleware | Respostas com PII redigida. |
| `guardrail.latency_ms` | middleware | Latencia total do middleware. |
| `validator.invocations` | validadores | Total de avaliacoes. |
| `validator.passed` | validadores | Avaliacoes aprovadas. |
| `validator.failed` | validadores | Avaliacoes reprovadas/sinalizadas. |
| `validator.score` | validadores | Distribuicao dos scores. |
| `validator.latency_ms` | validadores | Latencia de cada avaliacao. |

---

## 13. Dependencias e acoplamentos

### 13.1 Mapa de modulos

```text
__main__.py
  `-> app.py
      |-> config.py
      |-> graph.py
      |   |-> config.py
      |   |-> llm/factory.py -> llm/gateway_outbound.py
      |   |-> rag/rag_tool.py
      |   `-> validators/*
      |-> utils/guardrails_middleware.py
      |   |-> utils/filter_patterns.py
      |   `-> utils/genera_safe_guardrails.py
      `-> utils/tracing.py
```

Nao foram encontradas importacoes circulares diretas. Os judges importam `LLMFactory` dentro de `_build_judge_llm`, evitando ciclo na carga dos modulos.

### 13.2 Sistemas externos

| Sistema | Protocolo | Codigo consumidor | Falha observada no desenho |
|---|---|---|---|
| Gateway Outbound BB | HTTPS + mTLS | `llm/gateway_outbound.py` | Falha impede criacao/uso do LLM. |
| MCP Server | `streamable_http` | `graph.py` | Startup continua sem tools. |
| Genera RAG | HTTPS JSON | `rag/rag_tool.py` | Retorna lista vazia. |
| Genera Safe | HTTPS JSON | `utils/genera_safe_guardrails.py` | Entrada e liberada. |
| OTLP Collector | gRPC/OTLP | auto-instrumentacao | Telemetria pode deixar de ser exportada. |
| Azure Application Insights | HTTPS | `utils/tracing.py`, callback do grafo | Recurso e ignorado quando nao configurado. |

---

## 14. Operacao local e verificacao

Execute a partir de `plg-agent-consult-fin-main/` com Python 3.11.

### Ambiente

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
```

Exporte no processo as variaveis obrigatorias do Gateway Outbound e dos certificados. Nao registre valores reais neste mapa, no `.env.example` ou em logs.

### Servico

```powershell
python -m plg_agent_consult_fin --host 0.0.0.0 --port 8080 --log-level info
```

### Smoke checks

```powershell
Invoke-RestMethod http://localhost:8080/health/live
Invoke-RestMethod http://localhost:8080/health/ready
Invoke-RestMethod http://localhost:8080/metrics
Invoke-RestMethod -Method Post -Uri http://localhost:8080/chat -ContentType 'application/json' -Body '{"message":"Quanto e 2 + 2?","session_id":"smoke-01"}'
```

### Testes

```powershell
python -m pytest
python -m pytest tests/unit -v
python -m pytest --cov=plg_agent_consult_fin --cov-report=term-missing
```

### Verificacao sem dependencias de runtime

```powershell
py -3.11 -m compileall -q plg_agent_consult_fin tests
```

---

## 15. Estado tecnico consolidado

### 15.1 Versoes declaradas

| Fonte | Versao |
|---|---|
| Pacote `plg_agent_consult_fin/__init__.py` | `0.1.1` |
| Tag da imagem em homologacao | `0.1.1` |
| `agent_config.yaml` -> `metadata.version` | `0.1.0` |
| `Chart.yaml` -> `appVersion` | `0.0.1` |
| `Chart.yaml` -> `version` | `0.0.1` |
| `CHANGELOG.md` | `0.1.0-SNAPSHOT` |

### 15.2 Funcionalidades ativas por default

| Capacidade | Estado default | Observacao |
|---|---|---|
| API e grafo | Ativos | Dependem da configuracao e da App Key para boot completo. |
| MCP | Configurado | Um endpoint interno de cluster, sem autenticacao. |
| RAG Genera | Desativado | Exige `rag.enabled`, identidade e `RAG_CLIENT_ID`. |
| Genera Safe | Desativado | Exige `guardrails.enabled` e client ID. |
| Bloqueio local de PII na entrada | Ativo | Default do ambiente, independente de `guardrails.enabled`. |
| Redacao local de PII na saida | Ativa | Default do ambiente. |
| Validadores internos | Ativos | Seus resultados sao telemetria; ver pendencia P1. |
| Azure Monitor | Opcional | Ativa com connection string. |
| OTLP no Helm | Configurado | Endpoint aponta para o node na porta 4317. |
| HPA / ServiceMonitor / Curio | Desativados | Conforme `values.yaml`. |

### 15.3 Validacoes realizadas nesta baseline

| Verificacao | Resultado |
|---|---|
| Inventario de arquivos visiveis e ocultos | Concluido |
| Leitura dos 23 modulos Python | Concluida |
| Conferencia de configuracao, CI e Helm | Concluida |
| Contagem da suite | 142 funcoes |
| Compilacao sintatica com Python | Aprovada |
| Comparacao da copia interna do deploy | 4 arquivos identicos por SHA-256 |
| Execucao de `pytest` | Nao executada; dependencias ausentes |
| Teste de rede, LLM, MCP, RAG ou cluster | Fora do escopo desta consolidacao local |

---

## 16. Indice de pendencias conhecidas

Esta secao serve como ponte entre o indice e o backlog. As constatacoes abaixo vieram da leitura estatica da baseline.

| ID | Prioridade | Tema | Local principal | Resumo |
|---|---|---|---|---|
| P1 | Alta | Acoes `BLOCK` nao aplicadas | `graph.py:173` | O grafo ignora o `ValidationResult` de toxicidade, non-advice e PII; eles sinalizam telemetria, mas nao interrompem nem substituem a resposta. |
| P2 | Alta | Prompts dos judges | `context_precision.py`, `tool_correctness.py` | Exemplos JSON usam chaves simples dentro de strings processadas por `.format()`, provocando erro antes da chamada; os testes substituem o prompt. |
| P3 | Alta | Judge sincrono vs. cliente assincrono | mesmos validators + `gateway_outbound.py` | Judges chamam `llm.invoke`, enquanto o transporte corporativo customizado foi fornecido apenas como `http_async_client`. |
| P4 | Alta | CNPJ bloqueado no dominio PJ | `guardrails_middleware.py`, `filter_patterns.py` | `GUARDRAIL_BLOCK_PII_INPUT=true` rejeita CNPJ no texto, embora ferramentas PJ possam precisar desse identificador. |
| P5 | Alta | MCP sem reconexao | `graph.py:209` | Se a descoberta falhar no startup, o singleton permanece compilado sem tools ate reinicio. |
| P6 | Media | Versoes divergentes | secao 15.1 | Pacote/imagem, metadata, chart e changelog nao representam uma unica versao. |
| P7 | Media | Dependencias divergentes | `requirements.txt`, `setup.py` | `rapidfuzz` existe apenas em requirements; limites de LangGraph diferem; `requests` existe apenas em setup. Instalacao como pacote pode diferir do container. |
| P8 | Media | Auth MCP `cert` incompleta | `config.py`, `graph.py` | Cert/key sao modelados, mas `_mcp_server_config` aplica apenas bearer token. |
| P9 | Media | `session_id` sem persistencia | `app.py` | O campo e apenas ecoado; nao ha memoria entre requisicoes. |
| P10 | Media | Politicas fail-open | `rag_tool.py`, `genera_safe_guardrails.py`, validators base | Falhas externas ou internas podem liberar trafego ou retornar score neutro/contexto vazio. Decisao deve ser consciente por ambiente. |
| P11 | Media | Cobertura de integracao | `tests/integration/test_dummy.py` | Nao ha teste automatizado real para Gateway, MCP, RAG, DB2 ou deploy. |
| P12 | Baixa | Metrica de bloqueio PII | `guardrails_middleware.py:120` | O retorno por PII nao chama `_record_block`, ao contrario das demais regras. |
| P13 | Baixa | Default RAG duplicado | `rag_tool.py` | A assinatura da tool fixa `total_context=5`; uma mudanca apenas em `agent_config.yaml` pode nao alterar o default exposto ao LLM. |
| P14 | Baixa | Codigo sem consumidor | `ValidatorPipeline`, `rag.retrieve`, `pii_validator.redact_pii` | APIs implementadas nao sao chamadas pelo runtime atual. |
| P15 | Baixa | Artefatos de template | testes dummy, changelog, `.env.example` | Permanecem placeholders como `{{ codebase_name }}` e referencias de versao antiga. |
| P16 | Baixa | Duplicacao do deploy | subpasta interna de `deploy-.../` | Quatro arquivos duplicados aumentam risco de editar a copia errada. |

---

## 17. Regras de manutencao deste indice

Atualize este arquivo quando ocorrer qualquer uma destas mudancas:

- criacao, remocao ou renomeacao de modulo, rota, tool, validator ou pagina de wiki;
- alteracao de `agent_config.yaml`, variavel de ambiente ou secret esperado;
- troca de endpoint, modelo, transporte MCP ou formato de payload Genera;
- mudanca de versao do pacote, imagem ou chart;
- alteracao de pipeline, branch de deploy, probe, ingress, volume ou recurso;
- inclusao de testes de integracao ou mudanca relevante na contagem da suite;
- resolucao ou descoberta de uma pendencia da secao 16.

Checklist de atualizacao:

1. Atualizar a data da baseline.
2. Conferir o indice por assunto.
3. Atualizar o catalogo do arquivo afetado.
4. Atualizar fluxo, contrato ou configuracao correspondente.
5. Sincronizar a matriz de versoes.
6. Executar ao menos `compileall`; executar `pytest` quando o ambiente estiver preparado.
7. Registrar o resultado real em `Estado tecnico consolidado`.

Este documento e o ponto de entrada do workspace. Ele localiza a fonte correta; o codigo e a configuracao ativa continuam sendo a autoridade final sobre o comportamento executavel.
