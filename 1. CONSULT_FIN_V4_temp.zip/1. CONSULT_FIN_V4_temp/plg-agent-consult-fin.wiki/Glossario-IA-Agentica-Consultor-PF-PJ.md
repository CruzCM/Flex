# Glossario Tecnico - IA Agentica - Consultor PF/PJ

Termos de arquitetura, ABB, IBM watsonx Orchestrate, ARI e esteira BB, extraidos das
ADRs, transcricoes e reunioes do projeto Agentes Consultores Financeiros PF e PJ.

| Campo | Valor |
|---|---|
| Responsavel | Juscelino Barbosa da Silva Neto |
| Area | UAN - Inteligencia Artificial e Analitica |
| Projeto | Agentes Consultores Financeiros PF e PJ |
| Total de termos | 117 |
| Atualizado em | 14/08/2026 |

> Esta pagina e um **material vivo**: complete e edite conforme o time evoluir. A
> categoria "Deploy, CI/CD & Infraestrutura (Esteira AgentOps)" reune termos do Hands On
> AgentOps de 14/08 e ainda tem o mapeamento de capacitacao pendente (ver observacao na
> secao correspondente).

---

## Sumario

### Categorias do Glossario

| Categoria | Qtd. de termos |
|---|---|
| [Conceitos de IA Agentica](#conceitos-de-ia-agentica) | 14 |
| [Protocolos e Interoperabilidade](#protocolos-e-interoperabilidade) | 7 |
| [IBM watsonx Orchestrate](#ibm-watsonx-orchestrate) | 11 |
| [ABB - Assistente Conversacional BB](#abb---assistente-conversacional-bb) | 6 |
| [Frameworks e Dev](#frameworks-e-dev) | 7 |
| [Esteira e Plataforma BB](#esteira-e-plataforma-bb) | 14 |
| [Deploy, CI/CD e Infraestrutura (Esteira AgentOps)](#deploy-cicd-e-infraestrutura-esteira-agentops) | 25 |
| [ARI e Consultor PF/PJ](#ari-e-consultor-pfpj) | 13 |
| [Governanca, Risco e Seguranca](#governanca-risco-e-seguranca) | 14 |
| [Siglas Organizacionais BB](#siglas-organizacionais-bb) | 6 |

### Outras secoes

- [Trilha de Capacitacao](#trilha-de-capacitacao)
- [Lacunas de Capacitacao Pendentes](#lacunas-de-capacitacao-pendentes)


---

## Conceitos de IA Agentica

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 1 | Agente (Agent) | Sistema baseado em LLM capaz de raciocinar, decidir e executar acoes de forma autonoma para cumprir um objetivo, usando ferramentas (tools), memoria e contexto. | - |
| 2 | Agente Informacional | Agente que responde perguntas consultando uma base de conhecimento de um tema (ex.: PIX, cartao, credito, seguranca). No ABB eram ~10-14 desses. | - |
| 3 | Agente Orquestrador / Supervisor | Agente central que recebe a solicitacao do cliente e roteia para o agente especialista mais apropriado conforme o tema. E o "cerebro" que coordena o sistema multiagente. | - |
| 4 | Agente Transacional | Agente que executa acoes/operacoes (ex.: conta, cartao, PIX), nao apenas informa. No ABB, 3 agentes transacionais na V4. | - |
| 5 | Agentes Especialistas / Colaboradores | Agentes focados em um dominio especifico (ex.: fatura, Minhas Financas, Open Finance) acionados pelo orquestrador. Cada um responde por um assunto. | - |
| 6 | Agentic Banking | Visao de banco onde multiplos agentes especializados trabalham juntos, evoluindo o atendimento para planejamento financeiro conversacional e proativo. | - |
| 7 | Base de Conhecimento | Repositorio de documentos/dados que fundamenta as respostas de um agente informacional. Na V5, foram centralizadas em uma unica base. | - |
| 8 | Contexto (dados + conversa) | Uso simultaneo de historico financeiro, perfil, produtos contratados e conversa atual para personalizar a resposta do agente. | - |
| 9 | Graph RAG | Variante do RAG que usa grafos semanticos e ontologias para enriquecer a busca de informacao e os guardrails do sistema. | [arxiv.org/abs/2404.16130](https://arxiv.org/abs/2404.16130) |
| 10 | Multimodalidade | Capacidade do agente de interagir por multiplos formatos: texto, voz e imagens/documentos (ex.: enviar foto de boleto). | - |
| 11 | RAG (Retrieval-Augmented Generation) | Tecnica em que o LLM consulta uma base externa (documentos, tabelas) para gerar respostas fundamentadas e atualizadas, reduzindo alucinacao. | - |
| 12 | Superagente / Agente Monolitico | Agente unico que concentra muitas responsabilidades. Desaconselhado por elevar latencia, consumo de tokens e alucinacao; prefere-se orquestrador + especialistas. | - |
| 13 | Tool (Ferramenta) / Tool Calling | Funcao ou servico externo (consulta a tabela, API, modelo) que o agente pode invocar. Cada iniciativa do BB e "plugada" ao orquestrador como uma tool. | - |
| 14 | Transacao Agentica | Evolucao do agente de informativo/recomendador para executor assistido de acoes (contratar, aplicar, resgatar), dentro de limites controlados. | - |

---

## Protocolos e Interoperabilidade

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 15 | A2A (Agent-to-Agent) | Protocolo de comunicacao entre agentes, permitindo troca de mensagens e delegacao de tarefas entre agentes distintos. | [Curso Alura](https://unibb.alura.com.br/course/protocolos-agentes-inteligentes) |
| 16 | AG-UI | Protocolo/camada que padroniza a interacao entre agentes e interfaces de usuario (front-end), conectando o backend agentico a experiencia do usuario. | [Curso Alura](https://unibb.alura.com.br/course/protocolos-agentes-inteligentes) |
| 17 | Agent Connect / Chat Completions API | Padroes abertos de integracao citados na ADR para conectar o ABB a ecossistemas externos, junto de MCP e A2A. | [ADR #470](https://fontes.intranet.bb.com.br/aqt/publico/comunidade/-/issues/470) |
| 18 | BFA (Backend for Agents) | Padrao de arquitetura de backend dedicado a servir agentes, expondo tools, memoria e orquestracao de forma organizada e escalavel. | [Curso Alura](https://unibb.alura.com.br/course/protocolos-agentes-inteligentes) |
| 19 | Chat Completion | Padrao de entrada/saida (formato de mensagem) que o agente deve seguir para integracao; no BB, a resposta e ajustada para simular streaming. | - |
| 20 | MCP (Model Context Protocol) | Protocolo aberto que padroniza como agentes/LLMs se conectam a fontes de dados e ferramentas externas, expondo contexto de forma interoperavel. Base do CCA da IBM. | [ADR #470](https://fontes.intranet.bb.com.br/aqt/publico/comunidade/-/issues/470) |
| 21 | Streaming / Stream Fake | Envio incremental da resposta. Como o Genera e a infra BB/IBM nao suportam streaming nativo, simula-se ("stream fake") para atender o padrao IBM. | - |

---

## IBM watsonx Orchestrate

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 22 | ADK (Agent Development Kit) | Kit de desenvolvimento da IBM para construir agentes no watsonx Orchestrate. | - |
| 23 | AI Foundry (Azure) | Equivalente da Microsoft ao Orchestrate para orquestracao de agentes. A esteira AgentOps busca ser agnostica a Orchestrate e AI Foundry. | - |
| 24 | Agente React | Estilo de agente "default" do Orchestrate baseado no padrao ReAct (raciocinio + acao em ciclos), diferente do fluxo deterministico do CCA. | - |
| 25 | Agente Rota de Fuga | Agente que trata casos fora do escopo/roteamento, garantindo uma saida controlada quando nenhum especialista atende a demanda. | - |
| 26 | CCA (Customer Care Agent) | Estilo de agente do Orchestrate voltado a atendimento, com fluxos mais deterministicos que reduzem chamadas ao LLM. Construido sobre MCP e ADK da IBM. | - |
| 27 | Go Runtime / Runtime V2 | Nova versao do runtime do Orchestrate sobre a qual a arquitetura V5 foi desenhada. Virada para producao as 8h37 de 12/08/2026. | - |
| 28 | Golden Dataset | Conjunto de dados de referencia usado para testes exaustivos de assertividade e validacao de guardrails da nova arquitetura. | - |
| 29 | Guardrail | Componente que analisa e barra inputs maliciosos antes de acionar o Supervisor; tambem impoe limites de comportamento e seguranca ao agente. | [Figma - Estrutura](https://www.figma.com/design/Qq5zTRkPfwVPz1b7sMTrBv/Estrutura?node-id=2399-9100) |
| 30 | IBM watsonx Orchestrate | Plataforma da IBM para construir, publicar e orquestrar agentes de IA. Solucao escolhida para o ABB no App 5.0; cobra por acionamento (nao por token). | [ADR #470](https://fontes.intranet.bb.com.br/aqt/publico/comunidade/-/issues/470) |
| 31 | Orchestrate V4 / V5 | Versoes da SOLUCAO do BB no Orchestrate (nao do produto). A V5 simplifica a arquitetura: de ~17-18 agentes para 3, com bases centralizadas. | [ADR #470](https://fontes.intranet.bb.com.br/aqt/publico/comunidade/-/issues/470) |
| 32 | Step Details | Recurso do Orchestrate para inspecionar os passos/decisoes do agente, util na curadoria e no diagnostico de respostas. | - |

---

## ABB - Assistente Conversacional BB

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 33 | ABB (Assistente Conversacional BB) | Assistente virtual do BB disponibilizado no App 5.0, construido em arquitetura multiagente no watsonx Orchestrate. Alvo da modernizacao da ADR #470. | [ADR #470](https://fontes.intranet.bb.com.br/aqt/publico/comunidade/-/issues/470) |
| 34 | App 5.0 / App BB 5.0 | Nova versao do aplicativo do BB onde o ABB e os agentes consultores sao disponibilizados ao cliente. Lancamento previsto para 24/08. | - |
| 35 | IBM Toolhandler / Unir Toolhandler | Componente que recebe a transacao de volta (via Satellite) e executa os endpoints disponibilizados, efetivando a operacao. | - |
| 36 | NEC AC (Assistente Cognitivo) | Camada/assistente cognitivo pela qual passa a mensagem no fluxo do adapter ate chegar ao NIA e ao Orchestrate. | - |
| 37 | NIA | Componente de enderecamento que direciona a chamada para a instancia de Orchestrate desejada (piloto/producao). | - |
| 38 | Plataforma de Assistentes Conversacionais BB | Estrutura/squad responsavel pelos assistentes que atendem clientes externos (WhatsApp e Assistente App), incluindo infraestrutura e jornadas. | - |

---

## Frameworks e Dev

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 39 | Curadoria / Agente Anotador | Processo (humano + agente) de validar e anotar respostas/categorizacoes para medir acuracia e controlar alucinacoes. MF atingiu 94% de precisao. | - |
| 40 | Engenharia de Prompt | Construcao e ajuste das instrucoes (prompt) que guiam o comportamento do agente; no ABB, o prompt era generico e a "descricao" fazia o roteamento. | - |
| 41 | FastMCP / Factory | Template base para criar servidores MCP na esteira BB, usando FastMCP e padrao factory, permitindo heranca e organizacao de tools. | - |
| 42 | GPT-4O | Modelo LLM atualmente provisionado na esteira de agentes do BB; outros modelos dependem de certificacao. | - |
| 43 | LLM (Large Language Model) | Modelo de linguagem de grande escala que sustenta os agentes. No BB, provisionado GPT-4O; testes com Gemini e outros. | - |
| 44 | LangChain | Framework para aplicacoes com LLMs: abstracoes para prompts, cadeias (chains), memoria, tools e integracao com dados. Facilita troca de LLM. | [python.langchain.com](https://python.langchain.com/) |
| 45 | LangGraph | Extensao do LangChain para orquestracao baseada em grafos de estado, com ciclos, ramificacoes e controle de estado dos agentes. | [langchain-ai.github.io/langgraph](https://langchain-ai.github.io/langgraph) |

---

## Esteira e Plataforma BB

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 46 | A2B2 | Plataforma/esteira corporativa que unifica projetos de IA e Analytics; pode evoluir para implementar ou substituir o Orchestrate. | - |
| 47 | AgentOps | Esteira/praticas de ops para implantar, monitorar, versionar e governar agentes em producao ("DevOps/MLOps" dos agentes). Meta: consumo agnostico de agentes. | - |
| 48 | Argo | Ferramenta de deploy (GitOps) presente no repositorio-template dos agentes/microservicos; monitorado via Tech BB Operator. | - |
| 49 | Catalogo de APIs | Cada microsservico do tipo agente deve estar sempre vinculado a uma API cadastrada no Catalogo de APIs. | - |
| 50 | Catalogo de Agentes | Registro onde cada agente especialista e descrito (capacidades, responsabilidades, exemplos) para o supervisor saber quando aciona-lo. | - |
| 51 | Gaia | Sistema de cadastro/governanca onde o agente criado e vinculado (via ID e nome) para acompanhamento e integracao entre sistemas. | - |
| 52 | Gateway (de IA) | Ponto de entrada que controla acesso, certificacao e permissoes das aplicacoes/agentes, evitando conflitos de uso. | - |
| 53 | Genera / Genera BB / Genera Safe | Plataforma interna de IA generativa do BB. Alguns agentes (ex.: educacao financeira) nasceram no Genera; ABB migra para Orchestrate. | - |
| 54 | Nexus | Ambiente/plataforma onde microservicos (ex.: ARI Funci) sao desenvolvidos e expostos via endpoint para consumo pelo superagente. | - |
| 55 | OAS (Orquestracao e Automacao de Servicos) | Plataforma da TechBB para criar e integrar servicos tecnologicos ao Menu de Servicos, com fluxo de aprovacoes. | [tech.bb.com.br/p/oas](https://tech.bb.com.br/p/oas/service/gerenciamento-solicitacoes/aprovacoes-pendentes) |
| 56 | Plata.IA | Chat conversacional do BB que integra assistentes de IA especializados (ex.: IN.GPT, IAgro) na Plataforma BB. | - |
| 57 | Satellite | Servico de borda ("edge") do banco que expoe o endpoint do agente e fornece a URL usada na integracao com a IBM. | - |
| 58 | Tech BB Operator | Operador para monitorar microsservicos dos agentes (ex.: status no Argo). | - |
| 59 | TechBB / IDP | Internal Developer Platform do BB (tech.bb.com.br) que centraliza autoatendimento para criar, testar e gerenciar aplicacoes, abstraindo a infra. | [tech.bb.com.br](https://tech.bb.com.br/) |

---

## Deploy, CI/CD e Infraestrutura (Esteira AgentOps)

> Categoria incorporada a partir do Hands On AgentOps de 14/08. O mapeamento de
> capacitacao ainda esta pendente para todos os termos desta secao (ver
> [Lacunas de Capacitacao Pendentes](#lacunas-de-capacitacao-pendentes)).

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 60 | Agitec (diretrizes) | Diretrizes de seguranca do BB; entre elas, a proibicao de inserir dados do banco diretamente no codigo do agente. | - |
| 61 | AppKey | Chave gerada apos a liberacao de consumo de uma API para uma aplicacao; validada pelo Gateway a cada requisicao (aprovacao manual). | - |
| 62 | ArgoCD | Ferramenta GitOps para acompanhar o estado dos pods e do deploy. Refina o termo "Argo" num contexto de monitoramento. | - |
| 63 | BB Cert / IDH | Certificados internos usados para comunicacao segura entre aplicacoes no ambiente BB. | - |
| 64 | CI/CD (Motor de Liberacao) | Pipeline de integracao/entrega continua que roda builds, testes e analises e, via "motor de liberacao", define a alcada de aprovacao por pontuacao. | - |
| 65 | Catalogo de Aplicacoes | Registro das aplicacoes provedoras; o agente deve ser vinculado a uma aplicacao ja cadastrada aqui para liberar consumo. | - |
| 66 | Catalogo de IA | Onde se cadastram agentes, APIs e modelos (nome, categoria, URLs dev/homolog/prod) e se consultam logs de consumo das APIs. | - |
| 67 | Certificacao de Modelo | Processo (burocratico) para habilitar um LLM nao certificado na esteira; responsabilidade do dono do projeto antes de usar o modelo. | - |
| 68 | Docker / Dockerfile | Empacotamento da aplicacao em conteiner. O Dockerfile define a imagem; recomenda-se rodar local (docker build/run) para simular producao. | - |
| 69 | Epic (liberacao de consumo) | Processo/roteiro para solicitar e liberar o consumo de uma API entre times, definindo como proceder e quem acionar. | - |
| 70 | Gateway Outbound | Ponto por onde se configura o modelo LLM (GPT-4, GPT-5, GPT-5 mini) a ser consumido, cadastrado no Catalogo de API do banco. | - |
| 71 | HPA (Horizontal Pod Autoscaler) | Recurso de escalabilidade horizontal do Kubernetes. O numero correto de replicas em producao e requisito para certificacoes internas. | - |
| 72 | Helm Charts | Pacotes que empacotam e configuram o deploy dos servicos no Kubernetes, com configuracoes obrigatorias do banco (ex.: ingress interno). | - |
| 73 | ITSM | Sistema de abertura/tratamento de incidentes. Acoes emergenciais (ex.: reiniciar pod em prod) exigem incidente + aprovacao do gestor. | - |
| 74 | Ingress interno | Configuracao de entrada obrigatoria no padrao BB para expor/rotear o servico internamente de forma segura. | - |
| 75 | Jinja / Jinx file | Arquivo de template de deploy (a ser documentado pelo time) usado na configuracao/geracao dos artefatos de publicacao. | - |
| 76 | Kubernetes / Pods | Orquestrador de conteineres do BB. Os pods (instancias) sao administrados por ambiente (dev/homolog/prod), separados entre si. | - |
| 77 | OpenShift | Plataforma onde se obtem variaveis de ambiente, secrets e certificados do agente. Cada ambiente possui certificados distintos (nao misturar). | - |
| 78 | OpenTelemetry / Azure Monitor | Instrumentacao e coleta de metricas/telemetria da aplicacao. Codigo de monitoramento a ser disponibilizado na semana seguinte. | - |
| 79 | Regex (guardrail de filtro) | Uso de expressoes regulares como guardrail para filtrar conteudos inadequados, com bloqueio automatico de mensagens improprias. | - |
| 80 | Secrets / .env | Gestao de credenciais e certificados (cert, key, CA) via arquivos .env e secrets no OpenShift, montados como volumes no container. | - |
| 81 | SonarQube / XRay | Ferramentas de analise de qualidade de codigo e de vulnerabilidades executadas no pipeline de CI/CD. | - |
| 82 | WSL / Pengwin (Pinguim) | Ambiente Linux sobre Windows (WSL, distro Pengwin/"Pinguim") recomendado para instalar dependencias e rodar os comandos do deploy. | [fontes.intranet.bb.com.br/dev/publico/pengwin](https://fontes.intranet.bb.com.br/dev/publico/pengwin/) |
| 83 | graph.py | Arquivo do template do agente que centraliza o raciocinio (logica) do agente. E o nucleo a ser customizado pelo desenvolvedor. | - |
| 84 | main / app / config (template) | Arquivos padrao do template do agente (alem do graph.py), alteraveis conforme a necessidade do projeto. Template minimalista e flexivel. | - |

---

## ARI e Consultor PF/PJ

> Categoria com mapeamento de capacitacao ainda pendente (ver
> [Lacunas de Capacitacao Pendentes](#lacunas-de-capacitacao-pendentes)).

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 85 | NIA | Componente/agente citado na assessoria de credito PJ, associado a transacao agentica de operacoes de credito. | - |
| 86 | ARI (Area de Recomendacoes Inteligentes) | Solucao de IA Generativa do BB (DEMPE) para desenvolvimento de empresas PJ/MPE, com atuacao conversacional e mais de 55 recomendacoes personalizadas. | - |
| 87 | ARI Cliente | Agente especialista PJ voltado ao cliente. Funcional, porem deve ser migrado para a nova arquitetura (AgentOps) para escalar como multiagente. | - |
| 88 | ARI Funci | Assistente de IA que apoia funcionarios no atendimento e geracao de negocios com clientes PJ. Desenvolvido em Nexus, consumido via endpoint. Em piloto. | - |
| 89 | Ari 2.0 | Nova arquitetura da ARI que transforma a solucao unica em ~5 microservicos, resolvendo acoplamento, manutencao dificil e onboarding demorado. | - |
| 90 | CRM 360 / Memoria CRM | Visao consolidada 360 graus do cliente que registra interacoes, preferencias e recomendacoes, criando memoria corporativa para aprendizado continuo. | - |
| 91 | Consultor Financeiro PF/PJ | Projeto de agentes consultores financeiros 24/7 no App 5.0, com contexto de dados/conversa, recomendacao proativa e transacao agentica. | - |
| 92 | Controller (ARI) | Componente da nova arquitetura da ARI que centraliza a orquestracao/controle dos agentes especialistas. | - |
| 93 | Copiloto do Gerente | Agente de IA (RAG) que resume ao gerente o "porque" tatico de um encarteiramento, publicando cards/alertas na Plataforma BB (via Kafka/RabbitMQ). | - |
| 94 | DEMPE | Ecossistema Integral de Inteligencia PJ MPE - guarda-chuva de iniciativas (inclui ARI e Encarteiramento PJ) onde os agentes serao integrados. | - |
| 95 | Encarteiramento PJ | Processo (e squad) que define a alocacao de clientes PJ a carteiras via IA/dados, gerando pesos, impedimentos e ranking financeiro. | - |
| 96 | Open Finance (Insights) | Uso de dados consentidos de outras IFs para ampliar contexto e recomendacoes. Requer habilitar consentimento do cliente. | - |
| 97 | Transbordo | Transferencia segura da conversa do agente para um atendente humano (ou agente mais especializado), preservando contexto e historico. | - |

---

## Governanca, Risco e Seguranca

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 98 | ADR #470 | ADR de Modernizacao do Assistente Conversacional BB (ABB): define migracao de NLP para LLM/agentes e escolha do watsonx Orchestrate. | [ADR #470](https://fontes.intranet.bb.com.br/aqt/publico/comunidade/-/issues/470) |
| 99 | ADR (Architecture Decision Record) | Registro de Decisao de Arquitetura: documenta uma decisao relevante, seu contexto, alternativas e consequencias. Ex.: ADR #470 (Modernizacao do ABB). | [ADR #470](https://fontes.intranet.bb.com.br/aqt/publico/comunidade/-/issues/470) |
| 100 | AS-IS / TO-BE | Representacao da situacao atual (AS-IS) versus a situacao futura desejada (TO-BE) em diagramas de arquitetura. | - |
| 101 | ASR (Architecturally Significant Requirement) | Requisito arquiteturalmente significativo: foca em aspectos nao funcionais (desempenho, seguranca, escalabilidade) que moldam a arquitetura. | - |
| 102 | Alucinacao | Resposta incorreta ou inventada pelo LLM. Mitigada com curadoria, guardrails e arquitetura de agentes especializados. | - |
| 103 | Divida Tecnica | Debito acumulado por escolhas de curto prazo; no ABB, a migracao pendente para AgentOps e divida tecnica reconhecida na ADR. | - |
| 104 | FinOps | Praticas de gestao e otimizacao de custos de nuvem/tecnologia; sensivel ao desenho da arquitetura de agentes (custo por acionamento/token). | - |
| 105 | MVP (Minimum Viable Product) | Produto minimo viavel: primeira versao funcional liberada a publico restrito para validar em ambiente real antes de escalar. | - |
| 106 | Observabilidade | Capacidade de monitorar/auditar o comportamento dos agentes (logs, metricas). Uma das Alavancas de TI do MAD. | - |
| 107 | Prompt Injection | Ataque em que o input manipula o agente para burlar instrucoes/guardrails. Exige red team e logs auditaveis. | - |
| 108 | Red Team | Equipe/atividade que testa o agente adversarialmente para encontrar falhas de seguranca (ex.: prompt injection). | - |
| 109 | SOPRO | Equipe responsavel pela governanca das solicitacoes de projetos de IA e Analytics e sua unificacao na Plataforma A2B2. | - |
| 110 | Suitability | Adequacao de produtos/recomendacoes ao perfil do cliente, exigencia regulatoria a ser respeitada pelos agentes. | - |
| 111 | Vendor Lock-in | Dependencia excessiva de um fornecedor (ex.: IBM) por falta de conhecimento interno, elevando custo e reduzindo autonomia sobre a arquitetura. | - |

---

## Siglas Organizacionais BB

| # | Termo | Definicao | Referencia |
|---|---|---|---|
| 112 | DEMPE (unidade) | Unidade ligada ao ecossistema PJ/MPE; dona da ARI e do Encarteiramento. | - |
| 113 | DINED / DIMEP / DIRIN / DIREC / UAR / DIRAF / USD | Diretorias/unidades intervenientes do projeto Consultores PF/PJ (Open Finance, cartoes, CRM, educacao financeira, recuperacao de credito etc.). | - |
| 114 | DITEC / GECAP | Diretoria de Tecnologia; GECAP sao gerencias (ex.: Gecap 10 = IA Generativa Avancada, dona da esteira AgentOps). | [humanograma.intranet.bb.com.br/uor/530652](https://humanograma.intranet.bb.com.br/uor/530652) |
| 115 | HU (Historia de Usuario) | Unidade de trabalho agil que descreve uma funcionalidade sob a otica do usuario; base das entregas nas sprints. | - |
| 116 | MAD (Movimento Aceleracao Digital) | Programa de modernizacao tecnologica do BB, do qual derivam as Alavancas de TI (Cloud, DevSecOps, Divida Tecnica, Observabilidade). | - |
| 117 | UAN | Unidade de Inteligencia Artificial e Analitica - area do Juscelino/Buiati, responsavel por dados e IA. | - |

---

## Trilha de Capacitacao

Mapeamento de "o que precisamos dominar" e a capacitacao principal recomendada para
cada termo, organizada por categoria. A prioridade segue a escala:

- **P0** - prioridade maxima, base indispensavel para atuar no projeto.
- **P1** - prioridade secundaria, complementar ou de aprofundamento.
- **Legado** - tecnologia em uso atual, sem capacitacao dedicada nova.

> Apenas os termos com mapeamento de capacitacao preenchido na planilha original
> aparecem nesta secao. Os demais estao listados em
> [Lacunas de Capacitacao Pendentes](#lacunas-de-capacitacao-pendentes).

### Conceitos de IA Agentica

| Termo | O que precisamos dominar | Capacitacao principal | Prioridade |
|---|---|---|---|
| Agente (Agent) | arquitetura de agente, reasoning, planning tools, reflection, autonomia | Agentic AI - DeepLearning.AI | P0 |
| Agente Informacional | RAG, grounding, busca, retrieval, knowledge base | Arquiteturas RAG com LLMs - Alura | P0 |
| Agente Orquestrador / Supervisor | routing, delegacao, supervisor-worker, estado, coordenacao | Protocolos e arquitetura para construcao de agentes - Alura | P0 |
| Agente Transacional | tool calling, APIs, execucao, seguranca, estado e acoes | Protocolos e arquitetura para construcao de agentes - Alura + aprofundamento em Tool Calling | P0 |
| Agentes Especialistas / Colaboradores | multi-agent, papeis, delegacao e colaboracao | LangGraph: Orquestrando agentes e multiagentes - Alura | P0 |
| Agentic Banking | aplicacao de agentes em jornadas bancarias / financeiras | Protocolos e arquitetura para construcao de agentes - Alura + curso Agentic AI Finance | P1 |
| Base de Conhecimento | ingestao, chunking, embeddings, vector DB, retrieval | Arquiteturas RAG com LLMs - Alura | P0 |
| Contexto (dados + conversa) | context engineering, memoria, historico, dados recuperados, estado | Context Engineering - Alura | P0 |
| Graph RAG | knowledge graphs + RAG + Cypher + retrieval em grafos | GraphRAG - Alura + Neo4j GraphAcademy | P1 |
| Multimodalidade | texto + imagem + audio + video + multimodal RAG | Building Multimodal Data Pipelines - DeepLearning.AI | P1 |
| RAG (Retrieval-Augmented Generation) | retrieval, embeddings, vector DB, chunking, reranking, avaliacao | Arquiteturas RAG com LLMs - Alura | P0 |
| Superagente / Agente Monolitico | single-agente vs multiagent, limites do monolito, decomposicao e supervisor | Protocolos e arquitetura para construcao de agentes - Alura | P0 |
| Tool (Ferramenta) / Tool Calling | funcao, schema, escolha de ferramenta, execucao e retorno ao LLM | Functions, Tools and Agents with LangChain - DeepLearning.AI | P0 |
| Transacao Agentica | agente executando acoes reais com autenticacao, autorizacao, guardrails e auditoria | Agentes de IA na AWS: memoria, seguranca e sistemas multiagentes - Alura + seguranca de agentes | P0 |

### Protocolos e Interoperabilidade

| Termo | O que precisamos dominar | Capacitacao principal | Prioridade |
|---|---|---|---|
| A2A (Agent-to-Agent) | descoberta, comunicacao, delegacao e interoperabilidade entre agentes | Protocolos e arquitetura para construcao de agentes - Alura + Laboratorio oficial A2A | P0/P1 |
| AG-UI | comunicacao agente e interface, streaming, eventos, estado e HITL | Protocolos e arquitetura para construcao de agentes - Alura | P1 |
| Agent Connect / Chat Completions API | integracao de agentes externos ao IBM watsonx Orchestrate | IBM watsonx Orchestrate: Business Automation in the Age of Agentic AI | P0 |
| BFA (Backend for Agents) | desacoplamento agente e APIs/servicos, backend especifico para agentes | Protocolos e arquitetura para construcao de agentes - Alura | P0/P1 |
| Chat Completion | mensagens, roles, contexto conversacional, API contract e tool calls | IBM watsonx Chat API + curso Coursera de OpenAI API | P0 |
| MCP (Model Context Protocol) | client/server, tools, resources, prompts, descoberta e integracao | MCP: Build Rich-Context AI Apps with Anthropic - DeepLearning.AI + Alura | P0 |
| Streaming / Stream Fake | SSE, eventos, deltas, resposta incremental, streaming real x simulado | Protocolos e arquitetura para construcao de agentes - Alura + IBM docs | P1 |

### IBM watsonx Orchestrate

| Termo | O que precisamos dominar | Capacitacao principal | Prioridade |
|---|---|---|---|
| ADK (Agent Development Kit) | agentes, tools, multiagentes, estado, callbacks, guardrails, eval e deploy | Google ADK: crie e orquestre agentes com Python - Alura + Google Skills | P0 |
| AI Foundry (Azure) | criacao, knowledge, tools, multiagent, deploy e evaluation no Azure | Develop AI Agents on Azure - Microsoft Learn | P1/P0 |
| Agente React | Reason -> Act -> Observe, tool use e raciocinio iterativo | IBM RAG and Agentic AI - Coursera + IBM ReAct Core | P0 |
| Agente Rota de Fuga | fallback, escalation, handoff, HITL, tratamento de erro | Building Safe and Reliable AI Agents - Coursera + IBM workflows | P0 |
| CCA (Customer Care Agent) | agente de atendimento, jornadas, ferramentas, handoff e resolucao ponta a ponta | watsonx Orchestrate + Customer Service Agents - IBM | P0 |
| Go Runtime / Runtime V2 | runtime agentico, workflows, concorrencia, retries, HITL, estado | Google ADK / ADK Go 2.0 - Conteudo oficial Google | P1 |
| Golden Dataset | ground truth, casos de teste, trajetorias esperadas e regressao | Evaluating, Governing, and Scaling AI Agents - Coursera + IBM Evaluation Framework | P0 |
| Guardrail | seguranca, politicas, input/output filtering, tool safety e red teaming | Engenharia de software na era da IA: seguranca de aplicacoes com agentes, MCPs e codigo gerado por IA - Alura + IBM red teaming | P0 |
| IBM watsonx Orchestrate | plataforma, ADK, agents, flows, tools, KB, eval, seguranca, deploy | watsonx Orchestrate: Business Automation in the Age of Agentic AI - IBM | P0 |
| Orchestrate V4 / V5 | evolucao arquitetural, compatibilidade, migracao, regressao e versionamento | Get started with watsonx Orchestrate - IBM + release notes/labs internos | P0 |
| Step Details | tracing, execucao passo a passo, debugging, tool calls e observabilidade | AgentOps with watsonx - IBM + Evaluating AI Agents - DeepLearning.AI | P0 |

### ABB - Assistente Conversacional BB

| Termo | O que precisamos dominar | Capacitacao principal | Prioridade |
|---|---|---|---|
| ABB (Assistente Conversacional BB) | arquitetura conversacional, contexto, canais, routing, acoes, integracoes | watsonx Assistant: Designing and Building an Advanced AI Assistant - IBM + Orchestrate | P0 |
| App 5.0 / App BB 5.0 | integracao mobile-conversacional, omnichannel, UX conversacional, APIs | Conversation Design for Chatbots & Voice Assistants - Coursera + formacao agentic | P1/P0 |
| IBM Toolhandler / Unir Toolhandler | execucao de tools, schemas, dispatch, autenticacao, erros, callbacks | IBM Orchestrate Tools / ADK + Functions, Tools and Agents - DeepLearning.AI | P0 |
| NEC AC (Assistente Cognitivo) | conversational AI/NLU, fluxo, conhecimento, actions, migracao para GenAI | watsonx Assistant: Build an AI Assistant - IBM | P1/P0 |
| NIA | arquitetura/plataforma interna de IA, integracao, governanca e servicos | capacitacao interna BB + microtrilha Orchestrate/Agentic | P0 |
| Plataforma de Assistentes Conversacionais BB | multiagentes, orquestrador, canais, contexto, execucao de jornadas | watsonx Orchestrate Learning Path - IBM + arquitetura de agentes | P0 |

### Frameworks e Dev

| Termo | O que precisamos dominar | Capacitacao principal | Prioridade |
|---|---|---|---|
| Curadoria / Agente Anotador | avaliacao, anotacao, rubricas, ground truth, LLM-as-a-Judge e HITL | Evaluating AI Agents - DeepLearning.AI + IBM Evaluation Framework | P0 |
| Engenharia de Prompt | instrucoes, few-shot, estrutura, contexto, decomposicao, avaliacao | Engenharia de Prompt - Alura | P0 |
| FastMCP / Factory | construcao de MCP servers/client, tools, resources, transports e factory pattern | Build AI Agents using MCP - IBM/Coursera | P0 |
| GPT-4O | modelos multimodais, model selection, API, structured output e function calling | - | Legado |
| LLM (Large Language Model) | transformers, tokens, contexto, inference, treinamento/fine-tuning, avaliacao | Generative AI with Large Language Models - DeepLearning.AI/AWS | P0 |
| LangChain | composicao de aplicacoes LLM, tools, RAG, agents, modelos e integracoes | LangChain: desenvolva agentes - Alura | P0 |
| LangGraph | agentes stateful, grafos, ciclos, routing, checkpoints, HITL e multiagentes | LangGraph: Orquestrando agentes e multiagentes - Alura | P0 |

### Esteira e Plataforma BB

| Termo | O que precisamos dominar | Capacitacao principal | Prioridade |
|---|---|---|---|
| A2B2 | plataforma corporativa de IA/Analytics do BB, servicos, padroes e ambientes | Capacitacao interna A2B2 + IBM Orchestrate + Microsoft Foundry | P0 |
| AgentOps | tracing, observabilidade, avaliacao, custo, latencia, versoes e regressao | AgentOps with watsonx - IBM | P0 |
| Argo | Kubernetes, GitOps, deployments/workflows, health, rollback e troubleshooting | CI/CD Pipelines with GitOps - Coursera | P1/P0 |
| Catalogo de APIs | API discovery, OpenAPI, versionamento, lifecycle, seguranca e governanca | Application Integration Essentials - IBM | P0 |
| Catalogo de Agentes | discovery, reutilizacao, publicacao, governanca, RBAC, lifecycle e colaboradores | watsonx Orchestrate Agent Catalog + Learning Path IBM | P0 |
| Gateway (de IA) | gateway de modelos / agentes, routing, autenticacao, politicas, fallback, rate limit, observabilidade | IBM Agentic Standards + API Connect | P0 |
| Genera / Genera BB / Genera Safe | GenAI corporativa, consumo seguro de modelos, governanca, seguranca | watsonx Technical Essentials + watsonx.governance Technical Essentials + treinamento interno | P0 |
| OAS (Orquestracao e Automacao de Servicos) | workflows, service orchestration, decisoes, integracoes e automacao deterministica | watsonx Orchestrate: Business Automation in the Age of Agentic AI - IBM + Automation Builder | P0 |

> Os termos Gaia, Nexus, Plata.IA, Satellite, Tech BB Operator e TechBB/IDP desta
> categoria ainda nao possuem capacitacao mapeada (ver secao de lacunas).

### Governanca, Risco e Seguranca

| Termo | O que precisamos dominar | Capacitacao principal | Prioridade |
|---|---|---|---|
| ADR (Architecture Decision Record) | decisao arquitetural, trade-offs, alternativas, consequencias e rastreabilidade | Decisoes arquiteturais: ADRs, trade-offs e governanca tecnica - Alura | P0 |
| AS-IS / TO-BE | diagnostico do estado atual, desenho futuro, BPMN e gap analysis | Gestao Agil: Gestao de Processos para Agilidade - Alura | P1/P0 |
| Alucinacao | causas, deteccao, grounding, avaliacao e mitigacao | Improving Accuracy of LLM Applications - DeepLearning.AI + curso especifico Coursera | P0 |
| Divida Tecnica | identificar, medir, priorizar e pagar divida sem travar entrega | Divida Tecnica: gestao estrategica entre velocidade e qualidade - Alura | P1/P0 |
| FinOps | custos cloud + tokens + modelos + agentes + custo por jornada / outcome | FinOps: gerenciando custos de cloud - Alura | P1/P0 |
| MVP (Minimum Viable Product) | hipotese, escopo minimo, experimentacao, metricas e evolucao | Gestao de produtos: fundamentos para product builders - Alura | P1 |
| Observabilidade | logs, metricas, traces, OpenTelemetry, alertas e troubleshooting | Observabilidade com OpenTelemetry e Grafana - Alura | P0 |
| Prompt Injection | direct / indirect injection, goal hijacking, tool misuse e mitigacao | Red Teaming LLM Applications - DeepLearning.AI | P0 |
| Red Team | adversarial testing, ataques a agentes, seguranca e regressao | Red Teaming LLM Applications - DeepLearning.AI | P0 |
| Vendor Lock-in | switching cost, portabilidade, padroes abertos, abstracao e exit strategy | Designing Hybrid and Multicloud Architectures - Coursera | P1 |

> Os termos ADR #470, ASR, SOPRO e Suitability desta categoria ainda nao possuem
> capacitacao mapeada (ver secao de lacunas).

---

## Lacunas de Capacitacao Pendentes

Os termos abaixo ainda **nao possuem** mapeamento de "o que precisamos dominar" nem
capacitacao principal definida na planilha de origem. Ficam registrados aqui para que
o time complete conforme a trilha evoluir.

| Categoria | Termos pendentes |
|---|---|
| Esteira e Plataforma BB | Gaia, Nexus, Plata.IA, Satellite, Tech BB Operator, TechBB / IDP |
| Deploy, CI/CD e Infraestrutura (Esteira AgentOps) | Todos os 25 termos da categoria (Agitec, AppKey, ArgoCD, BB Cert / IDH, CI/CD, Catalogo de Aplicacoes, Catalogo de IA, Certificacao de Modelo, Docker / Dockerfile, Epic, Gateway Outbound, HPA, Helm Charts, ITSM, Ingress interno, Jinja / Jinx file, Kubernetes / Pods, OpenShift, OpenTelemetry / Azure Monitor, Regex, Secrets / .env, SonarQube / XRay, WSL / Pengwin, graph.py, main / app / config) |
| ARI e Consultor PF/PJ | Todos os 13 termos da categoria (NIA, ARI, ARI Cliente, ARI Funci, Ari 2.0, CRM 360, Consultor Financeiro PF/PJ, Controller, Copiloto do Gerente, DEMPE, Encarteiramento PJ, Open Finance, Transbordo) |
| Governanca, Risco e Seguranca | ADR #470, ASR, SOPRO, Suitability |
| Siglas Organizacionais BB | Todos os 6 termos da categoria |

> Sugestao de proximo passo: priorizar o mapeamento das categorias "Deploy, CI/CD e
> Infraestrutura" e "ARI e Consultor PF/PJ", por serem as mais diretamente ligadas ao
> dia a dia de desenvolvimento e deploy do agente `plg_agent_consult_fin`.

---

## Manutencao desta Pagina

Esta pagina espelha o conteudo do arquivo `Glossario_IA_Agentica_Consultor_PF_PJ.xlsx`.
Ao atualizar a planilha original, replique as mudancas aqui para manter as duas fontes
sincronizadas, ou considere esta pagina da Wiki como a fonte unica de verdade daqui em
diante.

| Data | Versao | Descricao | Responsavel |
|---|---|---|---|
| 14/08/2026 | 1.0 | Criacao do glossario com 117 termos, a partir das ADRs, transcricoes e reunioes do projeto. | Juscelino Barbosa da Silva Neto |
