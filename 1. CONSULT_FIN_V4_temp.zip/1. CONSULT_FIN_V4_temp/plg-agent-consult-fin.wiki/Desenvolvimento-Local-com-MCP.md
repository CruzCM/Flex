# Desenvolvimento Local com Ferramentas MCP

Esta página descreve como desenvolver e testar as **ferramentas de dominio (tools MCP)**
do agente `plg_agent_consult_fin` de forma totalmente local, utilizando o **LLM real
provisionado pela esteira**, sem depender do deploy no cluster nem do mTLS de entrada
(Concierge para backend).

O objetivo e permitir que a equipe construa e valide capacidades do agente (tool-calling)
em paralelo, enquanto as frentes de infraestrutura de producao seguem seu curso.

---

## Sumario

- [Contexto e Motivacao](#contexto-e-motivacao)
- [Arquitetura da Solucao Local](#arquitetura-da-solucao-local)
- [Onde os Arquivos Ficam no Repositorio](#onde-os-arquivos-ficam-no-repositorio)
- [Pre-requisitos](#pre-requisitos)
- [Ponto Critico: Transporte MCP](#ponto-critico-transporte-mcp)
- [Passo a Passo - Execucao Nativa (WSL)](#passo-a-passo---execucao-nativa-wsl)
- [Passo a Passo - Execucao com Docker](#passo-a-passo---execucao-com-docker)
- [Achados de Arquitetura](#achados-de-arquitetura)
- [Troubleshooting](#troubleshooting)
- [Evolucao: Ligar a Base Real](#evolucao-ligar-a-base-real)

---

## Contexto e Motivacao

No boot padrao, o agente registra `Agente compilado com 0 ferramenta(s)`, pois nao ha
nenhum servidor MCP acessivel. Sem ferramentas, o agente opera apenas como um chat: ele
responde perguntas com o conhecimento do proprio modelo, mas nao consulta dados de dominio.

Para um consultor financeiro PJ, o valor esta justamente nas ferramentas (consultar
ranking, resumo de carteira, indicacao de encarteiramento). O **harness de desenvolvimento
MCP** preenche essa lacuna localmente.

Beneficio adicional: com uma tool ativa, o `ToolCorrectnessValidator` (ja existente no
projeto, em `graph.py`, via `ValidatingToolNode`) passa a ser exercitado no fluxo real,
emitindo os spans OpenTelemetry correspondentes. Sem ferramentas, esse validator nunca
e acionado.

> Importante: este harness e um artefato de **desenvolvimento**, mantido na pasta `dev/`
> do repositorio. Nao substitui o MCP Server de producao, que e uma oferta/template
> proprio do Banco do Brasil, com repositorio, pipeline e deploy dedicados.

---

## Arquitetura da Solucao Local

```
  +-------------------+        streamable_http        +-----------------------+
  |  Agente           |  -------------------------->  |  MCP Dev Harness      |
  |  plg_agent_...    |     get_tools() / invoke      |  (FastMCP, porta 9000)|
  |  (FastAPI+LangGraph)|  <--------------------------  |  tool de dominio PJ   |
  +---------+---------+                                +-----------------------+
            |
            | mTLS (idh-tls-hml)
            v
  +-------------------+
  |  Gateway Outbound |  <-- LLM real provisionado pela esteira
  |  (esteira BB)     |
  +-------------------+
```

O agente continua chamando o **LLM da esteira** normalmente (via mTLS). A unica adicao e
o canal MCP para a tool de dominio, servida localmente.

---

## Onde os Arquivos Ficam no Repositorio

O harness e o teste de integracao ficam versionados no repositorio, isolados do pacote
de runtime e do build da imagem Docker:

```
plg-agent-consult-fin/
├── dev/
│   └── mcp-harness/
│       ├── mcp_dev_harness.py         # servidor MCP local (FastMCP)
│       └── check_mcp_connection.py    # validador de conexao isolado
├── tests/
│   └── integration/
│       └── test_mcp_domain_tool.py    # teste opt-in (pula se o harness nao estiver rodando)
├── agent_config.yaml                  # entrada "local-mcp" ja aponta para o harness
├── .dockerignore                      # exclui dev/ da imagem
└── MANIFEST.in                        # exclui dev/ do empacotamento Python
```

A pasta `dev/` e propositalmente mantida fora do pacote instalavel e da imagem Docker
(ver `.dockerignore` e `MANIFEST.in`), para nao poluir o build nem a analise estatica
do runtime de producao.

---

## Pre-requisitos

- Ambiente local configurado conforme o `README.md` do projeto (Python 3.11, venv,
  `pip install -r requirements.txt` e `pip install -e .`).
- Arquivo `.env` funcional com a AppKey e os certificados mTLS (o mesmo que ja permite
  o `/chat` responder via LLM da esteira).
- Dependencias do harness:

```bash
pip install fastmcp langchain-mcp-adapters
```

---

## Ponto Critico: Transporte MCP

O metodo `graph._mcp_server_config` repassa o campo `transport.type` diretamente ao
`MultiServerMCPClient`, que aceita apenas os valores `streamable_http`, `sse` ou `stdio`.

O valor `http` (usado no template original do `agent_config.yaml`) **nao e reconhecido**
pelo cliente e faz o `get_tools()` falhar silenciosamente (o agente cai no `except` e
compila com 0 ferramentas).

Por esse motivo, a entrada `local-mcp` do `agent_config.yaml` ja foi corrigida para
declarar o transporte explicitamente como `streamable_http`:

```yaml
mcp:
  servers:
    - name: "local-mcp"
      description: "Servidor MCP local para desenvolvimento e testes"
      transport:
        type: "streamable_http"          # corrigido - "http" nao e reconhecido pelo client
        endpoint: "http://localhost:9000/mcp"
      authentication:
        type: "none"  # opcoes: none | bearer | cert
```

> Esta correcao de transporte e valida para qualquer servidor MCP local que a equipe
> venha a configurar, nao apenas para o harness de dominio PJ.

---

## Passo a Passo - Execucao Nativa (WSL)

### 1. Subir o harness

```bash
cd dev/mcp-harness
python mcp_dev_harness.py
# -> Iniciando MCP dev harness em http://0.0.0.0:9000/mcp (streamable_http)
```

Mantenha este terminal aberto.

### 2. Validar a conexao de forma isolada

Em outro terminal, a partir da raiz do repositorio:

```bash
python dev/mcp-harness/check_mcp_connection.py
```

Saida esperada:

```
OK - 1 tool(s) carregada(s):
  - consultar_ranking_pj : Consulta o ranking de desempenho financeiro de um cliente PJ (MPE).
```

Se falhar aqui, o problema e de transporte ou de URL. Resolva antes de prosseguir.

### 3. Confirmar o agent_config.yaml

A entrada `local-mcp` ja deve apontar para `http://localhost:9000/mcp` com
`type: "streamable_http"` (ver secao anterior). Nenhuma alteracao adicional e necessaria.

### 4. Subir o agente

```bash
set -a && source .env && set +a
python -m plg_agent_consult_fin
```

No boot, espere as linhas:

```
Ferramentas MCP carregadas (1): ['consultar_ranking_pj']
Agente compilado com 1 ferramenta(s)
```

### 5. Testar o tool-calling

```bash
curl -s -X POST http://localhost:8080/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Consulte o ranking do CNPJ 12.345.678/0001-95 e diga a carteira sugerida.","session_id":"dev-1"}' \
  | python3 -m json.tool
```

Resultado esperado: `tool_calls_made` igual a 1 e uma resposta com os campos reais da
tool (percentil, margem de contribuicao, carteira sugerida).

> Se a mensagem contiver um CNPJ e o guardrail de entrada bloquear com
> `pii_detected`, veja a secao [Achados de Arquitetura](#achados-de-arquitetura).

---

## Passo a Passo - Execucao com Docker

Ao rodar o agente dentro de um container, `localhost` passa a se referir ao proprio
container, e nao ao host WSL onde o harness esta. E necessario usar `host.docker.internal`.

### 1. Manter o harness rodando de forma nativa (WSL)

```bash
python dev/mcp-harness/mcp_dev_harness.py
```

### 2. Criar um agent_config.docker.yaml (nao versionado)

Copie o `agent_config.yaml` e ajuste apenas o endpoint da entrada `local-mcp`:

```yaml
mcp:
  servers:
    - name: "local-mcp"
      transport:
        type: "streamable_http"
        endpoint: "http://host.docker.internal:9000/mcp"
      authentication:
        type: "none"
```

Este arquivo esta listado no `.gitignore` do repositorio e nao deve ser versionado,
pois e especifico do ambiente Docker local de cada desenvolvedor.

### 3. Criar um .env.docker (nao versionado)

Copie o `.env` e ajuste os caminhos dos certificados para o mountpoint do container.
Atencao aos nomes reais dos arquivos (exemplo para o ambiente HML):

```
GATEWAY_OUTBOUND_GW_APP_KEY=<sua_app_key>
KEY_STORE_CERT_PATH=/app/certs/idh-tls-hml.crt
KEY_STORE_KEY_PATH=/app/certs/idh-tls-hml.key
TRUST_STORE_CA_PATH=/app/certs/idh-ca-hml.crt
```

Este arquivo tambem esta listado no `.gitignore`.

### 4. Executar o container

```bash
docker run --rm \
  --name plg-agent \
  --env-file .env.docker \
  --add-host=host.docker.internal:host-gateway \
  -v $(pwd)/certs-hml:/app/certs:ro \
  -v $(pwd)/agent_config.docker.yaml:/app/agent_config.yaml:ro \
  -p 8080:8080 \
  plg-agent:local
```

Pontos-chave:

- `--add-host=host.docker.internal:host-gateway` permite que o container alcance o host WSL.
- O volume do `agent_config.docker.yaml` sobrepoe o config sem necessidade de rebuild.
- O volume de certificados aponta para a pasta do ambiente correspondente (HML/DES).
- A pasta `dev/` nao e copiada para a imagem (ver `.dockerignore`); o harness continua
  rodando nativamente no host durante o desenvolvimento com Docker.

No boot, espere `Ferramentas MCP carregadas (1)` e `SSL config: cert=... (exists=True)`.

---

## Achados de Arquitetura

Estes pontos foram identificados durante a validacao e merecem discussao com a equipe.

### 1. Conflito entre CNPJ e guardrail de PII

O guardrail de entrada (`GuardrailsMiddleware`) trata o CNPJ como PII e bloqueia a
requisicao com `pii_detected` (HTTP 400). Contudo, a ferramenta de dominio PJ **precisa**
do CNPJ para operar.

- Em desenvolvimento local, o bloqueio pode ser desativado com a variavel de ambiente
  `GUARDRAIL_BLOCK_PII_INPUT=false`.
- Em homologacao e producao, o bloqueio deve permanecer ativo. Para viabilizar a tool de
  dominio, e recomendavel avaliar uma **excecao/allowlist para CNPJ de consulta
  autorizada**, ou o uso de um canal de parametros estruturados que nao passe pela
  deteccao de PII em texto livre.

### 2. Instrucoes do agente e uso efetivo da tool

Com o `instructions` generico (assistente prestativo), o LLM tende a responder de memoria,
inventando campos que nao existem na tool (por exemplo, "score de credito"). Para garantir
o uso da ferramenta, o `instructions` deve orientar explicitamente o tool-calling:

```yaml
instructions: |
  Voce e o Consultor Financeiro PJ do Banco do Brasil. Para qualquer pergunta sobre
  ranking, carteira, margem de contribuicao, segmento ou desempenho de um cliente PJ,
  voce DEVE chamar a ferramenta 'consultar_ranking_pj' com o CNPJ informado e responder
  apenas com os dados retornados por ela. Nunca invente campos.
```

O contraste e didatico: sem a tool, o modelo estima; com a tool, a resposta e concreta
e rastreavel.

---

## Troubleshooting

| Sintoma | Causa provavel | Acao |
|---|---|---|
| Boot: `0 ferramenta(s)` | `transport.type` como `http` | Confirmar `streamable_http` em `agent_config.yaml` |
| `check_mcp_connection.py` falha | Harness nao esta rodando | Subir `python dev/mcp-harness/mcp_dev_harness.py` |
| Docker: `0 ferramenta(s)` | Container nao alcanca o host | Usar `host.docker.internal` + `--add-host` |
| `SSL config ... exists=False` | Nome/caminho de cert incorreto | Conferir nomes reais (ex.: `idh-tls-hml.crt`) |
| `/chat` retorna `pii_detected` | Guardrail de PII bloqueando o CNPJ | `GUARDRAIL_BLOCK_PII_INPUT=false` (apenas dev) |
| `tool_calls_made: 0` | `instructions` generico | Reforcar o tool-calling no `instructions` |

---

## Evolucao: Ligar a Base Real

Toda a logica sintetica esta isolada na funcao `_backend_ranking_pj`, dentro de
`dev/mcp-harness/mcp_dev_harness.py`. Para ligar a tool a base real, substitua apenas o
corpo dessa funcao pela consulta correspondente (DB2/Hive/Spark), mantendo o mesmo
formato de retorno. A assinatura da tool, o grafo do agente e os testes permanecem
inalterados.

Proximas ferramentas sugeridas para o backlog:

- `resumo_carteira(nome_carteira)` - metricas consolidadas por carteira.
- `indicar_carteira(cnpj)` - recomendacao de encarteiramento com verificacao de vagas.
- `indicar_local_nova_carteira(regiao)` - apoio a geolocalizacao de novas carteiras.
