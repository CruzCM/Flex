# MCP Server Oficial - Consultor PJ (plg-mcp-consult-fin)

Registro tecnico da implementacao, validacao local e deploy do primeiro MCP Server
oficial do time, aprovado pela oferta corporativa de IA do BB. Documenta o servico de
dominio `ServiceRankingPJ`, a validacao end-to-end com o agente `plg-agent-consult-fin`,
e a jornada de deploy em desenvolvimento e homologacao, incluindo os problemas
encontrados e as evidencias de resolucao.

---

## Sumario

- [Contexto](#contexto)
- [Repositorios Envolvidos](#repositorios-envolvidos)
- [Arquitetura do MCP Server (Factory Pattern)](#arquitetura-do-mcp-server-factory-pattern)
- [ServiceRankingPJ - Implementacao](#servicerankingpj---implementacao)
- [Validacao Local - Testes Unitarios](#validacao-local---testes-unitarios)
- [Validacao End-to-End - Agente + MCP + LLM Real](#validacao-end-to-end---agente--mcp--llm-real)
- [Jornada de Deploy](#jornada-de-deploy)
  - [Problema 1: Ativacao do Service](#problema-1-ativacao-do-service)
  - [Problema 2: Versao do Python no aic.json](#problema-2-versao-do-python-no-aicjson)
  - [Problema 3: Publicacao Bloqueada em Branch Auxiliar](#problema-3-publicacao-bloqueada-em-branch-auxiliar)
- [Evidencias de Deploy Bem-Sucedido](#evidencias-de-deploy-bem-sucedido)
- [Pendencia Externa: Certificado do Ingress Expirado](#pendencia-externa-certificado-do-ingress-expirado)
- [Licoes Aprendidas](#licoes-aprendidas)

---

## Contexto

O objetivo desta frente foi sair do harness de desenvolvimento local (ver pagina
[Desenvolvimento Local com MCP](Desenvolvimento-Local-com-MCP)) e implementar a mesma
capacidade de dominio - ranking financeiro e encarteiramento de clientes PJ - dentro do
**MCP Server oficial aprovado pela oferta corporativa do BB**, publicando-o de forma real
nos ambientes de desenvolvimento e homologacao.

O MCP Server oficial e uma oferta separada da oferta de Agente de IA, com repositorio,
template, pipeline e chart de deploy proprios, documentados na `Doc MCP Server` do
Tech BB.

---

## Repositorios Envolvidos

Assim como no agente, a oferta de MCP Server segue o padrao de dois repositorios
irmãos - um de codigo e um de deploy:

| Repositorio | Papel |
|---|---|
| `bbvinet/plg-mcp-consult-fin` | Codigo do MCP Server (FastMCP, Factory Pattern, testes) |
| `bbvinet/deploy-plg-mcp-consult-fin` | Helm chart e configuracao de deploy (branches `cloud/desenvolvimento`, `cloud/homologacao`, `cloud/producao`) |

---

## Arquitetura do MCP Server (Factory Pattern)

O template oficial de MCP Server Python difere do harness de desenvolvimento: em vez de
tools soltas registradas diretamente em um objeto `FastMCP`, o template adota um padrao
de fabrica (`MCPToolFactory` + `MCPToolBase`), no qual cada dominio de negocio vira um
"servico" isolado.

```
plg_mcp_consult_fin/
├── __main__.py              # Entry point: cria a app FastMCP, sobe na porta 8080
├── core/
│   ├── factory.py           # MCPToolFactory + MCPToolBase (classe abstrata)
│   └── tracing.py           # decorator @trace_tool (OpenTelemetry)
└── services/
    ├── service_exemplo.py   # servico de exemplo do template (3 tools + 1 resource + 1 prompt)
    └── service_ranking_pj.py  # servico de dominio PJ (adicionado nesta frente)
```

Cada servico implementa dois membros obrigatorios da classe abstrata `MCPToolBase`:

```python
class MCPToolBase(ABC):
    @abstractmethod
    def register_tools(self, mcp: FastMCP) -> None:
        """Registra as tools no servidor MCP."""

    @property
    @abstractmethod
    def tool_count(self) -> int:
        """Numero de tools deste servico."""
```

A fabrica (`MCPToolFactory`) registra todos os servicos e monta o servidor MCP unico:

```python
factory = MCPToolFactory()
factory.register_service(ServiceExemplo())
factory.register_service(ServiceRankingPJ())
mcp = factory.create_mcp_server(name="BBMCPServer")
```

O servidor sobe via transporte `streamable-http` em modo stateless, na porta 8080:

```python
app.run(transport="streamable-http", host=args.host, port=args.port, stateless_http=True)
```

---

## ServiceRankingPJ - Implementacao

O servico `ServiceRankingPJ` foi criado seguindo rigorosamente o padrao acima, migrando
a logica ja validada no harness de desenvolvimento local para o formato oficial do
template.

### Tools, resource e prompt expostos

| Tipo | Nome | Descricao |
|---|---|---|
| tool | `consultar_ranking_pj` | Ranking, percentil, margem de contribuicao, segmento comportamental e carteira sugerida para um CNPJ |
| tool | `resumo_carteira` | Metricas consolidadas de uma carteira PJ (total de clientes, margem total, vagas, distribuicao por segmento) |
| tool | `indicar_carteira` | Recomendacao de encarteiramento combinando ranking do cliente e disponibilidade de vagas |
| resource | `consultor-pj://carteiras` | Lista de carteiras PJ disponiveis |
| prompt | `analisar_cliente_pj` | Orienta o LLM a encadear as tools acima para uma analise completa de um CNPJ |

### Arquitetura interface-first (backend trocavel)

A logica de dados sintetica esta isolada em funcoes `_backend_*`
(`_backend_ranking_pj`, `_backend_resumo_carteira`), com dados deterministicos gerados
a partir de um hash do CNPJ/nome da carteira. Para ligar a base real (DB2/Hive/Spark),
basta substituir o corpo dessas funcoes, mantendo o formato de retorno - a assinatura
das tools, o registro na factory e os testes permanecem inalterados.

```python
def _backend_ranking_pj(cnpj_digits: str) -> RankingPJ:
    """STUB deterministico. Substituir pela query real mantendo o retorno.

    Exemplo de substituicao futura (pseudo):
        row = spark.sql(f"SELECT ranking, percentil, margem, segmento, carteira "
                        f"FROM tb_ranking_pj WHERE cnpj = '{cnpj_digits}'").first()
        return RankingPJ(cnpj=cnpj_digits, ranking=row.ranking, ...)
    """
```

---

## Validacao Local - Testes Unitarios

A suite de testes cobre a logica de dominio isoladamente e o registro das tools via um
`FakeMCP` (substituto minimo de `FastMCP` para capturar decorators sem depender do
servidor real), no mesmo espirito do `helpers.py` do template oficial.

Execucao local, com o `fastmcp` real instalado (versao 3.4.7):

```
$ pytest tests/unit/services/test_service_ranking_pj.py -v
...
tests/unit/services/test_service_ranking_pj.py::test_normaliza_cnpj_remove_mascara[...] PASSED
tests/unit/services/test_service_ranking_pj.py::test_valida_cnpj[...] PASSED
tests/unit/services/test_service_ranking_pj.py::test_backend_ranking_retorna_contrato_estavel PASSED
tests/unit/services/test_service_ranking_pj.py::test_backend_ranking_e_deterministico PASSED
tests/unit/services/test_service_ranking_pj.py::test_backend_resumo_carteira_estrutura PASSED
tests/unit/services/test_service_ranking_pj.py::test_register_tools_registra_tres_tools PASSED
tests/unit/services/test_service_ranking_pj.py::test_register_tools_registra_resource_e_prompt PASSED
tests/unit/services/test_service_ranking_pj.py::test_tool_consultar_ranking_pj_via_fake_mcp PASSED
tests/unit/services/test_service_ranking_pj.py::test_tool_consultar_ranking_pj_cnpj_invalido PASSED
tests/unit/services/test_service_ranking_pj.py::test_tool_resumo_carteira_inexistente PASSED
tests/unit/services/test_service_ranking_pj.py::test_tool_indicar_carteira_coerente_com_ranking PASSED
tests/unit/services/test_service_ranking_pj.py::test_resource_listar_carteiras PASSED
tests/unit/services/test_service_ranking_pj.py::test_prompt_analisar_cliente_pj_menciona_cnpj PASSED

18 passed in 1.20s
```

---

## Validacao End-to-End - Agente + MCP + LLM Real

Apos a suite unitaria, o MCP Server foi subido localmente e o agente
`plg_agent_consult_fin` foi apontado para ele via `agent_config.yaml`
(`transport.type: streamable_http`, `endpoint: http://localhost:8080/mcp`).

### Boot do agente - 6 ferramentas carregadas

```
INFO  plg_agent_consult_fin.graph: Ferramentas MCP carregadas (6):
      ['somar_numeros', 'ola_mundo', 'ping',
       'consultar_ranking_pj', 'resumo_carteira', 'indicar_carteira']
INFO  plg_agent_consult_fin.llm.gateway_outbound: SSL config: cert=./certs-des/idh-tls-des.crt
      (exists=True), key=./certs-des/idh-tls-des.key (exists=True), ca=./certs-des/idh-ca-des.crt
      (exists=True)
INFO  plg_agent_consult_fin.graph: Agente compilado com 6 ferramenta(s)
```

### Chamada real ao `/chat` do agente

Requisicao:

```json
{
  "message": "Consulte o ranking do CNPJ 12.345.678/0001-95 e diga a carteira sugerida.",
  "session_id": "teste-mcp-oficial"
}
```

Resposta do agente (LLM real da esteira BB, via Gateway Outbound, com mTLS valido):

```json
{
  "reply": "O CNPJ [CNPJ] possui as seguintes informacoes de ranking:\n\n- **Ranking**: 170.288\n- **Percentil**: 29.0%\n- **Margem de Contribuicao Estimada**: R$ 3.208,61\n- **Segmento Comportamental**: Media\n\n**Carteira Sugerida**: PJ-Empresarial-01\n**Justificativa**: A sugestao considera o percentil de desempenho financeiro, a margem de contribuicao estimada e o perfil comportamental \"Media\", que sao compativeis com a carteira \"PJ-Empresarial-01\".",
  "session_id": "teste-mcp-oficial",
  "tool_calls_made": 1
}
```

### O que esta resposta comprova

- `tool_calls_made: 1` - o LLM decidiu, de forma autonoma, invocar a tool
  `consultar_ranking_pj` a partir da pergunta em linguagem natural.
- Os valores (`170.288`, `29.0%`, `R$ 3.208,61`, `PJ-Empresarial-01`) sao identicos aos
  retornados por uma chamada direta `tools/call` ao MCP Server, confirmando que o dado
  nao foi alucinado pelo LLM.
- O CNPJ foi automaticamente redigido (`[CNPJ]`) pelo guardrail de saida de PII do
  agente (`PIIValidator` / `redact_pii`), demonstrando que a camada de guardrails
  continua ativa mesmo com o novo MCP conectado.

---

## Jornada de Deploy

O deploy do MCP Server seguiu o mesmo padrao Helm/ArgoCD ja utilizado pelo agente, mas
com particularidades proprias do chart `dia-chart-mcp` e da esteira de CI/CD em GitHub
Actions (diferente do Jenkins usado no agente). Tres problemas distintos precisaram ser
resolvidos, em sequencia, ate o deploy ficar saudavel nos dois ambientes.

### Problema 1: Ativacao do Service

Assim como no agente, o `values.yaml` do repositorio de deploy vem com
`service.enable: false` por padrao, exigindo ativacao manual antes da primeira execucao
(conforme o proprio README do template orienta).

**Correcao aplicada** (mesmo procedimento cirurgico usado no agente, por numero de
linha, para nao afetar outros toggles do arquivo):

```bash
# branch cloud/desenvolvimento
sed -i '5s/enable: false/enable: true/' values.yaml
git add values.yaml
git commit -m "chore(des): ativa service.enable para exposicao do container"
git push origin cloud/desenvolvimento

# branch cloud/homologacao (mesma operacao)
git checkout cloud/homologacao
sed -i '5s/enable: false/enable: true/' values.yaml
git add values.yaml
git commit -m "chore(hml): ativa service.enable para exposicao do container"
git push origin cloud/homologacao
```

Validacao pos-edicao (YAML valido, apenas a linha alvo alterada):

```
$ sed -n '1,10p' values.yaml
plg-mcp-consult-fin:
  projetoPiloto: false
  multEnv: false
  service:
    enable: true
    name: plg-mcp-consult-fin
    ...
$ grep -n "enable: false" values.yaml   # linha 5 nao aparece mais
16:    enable: false
124:      enable: false
$ python3 -c "import yaml; yaml.safe_load(open('values.yaml')); print('YAML ok')"
YAML ok
```

O push disparou automaticamente as pipelines de deploy (GitHub Actions) para os dois
ambientes, que chegaram ao estagio `deploy-ArgoCD` com sucesso (verde), sincronizando o
Service, Ingress, `bbcert`, `idhmtls` e RoleBindings - porem o **pod** ficou em
`ImagePullBackOff`, revelando o proximo problema.

---

### Problema 2: Versao do Python no aic.json

O evento do pod no ArgoCD apontava o erro real:

```
Failed to pull image "docker.binarios.intranet.bb.com.br/bb/plg/plg-mcp-consult-fin:0.0.1":
reading manifest 0.0.1 in docker.binarios.intranet.bb.com.br/bb/plg/plg-mcp-consult-fin:
manifest unknown: The named manifest is not known to the registry.
```

A imagem referenciada pelo deploy nunca havia sido publicada no Artifactory, porque o
pipeline de **build do codigo** (repositorio `plg-mcp-consult-fin`, nao o de deploy)
estava falhando. O log do job `build_python` mostrava a causa raiz:

```
Requirement already satisfied: pip in ./venv/lib/python3.8/site-packages (23.0.1)
...
INFO: pip is looking at multiple versions of mcp-server to determine which version
      is compatible with other requirements. This could take a while.
ERROR: Could not find a version that satisfies the requirement fastmcp==2.13.0 (from mcp-server)
ERROR: No matching distribution found for fastmcp==2.13.0
Error: Process completed with exit code 1.
```

O ambiente de CI estava rodando em **Python 3.8**, versao declarada no `aic.json` do
repositorio de codigo - mesmo padrao de configuracao ja conhecido da jornada do agente,
onde o mesmo arquivo precisou de ajuste identico.

```json
{
    "pipeline": {
      "versaoPython": "3.8",
      "publicarPacoteEImagem": false,
      "habilitarValidacaoEstatica": true,
      "habilitarValidacaoSeguranca": false,
      "pacoteSource": false
    }
}
```

Importante: **os builds anteriores ao trabalho nesta frente ja falhavam com o mesmo
erro** (commits automaticos do proprio template, como `AUTO - ADD template files` e
`chore: inclusao do workflow`), confirmando que a causa era estrutural do template
gerado, nao um problema introduzido pelo codigo desta iniciativa.

**Correcao aplicada:**

```bash
sed -i 's/"versaoPython": "3.8"/"versaoPython": "3.11"/' aic.json
git add aic.json
git commit -m "fix: corrige versaoPython para 3.11 no aic.json"
git push origin feat/plg-mcp-consult-fin-inicial
```

Apos a correcao, o pipeline de build passou em todos os estagios (`valida_workflow`,
`build_python`, `sonarQube`, `checkmarx`, `sincronizacao`, `Analise Motor Liberacao`).

---

### Problema 3: Publicacao Bloqueada em Branch Auxiliar

Mesmo com o build passando, o job `CD (desenvolvimento)` do workflow apareceu como
**nao executado** (`-`), e a imagem continuava ausente no registry. O log revelou a
causa:

```
##[warning]Versao fechada fora da branch main, sem opcao explicita de publicacao em
           branch auxiliar.
...
echo "Para publicar a versao, abra um Pull Request para a branch main."
...
imageid=docker-bb-local.binarios.intranet.bb.com.br/bb/plg/plg-mcp-consult-fin:0.0.1
```

A imagem chegou a ser **construida** no runner, mas o pipeline trata builds em branches
auxiliares (`feat/**`, `fix/**`, `feature/**`) como "versao fechada fora da main" e nao
publica o artefato oficialmente - condicao confirmada tambem na definicao do workflow:

```yaml
on:
  push:
    branches:
      - main
      - "fix/**"
      - "feat/**"
      - "feature/**"
```

Nota-se que `develop` **nao consta** na lista de branches que disparam o workflow -
portanto, mesmo o merge do Pull Request original (`feat/... -> develop`) nao seria
suficiente para destravar a publicacao.

**Correcao aplicada:** o Pull Request existente foi redirecionado para apontar
diretamente para `main`, e entao mergeado:

```bash
gh pr edit 1 --repo bbvinet/plg-mcp-consult-fin --base main
gh pr merge 1 --repo bbvinet/plg-mcp-consult-fin --merge
```

O push resultante na `main` disparou um novo build, que desta vez publicou a imagem
oficialmente e satisfez a condicao `autodeploy == 'true'` do workflow, liberando os jobs
`CD (desenvolvimento)` e `CD (homologacao)`.


---

## Evidencias de Deploy Bem-Sucedido

Apos a resolucao dos tres problemas acima, os dois ambientes foram validados de forma
independente, primeiro pelo ArgoCD e depois por chamadas diretas de dentro do proprio
pod, confirmando saude de ponta a ponta.

### ArgoCD - Desenvolvimento (`des-bb2-d1-plg-mcp-consult-fin`)

```
APP HEALTH:   Healthy
SYNC STATUS:  Synced
LAST SYNC:    Sync OK

pod: plg-mcp-consult-fin-regular-85c74d866-5hvlr
STATE:        Running
CONTAINER:    1/1
```

### ArgoCD - Homologacao (`hml-bb2-d1-plg-mcp-consult-fin`)

Mesmo resultado: `APP HEALTH: Healthy`, `SYNC STATUS: Synced`, pod em `Running`.

### Validacao via rede interna do cluster (`svc.cluster.local`)

Executado de dentro do proprio pod, validando o Service Kubernetes e o container
simultaneamente - **sem depender do Ingress externo**:

**Desenvolvimento:**

```
sh-5.2$ curl http://plg-mcp-consult-fin.plg-mcp-consult-fin.svc.cluster.local/health/live
OK
```

```
sh-5.2$ curl -s -X POST http://plg-mcp-consult-fin.plg-mcp-consult-fin.svc.cluster.local/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}'

event: message
data: {"jsonrpc":"2.0","id":1,"result":{"tools":[
  {"name":"somar_numeros", ...},
  {"name":"ola_mundo", ...},
  {"name":"ping", ...},
  {"name":"consultar_ranking_pj", ...},
  {"name":"resumo_carteira", ...},
  {"name":"indicar_carteira", ...}
]}}
```

**Homologacao:** o mesmo par de comandos, executado dentro do pod de homologacao,
retornou resultado identico - `health/live` respondendo `OK` e as mesmas 6 tools
listadas com schemas identicos aos de desenvolvimento, confirmando paridade total entre
os dois ambientes.

### Resumo consolidado

| Ambiente | Pipeline (build+CD) | ArgoCD | Pod | Health Check | Tools MCP |
|---|---|---|---|---|---|
| Desenvolvimento | Passou | Healthy / Synced | Running 1/1 | OK | 6 tools confirmadas |
| Homologacao | Passou | Healthy / Synced | Running | OK | 6 tools confirmadas |

---

## Pendencia Externa: Certificado do Ingress Expirado

Ao tentar validar o MCP Server pela rota **externa** (Ingress publico, em vez da rede
interna do cluster), a conexao TLS falhou:

```
$ curl -v https://mcp-consult-fin.plg.desenv.bb.com.br/health/live
...
* TLSv1.3 (OUT), TLS alert, certificate expired (557):
* SSL certificate problem: certificate has expired
```

Inspecao do certificado apresentado pelo servidor:

```
$ echo | openssl s_client -connect mcp-consult-fin.plg.desenv.bb.com.br:443 \
    -servername mcp-consult-fin.plg.desenv.bb.com.br 2>/dev/null \
    | openssl x509 -noout -dates -subject -issuer

subject=C = BR, O = BB, OU = Servidores, CN = ingress.nuvem.bb.com.br
issuer=C = BR, O = Banco do Brasil S.A., OU = ICP-BB, CN = AC Banco do Brasil - Servidores v3 DES
notBefore=May  6 02:00:00 2025 GMT
notAfter=May  6 01:59:59 2026 GMT
```

### Diagnostico

O `CN` do certificado (`ingress.nuvem.bb.com.br`) identifica-o como o **certificado
generico do Ingress Controller compartilhado** (`ingress-interno-iib`), e nao um
certificado especifico da aplicacao `plg-mcp-consult-fin`. A data de expiracao
(`06/05/2026`) ja havia sido ultrapassada no momento do teste, o que caracteriza uma
falha de **infraestrutura compartilhada**, afetando potencialmente todos os servicos
atras do mesmo Ingress Controller no ambiente de desenvolvimento - nao um problema
especifico deste deploy.

Como o acesso interno (`svc.cluster.local`) ja havia sido validado com sucesso antes
deste teste, esta pendencia **nao invalida** a conclusao de que o MCP Server esta
implantado e funcional; ela apenas bloqueia o acesso via rota externa ate a renovacao
do certificado pelo time responsavel pela plataforma de Ingress.

### Encaminhamento sugerido

> Certificado do Ingress Controller expirado - `ingress-interno-iib` (ambiente
> desenvolvimento). Ao acessar `https://mcp-consult-fin.plg.desenv.bb.com.br`
> (MCP Server `plg-mcp-consult-fin`, deployado e saudavel no cluster - confirmado via
> `svc.cluster.local`), o TLS handshake falha com `certificate expired`
> (`CN=ingress.nuvem.bb.com.br`, `notAfter=May 6 2026`). Por se tratar do certificado
> do proprio Ingress Controller compartilhado, o problema deve afetar todos os servicos
> atras do mesmo Ingress no ambiente. Solicita-se a renovacao do certificado.

---

## Licoes Aprendidas

Os tres problemas desta jornada de deploy, embora resolvidos em sequencia, tem causas
independentes e vale destaca-las separadamente para acelerar o diagnostico em futuros
deploys de MCP Servers a partir do mesmo template:

1. **`service.enable` comeca desativado por padrao** no `values.yaml` gerado pelo
   template de deploy - e preciso ativa-lo manualmente antes do primeiro deploy, tanto
   em desenvolvimento quanto em homologacao (a producao segue outro fluxo, manual, por
   design).

2. **O `aic.json` do template de codigo referencia Python 3.8 por padrao**, mesmo
   quando o projeto (e suas dependencias, como o `fastmcp`) exige uma versao mais
   recente. Isso ja havia ocorrido de forma identica no template de Agente de IA - vale
   conferir esse arquivo logo na configuracao inicial de qualquer novo repositorio
   criado a partir dos templates AIC.

3. **Builds em branches auxiliares (`feat/**`, `fix/**`) nunca publicam artefatos**
   nesta esteira - apenas pushes na branch `main` publicam pacote e imagem Docker e
   liberam o autodeploy. A branch `develop` sequer dispara o workflow de CI. Ao abrir um
   Pull Request para incorporar uma nova funcionalidade que precise ser deployada, e
   necessario garantir que o destino final do merge seja a `main`, nao apenas uma branch
   intermediaria.

4. **A validacao via rede interna do cluster (`svc.cluster.local`) e independente do
   Ingress externo** e deve ser o primeiro teste de saude de um deploy, antes de
   depender de certificados e rotas publicas que envolvem infraestrutura compartilhada
   fora do controle do time do projeto.
