# Integração MCP com DB2 para Métricas Consolidadas MPE

## 1. Objetivo

Este documento registra o passo a passo técnico utilizado para disponibilizar dados consolidados de margem e visitas MPE como tools MCP, permitindo que o agente `plg-agent-consult-fin` consulte informações reais no DB2 por meio do MCP Server `plg-mcp-consult-fin`.

Capacidades disponibilizadas:

- `consultar_margem_mpe`
- `consultar_visitas_mpe`

Fluxo validado:

```text
Usuário
  |
  v
Agente plg-agent-consult-fin
  |
  | LangGraph + GPT-4o via Gateway Outbound HML
  v
Tool calling
  |
  v
MCP Server plg-mcp-consult-fin
  |
  | streamable HTTP
  v
ServiceConsolidadosMPE
  |
  v
ConsolidadosMPERepository
  |
  v
DB2Backend
  |
  v
Gateway DB2 corporativo
  |
  v
BDB2P04
  |
  +-- TB_CNSLD_MARGEM_MPE
  +-- TB_CNSLD_VISITAS_MPE
```

---

## 2. Escopo da implementação

A implementação contempla:

1. conectividade local com o DB2 por gateway corporativo;
2. autenticação via usuário DB2 configurado por variável de ambiente;
3. backend DB2 reutilizável com `ibm_db`;
4. repository específico para os consolidados MPE;
5. validação e normalização dos filtros;
6. conversão segura de tipos DB2 para JSON;
7. criação das tools MCP de margem e visitas;
8. carregamento das tools pelo agente;
9. tool calling pelo GPT-4o;
10. memória de curto prazo com checkpointer LangGraph;
11. validação ponta a ponta com dados reais;
12. preparação profissional da branch para publicação.

Fica fora deste escopo:

- escrita no DB2;
- SQL arbitrário gerado pelo usuário ou pelo LLM;
- persistência de memória após reinício do agente;
- definição do schema definitivo de produção;
- gestão ou distribuição de credenciais.

---

## 3. Repositórios envolvidos

### 3.1 MCP Server

```text
plg-mcp-consult-fin
```

Responsabilidades:

- conectar ao DB2;
- executar consultas controladas;
- mapear os resultados para objetos de domínio;
- expor as consultas como tools MCP.

### 3.2 Agente

```text
plg-agent-consult-fin
```

Responsabilidades:

- descobrir as tools do MCP;
- apresentar os schemas das tools ao LLM;
- permitir que o LLM selecione a tool e monte os argumentos;
- sintetizar uma resposta em linguagem natural;
- manter o contexto da conversa por `thread_id`.

---

## 4. Fontes de dados

## 4.1 Tabela de margem

```text
<SCHEMA_CONFIGURADO>.TB_CNSLD_MARGEM_MPE
```

Estrutura identificada no catálogo DB2:

```text
ANO_MES         CHAR(7)         NOT NULL
GRUPO           VARCHAR(20)     NOT NULL
TOTAL_MARGEM    DECIMAL(18,2)   NOT NULL
MEDIA_MARGEM    DECIMAL(18,6)   NOT NULL
NM_INICIATIVA   VARCHAR(100)    NOT NULL
ID_INICIATIVA   VARCHAR(20)     NOT NULL
DT_ATUALIZACAO  TIMESTAMP(6)    NOT NULL
```

Perfil observado durante a validação:

- `ANO_MES` no formato `AAAA-MM`;
- quatro grupos no período mais recente validado;
- valores de margem retornados pelo driver como strings com vírgula decimal;
- uma iniciativa identificada nos dados validados.

## 4.2 Tabela de visitas

```text
<SCHEMA_CONFIGURADO>.TB_CNSLD_VISITAS_MPE
```

Estrutura identificada no catálogo DB2:

```text
ANO_MES               CHAR(7)       NOT NULL
GRUPO                  VARCHAR(20)   NOT NULL
CLIENTES_ACUMULADOS    INTEGER       NOT NULL
TOTAL_CLIENTES         INTEGER       NOT NULL
PERCENTUAL_ACUMULADO   DECIMAL(8,4)  NOT NULL
NM_INICIATIVA          VARCHAR(100)  NOT NULL
ID_INICIATIVA          VARCHAR(20)   NOT NULL
DT_ATUALIZACAO         TIMESTAMP(6)  NOT NULL
```

Perfil observado durante a validação:

- `ANO_MES` no formato `AAAA-MM`;
- quatro grupos no período mais recente validado;
- percentual retornado pelo driver como string com vírgula decimal;
- nomenclaturas de grupos diferentes das utilizadas na tabela de margem.

> O schema não deve ficar fixo no código. Ele deve ser informado por `DB2_MPE_SCHEMA` no ambiente de execução.

---

## 5. Pré-requisitos

- Python 3.11 ou 3.12;
- virtual environment do projeto;
- acesso ao índice PyPI corporativo;
- rota de rede para o gateway DB2;
- usuário DB2 autorizado;
- permissão `SELECT` nas tabelas utilizadas;
- MCP Server configurado com transporte `streamable-http`;
- agente com `langchain-mcp-adapters` e LangGraph.

---

## 6. Descoberta do endpoint DB2 acessível

O primeiro endpoint testado foi o host direto da base. O DNS resolveu, mas a conexão TCP expirou. O diagnóstico mostrou que o WSL possuía rota para um gateway corporativo alternativo.

Teste genérico de DNS e porta:

```python
import socket
from time import perf_counter

host = "<HOST_DB2>"
port = <PORTA_DB2>

addresses = socket.getaddrinfo(
    host,
    port,
    type=socket.SOCK_STREAM,
)

ips = sorted({item[4][0] for item in addresses})
print(">> DNS:", ips)

started = perf_counter()

try:
    with socket.create_connection((host, port), timeout=8):
        elapsed_ms = (perf_counter() - started) * 1000
        print(f">> TCP: ABERTA ({elapsed_ms:.2f} ms)")
except socket.timeout:
    print(">> TCP: TIMEOUT")
except ConnectionRefusedError:
    print(">> TCP: RECUSADA")
except OSError as exc:
    print(f">> TCP: ERRO errno={exc.errno}, detalhe={exc}")
```

Endpoint utilizado na validação local:

```text
HOSTNAME=gwdb2.bb.com.br
PORT=50100
DATABASE=BDB2P04
PROTOCOL=TCPIP
```

O acesso direto ao host interno da base não foi utilizado no runtime local porque a porta testada apresentou timeout.

---

## 7. Instalação e alinhamento das dependências

## 7.1 Instalação do driver DB2

Para evitar instalação no Python global por aliases ou lazy loaders do shell, utilizar sempre o Python explícito da virtual environment:

```bash
./.venv/bin/python -m pip install ibm_db==3.3.0
```

Validar:

```bash
./.venv/bin/python -c \
  "import ibm_db; print('ibm_db OK', ibm_db.__version__)"
```

## 7.2 FastMCP

A versão inicial apresentou conflito com `py-key-value-aio`. A versão validada foi:

```text
fastmcp==2.13.3
mcp==1.22.0
py-key-value-aio==0.3.0
py-key-value-shared==0.3.0
```

Atualização:

```bash
./.venv/bin/python -m pip install --upgrade \
  "fastmcp==2.13.3"
```

Como o projeto estava instalado em modo editável, os metadados foram atualizados com:

```bash
./.venv/bin/python -m pip install -e . --no-deps
```

Validações:

```bash
./.venv/bin/python -m pip check
```

Resultado esperado:

```text
No broken requirements found.
```

Validação do módulo `filetree`:

```python
import importlib.util

spec = importlib.util.find_spec(
    "key_value.aio.stores.filetree"
)

print(spec is not None)
```

---

## 8. Configuração por variáveis de ambiente

Exemplo de `.env` local:

```dotenv
DB2_HOSTNAME=gwdb2.bb.com.br
DB2_PORT=50100
DB2_DATABASE=BDB2P04
DB2_PROTOCOL=TCPIP
DB2_UID=<USUARIO_DB2>
DB2_PWD=<SEGREDO_DB2>
DB2_MPE_SCHEMA=<SCHEMA_AUTORIZADO>
DB2_CURRENT_SCHEMA=
DB2_LOGIN_TIMEOUT_SECONDS=8
DB2_QUERY_TIMEOUT_SECONDS=30
```

Carregar no shell:

```bash
set -a
source .env
set +a
```

### Regras de segurança

Nunca versionar:

- `.env`;
- usuário e senha DB2;
- AppKeys;
- certificados e chaves privadas;
- schema pessoal como padrão no código;
- testes locais que dependam de credenciais reais.

Validar o ignore:

```bash
git check-ignore -v .env
```

O código pode utilizar os nomes das variáveis, mas nunca seus valores.

---

## 9. Teste isolado de autenticação DB2

Antes de consultar tabelas de negócio, validar somente a conexão:

```python
import os
from time import perf_counter

import ibm_db

parts = [
    f"DATABASE={os.environ['DB2_DATABASE']}",
    f"HOSTNAME={os.environ['DB2_HOSTNAME']}",
    f"PORT={os.environ['DB2_PORT']}",
    f"PROTOCOL={os.getenv('DB2_PROTOCOL', 'TCPIP')}",
    f"UID={os.environ['DB2_UID']}",
    f"PWD={os.environ['DB2_PWD']}",
    f"CONNECTTIMEOUT={os.getenv('DB2_LOGIN_TIMEOUT_SECONDS', '8')}",
]

conn_str = ";".join(parts) + ";"
conn = None

try:
    started = perf_counter()
    conn = ibm_db.connect(conn_str, "", "")
    elapsed_ms = (perf_counter() - started) * 1000

    server = ibm_db.server_info(conn)
    client = ibm_db.client_info(conn)

    print(f">> DB2 conectado: SIM ({elapsed_ms:.2f} ms)")
    print(">> DBMS_NAME:", server.DBMS_NAME)
    print(">> DBMS_VER:", server.DBMS_VER)
    print(">> DB_NAME:", server.DB_NAME)
    print(">> CLIENT_DRIVER:", client.DRIVER_NAME)
    print(">> CLIENT_VER:", client.DRIVER_VER)
finally:
    if conn is not None:
        ibm_db.close(conn)
```

---

## 10. Teste isolado de execução SQL

Validar `prepare`, `execute`, `fetch`, liberação do statement e fechamento da conexão antes de acessar as tabelas de negócio:

```sql
SELECT
    CURRENT SERVER AS SERVIDOR,
    SESSION_USER AS USUARIO,
    CURRENT SCHEMA AS ESQUEMA
FROM SYSIBM.SYSDUMMY1
```

> Na base validada, `SESSION_USER` foi aceito. A forma `CURRENT USER` apresentou erro de sintaxe nesse contexto.

Ciclo esperado:

```text
connect
  -> prepare
  -> execute
  -> fetch
  -> free_stmt
  -> close
```

---

## 11. Inspeção das tabelas pelo catálogo DB2

O catálogo `SYSCAT` não estava disponível no ambiente validado. A inspeção foi feita com `SYSIBM.SYSCOLUMNS`.

Consulta genérica:

```sql
SELECT
    C.TBCREATOR,
    C.TBNAME,
    C.COLNO,
    C.NAME AS COLNAME,
    C.COLTYPE,
    C.LENGTH,
    C.SCALE,
    C.NULLS
FROM SYSIBM.SYSCOLUMNS C
WHERE C.TBNAME IN (?, ?)
ORDER BY
    C.TBNAME,
    C.TBCREATOR,
    C.COLNO
```

Binds utilizados:

```text
TB_CNSLD_MARGEM_MPE
TB_CNSLD_VISITAS_MPE
```

A inspeção do catálogo deve ocorrer antes da codificação do repository para evitar suposições sobre:

- tipo de `ANO_MES`;
- escala dos decimais;
- tamanho de grupos e identificadores;
- nullability;
- tipo da data de atualização.

---

## 12. Backend DB2 reutilizável

Arquivo:

```text
plg_mcp_consult_fin/backends/db2_backend.py
```

Responsabilidades:

- criar conexão a partir de variáveis de ambiente;
- manter uma conexão por thread;
- reutilizar conexões ativas;
- executar somente `SELECT` ou `WITH`;
- aplicar timeout;
- fazer binds parametrizados;
- retornar linhas como `list[dict]`;
- liberar statements;
- fechar a conexão da thread;
- registrar latência sem expor credenciais.

Estrutura principal:

```python
class DB2Backend:
    @classmethod
    def from_env(cls) -> "DB2Backend":
        ...

    def execute_select(
        self,
        *,
        query_name: str,
        sql: str,
        values=(),
    ) -> list[dict]:
        ...

    def close_current_thread_connection(self) -> None:
        ...
```

### Reuso da conexão

A conexão é armazenada em `threading.local()` para evitar compartilhar um handle DB2 entre threads.

Comportamento esperado:

```text
Primeira consulta:
conexao_reutilizada=False
connect_ms > 0

Consultas seguintes na mesma thread:
conexao_reutilizada=True
connect_ms=0.00
```

### Restrição de leitura

Antes da execução:

```python
normalized_sql = sql.lstrip().upper()

if not normalized_sql.startswith(("SELECT", "WITH")):
    raise ValueError(
        "O backend permite apenas SELECT ou WITH."
    )
```

Essa validação é uma barreira adicional. O LLM não recebe acesso para montar ou submeter SQL arbitrário.

---

## 13. Repository dos consolidados MPE

Arquivo:

```text
plg_mcp_consult_fin/repositories/consolidados_mpe_repository.py
```

Modelos de domínio:

```python
@dataclass(frozen=True)
class MargemMPE:
    ano_mes: str
    grupo: str
    total_margem: Decimal
    media_margem: Decimal
    nm_iniciativa: str
    id_iniciativa: str
    dt_atualizacao: datetime


@dataclass(frozen=True)
class VisitasMPE:
    ano_mes: str
    grupo: str
    clientes_acumulados: int
    total_clientes: int
    percentual_acumulado: Decimal
    nm_iniciativa: str
    id_iniciativa: str
    dt_atualizacao: datetime
```

Criação pelo ambiente:

```python
@classmethod
def from_env(cls) -> "ConsolidadosMPERepository":
    return cls(
        backend=DB2Backend.from_env(),
        schema=os.environ["DB2_MPE_SCHEMA"],
    )
```

O schema é obrigatório e validado antes de ser interpolado no SQL.

### Validação do schema

```python
_SCHEMA_PATTERN = re.compile(
    r"^[A-Z][A-Z0-9_]{0,127}$"
)
```

Somente o identificador do schema é interpolado. Valores de filtros são passados por binds.

---

## 14. Validação dos filtros

Filtros suportados:

```text
ano_mes
grupo
id_iniciativa
apenas_periodo_mais_recente
limite
```

### `ano_mes`

Formato aceito:

```text
AAAA-MM
```

Regex:

```python
_ANO_MES_PATTERN = re.compile(
    r"^\d{4}-(0[1-9]|1[0-2])$"
)
```

Exemplo válido:

```text
2026-06
```

Exemplo inválido:

```text
202606
```

Retorno esperado:

```json
{
  "encontrado": false,
  "codigo": "PARAMETRO_INVALIDO",
  "mensagem": "ano_mes deve usar o formato AAAA-MM."
}
```

### Limite

O limite é normalizado entre 1 e 100 para evitar retornos excessivos:

```python
limite_normalizado = max(
    1,
    min(int(limite), 100),
)
```

### Período mais recente

Se `ano_mes` não for informado e `apenas_periodo_mais_recente=True`, é aplicado:

```sql
ANO_MES = (
    SELECT MAX(ANO_MES)
    FROM <SCHEMA>.<TABELA>
)
```

---

## 15. Conversão de tipos DB2

## 15.1 Decimais

O driver retornou os campos `DECIMAL` como strings com vírgula:

```text
2817314,54
233,530715
85,7675
```

Conversão implementada:

```python
def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value

    if isinstance(value, bytes):
        value = value.decode("utf-8")

    text = str(value).strip()

    if not text:
        raise ValueError(
            "O DB2 retornou um valor decimal vazio."
        )

    return Decimal(text.replace(",", "."))
```

Internamente, valores financeiros permanecem como `Decimal`. A serialização para JSON ocorre apenas na borda da tool.

## 15.2 Timestamp

Conversão para ISO 8601:

```python
value.isoformat()
```

## 15.3 Caracteres de controle

Foi identificado um caractere de controle no nome da iniciativa. A sanitização evita expor caracteres não imprimíveis ao MCP:

```python
def _sanitize_text(value: object) -> str:
    text = str(value).strip()

    cleaned = "".join(
        char if char.isprintable() else " "
        for char in text
    )

    return " ".join(cleaned.split())
```

---

## 16. Consultas do repository

## 16.1 Margem MPE

```sql
SELECT
    ANO_MES,
    GRUPO,
    TOTAL_MARGEM,
    MEDIA_MARGEM,
    NM_INICIATIVA,
    ID_INICIATIVA,
    DT_ATUALIZACAO
FROM <SCHEMA>.TB_CNSLD_MARGEM_MPE
<WHERE_CONTROLADO>
ORDER BY ANO_MES DESC, GRUPO
FETCH FIRST <LIMITE_VALIDADO> ROWS ONLY
```

## 16.2 Visitas MPE

```sql
SELECT
    ANO_MES,
    GRUPO,
    CLIENTES_ACUMULADOS,
    TOTAL_CLIENTES,
    PERCENTUAL_ACUMULADO,
    NM_INICIATIVA,
    ID_INICIATIVA,
    DT_ATUALIZACAO
FROM <SCHEMA>.TB_CNSLD_VISITAS_MPE
<WHERE_CONTROLADO>
ORDER BY ANO_MES DESC, GRUPO
FETCH FIRST <LIMITE_VALIDADO> ROWS ONLY
```

Condições opcionais são construídas no repository, mantendo os valores em binds:

```sql
ANO_MES = ?
GRUPO = ?
ID_INICIATIVA = ?
```

---

## 17. Service e tools MCP

Arquivo:

```text
plg_mcp_consult_fin/services/service_consolidados_mpe.py
```

Classe:

```python
class ServiceConsolidadosMPE(MCPToolBase):
    ...
```

Tools registradas:

```text
consultar_margem_mpe
consultar_visitas_mpe
```

Contrato geral de retorno:

```json
{
  "encontrado": true,
  "codigo": "SUCESSO",
  "total_registros": 1,
  "dados": []
}
```

Possíveis códigos:

```text
SUCESSO
DADOS_NAO_ENCONTRADOS
PARAMETRO_INVALIDO
CONSULTA_INDISPONIVEL
```

A exceção real é registrada no servidor, mas não é devolvida ao cliente para evitar vazamento de host, tabela, usuário ou outros detalhes internos.

---

## 18. Registro no MCP Server

Arquivo:

```text
plg_mcp_consult_fin/__main__.py
```

A criação da aplicação aceita injeção de repository para permitir testes sem DB2 real:

```python
def create_app(
    consolidados_repository=None,
) -> FastMCP:
    if consolidados_repository is None:
        consolidados_repository = (
            ConsolidadosMPERepository.from_env()
        )

    factory = MCPToolFactory()
    factory.register_service(ServiceExemplo())
    factory.register_service(
        ServiceConsolidadosMPE(
            consolidados_repository
        )
    )

    return factory.create_mcp_server(
        name=os.getenv(
            "MCP_SERVER_NAME",
            "BBMCPServer",
        )
    )
```

---

## 19. Inicialização local do MCP

Carregar o ambiente:

```bash
set -a
source .env
set +a
```

Subir em uma única linha para evitar erro de barra invertida com espaços:

```bash
./.venv/bin/python -m plg_mcp_consult_fin --host 127.0.0.1 --port 8080
```

Health check:

```bash
curl -s http://127.0.0.1:8080/health/ready
```

Resultado esperado:

```text
OK
```

---

## 20. Teste das tools com cliente FastMCP

Exemplo de chamada:

```python
import asyncio
from fastmcp import Client


async def main():
    async with Client(
        "http://127.0.0.1:8080/mcp/"
    ) as client:
        result = await client.call_tool(
            "consultar_margem_mpe",
            {
                "ano_mes": "2026-06",
                "grupo": "IA",
                "apenas_periodo_mais_recente": False,
                "limite": 10,
            },
        )

        print(result.data)


asyncio.run(main())
```

Testes executados:

1. margem do período mais recente;
2. visitas do período mais recente;
3. margem do grupo IA em período específico;
4. visitas do grupo IA em período específico;
5. rejeição de `ano_mes` inválido.

---

## 21. Configuração do agente para o MCP local

Arquivo:

```text
agent_config.yaml
```

Configuração utilizada no teste local:

```yaml
mcp:
  servers:
    - name: "plg-mcp-consult-fin-local"
      description: "MCP Server local para validação"
      transport:
        type: "streamable_http"
        endpoint: "http://127.0.0.1:8080/mcp"
      authentication:
        type: "none"
```

> O endpoint local é apenas para desenvolvimento. Antes da publicação da configuração do agente, restaurar o endpoint corporativo ou torná-lo parametrizável por ambiente.

O agente transforma a configuração para o formato esperado pelo `MultiServerMCPClient`:

```python
{
    server.name: {
        "url": server.transport.mcp_url,
        "transport": server.transport.type,
    }
}
```

---

## 22. Validação de descoberta das tools pelo agente

Resultado observado:

```text
consultar_margem_mpe
consultar_visitas_mpe
```

Schemas inferidos:

```text
ano_mes
grupo
id_iniciativa
apenas_periodo_mais_recente
limite
```

A antiga tool experimental de recomendações não permaneceu no registro ativo da entrega final do MCP.

---

## 23. Conexão do agente ao LLM

Provider utilizado:

```text
gateway_outbound
```

Autenticação local com:

- AppKey via variável de ambiente;
- certificado cliente HML;
- chave privada HML;
- CA HML;
- mTLS.

Variáveis esperadas pelo agente:

```dotenv
GATEWAY_OUTBOUND_GW_APP_KEY=<APPKEY>
KEY_STORE_CERT_PATH=<CAMINHO_ABSOLUTO_DO_CERTIFICADO>
KEY_STORE_KEY_PATH=<CAMINHO_ABSOLUTO_DA_CHAVE>
TRUST_STORE_CA_PATH=<CAMINHO_ABSOLUTO_DA_CA>
```

Nunca registrar os valores na Wiki, no Git ou em logs.

Smoke test executado pelo próprio provider:

```python
llm = LLMFactory.create(
    config.llm.provider,
    config.temperature,
    config.top_p,
)

response = await llm.ainvoke(
    "Responda apenas com a palavra: pong"
)
```

Resultado validado:

```text
pong
```

---

## 24. Validação ponta a ponta com margem MPE

Pergunta utilizada:

```text
Consulte obrigatoriamente a ferramenta de margem MPE e informe os dados
do grupo IA no período 2026-06. Apresente a margem total, a margem média,
a iniciativa e a data de atualização. Não estime valores.
```

Tool selecionada pelo LLM:

```text
consultar_margem_mpe
```

Argumentos gerados:

```json
{
  "ano_mes": "2026-06",
  "grupo": "IA"
}
```

O agente recebeu os dados estruturados da tool e gerou uma resposta em linguagem natural, preservando os valores retornados pelo DB2.

---

## 25. Validação ponta a ponta com visitas MPE

Pergunta utilizada:

```text
Consulte obrigatoriamente a ferramenta de visitas MPE para o grupo IA no
período 2026-07. Informe clientes acumulados, total de clientes, percentual
acumulado e data de atualização. Não estime valores.
```

Tool selecionada:

```text
consultar_visitas_mpe
```

Argumentos gerados:

```json
{
  "ano_mes": "2026-07",
  "grupo": "IA"
}
```

---

## 26. Memória de curto prazo no agente

O grafo utilizou um checkpointer em memória:

```python
from langgraph.checkpoint.memory import MemorySaver

checkpointer = MemorySaver()
return builder.compile(
    checkpointer=checkpointer
)
```

A execução deve informar um `thread_id`:

```python
config = {
    "configurable": {
        "thread_id": "identificador-da-conversa"
    }
}
```

Teste realizado:

### Turno 1

```text
Consulte visitas MPE do grupo IA no período informado.
```

### Turno 2

```text
Qual foi o percentual acumulado que você acabou de informar?
```

O agente respondeu usando o histórico sem nova consulta ao DB2.

### Limitação

`MemorySaver` é volátil:

- preserva o histórico enquanto o processo estiver ativo;
- perde o histórico ao reiniciar;
- não é adequado para múltiplas réplicas em produção.

Evolução recomendada para ambientes compartilhados:

- Redis;
- PostgreSQL;
- outro checkpointer persistente compatível com LangGraph.

---

## 27. Testes e gates de qualidade

Comandos utilizados:

```bash
./.venv/bin/python -m compileall -q \
  plg_mcp_consult_fin
```

```bash
./.venv/bin/python -m pip check
```

```bash
env \
  -u DB2_HOSTNAME \
  -u DB2_PORT \
  -u DB2_DATABASE \
  -u DB2_UID \
  -u DB2_PWD \
  -u DB2_MPE_SCHEMA \
  ./.venv/bin/python -m pytest -q
```

Resultado validado no momento da publicação:

```text
22 testes unitários aprovados
pip check sem dependências quebradas
smoke test real DB2 aprovado
smoke test MCP aprovado
integração Agent -> MCP -> DB2 aprovada
```

Os testes locais que dependem de DB2 real devem ficar fora do Git ou ser convertidos em testes de integração explicitamente habilitados por configuração.

---

## 28. Observabilidade

O backend registra:

- nome lógico da consulta;
- quantidade de binds;
- latência de conexão;
- reutilização da conexão;
- latência de execução e fetch;
- quantidade de registros retornados.

Não registrar:

- senha;
- AppKey;
- conteúdo do `.env`;
- chave privada;
- connection string completa;
- dados sensíveis de clientes.

Exemplo de evidência observada:

```text
evento=db2_consulta_sucesso
consulta=consultar_visitas_mpe
conexao_reutilizada=True
connect_ms=0.00
rowcount=4
```

---

## 29. Tratamento de erros

As tools devolvem mensagens controladas.

### Parâmetro inválido

```json
{
  "encontrado": false,
  "codigo": "PARAMETRO_INVALIDO",
  "mensagem": "ano_mes deve usar o formato AAAA-MM."
}
```

### Dados não encontrados

```json
{
  "encontrado": false,
  "codigo": "DADOS_NAO_ENCONTRADOS",
  "total_registros": 0,
  "dados": []
}
```

### Indisponibilidade

```json
{
  "encontrado": false,
  "codigo": "CONSULTA_INDISPONIVEL",
  "mensagem": "Não foi possível consultar os dados MPE."
}
```

Detalhes técnicos permanecem apenas nos logs internos.

---

## 30. Checklist para criar uma nova tool DB2

1. Identificar a fonte e finalidade da informação.
2. Confirmar o schema e o nome qualificado da tabela.
3. Inspecionar colunas e tipos no catálogo DB2.
4. Confirmar permissão de leitura do usuário da aplicação.
5. Definir filtros permitidos.
6. Bloquear SQL arbitrário.
7. Utilizar binds para todos os valores fornecidos externamente.
8. Limitar o volume retornado.
9. Criar dataclasses de domínio.
10. Tratar `Decimal`, `TIMESTAMP`, bytes e caracteres de controle.
11. Implementar o método no repository.
12. Criar envelope de retorno estável.
13. Registrar a tool no service.
14. Registrar o service na factory do MCP.
15. Testar repository isoladamente.
16. Testar tool pelo cliente FastMCP.
17. Testar descoberta pelo agente.
18. Testar tool calling pelo LLM.
19. Confirmar ausência de segredos no Git.
20. Executar compilação, testes e `pip check`.
21. Validar a configuração em runtime autorizado.
22. Documentar limitações e requisitos do ambiente.

---

## 31. Cuidados para HML e produção

Antes de promover:

- substituir schema pessoal por schema compartilhado;
- configurar `DB2_MPE_SCHEMA` no ambiente;
- utilizar usuário impessoal autorizado;
- injetar credenciais por Secret;
- confirmar rota do cluster ao DB2;
- definir política de rotação das credenciais;
- validar timeout e pool/reuso de conexão;
- revisar volume máximo de retorno;
- revisar logs e telemetria;
- configurar endpoint MCP por ambiente;
- substituir memória volátil se houver requisito de persistência;
- corrigir ou revisar o avaliador `ToolCorrectness` que operou em `fail-open` nos testes do agente;
- preservar a precisão de percentuais quando necessário, instruindo o agente a não arredondar sem solicitação.

---

## 32. Branch e commit da entrega MCP

Branch publicada:

```text
feature/mpe-db2-tools
```

Commit:

```text
e2e1537
feat(mcp): add DB2 tools for MPE consolidated metrics
```

Conteúdo principal:

```text
plg_mcp_consult_fin/__main__.py
plg_mcp_consult_fin/backends/db2_backend.py
plg_mcp_consult_fin/repositories/consolidados_mpe_repository.py
plg_mcp_consult_fin/services/service_consolidados_mpe.py
requirements.txt
setup.py
tests/unit/test_mcp_server.py
```

---

## 33. Resultado final

Capacidades validadas:

```text
[OK] Conectividade com DB2 via gateway corporativo
[OK] Autenticação DB2
[OK] Consulta SQL parametrizada
[OK] Reuso de conexão por thread
[OK] Conversão de DECIMAL com vírgula
[OK] Sanitização de caracteres de controle
[OK] Tool consultar_margem_mpe
[OK] Tool consultar_visitas_mpe
[OK] Validação do formato AAAA-MM
[OK] Descoberta das tools pelo agente
[OK] Tool calling pelo GPT-4o
[OK] Resposta em linguagem natural
[OK] Memória de curto prazo por thread_id
[OK] FastMCP 2.13.3 sem conflito de dependências
[OK] Publicação da branch do MCP
```

A implementação estabeleceu um padrão reutilizável para novas tools MCP com acesso controlado a dados corporativos no DB2.
