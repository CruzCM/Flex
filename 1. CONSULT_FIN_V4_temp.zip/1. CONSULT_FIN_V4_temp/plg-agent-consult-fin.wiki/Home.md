# Deploy do Agente Consultor-Fin - Guia Hands-On

**Versão:** 1.0
**Última atualização:** 25/08/2026
**Responsável:** Juscelino Barbosa da Silva Neto

Este guia descreve, do início ao fim, o processo de publicação do agente
Consultor-Fin nos ambientes de desenvolvimento, homologação e produção,
incluindo a obtenção dos certificados e a validação via mTLS. Trata-se de
um material vivo: seções marcadas como pendência serão detalhadas em
versões futuras.

**Legenda de status:** Validado (confirmado em ambiente) - A confirmar - Pendência.

---

## Sequência oficial do processo

O fluxo abaixo respeita a dependência real entre as etapas. Em especial,
os certificados só existem no cluster após o primeiro deploy; por isso a
obtenção dos certificados (etapa 4) antecede a execução local (etapa 5).

1. Solicitar os acessos necessários (ver "1. Acessos e pré-requisitos").
2. Configurar o Git e clonar os dois repositórios (ver "2. Repositórios e Git").
3. Ativar o parâmetro `enabled` no `values.yaml` e realizar o push. Isso
   sobe o container inicial, que provisiona as secrets de certificado no
   cluster (ver "5. Deploy no ArgoCD").
4. Obter os certificados a partir do console OpenShift (ver "4. Certificados
   do cluster").
5. Preparar e executar a aplicação localmente, utilizando os certificados e
   o arquivo `.env` (ver "3. Preparo local").
6. Validar as duas pontas da integração: o agente e o acesso ao LLM via mTLS
   (ver "6. Validação").

---

## 0. Mapa de origem: Instância OAS e Catálogos

A página-raiz da esteira é a instância **OAS - consult-fin**
(`tech.bb.com.br/p/oas/instance/fd84eb19-.../info`), a partir da qual se
acessam os links do ArgoCD e os catálogos abaixo.

**Catálogo de IA** - endereços do agente por ambiente:

| Ambiente        | Endpoint `/v1/chat`                                             |
|-----------------|----------------------------------------------------------------|
| Desenvolvimento | `consultor-financeiro.ai-interno.api.desenv.bb.com.br/v1/chat` |
| Homologação     | `consultor-financeiro.ai-interno.api.hm.bb.com.br/v1/chat`     |
| Produção        | `consultor-financeiro.ai-interno.api.bb.com.br/v1/chat`        |

**Catálogo de APIs** - API do Azure AI Foundry, onde estão os modelos de
linguagem (LLMs): `/cambio-chat-completion`,
`/openai/deployments/gpt-5/chat/completions` e
`/openai/deployments/gpt-5-mini/chat/completions`.

**Catálogo de Aplicações** - origem da AppKey da aplicação, disponível para
os três ambientes e recebida por e-mail. O valor da AppKey nunca deve ser
registrado nesta Wiki.

---

## 1. Acessos e pré-requisitos

Papéis de acesso solicitados para o projeto:

| Papel               | Finalidade                          |
|---------------------|-------------------------------------|
| `ALMFD<<SIGLA>>`    | Cluster e ArgoCD - perfil de desenvolvimento |
| `ALMFE<<SIGLA>>`    | Cluster e ArgoCD - perfil de RT     |
| `CTL02000`          | -                                   |
| `CTL00030`          | -                                   |
| `RFG...`            | Acesso ao repositório de deploy no GitHub |

A concessão dos papéis é feita pelo gestor responsável. A sigla do projeto
é **PLG**.

---

## 2. Repositórios e Git

O projeto utiliza dois repositórios com responsabilidades distintas:

- **Código base:** `github.com/bbvinet/plg-agent-consult-fin` - contém o
  código do agente e esta Wiki. Alterações de código, incluindo o rename do
  pacote, ocorrem aqui.
- **Deploy:** `github.com/bbvinet/deploy-plg-agent-consult-fin` (prefixo
  `deploy-`) - contém o `values.yaml`, os charts e as branches `cloud/*`. O
  push nas branches `cloud/*` é o que dispara o auto-sync no ArgoCD.

**Configuração inicial (necessária apenas na primeira utilização):**

- Autenticação no GitHub via `gh` com SSH: gerar a chave, configurar o
  arquivo `~/.ssh/config`, aplicar `chmod 600` na chave e testar com
  `ssh -T git@github.com`.
- Clone com SAML SSO na organização `bbvinet`: autorizar o token de acesso
  pessoal (PAT) na organização.
- Assinatura de commits: `git config --global gpg.format ssh` seguido de
  `git config --global user.signingkey <chave>`.

---

## 3. Preparo local

Esta etapa deve ser executada após a obtenção dos certificados (seção 4),
pois a aplicação local depende deles.

- **Rename do pacote:** renomear `dia_agent_azure_template_python` para
  `big_agent_consultor_fin`. É um passo obrigatório e já vem indicado no
  template.
- **Ambiente virtual:** criar o `venv` do Python e instalar as dependências.
- **Arquivo `.env`:** o projeto disponibiliza o modelo `env.example`. Copie-o
  para `.env` e preencha os campos abaixo. O arquivo `.env` não deve ser
  versionado.

```dotenv
# ----------------------------------------------------------------------------
# OBRIGATORIO - Gateway Outbound BB
# AppKey da aplicacao registrada no Outbound Gateway BB. Recebida por email.
# ----------------------------------------------------------------------------
GATEWAY_OUTBOUND_GW_APP_KEY=<PREENCHER>

# ----------------------------------------------------------------------------
# OBRIGATORIO PARA EXECUCAO LOCAL - mTLS (autenticacao cliente)
# Certificado cliente e chave privada registrados no Gateway BB.
# Informe os caminhos absolutos aos arquivos locais .crt e .key.
# Obtidos nas secrets do container provisionado da aplicacao.
# Exemplo: /home/usuario/certs/agent-idh-hml-tls.crt
# ----------------------------------------------------------------------------
KEY_STORE_CERT_PATH=<PREENCHER>
KEY_STORE_KEY_PATH=<PREENCHER>

# ----------------------------------------------------------------------------
# OBRIGATORIO PARA EXECUCAO LOCAL - CA do BB (validacao do servidor)
# Arquivo CA para validar o certificado do servidor gateway.
# Normalmente acompanha os certificados mTLS.
# Obtido nas secrets do container provisionado da aplicacao.
# Exemplo: /home/usuario/certs/agent-idh-hml-ca.crt
# ----------------------------------------------------------------------------
TRUST_STORE_CA_PATH=<PREENCHER>
```

- **Arquivo `agent_config.yaml`:** o parâmetro `base_url` deve apontar para a
  API do ambiente correspondente (ver seção 0).
- **Execução em container:** `docker run` com `--env-file .env` e os volumes
  dos certificados.
- **Validação local:** executar `curl http://localhost:8080/health/live`.
  A resposta esperada é `{"status":"alive"}`.

---

## 4. Certificados do cluster

Os certificados não existem previamente: eles são provisionados quando o
container inicial sobe (seção 5). A via recomendada para obtê-los é o
console do OpenShift.

**Caminho no console (ambiente de desenvolvimento):** Console → namespace
`plg-agent-consult-fin` → aba **Secrets**. Nela encontram-se os certificados
IDH (`idhmtls`) e o `bbcert`.

`console.apps.k8sdesbb211d.nuvem.bb.com.br/k8s/ns/plg-agent-consult-fin/core~v1~Secret`

**Padrão por ambiente:** troca-se apenas o termo `des` por `hml` ou `prd` no
host do console. O restante do endereço permanece inalterado.

| Ambiente        | Host do console                                    |
|-----------------|----------------------------------------------------|
| Desenvolvimento | `console.apps.k8sdesbb211d.nuvem.bb.com.br/...`    |
| Homologação     | `console.apps.k8shmlbb211d.nuvem.bb.com.br/...`    |
| Produção        | `console.apps.k8sprdbb211d.nuvem.bb.com.br/...`    |

**Visualização do pod:** utilizar a aba **Topology** do mesmo console.

**Uso local:** copiar os valores das secrets, gerar os arquivos `.crt`,
`.key` e `ca.crt` e apontar os respectivos caminhos no arquivo `.env`
(seção 3).

---

## 5. Deploy no ArgoCD

- No repositório de deploy, o `values.yaml` traz os services de
  desenvolvimento e homologação com `enabled: false`. É necessário alterar
  para `enabled: true`.
- O push para as branches de desenvolvimento e homologação dispara o
  auto-sync no ArgoCD e sobe o container inicial. É esse primeiro deploy que
  provisiona as secrets de certificado descritas na seção 4.
- Branches de deploy: `cloud/desenvolvimento`, `cloud/homologacao` e
  `cloud/producao`.
- Após a subida nos dois ambientes, confirmar a presença dos certificados no
  cluster.

---

## 6. Validação

A validação cobre duas pontas distintas da integração.

**6.1. Ponta do agente (Swagger).** Contrato: `{ message, session_id }`.

```bash
curl -X POST "https://consultor-financeiro.ai-interno.api.desenv.bb.com.br/v1/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"Qual e o sentido da vida?","session_id":"sessao-exemplo"}'
```

**6.2. Ponta do LLM (outbound, mTLS).** Utiliza os certificados IDH obtidos
na seção 4 e a AppKey. Contrato: `{ model, messages, max_tokens }`.

```bash
curl \
  --cert agent-idh-des-tls.crt \
  --key  agent-idh-des-tls.key \
  -H "x-application-key: ***" \
  -H "Content-Type: application/json" \
  -X POST "***" \
  -d '{"model":"cambio-non-prod-gpt4o","messages":[{"role":"user","content":"Qual e o sentido da vida?"}],"max_tokens":10}'
```

O valor de `x-application-key` e a URL de produção devem permanecer
mascarados nesta Wiki.

| Ponta        | O que valida                  | Autenticação          | Contrato                        |
|--------------|-------------------------------|-----------------------|---------------------------------|
| Agente       | Agente publicado (`/v1/chat`) | Interno               | `{ message, session_id }`       |
| LLM/outbound | Acesso ao Azure AI Foundry    | mTLS (IDH) + AppKey   | `{ model, messages, max_tokens }` |

**Dica de diagnóstico (troubleshooting).** Para inspecionar a cadeia e o
emissor do certificado do gateway:

```bash
openssl s_client -connect outbound.api.desenv.bb.com.br:443 </dev/null | openssl x509 -noout -text
```

---

## Pendências (próximas versões)

- **mTLS Leg 2 (Concierge para backend):** o Ingress termina o TLS e entrega
  HTTP puro ao pod. A solução envolve decisão de arquitetura do time e está
  fora do escopo desta versão.
- Detalhamento da finalidade dos papéis `CTL02000` e `CTL00030`.
- Etapas de CI/pipeline (Sonar, Jenkins e aprovação de merge request), a
  serem incorporadas na evolução deste guia.

