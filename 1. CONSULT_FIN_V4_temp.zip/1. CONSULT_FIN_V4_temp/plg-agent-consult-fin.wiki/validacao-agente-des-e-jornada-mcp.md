# Validação do Agente em DES e Jornada do MCP Corporativo

**Projeto:** Consultor Financeiro  
**Aplicação:** `plg-agent-consult-fin`  
**Ambiente:** DES  
**Data do registro:** 26/08/2026  
**Status geral:** agente validado internamente; acesso externo em investigação; solicitação do MCP aguardando aprovação.

---

## 1. Objetivo

Registrar as atividades realizadas para:

1. Publicar e validar uma nova versão do agente Consultor Financeiro no ambiente de desenvolvimento;
2. Confirmar o funcionamento da integração do agente com o Gateway Outbound e o modelo de linguagem;
3. Investigar o erro apresentado no acesso externo pela API catalogada;
4. Iniciar a jornada de provisionamento de um MCP Server pela oferta corporativa do Tech.bb.

---

## 2. Resumo executivo

A versão `0.1.0.dev1` do agente foi construída, publicada e implantada no ambiente DES. Os testes internos confirmaram o funcionamento do pod, do Service, dos Endpoints, da aplicação FastAPI, do grafo LangGraph e da chamada ao modelo por meio do Gateway Outbound.

O endpoint local `POST /chat` respondeu corretamente ao teste `2 + 2`, demonstrando que o agente e sua integração outbound estão operacionais.

O acesso externo, entretanto, continua retornando erro. A Route `agent-consult-fin.plg.desenv.bb.com.br` responde com HTTP 503, enquanto a API catalogada retorna o código `9502`, relacionado à validação mTLS do backend. As evidências indicam que a falha ocorre depois do Service e antes de a requisição alcançar a aplicação, permanecendo em investigação na camada de Route, Ingress ou catalogação.

Também foi iniciada a solicitação de um MCP Server corporativo no domínio PLG. A solicitação encontra-se aguardando aprovação pelo papel corporativo responsável.

---

## 3. Alteração implantada

### 3.1 Versão

```text
0.1.0.dev1
```

### 3.2 Objetivo da alteração

Correção do endpoint utilizado pelo provedor de LLM no ambiente DES.

### 3.3 Configuração efetiva do Gateway Outbound

```yaml
llm:
  provider: gateway_outbound
  gateway_outbound:
    base_url: https://llms-agentes-ia.outbound.api.desenv.bb.com.br/v1
    model: cambio-non-prod-gpt4o
    api_version: 2024-12-01-preview
    max_tokens: 4096
```

> Os valores sensíveis de autenticação não devem ser armazenados na Wiki. A AppKey é fornecida ao container por Secret e variável de ambiente.

---

## 4. Fluxo de build e deploy

O fluxo executado foi:

```text
Repositório de código
        ↓
Alteração da versão para 0.1.0.dev1
        ↓
GitHub Actions / Esteira de Build Python
        ↓
Publicação da imagem corporativa
        ↓
Atualização do values.yaml no repositório de deploy
        ↓
Argo CD
        ↓
Pod DES com a imagem 0.1.0.dev1
```

Imagem observada no pod:

```text
docker.binarios.intranet.bb.com.br/bb/plg/plg-agent-consult-fin:0.1.0.dev1
```

O pod foi iniciado sem reinicializações e permaneceu em estado `Running` e `Ready`.

---

## 5. Configuração de Service e aplicação

### 5.1 Service

```yaml
service:
  enable: true
  name: plg-agent-consult-fin
  type: ClusterIP
  ports:
    - name: http
      port: 80
      targetPort: 8080
```

### 5.2 Probes

```yaml
livenessProbe:
  httpGet:
    path: /health/live
    port: 8080

readinessProbe:
  httpGet:
    path: /health/ready
    port: 8080
```

### 5.3 Certificados disponibilizados ao container

```text
KEY_STORE_CERT_PATH=/app/certs/tls.crt
KEY_STORE_KEY_PATH=/app/certs/tls.key
TRUST_STORE_CA_PATH=/app/certs/ca.crt
```

Os arquivos foram encontrados pela aplicação durante o startup. O conteúdo dos certificados, chaves privadas, tokens e AppKeys não deve ser registrado nesta Wiki.

---

## 6. Evidências de funcionamento interno

### 6.1 Health-check dentro do pod

```bash
curl http://localhost:8080/health/ready
```

Resultado:

```text
HTTP 200
```

O endpoint `/docs` também respondeu com HTTP 200 diretamente no pod.

### 6.2 Health-check pelo Service

Teste pelo DNS interno:

```bash
curl http://plg-agent-consult-fin:80/health/ready
```

Resultado:

```text
HTTP 200
```

Teste pelo ClusterIP:

```bash
curl http://10.150.169.93:80/health/ready
```

Resultado:

```text
HTTP 200
```

### 6.3 Endpoints do Service

O objeto `Endpoints` reconheceu o pod como disponível:

```yaml
subsets:
  - addresses:
      - ip: 10.149.119.26
        targetRef:
          kind: Pod
          name: plg-agent-consult-fin-regular-5c8db456c4-nc9vw
    ports:
      - name: http
        port: 8080
        protocol: TCP
```

O endereço foi listado em `addresses`, e não em `notReadyAddresses`.

### 6.4 Rotas publicadas pela aplicação

A especificação OpenAPI expõe:

```text
POST /chat
GET  /metrics
GET  /health/live
GET  /health/ready
```

O endpoint correto da aplicação é `/chat`, e não `/v1/chat`.

### 6.5 Teste funcional do agente

Requisição executada diretamente dentro do pod:

```bash
curl \
  -H "Content-Type: application/json" \
  http://localhost:8080/chat \
  -d '{
    "message": "2 + 2"
  }'
```

Resposta:

```json
{
  "reply": "2 + 2 = 4",
  "session_id": null,
  "tool_calls_made": 0
}
```

Tempo observado no teste:

```text
Aproximadamente 1 segundo
```

Esse teste confirmou o funcionamento conjunto de:

- API FastAPI;
- grafo LangGraph;
- provedor `gateway_outbound`;
- autenticação configurada em runtime;
- certificados mTLS do consumo outbound;
- chamada ao modelo de linguagem.

---

## 7. Problema no acesso externo

### 7.1 Route

Host testado:

```text
agent-consult-fin.plg.desenv.bb.com.br
```

Testes:

```bash
curl -vk https://agent-consult-fin.plg.desenv.bb.com.br/health/ready
curl -vk https://agent-consult-fin.plg.desenv.bb.com.br/docs
```

Resultado nos dois casos:

```text
HTTP 503 - Service Temporarily Unavailable
Resposta gerada por nginx
```

### 7.2 API catalogada

A chamada pela API catalogada retornou:

```json
{
  "errors": [
    {
      "code": "9502",
      "title": "Aconteceu um problema técnico",
      "detail": "Falha ao validar mTLS no backend: mTLS obrigatório não configurado"
    }
  ]
}
```

A requisição feita pela API catalogada não produziu registro de acesso no log da aplicação.

---

## 8. Verificações de infraestrutura realizadas

### 8.1 Pod

```text
Status: Running
Ready: 1/1
Restarts: 0
Imagem: 0.1.0.dev1
```

### 8.2 Service

Mapeamento confirmado:

```text
Service 80/TCP → Pod 8080/TCP
```

### 8.3 Endpoints

O Service possui endpoint pronto e associado ao pod.

### 8.4 Ingress

O Ingress apresenta o backend:

```text
plg-agent-consult-fin:80 → 10.149.119.26:8080
```

Não foram apresentados eventos de erro no `oc describe ingress`.

### 8.5 Route

A Route foi criada para:

```text
agent-consult-fin.plg.desenv.bb.com.br
```

Configuração observada:

```yaml
to:
  kind: Service
  name: plg-agent-consult-fin
port:
  targetPort: http
tls:
  termination: edge
  insecureEdgeTerminationPolicy: Redirect
```

A Route aparece como admitida pelo controller.

### 8.6 Secret TLS

A Secret abaixo existe e possui três entradas:

```text
plg-agent-consult-fin-tls
Tipo: kubernetes.io/tls
Dados: tls.crt, tls.key e ca.crt
```

Nenhum conteúdo da Secret deve ser incluído na Wiki.

### 8.7 NetworkPolicy

Não há objetos `NetworkPolicy` no namespace:

```text
No resources found in plg-agent-consult-fin namespace.
```

### 8.8 Reconciliação do Ingress

Foi solicitada uma nova reconciliação do objeto Ingress por anotação. Após a reconciliação, a Route continuou retornando HTTP 503.

### 8.9 Eventos do namespace

Os eventos observados registraram apenas o ciclo normal de deploy:

- criação do novo ReplicaSet;
- agendamento do pod;
- download da imagem `0.1.0.dev1`;
- inicialização do container;
- encerramento do pod anterior.

Não foram apresentados eventos de falha relacionados ao Ingress no namespace da aplicação.

---

## 9. Diagnóstico atual

Com base nos testes executados:

```text
Aplicação /chat        ✅
Pod                     ✅
Probes                  ✅
Gateway Outbound        ✅
Service                 ✅
Endpoints               ✅
Secret TLS              ✅
Ingress mapeado         ✅
Route admitida          ✅
NetworkPolicy ausente   ✅
Acesso pela Route       ❌ HTTP 503
API catalogada          ❌ Código 9502
```

As evidências indicam que a falha ocorre após o Service e antes de a requisição alcançar a aplicação. O ponto permanece em investigação nas camadas de Route, controller `ingress-interno-iib` ou configuração da API catalogada.

Não foi identificada evidência de falha no código do agente, no Gateway Outbound, no pod, no Service ou nos Endpoints.

---

## 10. Solicitação do MCP Server corporativo

Foi iniciada a solicitação de um MCP Server pela oferta corporativa do Tech.bb.

### 10.1 Dados informados

```text
Sigla: PLG
Nome do MCP Server: mcp-consult-fin
Tipo: Python
Nome da instância: mcp-consult-fin
UOR mantenedora informada: 470765
```

### 10.2 Finalidade inicial

A versão inicial será utilizada para validar a jornada corporativa completa de MCP, incluindo:

- provisionamento;
- estrutura do projeto;
- desenvolvimento com FastMCP;
- tools, resources e prompts;
- testes locais;
- CI/CD;
- deploy com Argo CD;
- vinculação obrigatória a uma API;
- configuração do Resource Indicator;
- consumo pelo agente Consultor Financeiro.

### 10.3 Descrição utilizada na solicitação

```text
MCP Server experimental do dominio PLG para validar a jornada corporativa de provisionamento, desenvolvimento, CI/CD, deploy, catalogacao e consumo por agentes de IA. A versao inicial disponibilizara ferramentas utilitarias de teste, recursos com informacoes operacionais do servico e prompts de apoio a validacao da integracao. Apos a validacao do fluxo, podera evoluir para capacidades relacionadas ao Consultor Financeiro PJ e a outras solucoes do dominio PLG.
```

A descrição foi submetida em uma única linha e sem caracteres acentuados devido a uma validação do campo `descricao_projeto` apresentada pelo formulário.

### 10.4 Status

```text
Aguardando aprovação pelo papel DEVMSAPV.
```

A aprovação é uma condição necessária para o provisionamento dos recursos associados à oferta.

---

## 11. Jornada prevista após a aprovação do MCP

1. Acompanhar o provisionamento e acessar o recurso criado;
2. Identificar o repositório Python provisionado inicialmente;
3. Solicitar a migração do repositório Python para o GitHub;
4. Inspecionar o template recebido antes de portar o MCP local;
5. Utilizar a branch `develop` para o desenvolvimento;
6. Implementar uma versão inicial pequena, com tool, resource e prompt de validação;
7. Executar os testes locais;
8. Acionar a esteira corporativa de CI/CD Python;
9. Validar o deploy com o chart `dia-chart-mcp`;
10. Criar a API vinculada ao MCP como comunicação interna de microsserviços;
11. Configurar e registrar o Resource Indicator;
12. Integrar o MCP ao `plg-agent-consult-fin`;
13. Validar a descoberta e a chamada das ferramentas pelo agente;
14. Documentar a jornada e somente depois definir as capacidades de negócio.

---

## 12. Decisões tomadas

- Manter o MCP no domínio `PLG`;
- Utilizar Python e FastMCP;
- Começar com capacidades simples de diagnóstico e validação;
- Não assumir ferramentas de negócio antes de concluir o desbravamento da esteira;
- Evoluir posteriormente para capacidades relacionadas ao Consultor Financeiro PJ, se adequado;
- Manter o material como documentação viva e atualizá-lo a cada avanço;
- Não versionar secrets, tokens, AppKeys, certificados privados ou valores sensíveis.

---

## 13. Próximos passos

### Agente

- Aguardar análise da Route, do Ingress ou da catalogação;
- Retestar `GET /health/ready` pela Route após eventual ajuste;
- Retestar o `POST` pela API catalogada;
- Confirmar que a requisição externa passa a aparecer nos logs da aplicação;
- Registrar a causa raiz e a correção quando confirmadas.

### MCP

- Aguardar a aprovação da oferta;
- Acompanhar o provisionamento;
- Solicitar a migração do repositório Python para o GitHub;
- Inspecionar o template e o README recebidos;
- Definir a primeira tool, o primeiro resource e o primeiro prompt de validação;
- Planejar a API vinculada e o Resource Indicator.

---

## 14. Segurança e tratamento de credenciais

Durante o diagnóstico foram manipulados tokens, AppKeys, certificados e Secrets. Estes dados não devem ser copiados para a Wiki, README, issues, logs compartilhados ou commits.

Ações recomendadas:

- revogar ou substituir tokens exibidos fora do ambiente seguro;
- rotacionar credenciais que tenham sido expostas durante o troubleshooting;
- utilizar placeholders em toda documentação;
- guardar valores sensíveis exclusivamente nos mecanismos corporativos de Secret;
- revisar o histórico local antes de publicar arquivos de log;
- garantir que `.env`, chaves privadas e certificados estejam ignorados pelo Git.

Exemplos de placeholders permitidos:

```text
<APP_KEY_MASCARADA>
<TOKEN_MASCARADO>
<SECRET_GERENCIADA_NO_OPENSHIFT>
<CERTIFICADO_NAO_REGISTRADO_NA_WIKI>
```

---

## 15. Comandos úteis para nova validação

### Verificar o pod

```bash
oc get pods -n plg-agent-consult-fin -o wide
```

### Verificar Service e Endpoints

```bash
oc get service plg-agent-consult-fin -n plg-agent-consult-fin -o yaml
oc get endpoints plg-agent-consult-fin -n plg-agent-consult-fin -o yaml
```

### Verificar Ingress e Route

```bash
oc describe ingress plg-agent-consult-fin -n plg-agent-consult-fin
oc get route -n plg-agent-consult-fin -o yaml
```

### Verificar eventos

```bash
oc get events -n plg-agent-consult-fin --sort-by=.lastTimestamp
```

### Testar a Route

```bash
curl -k -o /dev/null -w "%{http_code}\n" \
  https://agent-consult-fin.plg.desenv.bb.com.br/health/ready
```

### Testar o agente diretamente dentro do pod

```bash
curl \
  -H "Content-Type: application/json" \
  http://localhost:8080/chat \
  -d '{
    "message": "2 + 2"
  }'
```

---

## 16. Histórico de atualização

| Data | Alteração | Status |
|---|---|---|
| 26/08/2026 | Implantação da versão `0.1.0.dev1` e validação interna do agente | Concluído |
| 26/08/2026 | Investigação do HTTP 503 na Route e do erro 9502 na API catalogada | Em investigação |
| 26/08/2026 | Solicitação do MCP `mcp-consult-fin` no domínio PLG | Aguardando aprovação |
