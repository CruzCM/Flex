# Guia corporativo Pengwin-WSL

Guia de instalação, uso e manutenção do ambiente de desenvolvimento Linux corporativo no Windows.

**Revisão editorial:** 10/09/2026. **Ambiente de referência:** coleta de 10/09/2026, complementada pelos esclarecimentos da exploração. As versões registradas descrevem essa instalação; não constituem, por si só, requisitos de outras instalações.

## Sumário

1. [Apresentação e convenções](#apresentacao)
2. [Arquitetura](#arquitetura)
3. [Instalação e primeira utilização](#instalacao)
4. [Terminal e comandos corporativos](#terminal)
5. [Arquivos e integração Windows](#arquivos)
6. [Proxy e certificados](#conectividade)
7. [Componentes e pacotes](#componentes)
8. [Python, pyenv e ambientes virtuais](#python)
9. [Git e VS Code com WSL](#git-vscode)
10. [Atualização e manutenção](#manutencao)
11. [Troubleshooting, diagnóstico e suporte](#suporte)
12. [Referência rápida de comandos](#referencia)
13. [Ambiente de referência observado](#ambiente-observado)
14. [Fontes e controle documental](#fontes)

<a id="apresentacao"></a>
## 1. Apresentação e convenções

Este documento orienta quem precisa instalar, utilizar e manter o Pengwin-WSL corporativo. O escopo é o ambiente: terminal, ferramentas, conectividade, integração Windows e procedimentos de suporte. Tutoriais de aplicações e configurações de projetos não fazem parte do guia.

O Pengwin corporativo automatiza a configuração de um ambiente Ubuntu/WSL para a infraestrutura do BB. Sua composição deve ser consultada na documentação institucional. A existência de um projeto público também chamado Pengwin não estabelece o baseline desta solução corporativa.

### Como interpretar as informações

| Identificação | Significado |
| --- | --- |
| Orientação institucional | Procedimento ou característica descrita no material institucional consultado |
| Observado | Resultado da instalação analisada, sem generalização para outras máquinas |
| Explicação técnica | Funcionamento geral da tecnologia, apoiado em documentação upstream quando necessário |
| Limite da evidência | Algo que o levantamento não demonstrou e que não deve ser presumido |

A documentação institucional define o que é ofertado e suportado; as evidências descrevem o que aconteceu nesta instalação. Quando a documentação não enumera detalhes, o guia preserva essa limitação. As [fontes e suas revisões](#fontes) permitem rastrear essas distinções.

### Onde executar os comandos

- **PowerShell do Windows:** comandos de instalação e gerenciamento do WSL. O texto indica quando abrir como administrador.
- **Pengwin Terminal:** comandos Linux e funções do Pengwin-CLI, em uma sessão zsh interativa.
- **VS Code do Windows:** instalação de extensões e abertura de uma janela conectada ao WSL.

Os blocos de código não incluem o símbolo do prompt. `$HOME` representa a pasta pessoal Linux. Exemplos com `NOME.service` ou outros nomes descritivos exigem substituição conforme o caso; não representam um componente real identificado.

Comandos de consulta podem exibir dados locais. Leia as saídas na própria máquina e compartilhe apenas informações revisadas. Instalações, atualizações, reconfigurações e criação de ambientes virtuais alteram o estado local; esses efeitos são identificados nas respectivas seções.

<a id="arquitetura"></a>
## 2. Arquitetura

**Orientação institucional:** a solução é composta pelo instalador Pengwin, pelas imagens WSL e pelo Pengwin-CLI.

| Camada | Papel |
| --- | --- |
| Windows | Sistema hospedeiro e ponto de instalação da solução |
| WSL2 | Infraestrutura para executar o ambiente Linux no Windows |
| Pengwin-WSL | Distribuição corporativa de trabalho, customizada a partir do Ubuntu, que contém ferramentas, arquivos e configurações Linux |
| Pengwin-CLI | Camada de comandos corporativos instalada dentro da distribuição |
| Instalador Pengwin | Aplicativo que ajusta a instalação, obtém a imagem e instala/configura o CLI e as ferramentas |
| Pengwin Terminal | Atalho para o perfil Pengwin-WSL no Windows Terminal |
| Pengwin-rede | Distribuição/componente separado, responsável por serviços de conectividade corporativa; sua operação interna não é documentada aqui |

**Observado:** a distribuição de trabalho está registrada como `Pengwin-WSL`, usa WSL2, identifica sua base como Ubuntu e executa um kernel Microsoft WSL2. O nome registrado, a versão do Ubuntu, a versão do kernel e a versão do CLI são informações distintas.

Para consultar as distribuições registradas, use **PowerShell do Windows, sem necessidade de elevação para a consulta**:

```powershell
wsl.exe --list --verbose
```

O nome da distribuição deve ser considerado ao abrir uma sessão. Executar apenas `wsl.exe` utiliza a distribuição padrão do usuário, que pode não ser a pretendida. [Comandos do WSL](https://learn.microsoft.com/en-us/windows/wsl/basic-commands).

<a id="instalacao"></a>
## 3. Instalação e primeira utilização

### 3.1. Pré-requisitos

**Orientação institucional:** o material consultado indica compatibilidade com Windows 11 e Ubuntu 24.04 LTS. Este guia cobre a instalação Windows/WSL; não descreve instalação em Ubuntu nativo. Windows 11 Enterprise foi a edição observada, não um requisito adicional identificado na fonte.

Antes da instalação:

1. Verifique **Gerenciador de Tarefas → Desempenho → CPU → Virtualização**. A virtualização deve estar habilitada.
2. Conclua as atualizações pendentes do Windows, observando o procedimento corporativo para a máquina ou VDI.
3. Garanta acesso aos canais institucionais de distribuição e autenticação, pela rede ou VPN aplicável.
4. Prepare o WSL conforme o procedimento abaixo, se ainda necessário.

**PowerShell do Windows como administrador — instala/atualiza componentes do WSL:**

```powershell
wsl --install --no-distribution
wsl --update
```

Conclua o processo e reinicie o Windows, conforme orientado pela documentação. A instalação do Pengwin depende da virtualização e do WSL operacional.

### 3.2. Instalação pelo Portal da Empresa

1. Abra o **Portal da Empresa** no Windows.
2. Procure **Pengwin** e solicite a instalação.
3. Abra o atalho **Pengwin** no Menu Iniciar ou na Área de Trabalho.
4. Siga as etapas do configurador, incluindo autenticação e seleção de pacotes quando apresentadas.
5. Ao concluir, abra o **Pengwin Terminal**.

Forneça dados de autenticação somente nos campos ou prompts próprios do configurador. Não copie esses dados para comandos, exemplos ou relatos de suporte.

### 3.3. Alternativa institucional por PowerShell

A documentação oferece o script abaixo quando o Portal da Empresa não está disponível ou apresenta dificuldades. O endereço é o de distribuição publicado no material institucional, não uma configuração de proxy.

**PowerShell de usuário do Windows — altera a política de execução do usuário e executa o instalador baixado:**

```powershell
$urlScript = "https://binarios.intranet.bb.com.br:443/artifactory/generic-bb-binarios-dev-local/publico/pengwin/scripts/instalar-pengwin.ps1"
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
Invoke-RestMethod $urlScript | Invoke-Expression
```

O procedimento executa código remoto e pode solicitar confirmação. Utilize o endereço institucional vigente e siga as instruções da instalação. Se a política corporativa impedir a execução, encaminhe o problema pelo suporte; não substitua o procedimento por um bypass de segurança.

Depois, abra o aplicativo **Pengwin**, conclua o configurador e abra o **Pengwin Terminal**. A obtenção atual do script não foi repetida durante a elaboração deste guia.

### 3.4. Primeira conferência

**Pengwin Terminal — consultas:**

```zsh
pwd
printf '%s\n' "$WSL_DISTRO_NAME"
ajuda
versao
```

Confirme que a sessão corresponde à distribuição pretendida e que a ajuda corporativa está acessível. `versao` informa a versão do CLI, não a versão do Ubuntu ou do WSL. Evite capturas do banner completo.

Para conferir ferramentas conforme os pacotes selecionados, consulte [componentes](#componentes), [Python](#python) e [Git/VS Code](#git-vscode). A ausência de uma ferramenta opcional não caracteriza falha de instalação.

<a id="terminal"></a>
## 4. Terminal e comandos corporativos

Abra o atalho **Pengwin Terminal** para o trabalho cotidiano. A documentação informa que o Windows Terminal é instalado por padrão e que o atalho seleciona o perfil da distribuição.

### 4.1. Zsh interativo e funções do CLI

**Observado:** o shell cadastrado do usuário é zsh. Os comandos corporativos são funções carregadas em sessões interativas; não foram encontrados como comandos disponíveis em todos os tipos de shell.

| Contexto examinado | Resultado para `ajuda`, `versao`, `proxyStatus` e `reconfigurar` |
| --- | --- |
| `zsh -lic` — login e interativo | Funções disponíveis |
| `zsh -ic` — interativo | Funções disponíveis |
| `zsh -lc` — login, não interativo | Não encontrados |
| `bash -lc` — login, não interativo | Não encontrados |

Isso explica por que um coletor ou script pode informar “comando não encontrado” enquanto o comando funciona no terminal. O resultado não prova ausência do Pengwin-CLI. A flag de login, sozinha, não reproduziu o ambiente interativo.

**Pengwin Terminal — consultas que não imprimem o corpo das funções:**

```zsh
ps -p $$ -o comm=
whence -w ajuda versao proxyStatus
```

`echo "$SHELL"` mostra a variável de shell, mas não necessariamente o processo que executa o comando. O coletor da exploração, por exemplo, rodava em bash mesmo com zsh configurado para o usuário.

Para uso humano, prefira uma sessão normal do Pengwin Terminal. A coleta não definiu uma interface suportada de automação não interativa; não copie funções ou conteúdo de arquivos de inicialização para contornar essa diferença.

### 4.2. Consultar ajuda e versão

Use `ajuda` para conhecer os comandos habilitados na instalação. A [referência rápida](#referencia) explica os comandos gerais relevantes para este guia. Outros comandos podem depender dos pacotes selecionados.

Quando uma orientação não coincidir com a ajuda local, registre a versão do CLI e confira a documentação institucional correspondente antes de executar uma alteração.

<a id="arquivos"></a>
## 5. Arquivos e integração Windows

### 5.1. HOME Linux e unidade Windows

**Orientação institucional:** utilize o terminal e a HOME do WSL para o trabalho com ferramentas Linux; evite a manipulação cotidiana de arquivos WSL pelo Windows Explorer.

**Observado:** a HOME está em ext4; `/mnt/c` está disponível como acesso à unidade Windows. São ambientes de filesystem distintos.

**Pengwin Terminal — navegação e consulta:**

```zsh
cd "$HOME"
pwd
df -h . /mnt/c
```

`cd` muda apenas o diretório da sessão. `df` consulta espaço; seus valores são momentâneos e não representam capacidade mínima exigida pelo Pengwin. Não interprete o tamanho virtual apresentado pelo filesystem como espaço físico garantido no Windows.

Use `/mnt/c` quando precisar acessar arquivos do Windows. Para atividades Linux, mantenha a orientação institucional de utilizar a HOME. Não altere permissões ou opções de montagem apenas para reproduzir valores de outra máquina.

### 5.2. PATH e interoperabilidade

**Observado:** `appendWindowsPath=false`, registro WSLInterop habilitado e execução de `cmd.exe` por caminho absoluto bem-sucedida. `code` também estava acessível.

As configurações tratam de capacidades diferentes: montagem disponibiliza arquivos; interoperabilidade permite iniciar processos Windows; `appendWindowsPath` controla a inclusão automática de diretórios Windows no PATH. Portanto, `/mnt/c` e a interoperabilidade podem funcionar mesmo quando `cmd.exe`, `powershell.exe` e `explorer.exe` não são encontrados pelo nome curto. [Configuração do WSL](https://learn.microsoft.com/en-us/windows/wsl/wsl-config).

A origem exata da disponibilização de `code` não foi estabelecida como padrão corporativo. Sua presença não significa que todo o PATH do Windows tenha sido importado.

Uma verificação pontual de execução Win32, caso necessária em suporte, é **Pengwin Terminal**:

```zsh
/mnt/c/Windows/System32/cmd.exe /d /c ver
```

Esse comando consulta a versão do Windows por um executável com caminho absoluto. Não é necessário modificar `appendWindowsPath` para realizá-lo.

<a id="conectividade"></a>
## 6. Proxy e certificados

### 6.1. Operação institucional

O Pengwin configura conectividade e certificados para a infraestrutura corporativa. A documentação descreve o uso do proxy Windows/NTLM como padrão no WSL a partir da versão 1.8.0 e oferece comandos para alternar o modo Stunnel. Essa informação corresponde à revisão institucional consultada; não é uma regra do WSL em geral.

**Observado:** o terminal da instalação analisada utilizava NTLM, em concordância com essa descrição. DNS público e corporativo responderam nos testes realizados.

**Pengwin Terminal — consulta de status com checagem de conexão:**

```zsh
proxyStatus
```

Leia o resultado localmente. Ele pode apresentar endereços ou informações da configuração e não deve ser copiado integralmente para documentação ou atendimento.

Os controles disponíveis estão na [referência de comandos](#referencia). `proxyOn`, `proxyOff`, `proxyStunnelOn` e `proxyStunnelOff` alteram o modo de conectividade; não são testes de saúde. Escolha o modo previsto para o seu vínculo e rede, conforme orientação institucional. Não alterne modos apenas para tentar eliminar uma mensagem de erro.

### 6.2. Troca de senha e certificados

**Orientação institucional:** após trocar a senha no SISBB, execute no **Pengwin Terminal**:

```zsh
reconfigurar
```

Esse comando solicita novamente os dados necessários e reconfigura as ferramentas; a documentação informa que também instala os certificados mais recentes. Ele altera configurações e pode atualizar credenciais armazenadas. A fonte orienta realizar essa atualização após a troca de senha para evitar tentativas com credenciais antigas e bloqueios.

A documentação de suporte cita as autoridades **AC Raiz v3**, **AC Servidores v3** e **AC Usuários v3**, e remete ao [portal institucional de PKI](https://pki.bb.com.br). Esses nomes reproduzem a referência institucional consultada, não uma lista de certificados cuja presença individual foi comprovada na máquina. Certificados e cadeias podem ser renovados; siga a orientação institucional vigente.

**Observado:** havia trust store Linux e o pacote `ca-certificates`; conexões HTTPS foram validadas sem desativar a verificação. A existência de certificados no Windows, isoladamente, não demonstra a confiança usada por cada cliente Linux. Não foi comprovado um mecanismo universal de sincronização entre os dois sistemas.

### 6.3. O alcance dos testes TLS

No levantamento, o GitHub respondeu HTTP 200 e o serviço corporativo de binários respondeu HTTP 302, ambos com validação TLS bem-sucedida. O segundo resultado confirma a conexão ao servidor que redirecionou; não comprova acesso ao destino final ou download de artefatos.

Uma consulta pública curta, para uso pontual em troubleshooting, é **Pengwin Terminal**:

```zsh
curl --fail --silent --show-error \
  --connect-timeout 10 --max-time 30 \
  --output /dev/null \
  --write-out 'HTTP %{http_code} | TLS %{ssl_verify_result}\n' \
  https://github.com/
```

O comando faz uma requisição de rede e descarta o corpo. HTTP 200 com conclusão sem erro é o resultado esperado para esse exemplo. O sucesso vale para esse cliente, destino e momento. Não comprova, sozinho, o uso de uma CA corporativa ou o caminho de proxy de outro programa.

O curl verifica certificados por padrão; falhas devem ser investigadas pela cadeia, destino e configuração utilizados. Não use `-k`/`--insecure` como correção ou critério de aprovação de TLS. [Verificação TLS no curl](https://curl.se/docs/sslcerts.html).

Git, APT, pip e ferramentas instaladas manualmente podem depender de configurações próprias. A fonte institucional também reconhece a necessidade de analisar individualmente falhas de ferramentas adicionadas pelo usuário.

<a id="componentes"></a>
## 7. Componentes e pacotes

### 7.1. Classificação

| Categoria | Como identificar | O que se pode afirmar |
| --- | --- | --- |
| Infraestrutura Windows/WSL | Windows, WSL2 e kernel | Sustentam a execução do ambiente |
| Pengwin-WSL | Distribuição corporativa registrada | É o ambiente de trabalho Linux |
| Pengwin-CLI | Camada corporativa de comandos | Oferece operações documentadas para o terminal |
| Core | Pacote denominado `core` pela documentação | É descrito como sempre instalado |
| Shared | Componente denominado `shared` | Contém funções compartilhadas; não é um catálogo de ferramentas do usuário |
| Opcionais | Pacotes explicitamente oferecidos para seleção | Sua presença depende da instalação escolhida |
| Ferramentas observadas | Executáveis ou versões encontrados localmente | Estavam disponíveis nesta instalação; isso não comprova a origem da instalação ou pertencimento ao core |
| Integrações externas | Produtos e serviços acessados pelo ambiente | Possuem configuração e ciclo de atualização próprios |

**Limite documental:** o material fornecido declara que `core` é sempre instalado, mas não enumera exaustivamente seu conteúdo. Este guia não atribui automaticamente Git, Docker, Node, Java ou Python a esse pacote.

### 7.2. Catálogo opcional documentado

Os nomes abaixo são identificadores de pacotes institucionais, apresentados apenas como catálogo de instalação.

| Pacote | Capacidade descrita no material |
| --- | --- |
| `pyenv` | Gerenciamento de versões Python |
| `plataforma` | Conjunto com nvm, Node e utilitário de integração associado |
| `arq3` | Conjunto com Java, Maven, Docker e ferramentas Kubernetes/OpenShift |
| `mobile` | Conjunto de ferramentas Android/Node/JDK; classificado como beta na documentação |
| `wl-plat` | Conjunto WebLogic |

Selecione capacidades pelo fluxo institucional do Pengwin e por sua documentação. A composição e versões dos conjuntos não devem ser deduzidas das versões locais. Este guia não detalha seu uso em aplicações.

### 7.3. Pacote Pengwin versus programa APT

`instalar <nome_programa>` é um facilitador para instalar um programa dos repositórios APT. A documentação diz expressamente que ele **não instala pacotes do Pengwin**.

Portanto, não interprete `instalar pyenv` como a forma institucional de selecionar o pacote opcional `pyenv`. O material aponta a oferta desse opcional, mas não contém todas as telas atuais de seleção nem um procedimento específico completo para adicioná-lo a uma instalação existente. Consulte o catálogo/README do CLI na plataforma institucional quando precisar dessa alteração.

<a id="python"></a>
## 8. Python, pyenv e ambientes virtuais

### 8.1. As três informações que devem permanecer separadas

| Aspecto | Informação |
| --- | --- |
| Capacidade ofertada | Pyenv é um pacote opcional documentado |
| Configuração observada | Pyenv instalado, com Python de desenvolvimento 3.12.5 selecionado |
| Baseline institucional | Não foi identificado requisito para que toda instalação tenha pyenv ou Python 3.12.5 |

O Python de desenvolvimento gerenciado pelo pyenv é separado do Python fornecido pelo Ubuntu. Não substitua `/usr/bin/python3` nem altere seus links para selecionar uma versão de desenvolvimento.

### 8.2. Identificar o interpretador selecionado

Se o opcional pyenv estiver instalado, consulte no **Pengwin Terminal**:

```zsh
pyenv versions
pyenv version
pyenv which python
python --version
python -m pip --version
/usr/bin/python3 --version
```

Os comandos consultam estado; alguns mostram caminhos locais, que devem ser sanitizados antes de compartilhar. A consulta ao Python do Ubuntu pode apresentar versão diferente daquela de `python` sem que exista um defeito.

O pyenv usa shims no PATH para encaminhar a execução ao interpretador selecionado. Sua seleção considera, entre outros fatores, variável de ambiente, configuração local e configuração global; por isso o diretório e o contexto de shell podem mudar o resultado. Use `pyenv version` para identificar a seleção efetiva. Não execute `pyenv global` com uma versão apenas para igualar o snapshot deste guia. [Funcionamento do pyenv](https://github.com/pyenv/pyenv#how-it-works).

### 8.3. Criar um ambiente virtual independente

O exemplo usa somente o módulo `venv` do Python; não pressupõe instalação de plugin `pyenv-virtualenv`. Execute em um diretório Linux de trabalho no qual `.venv` ainda não exista. **Os comandos criam arquivos nesse diretório.**

**Pengwin Terminal — primeiro confira o Python; depois crie e ative:**

```zsh
python --version
python -m venv .venv
source .venv/bin/activate
python --version
python -m pip --version
python -c 'import sys; print("Ambiente virtual ativo:", sys.prefix != sys.base_prefix)'
```

Confirme a versão desejada antes da criação. Após ativar, o último comando deve informar `True`. Para sair do ambiente virtual:

```zsh
deactivate
```

`deactivate` desfaz a ativação na sessão; não remove `.venv`. O ambiente virtual tem seus próprios pacotes e fica associado ao Python usado na criação. Ao mudar de interpretador-base, recrie o ambiente conforme necessário, em vez de presumir que uma seleção posterior do pyenv atualize um venv existente. [Documentação Python 3.12 — venv](https://docs.python.org/3.12/library/venv.html).

**Observado:** a criação e execução de um venv com Python 3.12.5 e pip funcionaram. Isso não valida acesso a índices pip, instalação de dependências, extensões nativas ou bibliotecas específicas. Não foi definido nesta coleta um índice pip institucional padrão; utilize a orientação corporativa correspondente e nunca coloque credenciais na linha de comando.

<a id="git-vscode"></a>
## 9. Git e VS Code com WSL

### 9.1. Git Linux por HTTPS

**Observado:** Git 2.43.0 disponível e operação `git ls-remote` por HTTPS bem-sucedida contra um repositório público. O teste é independente de arquivos de trabalho e não requer clonar um repositório.

**Pengwin Terminal — consulta local e leitura remota:**

```zsh
git --version
GIT_TERMINAL_PROMPT=0 git ls-remote --exit-code \
  https://github.com/WhitewaterFoundry/Pengwin.git HEAD
```

Espera-se uma referência `HEAD` acompanhada do identificador do commit e conclusão sem erro. O identificador muda ao longo do tempo; não deve ser fixado como valor de aceite. `--exit-code` permite distinguir ausência de referência correspondente. A variável desativa prompts de terminal do Git, mas não constitui garantia universal sobre interfaces de helpers externos. [Referência de git ls-remote](https://git-scm.com/docs/git-ls-remote).

Esse repositório foi apenas o alvo público utilizado na exploração. Não é um endpoint de homologação corporativa nem fonte do baseline deste guia. Não foi fornecido um repositório institucional específico para teste autenticado; não se deve inventar um endereço ou utilizar um repositório privado arbitrário.

O resultado público não comprova acesso privado, permissões de escrita, autenticação corporativa ou Git por SSH. A identidade de autoria configurada no Git também não comprova autenticação no servidor.

**Cuidado com credenciais:** a coleta registrou o helper `store`, sem ler credenciais. Esse helper armazena credenciais sem criptografia, conforme a documentação do Git. Sua presença foi observada; não é recomendação de configuração nem confirmação de que existam credenciais gravadas. Não exponha seus arquivos e consulte a orientação institucional antes de alterar o mecanismo. [Git credential-store](https://git-scm.com/docs/git-credential-store).

### 9.2. VS Code do Windows conectado ao WSL

**Orientação institucional:** mantenha o VS Code atualizado e confira a instalação do pacote de extensões **Remote Development**, identificador `ms-vscode-remote.vscode-remote-extensionpack`. Reinicie o VS Code após a instalação.

A documentação consultada também orienta selecionar `wslExeProxy` em **Remote.WSL2: Connection Method**, se essa configuração existir. Se não existir na versão instalada, a própria fonte manda ignorar essa etapa; não crie uma chave de configuração presumida.

No **Pengwin Terminal**, consulte o launcher e abra o diretório Linux que deseja editar:

```zsh
code --version
code .
```

`code .` abre a interface e pode iniciar ou instalar componentes auxiliares do VS Code no WSL. Confirme na janela o indicador de conexão **WSL: Pengwin-WSL**. O diretório aberto deve ser aquele selecionado no terminal.

**Limite da evidência:** o launcher estava disponível e informou versão. A coleta declara que a abertura com `code .` não foi executada automaticamente. Portanto, abertura da janela remota, download do VS Code Server e funcionamento das extensões não são apresentados como testes concluídos.

Se o terminal integrado não reconhecer funções corporativas, verifique se está no WSL e utiliza zsh interativo. A disponibilidade de `code` e a importação do PATH do Windows são assuntos distintos, conforme [integração de arquivos e processos](#arquivos).

<a id="manutencao"></a>
## 10. Atualização e manutenção

### 10.1. O que cada atualização alcança

| Ação | Alcance documentado |
| --- | --- |
| Atualizar WSL pelo Windows | Infraestrutura WSL; não equivale à atualização do CLI |
| Atualizar o aplicativo Pengwin no Windows | Aplicativo instalador; ainda é necessário seguir o fluxo de atualização da distribuição |
| Atualizar a instalação pelo aplicativo Pengwin | Atualiza/configura a distribuição e o CLI conforme a opção escolhida |
| Executar `atualizar` no terminal | Programas e bibliotecas instalados via APT |
| Executar `reconfigurar` | Dados, configurações das ferramentas e certificados conforme o fluxo institucional |

### 10.2. Atualizar pelo aplicativo Pengwin

**Orientação institucional — procedimento com alterações no ambiente:**

1. Atualize o aplicativo pelo Portal da Empresa ou repita a alternativa institucional de instalação por PowerShell, conforme o canal usado.
2. Abra o atalho **Pengwin**, conclua a autenticação e examine as opções oferecidas.
3. Escolha a ação pelo efeito pretendido, observando a tabela abaixo.
4. Conclua o configurador e reabra o Pengwin Terminal para consultar `versao` e a ajuda local.

| Opção institucional | Efeito e cuidado |
| --- | --- |
| Atualizar a existente | Usa a imagem atual, atualiza o CLI e reconfigura ferramentas. A fonte ressalva que a atualização pode não ser possível entre determinadas versões |
| Remover e instalar uma nova | Remove a imagem atual e instala uma nova. Pode eliminar arquivos e configurações locais; exige preservação prévia do que for necessário |
| Fazer backup e instalar uma nova | Faz backup da imagem atual antes da substituição. A fonte informa que o backup não é restaurado automaticamente; o usuário pode recuperar arquivos seletivamente |

Antes de substituir ou remover a imagem, confirme que os dados necessários estão preservados e recuperáveis. Não confunda “backup criado” com “dados restaurados”. O material disponível não detalha localização, retenção e procedimento completo de restauração; confirme essas informações no fluxo vigente antes de depender desse backup.

### 10.3. Programas APT

**Pengwin Terminal — execute somente a operação desejada, pois altera pacotes:**

- `atualizar`: atualiza programas e bibliotecas APT.
- `corrigir`: corrige instalações de programas APT; use para esse tipo de falha, não como reparo genérico do WSL.
- `instalar <nome_programa>`: instala o programa APT informado, com tentativas adicionais em caso de falha, conforme a fonte.

A sintaxe completa está na [referência](#referencia). Não use esses comandos como sinônimos de atualização da imagem ou seleção de pacotes opcionais Pengwin.

**Limite da evidência APT:** a coleta consultou pacotes atualizáveis usando os índices locais existentes e não executou `apt-get update`. O resultado de zero pacotes atualizáveis não certifica que todos os repositórios estavam acessíveis nem que os índices eram recentes. Da mesma forma, presença de arquivos de repositório não comprova sua autenticação ou integridade operacional.

### 10.4. Privilégios e encerramento do WSL

Privilégios administrativos no Windows e `sudo` dentro do Linux são contextos diferentes. A coleta identificou `sudo`, mas não testou uma autenticação interativa bem-sucedida; não se presume execução sem senha.

Fechar uma janela de terminal não é garantia de encerramento de toda a infraestrutura WSL. Quando uma instrução institucional exigir desligamento completo, salve o trabalho e finalize atividades em todas as distribuições antes de executar no **PowerShell do Windows**:

```powershell
wsl --shutdown
```

Esse comando interrompe todas as distribuições WSL em execução. Não é parte da verificação básica de saúde e não deve ser executado automaticamente em uma coleta. [Configuração e reinicialização do WSL](https://learn.microsoft.com/en-us/windows/wsl/wsl-config).

<a id="suporte"></a>
## 11. Troubleshooting, diagnóstico e suporte

### 11.1. Comece pelo sintoma

| Sintoma | Primeira verificação | Como interpretar |
| --- | --- | --- |
| `ajuda` ou `versao` não encontrados | Abra o Pengwin Terminal; consulte o tipo com `whence -w` em zsh | A diferença interativo/não interativo pode explicar o resultado |
| Ferramenta não encontrada | Consulte os pacotes selecionados e a ajuda | Uma ferramenta opcional pode não estar instalada |
| Executável Windows não encontrado pelo nome | Considere `appendWindowsPath=false` e o caminho absoluto | Ausência no PATH não significa interop desabilitado |
| DNS ou HTTPS falha | Confira rede/VPN e `proxyStatus` localmente | Identifique o cliente e destino que falham; não generalize |
| Erro de certificado | Registre o erro sem credenciais e verifique o procedimento institucional de certificados | Não desative a verificação TLS |
| Falha após troca da senha corporativa | Utilize o fluxo `reconfigurar` | É uma alteração documentada, não mera consulta |
| Python inesperado | Consulte `pyenv version`, `python --version` e o estado do venv | Seleção pyenv, venv ativo e Python do Ubuntu são distintos |
| Falha em pacotes APT | Registre a operação e a mensagem; consulte a orientação de manutenção | `corrigir` trata instalações APT, não toda a distribuição |
| `code` existe, mas conexão WSL falha | Confira extensão e contexto remoto conforme a seção VS Code | Launcher disponível não prova funcionamento do servidor remoto |
| `systemd` em `degraded` | Liste as unidades falhas | Classifique a unidade antes de concluir sobre o impacto |

Execute verificações pontuais quando houver um problema. Não é necessário repetir todo o levantamento para usar o ambiente.

### 11.2. Estado systemd degraded

**Observado:** systemd é PID 1 e o estado `degraded` foi registrado. A causa não foi determinada nas evidências consolidadas. Não se deve descrevê-lo como estado saudável, padrão obrigatório ou falha fatal de toda a distribuição.

Para identificar unidades falhas, use **Pengwin Terminal — somente consulta**:

```zsh
systemctl is-system-running
systemctl --failed --all --no-pager
```

Se houver uma unidade relevante, substitua `NOME.service` pelo nome exibido e consulte:

```zsh
systemctl status NOME.service --no-pager
journalctl --boot --unit NOME.service --lines 100 --no-pager
```

O acesso aos logs pode depender de permissões. Saídas de status e journal podem conter dados sensíveis; revise-as antes de compartilhar. Não use `reset-failed` para esconder o indicador antes de compreender a causa. Caso seja necessário analisar o gerenciador do usuário, a consulta correspondente é `systemctl --user --failed --no-pager`; ele é distinto do gerenciador de sistema.

Essa orientação serve para localizar a falha. Reiniciar, desabilitar ou mascarar uma unidade exige avaliar sua função; nenhuma dessas ações é prescrita como correção universal.

### 11.3. Preparação do atendimento

**Orientação institucional:** consulte a documentação de ajuda, pesquise issues semelhantes e utilize o template institucional ao iniciar atendimento. Informe:

1. Qual operação falhou e em qual contexto: PowerShell, Pengwin Terminal ou VS Code.
2. O resultado esperado, o ocorrido e passos mínimos para reproduzir.
3. A versão do CLI e informações de ambiente pertinentes, sem banner completo.
4. Se houve mudança recente de senha, atualização, rede/VPN ou pacote, sem revelar dados de autenticação.
5. Apenas os trechos revisados de erro e anexos necessários.

Os links completos do sistema de issues e do template não foram preservados no material fornecido. Acesse-os pela documentação do Pengwin na plataforma institucional techbb; não encaminhe automaticamente informações corporativas para o repositório público usado no teste de Git.

### 11.4. Diagnóstico e logs: revisar antes de compartilhar

**Pengwin Terminal — coleta e criação de arquivos de diagnóstico:**

```zsh
diagnosticar
```

Conforme a documentação, esse comando executa verificações extensas e compacta o resultado com logs recentes da instalação. **Ele também captura conteúdo de `.bashrc`, `.zshrc` e `.profile`.** Portanto, não equivale a uma consulta pequena nem produz automaticamente um anexo seguro para divulgação.

Para localizar os logs do aplicativo, o comando institucional é:

```zsh
mostrarLogs
```

Ele abre a pasta de logs; não sanitiza seu conteúdo. Antes de qualquer compartilhamento:

- Revise relatórios, arquivos incluídos, capturas de tela e saídas de inicialização.
- Remova senhas, tokens, PATs, credenciais, dados pessoais, caminhos identificáveis, valores de proxy e cabeçalhos de autenticação.
- Não envie arquivos completos de configuração ou inicialização apenas porque vieram no pacote de diagnóstico.
- Preserve o erro necessário para análise e use o canal institucional adequado.

Não coloque segredos diretamente nos arquivos de inicialização. A recomendação da fonte de separar conteúdo em outro arquivo não deve ser interpretada como garantia de que o diagnóstico esteja livre de segredos: outros comandos, logs e banners podem exibi-los. Este guia não reproduz conteúdo de `.gitconfig`, `.npmrc`, `.docker/config.json`, arquivos SSH ou arquivos de inicialização.

<a id="referencia"></a>
## 12. Referência rápida de comandos

### 12.1. Pengwin-CLI

Execute em **Pengwin Terminal, zsh interativo**. As finalidades abaixo vêm da seção institucional “Comandos disponíveis no CLI”; a disponibilidade das treze funções gerais foi observada na instalação analisada. Esta tabela é referência, não uma sequência para executar integralmente.

| Comando | Finalidade documentada | Efeito/cuidado | Detalhes |
| --- | --- | --- | --- |
| `ajuda` | Mostra resumo dos comandos habilitados | Consulta; disponibilidade depende da instalação | [Terminal](#terminal) |
| `versao` | Mostra a versão do Pengwin-CLI | Consulta; não confundir com imagem ou kernel | [Terminal](#terminal) |
| `reconfigurar` | Atualiza dados e configura ferramentas; instala certificados recentes | Altera configuração e solicita dados do usuário | [Proxy e certificados](#conectividade) |
| `diagnosticar` | Produz e compacta diagnóstico com logs de instalação | Executa verificações e cria arquivos; captura dados extensos | [Diagnóstico e suporte](#suporte) |
| `atualizar` | Atualiza programas e bibliotecas via APT | Altera pacotes; não substitui atualização pelo aplicativo | [Manutenção](#manutencao) |
| `corrigir` | Corrige instalações de programas APT | Pode alterar estado de pacotes | [Manutenção](#manutencao) |
| `instalar <nome_programa>` | Instala um programa APT; a fonte prevê três tentativas em caso de falha | Substituir o argumento; não instala pacotes opcionais Pengwin | [Componentes](#componentes) |
| `mostrarLogs` | Abre diretório dos logs de execução do aplicativo | Abre interface/pasta; não anonimiza logs | [Suporte](#suporte) |
| `proxyStatus` | Mostra status por serviço/ferramenta e verifica conexão | Consulta com tráfego de rede; saída pode conter dados locais | [Conectividade](#conectividade) |
| `proxyOn` | Habilita uso das credenciais do usuário no proxy corporativo | Altera conectividade; observar vínculo/rede | [Conectividade](#conectividade) |
| `proxyOff` | Desabilita esse uso de credenciais no proxy corporativo | Não comprova remoção de toda configuração de proxy de todo programa | [Conectividade](#conectividade) |
| `proxyStunnelOn` | Habilita Stunnel para autenticação no proxy no WSL | Altera modo de conectividade | [Conectividade](#conectividade) |
| `proxyStunnelOff` | Desabilita Stunnel e utiliza o modo proxy Windows descrito na fonte | Altera modo de conectividade | [Conectividade](#conectividade) |

Existem comandos adicionais associados a pacotes e finalidades específicas. Consulte `ajuda` e o README institucional do CLI para o catálogo aplicável; a tabela acima se limita à operação geral do ambiente.

### 12.2. Consultas de identidade

**PowerShell do Windows — consultas, sem alteração da configuração:**

```powershell
wsl.exe --version
wsl.exe --status
wsl.exe --list --verbose
```

Essas consultas distinguem a versão do WSL, seu estado/configuração geral e as distribuições registradas. A versão do pacote WSL não pode ser deduzida apenas do número do kernel. [Comandos básicos do WSL](https://learn.microsoft.com/en-us/windows/wsl/basic-commands).

**Pengwin Terminal — consultas da base e do kernel:**

```zsh
grep -E '^(NAME|VERSION|VERSION_ID|PRETTY_NAME)=' /etc/os-release
uname -r
uname -m
```

Esses comandos não substituem `versao`, que consulta o CLI. `wslsys` não foi encontrado na instalação analisada e não é requisito de validação deste guia. A ausência de utilitários do Pengwin público não é critério para reprovar a solução corporativa.

<a id="ambiente-observado"></a>
## 13. Ambiente de referência observado

### 13.1. Identidade e versões

Snapshot da coleta de **10/09/2026**. Os valores são transcritos de forma seletiva e sem identificadores pessoais. A versão de um pacote de distribuição pode incluir revisão diferente da versão curta exibida pelo programa.

| Item | Valor observado | Alcance |
| --- | --- | --- |
| Windows | Windows 11 Enterprise, build 26100 | Edição/build local |
| Infraestrutura | WSL2 | Modo da distribuição; versão do pacote WSL não consolidada |
| Distribuição registrada | `Pengwin-WSL` | Nome local no WSL |
| Base Linux | Ubuntu 24.04.5 LTS | Identificação de `/etc/os-release` |
| Kernel | `6.6.87.2-microsoft-standard-WSL2` | Kernel em execução |
| Arquitetura | x86_64 | Arquitetura local |
| Shell cadastrado | zsh 5.9 | Não implica que todo script rode em zsh |
| Pengwin-CLI | 1.10.1 | Camada corporativa, não versão de toda a solução |
| Init | systemd como PID 1 | Estado `degraded` registrado, sem causa consolidada |
| Git | 2.43.0 | Executável Linux utilizado no teste HTTPS |
| Python de desenvolvimento | 3.12.5 via pyenv | Seleção local, não requisito institucional |
| Pyenv | 2.4.10 | Opcional presente na instalação |
| Pip do Python selecionado | 24.2 | Consulta e disponibilidade no venv |
| Pacote Ubuntu `python3` | `3.12.3-0ubuntu2.1` | Versão de pacote registrada; não confundir com o Python pyenv |
| Curl / OpenSSL | 8.5.0 / 3.0.13 | Ferramentas locais |
| APT | 2.8.3 | Gerenciador presente |
| VS Code consultado pelo launcher | 1.137.0 | Abertura remota não testada na coleta |
| HOME / unidade Windows | ext4 / `/mnt/c` disponível | Contextos de filesystem distintos |
| Interoperabilidade | WSLInterop habilitado; `appendWindowsPath=false` | Execução Win32 absoluta funcionou |
| Locale | `pt_BR.UTF-8` | Configuração local; não inferir padrão universal |

Outras ferramentas encontradas incluem Node/npm, OpenJDK/Maven, Docker CLI, clientes Kubernetes/OpenShift, GitHub CLI, compiladores GNU, make, jq, pipx e OpenSSH. Sua presença não estabelece pertencimento ao core nem valida serviços, clusters, autenticação ou execução de cargas. As versões desses componentes secundários não são fixadas como recomendações neste guia.

### 13.2. Capacidades e limites

| Área | Evidência | O que permanece fora dessa conclusão |
| --- | --- | --- |
| CLI | Funções gerais disponíveis no zsh interativo | Interface suportada de automação não interativa |
| Proxy | Modo terminal NTLM identificado | Configuração efetiva de todo cliente e rede possível |
| DNS | Resolução pública e corporativa funcionou | Todos os domínios, VPNs e momentos |
| HTTPS público | HTTP 200, TLS verificado | Autenticação em serviços privados |
| HTTPS corporativo | HTTP 302, TLS verificado | Destino após redirecionamento e download final |
| Trust store | Diretórios/pacote presentes e conexões TLS válidas | Inventário certificado por certificado ou sincronização Windows/Linux |
| Git | `ls-remote` público funcionou | Git privado, push, SSH e credenciais corporativas |
| Python | Seleção pyenv e criação/execução de venv funcionaram | Instalação via pip, índice corporativo ou extensões nativas |
| VS Code | Launcher disponível e versão obtida | Janela remota, servidor e extensões |
| APT | Inventário e consulta com índices locais | Atualização de índices, downloads e autenticação dos repositórios |
| Sudo | Comando disponível | Autenticação interativa bem-sucedida ou política sem senha |
| SSH | Cliente disponível | Chaves, agente, acesso remoto ou autenticação |
| Windows/WSL | `/mnt/c` acessível e execução Win32 absoluta | Todos os fluxos de integração e rede entre os sistemas |

Esses limites não impedem o uso do guia. Evitam que uma consulta parcial seja apresentada como validação completa. CPU, memória e espaço variam entre máquinas e sessões; não foram convertidos em requisitos mínimos.

<a id="fontes"></a>
## 14. Fontes e controle documental

### 14.1. Fontes institucionais e evidências

| Material de origem | Uso nesta edição | Limite |
| --- | --- | --- |
| `ambiente_pengwin.md` | Compilação institucional: instalação, atualização, arquitetura, terminal, CLI, pacotes, VS Code, proxy, certificados e suporte | Data/revisão institucional original não identificada; diversos links aparecem apenas como referências textuais |
| `pengwin-wsl-exploracao.txt` | Evidências selecionadas de identidade, shells, ferramentas, TLS, Git, Python, filesystem e interop | Contém coleta extensa; não é anexo de distribuição deste guia |
| Esclarecimentos da exploração fornecidos pelo responsável | Consolidação do estado final e limites editoriais | Tratados como observação informada, sem promovê-los a política institucional |

O conteúdo necessário para uso do guia foi consolidado neste arquivo. Os materiais brutos não precisam acompanhá-lo e não devem ser compartilhados sem revisão. Nenhum banner de autenticação foi incorporado.

A fonte institucional indica a plataforma **techbb**, o README do **Pengwin-CLI**, o histórico de mudanças e o sistema de issues como referências. Endereços ausentes na compilação não foram reconstruídos por suposição. Consulte esses canais institucionais para mudanças posteriores à revisão disponível.

### 14.2. Documentação técnica complementar

As referências técnicas foram usadas para explicar a tecnologia, não para definir o baseline corporativo:

- [Microsoft — comandos básicos do WSL](https://learn.microsoft.com/en-us/windows/wsl/basic-commands).
- [Microsoft — configuração do WSL](https://learn.microsoft.com/en-us/windows/wsl/wsl-config).
- [Python 3.12 — ambientes virtuais](https://docs.python.org/3.12/library/venv.html).
- [Pyenv — funcionamento e seleção de versões](https://github.com/pyenv/pyenv#how-it-works).
- [Git — consulta de referências remotas](https://git-scm.com/docs/git-ls-remote).
- [Git — armazenamento de credenciais com store](https://git-scm.com/docs/git-credential-store).
- [Curl — verificação de certificados TLS](https://curl.se/docs/sslcerts.html).

### 14.3. Pendências documentais e atualização do guia

Esta edição não estabelece uma lista exaustiva do core, um índice pip padrão, um repositório corporativo de teste, uma política universal de credential helper, nem detalhes de recuperação do backup. Esses pontos dependem da documentação institucional correspondente. A causa do `systemd degraded` também permanece sem determinação nas evidências disponíveis.

Ao revisar o guia, atualize separadamente os requisitos institucionais e o snapshot observado. Preserve a data real de cada coleta, confirme efeitos de comandos alterados e mantenha as limitações dos testes. A revisão editorial desta edição não executou diagnósticos adicionais nem modificou o ambiente Pengwin-WSL.
