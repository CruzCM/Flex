# -*- encoding: utf-8 -*-
# Referência: https://packaging.python.org/guides/distributing-packages-using-setuptools/

import io
import re

from setuptools import find_packages, setup

common_requirements = [
    'pytest',
    'pytest-asyncio',
    'httpx>=0.27',
]

dev_requirements = [
    'bandit',
    'flake8',
    'isort',
    'langchain-azure-ai',
] + common_requirements

unit_test_requirements = common_requirements

integration_test_requirements = common_requirements

run_requirements = [
    'fastapi>=0.111.0',
    'uvicorn[standard]>=0.29.0',
    'pydantic>=2.7.0',
    'langgraph>=1.0.0',
    'langchain-core>=0.2',
    'langchain-openai>=0.1',
    'langchain-azure-ai',
    'openai>=1.30',
    'pyyaml>=6.0',
    'httpx>=0.27',
    'typing-extensions>=4.11',
    'azure-monitor-opentelemetry',
    'opentelemetry-sdk',
    'opentelemetry-distro',
    'opentelemetry-exporter-otlp',
]

with io.open('./plg_agent_consult_fin/__init__.py', encoding='utf8') as version_f:
    version_match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]",
                              version_f.read(), re.M)
    if version_match:
        version = version_match.group(1)
    else:
        raise RuntimeError("Não foi possível encontrar a string de versão.")

with io.open('README.md', encoding='utf8') as readme:
    long_description = readme.read()

setup(
    name="plg_agent_consult_fin",
    version=version,
    author="Banco do Brasil S.A.",
    author_email="ditec@bb.com.br",
    packages=find_packages(exclude=['tests', 'tests.*']),
    include_package_data=True,
    url="https://fontes.intranet.bb.com.br/plg/plg-agent-consult-fin/plg-agent-consult-fin",
    license="COPYRIGHT",
    description="Microsserviço do Educador Financeiro com Agent-Ops, LangGraph, RAG e guardrails locais.",
    long_description=long_description,
    zip_safe=False,
    install_requires=run_requirements,
    extras_require={
         'dev': dev_requirements,
         'unit': unit_test_requirements,
         'integration': integration_test_requirements,
    },
    python_requires='>=3.11',
    classifiers=[
        'Intended Audience :: Information Technology',
        'Natural Language :: Portuguese (Brazilian)',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3.11'
    ],
    keywords=[],
    entry_points={
        'console_scripts': [
            'plg_agent_consult_fin = plg_agent_consult_fin.__main__:main'
        ],
    },
)
