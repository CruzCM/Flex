# Material de referência histórico

Os arquivos desta pasta registram o ambiente e a implementação anteriores à simplificação para o Educador Financeiro.

Eles não descrevem o runtime atual e não são carregados pela aplicação, pelos testes, pela imagem Docker ou pela esteira. A especificação vigente do microsserviço está no `README.md` da raiz e em `agent_config.yaml`.
