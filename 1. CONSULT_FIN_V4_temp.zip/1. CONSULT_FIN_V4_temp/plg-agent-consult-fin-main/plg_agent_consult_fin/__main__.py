"""
__main__.py - Entrypoint for the AIOps Agent microservice.

Starts the FastAPI application with Uvicorn.

Usage:
  python -m plg_agent_consult_fin
  uvicorn plg_agent_consult_fin.app:app --host 0.0.0.0 --port 8000
"""

import sys
from pathlib import Path
import argparse
import logging
import warnings

import uvicorn

# Prepend the package directory so that intra-package imports of the form
# `from plg_agent_consult_fin.xxx import ...` resolve correctly regardless of how the process
# is launched (entry-point, `python -m`, or direct invocation).
_PKG_DIR = str(Path(__file__).parent)
if _PKG_DIR not in sys.path:
    sys.path.insert(0, _PKG_DIR)

_LOG_FORMAT = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"
_LOG_DATE_FMT = "%Y-%m-%dT%H:%M:%S"


class HealthCheckFilter(logging.Filter):
    """Filtra logs de requisições HTTP para /health/* e /metrics (health checks do K8s)."""

    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        # Silencia apenas GET /health/* e GET /metrics
        return not any(
            pattern in message
            for pattern in [
                "GET /health/live",
                "GET /health/ready",
                "GET /metrics",
            ]
        )


def main():
    """Run the App"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--log-level", default="info")
    args = parser.parse_args()

    # Silencia UserWarnings específicos do Azure Monitor e OpenTelemetry
    warnings.filterwarnings("ignore", category=UserWarning, module="azure.monitor.opentelemetry")
    warnings.filterwarnings("ignore", category=UserWarning, module="opentelemetry.instrumentation")
    warnings.filterwarnings("ignore", category=UserWarning, module="azure.ai.projects.telemetry")

    logging.basicConfig(
        level=args.log_level.upper(),
        format=_LOG_FORMAT,
        datefmt=_LOG_DATE_FMT,
        force=True,
    )

    # Silencia logs verbosos do Azure SDK (HTTP requests, statsbeat, quickpulse)
    logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.WARNING)
    logging.getLogger("azure.monitor.opentelemetry.exporter").setLevel(logging.WARNING)
    logging.getLogger("azure.ai.projects.telemetry").setLevel(logging.WARNING)
    logging.getLogger("urllib3.connectionpool").setLevel(logging.WARNING)

    # Adiciona filtro para silenciar health checks nos logs do uvicorn
    logging.getLogger("uvicorn.access").addFilter(HealthCheckFilter())

    uvicorn.run(
        "plg_agent_consult_fin.app:app",
        host=args.host,
        port=args.port,
        workers=args.workers,
        log_level=args.log_level,
        access_log=True,
    )


if __name__ == "__main__":
    main()
