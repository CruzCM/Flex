"""factory.py - Instancia o provedor LLM definido em agent_config.yaml.

Para adicionar um novo provedor:
  1. Crie plg_agent_consult_fin/llm/<nome>.py com classe herdando LLMProvider.
  2. Registre: LLMFactory.register("nome", MinhaClasse)
  3. Atualize agent_config.yaml: llm.provider: "nome"
"""

from __future__ import annotations

from typing import Dict, Type

from langchain_core.language_models import BaseChatModel

from plg_agent_consult_fin.llm.base import LLMProvider
from plg_agent_consult_fin.llm.gateway_outbound import GatewayOutboundProvider


class LLMFactory:
    _registry: Dict[str, Type[LLMProvider]] = {
        "gateway_outbound": GatewayOutboundProvider,
    }

    @classmethod
    def register(cls, name: str, provider_cls: Type[LLMProvider]) -> None:
        cls._registry[name] = provider_cls

    @classmethod
    def create(cls, provider: str, temperature: float, top_p: float) -> BaseChatModel:
        if provider not in cls._registry:
            raise ValueError(
                f"Provedor LLM desconhecido '{provider}'. "
                f"Disponíveis: {sorted(cls._registry)}"
            )
        return cls._registry[provider]().build(temperature, top_p)
