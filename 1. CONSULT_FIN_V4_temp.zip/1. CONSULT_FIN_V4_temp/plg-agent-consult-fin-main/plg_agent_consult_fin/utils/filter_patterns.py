"""filter_patterns.py - Verificações de guardrail baseadas em regex (injeção, PII, blocklist)."""

from __future__ import annotations

import re
from typing import Callable

_INJECTION_PATTERNS: list[re.Pattern] = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"ignore\s+(?:\w+\s+){0,3}instructions?",
        r"you\s+are\s+now\s+(?:a\s+)?(?:dan|jailbreak|evil|unrestricted)",
        r"disregard\s+(?:\w+\s+){0,3}(?:rules?|guidelines?|restrictions?|training)",
        r"pretend\s+(you\s+are|to\s+be)\s+(?:a\s+)?(?:human|person|unrestricted)",
        r"act\s+as\s+(?:if\s+you\s+(?:are|have\s+no))",
        r"do\s+anything\s+now",
        r"jailbreak",
        r"system\s*prompt\s*[:=]",
        r"<\s*system\s*>",
        r"\bDAN\b",
        r"tell\s+me\s+(your\s+)?system\s+prompt",
    ]
]


def _cpf_checksum_valid(digits: str) -> bool:
    """Validate CPF using the official modulus-11 algorithm."""
    if len(digits) != 11 or digits == digits[0] * 11:
        return False
    for i in (9, 10):
        total = sum(int(digits[j]) * ((i + 1) - j) for j in range(i))
        remainder = (total * 10) % 11
        if remainder == 10:
            remainder = 0
        if int(digits[i]) != remainder:
            return False
    return True


def _cnpj_checksum_valid(digits: str) -> bool:
    """Validate CNPJ using the official modulus-11 algorithm."""
    if len(digits) != 14:
        return False
    weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    total = sum(int(digits[i]) * weights1[i] for i in range(12))
    d1 = 0 if total % 11 < 2 else 11 - total % 11
    if int(digits[12]) != d1:
        return False
    total = sum(int(digits[i]) * weights2[i] for i in range(13))
    d2 = 0 if total % 11 < 2 else 11 - total % 11
    return int(digits[13]) == d2


# (regex, replacement, checksum_fn or None)
_PII_PATTERNS: list[tuple[re.Pattern, str, Callable[[str], bool] | None]] = [
    (re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"), "[EMAIL]", None),
    (re.compile(r"\b(?:\+?1[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}\b"), "[PHONE]", None),
    (re.compile(r"\b(?:\+55[\s\-.]?)?\(?\d{2}\)?[\s\-.]?9?\d{4}[\s\-.]?\d{4}\b"), "[PHONE]", None),
    (re.compile(r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"), "[SSN]", None),
    (re.compile(r"\b(?:\d[ \-]?){13,19}\b"), "[CARD]", None),
    # Documentos brasileiros
    (re.compile(r"\b(\d{3})[.\s-]?(\d{3})[.\s-]?(\d{3})[.\s-]?(\d{2})\b"), "[CPF]", _cpf_checksum_valid),
    (re.compile(r"\b(\d{2})[.\s-]?(\d{3})[.\s-]?(\d{3})[/.\s-]?(\d{4})[.\s-]?(\d{2})\b"), "[CNPJ]", _cnpj_checksum_valid),
]

_OUTPUT_BLOCKLIST: list[re.Pattern] = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"(my\s+)?system\s+prompt\s+is",
        r"as\s+an?\s+unrestricted",
        r"i\s+(can|will)\s+ignore\s+(my\s+)?guidelines",
    ]
]


def check_injection(text: str) -> str | None:
    for pattern in _INJECTION_PATTERNS:
        m = pattern.search(text)
        if m:
            return m.group(0)
    return None


def contains_pii(text: str) -> bool:
    for pattern, _, checksum_fn in _PII_PATTERNS:
        for m in pattern.finditer(text):
            if checksum_fn is None:
                return True
            digits = re.sub(r"\D", "", m.group(0))
            if checksum_fn(digits):
                return True
    return False


def redact_pii(text: str) -> str:
    for pattern, replacement, checksum_fn in _PII_PATTERNS:
        if checksum_fn is None:
            text = pattern.sub(replacement, text)
            continue

        def _replace(
            m: re.Match[str],
            _checksum_fn: Callable[[str], bool] = checksum_fn,
            _replacement: str = replacement,
        ) -> str:
            digits = re.sub(r"\D", "", m.group(0))
            if _checksum_fn(digits):
                return _replacement
            return m.group(0)

        text = pattern.sub(_replace, text)
    return text


def check_output_blocklist(text: str) -> str | None:
    for pattern in _OUTPUT_BLOCKLIST:
        m = pattern.search(text)
        if m:
            return m.group(0)
    return None
