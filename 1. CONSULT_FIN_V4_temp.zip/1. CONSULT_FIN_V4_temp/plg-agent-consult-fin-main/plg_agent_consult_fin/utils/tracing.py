"""tracing.py - OpenTelemetry bootstrap for on-premises deployment.

This module configures the OTel SDK so that:
  1. **Locally** it exports via OTLP (to an OTel Collector or directly).
  2. **Azure Foundry** integration is achieved by routing through the
     ``azure-monitor-opentelemetry-exporter`` → Application Insights.

The existing ``opentelemetry-distro`` auto-instrumentation remains the
primary TracerProvider / MeterProvider.  This module only:
  - Adds the Azure Monitor exporter **if** ``APPLICATIONINSIGHTS_CONNECTION_STRING``
    is set (dual-export: OTLP + App Insights).
  - Exposes convenience ``get_tracer`` / ``get_meter`` helpers used by the
    application and middleware.

Environment variables
---------------------
APPLICATIONINSIGHTS_CONNECTION_STRING   Enables Azure Monitor exporter.
OTEL_EXPORTER_OTLP_ENDPOINT            Standard OTLP collector endpoint.
OTEL_SERVICE_NAME                       Service name tag (default: agent).
"""

from __future__ import annotations

import logging
import os

from opentelemetry import metrics, trace

logger = logging.getLogger(__name__)

_APPINSIGHTS_CS = os.getenv("APPLICATION_INSIGHTS_CONNECTION_STRING", "")


def configure_azure_monitor() -> None:
    """Attach the Azure Monitor trace exporter when the connection string is present.

    **Note on metrics**: Dynamic attachment of metric readers after SDK bootstrap is
    not supported by opentelemetry-sdk and causes KeyError in the background
    PeriodicExportingMetricReader thread. Metrics export via OTLP (configured by
    opentelemetry-distro) is sufficient for on-premises deployments.

    Traces are still exported to Azure Insights via add_span_processor, which is safe.
    """
    if not _APPINSIGHTS_CS:
        logger.info("APPLICATION_INSIGHTS_CONNECTION_STRING not set - Azure Monitor exporter skipped")
        return

    try:
        from azure.monitor.opentelemetry.exporter import AzureMonitorTraceExporter
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        # -- Traces only --
        tracer_provider = trace.get_tracer_provider()
        if isinstance(tracer_provider, TracerProvider):
            az_trace_exporter = AzureMonitorTraceExporter(
                connection_string=_APPINSIGHTS_CS,
            )
            tracer_provider.add_span_processor(BatchSpanProcessor(az_trace_exporter))
            logger.info("Azure Monitor trace exporter attached")
        else:
            logger.warning(
                "TracerProvider is %s - cannot attach Azure Monitor exporter. "
                "Ensure opentelemetry-distro is configured first.",
                type(tracer_provider).__name__,
            )

        # Metrics are exported via OTLP by the distro; dynamic reader attachment
        # causes threading issues, so we skip metric attachment here.
    except ImportError:
        logger.warning(
            "azure-monitor-opentelemetry-exporter not installed - "
            "pip install azure-monitor-opentelemetry-exporter to enable App Insights trace export"
        )
    except Exception as exc:
        logger.warning("Failed to configure Azure Monitor trace exporter: %s", exc)


def get_tracer(name: str = "agent") -> trace.Tracer:
    """Return a named tracer from the global TracerProvider."""
    return trace.get_tracer(name)


def get_meter(name: str = "agent") -> metrics.Meter:
    """Return a named meter from the global MeterProvider."""
    return metrics.get_meter(name)
