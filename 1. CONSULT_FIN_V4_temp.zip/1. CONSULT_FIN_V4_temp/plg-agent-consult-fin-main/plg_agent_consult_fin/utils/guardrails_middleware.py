"""guardrails_middleware.py - Middleware Starlette para guardrails de entrada e saída.

Variáveis de ambiente opcionais:
    GUARDRAIL_MAX_INPUT_LEN     Sobrescreve o valor de agent_config.yaml
    GUARDRAIL_BLOCK_PROMPT_INJECTION Sobrescreve o valor de agent_config.yaml
    GUARDRAIL_BLOCK_PII_INPUT   Sobrescreve o valor de agent_config.yaml
    GUARDRAIL_REDACT_PII_OUTPUT Sobrescreve o valor de agent_config.yaml
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any, Awaitable, Callable

from opentelemetry import metrics, trace
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from plg_agent_consult_fin.config import get_config
from plg_agent_consult_fin.utils.filter_patterns import (
    check_injection,
    check_output_blocklist,
    contains_pii,
    redact_pii,
)

logger = logging.getLogger(__name__)

_tracer = trace.get_tracer("agent.guardrails")
_meter = metrics.get_meter("agent.guardrails")

_guardrail_requests = _meter.create_counter(
    "guardrail.requests",
    description="Total number of /chat requests processed by guardrails middleware",
)
_guardrail_blocks = _meter.create_counter(
    "guardrail.blocked",
    description="Total number of guardrail blocks by layer/rule",
)
_guardrail_redactions = _meter.create_counter(
    "guardrail.redactions",
    description="Total number of output redactions applied by guardrails",
)
_guardrail_latency = _meter.create_histogram(
    "guardrail.latency_ms",
    description="Guardrails middleware latency in milliseconds",
)

_profile_guardrails = get_config().guardrails
_MAX_INPUT_LEN: int = int(
    os.getenv("GUARDRAIL_MAX_INPUT_LEN", str(_profile_guardrails.max_input_length))
)
_BLOCK_PROMPT_INJECTION: bool = os.getenv(
    "GUARDRAIL_BLOCK_PROMPT_INJECTION",
    str(_profile_guardrails.block_prompt_injection),
).lower() == "true"
_BLOCK_PII_INPUT: bool = os.getenv(
    "GUARDRAIL_BLOCK_PII_INPUT", str(_profile_guardrails.block_pii_input)
).lower() == "true"
_REDACT_PII_OUTPUT: bool = os.getenv(
    "GUARDRAIL_REDACT_PII_OUTPUT", str(_profile_guardrails.redact_pii_output)
).lower() == "true"
_CHAT_ROUTE = "/chat"
_ATTR_ROUTE_KEY = "guardrail.route"

# Service identity injected into every metric as extra dimensions.
# Set SERVICE_NAME and DEPLOY_ENV in the container/pod environment.
_SERVICE_NAME: str = os.getenv("SERVICE_NAME", "")
_DEPLOY_ENV: str = os.getenv("DEPLOY_ENV", "")  # desenv | homol | prod
_EXTRA_ATTRS: dict = {
    k: v
    for k, v in [("service.name", _SERVICE_NAME), ("deploy.environment", _DEPLOY_ENV)]
    if v
}


class GuardrailsMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        if request.method == "POST" and request.url.path == _CHAT_ROUTE:
            return await self._guard_chat(request, call_next)
        return await call_next(request)

    async def _guard_chat(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        attrs_base = {_ATTR_ROUTE_KEY: _CHAT_ROUTE, **_EXTRA_ATTRS}
        _guardrail_requests.add(1, attrs_base)

        with _tracer.start_as_current_span("guardrails.middleware.chat", attributes=attrs_base) as span:
            t0 = time.perf_counter()
            body_bytes = await request.body()

            async def _replay_receive():
                return {"type": "http.request", "body": body_bytes, "more_body": False}

            request = Request(request.scope, _replay_receive)

            try:
                body = json.loads(body_bytes)
                message: str = body.get("message", "")
            except (json.JSONDecodeError, AttributeError):
                message = ""

            try:
                # 1. Verificacao de tamanho
                if len(message) > _MAX_INPUT_LEN:
                    logger.warning("Guardrail: entrada muito longa (%d chars)", len(message))
                    _record_block(span, code="input_too_long", layer="input")
                    return _blocked(
                        "input_too_long",
                        f"A mensagem excede o tamanho maximo permitido de {_MAX_INPUT_LEN} caracteres.",
                    )

                # 2. Verificacao de injecao de prompt / jailbreak
                matched = check_injection(message) if _BLOCK_PROMPT_INJECTION else None
                if matched:
                    logger.warning("Guardrail: injecao detectada: %r", matched)
                    _record_block(span, code="prompt_injection", layer="input")
                    return _blocked("prompt_injection", "A mensagem contem conteudo nao permitido.")

                # 3. PII na entrada
                if _BLOCK_PII_INPUT and contains_pii(message):
                    logger.warning("Guardrail: PII detectado na entrada")
                    _record_block(span, code="pii_detected", layer="input")
                    return _blocked(
                        "pii_detected",
                        "A mensagem parece conter informacoes pessoais (PII). "
                        "Por favor, remova-as antes de enviar.",
                    )

                response = await call_next(request)

                # 4. Guardrails locais de saída
                if response.status_code == 200 and "application/json" in response.headers.get(
                    "content-type", ""
                ):
                    raw = b""
                    async for chunk in response.body_iterator:
                        raw += chunk

                    try:
                        payload = json.loads(raw)
                        reply: str = payload.get("reply", "")

                        # 4a. Blocklist de saida
                        matched_out = check_output_blocklist(reply)
                        if matched_out:
                            logger.warning("Guardrail: frase bloqueada na saida: %r", matched_out)
                            _record_block(span, code="output_blocklist", layer="output")
                            payload["reply"] = (
                                "Desculpe, nao posso fornecer essa informacao."
                            )

                        # 4b. Redacao de PII na saida
                        elif _REDACT_PII_OUTPUT:
                            redacted = redact_pii(reply)
                            if redacted != reply:
                                logger.info("Guardrail: PII redigido na saida")
                                _guardrail_redactions.add(1, {
                                    _ATTR_ROUTE_KEY: _CHAT_ROUTE,
                                    "guardrail.layer": "output",
                                    "guardrail.rule": "pii_redaction",
                                    **_EXTRA_ATTRS,
                                })
                                span.set_attribute("guardrail.output_redacted", True)
                            payload["reply"] = redacted

                        raw = json.dumps(payload).encode()
                    except (json.JSONDecodeError, AttributeError):
                        pass  # body nao-JSON; passa como esta

                    headers = dict(response.headers)
                    headers["content-length"] = str(len(raw))
                    return Response(
                        content=raw,
                        status_code=response.status_code,
                        headers=headers,
                        media_type="application/json",
                    )

                return response
            finally:
                elapsed_ms = (time.perf_counter() - t0) * 1000
                _guardrail_latency.record(elapsed_ms, attrs_base)
                span.set_attribute("guardrail.latency_ms", elapsed_ms)


def _record_block(span: Any, code: str, layer: str) -> None:
    attrs = {
        _ATTR_ROUTE_KEY: _CHAT_ROUTE,
        "guardrail.layer": layer,
        "guardrail.code": code,
        **_EXTRA_ATTRS,
    }
    _guardrail_blocks.add(1, attrs)
    span.set_attribute("guardrail.blocked", True)
    span.set_attribute("guardrail.blocked_layer", layer)
    span.set_attribute("guardrail.blocked_code", code)


def _blocked(code: str, detail: str) -> JSONResponse:
    return JSONResponse(
        status_code=400,
        content={"error": "guardrail_violation", "code": code, "detail": detail},
    )
