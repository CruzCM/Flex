"""app.py - Aplicação FastAPI que expõe o agente LangGraph.

Rotas
-----
POST /chat          - Envia uma mensagem e recebe a resposta do agente.
GET  /metrics       - Métricas básicas de execução (uptime, contagem de requisições).
GET  /health/live   - Liveness probe: retorna 200 enquanto o processo está em execução.
GET  /health/ready  - Readiness probe: retorna 200 quando as dependências estão prontas.

Swagger UI disponível em /docs (built-in do FastAPI).
"""

from __future__ import annotations

import logging
import threading
import time
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from langchain_core.messages import HumanMessage, ToolMessage
from pydantic import BaseModel
from plg_agent_consult_fin.config import get_config, rag_readiness_issues
from plg_agent_consult_fin.graph import graph
from plg_agent_consult_fin.utils.guardrails_middleware import GuardrailsMiddleware

from plg_agent_consult_fin.utils.tracing import configure_azure_monitor

logger = logging.getLogger(__name__)

config = get_config()

# Bootstrap Azure Monitor exporter (safe no-op if connection string is unset)
configure_azure_monitor()


@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    """Compila o grafo no startup para que o readiness probe passe imediatamente."""
    await graph.compile()
    yield


app = FastAPI(
    title=config.agent_name,
    description=config.agent_description,
    version=config.metadata.version or "0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

_START_TIME = time.time()
_request_count: int = 0
_request_count_lock = threading.Lock()

app.add_middleware(GuardrailsMiddleware)


class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None

    model_config = {
        "json_schema_extra": {
            "examples": [{"message": "Quanto é 2 + 2?", "session_id": "sessao-exemplo"}]
        }
    }


class ChatResponse(BaseModel):
    reply: str
    session_id: Optional[str] = None
    tool_calls_made: int = 0


class MetricsResponse(BaseModel):
    uptime_seconds: float
    total_requests: int
    agent_id: str
    agent_name: str


@app.post(
    "/chat",
    response_model=ChatResponse,
    summary="Envia uma mensagem para o agente",
    tags=["Agente"],
)
async def chat(request: ChatRequest) -> ChatResponse:
    global _request_count
    with _request_count_lock:
        _request_count += 1

    logger.info("chat iniciado: session_id=%s", request.session_id)
    t0 = time.perf_counter()
    try:
        initial_state = {
            "messages": [HumanMessage(content=request.message)],
        }
        result = await graph.ainvoke(initial_state)
    except Exception as exc:
        logger.exception("Erro na execução do agente: session_id=%s", request.session_id)
        raise HTTPException(status_code=500, detail="Erro interno do servidor.") from exc

    messages = result.get("messages", [])
    raw_content = messages[-1].content if messages else ""

    if isinstance(raw_content, list):
        reply = " ".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in raw_content
        ).strip()
    else:
        reply = str(raw_content)

    tool_calls_made = sum(1 for m in messages if isinstance(m, ToolMessage))
    elapsed_ms = (time.perf_counter() - t0) * 1000
    logger.info(
        "chat concluído: session_id=%s tool_calls=%d elapsed_ms=%.0f",
        request.session_id,
        tool_calls_made,
        elapsed_ms,
    )

    return ChatResponse(
        reply=reply,
        session_id=request.session_id,
        tool_calls_made=tool_calls_made,
    )


@app.get(
    "/metrics",
    response_model=MetricsResponse,
    summary="Métricas de execução",
    tags=["Operações"],
)
async def metrics() -> MetricsResponse:
    cfg = get_config()
    return MetricsResponse(
        uptime_seconds=round(time.time() - _START_TIME, 2),
        total_requests=_request_count,
        agent_id=cfg.agent_id,
        agent_name=cfg.agent_name,
    )


@app.get(
    "/health/live",
    summary="Liveness probe",
    tags=["Health"],
)
async def health_live() -> JSONResponse:
    """Liveness probe - retorna 200 enquanto o processo estiver em execução."""
    return JSONResponse(content={"status": "alive"})


@app.get(
    "/health/ready",
    summary="Readiness probe",
    tags=["Health"],
)
async def health_ready() -> JSONResponse:
    """Readiness probe - verifica se a configuração está carregada e o grafo compilado."""
    try:
        cfg = get_config()
    except Exception as exc:  # noqa: BLE001
        return JSONResponse(
            status_code=503,
            content={"status": "not ready", "detail": str(exc)},
        )
    issues = rag_readiness_issues(cfg)
    if issues:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not ready",
                "detail": "Configuração RAG incompleta: " + ", ".join(issues),
            },
        )
    if graph._compiled is None:
        return JSONResponse(
            status_code=503,
            content={"status": "not ready", "detail": "Grafo ainda não compilado."},
        )
    return JSONResponse(content={"status": "ready"})
