"""Ferramenta LangChain para recuperar contexto do índice GeneraBB."""

from __future__ import annotations

import logging
import os
import ssl
from typing import Any

import httpx
from langchain_core.tools import tool as _tool

from plg_agent_consult_fin.config import RAGConfig, get_config

logger = logging.getLogger(__name__)

_http_client: httpx.AsyncClient | None = None


def _get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None:
        ca_bundle = os.environ.get("REQUESTS_CA_BUNDLE")
        verify: ssl.SSLContext | bool = (
            ssl.create_default_context(cafile=ca_bundle) if ca_bundle else True
        )
        _http_client = httpx.AsyncClient(verify=verify)
    return _http_client


def _extract_contexts(data: Any) -> list[Any]:
    """Extrai a lista retornada pelo contrato atual do GeneraBB."""
    if not isinstance(data, dict):
        return []
    text_blocks = data.get("data", {}).get("output", {}).get("text", [])
    if not isinstance(text_blocks, list) or not text_blocks:
        return []
    first_block = text_blocks[0]
    if not isinstance(first_block, dict):
        return []
    contexts = first_block.get("retrieved_contexts")
    return contexts if isinstance(contexts, list) else []


async def _call_gateway(query: str, config: RAGConfig | None = None) -> list[Any]:
    """Consulta diretamente a base indexada; falhas produzem contexto vazio."""
    cfg = config or get_config().rag
    client_id = os.environ.get("RAG_CLIENT_ID", "")
    if not cfg.enabled or not client_id or not cfg.agent_id:
        logger.info("RAG indisponível ou incompleto; recuperação não executada")
        return []

    payload = {
        "action": "recuperar-contexto",
        "body": {
            "data": {
                "input": query,
                "context": {
                    "messages": [],
                    "total_context": cfg.total_context,
                },
            }
        },
        # No Agent-Ops, agent_id contém o identificador da base indexada.
        "agent_id": cfg.agent_id,
    }
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "X-Client-Id": client_id,
        "UOR": cfg.uor,
        "userIdentification": cfg.user_id,
    }

    try:
        response = await _get_http_client().post(
            cfg.url,
            json=payload,
            headers=headers,
            timeout=cfg.timeout,
        )
        response.raise_for_status()
        contexts = _extract_contexts(response.json())
        if not contexts:
            logger.warning("RAG não retornou contextos para a consulta")
        return contexts
    except httpx.TimeoutException:
        logger.warning("RAG excedeu o timeout de %.1fs", cfg.timeout)
    except httpx.HTTPStatusError as exc:
        logger.warning("RAG retornou HTTP %d", exc.response.status_code)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Falha ao consultar o RAG: %s", exc)
    return []


def build_rag_tool(config: RAGConfig | None = None):
    """Cria a única ferramenta disponível ao Educador Financeiro."""
    cfg = config or get_config().rag

    @_tool(cfg.tool_name, description=cfg.tool_description)
    async def _retrieve(query: str) -> list[Any]:
        return await _call_gateway(query, cfg)

    return _retrieve
