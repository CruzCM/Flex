"""Recuperacao de contexto do Educador Financeiro."""

from plg_agent_consult_fin.rag.rag_tool import build_rag_tool

__all__ = ["build_rag_tool"]
