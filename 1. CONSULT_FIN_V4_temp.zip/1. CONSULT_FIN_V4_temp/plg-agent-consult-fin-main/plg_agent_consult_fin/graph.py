"""LangGraph do Agente Especialista Educador Financeiro."""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Annotated, Any, Dict, List

from langchain_azure_ai.callbacks.tracers import AzureAIOpenTelemetryTracer
from langchain_core.messages import AIMessage, BaseMessage, SystemMessage, ToolMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from typing_extensions import TypedDict

from plg_agent_consult_fin.config import AgentConfig, get_config
from plg_agent_consult_fin.llm import LLMFactory
from plg_agent_consult_fin.rag.rag_tool import build_rag_tool

logger = logging.getLogger(__name__)

OUT_OF_SCOPE_REPLY = (
    "Posso ajudar com temas de educação financeira, como orçamento, crédito, "
    "endividamento, reserva financeira, investimentos e planejamento. "
    "Se quiser, reformule sua pergunta dentro desse escopo."
)
RAG_UNAVAILABLE_REPLY = (
    "Não encontrei conteúdo suficiente na base de Educação Financeira para "
    "responder com segurança neste momento. Tente novamente mais tarde."
)

config = get_config()
_appinsights_conn_str = os.environ.get("APPLICATION_INSIGHTS_CONNECTION_STRING")
azure_tracer = (
    AzureAIOpenTelemetryTracer(
        connection_string=_appinsights_conn_str,
        enable_content_recording=False,
        name=config.agent_name or "educador-financeiro",
    )
    if _appinsights_conn_str
    else None
)


class AgentState(TypedDict, total=False):
    messages: Annotated[List[BaseMessage], add_messages]
    rag_attempted: bool
    rag_has_context: bool


def _has_retrieved_context(content: Any) -> bool:
    """Reconhece contexto não vazio mesmo após serialização pelo ToolNode."""
    if isinstance(content, list):
        return bool(content)
    if isinstance(content, dict):
        return bool(content)
    if not isinstance(content, str) or not content.strip():
        return False
    try:
        parsed = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return True
    return bool(parsed)


class RAGToolNode:
    """Executa a única ferramenta e registra se houve contexto recuperado."""

    def __init__(self, rag_tool: Any) -> None:
        self._inner = ToolNode([rag_tool])

    async def __call__(self, state: AgentState) -> Dict[str, Any]:
        result = await self._inner.ainvoke(state)
        tool_messages = [
            message
            for message in result.get("messages", [])
            if isinstance(message, ToolMessage)
        ]
        has_context = any(
            _has_retrieved_context(message.content) for message in tool_messages
        )
        return {
            "messages": tool_messages,
            "rag_attempted": True,
            "rag_has_context": has_context,
        }


class AgentFactory:
    """Compila o fluxo único LLM -> RAG -> resposta fundamentada."""

    @staticmethod
    def _compile_graph(
        llm: Any,
        rag_tool: Any | None,
        instructions: str,
    ):
        async def llm_call(state: AgentState) -> Dict[str, Any]:
            messages: List[BaseMessage] = list(state["messages"])
            if not messages or not isinstance(messages[0], SystemMessage):
                messages = [SystemMessage(content=instructions)] + messages
            response: AIMessage = await llm.ainvoke(messages)
            return {"messages": [response]}

        def route_after_llm(state: AgentState) -> str:
            last_message = state["messages"][-1]
            if isinstance(last_message, AIMessage) and last_message.tool_calls:
                # Uma única tentativa de RAG mantém o fluxo previsível.
                if rag_tool is not None and not state.get("rag_attempted", False):
                    return "rag"
                return "rag_unavailable"
            if state.get("rag_has_context", False):
                return "answer"
            return "out_of_scope"

        def route_after_rag(state: AgentState) -> str:
            return "llm_call" if state.get("rag_has_context", False) else "rag_unavailable"

        async def out_of_scope(_: AgentState) -> Dict[str, Any]:
            return {"messages": [AIMessage(content=OUT_OF_SCOPE_REPLY)]}

        async def rag_unavailable(_: AgentState) -> Dict[str, Any]:
            return {"messages": [AIMessage(content=RAG_UNAVAILABLE_REPLY)]}

        builder = StateGraph(AgentState)
        builder.add_node("llm_call", llm_call)
        builder.add_node("out_of_scope", out_of_scope)
        builder.add_node("rag_unavailable", rag_unavailable)
        builder.add_edge(START, "llm_call")
        builder.add_conditional_edges(
            "llm_call",
            route_after_llm,
            {
                "rag": "rag" if rag_tool is not None else "rag_unavailable",
                "answer": END,
                "out_of_scope": "out_of_scope",
                "rag_unavailable": "rag_unavailable",
            },
        )
        builder.add_edge("out_of_scope", END)
        builder.add_edge("rag_unavailable", END)

        if rag_tool is not None:
            builder.add_node("rag", RAGToolNode(rag_tool))
            builder.add_conditional_edges(
                "rag",
                route_after_rag,
                {
                    "llm_call": "llm_call",
                    "rag_unavailable": "rag_unavailable",
                },
            )

        return builder.compile()

    @classmethod
    async def create(cls, agent_config: AgentConfig | None = None):
        cfg = agent_config or get_config()
        rag_tool = build_rag_tool(cfg.rag) if cfg.rag.enabled else None
        llm = LLMFactory.create(cfg.llm.provider, cfg.temperature, cfg.top_p)
        llm_for_graph = llm.bind_tools([rag_tool]) if rag_tool is not None else llm
        logger.info("Educador Financeiro compilado; rag_enabled=%s", cfg.rag.enabled)
        return cls._compile_graph(llm_for_graph, rag_tool, cfg.instructions)


class AgentGraph:
    """Handle público do grafo compilado sob demanda."""

    def __init__(self) -> None:
        self._compiled: Any = None
        self._lock = asyncio.Lock()

    async def compile(self) -> None:
        if self._compiled is None:
            async with self._lock:
                if self._compiled is None:
                    self._compiled = await AgentFactory.create()

    async def ainvoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        await self.compile()
        callbacks = [azure_tracer] if azure_tracer else []
        return await self._compiled.ainvoke(state, config={"callbacks": callbacks})

    def invoke(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return asyncio.run(self.ainvoke(state))


graph = AgentGraph()
