"""Carregamento da configuração única do Educador Financeiro."""

from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml


@dataclass
class GatewayOutboundConfig:
    base_url: str = "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"
    model: str = "cambio-non-prod-gpt4o"
    api_version: str = "2024-12-01-preview"
    max_tokens: int = 4096


@dataclass
class LLMConfig:
    provider: str = "gateway_outbound"
    gateway_outbound: GatewayOutboundConfig = field(default_factory=GatewayOutboundConfig)


@dataclass
class GuardrailsConfig:
    max_input_length: int = 4096
    block_prompt_injection: bool = True
    block_pii_input: bool = True
    redact_pii_output: bool = True


@dataclass
class RAGConfig:
    enabled: bool = False
    url: str = "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"
    uor: str = ""
    user_id: str = ""
    # Conforme o contrato Agent-Ops, este campo identifica a base indexada.
    agent_id: str = ""
    total_context: int = 5
    timeout: float = 20.0
    tool_name: str = "retrieve_context"
    tool_description: str = (
        "Consulta a base de Educação Financeira e recupera trechos relevantes."
    )


@dataclass
class Metadata:
    owner: str = ""
    version: str = ""
    created_at: str = ""


@dataclass
class AgentConfig:
    agent_id: str
    agent_name: str
    deployment: str
    instructions: str
    agent_description: str
    temperature: float
    top_p: float
    metadata: Metadata
    llm: LLMConfig = field(default_factory=LLMConfig)
    guardrails: GuardrailsConfig = field(default_factory=GuardrailsConfig)
    rag: RAGConfig = field(default_factory=RAGConfig)


def load_agent_config(path: str | Path | None = None) -> AgentConfig:
    """Carrega o único ``agent_config.yaml`` do microsserviço."""
    if path is None:
        candidates = [
            Path(__file__).parent.parent / "agent_config.yaml",
            Path.cwd() / "agent_config.yaml",
        ]
        for candidate in candidates:
            if candidate.is_file():
                path = candidate
                break
        else:
            raise FileNotFoundError(
                "agent_config.yaml não encontrado. "
                f"Locais consultados: {[str(candidate) for candidate in candidates]}"
            )

    with Path(path).open("r", encoding="utf-8") as config_file:
        raw = yaml.safe_load(config_file) or {}
    if not isinstance(raw, dict):
        raise ValueError("agent_config.yaml deve conter um objeto YAML")

    llm_raw = raw.get("llm", {})
    gateway_raw = llm_raw.get("gateway_outbound", {})
    guardrails_raw = raw.get("guardrails", {})
    rag_raw = raw.get("rag", {})
    metadata_raw = raw.get("metadata", {})

    return AgentConfig(
        agent_id=raw["agent_id"],
        agent_name=raw["agent_name"],
        deployment=raw["deployment"],
        instructions=str(raw["instructions"]).strip(),
        agent_description=raw["agent_description"],
        temperature=float(raw.get("temperature", 0.2)),
        top_p=float(raw.get("top_p", 0.9)),
        llm=LLMConfig(
            provider=llm_raw.get("provider", "gateway_outbound"),
            gateway_outbound=GatewayOutboundConfig(
                base_url=gateway_raw.get(
                    "base_url", GatewayOutboundConfig.base_url
                ),
                model=gateway_raw.get("model", GatewayOutboundConfig.model),
                api_version=gateway_raw.get(
                    "api_version", GatewayOutboundConfig.api_version
                ),
                max_tokens=int(
                    gateway_raw.get("max_tokens", GatewayOutboundConfig.max_tokens)
                ),
            ),
        ),
        guardrails=GuardrailsConfig(
            max_input_length=int(guardrails_raw.get("max_input_length", 4096)),
            block_prompt_injection=bool(
                guardrails_raw.get("block_prompt_injection", True)
            ),
            block_pii_input=bool(guardrails_raw.get("block_pii_input", True)),
            redact_pii_output=bool(
                guardrails_raw.get("redact_pii_output", True)
            ),
        ),
        rag=RAGConfig(
            enabled=bool(rag_raw.get("enabled", False)),
            url=rag_raw.get("url", RAGConfig.url),
            uor=str(rag_raw.get("uor", "")),
            user_id=rag_raw.get("user_id", ""),
            agent_id=rag_raw.get("agent_id", ""),
            total_context=int(rag_raw.get("total_context", 5)),
            timeout=float(rag_raw.get("timeout", 20.0)),
            tool_name=rag_raw.get("tool_name", "retrieve_context"),
            tool_description=rag_raw.get(
                "tool_description", RAGConfig.tool_description
            ),
        ),
        metadata=Metadata(
            owner=metadata_raw.get("owner", ""),
            version=metadata_raw.get("version", ""),
            created_at=metadata_raw.get("created_at", ""),
        ),
    )


def rag_readiness_issues(config: AgentConfig) -> list[str]:
    """Valida configuração/secrets do RAG sem executar chamada externa."""
    if not config.rag.enabled:
        return []

    required = {
        "rag.url": config.rag.url,
        "rag.uor": config.rag.uor,
        "rag.user_id": config.rag.user_id,
        "rag.agent_id": config.rag.agent_id,
        "RAG_CLIENT_ID": os.getenv("RAG_CLIENT_ID", ""),
    }
    return [name for name, value in required.items() if not str(value).strip()]


_config: Optional[AgentConfig] = None
_config_lock = threading.Lock()


def get_config() -> AgentConfig:
    """Retorna o singleton thread-safe da configuração do microsserviço."""
    global _config
    if _config is None:
        with _config_lock:
            if _config is None:
                _config = load_agent_config()
    return _config
