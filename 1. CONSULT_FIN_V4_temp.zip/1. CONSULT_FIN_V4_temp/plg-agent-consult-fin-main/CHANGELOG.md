# Changelog

Todas as mudanças notáveis serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](http://keepachangelog.com/pt-BR/1.0.0/) e este projeto adere ao padrão [Semantic Versioning](http://semver.org/lang/pt-BR/spec/v2.0.0.html).

## [Não liberado]

### Adicionado

- Fluxo único do Educador Financeiro com LangGraph e uma ferramenta RAG GeneraBB.
- Respostas fixas para ausência de chamada ao RAG e contexto indisponível.
- Validação de prontidão da configuração e secret do RAG.
- Testes do fluxo ponta a ponta sem acesso a serviços externos.

### Corrigido

### Modificado

- Configuração consolidada no arquivo `agent_config.yaml`.
- Guardrails reduzidos às proteções locais essenciais.

### Obsoleto

### Removido

- Seleção de múltiplos agentes por perfil em runtime.
- MCP, Genera Safe e validadores semânticos do modelo inicial e das dependências ativas.

## [0.1.0-SNAPSHOT](https://fontes.intranet.bb.com.br/plg/plg-agent-consult-fin/plg-agent-consult-fin/tags/0.1.0-SNAPSHOT) - aaaa-mm-dd

### Adicionado
- Primeira versão
