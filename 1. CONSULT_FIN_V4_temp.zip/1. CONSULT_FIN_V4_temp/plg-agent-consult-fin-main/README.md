# Educador Financeiro

Microsserviço de Agente Especialista informacional construído sobre o padrão Agent-Ops, com FastAPI, LangGraph e consulta direta a uma base indexada no GeneraBB.

Este repositório contém um único agente, uma única configuração e um único RAG. Ele não seleciona agentes em runtime e não inclui MCP, orquestração, Genera Safe ou validadores semânticos como dependências ativas.

## Fluxo

```text
POST /chat
    |
    v
guardrails locais de entrada
    |
    v
LangGraph / Educador Financeiro
    |
    +-- modelo não chama o RAG --> resposta do modelo é descartada
    |                              e uma recusa orientativa fixa é retornada
    |
    +-- modelo chama o RAG ------> GeneraBB
                                      |
                                      +-- contexto vazio/erro --> resposta fixa de contexto insuficiente
                                      |
                                      +-- contexto disponível --> resposta fundamentada
    |
    v
guardrails locais de saída
```

Neste modelo inicial, a ausência de chamada ao RAG é tratada como indicação de que a pergunta está fora do escopo. Essa classificação é feita implicitamente pelo próprio LLM. Uma resposta de conteúdo só é aceita depois de uma recuperação não vazia.

## Configuração

Toda a configuração não secreta fica em [`agent_config.yaml`](agent_config.yaml). Os campos principais são:

- `agent_id`, `agent_name` e `instructions`: identidade e instruções do Educador Financeiro;
- `llm`: modelo e parâmetros de geração;
- `guardrails`: proteções locais simples de entrada e saída;
- `rag`: endpoint, identificação da base e parâmetros de consulta ao GeneraBB;
- `metadata`: informações operacionais.

Dentro de `rag`, o campo `agent_id` representa o identificador da base indexada no GeneraBB. Ele não pressupõe a criação de um agente RAG no GeneraBB.

O RAG permanece desabilitado até que `rag.enabled` seja alterado para `true` e os campos abaixo sejam preenchidos:

```yaml
rag:
  enabled: true
  url: https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent
  uor: "<UOR>"
  user_id: "<USUARIO>"
  agent_id: "<ID_DA_BASE_INDEXADA>"
```

A credencial `RAG_CLIENT_ID` é secret e deve ser fornecida por variável de ambiente. Quando o RAG está habilitado, o endpoint `/health/ready` retorna `503` se qualquer configuração obrigatória ou essa secret estiver ausente. A prontidão não faz uma chamada de rede ao GeneraBB.

Use [`.env.example`](.env.example) como referência para as demais variáveis de ambiente. Certificados e secrets não devem ser versionados.

## Guardrails

O middleware aplica apenas proteções locais essenciais:

- limite de tamanho da entrada;
- bloqueio simples de padrões de prompt injection;
- bloqueio configurável de PII na entrada;
- redação configurável de PII na saída.

As instruções do agente exigem linguagem educacional e neutra, sem promessas de resultado. A política de recomendação financeira personalizada continua sendo uma decisão de produto e governança, não uma restrição técnica inferida do Agent-Ops.

## Execução local

Requer Python 3.11.

Para um roteiro completo, desde a cópia da pasta até o teste integrado, consulte [`how_use.md`](how_use.md).

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m plg_agent_consult_fin --host 0.0.0.0 --port 8080
```

No Windows PowerShell, ative o ambiente com `.venv\Scripts\Activate.ps1`.

Endpoints:

- `POST /chat`: conversa com o Educador Financeiro;
- `GET /health/live`: processo ativo;
- `GET /health/ready`: configuração e grafo prontos;
- `GET /metrics`: métricas básicas do serviço.

Exemplo:

```bash
curl -X POST http://localhost:8080/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"O que é taxa Selic?"}'
```

## Testes

```bash
python -m pytest -q
```

A suíte cobre configuração, prontidão, guardrails, integração do RAG e as rotas do LangGraph para resposta fundamentada, fora de escopo e contexto indisponível.

## Reutilização

Depois da validação ponta a ponta, este projeto serve como modelo para novos Agentes Especialistas. Cada novo domínio deve nascer como outro microsserviço/projeto, copiando a estrutura validada e alterando somente configuração, instruções, identificação da base e regras realmente específicas do domínio.
