"""conftest.py - fixtures pytest compartilhados e configuração de sys.path."""

import sys
from pathlib import Path

# Adiciona a raiz do repositório ao sys.path para que `from plg_agent_consult_fin.xxx import ...`
# resolva da mesma forma que em tempo de execução (espelha o PYTHONPATH=/app
# definido no Dockerfile).
_ROOT_DIR = str(Path(__file__).parent.parent)
if _ROOT_DIR not in sys.path:
    sys.path.insert(0, _ROOT_DIR)
