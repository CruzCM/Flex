from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, Mock

import pytest
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool

import plg_agent_consult_fin.graph as graph_module
from plg_agent_consult_fin.config import load_agent_config
from plg_agent_consult_fin.graph import (
    AgentFactory,
    AgentGraph,
    OUT_OF_SCOPE_REPLY,
    RAG_UNAVAILABLE_REPLY,
    _has_retrieved_context,
)


def _tool_call(query: str = "taxa Selic") -> AIMessage:
    return AIMessage(
        content="",
        tool_calls=[
            {
                "name": "retrieve_context",
                "args": {"query": query},
                "id": "call-1",
                "type": "tool_call",
            }
        ],
    )


def _rag_tool(result):
    @tool("retrieve_context", description="Consulta a base indexada.")
    async def retrieve_context(query: str):
        return result

    return retrieve_context


@pytest.mark.parametrize(
    "content,expected",
    [([], False), ({}, False), ("", False), ("[]", False), ("{}", False),
     (["contexto"], True), ({"content": "contexto"}, True), ("contexto", True)],
)
def test_context_detection(content, expected: bool) -> None:
    assert _has_retrieved_context(content) is expected


@pytest.mark.asyncio
async def test_no_rag_call_discards_model_answer_and_returns_fixed_refusal() -> None:
    llm = Mock(ainvoke=AsyncMock(return_value=AIMessage(content="resposta livre")))
    compiled = AgentFactory._compile_graph(llm, None, "instrucao do sistema")

    result = await compiled.ainvoke(
        {"messages": [HumanMessage(content="Qual e a capital da Franca?")]}
    )

    assert result["messages"][-1].content == OUT_OF_SCOPE_REPLY
    sent_messages = llm.ainvoke.await_args.args[0]
    assert isinstance(sent_messages[0], SystemMessage)
    assert sent_messages[0].content == "instrucao do sistema"


@pytest.mark.asyncio
async def test_non_empty_rag_allows_grounded_answer() -> None:
    llm = Mock(
        ainvoke=AsyncMock(
            side_effect=[_tool_call(), AIMessage(content="Resposta fundamentada.")]
        )
    )
    compiled = AgentFactory._compile_graph(
        llm,
        _rag_tool([{"content": "A Selic e a taxa basica."}]),
        "instrucao",
    )

    result = await compiled.ainvoke(
        {"messages": [HumanMessage(content="O que e Selic?")]}
    )

    assert result["messages"][-1].content == "Resposta fundamentada."
    assert result["rag_attempted"] is True
    assert result["rag_has_context"] is True
    assert sum(isinstance(message, ToolMessage) for message in result["messages"]) == 1


@pytest.mark.asyncio
async def test_empty_rag_returns_fixed_unavailable_reply() -> None:
    llm = Mock(ainvoke=AsyncMock(return_value=_tool_call()))
    compiled = AgentFactory._compile_graph(llm, _rag_tool([]), "instrucao")

    result = await compiled.ainvoke(
        {"messages": [HumanMessage(content="O que e Selic?")]}
    )

    assert result["messages"][-1].content == RAG_UNAVAILABLE_REPLY
    assert result["rag_attempted"] is True
    assert result["rag_has_context"] is False
    assert llm.ainvoke.await_count == 1


@pytest.mark.asyncio
async def test_second_rag_request_is_not_executed() -> None:
    llm = Mock(ainvoke=AsyncMock(side_effect=[_tool_call(), _tool_call("novamente")]))
    compiled = AgentFactory._compile_graph(
        llm, _rag_tool([{"content": "contexto"}]), "instrucao"
    )

    result = await compiled.ainvoke(
        {"messages": [HumanMessage(content="pergunta")]}
    )

    assert result["messages"][-1].content == RAG_UNAVAILABLE_REPLY
    assert sum(isinstance(message, ToolMessage) for message in result["messages"]) == 1


@pytest.mark.asyncio
async def test_factory_binds_only_the_rag_tool(monkeypatch: pytest.MonkeyPatch) -> None:
    cfg = load_agent_config(Path(__file__).parents[2] / "agent_config.yaml")
    cfg.rag.enabled = True
    fake_tool = _rag_tool(["contexto"])
    raw_llm = Mock()
    bound_llm = Mock()
    raw_llm.bind_tools.return_value = bound_llm
    monkeypatch.setattr(graph_module, "build_rag_tool", Mock(return_value=fake_tool))
    monkeypatch.setattr(graph_module.LLMFactory, "create", Mock(return_value=raw_llm))
    compile_graph = Mock(return_value="compiled")
    monkeypatch.setattr(AgentFactory, "_compile_graph", compile_graph)

    result = await AgentFactory.create(cfg)

    assert result == "compiled"
    raw_llm.bind_tools.assert_called_once_with([fake_tool])
    compile_graph.assert_called_once_with(bound_llm, fake_tool, cfg.instructions)


@pytest.mark.asyncio
async def test_factory_does_not_bind_tools_when_rag_is_disabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cfg = load_agent_config(Path(__file__).parents[2] / "agent_config.yaml")
    cfg.rag.enabled = False
    raw_llm = Mock()
    monkeypatch.setattr(graph_module.LLMFactory, "create", Mock(return_value=raw_llm))
    compile_graph = Mock(return_value="compiled")
    monkeypatch.setattr(AgentFactory, "_compile_graph", compile_graph)

    result = await AgentFactory.create(cfg)

    assert result == "compiled"
    raw_llm.bind_tools.assert_not_called()
    compile_graph.assert_called_once_with(raw_llm, None, cfg.instructions)


@pytest.mark.asyncio
async def test_agent_graph_compiles_once_and_invokes(monkeypatch: pytest.MonkeyPatch) -> None:
    compiled = Mock(ainvoke=AsyncMock(return_value={"messages": []}))
    create = AsyncMock(return_value=compiled)
    monkeypatch.setattr(AgentFactory, "create", create)
    agent_graph = AgentGraph()

    await agent_graph.ainvoke({"messages": []})
    await agent_graph.ainvoke({"messages": []})

    create.assert_awaited_once()
    assert compiled.ainvoke.await_count == 2
