from __future__ import annotations

from pathlib import Path

import pytest

import plg_agent_consult_fin.config as config_module
from plg_agent_consult_fin.config import (
    AgentConfig,
    RAGConfig,
    load_agent_config,
    rag_readiness_issues,
)


YAML = """
agent_id: educador-financeiro
agent_name: Educador Financeiro
deployment: desenv
instructions: |
  Responda como educador financeiro.
agent_description: Especialista informacional.
temperature: 0.2
top_p: 0.9
llm:
  provider: gateway_outbound
  gateway_outbound:
    base_url: https://gateway.example/v1
    model: test-model
    api_version: 2024-12-01-preview
    max_tokens: 1024
guardrails:
  max_input_length: 3000
  block_prompt_injection: true
  block_pii_input: true
  redact_pii_output: true
rag:
  enabled: true
  url: https://genera.example/rag
  uor: "1234"
  user_id: tester
  agent_id: indice-educacao-financeira
  total_context: 4
  timeout: 12
  tool_name: consultar_educacao_financeira
  tool_description: Consulta a base indexada.
metadata:
  owner: IAA
  version: 1.0.0
  created_at: 2026-09-10
"""


def _write_config(tmp_path: Path, content: str = YAML) -> Path:
    path = tmp_path / "agent_config.yaml"
    path.write_text(content, encoding="utf-8")
    return path


def test_loads_the_single_agent_configuration(tmp_path: Path) -> None:
    cfg = load_agent_config(_write_config(tmp_path))

    assert isinstance(cfg, AgentConfig)
    assert cfg.agent_id == "educador-financeiro"
    assert cfg.agent_name == "Educador Financeiro"
    assert cfg.instructions == "Responda como educador financeiro."
    assert cfg.llm.gateway_outbound.model == "test-model"
    assert cfg.guardrails.max_input_length == 3000
    assert cfg.rag.agent_id == "indice-educacao-financeira"
    assert cfg.rag.total_context == 4
    assert cfg.metadata.owner == "IAA"


def test_rejects_non_mapping_yaml(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="objeto YAML"):
        load_agent_config(_write_config(tmp_path, "- item\n"))


def test_missing_required_identity_fails(tmp_path: Path) -> None:
    with pytest.raises(KeyError):
        load_agent_config(_write_config(tmp_path, "agent_name: incompleto\n"))


def test_rag_readiness_is_ignored_when_disabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("RAG_CLIENT_ID", raising=False)
    cfg = load_agent_config(Path(__file__).parents[2] / "agent_config.yaml")
    cfg.rag.enabled = False

    assert rag_readiness_issues(cfg) == []


def test_rag_readiness_reports_every_missing_value(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("RAG_CLIENT_ID", raising=False)
    cfg = load_agent_config(Path(__file__).parents[2] / "agent_config.yaml")
    cfg.rag = RAGConfig(enabled=True, url="", uor="", user_id="", agent_id="")

    assert rag_readiness_issues(cfg) == [
        "rag.url",
        "rag.uor",
        "rag.user_id",
        "rag.agent_id",
        "RAG_CLIENT_ID",
    ]


def test_rag_readiness_accepts_complete_configuration(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("RAG_CLIENT_ID", "secret")
    cfg = load_agent_config(_write_config(tmp_path))

    assert rag_readiness_issues(cfg) == []


def test_get_config_is_a_singleton(monkeypatch: pytest.MonkeyPatch) -> None:
    sentinel = object()
    monkeypatch.setattr(config_module, "_config", sentinel)

    assert config_module.get_config() is sentinel
