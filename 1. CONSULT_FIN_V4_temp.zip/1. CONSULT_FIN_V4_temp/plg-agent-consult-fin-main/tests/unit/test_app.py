"""Testes unitários para plg_agent_consult_fin/app.py.

Usa httpx.AsyncClient com ASGITransport para testar todos os endpoints sem
depender de rede real. O LLM e o grafo são totalmente mockados.
"""

from __future__ import annotations

import sys
import textwrap
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_YAML = textwrap.dedent("""\
    agent_id: "test-agent"
    agent_name: "Test Agent"
    deployment: "test"
    instructions: "Be helpful."
    agent_description: "A test agent."
    temperature: 0.5
    top_p: 0.9
    llm:
      provider: "gateway_outbound"
    rag:
      enabled: false
    metadata:
      owner: "team"
      version: "0.1.0"
      created_at: "2026-01-01"
""")


@pytest.fixture(autouse=True)
def _setup(tmp_path, monkeypatch):
    """Configura YAML mínimo e credenciais Azure antes de cada teste."""
    cfg = tmp_path / "agent_config.yaml"
    cfg.write_text(_YAML)
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://test.openai.azure.com/")
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "test-key")

    from plg_agent_consult_fin.config import load_agent_config as _real
    with patch("plg_agent_consult_fin.config.load_agent_config", return_value=_real(cfg)):
        yield


@pytest.fixture()
def mock_graph():
    """Grafo mockado que devolve uma resposta AI pré-definida."""
    ai_msg = AIMessage(content="Resposta de teste.")
    g = MagicMock()
    g.ainvoke = AsyncMock(
        return_value={"messages": [HumanMessage(content="olá"), ai_msg]}
    )
    return g


@pytest_asyncio.fixture()
async def client(mock_graph):
    """AsyncClient apontando para a app FastAPI com LLM totalmente mockado."""
    saved = {k: v for k, v in sys.modules.items() if k.startswith("plg_agent_consult_fin.")}
    for mod in list(sys.modules):
        if mod.startswith("plg_agent_consult_fin."):
            del sys.modules[mod]
    try:
        with patch("plg_agent_consult_fin.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
            from plg_agent_consult_fin.app import app  # noqa: PLC0415
            async with AsyncClient(
                transport=ASGITransport(app=app), base_url="http://test"
            ) as ac:
                yield ac
    finally:
        for mod in list(sys.modules):
            if mod.startswith("plg_agent_consult_fin."):
                del sys.modules[mod]
        sys.modules.update(saved)


# ---------------------------------------------------------------------------
# Health probes
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_health_live_returns_200(client):
    resp = await client.get("/health/live")
    assert resp.status_code == 200
    assert resp.json() == {"status": "alive"}


@pytest.mark.asyncio
async def test_health_ready_returns_200(client):
    import plg_agent_consult_fin.app as app_module
    app_module.graph._compiled = object()  # simula grafo compilado
    resp = await client.get("/health/ready")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ready"


@pytest.mark.asyncio
async def test_health_ready_returns_503_when_config_raises(client):
    with patch("plg_agent_consult_fin.app.get_config", side_effect=RuntimeError("config indisponível")):
        resp = await client.get("/health/ready")
    assert resp.status_code == 503
    body = resp.json()
    assert body["status"] == "not ready"
    assert "detail" in body


@pytest.mark.asyncio
async def test_health_ready_returns_503_when_rag_configuration_is_incomplete(client):
    with patch(
        "plg_agent_consult_fin.app.rag_readiness_issues",
        return_value=["rag.agent_id", "RAG_CLIENT_ID"],
    ):
        resp = await client.get("/health/ready")
    assert resp.status_code == 503
    body = resp.json()
    assert body["status"] == "not ready"
    assert "rag.agent_id" in body["detail"]
    assert "RAG_CLIENT_ID" in body["detail"]


# ---------------------------------------------------------------------------
# Métricas
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_metrics_returns_expected_structure(client):
    resp = await client.get("/metrics")
    assert resp.status_code == 200
    body = resp.json()
    assert "uptime_seconds" in body
    assert "total_requests" in body
    assert "agent_id" in body
    assert "agent_name" in body
    assert isinstance(body["uptime_seconds"], float)
    assert isinstance(body["total_requests"], int)


# ---------------------------------------------------------------------------
# /chat - fluxo principal
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_chat_returns_reply(client):
    resp = await client.post("/chat", json={"message": "Olá"})
    assert resp.status_code == 200
    body = resp.json()
    assert "reply" in body
    assert body["reply"] == "Resposta de teste."


@pytest.mark.asyncio
async def test_chat_echoes_session_id(client):
    resp = await client.post(
        "/chat", json={"message": "Olá", "session_id": "sessao-99"}
    )
    assert resp.status_code == 200
    assert resp.json()["session_id"] == "sessao-99"


@pytest.mark.asyncio
async def test_chat_session_id_optional(client):
    resp = await client.post("/chat", json={"message": "Olá"})
    assert resp.status_code == 200
    assert resp.json()["session_id"] is None


@pytest.mark.asyncio
async def test_chat_422_on_missing_message(client):
    resp = await client.post("/chat", json={})
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_chat_500_on_graph_exception(client, mock_graph):
    mock_graph.ainvoke.side_effect = RuntimeError("LLM indisponível")
    with patch("plg_agent_consult_fin.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "mensagem"})
    assert resp.status_code == 500
    assert resp.json()["detail"] == "Erro interno do servidor."


@pytest.mark.asyncio
async def test_chat_list_content_blocks_concatenated(client, mock_graph):
    """Quando o LLM retorna lista de blocos, o reply deve ser a concatenação dos textos."""
    ai_msg = AIMessage(
        content=[{"type": "text", "text": "parte A"}, {"type": "text", "text": "parte B"}]
    )
    mock_graph.ainvoke = AsyncMock(
        return_value={"messages": [HumanMessage(content="q"), ai_msg]}
    )
    with patch("plg_agent_consult_fin.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "q"})
    assert resp.status_code == 200
    reply = resp.json()["reply"]
    assert "parte A" in reply
    assert "parte B" in reply


@pytest.mark.asyncio
async def test_chat_list_content_with_non_dict_block(client, mock_graph):
    """Blocos não-dict na lista de conteúdo devem ser convertidos via str()."""
    ai_msg = AIMessage(content=[{"type": "text", "text": "texto"}, "string direta"])
    mock_graph.ainvoke = AsyncMock(
        return_value={"messages": [HumanMessage(content="q"), ai_msg]}
    )
    with patch("plg_agent_consult_fin.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "q"})
    assert resp.status_code == 200
    assert "texto" in resp.json()["reply"]


@pytest.mark.asyncio
async def test_chat_counts_tool_calls(client, mock_graph):
    """tool_calls_made deve contar ToolMessages na lista de messages."""
    tool_msg = ToolMessage(content="resultado", tool_call_id="tc-1")
    ai_msg = AIMessage(content="resposta final")
    mock_graph.ainvoke = AsyncMock(
        return_value={"messages": [HumanMessage(content="q"), tool_msg, ai_msg]}
    )
    with patch("plg_agent_consult_fin.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "q"})
    assert resp.status_code == 200
    assert resp.json()["tool_calls_made"] == 1


@pytest.mark.asyncio
async def test_chat_empty_messages_returns_empty_reply(client, mock_graph):
    """Quando o grafo retorna messages=[], reply deve ser string vazia."""
    mock_graph.ainvoke = AsyncMock(return_value={"messages": []})
    with patch("plg_agent_consult_fin.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "q"})
    assert resp.status_code == 200
    assert resp.json()["reply"] == ""
