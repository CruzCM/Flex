"""Testes unitários para plg_agent_consult_fin/llm/factory.py e plg_agent_consult_fin/llm/base.py."""

import pytest
from unittest.mock import MagicMock

from plg_agent_consult_fin.llm.base import LLMProvider
from plg_agent_consult_fin.llm.factory import LLMFactory


# ---------------------------------------------------------------------------
# LLMFactory.register / create
# ---------------------------------------------------------------------------


class _DummyProvider(LLMProvider):
    """Provider mínimo que retorna um modelo mock."""

    def build(self, temperature: float, top_p: float):
        m = MagicMock()
        m.temperature = temperature
        m.top_p = top_p
        return m


def setup_function():
    # Restaura o registro para um estado limpo antes de cada função de teste
    LLMFactory._registry.pop("dummy", None)


def test_register_and_create():
    LLMFactory.register("dummy", _DummyProvider)
    model = LLMFactory.create("dummy", temperature=0.3, top_p=0.8)
    assert model.temperature == pytest.approx(0.3)
    assert model.top_p == pytest.approx(0.8)


def test_unknown_provider_raises():
    with pytest.raises(ValueError, match="Provedor LLM desconhecido"):
        LLMFactory.create("nonexistent-provider", temperature=0.5, top_p=1.0)


def test_register_overrides_existing():
    class _AltProvider(LLMProvider):
        def build(self, temperature, top_p):
            m = MagicMock()
            m.name = "alt"
            return m

    LLMFactory.register("dummy", _DummyProvider)
    LLMFactory.register("dummy", _AltProvider)
    model = LLMFactory.create("dummy", temperature=0.0, top_p=1.0)
    assert model.name == "alt"


def test_builtin_providers_registered():
    assert "gateway_outbound" in LLMFactory._registry
