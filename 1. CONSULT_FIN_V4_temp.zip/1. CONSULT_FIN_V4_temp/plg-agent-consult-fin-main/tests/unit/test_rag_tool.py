from __future__ import annotations

from unittest.mock import AsyncMock, Mock

import httpx
import pytest

import plg_agent_consult_fin.rag.rag_tool as rag_module
from plg_agent_consult_fin.config import RAGConfig
from plg_agent_consult_fin.rag.rag_tool import (
    _call_gateway,
    _extract_contexts,
    build_rag_tool,
)


def _config(**overrides) -> RAGConfig:
    values = {
        "enabled": True,
        "url": "https://genera.example/rag",
        "uor": "1234",
        "user_id": "tester",
        "agent_id": "indice-educacao-financeira",
        "total_context": 3,
        "timeout": 8.0,
        "tool_name": "retrieve_context",
        "tool_description": "Consulta a base de educacao financeira.",
    }
    values.update(overrides)
    return RAGConfig(**values)


def _response(data: dict, status_code: int = 200) -> Mock:
    response = Mock()
    response.json.return_value = data
    response.raise_for_status.return_value = None
    response.status_code = status_code
    return response


@pytest.mark.asyncio
async def test_disabled_rag_does_not_call_network(monkeypatch: pytest.MonkeyPatch) -> None:
    client = Mock(post=AsyncMock())
    monkeypatch.setattr(rag_module, "_http_client", client)
    monkeypatch.setenv("RAG_CLIENT_ID", "secret")

    assert await _call_gateway("pergunta", _config(enabled=False)) == []
    client.post.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize("client_id,agent_id", [("", "indice"), ("secret", "")])
async def test_incomplete_rag_does_not_call_network(
    monkeypatch: pytest.MonkeyPatch, client_id: str, agent_id: str
) -> None:
    client = Mock(post=AsyncMock())
    monkeypatch.setattr(rag_module, "_http_client", client)
    monkeypatch.setenv("RAG_CLIENT_ID", client_id)

    assert await _call_gateway("pergunta", _config(agent_id=agent_id)) == []
    client.post.assert_not_awaited()


@pytest.mark.asyncio
async def test_calls_genera_with_index_agent_id(monkeypatch: pytest.MonkeyPatch) -> None:
    data = {
        "data": {
            "output": {
                "text": [{"retrieved_contexts": [{"content": "contexto"}]}]
            }
        }
    }
    client = Mock(post=AsyncMock(return_value=_response(data)))
    monkeypatch.setattr(rag_module, "_http_client", client)
    monkeypatch.setenv("RAG_CLIENT_ID", "secret")

    result = await _call_gateway("O que e Selic?", _config())

    assert result == [{"content": "contexto"}]
    client.post.assert_awaited_once()
    kwargs = client.post.await_args.kwargs
    assert kwargs["json"]["agent_id"] == "indice-educacao-financeira"
    assert kwargs["json"]["body"]["data"]["input"] == "O que e Selic?"
    assert kwargs["json"]["body"]["data"]["context"]["total_context"] == 3
    assert kwargs["headers"]["X-Client-Id"] == "secret"
    assert kwargs["headers"]["UOR"] == "1234"
    assert kwargs["headers"]["userIdentification"] == "tester"
    assert kwargs["timeout"] == 8.0


@pytest.mark.parametrize(
    "payload",
    [None, {}, {"data": {}}, {"data": {"output": {"text": []}}},
     {"data": {"output": {"text": [{}]}}}],
)
def test_extract_contexts_returns_empty_for_unknown_shapes(payload) -> None:
    assert _extract_contexts(payload) == []


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "failure",
    [
        httpx.TimeoutException("timeout"),
        RuntimeError("falha inesperada"),
    ],
)
async def test_gateway_failures_become_empty_context(
    monkeypatch: pytest.MonkeyPatch, failure: Exception
) -> None:
    client = Mock(post=AsyncMock(side_effect=failure))
    monkeypatch.setattr(rag_module, "_http_client", client)
    monkeypatch.setenv("RAG_CLIENT_ID", "secret")

    assert await _call_gateway("pergunta", _config()) == []


@pytest.mark.asyncio
async def test_http_error_becomes_empty_context(monkeypatch: pytest.MonkeyPatch) -> None:
    request = httpx.Request("POST", "https://genera.example/rag")
    response = httpx.Response(503, request=request)
    client = Mock(
        post=AsyncMock(
            side_effect=httpx.HTTPStatusError(
                "indisponivel", request=request, response=response
            )
        )
    )
    monkeypatch.setattr(rag_module, "_http_client", client)
    monkeypatch.setenv("RAG_CLIENT_ID", "secret")

    assert await _call_gateway("pergunta", _config()) == []


@pytest.mark.asyncio
async def test_build_tool_uses_the_given_configuration(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cfg = _config(tool_name="consultar_base")
    call = AsyncMock(return_value=["contexto"])
    monkeypatch.setattr(rag_module, "_call_gateway", call)

    rag_tool = build_rag_tool(cfg)
    result = await rag_tool.ainvoke({"query": "pergunta"})

    assert rag_tool.name == "consultar_base"
    assert result == ["contexto"]
    call.assert_awaited_once_with("pergunta", cfg)
