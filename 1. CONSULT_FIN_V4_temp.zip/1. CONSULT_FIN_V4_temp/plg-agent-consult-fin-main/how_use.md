# Como preparar e testar o Educador Financeiro

Este guia começa no momento em que a pasta `plg-agent-consult-fin-main` chega ao ambiente corporativo. Ele foi escrito para quem não trabalha diariamente com Python ou microsserviços.

Os comandos principais consideram um terminal Linux. Há uma seção de PowerShell no final.

## Visão geral do que você fará

Você seguirá esta ordem:

1. conferir os arquivos e o Python;
2. criar um ambiente Python isolado;
3. instalar as dependências;
4. executar os testes automáticos, que não acessam sistemas externos;
5. conseguir as credenciais e identificadores corporativos;
6. configurar o RAG e as variáveis de ambiente;
7. iniciar o microsserviço;
8. testar saúde, RAG, recusa fora do escopo e guardrails;
9. encaminhar o projeto para a esteira corporativa.

## Antes de copiar a pasta

Não é necessário transferir arquivos locais ou temporários. A pasta que vai para o ambiente corporativo não deve conter:

- `.venv`;
- `.env`;
- certificados ou chaves privadas;
- `__pycache__`;
- `.pytest_cache`;
- logs locais.

Esses itens devem ser criados ou fornecidos novamente no ambiente de destino. Nunca envie secrets, tokens, certificados ou chaves privadas para o Git.

## 1. Entre na pasta do projeto

Abra um terminal no ambiente corporativo e vá até a pasta copiada. Exemplo:

```bash
cd /caminho/onde/foi/copiado/plg-agent-consult-fin-main
```

Confira se está no lugar correto:

```bash
pwd
ls
```

Você deve ver, entre outros, estes arquivos:

```text
agent_config.yaml
Dockerfile
Jenkinsfile
requirements.txt
plg_agent_consult_fin/
tests/
```

Todos os próximos comandos devem ser executados a partir dessa pasta.

## 2. Confira a versão do Python

Execute:

```bash
python3.11 --version
```

O esperado é algo parecido com:

```text
Python 3.11.x
```

Se `python3.11` não existir, tente:

```bash
python3 --version
```

Se a versão não for 3.11, solicite ao responsável pelo ambiente a disponibilização do Python 3.11. Não continue com uma versão diferente sem validar antes com a equipe técnica.

## 3. Crie o ambiente Python isolado

O ambiente virtual evita misturar as bibliotecas deste projeto com as de outros sistemas.

```bash
python3.11 -m venv .venv
source .venv/bin/activate
```

Depois da ativação, o terminal normalmente passa a mostrar `(.venv)` no início da linha.

Confirme:

```bash
python --version
```

Para sair do ambiente virtual mais tarde, use:

```bash
deactivate
```

## 4. Instale as dependências

Com o ambiente virtual ativado:

```bash
python -m pip install -r requirements.txt
```

O ambiente corporativo precisa ter acesso ao repositório interno de pacotes Python e à cadeia de certificados do Banco.

Se aparecer erro de SSL, certificado ou acesso ao Artifactory:

- não desative a verificação SSL;
- confirme que a CA corporativa foi instalada no ambiente;
- confirme com a equipe responsável qual configuração corporativa do `pip` deve ser usada;
- verifique se o acesso a `binarios.intranet.bb.com.br` está liberado.

O arquivo `pip.conf` do projeto é usado pela construção corporativa, mas depende do certificado disponibilizado no ambiente/container.

Confira se as dependências ficaram consistentes:

```bash
python -m pip check
```

O resultado esperado é:

```text
No broken requirements found.
```

## 5. Execute primeiro os testes automáticos

Estes testes usam simulações do LLM e do GeneraBB. Portanto, podem ser executados antes de configurar tokens, certificados ou acesso de rede.

```bash
python -m pytest -q
```

O importante é que o comando termine com todos os testes aprovados e nenhuma falha. A quantidade exata pode aumentar conforme o projeto evoluir.

Se houver falhas, não avance para o teste integrado. Guarde a saída completa do terminal e encaminhe para a equipe técnica.

Passar nesses testes confirma a lógica local, mas ainda não confirma acesso ao Gateway Outbound nem ao GeneraBB.

## 6. Reúna as informações corporativas necessárias

Para testar o fluxo real, você precisará obter:

| Informação | Onde será usada |
|---|---|
| App key do Gateway Outbound | `GATEWAY_OUTBOUND_GW_APP_KEY` |
| Certificado cliente mTLS | `KEY_STORE_CERT_PATH` |
| Chave privada do certificado | `KEY_STORE_KEY_PATH` |
| CA usada para validar os serviços | `TRUST_STORE_CA_PATH` e, quando aplicável, `REQUESTS_CA_BUNDLE` |
| Identificador da base indexada de Educação Financeira | `rag.agent_id` no YAML |
| UOR autorizada no GeneraBB | `rag.uor` no YAML |
| Identificação do usuário técnico | `rag.user_id` no YAML |
| Client ID/JWT de acesso ao GeneraBB | `RAG_CLIENT_ID` |

Também confirme com a equipe:

- se o endpoint do Gateway Outbound configurado é o correto para o ambiente;
- se o modelo `cambio-non-prod-gpt4o` está liberado para a aplicação;
- se a URL do GeneraBB está correta para o ambiente de homologação;
- se a base já está indexada e contém conteúdo de Educação Financeira.

O `rag.agent_id` é o identificador da base indexada. Não é necessário criar um agente RAG no GeneraBB.

## 7. Configure o RAG no `agent_config.yaml`

Abra `agent_config.yaml` em um editor de texto e localize a seção `rag`.

Enquanto as informações reais não estiverem disponíveis, mantenha:

```yaml
rag:
  enabled: false
```

Nesse estado o programa pode iniciar, mas não produzirá respostas informacionais fundamentadas. Como nenhuma ferramenta RAG estará disponível, as respostas livres do modelo serão descartadas e a recusa orientativa será retornada.

Para o teste integrado, preencha a seção desta forma:

```yaml
rag:
  enabled: true
  url: "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"
  user_id: "USUARIO_TECNICO_FORNECIDO"
  uor: "UOR_FORNECIDA"
  agent_id: "IDENTIFICADOR_DA_BASE_INDEXADA"
  total_context: 5
  timeout: 20.0
  tool_name: "retrieve_context"
  tool_description: "Consulta a base de Educação Financeira e recupera trechos relevantes."
```

Cuidados:

- altere apenas os valores fornecidos pela equipe responsável;
- preserve os espaços antes de cada campo, pois YAML depende da indentação;
- não coloque `RAG_CLIENT_ID`, app keys, certificados ou chaves dentro do YAML;
- não altere `tool_name` neste primeiro teste.

## 8. Configure as secrets e os certificados

Faça uma cópia local do exemplo:

```bash
cp .env.example .env
```

Abra `.env` em um editor e substitua todos os valores `<PREENCHER>`. Um exemplo ilustrativo, sem credenciais reais, é:

```dotenv
GATEWAY_OUTBOUND_GW_APP_KEY=VALOR_FORNECIDO
KEY_STORE_CERT_PATH=/caminho/seguro/certificado.crt
KEY_STORE_KEY_PATH=/caminho/seguro/chave.key
TRUST_STORE_CA_PATH=/caminho/seguro/ca-corporativa.crt
RAG_CLIENT_ID=VALOR_FORNECIDO
REQUESTS_CA_BUNDLE=/caminho/seguro/ca-corporativa.crt
APPLICATION_INSIGHTS_CONNECTION_STRING=
OTEL_RECORD_CONTENT=false
SERVICE_NAME=plg-agent-consult-fin
DEPLOY_ENV=homol
```

Os caminhos precisam apontar para arquivos que realmente existem no ambiente. Confira sem exibir seu conteúdo:

```bash
test -f /caminho/seguro/certificado.crt && echo "certificado encontrado"
test -f /caminho/seguro/chave.key && echo "chave encontrada"
test -f /caminho/seguro/ca-corporativa.crt && echo "CA encontrada"
```

Carregue as variáveis no terminal atual:

```bash
set -a
. ./.env
set +a
```

O projeto não carrega `.env` automaticamente. Esse comando precisa ser executado novamente quando você abrir outro terminal para iniciar o serviço.

Confira somente se as variáveis existem, sem imprimir os valores:

```bash
python -c "import os; nomes=['GATEWAY_OUTBOUND_GW_APP_KEY','KEY_STORE_CERT_PATH','KEY_STORE_KEY_PATH','TRUST_STORE_CA_PATH','RAG_CLIENT_ID']; [print(f'{n}:', 'OK' if os.getenv(n) else 'AUSENTE') for n in nomes]"
```

Todas devem aparecer como `OK` para o teste integrado com RAG.

Proteja o arquivo local:

```bash
chmod 600 .env
```

O `.env` já está ignorado pelo Git, mas continue tratando-o como arquivo secreto.

## 9. Inicie o microsserviço

Com o ambiente virtual ativado e as variáveis carregadas:

```bash
python -m plg_agent_consult_fin --host 127.0.0.1 --port 8080
```

Deixe esse terminal aberto. Ele mostrará os logs e ficará ocupado enquanto o serviço estiver executando.

O esperado é ver uma mensagem indicando que a aplicação iniciou. Se o processo encerrar imediatamente, leia as últimas linhas do erro antes de tentar novamente.

Para parar o serviço, volte a esse terminal e pressione `Ctrl+C`.

## 10. Abra outro terminal para os testes HTTP

No segundo terminal não é necessário iniciar o Python novamente. Ele será usado apenas para enviar requisições ao serviço que está rodando no primeiro terminal.

### 10.1 Teste se o processo está vivo

```bash
curl -i http://127.0.0.1:8080/health/live
```

Esperado: HTTP `200` e:

```json
{"status":"alive"}
```

### 10.2 Teste se o agente está pronto

```bash
curl -i http://127.0.0.1:8080/health/ready
```

Esperado: HTTP `200` e:

```json
{"status":"ready"}
```

Se retornar `503` com `Configuração RAG incompleta`, o próprio texto indicará os campos ou a secret ausentes. Corrija-os, pare o serviço com `Ctrl+C` e inicie-o novamente.

### 10.3 Teste uma pergunta de Educação Financeira

```bash
curl -i -X POST http://127.0.0.1:8080/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"O que é taxa Selic e como ela afeta minha vida financeira?","session_id":"teste-rag-01"}'
```

Esperado:

- HTTP `200`;
- um campo `reply` com uma resposta baseada no conteúdo recuperado;
- `session_id` igual a `teste-rag-01`;
- `tool_calls_made` igual a `1`.

Exemplo de formato, não de conteúdo:

```json
{
  "reply": "Resposta fundamentada na base...",
  "session_id": "teste-rag-01",
  "tool_calls_made": 1
}
```

Se a resposta disser que não encontrou conteúdo suficiente, o serviço funcionou, mas o RAG retornou vazio ou falhou. Verifique o identificador da base, permissões, UOR, usuário técnico, URL e logs.

### 10.4 Teste uma pergunta fora do escopo

```bash
curl -i -X POST http://127.0.0.1:8080/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Qual é a capital da França?","session_id":"teste-escopo-01"}'
```

Esperado: HTTP `200`, `tool_calls_made` igual a `0` e uma recusa explicando que o agente atende temas de Educação Financeira.

### 10.5 Teste um guardrail simples

Use somente dados fictícios:

```bash
curl -i -X POST http://127.0.0.1:8080/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Meu e-mail é pessoa@example.com"}'
```

Esperado: HTTP `400` com o código:

```json
{
  "error": "guardrail_violation",
  "code": "pii_detected",
  "detail": "..."
}
```

Não use CPF, conta, cartão, telefone ou qualquer dado verdadeiro nesse teste.

### 10.6 Consulte as métricas básicas

```bash
curl -i http://127.0.0.1:8080/metrics
```

O retorno inclui tempo de atividade, quantidade de requisições, ID e nome do agente.

### 10.7 Interface visual opcional

Se o ambiente permitir acessar a porta pelo navegador, abra:

```text
http://127.0.0.1:8080/docs
```

Essa é a interface Swagger. Nela você pode abrir `POST /chat`, clicar em **Try it out**, preencher a mensagem e clicar em **Execute**.

## 11. Como interpretar os resultados

| Resultado | Significado provável | O que fazer |
|---|---|---|
| Testes Python passaram | A lógica local está consistente | Continuar para o teste integrado |
| Serviço não inicia e cita `GATEWAY_OUTBOUND_GW_APP_KEY` | App key ausente no terminal | Carregar novamente o `.env` |
| Erro de certificado ou SSL | Caminho/CA incorreto ou não provisionado | Validar certificados com a equipe do ambiente |
| `/health/live` não conecta | Serviço parado, porta errada ou bloqueada | Conferir o primeiro terminal e a porta 8080 |
| `/health/ready` retorna `503` | Grafo não compilado ou RAG incompleto | Ler o campo `detail`, corrigir e reiniciar |
| Pergunta financeira retorna recusa de escopo | RAG desabilitado ou LLM não chamou a ferramenta | Confirmar `rag.enabled: true` e observar os logs |
| Resposta de contexto insuficiente | GeneraBB retornou vazio ou ocorreu falha | Conferir índice, acesso, UOR, usuário, URL e logs |
| `/chat` retorna `500` | Falha interna no LLM/grafo | Guardar logs e acionar a equipe técnica |
| `tool_calls_made: 1` com resposta de conteúdo fundamentada | O RAG foi chamado e retornou contexto | Fluxo principal aprovado |

## 12. Checklist de aprovação manual

Considere o teste integrado aprovado somente quando todos estes itens estiverem confirmados:

- [ ] Python 3.11 disponível;
- [ ] dependências instaladas;
- [ ] testes automáticos aprovados;
- [ ] secrets fornecidas por meio seguro;
- [ ] certificados encontrados nos caminhos configurados;
- [ ] `rag.enabled: true` no ambiente de teste;
- [ ] `rag.agent_id`, `rag.uor` e `rag.user_id` preenchidos;
- [ ] `/health/live` retornou `200`;
- [ ] `/health/ready` retornou `200`;
- [ ] pergunta financeira retornou `tool_calls_made: 1`;
- [ ] resposta financeira está coerente com a base;
- [ ] pergunta fora do escopo foi recusada;
- [ ] guardrail de PII fictícia retornou `400`;
- [ ] nenhum token, certificado ou dado de cliente apareceu nos logs.

Registre data, ambiente, versão testada e evidências dos retornos, removendo secrets e dados sensíveis das capturas.

## 13. Depois do teste manual: esteira corporativa

O teste manual não substitui a implantação oficial. Depois que ele passar:

1. versione somente o código-fonte no repositório corporativo;
2. não inclua `.env`, `.venv`, certificados ou secrets;
3. cadastre as variáveis secretas no mecanismo corporativo usado pela aplicação;
4. providencie o volume ou secret de certificados esperado pelo container;
5. confirme os valores não secretos de `agent_config.yaml` para o ambiente;
6. execute a pipeline definida pelo `Jenkinsfile`;
7. acompanhe construção, testes unitários e criação da imagem;
8. depois do deploy, repita os testes de `/health/live`, `/health/ready` e `/chat` usando a URL publicada.

Os nomes do projeto, namespace, cofre de secrets e procedimento de promoção entre ambientes dependem da esteira corporativa da equipe. Não invente esses valores: solicite-os ao responsável pelo Agent-Ops/DevOps.

## PowerShell no Windows

Na raiz do projeto:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest -q
```

O PowerShell não carrega `.env` automaticamente. Defina as variáveis no terminal que iniciará o serviço:

```powershell
$env:GATEWAY_OUTBOUND_GW_APP_KEY = "VALOR_FORNECIDO"
$env:KEY_STORE_CERT_PATH = "C:\caminho\seguro\certificado.crt"
$env:KEY_STORE_KEY_PATH = "C:\caminho\seguro\chave.key"
$env:TRUST_STORE_CA_PATH = "C:\caminho\seguro\ca-corporativa.crt"
$env:REQUESTS_CA_BUNDLE = "C:\caminho\seguro\ca-corporativa.crt"
$env:RAG_CLIENT_ID = "VALOR_FORNECIDO"
$env:OTEL_RECORD_CONTENT = "false"
$env:SERVICE_NAME = "plg-agent-consult-fin"
$env:DEPLOY_ENV = "homol"
```

Em seguida:

```powershell
python -m plg_agent_consult_fin --host 127.0.0.1 --port 8080
```

Em outro PowerShell, teste:

```powershell
Invoke-RestMethod http://127.0.0.1:8080/health/live
Invoke-RestMethod http://127.0.0.1:8080/health/ready

$body = @{
    message = "O que é taxa Selic?"
    session_id = "teste-rag-01"
} | ConvertTo-Json

Invoke-RestMethod `
    -Uri http://127.0.0.1:8080/chat `
    -Method Post `
    -ContentType "application/json" `
    -Body $body
```

As variáveis definidas com `$env:` duram somente naquela janela do PowerShell, o que é adequado para o teste manual.
