"""Experiencia guiada do notebook."""

from __future__ import annotations

import html
import importlib
import importlib.util
import json
import sys
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


DEPENDENCIAS_BASE = {"yaml": "PyYAML"}
DEPENDENCIAS_OFICIAIS = {
    "dotenv": "python-dotenv",
    "requests": "requests",
    "urllib3": "urllib3",
}
DEPENDENCIAS_OLLAMA = {"requests": "requests"}


try:
    from IPython.display import HTML, Markdown, display
    from IPython import get_ipython
except Exception:
    HTML = None
    Markdown = None
    display = None
    get_ipython = None


@dataclass
class StatusAmbiente:
    raiz: Path
    python: str
    provedor: str
    dependencias_ausentes: list[str] = field(default_factory=list)


def raiz_projeto(inicio: Optional[Path] = None) -> Path:
    atual = Path(inicio or Path.cwd()).resolve()

    for pasta in [atual] + list(atual.parents):
        if (
            (pasta / "produtos").exists()
            and (pasta / "publicos").exists()
            and (pasta / "prompts").exists()
        ):
            return pasta

    raise RuntimeError("Nao foi possivel localizar a raiz do projeto.")


def dependencias_ausentes(dependencias: dict[str, str]) -> list[str]:
    ausentes = []

    for modulo, pacote in dependencias.items():
        if importlib.util.find_spec(modulo) is None:
            ausentes.append(pacote)

    return sorted(set(ausentes))


def normalizar_provedor(provedor: Optional[str]) -> Optional[str]:
    if provedor is None:
        return None

    valor = str(provedor).strip().lower()

    if valor == "ollama":
        return "ollama"

    raise ValueError(
        "Provedor invalido: "
        + str(provedor)
        + "\n\nValores aceitos:\n"
        + "- nenhum argumento, para usar o Genera oficial;\n"
        + '- "ollama", para usar o testador local.'
    )


def preparar_ambiente(provedor: Optional[str]) -> StatusAmbiente:
    raiz = raiz_projeto()

    if str(raiz) not in sys.path:
        sys.path.insert(0, str(raiz))

    dependencias = dict(DEPENDENCIAS_BASE)
    nome_provedor = "Genera oficial"

    if provedor == "ollama":
        dependencias.update(DEPENDENCIAS_OLLAMA)
        nome_provedor = "Ollama local"
    else:
        dependencias.update(DEPENDENCIAS_OFICIAIS)

    return StatusAmbiente(
        raiz=raiz,
        python=".".join(str(parte) for parte in sys.version_info[:3]),
        provedor=nome_provedor,
        dependencias_ausentes=dependencias_ausentes(dependencias),
    )


def resolver_criador_provedor(provedor: Optional[str]) -> Any:
    if provedor is None:
        from .modelos import Genera

        return Genera

    if provedor == "ollama":
        try:
            modulo = importlib.import_module("src.ollama_local")
        except ModuleNotFoundError as erro:
            if erro.name == "src.ollama_local":
                raise RuntimeError(
                    "O testador local Ollama nao esta disponivel.\n\n"
                    "Arquivo esperado:\n"
                    "src/ollama_local.py\n\n"
                    "O fluxo oficial continua disponivel por meio de fluxo_geracao()."
                )
            raise

        if not hasattr(modulo, "ollama"):
            raise RuntimeError(
                "O arquivo src/ollama_local.py deve exportar um objeto chamado ollama."
            )

        if hasattr(modulo, "verificar_disponivel"):
            modulo.verificar_disponivel()

        return getattr(modulo, "ollama")

    raise ValueError("Provedor invalido.")


def em_notebook() -> bool:
    if display is None or get_ipython is None:
        return False

    shell = get_ipython()
    return shell is not None and shell.__class__.__name__ == "ZMQInteractiveShell"


def texto_curto(texto: Any, largura: int = 100) -> str:
    return textwrap.fill(" ".join(str(texto or "").split()), width=largura)


class Visual:
    def aplicar_estilo(self) -> None:
        if not em_notebook() or HTML is None:
            return

        display(
            HTML(
                """
                <style>
                .pc-wrap {
                    max-width: 980px;
                    font-family: Arial, sans-serif;
                    color: #1f2933;
                }
                .pc-hero {
                    border-left: 6px solid #f3c300;
                    padding: 14px 18px;
                    background: #f7f9fc;
                    margin: 8px 0 18px;
                }
                .pc-section {
                    margin: 18px 0 8px;
                    padding-bottom: 4px;
                    border-bottom: 1px solid #d8dee9;
                    font-size: 20px;
                    font-weight: 700;
                }
                .pc-card {
                    border: 1px solid #d8dee9;
                    border-radius: 8px;
                    margin: 10px 0;
                    background: #ffffff;
                }
                .pc-card > summary,
                .pc-final > summary {
                    cursor: pointer;
                    padding: 14px 16px;
                    font-weight: 700;
                    list-style: none;
                }
                .pc-card > summary::-webkit-details-marker,
                .pc-final > summary::-webkit-details-marker {
                    display: none;
                }
                .pc-card > summary:before,
                .pc-final > summary:before {
                    content: "+";
                    display: inline-block;
                    width: 18px;
                    color: #52606d;
                }
                .pc-card[open] > summary:before,
                .pc-final[open] > summary:before {
                    content: "-";
                }
                .pc-card-body,
                .pc-final-body {
                    padding: 0 16px 14px;
                }
                .pc-label {
                    font-size: 12px;
                    font-weight: 700;
                    letter-spacing: .02em;
                    text-transform: uppercase;
                    color: #52606d;
                    margin-bottom: 4px;
                }
                .pc-value {
                    white-space: pre-wrap;
                    line-height: 1.45;
                }
                .pc-muted {
                    color: #52606d;
                    font-size: 13px;
                }
                .pc-final {
                    border: 2px solid #f3c300;
                    border-radius: 8px;
                    margin: 14px 0;
                    background: #fffdf2;
                }
                .pc-flow-meta {
                    margin: 0 0 10px;
                    color: #52606d;
                    line-height: 1.45;
                }
                .pc-inner {
                    border-top: 1px solid #e4e7eb;
                    padding: 10px 0;
                    margin: 6px 0;
                }
                .pc-inner > summary {
                    cursor: pointer;
                    font-weight: 700;
                    list-style: none;
                }
                .pc-inner > summary:before {
                    content: "+";
                    display: inline-block;
                    width: 18px;
                    color: #52606d;
                }
                .pc-inner[open] > summary:before {
                    content: "-";
                }
                .pc-stage {
                    border-left: 3px solid #d8dee9;
                    padding-left: 12px;
                    margin: 14px 0;
                }
                .pc-stage-title {
                    font-weight: 700;
                    margin-bottom: 8px;
                }
                .pc-output-list {
                    padding-top: 2px;
                }
                .pc-output-item {
                    border-top: 1px solid #e4e7eb;
                    padding: 18px 0 20px;
                    margin: 0;
                }
                .pc-output-item:first-child {
                    border-top: 0;
                    padding-top: 8px;
                }
                .pc-output-title {
                    font-size: 18px;
                    font-weight: 800;
                    line-height: 1.3;
                    color: #102a43;
                    margin: 0 0 12px;
                }
                .pc-output-text {
                    white-space: pre-wrap;
                    line-height: 1.55;
                    font-size: 15px;
                    color: #1f2933;
                }
                .pc-output-main .pc-output-title {
                    font-size: 20px;
                    margin-bottom: 14px;
                }
                .pc-output-main .pc-output-text {
                    font-size: 16px;
                }
                .pc-progress {
                    border: 1px solid #d8dee9;
                    border-radius: 8px;
                    margin: 10px 0;
                    padding: 14px 16px;
                    background: #ffffff;
                }
                .pc-progress-title {
                    font-weight: 700;
                    margin-bottom: 4px;
                }
                .pc-progress-status {
                    color: #52606d;
                    font-size: 13px;
                    margin-bottom: 10px;
                    line-height: 1.45;
                }
                .pc-progress-track {
                    height: 10px;
                    border-radius: 999px;
                    background: #e4e7eb;
                    overflow: hidden;
                }
                .pc-progress-fill {
                    height: 100%;
                    border-radius: 999px;
                    background: #f3c300;
                    transition: width .25s ease;
                }
                .pc-progress-count {
                    color: #52606d;
                    font-size: 12px;
                    margin-top: 8px;
                }
                </style>
                """
            )
        )

    def titulo(self, texto: str, apoio: Optional[str] = None) -> None:
        if em_notebook() and HTML is not None:
            apoio_html = (
                f"<div class='pc-muted'>{html.escape(apoio)}</div>" if apoio else ""
            )
            display(
                HTML(
                    "<div class='pc-wrap pc-hero'>"
                    f"<h1 style='margin:0 0 6px'>{html.escape(texto)}</h1>"
                    f"{apoio_html}"
                    "</div>"
                )
            )
            return

        print("\n" + "=" * 80)
        print(texto.upper())
        if apoio:
            print(apoio)
        print("=" * 80)

    def secao(self, texto: str) -> None:
        if em_notebook() and HTML is not None:
            display(HTML(f"<div class='pc-wrap pc-section'>{html.escape(texto)}</div>"))
            return

        print("\n" + texto.upper())
        print("-" * len(texto))

    def ficha(self, titulo: str, dados: dict[str, Any]) -> None:
        if em_notebook() and HTML is not None:
            partes = []

            for chave, valor in dados.items():
                partes.append(
                    "<div style='margin:10px 0'>"
                    f"<div class='pc-label'>{html.escape(str(chave))}</div>"
                    f"<div class='pc-value'>{html.escape(str(valor or ''))}</div>"
                    "</div>"
                )

            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    + "".join(partes)
                    + "</div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        for chave, valor in dados.items():
            print(f"\n{chave}")
            print(texto_curto(valor))

    def bloco(self, titulo: str, texto: Any) -> None:
        if em_notebook() and HTML is not None:
            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    f"<div class='pc-value'>{html.escape(str(texto or ''))}</div>"
                    "</div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        print(texto_curto(texto))

    def bloco_partes(self, titulo: str, partes: list[dict[str, str]]) -> None:
        if em_notebook() and HTML is not None:
            html_partes = []

            for parte in partes:
                texto = html.escape(parte["texto"])
                html_partes.append(
                    f"<strong>{texto}</strong>"
                    if parte["tipo"] == "fixo"
                    else texto
                )

            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    "<div class='pc-value'>"
                    + "".join(html_partes)
                    + "</div></div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        print(
            "".join(
                f"**{parte['texto']}**"
                if parte["tipo"] == "fixo"
                else parte["texto"]
                for parte in partes
            )
        )

    def final(self, dados: dict[str, Any]) -> None:
        if em_notebook() and HTML is not None:
            partes = []

            for chave, valor in dados.items():
                partes.append(
                    "<div style='margin:12px 0'>"
                    f"<div class='pc-label'>{html.escape(str(chave))}</div>"
                    f"<div class='pc-value'>{html.escape(str(valor or ''))}</div>"
                    "</div>"
                )

            display(
                HTML(
                    "<details class='pc-wrap pc-final'>"
                    "<summary>Resultado final</summary>"
                    "<div class='pc-final-body'>"
                    + "".join(partes)
                    + "</div></details>"
                )
            )
            return

        self.ficha("Resultado final", dados)

    def progresso(
        self,
        titulo: str,
        atual: int,
        total: int,
        status: str,
        *,
        detalhe: str = "",
        handle: Any = None,
    ) -> Any:
        total_seguro = max(int(total or 1), 1)
        atual_seguro = max(0, min(int(atual), total_seguro))
        porcentagem = int((atual_seguro / total_seguro) * 100)

        if em_notebook() and HTML is not None:
            detalhe_html = (
                f"<br>{html.escape(detalhe)}"
                if detalhe
                else ""
            )
            conteudo = HTML(
                "<div class='pc-wrap pc-progress'>"
                f"<div class='pc-progress-title'>{html.escape(titulo)}</div>"
                "<div class='pc-progress-status'>"
                f"{html.escape(status)}{detalhe_html}"
                "</div>"
                "<div class='pc-progress-track'>"
                "<div class='pc-progress-fill' "
                f"style='width:{porcentagem}%'></div>"
                "</div>"
                "<div class='pc-progress-count'>"
                f"{atual_seguro}/{total_seguro} etapas concluidas"
                "</div>"
                "</div>"
            )

            if handle is not None and hasattr(handle, "update"):
                handle.update(conteudo)
                return handle

            return display(conteudo, display_id=True)

        print(f"{titulo}: {atual_seguro}/{total_seguro} - {status}")
        if detalhe:
            print(detalhe)
        return handle

    def limpar(self, handle: Any = None) -> None:
        if em_notebook() and HTML is not None:
            vazio = HTML("<div style='display:none'></div>")

            if handle is not None and hasattr(handle, "update"):
                handle.update(vazio)

    def opcoes(self, opcoes: list[str]) -> None:
        linhas = [
            f"{indice:>2}. {opcao.replace('_', ' ').title()}"
            for indice, opcao in enumerate(opcoes, start=1)
        ]

        if em_notebook() and Markdown is not None:
            display(Markdown("```text\n" + "\n".join(linhas) + "\n```"))
            return

        print("\n".join(linhas))

    def escolher(
        self,
        mensagem: str,
        opcoes: list[str],
        *,
        padrao: Optional[str] = None,
    ) -> str:
        if not opcoes:
            raise ValueError(f"Nenhuma opcao disponivel para: {mensagem}")

        self.opcoes(opcoes)

        indice_padrao = None
        if padrao in opcoes:
            indice_padrao = opcoes.index(padrao) + 1

        while True:
            sufixo = f" [{indice_padrao}]" if indice_padrao else ""
            valor = input(f"{mensagem}{sufixo}: ").strip()

            if not valor and indice_padrao:
                return opcoes[indice_padrao - 1]

            try:
                indice = int(valor)
                if 1 <= indice <= len(opcoes):
                    return opcoes[indice - 1]
            except ValueError:
                if valor in opcoes:
                    return valor

            print("Opcao invalida.")

    def numero(self, mensagem: str, padrao: int) -> int:
        while True:
            valor = input(f"{mensagem} [{padrao}]: ").strip()

            if not valor:
                return padrao

            try:
                numero = int(valor)
                if numero > 0:
                    return numero
            except ValueError:
                pass

            print("Informe um numero inteiro positivo.")

    def decimal(self, mensagem: str, padrao: float) -> float:
        while True:
            valor = input(f"{mensagem} [{padrao}]: ").strip()

            if not valor:
                return padrao

            try:
                numero = float(valor.replace(",", "."))
                if numero >= 0:
                    return numero
            except ValueError:
                pass

            print("Informe um numero decimal maior ou igual a zero.")

    def confirmar(self, mensagem: str, padrao: bool = True) -> bool:
        dica = "S/n" if padrao else "s/N"

        while True:
            valor = input(f"{mensagem} [{dica}]: ").strip().lower()

            if not valor:
                return padrao
            if valor in {"s", "sim", "y", "yes"}:
                return True
            if valor in {"n", "nao", "no"}:
                return False

            print("Responda com sim ou nao.")

    def debug_json(self, titulo: str, dados: dict[str, Any]) -> None:
        conteudo = json.dumps(dados, indent=2, ensure_ascii=False, default=str)

        if em_notebook() and HTML is not None:
            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    "<pre class='pc-value'>"
                    + html.escape(conteudo)
                    + "</pre></div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        print(conteudo)


class Experiencia:
    def __init__(
        self,
        motor: Any,
        status: StatusAmbiente,
        provedor: Optional[str],
    ):
        self.motor = motor
        self.status = status
        self.provedor = provedor
        self.criador_provedor = None
        self.parametros_por_etapa: dict[str, dict[str, Any]] = {}
        self.parametros_automaticos = True
        self.grupo_execucao_atual = ""
        self.fluxo_linear_iniciado = False
        self.loop_iniciado = False
        self.progresso_chamadas: dict[int, Any] = {}
        self.progresso_fluxo_handle = None
        self.progresso_fluxo_tendencia = ""
        self.progresso_fluxo_concluidas: dict[str, Any] = {}
        self.progresso_fluxo_prompts: dict[str, str] = {}
        self.resultado_tendencia_base = None
        self.fluxos_por_tendencia: dict[str, int] = {}
        self.tendencias_exibidas: set[str] = set()
        self.fluxos_exibidos_ao_vivo = 0
        self.fluxos_lineares: dict[str, int] = {}
        self.ui = Visual()

    def rodar(self) -> Any:
        self.ui.aplicar_estilo()
        self.ui.titulo(
            "Prompt Criativo",
            "Experiencia guiada para montar, comparar prompts e gerar mensagens.",
        )
        self.criador_provedor = resolver_criador_provedor(self.provedor)
        self.validar_catalogos()
        self.mostrar_status()

        produto = self.selecionar_produto()
        publico = self.selecionar_publico()
        apresentacao = self.selecionar_apresentacao(produto, publico)
        cenario = self.selecionar_cenario()

        self.ui.secao("Ajustes de geração")
        limite_tagline = self.ui.numero("Limite de caracteres da tagline", 100)
        limite_headline = self.ui.numero("Limite de caracteres da headline", 25)
        self.mostrar_configuracao(
            produto,
            publico,
            apresentacao,
            cenario,
            limite_tagline,
            limite_headline,
        )

        selecao = self.motor.Selecao(
            produto=produto.nome,
            publico=publico.nome,
            apresentacao=apresentacao.nome,
            cenario=cenario.nome,
            limite_tagline=limite_tagline,
            limite_headline=limite_headline,
        )

        self.parametros_automaticos = self.ui.confirmar(
            "Usar parametros automaticos?",
            padrao=True,
        )
        self.ui.ficha(
            "Escolha confirmada",
            {
                "Parametros": (
                    "automaticos"
                    if self.parametros_automaticos
                    else "configuracao manual por etapa"
                ),
            },
        )

        resultado = self.motor.rodar_fluxo(
            selecao,
            criador_provedor=self.criador_provedor,
            configurar_chamada=self.configurar_chamada,
            escolher_resultado=self.escolher_resultado,
            ao_resultado_etapa=self.mostrar_etapa_concluida,
            ao_inicio_prompt=self.mostrar_inicio_prompt,
            ao_fim_prompt=self.mostrar_fim_prompt,
            ao_conjunto_final=self.mostrar_conjunto_final_ao_vivo,
        )
        self.mostrar_resultado(resultado)
        return resultado

    def mostrar_status(self) -> None:
        self.ui.secao("Preparação")
        self.ui.ficha(
            "Tudo pronto",
            {
                "Provedor": self.status.provedor,
                "Status": "pronto",
                "Catalogos": "carregados",
            },
        )

    def validar_catalogos(self) -> None:
        erros = self.motor.validar_catalogos()

        if erros:
            self.ui.ficha(
                "Validacao dos catalogos",
                {
                    "Status": "Encontramos ajustes pendentes.",
                    "Erros": "\n".join(erros),
                },
            )
            raise RuntimeError("Catalogos com erros de validacao.")

    def selecionar_produto(self) -> Any:
        self.ui.secao("Produto")
        nome = self.ui.escolher("Escolha o produto", self.motor.listar_produtos())
        produto = self.motor.carregar_produto(nome)
        self.ui.ficha(
            produto.rotulo,
            {
                "Descricao": produto.descricao,
                "Beneficio racional": produto.beneficio_racional,
                "Beneficio emocional": produto.beneficio_emocional,
            },
        )
        return produto

    def selecionar_publico(self) -> Any:
        self.ui.secao("Publico")
        nome = self.ui.escolher("Escolha o publico", self.motor.listar_publicos())
        publico = self.motor.carregar_publico(nome)
        self.ui.ficha(
            publico.rotulo,
            {
                "Descricao": publico.descricao,
                "Necessidade racional": publico.necessidade_racional,
                "Necessidade emocional": publico.necessidade_emocional,
            },
        )
        return publico

    def selecionar_apresentacao(self, produto: Any, publico: Any) -> Any:
        self.ui.secao("Apresentacao")
        nome = self.ui.escolher(
            "Escolha a apresentacao",
            self.motor.listar_apresentacoes(),
        )
        apresentacao = self.motor.carregar_apresentacao(nome)
        previa = apresentacao.montar(produto, publico)

        self.ui.secao("Apresentação")
        self.ui.bloco("Template padrão", apresentacao.template)
        self.ui.bloco_partes("Apresentação preenchida", previa["partes"])

        return apresentacao

    def selecionar_cenario(self) -> Any:
        self.ui.secao("Cenario")
        nome = self.ui.escolher("Escolha o cenario", self.motor.listar_cenarios())
        cenario = self.motor.carregar_cenario(nome)
        self.ui.ficha(
            cenario.rotulo,
            {
                "Funcao": cenario.funcao_prompt,
                "Estrutura": cenario.texto_prompt,
            },
        )
        return cenario

    def mostrar_configuracao(
        self,
        produto: Any,
        publico: Any,
        apresentacao: Any,
        cenario: Any,
        limite_tagline: int,
        limite_headline: int,
    ) -> None:
        self.ui.secao("Escolhas iniciais")
        self.ui.ficha(
            "Escolhas confirmadas",
            {
                "Produto": produto.rotulo,
                "Publico": publico.rotulo,
                "Apresentacao": apresentacao.rotulo,
                "Cenario": cenario.rotulo,
                "Limite da tagline": limite_tagline,
                "Limite da headline": limite_headline,
            },
        )

    def escolher_resultado(self, etapa: Any, validos: list[Any]) -> str:
        opcoes = [resultado.identificador for resultado in validos]
        return self.ui.escolher(
            "Escolha o resultado que deve seguir no fluxo",
            opcoes,
            padrao=opcoes[0],
        )

    def titulo_execucao(self, etapa: Any, resultado: Any) -> str:
        if resultado.opcao and etapa.id == "tendencia_cognitiva":
            return (
                etapa.titulo
                + " - "
                + resultado.opcao.replace("_", " ").title()
                + " - "
                + resultado.prompt.nome
            )

        if resultado.opcao:
            return resultado.prompt.identificador

        return f"{etapa.titulo} - {resultado.prompt.identificador}"

    def grupo_execucao(self, etapa: Any, resultado: Any) -> str:
        if resultado.opcao:
            return (
                "Tendencia cognitiva - "
                + resultado.opcao.replace("_", " ").title()
            )

        return etapa.titulo

    def dados_entrada_execucao(self, resultado: Any) -> dict[str, Any]:
        dados = {
            "Template preenchido": resultado.template_preenchido,
            "System": resultado.system,
        }

        if resultado.opcao:
            dados["Opcao"] = resultado.opcao.replace("_", " ").title()

        return dados

    def mostrar_entrada_execucao(
        self,
        resultado: Any,
        titulo: Optional[str] = None,
    ) -> None:
        self.ui.ficha(
            f"Entrada - {titulo or resultado.identificador}",
            self.dados_entrada_execucao(resultado),
        )

    def mostrar_saida_execucao(
        self,
        resultado: Any,
        titulo: Optional[str] = None,
    ) -> None:
        titulo = titulo or resultado.identificador

        if resultado.valido:
            self.ui.ficha(
                f"Saída - {titulo}",
                {
                    "Texto gerado": resultado.output,
                },
            )
            return

        self.ui.ficha(
            f"Saída - {titulo}",
            {
                "Erro": resultado.erro,
            },
        )

    def mostrar_cards_execucao(self, resultado: Any, titulo: Optional[str] = None) -> None:
        titulo = titulo or resultado.identificador
        self.mostrar_entrada_execucao(resultado, titulo)
        self.mostrar_saida_execucao(resultado, titulo)

    def quantidade_prompts(self, grupo: str) -> int:
        try:
            return len(self.motor.listar_prompts(grupo))
        except Exception:
            return 0

    def mostrar_inicio_fluxo_linear(self) -> None:
        if self.fluxo_linear_iniciado:
            return

        self.ui.secao("Base criativa")
        self.ui.ficha(
            "Plano da base criativa",
            {
                "Etapas com escolha": "Revisor textual e Copywriter",
                "Revisor textual": (
                    str(self.quantidade_prompts("1_revisor_textual"))
                    + " prompt(s) disponivel(is)"
                ),
                "Copywriter": (
                    str(self.quantidade_prompts("2_copywriter"))
                    + " prompt(s) disponivel(is)"
                ),
                "Regra": "Quando houver mais de um resultado valido, voce escolhe qual segue.",
            },
        )
        self.fluxo_linear_iniciado = True

    def mostrar_inicio_loop(self, resultado: Any = None) -> None:
        if self.loop_iniciado:
            return

        total_tendencias = len(self.motor.listar_tendencias())
        prompts_tendencia = self.quantidade_prompts("3_tendencia_cognitiva")
        prompts_voz = self.quantidade_prompts("4_voz_BB")
        prompts_tagline = self.quantidade_prompts("5_tagline")
        prompts_headline = self.quantidade_prompts("6_headline")
        prompts_cta = self.quantidade_prompts("7_cta")
        previstos = (
            total_tendencias
            * max(prompts_tendencia, 1)
            * max(prompts_voz, 1)
            * max(prompts_tagline, 1)
            * max(prompts_headline, 1)
            * max(prompts_cta, 1)
        )

        self.ui.secao("Variações por tendência")
        self.ui.ficha(
            "Plano das variações",
            {
                "Tendencias processadas": total_tendencias,
                "Prompts de tendencia": prompts_tendencia,
                "Prompts de Voz BB": prompts_voz,
                "Prompts de tagline": prompts_tagline,
                "Prompts de headline": prompts_headline,
                "Prompts de CTA": prompts_cta,
                "Conjuntos finais previstos": previstos,
                "Regra": "Cada tendencia inicia um ramo independente, sem escolhas intermediarias.",
            },
        )
        self.loop_iniciado = True

    def configurar_parametros_variacoes(self) -> None:
        etapas = [
            etapa
            for etapa in self.motor.ETAPAS
            if self.etapa_automatica(etapa)
        ]

        if all(etapa.id in self.parametros_por_etapa for etapa in etapas):
            return

        self.ui.ficha(
            "Parametros manuais das variacoes",
            {
                "Aplicacao": (
                    "Os valores abaixo serao usados em todos os fluxos "
                    "automaticos por tendencia."
                ),
            },
        )

        for etapa in etapas:
            temperatura = self.ui.decimal(
                f"{etapa.titulo} - temperatura",
                float(etapa.temperature),
            )
            max_tokens = self.ui.numero(
                f"{etapa.titulo} - max tokens",
                int(etapa.max_tokens),
            )
            self.parametros_por_etapa[etapa.id] = {
                "temperature": temperatura,
                "max_tokens": max_tokens,
            }

    def etapa_automatica(self, etapa: Any) -> bool:
        return etapa.id in {
            "tendencia_cognitiva",
            "voz_bb",
            "tagline",
            "headline",
            "cta",
        }

    def mostrar_tendencia(self, tendencia: str) -> None:
        nome = tendencia or "Sem tendencia"

        if nome in self.tendencias_exibidas:
            return

        self.ui.secao(nome.replace("_", " ").title())
        self.tendencias_exibidas.add(nome)

    def rotulo_etapa(self, etapa_id: str) -> str:
        rotulos = {
            "tendencia_cognitiva": "Tendencia",
            "voz_bb": "Voz BB",
            "tagline": "Tagline",
            "headline": "Headline",
            "cta": "CTA",
            "revisor_textual": "Revisor textual",
            "copywriter": "Copywriter",
        }
        return rotulos.get(etapa_id, etapa_id)

    def caminho_progresso_fluxo(self) -> str:
        partes = []

        for etapa_id, _, _ in self.etapas_fluxo_final():
            prompt = self.progresso_fluxo_prompts.get(etapa_id)
            if prompt:
                partes.append(f"{self.rotulo_etapa(etapa_id)} {prompt}")

        return " -> ".join(partes)

    def preparar_progresso_automatico(self, etapa: Any, resultado: Any) -> None:
        if etapa.id == "tendencia_cognitiva":
            self.progresso_fluxo_handle = None
            self.progresso_fluxo_tendencia = resultado.opcao
            self.progresso_fluxo_concluidas = {}
            self.progresso_fluxo_prompts = {
                etapa.id: resultado.prompt.nome,
            }
            return

        if self.progresso_fluxo_handle is None:
            self.progresso_fluxo_tendencia = resultado.opcao
            self.progresso_fluxo_concluidas = {}
            self.progresso_fluxo_prompts = {}

            if (
                self.resultado_tendencia_base is not None
                and self.resultado_tendencia_base.opcao == resultado.opcao
            ):
                self.progresso_fluxo_concluidas["tendencia_cognitiva"] = (
                    self.resultado_tendencia_base
                )
                self.progresso_fluxo_prompts["tendencia_cognitiva"] = (
                    self.resultado_tendencia_base.prompt.nome
                )

        self.progresso_fluxo_prompts[etapa.id] = resultado.prompt.nome

    def atualizar_progresso_automatico(
        self,
        etapa: Any,
        resultado: Any,
        status: str,
    ) -> None:
        titulo = (
            "Gerando "
            + str(self.progresso_fluxo_tendencia or resultado.opcao)
            .replace("_", " ")
            .title()
        )
        detalhe = self.caminho_progresso_fluxo()
        atual = len(self.progresso_fluxo_concluidas)

        self.progresso_fluxo_handle = self.ui.progresso(
            titulo,
            atual,
            5,
            status,
            detalhe=detalhe,
            handle=self.progresso_fluxo_handle,
        )

    def mostrar_inicio_prompt(self, etapa: Any, resultado: Any) -> None:
        if etapa.id in {"revisor_textual", "copywriter"}:
            self.mostrar_inicio_fluxo_linear()

        if self.etapa_automatica(etapa):
            self.mostrar_inicio_loop(resultado)
            self.mostrar_tendencia(resultado.opcao)
            self.preparar_progresso_automatico(etapa, resultado)
            self.atualizar_progresso_automatico(
                etapa,
                resultado,
                f"Gerando {self.rotulo_etapa(etapa.id)} {resultado.prompt.nome}...",
            )
            return

        titulo = self.titulo_execucao(etapa, resultado)
        self.progresso_chamadas[id(resultado)] = self.ui.progresso(
            titulo,
            0,
            1,
            "Gerando resultado...",
        )

    def mostrar_fim_prompt(self, etapa: Any, resultado: Any) -> None:
        if self.etapa_automatica(etapa):
            if resultado.valido:
                self.progresso_fluxo_concluidas[etapa.id] = resultado
                self.progresso_fluxo_prompts[etapa.id] = resultado.prompt.nome

                if etapa.id == "tendencia_cognitiva":
                    self.resultado_tendencia_base = resultado

            self.atualizar_progresso_automatico(
                etapa,
                resultado,
                (
                    f"{self.rotulo_etapa(etapa.id)} concluida."
                    if resultado.valido
                    else f"{self.rotulo_etapa(etapa.id)} nao concluida."
                ),
            )
            return

        titulo = self.titulo_execucao(etapa, resultado)
        handle = self.progresso_chamadas.pop(id(resultado), None)
        self.ui.limpar(handle)
        self.mostrar_fluxo_linear(etapa, resultado)

    def configurar_chamada(
        self,
        etapa: Any,
        prompt: Any,
        opcao: str,
        parametros: dict[str, Any],
    ) -> dict[str, Any]:
        if self.parametros_automaticos:
            return dict(parametros)

        if self.etapa_automatica(etapa):
            self.mostrar_inicio_loop()
            self.configurar_parametros_variacoes()
            return dict(self.parametros_por_etapa[etapa.id])

        if etapa.id in self.parametros_por_etapa:
            return dict(self.parametros_por_etapa[etapa.id])

        vinculo = {
            "Etapa": etapa.titulo,
            "Prompt inicial": prompt.identificador,
            "Aplicacao": "todos os prompts desta etapa",
            "Valores padrao": (
                f"temperature={parametros['temperature']} | "
                f"max_tokens={parametros['max_tokens']}"
            ),
        }

        if opcao:
            vinculo["Primeira variacao"] = opcao.replace("_", " ").title()

        self.ui.secao(f"Parametros da etapa: {etapa.titulo}")
        self.ui.ficha("Configuracao vinculada", vinculo)
        temperatura = self.ui.decimal(
            f"Temperatura - {etapa.titulo}",
            float(parametros["temperature"]),
        )
        max_tokens = self.ui.numero(
            f"Quantidade maxima de tokens - {etapa.titulo}",
            int(parametros["max_tokens"]),
        )

        ajustes = {
            "temperature": temperatura,
            "max_tokens": max_tokens,
        }
        self.parametros_por_etapa[etapa.id] = ajustes
        return dict(ajustes)

    def mostrar_etapa_concluida(self, etapa: Any) -> None:
        selecionado = etapa.resultado_selecionado()

        if selecionado is None:
            return

        self.ui.ficha(
            f"Escolha confirmada - {etapa.titulo}",
            {
                "Resultado escolhido": etapa.prompt_selecionado,
                "Status": "concluido",
            },
        )

    def prompt_oficial_resultado(self, etapa: Any, resultado: Any) -> dict[str, Any]:
        return {
            "etapa": etapa.titulo,
            "prompt": resultado.prompt.nome,
            "arquivo_prompt": resultado.prompt.identificador,
            "opcao": resultado.opcao,
            "mensagens_enviadas": [
                {
                    "role": "system",
                    "content": resultado.system,
                },
                {
                    "role": "user",
                    "tipo": "template",
                    "content": resultado.template_preenchido,
                },
                {
                    "role": "user",
                    "tipo": "entrada",
                    "content": resultado.entrada,
                },
            ],
            "parametros": {
                "temperature": resultado.parametros.get("temperature"),
                "max_tokens": resultado.parametros.get("max_tokens"),
                "top_p": resultado.parametros.get("top_p"),
                "frequency_penalty": resultado.parametros.get("frequency_penalty"),
                "presence_penalty": resultado.parametros.get("presence_penalty"),
                "best_of": resultado.parametros.get("best_of"),
            },
        }

    def html_prompt_oficial_resultado(self, etapa: Any, resultado: Any) -> str:
        conteudo = json.dumps(
            self.prompt_oficial_resultado(etapa, resultado),
            indent=2,
            ensure_ascii=False,
            default=str,
        )
        return (
            "<pre class='pc-value' style='overflow:auto; white-space:pre-wrap'>"
            + html.escape(conteudo)
            + "</pre>"
        )

    def mostrar_fluxo_linear(self, etapa: Any, resultado: Any) -> None:
        numero = self.fluxos_lineares.get(etapa.id, 0) + 1
        self.fluxos_lineares[etapa.id] = numero
        titulo = (
            f"{etapa.titulo} - Alternativa {numero} - "
            f"{resultado.prompt.nome} - "
            + ("pronta" if resultado.valido else "não concluída")
        )

        if em_notebook() and HTML is not None:
            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    "<div class='pc-flow-meta'>"
                    f"Caminho: {html.escape(etapa.titulo)} {html.escape(resultado.prompt.nome)}<br>"
                    f"Status: {'pronta' if resultado.valido else 'não concluída'}"
                    "</div>"
                    "<details class='pc-inner'>"
                    f"<summary>Entrada - alternativa {numero}</summary>"
                    + self.html_entrada_resultados([resultado])
                    + "</details>"
                    "<details class='pc-inner'>"
                    f"<summary>Saída - alternativa {numero}</summary>"
                    + self.html_saida_lista(
                        [
                            (
                                "Texto gerado" if resultado.valido else "Erro",
                                resultado.output if resultado.valido else resultado.erro,
                            )
                        ],
                        destaque_primeiro=True,
                    )
                    + "</details>"
                    "<details class='pc-inner'>"
                    f"<summary>Prompt oficial enviado para LLM - alternativa {numero} - JSON</summary>"
                    + self.html_prompt_oficial_resultado(etapa, resultado)
                    + "</details>"
                    "</div></details>"
                )
            )
            return

        self.ui.ficha(
            titulo,
            {
                "Templates preenchidos": resultado.template_preenchido,
                "System": resultado.system,
                "Saída": resultado.output if resultado.valido else resultado.erro,
                "Prompt oficial enviado para LLM": json.dumps(
                    self.prompt_oficial_resultado(etapa, resultado),
                    indent=2,
                    ensure_ascii=False,
                    default=str,
                ),
            },
        )

    def mostrar_conjunto_final_ao_vivo(self, conjunto: Any) -> None:
        tendencia = conjunto.tendencia or "Sem tendencia"
        numero = self.fluxos_por_tendencia.get(tendencia, 0) + 1
        self.fluxos_por_tendencia[tendencia] = numero

        self.progresso_fluxo_concluidas = {
            resultado.prompt.grupo: resultado
            for resultado in conjunto.resultados
        }
        self.progresso_fluxo_prompts = {
            etapa_id: self.prompt_do_conjunto(conjunto, etapa_id)
            for etapa_id, _, _ in self.etapas_fluxo_final()
        }
        self.progresso_fluxo_tendencia = tendencia

        self.ui.progresso(
            "Variação: " + tendencia.replace("_", " ").title(),
            5,
            5,
            f"Fluxo {numero} pronto.",
            detalhe=self.caminho_fluxo(conjunto),
            handle=self.progresso_fluxo_handle,
        )
        self.ui.limpar(self.progresso_fluxo_handle)
        self.mostrar_fluxo_conjunto(conjunto, numero)
        self.fluxos_exibidos_ao_vivo += 1
        self.progresso_fluxo_handle = None
        self.progresso_fluxo_concluidas = {}
        self.progresso_fluxo_prompts = {}

    def mostrar_resultado(self, resultado: Any) -> None:
        self.ui.secao("Resultados finais")

        if resultado.conjuntos:
            self.ui.final(
                {
                    "Total de conjuntos gerados": len(resultado.conjuntos),
                    "Regra": "Cada resultado representa um caminho completo de geração.",
                }
            )
            if self.fluxos_exibidos_ao_vivo == 0:
                self.mostrar_conjuntos(resultado.conjuntos)
        else:
            self.ui.final(
                {
                    "Headline": resultado.headline,
                    "Tagline": resultado.tagline,
                    "CTA": resultado.cta,
                    "Resumo institucional": resultado.resumo_institucional,
                }
            )

    def prompt_do_conjunto(self, conjunto: Any, etapa_id: str) -> str:
        valor = str(conjunto.prompts.get(etapa_id, ""))
        valor = valor.split(" - ")[0]

        if "/" in valor:
            return valor.rsplit("/", 1)[-1]

        return valor

    def etapas_fluxo_final(self) -> list[tuple[str, str, str]]:
        return [
            ("tendencia_cognitiva", "Tendencia cognitiva", "3_tendencia_cognitiva"),
            ("voz_bb", "Voz Institucional BB", "4_voz_BB"),
            ("tagline", "Tagline", "5_tagline"),
            ("headline", "Headline", "6_headline"),
            ("cta", "CTA", "7_cta"),
        ]

    def resultado_conjunto_etapa(self, conjunto: Any, grupo_prompt: str) -> Any:
        for resultado in conjunto.resultados:
            if resultado.prompt.grupo == grupo_prompt:
                return resultado

        return None

    def caminho_fluxo(self, conjunto: Any) -> str:
        partes = []
        rotulos = {
            "tendencia_cognitiva": "Tendencia",
            "voz_bb": "Voz BB",
            "tagline": "Tagline",
            "headline": "Headline",
            "cta": "CTA",
        }

        for etapa_id, _, _ in self.etapas_fluxo_final():
            prompt = self.prompt_do_conjunto(conjunto, etapa_id)
            if prompt:
                partes.append(f"{rotulos[etapa_id]} {prompt}")

        return " -> ".join(partes)

    def html_valor(self, chave: str, valor: Any) -> str:
        return (
            "<div style='margin:8px 0'>"
            f"<div class='pc-label'>{html.escape(str(chave))}</div>"
            f"<div class='pc-value'>{html.escape(str(valor or ''))}</div>"
            "</div>"
        )

    def html_saida_valor(
        self,
        titulo: str,
        valor: Any,
        *,
        destaque: bool = False,
    ) -> str:
        classe = "pc-output-item pc-output-main" if destaque else "pc-output-item"
        return (
            f"<div class='{classe}'>"
            f"<div class='pc-output-title'>{html.escape(str(titulo))}</div>"
            f"<div class='pc-output-text'>{html.escape(str(valor or ''))}</div>"
            "</div>"
        )

    def html_saida_lista(
        self,
        itens: list[tuple[str, Any]],
        *,
        destaque_primeiro: bool = False,
    ) -> str:
        partes = []

        for indice, (titulo, valor) in enumerate(itens):
            partes.append(
                self.html_saida_valor(
                    titulo,
                    valor,
                    destaque=destaque_primeiro and indice == 0,
                )
            )

        return "<div class='pc-output-list'>" + "".join(partes) + "</div>"

    def html_templates_resultados(
        self,
        resultados: list[Any],
    ) -> str:
        partes = []

        for indice, resultado in enumerate(resultados, start=1):
            partes.append(
                "<div class='pc-stage'>"
                f"<div class='pc-stage-title'>{indice}. "
                f"{html.escape(resultado.prompt.identificador)}</div>"
                + self.html_valor(
                    "Template preenchido",
                    resultado.template_preenchido,
                )
                + "</div>"
            )

        return "".join(partes)

    def html_system_resultados(
        self,
        resultados: list[Any],
    ) -> str:
        vistos: dict[str, list[str]] = {}

        for resultado in resultados:
            vistos.setdefault(str(resultado.system or ""), []).append(
                resultado.prompt.identificador
            )

        partes = []

        for indice, (system, prompts) in enumerate(vistos.items(), start=1):
            titulo = (
                "System"
                if len(vistos) == 1
                else f"System {indice}"
            )
            partes.append(
                "<div class='pc-stage'>"
                f"<div class='pc-stage-title'>{html.escape(titulo)}</div>"
                + self.html_valor("Usado em", ", ".join(prompts))
                + self.html_valor("Conteudo", system)
                + "</div>"
            )

        return "".join(partes)

    def html_entrada_resultados(self, resultados: list[Any]) -> str:
        return (
            "<details class='pc-inner'>"
            "<summary>Templates com placeholders preenchidos</summary>"
            + self.html_templates_resultados(resultados)
            + "</details>"
            "<details class='pc-inner'>"
            "<summary>System enviado</summary>"
            + self.html_system_resultados(resultados)
            + "</details>"
        )

    def html_entrada_fluxo(self, conjunto: Any) -> str:
        resultados = []

        for _, _, grupo_prompt in self.etapas_fluxo_final():
            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is not None:
                resultados.append(resultado)

        return self.html_entrada_resultados(resultados)

    def html_saida_fluxo(self, conjunto: Any) -> str:
        saidas = [
            ("3_tendencia_cognitiva", "Texto com tendencia"),
            ("4_voz_BB", "Texto com Voz BB"),
            ("5_tagline", "Tagline"),
            ("6_headline", "Headline"),
            ("7_cta", "CTA"),
        ]
        itens = []

        for grupo_prompt, titulo in saidas:
            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is None:
                continue

            itens.append((titulo, resultado.output))

        return self.html_saida_lista(itens, destaque_primeiro=True)

    def prompt_oficial_fluxo(self, conjunto: Any) -> dict[str, Any]:
        etapas = []

        for _, titulo, grupo_prompt in self.etapas_fluxo_final():
            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is None:
                continue

            etapas.append(
                {
                    "etapa": titulo,
                    "prompt": resultado.prompt.nome,
                    "arquivo_prompt": resultado.prompt.identificador,
                    "opcao": resultado.opcao,
                    "mensagens_enviadas": [
                        {
                            "role": "system",
                            "content": resultado.system,
                        },
                        {
                            "role": "user",
                            "tipo": "template",
                            "content": resultado.template_preenchido,
                        },
                        {
                            "role": "user",
                            "tipo": "entrada",
                            "content": resultado.entrada,
                        },
                    ],
                    "parametros": {
                        "temperature": resultado.parametros.get("temperature"),
                        "max_tokens": resultado.parametros.get("max_tokens"),
                        "top_p": resultado.parametros.get("top_p"),
                        "frequency_penalty": resultado.parametros.get(
                            "frequency_penalty"
                        ),
                        "presence_penalty": resultado.parametros.get(
                            "presence_penalty"
                        ),
                        "best_of": resultado.parametros.get("best_of"),
                    },
                }
            )

        return {
            "tendencia": conjunto.tendencia,
            "caminho": self.caminho_fluxo(conjunto),
            "etapas": etapas,
        }

    def html_prompt_oficial_fluxo(self, conjunto: Any) -> str:
        conteudo = json.dumps(
            self.prompt_oficial_fluxo(conjunto),
            indent=2,
            ensure_ascii=False,
            default=str,
        )
        return (
            "<pre class='pc-value' style='overflow:auto; white-space:pre-wrap'>"
            + html.escape(conteudo)
            + "</pre>"
        )

    def mostrar_fluxo_conjunto(
        self,
        conjunto: Any,
        numero: int,
    ) -> None:
        caminho = self.caminho_fluxo(conjunto)

        if em_notebook() and HTML is not None:
            titulo = f"Fluxo {numero} - {caminho}"
            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    f"<summary>{html.escape(titulo)}</summary>"
                    "<div class='pc-card-body'>"
                    "<div class='pc-flow-meta'>"
                    f"Caminho: {html.escape(caminho)}<br>"
                    "Status: pronto"
                    "</div>"
                    "<details class='pc-inner'>"
                    f"<summary>Entradas - fluxo {numero}</summary>"
                    + self.html_entrada_fluxo(conjunto)
                    + "</details>"
                    "<details class='pc-inner'>"
                    f"<summary>Resultados gerados - fluxo {numero}</summary>"
                    + self.html_saida_fluxo(conjunto)
                    + "</details>"
                    "<details class='pc-inner'>"
                    f"<summary>Prompt enviado para LLM - fluxo {numero} - JSON</summary>"
                    + self.html_prompt_oficial_fluxo(conjunto)
                    + "</details>"
                    "</div></details>"
                )
            )
            return

        self.ui.ficha(
            f"Fluxo {numero} - {caminho}",
            {
                "Caminho": caminho,
                "Status": "pronto",
                "Entradas": "\n".join(
                    f"{titulo}: {self.prompt_do_conjunto(conjunto, etapa_id)}"
                    for etapa_id, titulo, _ in self.etapas_fluxo_final()
                ),
                "Texto com tendencia": (
                    self.resultado_conjunto_etapa(
                        conjunto,
                        "3_tendencia_cognitiva",
                    ).output
                ),
                "Texto com Voz BB": conjunto.texto_institucional,
                "Tagline": conjunto.tagline,
                "Headline": conjunto.headline,
                "CTA": conjunto.cta,
                "Prompt enviado para LLM": json.dumps(
                    self.prompt_oficial_fluxo(conjunto),
                    indent=2,
                    ensure_ascii=False,
                    default=str,
                ),
            },
        )

    def mostrar_conjuntos(self, conjuntos: list[Any]) -> None:
        self.ui.secao("Fluxos gerados")
        grupos: dict[str, list[Any]] = {}

        for conjunto in conjuntos:
            grupos.setdefault(conjunto.tendencia or "Sem tendencia", []).append(conjunto)

        for indice_tendencia, (tendencia, conjuntos_tendencia) in enumerate(
            grupos.items(),
            start=1,
        ):
            self.mostrar_tendencia(tendencia)
            self.ui.ficha(
                f"Resumo da variação {indice_tendencia}",
                {
                    "Tendencia": tendencia,
                    "Resultados gerados": len(conjuntos_tendencia),
                    "Regra": "Cada resultado abaixo e uma combinacao completa de prompts.",
                },
            )

            for numero, conjunto in enumerate(conjuntos_tendencia, start=1):
                self.mostrar_fluxo_conjunto(conjunto, numero)


def fluxo_geracao(provedor: Optional[str] = None) -> Any:
    """Entrada unica chamada pela rotina-principal.ipynb."""

    provedor_normalizado = normalizar_provedor(provedor)
    status = preparar_ambiente(provedor_normalizado)

    if status.dependencias_ausentes:
        raise RuntimeError(
            "Dependencias ausentes: "
            + ", ".join(status.dependencias_ausentes)
            + "\n\nInstale as dependencias do projeto antes de executar o fluxo."
        )

    motor = importlib.import_module("src.motor")

    return Experiencia(
        motor=motor,
        status=status,
        provedor=provedor_normalizado,
    ).rodar()
