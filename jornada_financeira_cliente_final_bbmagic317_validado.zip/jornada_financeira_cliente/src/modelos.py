"""Contratos internos da Jornada Financeira do Cliente."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date
from enum import Enum
from typing import Any


class EstadoCalculo(str, Enum):
    CALCULADO = "CALCULADO"
    DISPONIVEL_COM_RESSALVAS = "DISPONIVEL_COM_RESSALVAS"
    INDISPONIVEL = "INDISPONIVEL"
    NAO_CALCULAVEL = "NAO_CALCULAVEL"
    SEM_DADOS = "SEM_DADOS"


class EstadoMotorCirculacao(str, Enum):
    CANDIDATO_FORTE = "CANDIDATO_FORTE"
    CANDIDATO_MODERADO = "CANDIDATO_MODERADO"
    CANDIDATO_FRACO = "CANDIDATO_FRACO"
    AMBIGUO = "AMBIGUO"
    DESCARTADO_POR_CONFLITO = "DESCARTADO_POR_CONFLITO"


class EstadoRevisao(str, Enum):
    NAO_REVISADO = "NAO_REVISADO"
    CONFIRMADO = "CONFIRMADO"
    REJEITADO = "REJEITADO"


class EstadoDuplicidade(str, Enum):
    SEM_SINAL = "SEM_SINAL"
    DUPLICIDADE_FISICA = "DUPLICIDADE_FISICA"
    DUPLICIDADE_ECONOMICA_FORTE = "DUPLICIDADE_ECONOMICA_FORTE"
    DUPLICIDADE_PROVAVEL = "DUPLICIDADE_PROVAVEL"
    AMBIGUA = "AMBIGUA"


class TipoEntradaAnalitica(str, Enum):
    ENTRADA_EXTERNA_PROVAVEL = "ENTRADA_EXTERNA_PROVAVEL"
    SALARIO_PROVAVEL = "SALARIO_PROVAVEL"
    RENDA_RECORRENTE_PROVAVEL = "RENDA_RECORRENTE_PROVAVEL"
    MOVIMENTACAO_INTERNA_PROVAVEL = "MOVIMENTACAO_INTERNA_PROVAVEL"
    CREDITO_CONTRATADO_PROVAVEL = "CREDITO_CONTRATADO_PROVAVEL"
    RESGATE_INVESTIMENTO_PROVAVEL = "RESGATE_INVESTIMENTO_PROVAVEL"
    DEVOLUCAO_AJUSTE_PROVAVEL = "DEVOLUCAO_AJUSTE_PROVAVEL"
    DUPLICIDADE_PROVAVEL = "DUPLICIDADE_PROVAVEL"
    ENTRADA_INCONCLUSIVA = "ENTRADA_INCONCLUSIVA"


@dataclass(frozen=True)
class ConsultaPainel:
    cd_cli: int
    periodo_inicio: date
    periodo_fim: date
    moeda: str
    instituicoes: tuple[int, ...] = ()
    tela_inicial: str = "jornada_dinheiro"

    def to_dict(self, *, serializar_datas: bool = True) -> dict[str, Any]:
        dados = asdict(self)
        if serializar_datas:
            dados["periodo_inicio"] = self.periodo_inicio.isoformat()
            dados["periodo_fim"] = self.periodo_fim.isoformat()
        return dados

    def to_public_dict(self) -> dict[str, Any]:
        """Representação segura, sem o identificador restrito do cliente."""
        return {
            "periodo_inicio": self.periodo_inicio.isoformat(),
            "periodo_fim": self.periodo_fim.isoformat(),
            "moeda": self.moeda,
            "instituicoes": list(self.instituicoes),
            "tela_inicial": self.tela_inicial,
        }


@dataclass(frozen=True)
class ResultadoPercentual:
    valor: float | None
    estado: str
    motivo: str | None = None


@dataclass
class EvidenciaCirculacao:
    codigo: str
    peso: int
    descricao: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ParCirculacao:
    id_par: str
    id_saida: str
    id_entrada: str
    valor_centavos: int
    moeda: str
    data_saida: str
    data_entrada: str
    diferenca_dias: int
    conta_origem_id: str
    conta_destino_id: str
    conta_origem: str
    conta_destino: str
    instituicao_origem: str
    instituicao_destino: str
    indice_evidencia: int
    evidencias: list[EvidenciaCirculacao] = field(default_factory=list)
    alertas: list[str] = field(default_factory=list)
    estado_motor: str = EstadoMotorCirculacao.CANDIDATO_FRACO.value
    estado_revisao: str = EstadoRevisao.NAO_REVISADO.value
    selecionado_motor: bool = False
    usado_estimativa: bool = False
    recorrente: bool = False

    def to_dict(self) -> dict[str, Any]:
        dados = asdict(self)
        dados["valor"] = self.valor_centavos / 100
        return dados


@dataclass
class EvidenciaAnalitica:
    codigo: str
    descricao: str
    peso: int | None = None
    valor_observado: Any | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


__all__ = [
    "EstadoCalculo", "EstadoMotorCirculacao", "EstadoRevisao",
    "EstadoDuplicidade", "TipoEntradaAnalitica", "ConsultaPainel",
    "ResultadoPercentual", "EvidenciaCirculacao", "ParCirculacao",
    "EvidenciaAnalitica",
]
