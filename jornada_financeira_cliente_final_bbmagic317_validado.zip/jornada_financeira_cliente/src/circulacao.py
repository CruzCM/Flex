"""Motor heurístico e auditável de circulação provável entre contas.

O motor não confirma titularidade nem transforma candidatos em fatos. Ele gera
pares um-para-um, registra evidências, conserva ambiguidades e produz uma base
estimada separada da base observada.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import replace
from hashlib import sha1
from typing import Any, Iterable

import pandas as pd

from .modelos import EvidenciaCirculacao, ParCirculacao
from .regras import (
    JANELA_PAREAMENTO_DIAS,
    PENALIDADE_AMBIGUIDADE,
    PESOS_EVIDENCIAS_CIRCULACAO,
    TERMOS_CIRCULACAO,
    TERMOS_CONFLITANTES,
    classificar_evidencia,
)


def _texto(valor: Any) -> str:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return ""
    return str(valor).strip()


def _evidencia(codigo: str, descricao: str) -> EvidenciaCirculacao:
    return EvidenciaCirculacao(
        codigo=codigo,
        peso=PESOS_EVIDENCIAS_CIRCULACAO[codigo],
        descricao=descricao,
    )


def _tem_termo(texto: str, termos: Iterable[str]) -> bool:
    texto = _texto(texto).upper()
    return any(termo in texto for termo in termos)


def _contas_suficientemente_diferentes(saida: pd.Series, entrada: pd.Series) -> bool:
    origem = _texto(saida.get("conta_id"))
    destino = _texto(entrada.get("conta_id"))
    if origem and destino and origem != "CONTA_NAO_IDENTIFICADA" and destino != "CONTA_NAO_IDENTIFICADA":
        return origem != destino
    inst_origem = _texto(saida.get("instituicao_codigo"))
    inst_destino = _texto(entrada.get("instituicao_codigo"))
    seq_origem = _texto(saida.get("conta_sequencial"))
    seq_destino = _texto(entrada.get("conta_sequencial"))
    if inst_origem and inst_destino and inst_origem != inst_destino:
        return True
    return bool(seq_origem and seq_destino and seq_origem != seq_destino)


def _conta_contraparte_compativel(saida: pd.Series, entrada: pd.Series) -> bool:
    conta_destino = _texto(entrada.get("conta_numero_normalizado"))
    conta_origem = _texto(saida.get("conta_numero_normalizado"))
    cp_saida = _texto(saida.get("contraparte_conta_normalizada"))
    cp_entrada = _texto(entrada.get("contraparte_conta_normalizada"))
    id_destino = _texto(entrada.get("conta_identificador_externo"))
    id_origem = _texto(saida.get("conta_identificador_externo"))
    cp_id_saida = _texto(saida.get("contraparte_conta_id"))
    cp_id_entrada = _texto(entrada.get("contraparte_conta_id"))
    return any(
        (
            cp_saida and conta_destino and cp_saida == conta_destino,
            cp_entrada and conta_origem and cp_entrada == conta_origem,
            cp_id_saida and id_destino and cp_id_saida == id_destino,
            cp_id_entrada and id_origem and cp_id_entrada == id_origem,
        )
    )


def _criar_par(saida: pd.Series, entrada: pd.Series) -> ParCirculacao | None:
    if int(saida.get("valor_centavos", 0)) <= 0:
        return None
    if int(saida.get("valor_centavos", 0)) != int(entrada.get("valor_centavos", 0)):
        return None
    if _texto(saida.get("moeda")) != _texto(entrada.get("moeda")):
        return None
    if _texto(saida.get("natureza")) != "D" or _texto(entrada.get("natureza")) != "C":
        return None
    data_saida = pd.to_datetime(saida.get("data"), errors="coerce")
    data_entrada = pd.to_datetime(entrada.get("data"), errors="coerce")
    if pd.isna(data_saida) or pd.isna(data_entrada):
        return None
    diferenca_dias = abs((data_entrada.date() - data_saida.date()).days)
    if diferenca_dias > JANELA_PAREAMENTO_DIAS:
        return None
    if not _contas_suficientemente_diferentes(saida, entrada):
        return None

    evidencias = [
        _evidencia("VALOR_EXATO", "As duas pontas possuem o mesmo valor em centavos."),
        _evidencia("MESMA_MOEDA", "As duas pontas estão na mesma moeda."),
        _evidencia("NATUREZAS_OPOSTAS", "Uma ponta é saída e a outra é entrada."),
        _evidencia("CONTAS_DIFERENTES", "As pontas pertencem a contas observadas diferentes."),
    ]
    if diferenca_dias == 0:
        evidencias.append(_evidencia("MESMO_DIA", "As pontas ocorreram no mesmo dia."))
    elif diferenca_dias == 1:
        evidencias.append(_evidencia("UM_DIA_DIFERENCA", "As pontas ocorreram com um dia de diferença."))
    else:
        evidencias.append(_evidencia("DOIS_OU_TRES_DIAS", "As pontas ocorreram em até três dias."))

    if _texto(saida.get("instituicao_codigo")) != _texto(entrada.get("instituicao_codigo")):
        evidencias.append(
            _evidencia("INSTITUICOES_DIFERENTES", "As pontas estão em instituições diferentes.")
        )

    descricao = f"{_texto(saida.get('descricao_normalizada'))} {_texto(entrada.get('descricao_normalizada'))}"
    if _tem_termo(descricao, TERMOS_CIRCULACAO):
        evidencias.append(
            _evidencia("DESCRICAO_COMPATIVEL", "A descrição contém termo compatível com circulação.")
        )
    if _tem_termo(descricao, TERMOS_CONFLITANTES):
        evidencias.append(
            _evidencia("DESCRICAO_CONFLITANTE", "A descrição contém termo que pode indicar operação externa.")
        )
    if _conta_contraparte_compativel(saida, entrada):
        evidencias.append(
            _evidencia(
                "CONTRAPARTE_CONTA_COMPATIVEL",
                "A conta da contraparte é compatível com a outra ponta observada.",
            )
        )
    if bool(saida.get("contraparte_titular_cliente")) or bool(entrada.get("contraparte_titular_cliente")):
        evidencias.append(
            _evidencia(
                "CONTRAPARTE_TITULAR_COMPATIVEL",
                "A contraparte é compatível com documento de titular observado, sem expor o documento.",
            )
        )

    indice = sum(e.peso for e in evidencias)
    id_saida = _texto(saida.get("id_movimento"))
    id_entrada = _texto(entrada.get("id_movimento"))
    id_par = "PAR-" + sha1(f"{id_saida}|{id_entrada}".encode("utf-8")).hexdigest()[:12].upper()
    return ParCirculacao(
        id_par=id_par,
        id_saida=id_saida,
        id_entrada=id_entrada,
        valor_centavos=int(saida.get("valor_centavos", 0)),
        moeda=_texto(saida.get("moeda")),
        data_saida=data_saida.date().isoformat(),
        data_entrada=data_entrada.date().isoformat(),
        diferenca_dias=diferenca_dias,
        conta_origem_id=_texto(saida.get("conta_id")),
        conta_destino_id=_texto(entrada.get("conta_id")),
        conta_origem=_texto(saida.get("conta_rotulo")),
        conta_destino=_texto(entrada.get("conta_rotulo")),
        instituicao_origem=_texto(saida.get("instituicao_rotulo")),
        instituicao_destino=_texto(entrada.get("instituicao_rotulo")),
        indice_evidencia=indice,
        evidencias=evidencias,
        estado_motor=classificar_evidencia(indice),
    )


def gerar_candidatos(movimentos: pd.DataFrame) -> list[ParCirculacao]:
    if movimentos.empty:
        return []
    obrigatorias = {"valor_centavos", "moeda", "natureza", "data", "id_movimento"}
    ausentes = obrigatorias - set(movimentos.columns)
    if ausentes:
        raise ValueError(f"Base de circulação sem colunas obrigatórias: {sorted(ausentes)}")

    candidatos: list[ParCirculacao] = []
    agrupado = movimentos.groupby(["moeda", "valor_centavos"], dropna=False, sort=False)
    for (_, valor), grupo in agrupado:
        if int(valor or 0) <= 0:
            continue
        saidas = grupo[grupo["natureza"] == "D"].sort_values("data")
        entradas = grupo[grupo["natureza"] == "C"].sort_values("data")
        if saidas.empty or entradas.empty:
            continue
        for _, saida in saidas.iterrows():
            data_saida = pd.to_datetime(saida["data"], errors="coerce")
            if pd.isna(data_saida):
                continue
            minimo = data_saida - pd.Timedelta(days=JANELA_PAREAMENTO_DIAS)
            maximo = data_saida + pd.Timedelta(days=JANELA_PAREAMENTO_DIAS)
            entradas_janela = entradas[
                (pd.to_datetime(entradas["data"], errors="coerce") >= minimo)
                & (pd.to_datetime(entradas["data"], errors="coerce") <= maximo)
            ]
            for _, entrada in entradas_janela.iterrows():
                par = _criar_par(saida, entrada)
                if par is not None:
                    candidatos.append(par)
    return candidatos


def detectar_recorrencia(candidatos: list[ParCirculacao]) -> list[ParCirculacao]:
    grupos: dict[tuple[str, str], list[int]] = defaultdict(list)
    for indice, par in enumerate(candidatos):
        grupos[(par.conta_origem_id, par.conta_destino_id)].append(indice)
    atualizados = list(candidatos)
    for indices in grupos.values():
        meses = {
            pd.Timestamp(candidatos[i].data_saida).strftime("%Y-%m")
            for i in indices
        }
        if len(meses) < 2:
            continue
        for i in indices:
            par = atualizados[i]
            if not any(e.codigo == "ROTA_RECORRENTE" for e in par.evidencias):
                evidencias = list(par.evidencias) + [
                    _evidencia("ROTA_RECORRENTE", "A mesma rota aparece em mais de um mês do período.")
                ]
                indice = sum(e.peso for e in evidencias)
                atualizados[i] = replace(
                    par,
                    evidencias=evidencias,
                    indice_evidencia=indice,
                    estado_motor=classificar_evidencia(indice),
                    recorrente=True,
                )
    return atualizados


def resolver_conflitos(candidatos: list[ParCirculacao]) -> list[ParCirculacao]:
    """Seleciona pares únicos e conserva empates como ambíguos."""
    por_movimento: dict[str, list[int]] = defaultdict(list)
    for i, par in enumerate(candidatos):
        por_movimento[par.id_saida].append(i)
        por_movimento[par.id_entrada].append(i)

    ambiguos: set[int] = set()
    for indices in por_movimento.values():
        if len(indices) <= 1:
            continue
        maior = max(candidatos[i].indice_evidencia for i in indices)
        proximos = [i for i in indices if candidatos[i].indice_evidencia >= maior - 1]
        if len(proximos) > 1:
            ambiguos.update(proximos)

    atualizados = list(candidatos)
    for i in ambiguos:
        par = atualizados[i]
        atualizados[i] = replace(
            par,
            estado_motor="AMBIGUO",
            indice_evidencia=max(0, par.indice_evidencia - PENALIDADE_AMBIGUIDADE),
            alertas=list(par.alertas) + ["MULTIPLOS_PARES_PLAUSIVEIS"],
        )

    usados: set[str] = set()
    ordem = sorted(
        range(len(atualizados)),
        key=lambda i: (
            atualizados[i].estado_motor == "AMBIGUO",
            -atualizados[i].indice_evidencia,
            atualizados[i].diferenca_dias,
            atualizados[i].id_par,
        ),
    )
    for i in ordem:
        par = atualizados[i]
        if par.estado_motor == "AMBIGUO":
            continue
        if par.id_saida in usados or par.id_entrada in usados:
            atualizados[i] = replace(
                par,
                estado_motor="DESCARTADO_POR_CONFLITO",
                alertas=list(par.alertas) + ["MOVIMENTO_JA_ASSOCIADO_A_OUTRO_PAR"],
            )
            continue
        usados.update({par.id_saida, par.id_entrada})
        forte = par.estado_motor == "CANDIDATO_FORTE"
        atualizados[i] = replace(par, selecionado_motor=True, usado_estimativa=forte)
    return atualizados


def agregar_rotas(candidatos: list[ParCirculacao]) -> list[dict[str, Any]]:
    rotas: dict[tuple[str, str], dict[str, Any]] = {}
    for par in candidatos:
        if not par.selecionado_motor or par.estado_motor not in {"CANDIDATO_FORTE", "CANDIDATO_MODERADO"}:
            continue
        chave = (par.conta_origem_id, par.conta_destino_id)
        rota = rotas.setdefault(
            chave,
            {
                "conta_origem_id": par.conta_origem_id,
                "conta_destino_id": par.conta_destino_id,
                "conta_origem": par.conta_origem,
                "conta_destino": par.conta_destino,
                "instituicao_origem": par.instituicao_origem,
                "instituicao_destino": par.instituicao_destino,
                "valor_centavos": 0,
                "quantidade_pares": 0,
                "pares_fortes": 0,
                "pares_moderados": 0,
                "recorrente": False,
                "ids_pares": [],
            },
        )
        rota["valor_centavos"] += par.valor_centavos
        rota["quantidade_pares"] += 1
        rota["pares_fortes"] += int(par.estado_motor == "CANDIDATO_FORTE")
        rota["pares_moderados"] += int(par.estado_motor == "CANDIDATO_MODERADO")
        rota["recorrente"] = rota["recorrente"] or par.recorrente
        rota["ids_pares"].append(par.id_par)
    saida = []
    for rota in rotas.values():
        rota["valor"] = rota["valor_centavos"] / 100
        rota["estado"] = "PROVAVEL_FORTE" if rota["pares_fortes"] else "PROVAVEL_MODERADA"
        saida.append(rota)
    return sorted(saida, key=lambda x: (-x["valor_centavos"], x["conta_origem"], x["conta_destino"]))


def construir_base_estimada(
    movimentos: pd.DataFrame,
    candidatos: list[ParCirculacao],
) -> tuple[pd.DataFrame, set[str]]:
    ids_neutralizados: set[str] = set()
    for par in candidatos:
        if par.usado_estimativa:
            ids_neutralizados.update({par.id_saida, par.id_entrada})
    if movimentos.empty or not ids_neutralizados:
        return movimentos.copy(), ids_neutralizados
    estimada = movimentos[~movimentos["id_movimento"].isin(ids_neutralizados)].copy()
    return estimada, ids_neutralizados


def executar_estudo_circulacao(movimentos: pd.DataFrame) -> dict[str, Any]:
    candidatos = resolver_conflitos(detectar_recorrencia(gerar_candidatos(movimentos)))
    base_estimada, ids_neutralizados = construir_base_estimada(movimentos, candidatos)
    pares_dict = [par.to_dict() for par in sorted(candidatos, key=lambda p: (-p.indice_evidencia, p.id_par))]
    fortes = [p for p in candidatos if p.estado_motor == "CANDIDATO_FORTE" and p.selecionado_motor]
    moderados = [p for p in candidatos if p.estado_motor == "CANDIDATO_MODERADO" and p.selecionado_motor]
    ambiguos = [p for p in candidatos if p.estado_motor == "AMBIGUO"]
    valor_estimado = sum(p.valor_centavos for p in fortes)
    return {
        "candidatos": candidatos,
        "pares": pares_dict,
        "rotas": agregar_rotas(candidatos),
        "base_estimada": base_estimada,
        "ids_neutralizados": ids_neutralizados,
        "resumo": {
            "quantidade_pares_gerados": len(candidatos),
            "quantidade_pares_fortes": len(fortes),
            "quantidade_pares_moderados": len(moderados),
            "quantidade_pares_ambiguos": len(ambiguos),
            "quantidade_movimentos_neutralizados_estimativa": len(ids_neutralizados),
            "valor_circulacao_provavel_centavos": valor_estimado,
            "valor_circulacao_provavel": valor_estimado / 100,
            "regra_estimativa": "Somente pares fortes, únicos e não revisados são neutralizados na leitura estimada.",
            "confirmacao": "Nenhum candidato automático é tratado como confirmado.",
        },
    }


__all__ = [
    "gerar_candidatos", "detectar_recorrencia", "resolver_conflitos",
    "agregar_rotas", "construir_base_estimada", "executar_estudo_circulacao",
]
