"""Origem das entradas, fontes recorrentes e salário provável.

A categoria recebida é preservada como evidência auxiliar. Este módulo não
recategoriza movimentações e não afirma vínculo empregatício. Ele separa
hipóteses de entrada externa, circulação interna, crédito, resgate, ajuste,
duplicidade e casos inconclusivos.
"""
from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from hashlib import sha1
import math
import re
from statistics import median
from typing import Any, Iterable

import pandas as pd

from .modelos import ConsultaPainel
from .regras import (
    LIMIAR_RENDA_RECORRENTE,
    LIMIAR_SALARIO_FORTE,
    LIMIAR_SALARIO_MODERADO,
    MAX_CV_VALOR_SALARIO_FORTE,
    MAX_CV_VALOR_SALARIO_MODERADO,
    MAX_DISPERSAO_DIA_SALARIO,
    MIN_COBERTURA_MESES_RECORRENCIA,
    MIN_MESES_RECORRENCIA,
    PESOS_EVIDENCIAS_RENDA,
    TERMOS_CREDITO_CONTRATADO,
    TERMOS_DEVOLUCAO_AJUSTE,
    TERMOS_RENDA,
    TERMOS_RESGATE,
    TERMOS_SALARIO,
    TIPOS_ENTRADA_ANALITICA,
    VERSAO_REGRAS_RENDA,
)


def _texto(valor: Any) -> str:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return ""
    return str(valor).strip()


def _tem_termo(texto: Any, termos: Iterable[str]) -> bool:
    valor = _texto(texto).upper()
    return any(termo in valor for termo in termos)


def _id_hash(prefixo: str, valor: str) -> str:
    return prefixo + "-" + sha1(valor.encode("utf-8")).hexdigest()[:12].upper()


def _descricao_assinatura(texto: Any) -> str:
    valor = _texto(texto).upper()
    valor = re.sub(r"\b\d+\b", " ", valor)
    valor = re.sub(r"[^A-ZÀ-Ü ]+", " ", valor)
    palavras_genericas = {
        "PIX", "RECEBIDO", "RECEBIMENTO", "CREDITO", "TRANSFERENCIA",
        "TRANSF", "TED", "DOC", "PAGAMENTO", "VALOR", "BANCO",
    }
    tokens = [t for t in valor.split() if len(t) >= 3 and t not in palavras_genericas]
    return " ".join(tokens[:8]) or "ORIGEM_NAO_IDENTIFICADA"


def _assinatura_fonte(linha: pd.Series) -> tuple[str, str]:
    """Assinatura protegida e explicação da forma de agrupamento."""
    doc_hash = _texto(linha.get("contraparte_fonte_hash"))
    contraparte_inst = _texto(linha.get("contraparte_instituicao"))
    desc = _descricao_assinatura(linha.get("descricao_normalizada"))
    conta = _texto(linha.get("conta_id"))
    if doc_hash:
        material = f"DOC|{doc_hash}|{contraparte_inst}"
        return _id_hash("FNT", material), "CONTRAPARTE_PROTEGIDA"
    if contraparte_inst and desc != "ORIGEM_NAO_IDENTIFICADA":
        material = f"INSTDESC|{contraparte_inst}|{desc}"
        return _id_hash("FNT", material), "INSTITUICAO_E_DESCRICAO"
    if desc != "ORIGEM_NAO_IDENTIFICADA":
        material = f"DESC|{desc}|{conta}"
        return _id_hash("FNT", material), "DESCRICAO_E_CONTA_RECEPTORA"
    material = f"INCONCLUSIVA|{conta}|{contraparte_inst}"
    return _id_hash("FNT", material), "ORIGEM_INCONCLUSIVA"


def _meses_periodo(consulta: ConsultaPainel) -> list[str]:
    inicio = pd.Timestamp(consulta.periodo_inicio).to_period("M")
    fim = pd.Timestamp(consulta.periodo_fim).to_period("M")
    return [str(p) for p in pd.period_range(inicio, fim, freq="M")]


def _coeficiente_variacao(valores: list[int]) -> float | None:
    if len(valores) < 2:
        return None
    serie = pd.Series(valores, dtype="float64")
    media = float(serie.mean())
    if media == 0:
        return None
    return float(serie.std(ddof=0) / media)


def _dispersao_dias(dias: list[int]) -> float | None:
    if not dias:
        return None
    med = float(median(dias))
    desvios = [abs(d - med) for d in dias]
    return float(median(desvios))


def _evidencia(codigo: str, descricao: str, valor: Any = None) -> dict[str, Any]:
    return {
        "codigo": codigo,
        "descricao": descricao,
        "peso": PESOS_EVIDENCIAS_RENDA.get(codigo, 0),
        "valor_observado": valor,
    }


def _tipo_preliminar(linha: pd.Series, ids_internos: set[str]) -> tuple[str, list[dict[str, Any]]]:
    ident = _texto(linha.get("id_movimento"))
    descricao = _texto(linha.get("descricao_normalizada"))
    macro = int(linha.get("macroclasse_codigo") or 0)
    estado_dup = _texto(linha.get("estado_duplicidade"))
    evidencias: list[dict[str, Any]] = []
    if bool(linha.get("duplicidade_usada_estimativa")) or estado_dup in {
        "DUPLICIDADE_FISICA", "DUPLICIDADE_ECONOMICA_FORTE"
    }:
        evidencias.append(_evidencia("DUPLICIDADE_FORTE", "A movimentação integra um grupo de duplicidade forte."))
        return "DUPLICIDADE_PROVAVEL", evidencias
    if ident in ids_internos:
        evidencias.append(_evidencia("PAR_INTERNO_FORTE", "Existe uma saída forte e única associada em outra conta observada."))
        return "MOVIMENTACAO_INTERNA_PROVAVEL", evidencias
    if macro == 4 or _tem_termo(descricao, TERMOS_CREDITO_CONTRATADO):
        evidencias.append(_evidencia("DESCRICAO_CREDITO_CONTRATADO", "Categoria recebida ou descrição é compatível com crédito contratado."))
        return "CREDITO_CONTRATADO_PROVAVEL", evidencias
    if macro == 3 or _tem_termo(descricao, TERMOS_RESGATE):
        evidencias.append(_evidencia("DESCRICAO_RESGATE", "Categoria recebida ou descrição é compatível com resgate de investimento."))
        return "RESGATE_INVESTIMENTO_PROVAVEL", evidencias
    if macro == 2 or _tem_termo(descricao, TERMOS_DEVOLUCAO_AJUSTE):
        evidencias.append(_evidencia("DESCRICAO_DEVOLUCAO_AJUSTE", "Categoria recebida ou descrição é compatível com devolução ou ajuste."))
        return "DEVOLUCAO_AJUSTE_PROVAVEL", evidencias
    evidencias.append(_evidencia("ORIGEM_EXTERNA_SEM_PAR_INTERNO", "Nenhum par interno forte foi selecionado para esta entrada."))
    return "CANDIDATA_ORIGEM_EXTERNA", evidencias


def _avaliar_fonte(grupo: pd.DataFrame, consulta: ConsultaPainel, metodo_assinatura: str) -> dict[str, Any]:
    valores = [int(v) for v in grupo["valor_centavos"].tolist()]
    datas = pd.to_datetime(grupo["data"], errors="coerce").dropna()
    meses = sorted(datas.dt.strftime("%Y-%m").unique().tolist())
    dias = datas.dt.day.astype(int).tolist()
    meses_total = _meses_periodo(consulta)
    cobertura = len(meses) / len(meses_total) if meses_total else 0.0
    cv = _coeficiente_variacao(valores)
    dispersao = _dispersao_dias(dias)
    conta_counts = grupo["conta_id"].astype(str).value_counts()
    conta_principal = str(conta_counts.index[0]) if not conta_counts.empty else ""
    consistencia_conta = float(conta_counts.iloc[0] / len(grupo)) if len(grupo) else 0.0
    descricoes = grupo["descricao_protegida"].astype(str).value_counts()
    descricao_representativa = str(descricoes.index[0]) if not descricoes.empty else "Descrição não informada"
    texto_conjunto = " ".join(grupo["descricao_normalizada"].astype(str).tolist())
    macro_1 = float(grupo["macroclasse_codigo"].eq(1).mean()) if len(grupo) else 0.0

    evidencias: list[dict[str, Any]] = []
    pontuacao = 0
    if metodo_assinatura in {"CONTRAPARTE_PROTEGIDA", "INSTITUICAO_E_DESCRICAO"}:
        ev = _evidencia("ORIGEM_IDENTIFICAVEL", "A origem possui assinatura consistente sem expor dados restritos.", metodo_assinatura)
        evidencias.append(ev); pontuacao += ev["peso"]
    if len(meses) >= MIN_MESES_RECORRENCIA and Decimal(str(cobertura)) >= MIN_COBERTURA_MESES_RECORRENCIA:
        ev = _evidencia("RECORRENCIA_MENSAL", "A fonte aparece em vários meses do período.", {"meses": len(meses), "cobertura": cobertura})
        evidencias.append(ev); pontuacao += ev["peso"]
    else:
        ev = _evidencia("MESES_INSUFICIENTES", "A série possui poucos meses para caracterizar recorrência.", len(meses))
        evidencias.append(ev); pontuacao += ev["peso"]
    if dispersao is not None and dispersao <= MAX_DISPERSAO_DIA_SALARIO:
        ev = _evidencia("DIAS_CONCENTRADOS", "Os recebimentos se concentram em dias próximos do mês.", dispersao)
        evidencias.append(ev); pontuacao += ev["peso"]
    if cv is not None and Decimal(str(cv)) <= MAX_CV_VALOR_SALARIO_FORTE:
        ev = _evidencia("VALOR_ESTAVEL_FORTE", "O valor apresenta baixa variação entre ocorrências.", cv)
        evidencias.append(ev); pontuacao += ev["peso"]
    elif cv is not None and Decimal(str(cv)) <= MAX_CV_VALOR_SALARIO_MODERADO:
        ev = _evidencia("VALOR_ESTAVEL_MODERADO", "O valor apresenta variação moderada entre ocorrências.", cv)
        evidencias.append(ev); pontuacao += ev["peso"]
    if _tem_termo(texto_conjunto, TERMOS_SALARIO):
        ev = _evidencia("DESCRICAO_COMPATIVEL_SALARIO", "A descrição recebida contém termo compatível com salário ou provento.")
        evidencias.append(ev); pontuacao += ev["peso"]
    if macro_1 >= 0.60 or _tem_termo(texto_conjunto, TERMOS_RENDA):
        ev = _evidencia("CATEGORIA_RECEBIDA_COMPATIVEL", "A categoria recebida ou a descrição é compatível com renda.", macro_1)
        evidencias.append(ev); pontuacao += ev["peso"]
    if consistencia_conta >= 0.80:
        ev = _evidencia("CONTA_RECEPTORA_CONSISTENTE", "A maior parte dos valores chega à mesma conta.", consistencia_conta)
        evidencias.append(ev); pontuacao += ev["peso"]
    if _tem_termo(texto_conjunto, TERMOS_CREDITO_CONTRATADO):
        ev = _evidencia("DESCRICAO_CREDITO_CONTRATADO", "Há indício de empréstimo ou liberação de crédito.")
        evidencias.append(ev); pontuacao += ev["peso"]
    if _tem_termo(texto_conjunto, TERMOS_RESGATE):
        ev = _evidencia("DESCRICAO_RESGATE", "Há indício de resgate de investimento.")
        evidencias.append(ev); pontuacao += ev["peso"]
    if _tem_termo(texto_conjunto, TERMOS_DEVOLUCAO_AJUSTE):
        ev = _evidencia("DESCRICAO_DEVOLUCAO_AJUSTE", "Há indício de devolução, estorno ou ajuste.")
        evidencias.append(ev); pontuacao += ev["peso"]

    recorrencia_minima = (
        len(meses) >= MIN_MESES_RECORRENCIA
        and Decimal(str(cobertura)) >= MIN_COBERTURA_MESES_RECORRENCIA
    )
    if recorrencia_minima and pontuacao >= LIMIAR_SALARIO_FORTE:
        classificacao = "SALARIO_PROVAVEL_FORTE"
        tipo_entrada = "SALARIO_PROVAVEL"
    elif recorrencia_minima and pontuacao >= LIMIAR_SALARIO_MODERADO:
        classificacao = "SALARIO_PROVAVEL_MODERADO"
        tipo_entrada = "SALARIO_PROVAVEL"
    elif recorrencia_minima and pontuacao >= LIMIAR_RENDA_RECORRENTE:
        classificacao = "RENDA_RECORRENTE_PROVAVEL"
        tipo_entrada = "RENDA_RECORRENTE_PROVAVEL"
    elif len(meses) >= MIN_MESES_RECORRENCIA:
        classificacao = "FONTE_RECORRENTE_VARIAVEL"
        tipo_entrada = "RENDA_RECORRENTE_PROVAVEL"
    elif metodo_assinatura in {"CONTRAPARTE_PROTEGIDA", "INSTITUICAO_E_DESCRICAO"}:
        classificacao = "ENTRADA_EVENTUAL_ORIGEM_IDENTIFICAVEL"
        tipo_entrada = "ENTRADA_EXTERNA_PROVAVEL"
    else:
        classificacao = "ENTRADA_EVENTUAL_OU_INCONCLUSIVA"
        tipo_entrada = "ENTRADA_INCONCLUSIVA"

    valores_reais = [v / 100 for v in valores]
    dia_mediano = int(round(median(dias))) if dias else None
    return {
        "classificacao": classificacao,
        "tipo_entrada": tipo_entrada,
        "pontuacao_tecnica": pontuacao,
        "evidencias": evidencias,
        "quantidade": int(len(grupo)),
        "valor_total": sum(valores) / 100,
        "valor_tipico": float(median(valores_reais)) if valores_reais else 0.0,
        "valor_minimo": min(valores_reais) if valores_reais else 0.0,
        "valor_maximo": max(valores_reais) if valores_reais else 0.0,
        "coeficiente_variacao": cv,
        "meses_presentes": meses,
        "quantidade_meses": len(meses),
        "quantidade_meses_periodo": len(meses_total),
        "cobertura_meses": round(cobertura, 4),
        "dias_observados": sorted(set(dias)),
        "dia_mediano": dia_mediano,
        "dispersao_dias": dispersao,
        "conta_principal_id": conta_principal,
        "conta_consistencia": round(consistencia_conta, 4),
        "instituicao_receptora": str(grupo["instituicao_rotulo"].mode().iloc[0]) if not grupo.empty else "Instituição não informada",
        "conta_receptora": str(grupo["conta_rotulo"].mode().iloc[0]) if not grupo.empty else "Conta não informada",
        "descricao_representativa": descricao_representativa,
        "metodo_assinatura": metodo_assinatura,
        "movimentos": grupo["id_movimento"].astype(str).tolist(),
    }


def executar_estudo_renda(
    base_observada: pd.DataFrame,
    base_qualidade: pd.DataFrame,
    pares_circulacao: list[dict[str, Any]],
    consulta: ConsultaPainel,
) -> dict[str, Any]:
    """Constrói a leitura de entradas sem alterar a categorização recebida."""
    ids_internos: set[str] = set()
    for par in pares_circulacao:
        if par.get("usado_estimativa"):
            ids_internos.update({str(par.get("id_saida")), str(par.get("id_entrada"))})

    entradas = base_observada[base_observada["natureza"].eq("C")].copy()
    if entradas.empty:
        return {
            "resumo": {
                "entradas_observadas": 0.0,
                "entradas_externas_estimadas": 0.0,
                "circulacao_interna_provavel": 0.0,
                "duplicidades_neutralizadas": 0.0,
                "renda_recorrente_estimada": 0.0,
                "salario_provavel_estimado": 0.0,
                "entradas_inconclusivas": 0.0,
            },
            "fontes": [], "entradas": [], "fonte_principal": None,
            "linha_tempo_mensal": [], "versao_regra": VERSAO_REGRAS_RENDA,
        }

    tipos: list[str] = []
    evidencias_preliminares: list[list[dict[str, Any]]] = []
    fonte_ids: list[str | None] = []
    metodos: list[str | None] = []
    for _, linha in entradas.iterrows():
        tipo, evidencias = _tipo_preliminar(linha, ids_internos)
        tipos.append(tipo)
        evidencias_preliminares.append(evidencias)
        if tipo == "CANDIDATA_ORIGEM_EXTERNA":
            fonte, metodo = _assinatura_fonte(linha)
            fonte_ids.append(fonte); metodos.append(metodo)
        else:
            fonte_ids.append(None); metodos.append(None)
    entradas["tipo_entrada_preliminar"] = tipos
    entradas["evidencias_entrada"] = evidencias_preliminares
    entradas["fonte_id"] = fonte_ids
    entradas["fonte_metodo"] = metodos

    fontes: list[dict[str, Any]] = []
    fonte_lookup: dict[str, dict[str, Any]] = {}
    candidatas = entradas[entradas["tipo_entrada_preliminar"].eq("CANDIDATA_ORIGEM_EXTERNA")]
    for fonte_id, grupo in candidatas.groupby("fonte_id", dropna=True, sort=False):
        metodo = str(grupo["fonte_metodo"].mode().iloc[0])
        avaliacao = _avaliar_fonte(grupo, consulta, metodo)
        item = {"fonte_id": str(fonte_id), **avaliacao}
        fontes.append(item)
        fonte_lookup[str(fonte_id)] = item
    fontes.sort(key=lambda x: (-x["pontuacao_tecnica"], -x["valor_total"], x["fonte_id"]))
    for indice, fonte in enumerate(fontes, start=1):
        fonte["rotulo"] = f"Fonte {indice}"

    tipo_final: list[str] = []
    classificacao_fonte: list[str | None] = []
    for _, linha in entradas.iterrows():
        preliminar = str(linha["tipo_entrada_preliminar"])
        if preliminar != "CANDIDATA_ORIGEM_EXTERNA":
            tipo_final.append(preliminar)
            classificacao_fonte.append(None)
            continue
        fonte = fonte_lookup.get(str(linha.get("fonte_id")))
        if not fonte:
            tipo_final.append("ENTRADA_INCONCLUSIVA")
            classificacao_fonte.append("ORIGEM_NAO_AGRUPADA")
        else:
            tipo_final.append(fonte["tipo_entrada"] if fonte["tipo_entrada"] != "ENTRADA_INCONCLUSIVA" else "ENTRADA_INCONCLUSIVA")
            classificacao_fonte.append(fonte["classificacao"])
    entradas["tipo_entrada_analitica"] = tipo_final
    entradas["classificacao_fonte"] = classificacao_fonte

    # Movimentos externos eventuais com origem identificável são mantidos como
    # entrada externa provável, mesmo sem recorrência suficiente.
    for idx, linha in entradas.iterrows():
        if linha["tipo_entrada_analitica"] != "ENTRADA_INCONCLUSIVA":
            continue
        if linha.get("fonte_metodo") in {"CONTRAPARTE_PROTEGIDA", "INSTITUICAO_E_DESCRICAO"}:
            entradas.at[idx, "tipo_entrada_analitica"] = "ENTRADA_EXTERNA_PROVAVEL"

    fonte_principal = next((f for f in fontes if f["classificacao"] == "SALARIO_PROVAVEL_FORTE"), None)
    if fonte_principal is None:
        fonte_principal = next((f for f in fontes if f["classificacao"] == "SALARIO_PROVAVEL_MODERADO"), None)
    if fonte_principal is None:
        fonte_principal = next((f for f in fontes if f["classificacao"] in {"RENDA_RECORRENTE_PROVAVEL", "FONTE_RECORRENTE_VARIAVEL"}), None)

    def soma(tipos_alvo: set[str]) -> int:
        return int(entradas.loc[entradas["tipo_entrada_analitica"].isin(tipos_alvo), "valor_centavos"].sum())

    total_obs = int(entradas["valor_centavos"].sum())
    interno = soma({"MOVIMENTACAO_INTERNA_PROVAVEL"})
    duplicado = soma({"DUPLICIDADE_PROVAVEL"})
    externo = soma({"ENTRADA_EXTERNA_PROVAVEL", "SALARIO_PROVAVEL", "RENDA_RECORRENTE_PROVAVEL"})
    renda_rec = soma({"SALARIO_PROVAVEL", "RENDA_RECORRENTE_PROVAVEL"})
    salario = soma({"SALARIO_PROVAVEL"})
    inconclusivo = soma({"ENTRADA_INCONCLUSIVA"})

    mensal: list[dict[str, Any]] = []
    for mes in _meses_periodo(consulta):
        grupo = entradas[entradas["mes"].eq(mes)]
        mensal.append({
            "mes": mes,
            "observadas": int(grupo["valor_centavos"].sum()) / 100,
            "externas_provaveis": int(grupo.loc[grupo["tipo_entrada_analitica"].isin({"ENTRADA_EXTERNA_PROVAVEL", "SALARIO_PROVAVEL", "RENDA_RECORRENTE_PROVAVEL"}), "valor_centavos"].sum()) / 100,
            "salario_provavel": int(grupo.loc[grupo["tipo_entrada_analitica"].eq("SALARIO_PROVAVEL"), "valor_centavos"].sum()) / 100,
            "internas_provaveis": int(grupo.loc[grupo["tipo_entrada_analitica"].eq("MOVIMENTACAO_INTERNA_PROVAVEL"), "valor_centavos"].sum()) / 100,
            "inconclusivas": int(grupo.loc[grupo["tipo_entrada_analitica"].eq("ENTRADA_INCONCLUSIVA"), "valor_centavos"].sum()) / 100,
        })

    entrada_saida: list[dict[str, Any]] = []
    for _, linha in entradas.sort_values(["data", "hora", "id_movimento"], na_position="last").iterrows():
        fonte = fonte_lookup.get(str(linha.get("fonte_id"))) if linha.get("fonte_id") else None
        entrada_saida.append({
            "id_movimento": str(linha["id_movimento"]),
            "data": None if pd.isna(linha["data"]) else pd.Timestamp(linha["data"]).date().isoformat(),
            "valor": int(linha["valor_centavos"]) / 100,
            "instituicao": str(linha.get("instituicao_rotulo") or "Instituição não informada"),
            "conta": str(linha.get("conta_rotulo") or "Conta não informada"),
            "categoria_recebida": str(linha.get("categoria_vigente") or "Categoria não informada"),
            "macroclasse_recebida": str(linha.get("macroclasse_nome") or "Classificação não informada"),
            "descricao_protegida": str(linha.get("descricao_protegida") or "Descrição não informada"),
            "tipo_analitico": str(linha["tipo_entrada_analitica"]),
            "tipo_analitico_nome": TIPOS_ENTRADA_ANALITICA.get(str(linha["tipo_entrada_analitica"]), str(linha["tipo_entrada_analitica"])),
            "fonte_id": str(linha.get("fonte_id")) if linha.get("fonte_id") else None,
            "fonte_classificacao": fonte.get("classificacao") if fonte else None,
            "evidencias": list(linha["evidencias_entrada"]),
            "limitacao": "A interpretação é uma hipótese técnica; a categoria recebida foi preservada e não corrigida.",
        })

    return {
        "resumo": {
            "entradas_observadas": total_obs / 100,
            "entradas_externas_estimadas": externo / 100,
            "circulacao_interna_provavel": interno / 100,
            "duplicidades_neutralizadas": duplicado / 100,
            "renda_recorrente_estimada": renda_rec / 100,
            "salario_provavel_estimado": salario / 100,
            "entradas_inconclusivas": inconclusivo / 100,
            "outras_entradas_especificas": max(0, total_obs - externo - interno - duplicado - inconclusivo) / 100,
            "regra": "Entradas externas são estimadas após sinais de duplicidade e circulação; salário permanece provável, nunca confirmado.",
        },
        "fontes": fontes,
        "fonte_principal": fonte_principal,
        "entradas": entrada_saida,
        "linha_tempo_mensal": mensal,
        "versao_regra": VERSAO_REGRAS_RENDA,
        "base_entradas_anotada": entradas,
    }


__all__ = ["executar_estudo_renda"]
