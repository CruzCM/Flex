"""Qualidade das movimentações e detecção conservadora de duplicidades.

A categorização recebida não é corrigida por este módulo. O foco é validar o
grão, preservar a base observada e produzir uma leitura estimada separada.
"""
from __future__ import annotations

from collections import defaultdict
from hashlib import sha1
from typing import Any

import pandas as pd

from .regras import VERSAO_REGRAS_QUALIDADE


def _texto(valor: Any) -> str:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return ""
    return str(valor).strip()


def _grupo_id(prefixo: str, valores: list[str]) -> str:
    material = "|".join(valores)
    return f"{prefixo}-" + sha1(material.encode("utf-8")).hexdigest()[:12].upper()


def _hora_minuto(valor: Any) -> str:
    texto = _texto(valor)
    if not texto:
        return ""
    # Mantém a granularidade informada sem tentar reinterpretar fuso ou formato.
    return texto[:5]


def _assinatura_forte(linha: pd.Series) -> tuple[Any, ...]:
    data = pd.to_datetime(linha.get("data"), errors="coerce")
    data_iso = "" if pd.isna(data) else data.date().isoformat()
    return (
        _texto(linha.get("conta_id")),
        data_iso,
        _hora_minuto(linha.get("hora")),
        int(linha.get("valor_centavos") or 0),
        _texto(linha.get("natureza")),
        _texto(linha.get("moeda")),
        _texto(linha.get("descricao_normalizada")),
    )


def _assinatura_provavel(linha: pd.Series) -> tuple[Any, ...]:
    data = pd.to_datetime(linha.get("data"), errors="coerce")
    data_iso = "" if pd.isna(data) else data.date().isoformat()
    return (
        _texto(linha.get("conta_id")),
        data_iso,
        int(linha.get("valor_centavos") or 0),
        _texto(linha.get("natureza")),
        _texto(linha.get("moeda")),
        _texto(linha.get("descricao_normalizada")),
    )


def executar_estudo_qualidade(movimentos: pd.DataFrame) -> dict[str, Any]:
    """Anota duplicidades e devolve uma base estimada sem repetições fortes.

    Regras de neutralização:
    * chaves físicas repetidas: conserva a primeira ocorrência;
    * assinaturas econômicas fortes: conserva a primeira ocorrência;
    * sinais prováveis sem horário idêntico: apenas sinaliza, não neutraliza.
    """
    base = movimentos.copy()
    if base.empty:
        for coluna, padrao in {
            "estado_duplicidade": "SEM_SINAL",
            "grupo_duplicidade_id": None,
            "duplicidade_usada_estimativa": False,
            "duplicidade_evidencias": None,
        }.items():
            base[coluna] = padrao
        return {
            "base_anotada": base,
            "base_sem_duplicidades": base.copy(),
            "grupos": [],
            "ids_neutralizados": set(),
            "resumo": {
                "movimentacoes_observadas": 0,
                "duplicidades_fisicas": 0,
                "duplicidades_economicas_fortes": 0,
                "duplicidades_provaveis": 0,
                "movimentacoes_neutralizadas": 0,
                "valor_neutralizado": 0.0,
                "versao_regra": VERSAO_REGRAS_QUALIDADE,
            },
        }

    base["estado_duplicidade"] = "SEM_SINAL"
    base["grupo_duplicidade_id"] = None
    base["duplicidade_usada_estimativa"] = False
    base["duplicidade_evidencias"] = [[] for _ in range(len(base))]

    grupos_saida: list[dict[str, Any]] = []
    ids_neutralizados: set[str] = set()

    # 1. Duplicidade física pela chave original do evento.
    fisicos: dict[str, list[int]] = defaultdict(list)
    for indice, linha in base.iterrows():
        chave = _texto(linha.get("id_evento_fisico"))
        if chave:
            fisicos[chave].append(indice)
    for chave, indices in fisicos.items():
        if len(indices) <= 1:
            continue
        gid = _grupo_id("DUPF", [chave])
        ordenados = sorted(indices, key=lambda i: (_texto(base.at[i, "hora"]), _texto(base.at[i, "id_movimento"])))
        for pos, indice in enumerate(ordenados):
            base.at[indice, "estado_duplicidade"] = "DUPLICIDADE_FISICA"
            base.at[indice, "grupo_duplicidade_id"] = gid
            base.at[indice, "duplicidade_evidencias"] = [
                "MESMA_CHAVE_FISICA",
                "MESMO_EVENTO_RECEBIDO_MAIS_DE_UMA_VEZ",
            ]
            if pos > 0:
                base.at[indice, "duplicidade_usada_estimativa"] = True
                ids_neutralizados.add(_texto(base.at[indice, "id_movimento"]))
        grupos_saida.append({
            "grupo_id": gid,
            "estado": "DUPLICIDADE_FISICA",
            "quantidade": len(indices),
            "valor": int(base.at[ordenados[0], "valor_centavos"]) / 100,
            "movimentos": [_texto(base.at[i, "id_movimento"]) for i in ordenados],
            "evidencias": ["MESMA_CHAVE_FISICA"],
            "neutralizados_estimativa": len(indices) - 1,
        })

    # 2. Assinatura econômica forte. Ignora eventos já cobertos pela mesma chave.
    fortes: dict[tuple[Any, ...], list[int]] = defaultdict(list)
    for indice, linha in base.iterrows():
        fortes[_assinatura_forte(linha)].append(indice)
    for assinatura, indices in fortes.items():
        candidatos = [i for i in indices if base.at[i, "estado_duplicidade"] == "SEM_SINAL"]
        if len(candidatos) <= 1 or not assinatura[0] or not assinatura[1] or not assinatura[2]:
            continue
        gid = _grupo_id("DUPE", [str(x) for x in assinatura])
        ordenados = sorted(candidatos, key=lambda i: _texto(base.at[i, "id_movimento"]))
        for pos, indice in enumerate(ordenados):
            base.at[indice, "estado_duplicidade"] = "DUPLICIDADE_ECONOMICA_FORTE"
            base.at[indice, "grupo_duplicidade_id"] = gid
            base.at[indice, "duplicidade_evidencias"] = [
                "MESMA_CONTA", "MESMA_DATA_HORA", "MESMO_VALOR",
                "MESMA_NATUREZA_MOEDA", "MESMA_DESCRICAO_NORMALIZADA",
            ]
            if pos > 0:
                base.at[indice, "duplicidade_usada_estimativa"] = True
                ids_neutralizados.add(_texto(base.at[indice, "id_movimento"]))
        grupos_saida.append({
            "grupo_id": gid,
            "estado": "DUPLICIDADE_ECONOMICA_FORTE",
            "quantidade": len(candidatos),
            "valor": int(base.at[ordenados[0], "valor_centavos"]) / 100,
            "movimentos": [_texto(base.at[i, "id_movimento"]) for i in ordenados],
            "evidencias": [
                "MESMA_CONTA", "MESMA_DATA_HORA", "MESMO_VALOR",
                "MESMA_NATUREZA_MOEDA", "MESMA_DESCRICAO_NORMALIZADA",
            ],
            "neutralizados_estimativa": len(candidatos) - 1,
        })

    # 3. Sinal provável no mesmo dia, sem horário idêntico. Não neutraliza.
    provaveis: dict[tuple[Any, ...], list[int]] = defaultdict(list)
    for indice, linha in base.iterrows():
        if base.at[indice, "estado_duplicidade"] != "SEM_SINAL":
            continue
        provaveis[_assinatura_provavel(linha)].append(indice)
    for assinatura, indices in provaveis.items():
        if len(indices) <= 1 or not assinatura[0] or not assinatura[1]:
            continue
        gid = _grupo_id("DUPP", [str(x) for x in assinatura])
        for indice in indices:
            base.at[indice, "estado_duplicidade"] = "DUPLICIDADE_PROVAVEL"
            base.at[indice, "grupo_duplicidade_id"] = gid
            base.at[indice, "duplicidade_evidencias"] = [
                "MESMA_CONTA_DATA_VALOR_NATUREZA_MOEDA_DESCRICAO",
                "HORARIO_NAO_IDENTICO_OU_AUSENTE",
            ]
        grupos_saida.append({
            "grupo_id": gid,
            "estado": "DUPLICIDADE_PROVAVEL",
            "quantidade": len(indices),
            "valor": int(base.at[indices[0], "valor_centavos"]) / 100,
            "movimentos": [_texto(base.at[i, "id_movimento"]) for i in indices],
            "evidencias": ["ASSINATURA_DIARIA_REPETIDA"],
            "neutralizados_estimativa": 0,
        })

    base_sem = base[~base["duplicidade_usada_estimativa"]].copy().reset_index(drop=True)
    valor_neutralizado = int(base.loc[base["duplicidade_usada_estimativa"], "valor_centavos"].sum())
    resumo = {
        "movimentacoes_observadas": int(len(base)),
        "duplicidades_fisicas": int(base["estado_duplicidade"].eq("DUPLICIDADE_FISICA").sum()),
        "duplicidades_economicas_fortes": int(base["estado_duplicidade"].eq("DUPLICIDADE_ECONOMICA_FORTE").sum()),
        "duplicidades_provaveis": int(base["estado_duplicidade"].eq("DUPLICIDADE_PROVAVEL").sum()),
        "movimentacoes_neutralizadas": int(base["duplicidade_usada_estimativa"].sum()),
        "valor_neutralizado": valor_neutralizado / 100,
        "regra_estimativa": (
            "Somente repetições físicas e econômicas fortes posteriores à primeira "
            "ocorrência são neutralizadas na leitura estimada."
        ),
        "versao_regra": VERSAO_REGRAS_QUALIDADE,
    }
    return {
        "base_anotada": base,
        "base_sem_duplicidades": base_sem,
        "grupos": sorted(grupos_saida, key=lambda x: (x["estado"], -x["valor"], x["grupo_id"])),
        "ids_neutralizados": ids_neutralizados,
        "resumo": resumo,
    }


__all__ = ["executar_estudo_qualidade"]
