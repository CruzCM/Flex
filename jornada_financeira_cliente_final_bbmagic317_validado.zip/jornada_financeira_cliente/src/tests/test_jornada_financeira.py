from __future__ import annotations

from pathlib import Path
import ast
import json
import sys
import types
import warnings
import zipfile

import nbformat
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.analise import montar_painel, normalizar_movimentacoes
from src.app import criar_consulta, fluxo_dashboard
from src.config import carregar_configuracao
from src.circulacao import executar_estudo_circulacao
from src.dados import (
    ErroDados, contar_marcadores_sql, criar_cliente_db2, executar_select,
    limpar_cache_catalogos,
    montar_sql_complementos_conta, montar_sql_contas,
    montar_sql_perfil_financeiro, montar_sql_perfil_renda,
    montar_sql_transacoes, validar_sql_parametrizado,
)
from src.fontes import COLUNAS_POR_FONTE, FONTES
from src.qualidade import executar_estudo_qualidade
from src.renda import executar_estudo_renda
from src.validacoes import executar_todas_validacoes
from src.visual import render_dashboard


def consulta(cd_cli: int = 987654321012345):
    return criar_consulta(
        cd_cli=cd_cli, periodo_inicio="2026-01-01", periodo_fim="2026-07-31",
        moeda="BRL", instituicoes=None, tela_inicial="jornada_dinheiro",
    )


def _transacao(nr, data, natureza, valor, inst, marca, seq, conta, descricao, categoria, hora="09:00", cd_cli=987654321012345):
    return {
        "NR_TRAN_INST_PCT": nr, "NR_PTC": 1, "CD_CLI": cd_cli,
        "NR_MCA_PCT_OPB": marca, "CD_INST_PCT": inst, "NR_SEQL_CT_CLI": seq,
        "CD_CT_TITR": conta, "CD_PRD": 6, "VL_TRAN": valor,
        "CD_TIP_MOE_CRR": "BRL", "TX_DCR_TRAN": descricao,
        "CD_NTZ_CTB_TRAN": natureza, "DT_TRAN": data, "HR_TRAN": hora,
        "CD_CTGR_TRAN": categoria, "CD_CTGR_TRAN_OGNL": categoria,
        "CD_EST_TRAN_INST": 0, "CD_CLSC_MTO_CTGR": 1,
    }


def frames_controlados(cd_cli: int = 987654321012345):
    trans = []
    # Cinco meses de salário provável na conta A.
    for mes, nr in zip(range(1, 6), range(1, 6)):
        trans.append(_transacao(nr, f"2026-{mes:02d}-05", "C", 7000, 10, 100, 1, "0001234", "Folha salario mensal", 1, cd_cli=cd_cli))
    # Circulação interna forte A -> B.
    trans.append(_transacao(20, "2026-01-06", "D", 3000, 10, 100, 1, "0001234", "PIX transferencia entre contas", 39436, "10:00", cd_cli))
    trans.append(_transacao(21, "2026-01-06", "C", 3000, 20, 200, 2, "0009876", "Recebimento PIX", 1, "10:02", cd_cli))
    # Uso após recebimento.
    trans.append(_transacao(30, "2026-01-07", "D", 2200, 10, 100, 1, "0001234", "Aluguel", 10, "11:00", cd_cli))
    trans.append(_transacao(31, "2026-01-08", "D", 650, 10, 100, 1, "0001234", "Supermercado", 32, "13:00", cd_cli))
    trans.append(_transacao(32, "2026-01-10", "D", 400, 10, 100, 1, "0001234", "Bar", 35, "20:00", cd_cli))
    trans.append(_transacao(33, "2026-02-07", "D", 1000, 20, 200, 2, "0009876", "Aplicacao", 448977, "08:00", cd_cli))
    trans.append(_transacao(34, "2026-02-12", "D", 800, 20, 200, 2, "0009876", "Pagamento cartao", 111, "09:00", cd_cli))
    trans.append(_transacao(35, "2026-01-09", "D", 300, 20, 200, 2, "0009876", "Supermercado apos transferencia", 32, "15:00", cd_cli))
    # Duplicidade física: mesma chave recebida duas vezes.
    dup = _transacao(40, "2026-03-09", "D", 120, 10, 100, 1, "0001234", "Tarifa mensal", 3788, "12:00", cd_cli)
    trans.extend([dup.copy(), dup.copy()])
    # Entrada eventual de origem identificável via complemento.
    trans.append(_transacao(50, "2026-04-20", "C", 950, 10, 100, 1, "0001234", "Pagamento honorario projeto", 5, "14:00", cd_cli))

    contas = pd.DataFrame([
        {"CD_CLI_TITR_CT": cd_cli, "NR_MCA_PCT_OPB": 100, "NR_SEQL_CT_CLI": 1, "CD_CPF_CNPJ_TITR": 11111111111, "CD_INST_PCT": 10, "CD_IDFR_CT": "ACC-A", "CD_CT_TITR": "0001234", "CD_PRD": 6, "CD_MDLD_PRD": 1, "IN_AUTZ_EXB_TRAN": "S", "IN_EXB_DADO_CT": "S", "CD_EST_RCS_OPB": 0},
        {"CD_CLI_TITR_CT": cd_cli, "NR_MCA_PCT_OPB": 200, "NR_SEQL_CT_CLI": 2, "CD_CPF_CNPJ_TITR": 11111111111, "CD_INST_PCT": 20, "CD_IDFR_CT": "ACC-B", "CD_CT_TITR": "0009876", "CD_PRD": 6, "CD_MDLD_PRD": 1, "IN_AUTZ_EXB_TRAN": "S", "IN_EXB_DADO_CT": "S", "CD_EST_RCS_OPB": 0},
    ])
    complementos = pd.DataFrame([
        {"NR_TRAN_INST_PCT": 20, "NR_PTC": 1, "CD_IDFR_CT": "ACC-A", "NR_CPF_CNPJ_PGDR": 11111111111, "CD_CT_PGDR_BNFC": "0009876", "CD_CLI": cd_cli, "NR_MCA_PCT_OPB": 100, "NR_SEQL_CT_CLI": 1},
        {"NR_TRAN_INST_PCT": 21, "NR_PTC": 1, "CD_IDFR_CT": "ACC-B", "NR_CPF_CNPJ_PGDR": 11111111111, "CD_CT_PGDR_BNFC": "0001234", "CD_CLI": cd_cli, "NR_MCA_PCT_OPB": 200, "NR_SEQL_CT_CLI": 2},
        {"NR_TRAN_INST_PCT": 50, "NR_PTC": 1, "CD_IDFR_CT": "ACC-A", "NR_CPF_CNPJ_PGDR": 55555555000199, "CD_CPSO_PGDR_BNFC": 999, "CD_CLI": cd_cli, "NR_MCA_PCT_OPB": 100, "NR_SEQL_CT_CLI": 1},
    ])
    categorias = pd.DataFrame([
        {"CD_CTGR_TRAN": 1, "CD_GR_CTGR_TRAN": 1, "CD_NTZ_CTB_TRAN": "C", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Salário"},
        {"CD_CTGR_TRAN": 5, "CD_GR_CTGR_TRAN": 1, "CD_NTZ_CTB_TRAN": "C", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Outros Rendimentos"},
        {"CD_CTGR_TRAN": 39436, "CD_GR_CTGR_TRAN": 11, "CD_NTZ_CTB_TRAN": "D", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Transferência"},
        {"CD_CTGR_TRAN": 10, "CD_GR_CTGR_TRAN": 2, "CD_NTZ_CTB_TRAN": "D", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Aluguel e Condomínio"},
        {"CD_CTGR_TRAN": 32, "CD_GR_CTGR_TRAN": 6, "CD_NTZ_CTB_TRAN": "D", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Feira e Supermercado"},
        {"CD_CTGR_TRAN": 35, "CD_GR_CTGR_TRAN": 6, "CD_NTZ_CTB_TRAN": "D", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Bar"},
        {"CD_CTGR_TRAN": 448977, "CD_GR_CTGR_TRAN": 13, "CD_NTZ_CTB_TRAN": "D", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Aplicação"},
        {"CD_CTGR_TRAN": 111, "CD_GR_CTGR_TRAN": 12, "CD_NTZ_CTB_TRAN": "D", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Cartão de Crédito"},
        {"CD_CTGR_TRAN": 3788, "CD_GR_CTGR_TRAN": 10, "CD_NTZ_CTB_TRAN": "D", "IN_CTGR_PDRO_SIS": "S", "TX_DCR_CTGR_TRAN": "Encargos e Tarifas"},
    ])
    grupos = pd.DataFrame([
        {"CD_GR_CTGR_TRAN": 1, "TX_DCR_GR_CTGR": "Receitas"},
        {"CD_GR_CTGR_TRAN": 2, "TX_DCR_GR_CTGR": "Casa"},
        {"CD_GR_CTGR_TRAN": 6, "TX_DCR_GR_CTGR": "Alimentação"},
        {"CD_GR_CTGR_TRAN": 10, "TX_DCR_GR_CTGR": "Impostos e taxas"},
        {"CD_GR_CTGR_TRAN": 11, "TX_DCR_GR_CTGR": "Transferências"},
        {"CD_GR_CTGR_TRAN": 12, "TX_DCR_GR_CTGR": "Fatura"},
        {"CD_GR_CTGR_TRAN": 13, "TX_DCR_GR_CTGR": "Investimentos"},
    ])
    return {
        "transacoes": pd.DataFrame(trans), "contas": contas,
        "complementos_conta": complementos, "categorias": categorias, "grupos": grupos,
        "perfil_renda": pd.DataFrame(), "perfil_financeiro": pd.DataFrame(),
    }


def metadados(frames):
    return {k: {"tabela": FONTES[k].nome_completo, "estado": "CARREGADA", "linhas_retornadas": len(v), "obrigatoria": FONTES[k].obrigatoria} for k, v in frames.items()}


def base_normalizada(frames=None):
    frames = frames or frames_controlados()
    return normalizar_movimentacoes(frames["transacoes"], frames["contas"], frames["complementos_conta"], frames["categorias"], frames["grupos"])[0]


def test_fontes_centralizadas_e_schema_perfil():
    assert FONTES["perfil_financeiro"].nome_completo == "DB2D1D.DVS_GRDR_FNCO_PF"
    assert FONTES["transacoes"].nome_completo == "DB2GFP.TRAN_RLZD_INST_PCT"


def test_sql_coracao_parametrizado_cliente_periodo_moeda():
    segredo = "987654321012345"
    sql = montar_sql_transacoes(consulta(int(segredo)))
    assert segredo not in str(sql)
    assert "CD_CLI = ?" in sql
    assert "DT_TRAN >= CAST(? AS DATE)" in sql
    assert "DT_TRAN < CAST(? AS DATE)" in sql
    assert "CD_TIP_MOE_CRR = ?" in sql
    assert sql.params[:4] == (int(segredo), "2026-01-01", "2026-08-01", "BRL")
    assert sql.usar_chunks is True
    assert "SELECT *" not in sql.upper()
    assert "NR_PTC BETWEEN" not in sql.upper()


def test_sql_contas_e_complementos_parametrizados():
    segredo = "987654321012345"
    contas = montar_sql_contas(consulta(int(segredo)))
    assert segredo not in str(contas)
    assert "CD_CLI_TITR_CT = ?" in contas
    assert contas.params == (int(segredo),)
    comp = montar_sql_complementos_conta(consulta(int(segredo)))
    assert segredo not in str(comp)
    assert "c.CD_CLI = ?" in comp
    assert "EXISTS" in comp.upper()
    assert "DT_TRAN >= CAST(? AS DATE)" in comp and "DT_TRAN < CAST(? AS DATE)" in comp
    assert comp.params[0] == int(segredo)
    assert comp.params[1] == int(segredo)


def test_executar_select_usa_query_e_concatena_chunks():
    chamadas = []
    class Cliente:
        def query(self, sql, params=None, chunksize=None):
            chamadas.append((sql, params, chunksize))
            return iter([pd.DataFrame({"A": [1, 2]}), pd.DataFrame({"A": [3]})])
    resultado = executar_select(
        Cliente(), "SELECT A FROM T WHERE X = ?", params=[7], chunksize=2
    )
    assert resultado["A"].tolist() == [1, 2, 3]
    assert chamadas == [("SELECT A FROM T WHERE X = ?", [7], 2)]


def test_perfis_tem_cliente_e_datas_parametrizados():
    segredo = "987654321012345"
    renda = montar_sql_perfil_renda(consulta(int(segredo)))
    financeiro = montar_sql_perfil_financeiro(consulta(int(segredo)))
    assert segredo not in str(renda)
    assert segredo not in str(financeiro)
    assert "p.CD_CLI = ?" in renda
    assert "p.CD_CLI = ?" in financeiro
    assert renda.params[0] == int(segredo)
    assert financeiro.params[0] == int(segredo)


def test_executar_select_exige_api_query_e_oculta_erro():
    with pytest.raises(ErroDados, match=r"query\(\)"):
        executar_select(object(), "VALUES 1")

    class ClienteComFalha:
        def query(self, sql, params=None, chunksize=None):
            raise RuntimeError(f"falha com segredo {params}")

    with pytest.raises(ErroDados) as erro:
        executar_select(
            ClienteComFalha(),
            "SELECT 1 FROM T WHERE CD_CLI = ?",
            params=[987654321012345],
        )
    assert "987654321012345" not in str(erro.value)
    assert "SELECT 1" not in str(erro.value)


def test_configuracao_bbmagic_usa_chunksize_e_alias_legado(tmp_path, monkeypatch):
    for nome in (
        "DB2_CHUNKSIZE", "DB2_FETCHSIZE", "DB2_USER", "DB2_PASS"
    ):
        monkeypatch.delenv(nome, raising=False)
    env = tmp_path / "desenv.env"
    env.write_text("DB2_USER=u\nDB2_PASS=p\nDB2_CHUNKSIZE=4321\n")
    config = carregar_configuracao(env)
    assert config.chunksize_db2 == 4321
    assert config.fetchsize_db2 == 4321
    assert config.db2_database == "BDB2P04"
    assert config.db2_credential_mode == "ENV_BBMAGIC"
    assert config.credenciais_configuradas is True

    monkeypatch.delenv("DB2_CHUNKSIZE", raising=False)
    monkeypatch.delenv("DB2_FETCHSIZE", raising=False)
    env_legado = tmp_path / "legado.env"
    env_legado.write_text("DB2_USER=u\nDB2_PASS=p\nDB2_FETCHSIZE=2222\n")
    legado = carregar_configuracao(env_legado)
    assert legado.chunksize_db2 == 2222


def test_codigo_produtivo_nao_usa_run_select():
    for arquivo in (ROOT / "src").glob("*.py"):
        assert "run_select" not in arquivo.read_text(encoding="utf-8")



def test_todas_consultas_reconciliam_marcadores_e_parametros():
    q = consulta()
    comandos = [
        montar_sql_transacoes(q),
        montar_sql_contas(q),
        montar_sql_complementos_conta(q),
        montar_sql_perfil_renda(q),
        montar_sql_perfil_financeiro(q),
    ]
    for comando in comandos:
        contrato = validar_sql_parametrizado(comando)
        assert contrato["quantidade_marcadores"] == len(comando.params)
        assert "DATE(?)" not in str(comando).upper()
        assert "TIME(?)" not in str(comando).upper()
        assert "TIMESTAMP(?)" not in str(comando).upper()


def test_contador_de_marcadores_ignora_strings_e_comentarios():
    sql = "SELECT '?' AS X FROM T WHERE A = ? -- ?\n AND B = ? /* ? */"
    assert contar_marcadores_sql(sql) == 2


def test_executar_select_bloqueia_marcador_temporal_sem_tipo_antes_do_db2():
    chamado = False

    class Cliente:
        def query(self, sql, params=None, chunksize=None):
            nonlocal chamado
            chamado = True
            return pd.DataFrame()

    with pytest.raises(ErroDados, match="Marcador temporal sem tipo"):
        executar_select(
            Cliente(),
            "SELECT 1 FROM T WHERE DT_REF >= DATE(?)",
            params=["2026-01-01"],
        )
    assert chamado is False


def test_executar_select_suprime_apenas_aviso_conhecido_do_pandas():
    class Cliente:
        def query(self, sql, params=None, chunksize=None):
            warnings.warn(
                "pandas only supports SQLAlchemy connectable (engine/connection)",
                UserWarning,
            )
            return pd.DataFrame({"A": [1]})

    with warnings.catch_warnings(record=True) as capturados:
        warnings.simplefilter("always")
        resultado = executar_select(Cliente(), "VALUES 1")
    assert resultado["A"].tolist() == [1]
    assert capturados == []


def test_criar_cliente_db2_usa_somente_user_password_do_env(monkeypatch, tmp_path):
    chamadas = []

    class Db2Falso:
        def __init__(self, **kwargs):
            chamadas.append(kwargs)

    modulo = types.ModuleType("bbmagic")
    modulo.Db2 = Db2Falso
    monkeypatch.setitem(sys.modules, "bbmagic", modulo)
    env = tmp_path / "desenv.env"
    env.write_text(
        "DB2_USER=usuario_teste\nDB2_PASS=senha_teste\n"
        "DB2_HOST=host\nDB2_PORT=50100\nDB2_DATABASE=BASE\n"
    )
    config = carregar_configuracao(env)
    cliente = criar_cliente_db2(config)
    assert isinstance(cliente, Db2Falso)
    assert chamadas == [{
        "user": "usuario_teste",
        "password": "senha_teste",
        "host": "host",
        "port": 50100,
        "database": "BASE",
        "trust_env": True,
        "pconnect": True,
    }]
    assert getattr(cliente, "_jornada_origem_credencial") == "ENV_BBMAGIC"


def test_configuracao_do_arquivo_substitui_valores_antigos_do_kernel(tmp_path, monkeypatch):
    monkeypatch.setenv("DB2_USER", "usuario_antigo")
    monkeypatch.setenv("DB2_PASS", "senha_antiga")
    env = tmp_path / "desenv.env"
    env.write_text("DB2_USER=usuario_novo\nDB2_PASS=senha_nova\n")
    config = carregar_configuracao(env)
    assert config.db2_user == "usuario_novo"
    assert config.db2_pass == "senha_nova"


def test_codigo_produtivo_sem_cofre_modos_ou_conectores_alternativos():
    textos = "\n".join(
        arquivo.read_text(encoding="utf-8")
        for arquivo in (ROOT / "src").glob("*.py")
        if arquivo.name != "README.md"
    )
    assert "get_cofre_credentials" not in textos
    assert "DB2_CREDENTIAL_MODE" not in textos
    assert "run_select" not in textos
    for arquivo in (ROOT / "src").glob("*.py"):
        arvore = ast.parse(arquivo.read_text(encoding="utf-8"))
        for no in ast.walk(arvore):
            if isinstance(no, (ast.Import, ast.ImportFrom)):
                nomes = []
                if isinstance(no, ast.Import):
                    nomes = [a.name for a in no.names]
                else:
                    nomes = [no.module or ""]
                assert not any(
                    nome.split(".")[0] in {"ibm_db", "ibm_db_dbi", "sqlalchemy"}
                    for nome in nomes
                )


def test_todas_chamadas_registro_possuem_assinatura_correta():
    arvore = ast.parse((ROOT / "src" / "validacoes.py").read_text(encoding="utf-8"))
    chamadas = [
        no for no in ast.walk(arvore)
        if isinstance(no, ast.Call)
        and isinstance(no.func, ast.Name)
        and no.func.id == "_registro"
    ]
    assert chamadas
    assert all(len(no.args) == 7 and not no.keywords for no in chamadas)


def test_normalizacao_preserva_categoria_recebida():
    base = base_normalizada()
    interna = base[base["numero_transacao"].eq(21)].iloc[0]
    assert interna["categoria_vigente"] == "Salário"
    assert interna["macroclasse_codigo"] == 1


def test_ids_fisicos_duplicados_recebem_ids_internos_unicos():
    base = base_normalizada()
    linhas = base[base["numero_transacao"].eq(40)]
    assert len(linhas) == 2
    assert linhas["id_movimento"].nunique() == 2
    assert linhas["id_evento_fisico"].nunique() == 1


def test_qualidade_neutraliza_somente_repeticao_posterior():
    estudo = executar_estudo_qualidade(base_normalizada())
    assert estudo["resumo"]["movimentacoes_neutralizadas"] == 1
    assert estudo["resumo"]["duplicidades_fisicas"] == 2
    assert len(estudo["base_sem_duplicidades"]) == len(estudo["base_anotada"]) - 1


def test_circulacao_identifica_saida_e_entrada_em_bancos_diferentes():
    q = executar_estudo_qualidade(base_normalizada())
    estudo = executar_estudo_circulacao(q["base_sem_duplicidades"])
    assert estudo["resumo"]["quantidade_pares_fortes"] == 1
    assert estudo["resumo"]["valor_circulacao_provavel"] == 3000
    par = next(p for p in estudo["pares"] if p["estado_motor"] == "CANDIDATO_FORTE")
    assert par["instituicao_origem"] != par["instituicao_destino"]


def test_renda_identifica_salario_provavel_apenas_com_recorrencia():
    base = base_normalizada()
    q = executar_estudo_qualidade(base)
    c = executar_estudo_circulacao(q["base_sem_duplicidades"])
    estudo = executar_estudo_renda(q["base_anotada"], q["base_sem_duplicidades"], c["pares"], consulta())
    principal = estudo["fonte_principal"]
    assert principal is not None
    assert principal["classificacao"] == "SALARIO_PROVAVEL_FORTE"
    assert principal["quantidade_meses"] == 5
    assert principal["dia_mediano"] == 5
    assert estudo["resumo"]["salario_provavel_estimado"] == 35000


def test_entrada_interna_com_categoria_salario_nao_vira_renda():
    payload = montar_painel(frames=frames_controlados(), consulta=consulta(), fontes=metadados(frames_controlados()))
    interna = next(x for x in payload["origem_renda"]["entradas"] if x["valor"] == 3000)
    assert interna["tipo_analitico"] == "MOVIMENTACAO_INTERNA_PROVAVEL"
    assert interna["categoria_recebida"] == "Salário"
    assert interna["coerencia_categoria_recebida"]["estado"] == "CONFLITANTE_COM_CIRCULACAO"


def test_payload_explica_principalidade_por_papel():
    frames = frames_controlados()
    payload = montar_painel(frames=frames, consulta=consulta(), fontes=metadados(frames))
    principalidade = payload["circulacao_bancos"]["principalidade"]
    assert principalidade["estado"] in {"INSTITUICAO_CENTRAL_PROVAVEL", "PRINCIPALIDADE_DISTRIBUIDA"}
    assert "RECEBIMENTO_RENDA" in principalidade["top_por_papel"]
    assert payload["circulacao_bancos"]["instituicoes"]


def test_ciclos_pos_recebimento_nao_afirmam_causalidade():
    frames = frames_controlados()
    payload = montar_painel(frames=frames, consulta=consulta(), fontes=metadados(frames))
    ciclos = payload["uso_dinheiro"]["ciclos"]
    assert ciclos["estado"] == "CALCULADO"
    assert ciclos["eventos"]
    assert "não comprova" in ciclos["eventos"][0]["limitacao"]
    assert {x["dias"] for x in ciclos["resumo_janelas"]} == {0, 3, 7, 15}


def test_payload_publico_sem_codigo_cliente_e_com_periodo_unico():
    frames = frames_controlados()
    payload = montar_painel(frames=frames, consulta=consulta(), fontes=metadados(frames))
    texto = json.dumps(payload, ensure_ascii=False, default=str)
    assert "987654321012345" not in texto
    assert "cliente_codigo" not in texto
    assert payload["meta"]["periodo"]["inicio"] == "2026-01-01"
    assert "periodo_radar" not in texto.lower()


def test_payload_tem_novas_telas_e_nao_usa_radar_como_eixo():
    frames = frames_controlados()
    payload = montar_painel(frames=frames, consulta=consulta(), fontes=metadados(frames))
    assert {"jornada_dinheiro", "origem_renda", "circulacao_bancos", "uso_dinheiro", "evidencias_qualidade"}.issubset(payload)
    assert "analise_financeira" not in payload
    assert payload["metodologia"]["categorizacao"].startswith("Recebida")


def test_html_tem_cinco_telas_cards_expansiveis_e_sem_codigo_cliente():
    frames = frames_controlados()
    payload = montar_painel(frames=frames, consulta=consulta(), fontes=metadados(frames))
    html = render_dashboard(payload, include_plotly=False)
    for nome in ("Jornada do dinheiro", "Origem e renda", "Circulação e bancos", "Uso do dinheiro", "Evidências e qualidade"):
        assert nome in html
    assert "<details" in html
    assert "987654321012345" not in html
    assert "categoria é recebida" in html.lower()


def test_fluxo_publico_com_db2_controlado(tmp_path):
    limpar_cache_catalogos()
    frames = frames_controlados()

    class Db2Controlado:
        def query(self, sql, params=None, chunksize=None):
            assert "987654321012345" not in sql
            s = sql.upper()
            if "CMPT_TRAN_RLZD_CC" in s:
                return frames["complementos_conta"]
            if "INF_OPB_CT_CLI" in s:
                return frames["contas"]
            if "TRAN_RLZD_INST_PCT" in s:
                return frames["transacoes"]
            if "CTGR_TRAN_OPB" in s:
                return frames["categorias"]
            if "GR_CTGR_TRAN" in s:
                return frames["grupos"]
            if "CLI_SGM" in s:
                return frames["perfil_renda"]
            if "DVS_GRDR_FNCO_PF" in s:
                return frames["perfil_financeiro"]
            raise AssertionError(sql)

    env = tmp_path / "desenv.env"
    env.write_text("""DB2_USER=u
DB2_PASS=p
DASHBOARD_MOEDA_PADRAO=BRL
DASHBOARD_PLOTLY_OFFLINE=false
DB2_CHUNKSIZE=1000
""")
    resultado = fluxo_dashboard(
        987654321012345,
        "2026-01-01",
        "2026-07-31",
        exibir=False,
        env_path=env,
        cliente_db2=Db2Controlado(),
    )
    assert "cd_cli" not in resultado["consulta"]
    assert resultado["origem_renda"]["fonte_principal"]["classificacao"] == "SALARIO_PROVAVEL_FORTE"
    assert "html" in resultado


def _metadados_db2():
    rows=[]
    for chave, fonte in FONTES.items():
        for ordem, coluna in enumerate(COLUNAS_POR_FONTE[chave]):
            if coluna.startswith("DT_") or coluna.startswith("TS_") or coluna == "DT_REF": tipo="DATE"
            elif coluna in {"CD_NTZ_CTB_TRAN","CD_TIP_MOE_CRR"} or coluna.startswith(("TX_","NM_","IN_")): tipo="VARCHAR"
            else: tipo="DECIMAL"
            rows.append({"TABSCHEMA":fonte.schema,"TABNAME":fonte.tabela,"COLNAME":coluna,"TYPENAME":tipo,"LENGTH":20,"SCALE":0,"NULLS":"Y","COLNO":ordem})
    return pd.DataFrame(rows)


def test_validacao_exportada_nao_contem_identificador_restrito(tmp_path, capsys):
    limpar_cache_catalogos()
    segredo = "987654321012345"
    frames = frames_controlados(int(segredo))
    meta = _metadados_db2()

    class ClienteValidacao:
        def query(self, sql, params=None, chunksize=None):
            assert segredo not in sql
            s = sql.upper()
            if s.strip().startswith("VALUES"):
                return pd.DataFrame([{"OK": 1}])
            if "CMPT_TRAN_RLZD_CC" in s:
                return frames["complementos_conta"]
            if "INF_OPB_CT_CLI" in s:
                return frames["contas"]
            if "TRAN_RLZD_INST_PCT" in s:
                return frames["transacoes"]
            if "CTGR_TRAN_OPB" in s:
                return frames["categorias"]
            if "GR_CTGR_TRAN" in s:
                return frames["grupos"]
            if "CLI_SGM" in s:
                return frames["perfil_renda"]
            if "DVS_GRDR_FNCO_PF" in s:
                return frames["perfil_financeiro"]
            raise AssertionError("consulta não reconhecida")

        def connect(self):
            return object()

        def show_schemas(self):
            return pd.DataFrame({"SCHEMA": sorted({fonte.schema for fonte in FONTES.values()})})

        def show_tables(self, schema):
            return pd.DataFrame([
                {"SCHEMA": fonte.schema, "NAME": fonte.tabela, "TYPE": "T"}
                for fonte in FONTES.values()
                if fonte.schema == schema
            ])

        def syscolumns(self, schema, table):
            return meta[(meta["TABSCHEMA"] == schema) & (meta["TABNAME"] == table)].copy()

        def systabstats(self, schema, table):
            return pd.DataFrame([{"TABSCHEMA": schema, "TABNAME": table, "CARD": 1}])

        def describe(self, schema, table):
            return None

    env = tmp_path / "desenv.env"
    env.write_text("""DB2_USER=u
DB2_PASS=p
DASHBOARD_MOEDA_PADRAO=BRL
DASHBOARD_PLOTLY_OFFLINE=false
DB2_CHUNKSIZE=1000
""")
    rel = executar_todas_validacoes(
        segredo,
        "2026-01-01",
        "2026-07-31",
        env_path=env,
        cliente_db2=ClienteValidacao(),
        exibir=True,
        exportar=True,
        pasta_saida=tmp_path / "saida",
        limite_amostra=20,
    )
    capturado = capsys.readouterr().out
    assert segredo not in capturado
    zip_path = Path(rel["pacote_exportado"])
    assert zip_path.exists()
    assert segredo.encode() not in zip_path.read_bytes()
    with zipfile.ZipFile(zip_path) as zf:
        for nome in zf.namelist():
            assert segredo not in nome
            assert segredo not in zf.read(nome).decode("utf-8", errors="ignore")



def test_validacoes_retornam_relatorio_quando_pipeline_falha(tmp_path):
    segredo = "987654321012345"

    class ClienteFalha:
        def query(self, sql, params=None, chunksize=None):
            if str(sql).strip().upper().startswith("VALUES"):
                return pd.DataFrame({"1": [1]})
            raise RuntimeError("falha controlada")

        def show_tables(self, schema):
            return pd.DataFrame()

        def syscolumns(self, schema, table):
            return pd.DataFrame()

        def systabstats(self, schema, table):
            return pd.DataFrame()

    env = tmp_path / "desenv.env"
    env.write_text(
        "DB2_USER=u\nDB2_PASS=p\nDASHBOARD_MOEDA_PADRAO=BRL\n"
        "DASHBOARD_PLOTLY_OFFLINE=false\nDB2_CHUNKSIZE=1000\n"
    )
    relatorio = executar_todas_validacoes(
        segredo,
        "2026-01-01",
        "2026-07-31",
        env_path=env,
        cliente_db2=ClienteFalha(),
        exibir=False,
        exportar=False,
    )
    assert relatorio["estado_pipeline"] == "PIPELINE_REPROVADO"
    assert relatorio["estado_execucao"] == "EXECUCAO_REPROVADO"
    validacoes = relatorio["tabelas"]["validacoes"]
    assert "PIPE_RUN" in set(validacoes["codigo"])
    assert "RUN_NOT_EXECUTED" in set(validacoes["codigo"])
    assert segredo not in validacoes.to_csv(index=False)


def test_notebooks_validos_e_sem_cliente_pre_preenchido():
    for nome in ("rotina-principal.ipynb", "todas_validacoes.ipynb"):
        nb=nbformat.read(ROOT/nome,as_version=4)
        texto='\n'.join(str(c.get('source','')) for c in nb.cells)
        assert "987654321012345" not in texto
        assert nb.cells


def test_nomes_fisicos_fora_fontes_apenas_em_sqls_gerados():
    # Regra arquitetural: módulos analíticos não declaram nomes físicos.
    for nome in ("analise.py","qualidade.py","circulacao.py","renda.py","jornada.py","visual.py"):
        texto=(ROOT/"src"/nome).read_text(encoding="utf-8")
        assert "DB2GFP." not in texto
        assert "DB2D1D." not in texto


def test_sem_nota_global_ou_diagnostico_comportamental():
    frames=frames_controlados(); payload=montar_painel(frames=frames,consulta=consulta(),fontes=metadados(frames))
    texto=json.dumps(payload,ensure_ascii=False,default=str).lower()
    assert "pontuacao_global" not in texto
    assert "saúde financeira" not in texto
    assert "comportamento preocupante" not in texto


def test_salario_nao_e_afirmado_com_apenas_dois_meses():
    frames = frames_controlados()
    frames["transacoes"] = frames["transacoes"][
        ~((frames["transacoes"]["TX_DCR_TRAN"] == "Folha salario mensal") & (pd.to_datetime(frames["transacoes"]["DT_TRAN"]).dt.month > 2))
    ].copy()
    base, _ = normalizar_movimentacoes(
        frames["transacoes"], frames["contas"], frames["complementos_conta"],
        frames["categorias"], frames["grupos"],
    )
    q = executar_estudo_qualidade(base)
    c = executar_estudo_circulacao(q["base_sem_duplicidades"])
    estudo = executar_estudo_renda(q["base_anotada"], q["base_sem_duplicidades"], c["pares"], consulta())
    assert estudo["fonte_principal"] is None
    assert all("SALARIO_PROVAVEL" not in f["classificacao"] for f in estudo["fontes"])


def test_duplicidade_provavel_nao_e_neutralizada():
    base = base_normalizada().copy()
    original = base.iloc[0].copy()
    original["id_movimento"] = "EXTRA-1"
    original["id_evento_fisico"] = "EXTRA-1"
    original["hora"] = "18:00"
    copia = original.copy()
    copia["id_movimento"] = "EXTRA-2"
    copia["id_evento_fisico"] = "EXTRA-2"
    copia["hora"] = "18:45"
    base = pd.concat([base, pd.DataFrame([original, copia])], ignore_index=True)
    estudo = executar_estudo_qualidade(base)
    grupo = estudo["base_anotada"][estudo["base_anotada"]["id_movimento"].isin(["EXTRA-1", "EXTRA-2"])]
    assert set(grupo["estado_duplicidade"]) == {"DUPLICIDADE_PROVAVEL"}
    assert not grupo["duplicidade_usada_estimativa"].any()


def test_ambiguidade_de_circulacao_nao_entra_na_estimativa():
    base = pd.DataFrame([
        {"id_movimento":"S1","valor_centavos":50000,"moeda":"BRL","natureza":"D","data":"2026-01-10","conta_id":"A","conta_rotulo":"Conta A","instituicao_codigo":1,"instituicao_rotulo":"Instituição 1","conta_sequencial":1,"descricao_normalizada":"PIX TRANSFERENCIA","contraparte_conta_normalizada":"","conta_numero_normalizado":"1","contraparte_titular_cliente":False},
        {"id_movimento":"E1","valor_centavos":50000,"moeda":"BRL","natureza":"C","data":"2026-01-10","conta_id":"B","conta_rotulo":"Conta B","instituicao_codigo":2,"instituicao_rotulo":"Instituição 2","conta_sequencial":2,"descricao_normalizada":"RECEBIMENTO PIX","contraparte_conta_normalizada":"","conta_numero_normalizado":"2","contraparte_titular_cliente":False},
        {"id_movimento":"E2","valor_centavos":50000,"moeda":"BRL","natureza":"C","data":"2026-01-10","conta_id":"C","conta_rotulo":"Conta C","instituicao_codigo":3,"instituicao_rotulo":"Instituição 3","conta_sequencial":3,"descricao_normalizada":"RECEBIMENTO PIX","contraparte_conta_normalizada":"","conta_numero_normalizado":"3","contraparte_titular_cliente":False},
    ])
    estudo = executar_estudo_circulacao(base)
    assert estudo["resumo"]["quantidade_pares_ambiguos"] == 2
    assert estudo["resumo"]["quantidade_movimentos_neutralizados_estimativa"] == 0


def test_ids_publicos_nao_revelam_chaves_fisicas():
    frames = frames_controlados()
    payload = montar_painel(frames=frames, consulta=consulta(), fontes=metadados(frames))
    assert all(m["id_movimento"].startswith("MOV-") for m in payload["movimentacoes"])
    assert all(p["id_par"].startswith("PAR-") for p in payload["circulacao_bancos"]["pares"])
    texto = json.dumps(payload["movimentacoes"], ensure_ascii=False)
    assert "id_evento_fisico" not in texto
    assert "numero_transacao" not in texto


def test_ciclo_acompanha_conta_destino_de_transferencia_forte():
    frames = frames_controlados()
    payload = montar_painel(frames=frames, consulta=consulta(), fontes=metadados(frames))
    ciclo = payload["uso_dinheiro"]["ciclos"]["eventos"][0]
    assert len(ciclo["contas_acompanhadas"]) >= 2
    ate_7 = next(x for x in ciclo["janelas"] if x["dias"] == 7)
    assert ate_7["gastos_necessarios"] >= 3150
