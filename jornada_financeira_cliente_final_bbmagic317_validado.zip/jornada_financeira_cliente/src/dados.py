"""Acesso ao Db2 por meio da API pública do bbmagic 3.1.7.

A camada usa exclusivamente ``bbmagic.Db2.query`` com parâmetros separados do texto SQL. Consultas
potencialmente maiores são consumidas em chunks e concatenadas em pandas. O
identificador restrito do cliente nunca é incorporado ao texto SQL.
"""
from __future__ import annotations

from datetime import timedelta
import re
import warnings
from importlib import metadata as importlib_metadata
from time import perf_counter
from typing import Any, Iterable, Iterator, Sequence

import pandas as pd

from .config import Configuracao
from .fontes import (
    COLUNAS_CATEGORIAS,
    COLUNAS_COMPLEMENTOS_CONTA,
    COLUNAS_CONTAS,
    COLUNAS_GRUPOS,
    COLUNAS_TRANSACOES,
    FONTES,
    colunas_com_alias,
    tabela,
)
from .modelos import ConsultaPainel
from .regras import DATA_CORTE_PERFIL_RENDA


class ErroDados(RuntimeError):
    """Erro seguro de conexão, consulta ou conversão."""


class SqlParametrizado(str):
    """Texto SQL compatível com ``str`` e acompanhado de parâmetros seguros."""

    params: tuple[Any, ...]
    usar_chunks: bool
    nome: str

    def __new__(
        cls,
        sql: str,
        *,
        params: Sequence[Any] | None = None,
        usar_chunks: bool = False,
        nome: str = "consulta",
    ) -> "SqlParametrizado":
        objeto = super().__new__(cls, sql.strip())
        objeto.params = tuple(params or ())
        objeto.usar_chunks = bool(usar_chunks)
        objeto.nome = str(nome)
        return objeto

    def resumo_publico(self) -> dict[str, Any]:
        return {
            "nome": self.nome,
            "quantidade_parametros": len(self.params),
            "usar_chunks": self.usar_chunks,
        }


_CACHE_CATALOGOS: dict[int, dict[str, pd.DataFrame]] = {}


def versao_bbmagic() -> str | None:
    try:
        return importlib_metadata.version("bbmagic")
    except importlib_metadata.PackageNotFoundError:
        return None


def criar_cliente_db2(config: Configuracao) -> Any:
    """Cria exclusivamente ``bbmagic.Db2`` com usuário e senha do desenv.env."""
    if not config.db2_user or not config.db2_pass:
        raise ErroDados(
            "DB2_USER e DB2_PASS precisam estar configurados no desenv.env."
        )
    try:
        from bbmagic import Db2
    except ImportError as exc:
        raise ErroDados(
            "A biblioteca corporativa bbmagic não está disponível neste ambiente."
        ) from exc

    try:
        cliente = Db2(
            user=config.db2_user,
            password=config.db2_pass,
            host=config.db2_host,
            port=config.db2_port,
            database=config.db2_database,
            trust_env=config.db2_trust_env,
            pconnect=config.db2_pconnect,
        )
    except Exception as exc:
        raise ErroDados(
            f"Falha ao iniciar o Db2 do bbmagic ({type(exc).__name__})."
        ) from exc
    try:
        setattr(cliente, "_jornada_origem_credencial", "ENV_BBMAGIC")
    except Exception:
        pass
    return cliente


def capacidades_bbmagic(cliente_db2: Any) -> dict[str, bool]:
    metodos = (
        "query", "connect", "show_schemas", "show_tables", "syscolumns",
        "systabstats", "describe",
    )
    return {metodo: callable(getattr(cliente_db2, metodo, None)) for metodo in metodos}


def _para_pandas(resultado: Any) -> pd.DataFrame:
    if resultado is None:
        return pd.DataFrame()
    if isinstance(resultado, pd.DataFrame):
        frame = resultado.copy()
    elif hasattr(resultado, "toPandas"):
        frame = resultado.toPandas()
    else:
        try:
            frame = pd.DataFrame(resultado)
        except Exception as exc:
            raise ErroDados("O retorno do Db2 não pôde ser convertido para DataFrame.") from exc
    frame.columns = [str(coluna).upper() for coluna in frame.columns]
    return frame


def _concatenar_resultado(resultado: Any) -> pd.DataFrame:
    if resultado is None or isinstance(resultado, pd.DataFrame) or hasattr(resultado, "toPandas"):
        return _para_pandas(resultado)

    if isinstance(resultado, (str, bytes, dict)):
        return _para_pandas(resultado)

    try:
        iterador: Iterator[Any] = iter(resultado)
    except TypeError:
        return _para_pandas(resultado)

    partes: list[pd.DataFrame] = []
    for parte in iterador:
        frame = _para_pandas(parte)
        if not frame.empty or len(frame.columns):
            partes.append(frame)
    if not partes:
        return pd.DataFrame()
    colunas = list(partes[0].columns)
    for parte in partes[1:]:
        if list(parte.columns) != colunas:
            raise ErroDados("Os chunks retornados pelo Db2 possuem colunas incompatíveis.")
    return pd.concat(partes, ignore_index=True)


_MARCADORES_DATA_NAO_TIPADOS = re.compile(
    r"\b(?:DATE|TIME|TIMESTAMP)\s*\(\s*\?\s*\)", re.IGNORECASE
)


def contar_marcadores_sql(sql: str) -> int:
    """Conta marcadores ``?`` fora de strings e comentários SQL."""
    texto = str(sql)
    total = 0
    i = 0
    estado = "NORMAL"
    while i < len(texto):
        atual = texto[i]
        proximo = texto[i + 1] if i + 1 < len(texto) else ""
        if estado == "NORMAL":
            if atual == "'":
                estado = "STRING"
            elif atual == '"':
                estado = "IDENTIFICADOR"
            elif atual == "-" and proximo == "-":
                estado = "COMENTARIO_LINHA"
                i += 1
            elif atual == "/" and proximo == "*":
                estado = "COMENTARIO_BLOCO"
                i += 1
            elif atual == "?":
                total += 1
        elif estado == "STRING":
            if atual == "'":
                if proximo == "'":
                    i += 1
                else:
                    estado = "NORMAL"
        elif estado == "IDENTIFICADOR":
            if atual == '"':
                if proximo == '"':
                    i += 1
                else:
                    estado = "NORMAL"
        elif estado == "COMENTARIO_LINHA":
            if atual in "\r\n":
                estado = "NORMAL"
        elif estado == "COMENTARIO_BLOCO":
            if atual == "*" and proximo == "/":
                estado = "NORMAL"
                i += 1
        i += 1
    return total


def validar_sql_parametrizado(
    sql: str | SqlParametrizado,
    params: Sequence[Any] | None = None,
) -> dict[str, Any]:
    """Valida o contrato do SQL antes de chamar o driver do Db2.

    Evita especialmente o SQL0418N provocado por marcadores sem tipo em
    expressões como ``DATE(?)``. Datas devem usar ``CAST(? AS DATE)``.
    """
    texto = str(sql).strip()
    if not texto:
        raise ErroDados("A consulta SQL está vazia.")
    parametros = tuple(params if params is not None else getattr(sql, "params", ()))
    marcadores = contar_marcadores_sql(texto)
    if marcadores != len(parametros):
        raise ErroDados(
            "Quantidade de marcadores SQL diferente da quantidade de parâmetros."
        )
    if _MARCADORES_DATA_NAO_TIPADOS.search(texto):
        raise ErroDados(
            "Marcador temporal sem tipo detectado; use CAST(? AS DATE/TIME/TIMESTAMP)."
        )
    if re.search(r"\bSELECT\s+\*", texto, flags=re.IGNORECASE):
        raise ErroDados("SELECT * não é permitido nas consultas do projeto.")
    return {
        "quantidade_marcadores": marcadores,
        "quantidade_parametros": len(parametros),
        "marcadores_temporais_tipados": True,
    }


def executar_select(
    cliente_db2: Any,
    sql: str | SqlParametrizado,
    *,
    params: Sequence[Any] | None = None,
    chunksize: int | None = None,
) -> pd.DataFrame:
    """Executa uma consulta usando exclusivamente ``Db2.query``.

    O erro público nunca replica SQL, parâmetros ou mensagens completas do driver.
    """
    metodo = getattr(cliente_db2, "query", None)
    if not callable(metodo):
        raise ErroDados("O cliente Db2 não disponibiliza o método público query().")

    parametros = tuple(params if params is not None else getattr(sql, "params", ()))
    validar_sql_parametrizado(sql, parametros)
    try:
        # O bbmagic 3.1.7 usa pandas.read_sql sobre ibm_db_dbi. Pandas emite
        # um aviso genérico sobre conectores DBAPI não testados, embora a chamada
        # seja a implementação oficial do próprio bbmagic. Suprimimos somente
        # esse aviso conhecido; erros do driver continuam sendo propagados.
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message=r"pandas only supports SQLAlchemy connectable.*",
                category=UserWarning,
            )
            resultado = metodo(
                str(sql),
                params=list(parametros) if parametros else None,
                chunksize=chunksize,
            )
        return _concatenar_resultado(resultado)
    except ErroDados:
        raise
    except Exception as exc:
        raise ErroDados(f"Falha na consulta Db2 ({type(exc).__name__}).") from exc


def _validar_consulta(consulta: ConsultaPainel) -> None:
    if consulta.cd_cli <= 0:
        raise ValueError("cd_cli deve ser um inteiro positivo.")
    if consulta.periodo_inicio > consulta.periodo_fim:
        raise ValueError("periodo_inicio não pode ser posterior a periodo_fim.")
    if len(consulta.moeda) != 3 or not consulta.moeda.isalpha():
        raise ValueError("moeda deve conter três letras.")


def _filtros_transacao(
    consulta: ConsultaPainel,
    alias: str = "t",
) -> tuple[list[str], list[Any]]:
    _validar_consulta(consulta)
    fim_exclusivo = consulta.periodo_fim + timedelta(days=1)
    filtros = [
        f"{alias}.CD_CLI = ?",
        f"{alias}.DT_TRAN >= CAST(? AS DATE)",
        f"{alias}.DT_TRAN < CAST(? AS DATE)",
        f"{alias}.CD_EST_TRAN_INST = 0",
        f"{alias}.CD_TIP_MOE_CRR = ?",
    ]
    params: list[Any] = [
        int(consulta.cd_cli),
        consulta.periodo_inicio.isoformat(),
        fim_exclusivo.isoformat(),
        consulta.moeda,
    ]
    if consulta.instituicoes:
        marcadores = ", ".join("?" for _ in consulta.instituicoes)
        filtros.append(f"{alias}.CD_INST_PCT IN ({marcadores})")
        params.extend(int(valor) for valor in consulta.instituicoes)
    return filtros, params


def montar_sql_transacoes(consulta: ConsultaPainel) -> SqlParametrizado:
    filtros, params = _filtros_transacao(consulta, "t")
    return SqlParametrizado(
        f"""
        SELECT
            {colunas_com_alias(COLUNAS_TRANSACOES, 't')}
        FROM {tabela('transacoes')} t
        WHERE {' AND '.join(filtros)}
        ORDER BY t.DT_TRAN, t.HR_TRAN, t.NR_TRAN_INST_PCT
        """,
        params=params,
        usar_chunks=True,
        nome="transacoes",
    )


def montar_sql_contas(consulta: ConsultaPainel) -> SqlParametrizado:
    _validar_consulta(consulta)
    filtros = ["c.CD_CLI_TITR_CT = ?"]
    params: list[Any] = [int(consulta.cd_cli)]
    if consulta.instituicoes:
        marcadores = ", ".join("?" for _ in consulta.instituicoes)
        filtros.append(f"c.CD_INST_PCT IN ({marcadores})")
        params.extend(int(valor) for valor in consulta.instituicoes)
    return SqlParametrizado(
        f"""
        SELECT
            {colunas_com_alias(COLUNAS_CONTAS, 'c')}
        FROM {tabela('contas')} c
        WHERE {' AND '.join(filtros)}
        """,
        params=params,
        nome="contas",
    )


def montar_sql_complementos_conta(consulta: ConsultaPainel) -> SqlParametrizado:
    """Carrega somente complementos ligados às transações do recorte."""
    filtros_t, params_t = _filtros_transacao(consulta, "t")
    params = [int(consulta.cd_cli), *params_t]
    return SqlParametrizado(
        f"""
        SELECT
            {colunas_com_alias(COLUNAS_COMPLEMENTOS_CONTA, 'c')}
        FROM {tabela('complementos_conta')} c
        WHERE c.CD_CLI = ?
          AND EXISTS (
              SELECT 1
              FROM {tabela('transacoes')} t
              WHERE t.NR_PTC = c.NR_PTC
                AND t.NR_TRAN_INST_PCT = c.NR_TRAN_INST_PCT
                AND {' AND '.join(filtros_t)}
          )
        """,
        params=params,
        usar_chunks=True,
        nome="complementos_conta",
    )


def montar_sql_categorias() -> SqlParametrizado:
    return SqlParametrizado(
        f"SELECT {', '.join(COLUNAS_CATEGORIAS)} FROM {tabela('categorias')}",
        nome="categorias",
    )


def montar_sql_grupos() -> SqlParametrizado:
    return SqlParametrizado(
        f"SELECT {', '.join(COLUNAS_GRUPOS)} FROM {tabela('grupos')}",
        nome="grupos",
    )


def montar_sql_perfil_renda(consulta: ConsultaPainel) -> SqlParametrizado:
    return SqlParametrizado(
        f"""
        SELECT CD_CLI, CD_PRFL, DT_REF_PERFIL_RENDA
        FROM (
            SELECT
                p.CD_CLI,
                p.CD_SGM_CLI AS CD_PRFL,
                p.DT_ENQ_CLI_SGM AS DT_REF_PERFIL_RENDA,
                ROW_NUMBER() OVER (
                    PARTITION BY p.CD_CLI
                    ORDER BY p.DT_ENQ_CLI_SGM DESC
                ) AS NR_ORDEM
            FROM {tabela('perfil_renda')} p
            WHERE p.CD_CLI = ?
              AND p.CD_CRIT_SGM_CLI = 2
              AND p.DT_ENQ_CLI_SGM > CAST(? AS DATE)
              AND p.DT_ENQ_CLI_SGM <= CAST(? AS DATE)
        ) x
        WHERE NR_ORDEM = 1
        """,
        params=[
            int(consulta.cd_cli),
            DATA_CORTE_PERFIL_RENDA,
            consulta.periodo_fim.isoformat(),
        ],
        nome="perfil_renda",
    )


def montar_sql_perfil_financeiro(consulta: ConsultaPainel) -> SqlParametrizado:
    return SqlParametrizado(
        f"""
        SELECT CD_CLI, CD_MAC_PRFL_CLI, CD_MIC_PRFL_CLI, DT_REF_PERFIL_FINANCEIRO
        FROM (
            SELECT
                p.CD_CLI,
                p.CD_MAC_PRFL_CLI,
                p.CD_MIC_PRFL_CLI,
                p.DT_REF AS DT_REF_PERFIL_FINANCEIRO,
                ROW_NUMBER() OVER (
                    PARTITION BY p.CD_CLI
                    ORDER BY p.DT_REF DESC,
                             p.CD_MAC_PRFL_CLI DESC,
                             p.CD_MIC_PRFL_CLI DESC
                ) AS NR_ORDEM
            FROM {tabela('perfil_financeiro')} p
            WHERE p.CD_CLI = ?
              AND p.DT_REF <= CAST(? AS DATE)
        ) x
        WHERE NR_ORDEM = 1
        """,
        params=[int(consulta.cd_cli), consulta.periodo_fim.isoformat()],
        nome="perfil_financeiro",
    )


def _consultar_fonte(
    *,
    cliente_db2: Any,
    chave: str,
    comando: SqlParametrizado,
    chunksize: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    inicio = perf_counter()
    try:
        frame = executar_select(
            cliente_db2,
            comando,
            chunksize=chunksize if comando.usar_chunks else None,
        )
        estado = "CARREGADA"
        erro = None
    except ErroDados as exc:
        if FONTES[chave].obrigatoria:
            raise
        frame = pd.DataFrame()
        estado = "INDISPONIVEL"
        erro = str(exc)
    tempo_ms = round((perf_counter() - inicio) * 1000, 2)
    return frame, {
        "tabela": FONTES[chave].nome_completo,
        "finalidade": FONTES[chave].finalidade,
        "obrigatoria": FONTES[chave].obrigatoria,
        "estado": estado,
        "linhas_retornadas": int(len(frame)),
        "tempo_ms": tempo_ms,
        "erro": erro,
        "consulta_parametrizada": True,
        "quantidade_parametros": len(comando.params),
        "leitura_em_chunks": comando.usar_chunks,
    }


def _carregar_catalogos(
    cliente_db2: Any,
    chunksize: int,
) -> tuple[dict[str, pd.DataFrame], dict[str, Any]]:
    cache_key = id(cliente_db2)
    if cache_key in _CACHE_CATALOGOS:
        frames = {
            chave: frame.copy()
            for chave, frame in _CACHE_CATALOGOS[cache_key].items()
        }
        meta = {
            chave: {
                "tabela": FONTES[chave].nome_completo,
                "finalidade": FONTES[chave].finalidade,
                "obrigatoria": True,
                "estado": "CACHE_SESSAO",
                "linhas_retornadas": int(len(frame)),
                "tempo_ms": 0.0,
                "erro": None,
                "consulta_parametrizada": True,
                "quantidade_parametros": 0,
                "leitura_em_chunks": False,
            }
            for chave, frame in frames.items()
        }
        return frames, meta

    frames: dict[str, pd.DataFrame] = {}
    meta: dict[str, Any] = {}
    comandos = (
        ("categorias", montar_sql_categorias()),
        ("grupos", montar_sql_grupos()),
    )
    for chave, comando in comandos:
        frames[chave], meta[chave] = _consultar_fonte(
            cliente_db2=cliente_db2,
            chave=chave,
            comando=comando,
            chunksize=chunksize,
        )
    _CACHE_CATALOGOS[cache_key] = {
        chave: frame.copy() for chave, frame in frames.items()
    }
    return frames, meta


def limpar_cache_catalogos() -> None:
    _CACHE_CATALOGOS.clear()


def carregar_dados(
    consulta: ConsultaPainel,
    config: Configuracao,
    *,
    cliente_db2: Any | None = None,
) -> dict[str, Any]:
    _validar_consulta(consulta)
    cliente = cliente_db2 or criar_cliente_db2(config)
    frames, metadados = _carregar_catalogos(cliente, config.chunksize_db2)
    consultas = {
        "transacoes": montar_sql_transacoes(consulta),
        "contas": montar_sql_contas(consulta),
        "complementos_conta": montar_sql_complementos_conta(consulta),
        "perfil_renda": montar_sql_perfil_renda(consulta),
        "perfil_financeiro": montar_sql_perfil_financeiro(consulta),
    }
    for chave, comando in consultas.items():
        frames[chave], metadados[chave] = _consultar_fonte(
            cliente_db2=cliente,
            chave=chave,
            comando=comando,
            chunksize=config.chunksize_db2,
        )
    return {
        "frames": frames,
        "fontes": metadados,
        "integracao_db2": {
            "bbmagic_versao": versao_bbmagic(),
            "metodo_consulta": "Db2.query",
            "chunksize": config.chunksize_db2,
            "capacidades": capacidades_bbmagic(cliente),
            "origem_credencial": getattr(cliente, "_jornada_origem_credencial", "FORNECIDA_EXTERNAMENTE"),
        },
    }


__all__ = [
    "ErroDados", "SqlParametrizado", "versao_bbmagic", "capacidades_bbmagic",
    "criar_cliente_db2", "contar_marcadores_sql", "validar_sql_parametrizado",
    "executar_select", "montar_sql_transacoes",
    "montar_sql_contas", "montar_sql_complementos_conta", "montar_sql_categorias",
    "montar_sql_grupos", "montar_sql_perfil_renda", "montar_sql_perfil_financeiro",
    "carregar_dados", "limpar_cache_catalogos",
]
