"""Configuração técnica da integração exclusiva com o Db2 do bbmagic.

As credenciais são lidas de ``desenv.env`` e entregues explicitamente ao
construtor ``bbmagic.Db2(user=..., password=...)``. O projeto não possui cofre,
fallback de credenciais ou conexão alternativa.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

from dotenv import load_dotenv


@dataclass(frozen=True)
class Configuracao:
    db2_user: str | None
    db2_pass: str | None
    db2_host: str
    db2_port: int
    db2_database: str
    db2_trust_env: bool
    db2_pconnect: bool
    moeda_padrao: str
    incluir_plotly_offline: bool
    chunksize_db2: int
    db2_credential_mode: str = "ENV_BBMAGIC"

    @property
    def fetchsize_db2(self) -> int:
        """Compatibilidade temporária com versões anteriores do projeto."""
        return self.chunksize_db2

    @property
    def credenciais_configuradas(self) -> bool:
        return bool(self.db2_user and self.db2_pass)


def _bool_env(nome: str, padrao: bool) -> bool:
    valor = os.getenv(nome)
    if valor is None:
        return padrao
    normalizado = valor.strip().lower()
    if normalizado in {"1", "true", "sim", "s", "yes", "y"}:
        return True
    if normalizado in {"0", "false", "nao", "não", "n", "no"}:
        return False
    raise ValueError(f"{nome} deve ser true ou false.")


def _inteiro_positivo(nome: str, padrao: str) -> int:
    try:
        valor = int(os.getenv(nome, padrao))
    except ValueError as exc:
        raise ValueError(f"{nome} deve ser um número inteiro.") from exc
    if valor <= 0:
        raise ValueError(f"{nome} deve ser maior que zero.")
    return valor


def carregar_configuracao(env_path: str | Path = "desenv.env") -> Configuracao:
    caminho = Path(env_path)
    if not caminho.exists():
        raise FileNotFoundError(f"Arquivo de configuração não encontrado: {caminho}")

    # O arquivo informado é a fonte explícita de configuração desta execução.
    # override=True evita que um kernel antigo mantenha valores carregados antes
    # de uma alteração no desenv.env.
    load_dotenv(caminho, override=True)

    moeda = os.getenv("DASHBOARD_MOEDA_PADRAO", "BRL").strip().upper()
    if len(moeda) != 3 or not moeda.isalpha():
        raise ValueError("DASHBOARD_MOEDA_PADRAO deve conter três letras.")

    chunksize_texto = os.getenv("DB2_CHUNKSIZE") or os.getenv("DB2_FETCHSIZE") or "10000"
    try:
        chunksize = int(chunksize_texto)
    except ValueError as exc:
        raise ValueError("DB2_CHUNKSIZE deve ser um número inteiro.") from exc
    if chunksize <= 0:
        raise ValueError("DB2_CHUNKSIZE deve ser maior que zero.")

    host = os.getenv("DB2_HOST", "gwdb2.bb.com.br").strip()
    database = os.getenv("DB2_DATABASE", "BDB2P04").strip()
    if not host:
        raise ValueError("DB2_HOST não pode ficar vazio.")
    if not database:
        raise ValueError("DB2_DATABASE não pode ficar vazio.")

    return Configuracao(
        db2_user=(os.getenv("DB2_USER") or "").strip() or None,
        db2_pass=os.getenv("DB2_PASS") or None,
        db2_host=host,
        db2_port=_inteiro_positivo("DB2_PORT", "50100"),
        db2_database=database,
        db2_trust_env=_bool_env("DB2_TRUST_ENV", True),
        db2_pconnect=_bool_env("DB2_PCONNECT", True),
        moeda_padrao=moeda,
        incluir_plotly_offline=_bool_env("DASHBOARD_PLOTLY_OFFLINE", True),
        chunksize_db2=chunksize,
    )


__all__ = ["Configuracao", "carregar_configuracao"]
