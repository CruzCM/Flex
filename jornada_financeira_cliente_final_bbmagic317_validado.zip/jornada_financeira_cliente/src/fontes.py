"""Cadastro único de fontes físicas e colunas utilizadas pelo painel.

Nenhum outro módulo deve declarar nomes completos de tabelas. Isso permite
alterar schema ou tabela em um único ponto sem misturar decisões físicas com
regras financeiras.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FonteTabela:
    chave: str
    schema: str
    tabela: str
    finalidade: str
    campo_cliente: str | None
    obrigatoria: bool

    @property
    def nome_completo(self) -> str:
        return f"{self.schema}.{self.tabela}"


TABELAS_SISTEMA: dict[str, str] = {
    "catalogo_colunas": "SYSCAT.COLUMNS",
    "dummy": "SYSIBM.SYSDUMMY1",
}

FONTES: dict[str, FonteTabela] = {
    "transacoes": FonteTabela(
        chave="transacoes",
        schema="DB2GFP",
        tabela="TRAN_RLZD_INST_PCT",
        finalidade="Movimentações observadas do cliente no período.",
        campo_cliente="CD_CLI",
        obrigatoria=True,
    ),
    "contas": FonteTabela(
        chave="contas",
        schema="DB2GFP",
        tabela="INF_OPB_CT_CLI",
        finalidade="Identidade, instituição, produto e cobertura das contas.",
        campo_cliente="CD_CLI_TITR_CT",
        obrigatoria=False,
    ),
    "complementos_conta": FonteTabela(
        chave="complementos_conta",
        schema="DB2GFP",
        tabela="CMPT_TRAN_RLZD_CC",
        finalidade="Contraparte e identificadores candidatos à conciliação.",
        campo_cliente="CD_CLI",
        obrigatoria=False,
    ),
    "categorias": FonteTabela(
        chave="categorias",
        schema="DB2GFP",
        tabela="CTGR_TRAN_OPB",
        finalidade="Catálogo oficial de categorias de movimentações.",
        campo_cliente=None,
        obrigatoria=True,
    ),
    "grupos": FonteTabela(
        chave="grupos",
        schema="DB2GFP",
        tabela="GR_CTGR_TRAN",
        finalidade="Catálogo oficial de grupos de categorias.",
        campo_cliente=None,
        obrigatoria=True,
    ),
    "perfil_renda": FonteTabela(
        chave="perfil_renda",
        schema="DB2SMI",
        tabela="CLI_SGM",
        finalidade="Segmentação opcional preservada para contexto futuro; não prova salário ou renda observada.",
        campo_cliente="CD_CLI",
        obrigatoria=False,
    ),
    "perfil_financeiro": FonteTabela(
        chave="perfil_financeiro",
        schema="DB2D1D",
        tabela="DVS_GRDR_FNCO_PF",
        finalidade="Perfil opcional preservado para contexto futuro; não interfere na origem da renda ou principalidade.",
        campo_cliente="CD_CLI",
        obrigatoria=False,
    ),
}

COLUNAS_TRANSACOES = (
    "NR_TRAN_INST_PCT", "NR_PTC", "CD_CLI", "CD_TIP_PSS",
    "NR_MCA_PCT_OPB", "CD_INST_PCT", "NR_AG_TITR", "CD_CT_TITR",
    "DV_CT_TITR", "NR_SEQL_CT_CLI", "CD_PRD", "VL_TRAN",
    "CD_TIP_MOE_CRR", "TX_DCR_TRAN", "TX_CMPR_DCR_TRAN",
    "TX_DCR_TRAN_OGNL", "CD_NTZ_CTB_TRAN", "DT_TRAN", "HR_TRAN",
    "CD_CTGR_TRAN", "CD_CTGR_TRAN_OGNL", "CD_EST_TRAN_INST",
    "CD_TIP_TRAN", "IN_VSLO_EVT", "IN_VSLO_CX", "IN_VSLO_CSM",
    "IN_OCTR_TRAN", "IN_DVS_LCTO", "CD_CLSC_MTO_CTGR",
    "CD_HASH_AGPT_TRAN", "TS_INCL_TRAN", "TS_ATL_TRAN",
)

COLUNAS_CONTAS = (
    "CD_CLI_TITR_CT", "NR_MCA_PCT_OPB", "NR_SEQL_CT_CLI",
    "CD_CPF_CNPJ_TITR", "CD_INST_PCT", "CD_CPSO_INST_PCT",
    "CD_TIP_PSS", "CD_IDFR_CT", "CD_AG_DTTR_CT", "CD_CT_TITR",
    "DV_CT_TITR", "CD_TIP_CT_OPB", "CD_PRD", "CD_MDLD_PRD",
    "TS_ATL_INF", "IN_AUTZ_EXB_TRAN", "TS_ULT_ATL_TRAN", "NM_IDFC_CT",
    "TX_TIP_CT_CRT", "TX_CMPR_TIP_CT_CRT", "TX_BND_CT_CRT",
    "TX_CMPR_BND_CT_CRT", "NR_IDFR_PLST_CT", "IN_EXB_DADO_CT",
    "NR_SEQL_AUTZ_OPB", "CD_EST_RCS_OPB",
)

COLUNAS_COMPLEMENTOS_CONTA = (
    "NR_TRAN_INST_PCT", "NR_PTC", "NM_TRAN_INST", "CD_IDFR_TRAN_INST",
    "CD_IDFR_CT", "NR_CPF_CNPJ_PGDR", "CD_TIP_PGDR_BNFC",
    "CD_CPSO_PGDR_BNFC", "NR_AG_PGDR_BNFC", "CD_CT_PGDR_BNFC",
    "DV_CT_PGDR_BNFC", "NR_DOC", "CD_HST_TRAN", "CD_SHST_TRAN",
    "CD_SEQL_TRAN", "NR_LT_TRAN", "CD_TRAN_CTA", "DT_CTB_TRAN",
    "CD_CLI", "NR_MCA_PCT_OPB", "NR_SEQL_CT_CLI",
    "CD_CLSC_ATVD_ECNC", "CD_CTGR_CML",
)

COLUNAS_CATEGORIAS = (
    "CD_CTGR_TRAN", "CD_GR_CTGR_TRAN", "CD_NTZ_CTB_TRAN",
    "IN_CTGR_PDRO_SIS", "TX_DCR_CTGR_TRAN",
)

COLUNAS_GRUPOS = ("CD_GR_CTGR_TRAN", "TX_DCR_GR_CTGR")


COLUNAS_PERFIL_RENDA = (
    "CD_CLI", "CD_SGM_CLI", "DT_ENQ_CLI_SGM", "CD_CRIT_SGM_CLI",
)

COLUNAS_PERFIL_FINANCEIRO = (
    "CD_CLI", "CD_MAC_PRFL_CLI", "CD_MIC_PRFL_CLI", "DT_REF",
)

COLUNAS_POR_FONTE: dict[str, tuple[str, ...]] = {
    "transacoes": COLUNAS_TRANSACOES,
    "contas": COLUNAS_CONTAS,
    "complementos_conta": COLUNAS_COMPLEMENTOS_CONTA,
    "categorias": COLUNAS_CATEGORIAS,
    "grupos": COLUNAS_GRUPOS,
    "perfil_renda": COLUNAS_PERFIL_RENDA,
    "perfil_financeiro": COLUNAS_PERFIL_FINANCEIRO,
}

# Famílias de tipo são verificadas apenas nos campos críticos. Os demais
# campos têm sua presença validada sem impor um tipo exato, evitando falsos
# bloqueios por diferenças legítimas de precisão ou comprimento entre ambientes.
TIPOS_CRITICOS_POR_FONTE: dict[str, dict[str, str]] = {
    "transacoes": {
        "CD_CLI": "NUMERIC",
        "NR_PTC": "NUMERIC",
        "NR_TRAN_INST_PCT": "NUMERIC",
        "DT_TRAN": "DATE",
        "VL_TRAN": "NUMERIC",
        "CD_NTZ_CTB_TRAN": "CHARACTER",
        "CD_TIP_MOE_CRR": "CHARACTER",
        "CD_EST_TRAN_INST": "NUMERIC",
    },
    "contas": {
        "CD_CLI_TITR_CT": "NUMERIC",
        "NR_MCA_PCT_OPB": "NUMERIC",
        "NR_SEQL_CT_CLI": "NUMERIC",
        "CD_INST_PCT": "NUMERIC",
    },
    "complementos_conta": {
        "CD_CLI": "NUMERIC",
        "NR_PTC": "NUMERIC",
        "NR_TRAN_INST_PCT": "NUMERIC",
    },
    "categorias": {
        "CD_CTGR_TRAN": "NUMERIC",
        "CD_NTZ_CTB_TRAN": "CHARACTER",
    },
    "grupos": {
        "CD_GR_CTGR_TRAN": "NUMERIC",
    },
    "perfil_renda": {
        "CD_CLI": "NUMERIC",
        "CD_SGM_CLI": "NUMERIC",
        "DT_ENQ_CLI_SGM": "DATE",
        "CD_CRIT_SGM_CLI": "NUMERIC",
    },
    "perfil_financeiro": {
        "CD_CLI": "NUMERIC",
        "CD_MAC_PRFL_CLI": "NUMERIC",
        "CD_MIC_PRFL_CLI": "NUMERIC",
        "DT_REF": "DATE",
    },
}

CHAVE_TRANSACAO = ("NR_PTC", "NR_TRAN_INST_PCT")
CHAVE_CONTA = ("NR_MCA_PCT_OPB", "NR_SEQL_CT_CLI")


def tabela(chave: str) -> str:
    try:
        return FONTES[chave].nome_completo
    except KeyError as exc:
        raise KeyError(f"Fonte não cadastrada: {chave}") from exc


def colunas_com_alias(colunas: tuple[str, ...], alias: str) -> str:
    return ",\n            ".join(f"{alias}.{coluna}" for coluna in colunas)


__all__ = [
    "FonteTabela", "TABELAS_SISTEMA", "FONTES", "COLUNAS_TRANSACOES", "COLUNAS_CONTAS",
    "COLUNAS_COMPLEMENTOS_CONTA", "COLUNAS_CATEGORIAS", "COLUNAS_GRUPOS",
    "COLUNAS_PERFIL_RENDA", "COLUNAS_PERFIL_FINANCEIRO", "COLUNAS_POR_FONTE",
    "TIPOS_CRITICOS_POR_FONTE", "CHAVE_TRANSACAO", "CHAVE_CONTA",
    "tabela", "colunas_com_alias",
]
