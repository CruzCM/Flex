"""Entrada pública e orquestração da Jornada Financeira do Cliente."""
from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Any, Iterable

from IPython.display import HTML, display

from .analise import montar_painel
from .config import carregar_configuracao
from .dados import carregar_dados
from .modelos import ConsultaPainel
from .regras import PERIODO_MAXIMO_CONSULTA_DIAS
from .visual import render_dashboard

TELAS_VALIDAS = {"jornada_dinheiro", "origem_renda", "circulacao_bancos", "uso_dinheiro", "evidencias_qualidade"}


def _data_iso(valor: str | date, nome: str) -> date:
    if isinstance(valor, date):
        return valor
    try:
        return date.fromisoformat(str(valor))
    except ValueError as exc:
        raise ValueError(f"{nome} deve usar o formato AAAA-MM-DD.") from exc


def _normalizar_instituicoes(valores: Iterable[int] | None) -> tuple[int, ...]:
    if valores is None:
        return ()
    normalizadas = tuple(dict.fromkeys(int(valor) for valor in valores))
    if any(valor <= 0 for valor in normalizadas):
        raise ValueError("instituicoes deve conter apenas códigos positivos.")
    return normalizadas


def criar_consulta(
    *,
    cd_cli: int,
    periodo_inicio: str | date,
    periodo_fim: str | date,
    moeda: str,
    instituicoes: Iterable[int] | None,
    tela_inicial: str,
) -> ConsultaPainel:
    codigo = int(cd_cli)
    if codigo <= 0:
        raise ValueError("cd_cli deve ser um inteiro positivo.")
    inicio = _data_iso(periodo_inicio, "periodo_inicio")
    fim = _data_iso(periodo_fim, "periodo_fim")
    if inicio > fim:
        raise ValueError("periodo_inicio não pode ser posterior a periodo_fim.")
    if (fim - inicio).days > PERIODO_MAXIMO_CONSULTA_DIAS:
        raise ValueError(
            f"O período máximo suportado é de {PERIODO_MAXIMO_CONSULTA_DIAS + 1} dias."
        )
    moeda_normalizada = str(moeda).strip().upper()
    if len(moeda_normalizada) != 3 or not moeda_normalizada.isalpha():
        raise ValueError("moeda deve conter três letras.")
    tela = str(tela_inicial).strip().lower()
    if tela not in TELAS_VALIDAS:
        raise ValueError(f"tela_inicial deve ser uma de: {', '.join(sorted(TELAS_VALIDAS))}.")
    return ConsultaPainel(
        cd_cli=codigo,
        periodo_inicio=inicio,
        periodo_fim=fim,
        moeda=moeda_normalizada,
        instituicoes=_normalizar_instituicoes(instituicoes),
        tela_inicial=tela,
    )


def executar_pipeline(
    cd_cli: int,
    periodo_inicio: str | date,
    periodo_fim: str | date,
    *,
    moeda: str | None = None,
    instituicoes: Iterable[int] | None = None,
    tela_inicial: str = "jornada_dinheiro",
    env_path: str | Path = "desenv.env",
    cliente_db2: Any | None = None,
) -> dict[str, Any]:
    """Executa o pipeline analítico completo sem construir HTML.

    Esta é a mesma rota usada pela experiência visual e pelo notebook de
    validação. O retorno inclui artefatos técnicos internos (DataFrames e o
    objeto de consulta) para inspeção local. O módulo ``validacoes`` nunca os
    imprime ou exporta sem sanitização.
    """
    config = carregar_configuracao(env_path)
    consulta = criar_consulta(
        cd_cli=cd_cli,
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
        moeda=moeda or config.moeda_padrao,
        instituicoes=instituicoes,
        tela_inicial=tela_inicial,
    )
    carga = carregar_dados(consulta, config, cliente_db2=cliente_db2)
    payload = montar_painel(
        frames=carga["frames"],
        consulta=consulta,
        fontes=carga["fontes"],
    )
    return {
        "consulta_obj": consulta,
        "frames": carga["frames"],
        "fontes": carga["fontes"],
        "payload": payload,
        "integracao_db2": carga.get("integracao_db2", {}),
        "config_publica": {
            "moeda_padrao": config.moeda_padrao,
            "incluir_plotly_offline": config.incluir_plotly_offline,
            "chunksize_db2": config.chunksize_db2,
            "modo_credencial": config.db2_credential_mode,
            "database": config.db2_database,
            "credenciais_ambiente_configuradas": bool(config.db2_user and config.db2_pass),
        },
    }


def fluxo_dashboard(
    cd_cli: int,
    periodo_inicio: str | date,
    periodo_fim: str | date,
    *,
    moeda: str | None = None,
    instituicoes: Iterable[int] | None = None,
    tela_inicial: str = "jornada_dinheiro",
    exibir: bool = True,
    env_path: str | Path = "desenv.env",
    cliente_db2: Any | None = None,
) -> dict[str, Any]:
    """Consulta, analisa e renderiza um snapshot financeiro integrado.

    Todos os motores usam exatamente o mesmo cliente, período e moeda. O
    argumento ``cliente_db2`` existe para testes e para reutilização explícita
    de uma conexão já criada no notebook.
    """
    pipeline = executar_pipeline(
        cd_cli=cd_cli,
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
        moeda=moeda,
        instituicoes=instituicoes,
        tela_inicial=tela_inicial,
        env_path=env_path,
        cliente_db2=cliente_db2,
    )
    payload = pipeline["payload"]
    config_publica = pipeline["config_publica"]
    html = render_dashboard(payload, include_plotly=config_publica["incluir_plotly_offline"])
    resultado = {
        **payload,
        "consulta": pipeline["consulta_obj"].to_public_dict(),
        "html": html,
    }
    if exibir:
        display(HTML(html))
    return resultado


def exportar_html(resultado: dict[str, Any], caminho: str | Path) -> Path:
    destino = Path(caminho)
    destino.parent.mkdir(parents=True, exist_ok=True)
    html = resultado.get("html")
    if not isinstance(html, str) or not html.strip():
        raise ValueError("resultado não contém HTML renderizado.")
    destino.write_text(html, encoding="utf-8")
    return destino


__all__ = [
    "TELAS_VALIDAS", "criar_consulta", "executar_pipeline",
    "fluxo_dashboard", "exportar_html",
]
