"""Regras financeiras e analíticas versionadas.

O módulo contém decisões puras. Ele não conhece banco, HTML ou conexão.
Pontuações são sinais técnicos auditáveis, não notas de saúde financeira.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
import re
from typing import Any

VERSAO_REGRAS_CIRCULACAO = "circulacao-2.0"
VERSAO_REGRAS_ANALISE = "jornada-financeira-2.0"
VERSAO_REGRAS_RADAR = "radar-integrado-3.0"
VERSAO_MACROCLASSIFICACAO = "macroclassificacao-0-9-1.0"
VERSAO_REFERENCIAS = "referencias-1.0"
DATA_CORTE_PERFIL_RENDA = "2025-01-01"
PERIODO_MAXIMO_CONSULTA_DIAS = 548

# Circulação: regras heurísticas em validação, sem significado probabilístico.
JANELA_PAREAMENTO_DIAS = 3
TOLERANCIA_VALOR_CENTAVOS = 0
LIMIAR_EVIDENCIA_FORTE = 16
LIMIAR_EVIDENCIA_MODERADA = 12
PENALIDADE_AMBIGUIDADE = 3

PESOS_EVIDENCIAS_CIRCULACAO = {
    "VALOR_EXATO": 4,
    "MESMA_MOEDA": 1,
    "NATUREZAS_OPOSTAS": 3,
    "MESMO_DIA": 3,
    "UM_DIA_DIFERENCA": 2,
    "DOIS_OU_TRES_DIAS": 1,
    "CONTAS_DIFERENTES": 2,
    "INSTITUICOES_DIFERENTES": 1,
    "DESCRICAO_COMPATIVEL": 2,
    "CONTRAPARTE_CONTA_COMPATIVEL": 5,
    "CONTRAPARTE_TITULAR_COMPATIVEL": 5,
    "ROTA_RECORRENTE": 2,
    "DESCRICAO_CONFLITANTE": -4,
}

TERMOS_CIRCULACAO = (
    "PIX", "TED", "DOC", "TRANSFERENCIA", "TRANSF", "ENTRE CONTAS",
    "APLICACAO", "RESGATE", "ENVIO", "RECEBIMENTO", "MOVIMENTACAO",
)
TERMOS_CONFLITANTES = (
    "SALARIO", "PROVENTO", "COMPRA CARTAO", "PAGAMENTO FATURA", "BOLETO",
    "DEBITO AUTOMATICO", "TARIFA", "JUROS", "ALUGUEL", "SUPERMERCADO",
)

BLOCOS = {
    0: {"nome_tecnico": "Transferência / entrada indefinida", "nome_comunicacao": "Entradas e transferências a identificar", "natureza": "C"},
    1: {"nome_tecnico": "Receita / rendimento / benefício", "nome_comunicacao": "Renda e benefícios recebidos", "natureza": "C"},
    2: {"nome_tecnico": "Restituição / estorno / reembolso / ajuste", "nome_comunicacao": "Dinheiro devolvido ou ajustado", "natureza": "C"},
    3: {"nome_tecnico": "Resgate de investimento", "nome_comunicacao": "Dinheiro retirado de investimentos", "natureza": "C"},
    4: {"nome_tecnico": "Crédito tomado / liberação de crédito", "nome_comunicacao": "Empréstimos e financiamentos recebidos", "natureza": "C"},
    5: {"nome_tecnico": "Neutro / não classificado", "nome_comunicacao": "Saídas e transferências a identificar", "natureza": "D"},
    6: {"nome_tecnico": "Essenciais", "nome_comunicacao": "Contas e gastos necessários", "natureza": "D"},
    7: {"nome_tecnico": "Flexíveis", "nome_comunicacao": "Gastos que podem ser ajustados", "natureza": "D"},
    8: {"nome_tecnico": "Futuro", "nome_comunicacao": "Dinheiro destinado ao futuro", "natureza": "D"},
    9: {"nome_tecnico": "Dívidas / crédito / custo financeiro", "nome_comunicacao": "Dívidas, parcelas, juros e taxas", "natureza": "D"},
}

CODIGOS_CREDITO = {
    "Transferência / entrada indefinida": 0,
    "Receita / rendimento / benefício": 1,
    "Restituição / estorno / reembolso / ajuste": 2,
    "Resgate de investimento": 3,
    "Crédito tomado / liberação de crédito": 4,
}
CODIGOS_DEBITO = {
    "Neutro / não classificado": 5,
    "Essenciais": 6,
    "Flexíveis": 7,
    "Futuro": 8,
    "Dívidas / crédito / custo financeiro": 9,
}

BASE_CLASSIFICACAO = [(0, 0, 'Sem categoria', 'Transferência / entrada indefinida', 'Neutro / não classificado', 'N'), (0, 83, 'Sem categoria', 'Transferência / entrada indefinida', 'Neutro / não classificado', 'N'), (1, 1, 'Salário', 'Receita / rendimento / benefício', 'Neutro / não classificado', 'N'), (1, 2, 'Vale Alimentação', 'Receita / rendimento / benefício', 'Neutro / não classificado', 'N'), (1, 3, 'Restituição de IR', 'Restituição / estorno / reembolso / ajuste', 'Neutro / não classificado', 'N'), (1, 4, 'Bonificação', 'Receita / rendimento / benefício', 'Neutro / não classificado', 'N'), (1, 5, 'Outros Rendimentos', 'Receita / rendimento / benefício', 'Neutro / não classificado', 'N'), (2, 6, 'Água', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (2, 7, 'Eletricidade e Gás', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (2, 9, 'Compra de Imóvel', 'Crédito tomado / liberação de crédito', 'Dívidas / crédito / custo financeiro', 'N'), (2, 10, 'Aluguel e Condomínio', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (2, 11, 'Móveis e Utensílios', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (2, 12, 'Serviços e Manutenção', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (2, 13, 'Empregados', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (2, 14, 'Animais e Pets', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (2, 3790, 'Seguro Residencial', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (3, 15, 'Educação Superior', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (3, 16, 'Colégio', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (3, 17, 'Idiomas', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (3, 18, 'Publicações e Papelaria', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (3, 20, 'Outros Gastos', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (4, 21, 'Viagens e Lazer', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (4, 22, 'Esportes e Academia', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (4, 25, 'Cultura e Entretenimento', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (4, 26, 'Publicações Digitais', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (4, 61, 'Jogos e Loterias', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (5, 27, 'Plano de Saúde', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (5, 28, 'Serviços de Saúde', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (5, 29, 'Dentista', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (5, 30, 'Farmácias e Drogarias', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (6, 32, 'Feira e Supermercado', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (6, 35, 'Bar', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (7, 36, 'Compra de Veículo', 'Crédito tomado / liberação de crédito', 'Dívidas / crédito / custo financeiro', 'N'), (7, 37, 'Combustível', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (7, 38, 'Estacionamento e Pedágio', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (7, 39, 'Seguro de Veículo', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (7, 40, 'Serviços e Manutenção', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (7, 41, 'Transporte Urbano e Apps', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (8, 42, 'Vestuário e Acessórios', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (8, 43, 'Cuidado Pessoal e Beleza', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (8, 44, 'Compras Diversas', 'Restituição / estorno / reembolso / ajuste', 'Neutro / não classificado', 'N'), (8, 45, 'Pensão Alimentícia', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (8, 46, 'Seguros e Previdência', 'Restituição / estorno / reembolso / ajuste', 'Neutro / não classificado', 'N'), (8, 47, 'Doação', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (8, 48, 'Gasto com Familiares', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (8, 49, 'Presentes', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (8, 60, 'Serviços diversos', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (8, 4417, 'Empréstimos e Prestações', 'Crédito tomado / liberação de crédito', 'Dívidas / crédito / custo financeiro', 'N'), (9, 51, 'Telefonia e Internet', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (9, 53, 'Assinatura TV e Streaming', 'Restituição / estorno / reembolso / ajuste', 'Flexíveis', 'N'), (10, 54, 'IPTU', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (10, 55, 'IPVA e Gastos Detran', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (10, 56, 'Imposto de Renda', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (10, 57, 'ISS(Imposto sobre Serviços)', 'Restituição / estorno / reembolso / ajuste', 'Essenciais', 'N'), (10, 58, 'GPS(Guia de Previdência Social)', 'Restituição / estorno / reembolso / ajuste', 'Futuro', 'N'), (10, 59, 'Serviços Financeiros', 'Restituição / estorno / reembolso / ajuste', 'Dívidas / crédito / custo financeiro', 'N'), (10, 3787, 'IOF', 'Restituição / estorno / reembolso / ajuste', 'Dívidas / crédito / custo financeiro', 'N'), (10, 3788, 'Encargos e Tarifas', 'Restituição / estorno / reembolso / ajuste', 'Dívidas / crédito / custo financeiro', 'N'), (11, 279, 'Gastos Diversos', 'Transferência / entrada indefinida', 'Neutro / não classificado', 'N'), (11, 39434, 'Cheque', 'Transferência / entrada indefinida', 'Neutro / não classificado', 'N'), (11, 39435, 'Saque', 'Transferência / entrada indefinida', 'Neutro / não classificado', 'N'), (11, 39436, 'Transferência', 'Transferência / entrada indefinida', 'Neutro / não classificado', 'N'), (11, 39437, 'Boletos Diversos', 'Restituição / estorno / reembolso / ajuste', 'Neutro / não classificado', 'N'), (12, 111, 'Cartão de Crédito', 'Restituição / estorno / reembolso / ajuste', 'Dívidas / crédito / custo financeiro', 'N'), (13, 448977, 'Aplicação', 'Restituição / estorno / reembolso / ajuste', 'Futuro', 'N'), (13, 448978, 'Resgate de Investimentos', 'Resgate de investimento', 'Neutro / não classificado', 'N'), (14, 300, 'Receitas Agro', 'Receita / rendimento / benefício', 'Neutro / não classificado', 'S'), (14, 310, 'Criações', 'Receita / rendimento / benefício', 'Neutro / não classificado', 'S'), (14, 330, 'Cultivos', 'Receita / rendimento / benefício', 'Neutro / não classificado', 'S'), (14, 350, 'Insumos', 'Restituição / estorno / reembolso / ajuste', 'Neutro / não classificado', 'S'), (14, 370, 'Apoio Produtivo', 'Restituição / estorno / reembolso / ajuste', 'Neutro / não classificado', 'S')]

MAPA_CLASSIFICACAO: dict[tuple[int, str], dict[str, Any]] = {}
for grupo, categoria, nome, classe_credito, classe_debito, fl_agro in BASE_CLASSIFICACAO:
    for natureza, classe_nome, codigos in (
        ("C", classe_credito, CODIGOS_CREDITO),
        ("D", classe_debito, CODIGOS_DEBITO),
    ):
        codigo = codigos[classe_nome]
        MAPA_CLASSIFICACAO[(int(categoria), natureza)] = {
            "codigo": codigo,
            "nome_tecnico": classe_nome,
            "nome_comunicacao": BLOCOS[codigo]["nome_comunicacao"],
            "grupo_catalogo": int(grupo),
            "categoria_catalogo": nome,
            "agro": fl_agro == "S",
        }

CATEGORIAS_AGRO = frozenset(
    categoria for _, categoria, _, _, _, fl_agro in BASE_CLASSIFICACAO if fl_agro == "S"
)

PERFIS_RENDA = {
    2502: ("SEM PERFIL", "SEM_PERFIL"),
    2012: ("PF A", "CLASSIFICADA"),
    2112: ("PF B", "CLASSIFICADA"),
    2602: ("PF C", "CLASSIFICADA"),
    2702: ("PF D", "CLASSIFICADA"),
    2712: ("PF E", "CLASSIFICADA"),
    1111: ("A CLASSIFICAR", "A_CLASSIFICAR"),
}
MACROPERFIS = {1: "Endividado", 2: "Equilibrista", 3: "Investidor"}
MICROPERFIS = {
    1: "Inadimplente", 2: "Acrobata", 3: "Iminente", 4: "Consciente",
    5: "Equilibrista", 6: "Acelerado", 7: "Precavido", 8: "Despreocupado",
}

REFERENCIAS_RADAR = {
    "cobertura_classificacao": Decimal("0.75"),
    "gastos_necessarios": Decimal("0.50"),
    "gastos_ajustaveis": Decimal("0.30"),
    "destinacao_futuro": Decimal("0.20"),
    "credito_custos": Decimal("0.30"),
}

SINAIS_SEGMENTACAO = {
    "gastos_necessarios": {
        (1, 2): 2, (1, 1): 1, (2, 5): 1, (3, 7): 1, (3, 8): 1, (3, 6): 1,
    },
    "gastos_ajustaveis": {(1, 4): 2, (1, 3): 1},
    "destinacao_futuro": {
        (1, 4): 1, (2, 5): 2, (3, 7): 2, (3, 8): 2, (3, 6): 2,
    },
    "credito_custos": {(1, 2): 1, (1, 3): 2, (1, 1): 2},
}

TEMAS = {
    "cobertura_classificacao": {
        "nome": "Cobertura de classificação das saídas",
        "nome_origem": "Categorização de Gastos",
        "bloco": 5,
        "componentes": ("composicao",),
    },
    "gastos_necessarios": {
        "nome": "Gastos necessários e equilíbrio do período",
        "nome_origem": "Gestão de Orçamento",
        "bloco": 6,
        "componentes": ("composicao", "fluxo", "segmentacao"),
    },
    "gastos_ajustaveis": {
        "nome": "Gastos ajustáveis observados",
        "nome_origem": "Consumo Planejado",
        "bloco": 7,
        "componentes": ("composicao", "fluxo", "segmentacao"),
    },
    "destinacao_futuro": {
        "nome": "Destinação observada ao futuro",
        "nome_origem": "Formação de Reserva",
        "bloco": 8,
        "componentes": ("composicao", "fluxo", "segmentacao"),
    },
    "credito_custos": {
        "nome": "Crédito e custos financeiros observados",
        "nome_origem": "Uso Consciente do Crédito",
        "bloco": 9,
        "componentes": ("composicao", "fluxo", "segmentacao"),
    },
}

REGISTRO_REGRAS = {
    "CIRC_001": {
        "nome": "Pareamento por valor, moeda, natureza, conta e proximidade temporal",
        "objetivo": "Encontrar circulação provável entre contas observadas sem afirmar titularidade.",
        "estado": "EM_VALIDACAO",
        "versao": VERSAO_REGRAS_CIRCULACAO,
        "impacto_falha": "Pode superestimar entradas e saídas externas.",
    },
    "CIRC_002": {
        "nome": "Resolução conservadora de conflitos",
        "objetivo": "Não escolher silenciosamente entre pares igualmente plausíveis.",
        "estado": "EM_VALIDACAO",
        "versao": VERSAO_REGRAS_CIRCULACAO,
        "impacto_falha": "Pode atribuir a mesma movimentação a mais de uma rota.",
    },
    "ANL_001": {
        "nome": "Período global único",
        "objetivo": "Garantir que todas as telas descrevam o mesmo recorte temporal.",
        "estado": "APROVADA",
        "versao": VERSAO_REGRAS_ANALISE,
        "impacto_falha": "Resultados não comparáveis dentro do painel.",
    },
    "RAD_001": {
        "nome": "Sinais temáticos independentes",
        "objetivo": "Organizar sinais por tema sem produzir nota global ou diagnóstico.",
        "estado": "APROVADA",
        "versao": VERSAO_REGRAS_RADAR,
        "impacto_falha": "Interpretação indevida como avaliação de saúde financeira.",
    },
}


@dataclass(frozen=True)
class Percentual:
    valor: Decimal | None
    estado: str
    motivo: str | None = None


def percentual_seguro(numerador: Decimal, denominador: Decimal) -> Percentual:
    if denominador == 0:
        return Percentual(None, "NAO_CALCULAVEL", "DENOMINADOR_ZERO")
    return Percentual(numerador / denominador, "CALCULADO")


def normalizar_texto_regra(valor: Any) -> str:
    import unicodedata
    texto = str(valor or "").upper().strip()
    texto = "".join(c for c in unicodedata.normalize("NFKD", texto) if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", texto)


def classificar_movimento(categoria_original: Any, natureza: Any) -> dict[str, Any]:
    natureza_normalizada = str(natureza or "").strip().upper()
    if natureza_normalizada not in {"C", "D"}:
        return {
            "codigo": None, "nome_tecnico": None,
            "nome_comunicacao": "Natureza não reconhecida", "agro": False,
            "estado_mapeamento": "NATUREZA_NAO_RECONHECIDA",
        }
    try:
        categoria = int(categoria_original)
    except (TypeError, ValueError):
        categoria = None
    regra = MAPA_CLASSIFICACAO.get((categoria, natureza_normalizada)) if categoria is not None else None
    if regra:
        return {**regra, "estado_mapeamento": "MAPEADA"}
    fallback = 0 if natureza_normalizada == "C" else 5
    return {
        "codigo": fallback,
        "nome_tecnico": BLOCOS[fallback]["nome_tecnico"],
        "nome_comunicacao": BLOCOS[fallback]["nome_comunicacao"],
        "agro": False,
        "estado_mapeamento": "FALLBACK_CATEGORIA_NAO_MAPEADA",
    }


def mapear_perfil_renda(codigo: Any) -> dict[str, Any]:
    try:
        codigo_int = int(codigo)
    except (TypeError, ValueError):
        return {"codigo": None, "nome": None, "estado": "NAO_ENCONTRADA"}
    nome, estado = PERFIS_RENDA.get(codigo_int, ("A CLASSIFICAR", "A_CLASSIFICAR"))
    return {"codigo": codigo_int, "nome": nome, "estado": estado}


def mapear_perfil_financeiro(macro: Any, micro: Any) -> dict[str, Any]:
    try:
        macro_int, micro_int = int(macro), int(micro)
    except (TypeError, ValueError):
        return {
            "codigo_macro": None, "nome_macro": None, "codigo_micro": None,
            "nome_micro": None, "codigo_unificado": None, "nome_unificado": None,
            "estado": "NAO_ENCONTRADA",
        }
    nome_macro = MACROPERFIS.get(macro_int)
    nome_micro = MICROPERFIS.get(micro_int)
    estado = "CLASSIFICADA" if nome_macro and nome_micro else "A_CLASSIFICAR"
    return {
        "codigo_macro": macro_int, "nome_macro": nome_macro,
        "codigo_micro": micro_int, "nome_micro": nome_micro,
        "codigo_unificado": macro_int * 10 + micro_int if estado == "CLASSIFICADA" else None,
        "nome_unificado": f"{nome_macro} {nome_micro}" if estado == "CLASSIFICADA" else None,
        "estado": estado,
    }


def classificar_relacao_fluxo(entradas: Decimal, saidas: Decimal) -> dict[str, Any]:
    diferenca = entradas - saidas
    if entradas == 0 and saidas == 0:
        return {
            "estado_calculo": "SEM_MOVIMENTACAO_NO_PERIODO", "diferenca": diferenca,
            "razao": None, "codigo_faixa": None,
            "nome_faixa": "Sem movimentação no período",
            "direcao_origem": None, "intensidade_origem": None,
        }
    if entradas == 0:
        return {
            "estado_calculo": "SAIDAS_SEM_ENTRADAS_OBSERVADAS", "diferenca": diferenca,
            "razao": None, "codigo_faixa": None,
            "nome_faixa": "Saídas sem entradas observadas",
            "direcao_origem": None, "intensidade_origem": None,
        }
    razao = saidas / entradas
    if razao < Decimal("0.75"):
        codigo, nome, direcao, intensidade = "ENTRADAS_BEM_ACIMA", "Entradas bem acima das saídas", "Superavitário", "Forte"
    elif razao < Decimal("0.95"):
        codigo, nome, direcao, intensidade = "ENTRADAS_ACIMA", "Entradas acima das saídas", "Superavitário", "Fraco"
    elif razao < Decimal("1.00"):
        codigo, nome, direcao, intensidade = "PROXIMO_EQ_ENTRADAS", "Próximo do equilíbrio, com entradas acima", "Neutro", "Fraco"
    elif razao <= Decimal("1.05"):
        codigo, nome, direcao, intensidade = "PROXIMO_EQ_SAIDAS", "Próximo do equilíbrio, com saídas acima", "Neutro", "Forte"
    elif razao <= Decimal("1.25"):
        codigo, nome, direcao, intensidade = "SAIDAS_ACIMA", "Saídas acima das entradas", "Deficitário", "Fraco"
    else:
        codigo, nome, direcao, intensidade = "SAIDAS_BEM_ACIMA", "Saídas bem acima das entradas", "Deficitário", "Forte"
    return {
        "estado_calculo": "CALCULADO", "diferenca": diferenca, "razao": razao,
        "codigo_faixa": codigo, "nome_faixa": nome,
        "direcao_origem": direcao, "intensidade_origem": intensidade,
    }


def sinal_composicao(tema: str, percentual: Decimal | None) -> dict[str, Any]:
    if percentual is None:
        return {"nivel": None, "estado": "NAO_CALCULAVEL", "motivo": "DENOMINADOR_ZERO"}
    referencia = REFERENCIAS_RADAR[tema]
    if tema == "cobertura_classificacao":
        # Quanto menor a cobertura, maior o sinal técnico de necessidade de esclarecimento.
        nivel = 0 if percentual >= referencia else 1 if percentual >= Decimal("0.50") else 2
    elif tema == "destinacao_futuro":
        nivel = 0 if percentual >= referencia * Decimal("1.5") else 1 if percentual >= referencia else 2
    else:
        nivel = 0 if percentual < referencia else 1 if percentual < referencia * Decimal("1.5") else 2
    return {"nivel": nivel, "estado": "CALCULADO"}


def sinal_fluxo(tema: str, fluxo: dict[str, Any]) -> dict[str, Any]:
    if fluxo["estado_calculo"] != "CALCULADO":
        return {"nivel": None, "estado": "NAO_CALCULAVEL", "motivo": fluxo["estado_calculo"]}
    direcao = fluxo["direcao_origem"]
    intensidade = fluxo["intensidade_origem"]
    if tema == "destinacao_futuro":
        nivel = 2 if (direcao, intensidade) == ("Superavitário", "Forte") else 1 if direcao in {"Superavitário", "Neutro"} else 0
    else:
        nivel = 2 if (direcao, intensidade) == ("Deficitário", "Forte") else 1 if direcao in {"Deficitário", "Neutro"} else 0
    return {"nivel": nivel, "estado": "CALCULADO"}


def sinal_segmentacao(tema: str, perfil: dict[str, Any]) -> dict[str, Any]:
    if perfil.get("estado") != "CLASSIFICADA":
        return {"nivel": None, "estado": "INDISPONIVEL", "motivo": "SEGMENTACAO_NAO_CLASSIFICADA"}
    par = (perfil["codigo_macro"], perfil["codigo_micro"])
    nivel = SINAIS_SEGMENTACAO.get(tema, {}).get(par, 0)
    return {"nivel": nivel, "estado": "CALCULADO"}


def classificar_evidencia(indice: int) -> str:
    if indice >= LIMIAR_EVIDENCIA_FORTE:
        return "CANDIDATO_FORTE"
    if indice >= LIMIAR_EVIDENCIA_MODERADA:
        return "CANDIDATO_MODERADO"
    return "CANDIDATO_FRACO"


__all__ = [
    "VERSAO_REGRAS_CIRCULACAO", "VERSAO_REGRAS_ANALISE", "VERSAO_REGRAS_RADAR",
    "VERSAO_MACROCLASSIFICACAO", "VERSAO_REFERENCIAS", "DATA_CORTE_PERFIL_RENDA",
    "PERIODO_MAXIMO_CONSULTA_DIAS", "JANELA_PAREAMENTO_DIAS",
    "TOLERANCIA_VALOR_CENTAVOS", "LIMIAR_EVIDENCIA_FORTE",
    "LIMIAR_EVIDENCIA_MODERADA", "PENALIDADE_AMBIGUIDADE",
    "PESOS_EVIDENCIAS_CIRCULACAO", "TERMOS_CIRCULACAO", "TERMOS_CONFLITANTES",
    "BLOCOS", "BASE_CLASSIFICACAO", "MAPA_CLASSIFICACAO", "CATEGORIAS_AGRO",
    "REFERENCIAS_RADAR", "TEMAS", "REGISTRO_REGRAS", "percentual_seguro",
    "normalizar_texto_regra", "classificar_movimento", "mapear_perfil_renda",
    "mapear_perfil_financeiro", "classificar_relacao_fluxo", "sinal_composicao",
    "sinal_fluxo", "sinal_segmentacao", "classificar_evidencia",
]


# ---------------------------------------------------------------------------
# Jornada financeira: qualidade, origem de renda, principalidade e pós-fluxo
# ---------------------------------------------------------------------------
VERSAO_REGRAS_QUALIDADE = "qualidade-movimentacoes-1.0"
VERSAO_REGRAS_RENDA = "origem-renda-1.0"
VERSAO_REGRAS_JORNADA = "jornada-dinheiro-1.0"

# Duplicidade: somente sinais fortes e não ambíguos podem ser neutralizados na
# leitura estimada. A base observada nunca é alterada.
JANELA_DUPLICIDADE_MINUTOS = 5

# Fontes de renda e salário provável. Os limites são heurísticas versionadas,
# não probabilidades nem comprovação de vínculo empregatício.
MIN_MESES_RECORRENCIA = 3
MIN_COBERTURA_MESES_RECORRENCIA = Decimal("0.50")
MAX_DISPERSAO_DIA_SALARIO = 5
MAX_CV_VALOR_SALARIO_FORTE = Decimal("0.25")
MAX_CV_VALOR_SALARIO_MODERADO = Decimal("0.45")
LIMIAR_SALARIO_FORTE = 13
LIMIAR_SALARIO_MODERADO = 9
LIMIAR_RENDA_RECORRENTE = 6

PESOS_EVIDENCIAS_RENDA = {
    "ORIGEM_EXTERNA_SEM_PAR_INTERNO": 2,
    "ORIGEM_IDENTIFICAVEL": 2,
    "RECORRENCIA_MENSAL": 4,
    "DIAS_CONCENTRADOS": 3,
    "VALOR_ESTAVEL_FORTE": 3,
    "VALOR_ESTAVEL_MODERADO": 1,
    "DESCRICAO_COMPATIVEL_SALARIO": 5,
    "CATEGORIA_RECEBIDA_COMPATIVEL": 2,
    "CONTA_RECEPTORA_CONSISTENTE": 1,
    "MESES_INSUFICIENTES": -3,
    "DESCRICAO_CREDITO_CONTRATADO": -7,
    "DESCRICAO_RESGATE": -7,
    "DESCRICAO_DEVOLUCAO_AJUSTE": -5,
    "AMBIGUIDADE_ORIGEM": -2,
}

TERMOS_SALARIO = (
    "SALARIO", "PROVENTO", "FOLHA", "PAGAMENTO FUNCIONARIO",
    "REMUNERACAO", "VENCIMENTO", "HOLERITE", "BENEFICIO INSS",
)
TERMOS_RENDA = (
    "SALARIO", "PROVENTO", "REMUNERACAO", "BENEFICIO", "APOSENTADORIA",
    "PENSAO", "HONORARIO", "COMISSAO", "ALUGUEL RECEBIDO", "DIVIDENDO",
)
TERMOS_CREDITO_CONTRATADO = (
    "EMPRESTIMO", "FINANCIAMENTO", "CREDITO PESSOAL", "LIBERACAO CREDITO",
    "ANTECIPACAO", "CREDITO CONSIGNADO",
)
TERMOS_RESGATE = ("RESGATE", "LIQUIDACAO INVESTIMENTO", "VENCIMENTO APLICACAO")
TERMOS_DEVOLUCAO_AJUSTE = (
    "ESTORNO", "DEVOLUCAO", "REEMBOLSO", "RESTITUICAO", "AJUSTE",
    "CASHBACK",
)

JANELAS_POS_RECEBIMENTO_DIAS = (0, 3, 7, 15)
JANELA_DISTRIBUICAO_DIAS = 3
LIMIAR_CONTA_PASSAGEM = Decimal("0.60")
LIMIAR_PAPEL_RELEVANTE = Decimal("0.35")

PAPEIS_BANCARIOS = {
    "RECEBIMENTO_RENDA": "Recebimento de renda",
    "DISTRIBUICAO": "Distribuição entre contas",
    "OPERACIONAL": "Pagamentos e uso cotidiano",
    "RESERVA_INVESTIMENTO": "Reserva e investimento",
    "CREDITO": "Crédito e custos financeiros",
    "PASSAGEM": "Conta de passagem",
    "OCASIONAL": "Uso ocasional",
}

TIPOS_ENTRADA_ANALITICA = {
    "ENTRADA_EXTERNA_PROVAVEL": "Entrada externa provável",
    "SALARIO_PROVAVEL": "Salário provável",
    "RENDA_RECORRENTE_PROVAVEL": "Renda recorrente provável",
    "MOVIMENTACAO_INTERNA_PROVAVEL": "Movimentação interna provável",
    "CREDITO_CONTRATADO_PROVAVEL": "Crédito contratado provável",
    "RESGATE_INVESTIMENTO_PROVAVEL": "Resgate de investimento provável",
    "DEVOLUCAO_AJUSTE_PROVAVEL": "Devolução ou ajuste provável",
    "DUPLICIDADE_PROVAVEL": "Duplicidade provável",
    "ENTRADA_INCONCLUSIVA": "Entrada inconclusiva",
}

REGISTRO_REGRAS_JORNADA = {
    "QUAL_DUP_001": {
        "nome": "Duplicidade física",
        "objetivo": "Evitar contar duas vezes a mesma chave física na leitura estimada.",
        "estado": "EM_VALIDACAO",
        "versao": VERSAO_REGRAS_QUALIDADE,
    },
    "QUAL_DUP_002": {
        "nome": "Duplicidade econômica forte",
        "objetivo": "Sinalizar eventos praticamente idênticos na mesma conta e instante.",
        "estado": "EM_VALIDACAO",
        "versao": VERSAO_REGRAS_QUALIDADE,
    },
    "RENDA_001": {
        "nome": "Fonte recorrente",
        "objetivo": "Agrupar entradas externas candidatas por assinatura protegida de origem.",
        "estado": "EM_VALIDACAO",
        "versao": VERSAO_REGRAS_RENDA,
    },
    "RENDA_002": {
        "nome": "Salário provável",
        "objetivo": "Identificar recorrência mensal, estabilidade de valor e concentração de dias.",
        "estado": "EM_VALIDACAO",
        "versao": VERSAO_REGRAS_RENDA,
    },
    "JORNADA_001": {
        "nome": "Principalidade por papel",
        "objetivo": "Explicar funções distintas das instituições sem forçar um único banco principal.",
        "estado": "EM_VALIDACAO",
        "versao": VERSAO_REGRAS_JORNADA,
    },
    "JORNADA_002": {
        "nome": "Movimentações após recebimento",
        "objetivo": "Descrever o que foi observado depois de uma entrada recorrente sem afirmar causalidade.",
        "estado": "EM_VALIDACAO",
        "versao": VERSAO_REGRAS_JORNADA,
    },
}
