"""Principalidade por papel bancário e jornada após recebimentos prováveis."""
from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from typing import Any

import pandas as pd

from .modelos import ConsultaPainel
from .regras import (
    JANELA_DISTRIBUICAO_DIAS,
    JANELAS_POS_RECEBIMENTO_DIAS,
    LIMIAR_CONTA_PASSAGEM,
    LIMIAR_PAPEL_RELEVANTE,
    PAPEIS_BANCARIOS,
    VERSAO_REGRAS_JORNADA,
)


def _texto(valor: Any) -> str:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return ""
    return str(valor).strip()


def _soma(base: pd.DataFrame, filtro: pd.Series) -> int:
    if base.empty:
        return 0
    return int(base.loc[filtro, "valor_centavos"].sum())


def _indice_pares(pares: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    por_saida: dict[str, dict[str, Any]] = {}
    por_entrada: dict[str, dict[str, Any]] = {}
    for par in pares:
        if not par.get("usado_estimativa"):
            continue
        por_saida[str(par.get("id_saida"))] = par
        por_entrada[str(par.get("id_entrada"))] = par
    return por_saida, por_entrada


def _recebimentos_referencia(renda: dict[str, Any]) -> list[dict[str, Any]]:
    principal = renda.get("fonte_principal")
    entradas = renda.get("entradas", [])
    if principal:
        fonte_id = principal.get("fonte_id")
        selecionadas = [x for x in entradas if x.get("fonte_id") == fonte_id]
        if selecionadas:
            return selecionadas
    recorrentes = [
        x for x in entradas
        if x.get("tipo_analitico") in {"SALARIO_PROVAVEL", "RENDA_RECORRENTE_PROVAVEL"}
    ]
    return recorrentes


def calcular_papeis_bancarios(
    base: pd.DataFrame,
    renda: dict[str, Any],
    pares: list[dict[str, Any]],
) -> dict[str, Any]:
    if base.empty:
        return {"instituicoes": [], "principalidade": {"estado": "SEM_DADOS"}}

    entradas_lookup = {str(x["id_movimento"]): x for x in renda.get("entradas", [])}
    por_saida, por_entrada = _indice_pares(pares)
    instituicoes = sorted(base["instituicao_rotulo"].dropna().astype(str).unique().tolist())

    total_externo = sum(
        int(base.loc[base["id_movimento"].astype(str).eq(mid), "valor_centavos"].sum())
        for mid, item in entradas_lookup.items()
        if item.get("tipo_analitico") in {"ENTRADA_EXTERNA_PROVAVEL", "SALARIO_PROVAVEL", "RENDA_RECORRENTE_PROVAVEL"}
    )
    total_salario = sum(
        int(base.loc[base["id_movimento"].astype(str).eq(mid), "valor_centavos"].sum())
        for mid, item in entradas_lookup.items() if item.get("tipo_analitico") == "SALARIO_PROVAVEL"
    )
    total_debitos_externos = _soma(
        base,
        base["natureza"].eq("D") & ~base["id_movimento"].astype(str).isin(set(por_saida)),
    )
    total_interno_saida = sum(int(par.get("valor_centavos") or round(float(par.get("valor", 0)) * 100)) for par in por_saida.values())
    total_futuro = _soma(base, base["natureza"].eq("D") & base["macroclasse_codigo"].eq(8))
    total_credito = _soma(base, base["macroclasse_codigo"].isin([4, 9]))

    saida: list[dict[str, Any]] = []
    for inst in instituicoes:
        inst_base = base[base["instituicao_rotulo"].astype(str).eq(inst)]
        ids_inst = set(inst_base["id_movimento"].astype(str))
        externos = sum(
            int(base.loc[base["id_movimento"].astype(str).eq(mid), "valor_centavos"].sum())
            for mid, item in entradas_lookup.items()
            if mid in ids_inst and item.get("tipo_analitico") in {"ENTRADA_EXTERNA_PROVAVEL", "SALARIO_PROVAVEL", "RENDA_RECORRENTE_PROVAVEL"}
        )
        salario = sum(
            int(base.loc[base["id_movimento"].astype(str).eq(mid), "valor_centavos"].sum())
            for mid, item in entradas_lookup.items()
            if mid in ids_inst and item.get("tipo_analitico") == "SALARIO_PROVAVEL"
        )
        internos_saida = sum(
            int(par.get("valor_centavos") or round(float(par.get("valor", 0)) * 100))
            for mid, par in por_saida.items() if mid in ids_inst
        )
        internos_entrada = sum(
            int(par.get("valor_centavos") or round(float(par.get("valor", 0)) * 100))
            for mid, par in por_entrada.items() if mid in ids_inst
        )
        debitos_externos = int(inst_base.loc[
            inst_base["natureza"].eq("D") & ~inst_base["id_movimento"].astype(str).isin(set(por_saida)),
            "valor_centavos",
        ].sum())
        futuro = int(inst_base.loc[inst_base["natureza"].eq("D") & inst_base["macroclasse_codigo"].eq(8), "valor_centavos"].sum())
        credito = int(inst_base.loc[inst_base["macroclasse_codigo"].isin([4, 9]), "valor_centavos"].sum())
        dias_ativos = int(pd.to_datetime(inst_base["data"], errors="coerce").dt.date.nunique())

        share_recebimento = externos / total_externo if total_externo else 0.0
        share_salario = salario / total_salario if total_salario else 0.0
        share_operacional = debitos_externos / total_debitos_externos if total_debitos_externos else 0.0
        share_distribuicao = internos_saida / total_interno_saida if total_interno_saida else 0.0
        share_reserva = futuro / total_futuro if total_futuro else 0.0
        share_credito = credito / total_credito if total_credito else 0.0
        taxa_passagem = internos_saida / externos if externos else 0.0

        scores = {
            "RECEBIMENTO_RENDA": 0.7 * share_recebimento + 0.3 * share_salario,
            "DISTRIBUICAO": share_distribuicao,
            "OPERACIONAL": share_operacional,
            "RESERVA_INVESTIMENTO": share_reserva,
            "CREDITO": share_credito,
            "PASSAGEM": min(1.0, taxa_passagem) if Decimal(str(taxa_passagem)) >= LIMIAR_CONTA_PASSAGEM else 0.0,
            "OCASIONAL": 1.0 if dias_ativos <= 2 and len(inst_base) <= 5 else 0.0,
        }
        papel = max(scores, key=scores.get) if scores else "OCASIONAL"
        evidencias = []
        for codigo, valor in scores.items():
            if valor >= float(LIMIAR_PAPEL_RELEVANTE) or codigo == papel:
                evidencias.append({
                    "papel": codigo,
                    "nome": PAPEIS_BANCARIOS[codigo],
                    "indice_relativo": round(valor, 4),
                })
        saida.append({
            "instituicao": inst,
            "papel_predominante": papel,
            "papel_predominante_nome": PAPEIS_BANCARIOS[papel],
            "papeis_relevantes": sorted(evidencias, key=lambda x: -x["indice_relativo"]),
            "entradas_externas": externos / 100,
            "salario_provavel": salario / 100,
            "transferido_para_outras_contas": internos_saida / 100,
            "recebido_de_outras_contas": internos_entrada / 100,
            "saidas_externas": debitos_externos / 100,
            "destinacao_futuro": futuro / 100,
            "credito_e_custos": credito / 100,
            "taxa_passagem": round(taxa_passagem * 100, 2) if externos else None,
            "movimentacoes": int(len(inst_base)),
            "dias_ativos": dias_ativos,
            "evidencias": {
                "participacao_recebimento_externo": round(share_recebimento * 100, 2),
                "participacao_salario": round(share_salario * 100, 2),
                "participacao_saidas_operacionais": round(share_operacional * 100, 2),
                "participacao_distribuicao": round(share_distribuicao * 100, 2),
            },
            "limitacao": "O papel é relativo ao período e às instituições observadas; não representa relacionamento bancário total.",
        })

    saida.sort(key=lambda x: (-x["entradas_externas"], -x["saidas_externas"], x["instituicao"]))
    top_por_papel: dict[str, dict[str, Any]] = {}
    for papel in PAPEIS_BANCARIOS:
        melhor = max(
            saida,
            key=lambda x: next((e["indice_relativo"] for e in x["papeis_relevantes"] if e["papel"] == papel), 0.0),
            default=None,
        )
        if melhor:
            indice = next((e["indice_relativo"] for e in melhor["papeis_relevantes"] if e["papel"] == papel), 0.0)
            if indice > 0:
                top_por_papel[papel] = {
                    "instituicao": melhor["instituicao"],
                    "indice_relativo": indice,
                    "papel_nome": PAPEIS_BANCARIOS[papel],
                }

    contagem_top: dict[str, int] = defaultdict(int)
    for papel in ("RECEBIMENTO_RENDA", "DISTRIBUICAO", "OPERACIONAL"):
        if papel in top_por_papel and top_por_papel[papel]["indice_relativo"] >= float(LIMIAR_PAPEL_RELEVANTE):
            contagem_top[top_por_papel[papel]["instituicao"]] += 1
    central = max(contagem_top, key=contagem_top.get) if contagem_top and max(contagem_top.values()) >= 2 else None
    principalidade = {
        "estado": "INSTITUICAO_CENTRAL_PROVAVEL" if central else "PRINCIPALIDADE_DISTRIBUIDA",
        "instituicao_central": central,
        "quantidade_papeis_centrais": contagem_top.get(central, 0) if central else 0,
        "top_por_papel": top_por_papel,
        "explicacao": (
            "Uma instituição domina pelo menos dois papéis relevantes."
            if central else
            "Papéis de recebimento, distribuição e uso estão distribuídos entre instituições."
        ),
    }
    return {"instituicoes": saida, "principalidade": principalidade}


def calcular_ciclos_pos_recebimento(
    base: pd.DataFrame,
    renda: dict[str, Any],
    pares: list[dict[str, Any]],
    consulta: ConsultaPainel,
) -> dict[str, Any]:
    eventos = _recebimentos_referencia(renda)
    if not eventos:
        return {
            "eventos": [], "resumo_janelas": [],
            "estado": "SEM_RECEBIMENTO_RECORRENTE_IDENTIFICADO",
            "limitacao": "Sem fonte recorrente suficiente, não foram formados ciclos de recebimento.",
        }
    por_saida, _ = _indice_pares(pares)
    base_datas = base.copy()
    base_datas["data"] = pd.to_datetime(base_datas["data"], errors="coerce")
    eventos_ord = sorted(eventos, key=lambda x: (x.get("data") or "", x.get("id_movimento") or ""))
    ciclos: list[dict[str, Any]] = []
    agregado_janelas: dict[int, dict[str, int]] = {
        d: {"transferencias_internas": 0, "gastos_necessarios": 0, "gastos_ajustaveis": 0,
            "destinacao_futuro": 0, "credito_custos": 0, "saidas_a_identificar": 0,
            "saidas_total": 0}
        for d in JANELAS_POS_RECEBIMENTO_DIAS
    }
    for i, evento in enumerate(eventos_ord):
        data_evento = pd.to_datetime(evento.get("data"), errors="coerce")
        if pd.isna(data_evento):
            continue
        proxima = pd.to_datetime(eventos_ord[i + 1].get("data"), errors="coerce") if i + 1 < len(eventos_ord) else pd.NaT
        fim_ciclo = (proxima - pd.Timedelta(days=1)) if not pd.isna(proxima) else pd.Timestamp(consulta.periodo_fim)
        fim_ciclo = min(fim_ciclo, pd.Timestamp(consulta.periodo_fim))
        conta = evento.get("conta")
        inst = evento.get("instituicao")
        id_evento = str(evento.get("id_movimento"))
        linha_evento = base_datas[base_datas["id_movimento"].astype(str).eq(id_evento)]
        conta_id = str(linha_evento.iloc[0]["conta_id"]) if not linha_evento.empty else None

        # Acompanha também contas alcançadas por transferências internas fortes
        # nos primeiros dias do ciclo. Isso permite observar o uso posterior
        # sem afirmar que a entrada financiou causalmente cada saída.
        contas_acompanhadas: set[str] = {conta_id} if conta_id else set()
        cadeia_transferencias: list[dict[str, Any]] = []
        limite_distribuicao = min(
            data_evento + pd.Timedelta(days=JANELA_DISTRIBUICAO_DIAS), fim_ciclo
        )
        for par in pares:
            if not par.get("usado_estimativa"):
                continue
            linha_saida = base_datas[base_datas["id_movimento"].astype(str).eq(str(par.get("id_saida")))]
            linha_entrada = base_datas[base_datas["id_movimento"].astype(str).eq(str(par.get("id_entrada")))]
            if linha_saida.empty or linha_entrada.empty:
                continue
            data_saida_par = pd.to_datetime(linha_saida.iloc[0]["data"], errors="coerce")
            conta_saida = str(linha_saida.iloc[0]["conta_id"])
            conta_destino = str(linha_entrada.iloc[0]["conta_id"])
            if (
                conta_id and conta_saida == conta_id and not pd.isna(data_saida_par)
                and data_evento <= data_saida_par <= limite_distribuicao
            ):
                contas_acompanhadas.add(conta_destino)
                cadeia_transferencias.append({
                    "id_par": par.get("id_par"),
                    "conta_origem": par.get("conta_origem"),
                    "conta_destino": par.get("conta_destino"),
                    "valor": float(par.get("valor") or 0),
                    "data": data_saida_par.date().isoformat(),
                    "estado": par.get("estado_motor"),
                })

        janela_dados: list[dict[str, Any]] = []
        for dias in JANELAS_POS_RECEBIMENTO_DIAS:
            limite = min(data_evento + pd.Timedelta(days=dias), fim_ciclo)
            recorte = base_datas[
                (base_datas["data"] >= data_evento)
                & (base_datas["data"] <= limite)
                & (base_datas["natureza"].eq("D"))
            ].copy()
            if contas_acompanhadas:
                recorte_conta = recorte[recorte["conta_id"].astype(str).isin(contas_acompanhadas)]
            else:
                recorte_conta = recorte
            ids = set(recorte_conta["id_movimento"].astype(str))
            interno = sum(
                int(par.get("valor_centavos") or round(float(par.get("valor", 0)) * 100))
                for mid, par in por_saida.items() if mid in ids
            )
            externos = recorte_conta[~recorte_conta["id_movimento"].astype(str).isin(set(por_saida))]
            necessario = int(externos.loc[externos["macroclasse_codigo"].eq(6), "valor_centavos"].sum())
            ajustavel = int(externos.loc[externos["macroclasse_codigo"].eq(7), "valor_centavos"].sum())
            futuro = int(externos.loc[externos["macroclasse_codigo"].eq(8), "valor_centavos"].sum())
            credito = int(externos.loc[externos["macroclasse_codigo"].eq(9), "valor_centavos"].sum())
            identificar = int(externos.loc[externos["macroclasse_codigo"].eq(5), "valor_centavos"].sum())
            total = interno + int(externos["valor_centavos"].sum())
            valores = {
                "transferencias_internas": interno,
                "gastos_necessarios": necessario,
                "gastos_ajustaveis": ajustavel,
                "destinacao_futuro": futuro,
                "credito_custos": credito,
                "saidas_a_identificar": identificar,
                "saidas_total": total,
            }
            for chave, valor in valores.items():
                agregado_janelas[dias][chave] += valor
            janela_dados.append({
                "dias": dias,
                **{k: v / 100 for k, v in valores.items()},
                "movimentos": recorte_conta["id_movimento"].astype(str).tolist(),
                "caracter": "MOVIMENTACOES_OBSERVADAS_APOS_RECEBIMENTO_NA_CONTA_RECEPTORA",
            })
        ciclo_recorte = base_datas[
            (base_datas["data"] >= data_evento)
            & (base_datas["data"] <= fim_ciclo)
            & (base_datas["natureza"].eq("D"))
        ]
        ciclos.append({
            "id_evento": id_evento,
            "data_recebimento": data_evento.date().isoformat(),
            "valor_recebido": float(evento.get("valor") or 0),
            "fonte_id": evento.get("fonte_id"),
            "instituicao_receptora": inst,
            "conta_receptora": conta,
            "fim_ciclo": fim_ciclo.date().isoformat(),
            "duracao_dias": int((fim_ciclo.date() - data_evento.date()).days + 1),
            "janelas": janela_dados,
            "contas_acompanhadas": sorted(contas_acompanhadas),
            "cadeia_transferencias": cadeia_transferencias,
            "movimentacoes_periodo_ciclo": int(len(ciclo_recorte)),
            "limitacao": (
                "A sequência temporal não comprova que o recebimento financiou cada saída; "
                "o dinheiro é fungível e a tela mostra somente movimentos posteriores observados."
            ),
        })

    resumo_janelas = [
        {"dias": dias, **{k: v / 100 for k, v in valores.items()}}
        for dias, valores in sorted(agregado_janelas.items())
    ]
    return {
        "eventos": ciclos,
        "resumo_janelas": resumo_janelas,
        "estado": "CALCULADO" if ciclos else "SEM_EVENTOS_VALIDOS",
        "regra": "Janelas cumulativas após recebimentos recorrentes prováveis, limitadas ao próximo recebimento ou ao fim do período.",
        "limitacao": "Não há atribuição causal entre entrada e gasto.",
    }


def construir_cadeia_dinheiro(
    renda: dict[str, Any],
    papeis: dict[str, Any],
    pares: list[dict[str, Any]],
) -> dict[str, Any]:
    nos: list[dict[str, Any]] = []
    ligacoes: list[dict[str, Any]] = []
    fontes = renda.get("fontes", [])
    for fonte in fontes[:10]:
        nos.append({"id": fonte["fonte_id"], "rotulo": fonte.get("rotulo", "Fonte"), "tipo": "FONTE"})
        inst = fonte.get("instituicao_receptora")
        if inst:
            nos.append({"id": f"INST::{inst}", "rotulo": inst, "tipo": "INSTITUICAO"})
            ligacoes.append({
                "origem": fonte["fonte_id"], "destino": f"INST::{inst}",
                "valor": fonte.get("valor_total", 0), "estado": fonte.get("classificacao"),
                "prova": "AGRUPAMENTO_DE_ENTRADAS_EXTERNAS_CANDIDATAS",
            })
    for par in pares:
        if not par.get("selecionado_motor") or par.get("estado_motor") not in {"CANDIDATO_FORTE", "CANDIDATO_MODERADO"}:
            continue
        origem = f"INST::{par.get('instituicao_origem')}"
        destino = f"INST::{par.get('instituicao_destino')}"
        nos.extend([
            {"id": origem, "rotulo": par.get("instituicao_origem"), "tipo": "INSTITUICAO"},
            {"id": destino, "rotulo": par.get("instituicao_destino"), "tipo": "INSTITUICAO"},
        ])
        ligacoes.append({
            "origem": origem, "destino": destino, "valor": float(par.get("valor") or 0),
            "estado": par.get("estado_motor"), "prova": "PAR_DE_CIRCULACAO_CANDIDATO",
        })
    unicos = {n["id"]: n for n in nos}
    return {
        "nos": list(unicos.values()),
        "ligacoes": ligacoes,
        "caracter": "MAPA_ESTIMADO_E_AUDITAVEL",
        "limitacao": "Ligações automáticas são hipóteses e não confirmação de titularidade ou causalidade.",
    }


def executar_estudo_jornada(
    base: pd.DataFrame,
    renda: dict[str, Any],
    pares: list[dict[str, Any]],
    consulta: ConsultaPainel,
) -> dict[str, Any]:
    papeis = calcular_papeis_bancarios(base, renda, pares)
    ciclos = calcular_ciclos_pos_recebimento(base, renda, pares, consulta)
    cadeia = construir_cadeia_dinheiro(renda, papeis, pares)
    return {
        "papeis_bancarios": papeis,
        "ciclos_pos_recebimento": ciclos,
        "cadeia_dinheiro": cadeia,
        "versao_regra": VERSAO_REGRAS_JORNADA,
    }


__all__ = [
    "calcular_papeis_bancarios", "calcular_ciclos_pos_recebimento",
    "construir_cadeia_dinheiro", "executar_estudo_jornada",
]
