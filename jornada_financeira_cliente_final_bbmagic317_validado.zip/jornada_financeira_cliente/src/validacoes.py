"""Validações sanitizadas de ambiente, Db2, fontes, SQL e execução analítica.

O identificador restrito do cliente é usado apenas em memória e como parâmetro
separado de ``Db2.query``. Ele não pode aparecer em prints, DataFrames,
arquivos exportados, nomes de arquivo ou mensagens públicas de erro.
"""
from __future__ import annotations

import ast
from contextlib import redirect_stdout
from datetime import datetime
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import sys
import time
from typing import Any, Iterable
from uuid import uuid4
import zipfile

import pandas as pd
from IPython.display import display

from .app import criar_consulta, executar_pipeline
from .config import carregar_configuracao
from .dados import (
    capacidades_bbmagic,
    criar_cliente_db2,
    executar_select,
    contar_marcadores_sql,
    montar_sql_categorias,
    montar_sql_complementos_conta,
    montar_sql_contas,
    montar_sql_grupos,
    montar_sql_perfil_financeiro,
    montar_sql_perfil_renda,
    montar_sql_transacoes,
    validar_sql_parametrizado,
    versao_bbmagic,
)
from .fontes import COLUNAS_POR_FONTE, FONTES, TIPOS_CRITICOS_POR_FONTE
from .regras import (
    BLOCOS,
    MAPA_CLASSIFICACAO,
    REGISTRO_REGRAS,
    REGISTRO_REGRAS_JORNADA,
    VERSAO_MACROCLASSIFICACAO,
    VERSAO_REGRAS_ANALISE,
    VERSAO_REGRAS_CIRCULACAO,
    VERSAO_REGRAS_JORNADA,
    VERSAO_REGRAS_QUALIDADE,
    VERSAO_REGRAS_RENDA,
)


COLUNAS_RESTRITAS = {
    "CD_CLI", "CD_CLI_TITR_CT", "CLIENTE", "CLIENTE_CODIGO", "CPF", "CNPJ",
    "CD_CPF_CNPJ_TITR", "NR_CPF_CNPJ_PGDR", "DOCUMENTO", "CONTRAPARTE_DOCUMENTO",
    "CONTA_NUMERO_NORMALIZADO", "CONTA_IDENTIFICADOR_EXTERNO", "PARTICAO",
    "NUMERO_TRANSACAO", "ID_EVENTO_FISICO",
}


def _id_execucao() -> str:
    return uuid4().hex[:12]


def _segredo(valor: Any) -> str:
    texto = str(valor).strip()
    if not texto or not texto.isdigit():
        raise ValueError("Identificador restrito inválido.")
    return texto


def _substituir_segredo(texto: str, segredo: str) -> str:
    if segredo:
        texto = texto.replace(segredo, "[IDENTIFICADOR_RESTRITO_REMOVIDO]")
    return texto


def _coluna_restrita(nome: Any) -> bool:
    valor = str(nome).upper()
    return valor in COLUNAS_RESTRITAS or any(
        trecho in valor for trecho in ("CPF", "CNPJ", "CD_CLI", "DOCUMENTO")
    )


def _sanitizar(objeto: Any, segredo: str) -> Any:
    if isinstance(objeto, pd.DataFrame):
        frame = objeto.copy()
        frame = frame.drop(
            columns=[coluna for coluna in frame.columns if _coluna_restrita(coluna)],
            errors="ignore",
        )
        for coluna in frame.columns:
            if frame[coluna].dtype == object:
                frame[coluna] = frame[coluna].map(
                    lambda valor: _substituir_segredo(str(valor), segredo)
                    if valor is not None else valor
                )
        return frame
    if isinstance(objeto, dict):
        return {
            str(chave): _sanitizar(valor, segredo)
            for chave, valor in objeto.items()
            if not _coluna_restrita(chave)
        }
    if isinstance(objeto, (list, tuple, set)):
        return [_sanitizar(valor, segredo) for valor in objeto]
    if isinstance(objeto, str):
        return _substituir_segredo(objeto, segredo)
    if isinstance(objeto, (pd.Timestamp, datetime)):
        return objeto.isoformat()
    if hasattr(objeto, "item"):
        try:
            return objeto.item()
        except Exception:
            pass
    return objeto


def _json_seguro(objeto: Any) -> Any:
    if isinstance(objeto, pd.DataFrame):
        return objeto.to_dict(orient="records")
    if isinstance(objeto, dict):
        return {str(chave): _json_seguro(valor) for chave, valor in objeto.items()}
    if isinstance(objeto, (list, tuple, set)):
        return [_json_seguro(valor) for valor in objeto]
    if isinstance(objeto, (pd.Timestamp, datetime)):
        return objeto.isoformat()
    if not isinstance(objeto, (str, bytes, dict, list, tuple, set)):
        try:
            if pd.isna(objeto):
                return None
        except Exception:
            pass
    if hasattr(objeto, "item"):
        try:
            return objeto.item()
        except Exception:
            pass
    return objeto


def _garantir_sem_segredo(objeto: Any, segredo: str) -> None:
    if not segredo:
        return
    if isinstance(objeto, pd.DataFrame):
        texto = objeto.to_csv(index=False)
    else:
        texto = json.dumps(_json_seguro(objeto), ensure_ascii=False, default=str)
    if segredo in texto:
        raise RuntimeError("A exportação foi bloqueada por conter identificador restrito.")


def _registro(
    status: str,
    codigo: str,
    validacao: str,
    esperado: Any,
    encontrado: Any,
    impacto: str,
    camada: str,
) -> dict[str, Any]:
    return {
        "status": status,
        "codigo": codigo,
        "camada": camada,
        "validacao": validacao,
        "esperado": esperado,
        "encontrado": encontrado,
        "impacto": impacto,
    }


def _estado(registros: Iterable[dict[str, Any]], prefixo: str) -> str:
    itens = list(registros)
    if any(item["status"] == "FAIL" for item in itens):
        return f"{prefixo}_REPROVADO"
    if any(item["status"] == "WARN" for item in itens):
        return f"{prefixo}_APROVADO_COM_RESSALVAS"
    return f"{prefixo}_APROVADO"


def _versao(nome: str) -> str | None:
    try:
        return importlib.metadata.version(nome)
    except importlib.metadata.PackageNotFoundError:
        return None


def _codigo_notebook_compilavel(fonte: str) -> str:
    """Remove somente magias de linha para validar a sintaxe Python das células."""
    linhas = []
    for linha in str(fonte).splitlines():
        if linha.lstrip().startswith(("%", "!")):
            continue
        linhas.append(linha)
    return "\n".join(linhas)


def _validar_codigo_estatico(
    raiz: Path,
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    """Valida contratos de código que não podem depender de uma falha em produção."""
    linhas: list[dict[str, Any]] = []
    registros: list[dict[str, Any]] = []

    for arquivo in sorted((raiz / "src").glob("*.py")):
        texto = arquivo.read_text(encoding="utf-8")
        arvore = ast.parse(texto)

        chamadas_registro = [
            no for no in ast.walk(arvore)
            if isinstance(no, ast.Call)
            and isinstance(no.func, ast.Name)
            and no.func.id == "_registro"
        ]
        invalidas = [
            no.lineno for no in chamadas_registro
            if len(no.args) != 7 or no.keywords
        ]
        aprovado = not invalidas
        linhas.append({
            "arquivo": arquivo.name,
            "validacao": "assinatura_registro",
            "aprovada": aprovado,
            "detalhe": "ok" if aprovado else f"linhas {invalidas}",
        })
        registros.append(_registro(
            "PASS" if aprovado else "FAIL",
            "CODE_REGISTRY_SIGNATURE",
            f"Assinatura de _registro em {arquivo.name}",
            "7 argumentos posicionais",
            "válida" if aprovado else f"linhas {invalidas}",
            "O notebook de validações deve registrar falhas sem quebrar",
            "AMBIENTE",
        ))

        imports_proibidos: list[str] = []
        chamadas_proibidas: list[str] = []
        for no in ast.walk(arvore):
            if isinstance(no, ast.Import):
                for alias in no.names:
                    if alias.name.split(".")[0] in {"ibm_db", "ibm_db_dbi", "sqlalchemy"}:
                        imports_proibidos.append(alias.name)
            elif isinstance(no, ast.ImportFrom):
                modulo = (no.module or "").split(".")[0]
                if modulo in {"ibm_db", "ibm_db_dbi", "sqlalchemy"}:
                    imports_proibidos.append(no.module or modulo)
            elif isinstance(no, ast.Call):
                nome = ""
                if isinstance(no.func, ast.Name):
                    nome = no.func.id
                elif isinstance(no.func, ast.Attribute):
                    nome = no.func.attr
                if nome in {"run_" + "select", "get_cofre_" + "credentials"}:
                    chamadas_proibidas.append(f"{nome}@{no.lineno}")
        modo_alternativo = ("DB2_" + "CREDENTIAL_MODE") in texto
        aprovado_integracao = not imports_proibidos and not chamadas_proibidas and not modo_alternativo
        detalhe_integracao = "; ".join(
            [
                *(f"import {x}" for x in imports_proibidos),
                *chamadas_proibidas,
                *( ["DB2_" + "CREDENTIAL_MODE"] if modo_alternativo else [] ),
            ]
        ) or "ok"
        linhas.append({
            "arquivo": arquivo.name,
            "validacao": "integracao_exclusiva_bbmagic",
            "aprovada": aprovado_integracao,
            "detalhe": detalhe_integracao,
        })
        registros.append(_registro(
            "PASS" if aprovado_integracao else "FAIL",
            "CODE_BBMAGIC_ONLY",
            f"Integração exclusiva bbmagic em {arquivo.name}",
            "sem conexão alternativa, cofre ou " + "run_" + "select",
            detalhe_integracao,
            "Conectividade Db2",
            "AMBIENTE",
        ))

    try:
        import nbformat
        for nome in ("rotina-principal.ipynb", "todas_validacoes.ipynb"):
            caminho = raiz / nome
            notebook = nbformat.read(caminho, as_version=4)
            erros: list[str] = []
            for indice, celula in enumerate(notebook.cells):
                if celula.cell_type != "code":
                    continue
                codigo = _codigo_notebook_compilavel(celula.source)
                if not codigo.strip():
                    continue
                try:
                    compile(codigo, f"{nome}:celula_{indice}", "exec")
                except SyntaxError as exc:
                    erros.append(f"célula {indice}, linha {exc.lineno}")
            aprovado = not erros
            linhas.append({
                "arquivo": nome,
                "validacao": "sintaxe_notebook",
                "aprovada": aprovado,
                "detalhe": "ok" if aprovado else "; ".join(erros),
            })
            registros.append(_registro(
                "PASS" if aprovado else "FAIL",
                "CODE_NOTEBOOK_SYNTAX",
                f"Células Python de {nome}",
                "compiláveis",
                "válidas" if aprovado else "; ".join(erros),
                "Execução inicial no Jupyter",
                "AMBIENTE",
            ))
    except Exception as exc:
        registros.append(_registro(
            "FAIL",
            "CODE_NOTEBOOK_READ",
            "Leitura dos notebooks",
            "válida",
            type(exc).__name__,
            "Execução inicial no Jupyter",
            "AMBIENTE",
        ))

    return pd.DataFrame(linhas), registros


def _validar_ambiente(
    raiz: Path,
    cliente_db2: Any | None,
    config: Any,
) -> tuple[dict[str, pd.DataFrame], list[dict[str, Any]]]:
    registros: list[dict[str, Any]] = []
    pacotes: list[dict[str, Any]] = []
    requeridos = [
        "pandas", "plotly", "python-dotenv", "ipython", "nbformat", "pytest", "bbmagic"
    ]
    for pacote in requeridos:
        versao = _versao(pacote)
        status = "PASS" if versao else "FAIL"
        pacotes.append({"pacote": pacote, "versao": versao, "estado": status})
        registros.append(_registro(
            status,
            f"ENV_PKG_{pacote}",
            f"Pacote {pacote} disponível",
            "instalado",
            versao or "ausente",
            "Execução do projeto",
            "AMBIENTE",
        ))

    versao_bbm = versao_bbmagic()
    registros.append(_registro(
        "PASS" if versao_bbm else "FAIL",
        "ENV_BBMAGIC_VERSION",
        "Versão do bbmagic identificada",
        "3.1.7 ou compatível com Db2.query",
        versao_bbm or "ausente",
        "Integração Db2",
        "AMBIENTE",
    ))

    estrutura: list[dict[str, Any]] = []
    obrigatorios = [
        "src/app.py", "src/analise.py", "src/qualidade.py", "src/circulacao.py",
        "src/renda.py", "src/jornada.py", "src/visual.py", "src/validacoes.py",
        "src/fontes.py", "src/regras.py", "src/dados.py", "src/config.py",
        "rotina-principal.ipynb", "todas_validacoes.ipynb", "requirements.txt",
        "desenv.env",
    ]
    for relativo in obrigatorios:
        existe = (raiz / relativo).exists()
        estrutura.append({"arquivo": relativo, "existe": existe})
        registros.append(_registro(
            "PASS" if existe else "FAIL",
            "ENV_FILE",
            f"Arquivo {relativo}",
            True,
            existe,
            "Estrutura executável",
            "AMBIENTE",
        ))

    sintaxe: list[dict[str, Any]] = []
    for arquivo in sorted((raiz / "src").glob("*.py")):
        try:
            ast.parse(arquivo.read_text(encoding="utf-8"))
            status = "PASS"
            detalhe = "sintaxe válida"
        except SyntaxError as exc:
            status = "FAIL"
            detalhe = f"linha {exc.lineno}"
        sintaxe.append({"arquivo": arquivo.name, "estado": status, "detalhe": detalhe})
        registros.append(_registro(
            status,
            "ENV_AST",
            f"Sintaxe {arquivo.name}",
            "válida",
            detalhe,
            "Importação do módulo",
            "AMBIENTE",
        ))

    credencial_possivel = (
        cliente_db2 is not None
        or bool(config.db2_user and config.db2_pass)
    )
    registros.append(_registro(
        "PASS" if credencial_possivel else "FAIL",
        "ENV_DB2_CRED",
        "DB2_USER e DB2_PASS disponíveis para o Db2 do bbmagic",
        True,
        credencial_possivel,
        "Conectividade",
        "AMBIENTE",
    ))

    capacidades = capacidades_bbmagic(cliente_db2) if cliente_db2 is not None else {}
    for metodo in ("query", "show_tables", "syscolumns", "systabstats"):
        if cliente_db2 is None:
            break
        disponivel = capacidades.get(metodo, False)
        registros.append(_registro(
            "PASS" if disponivel else "FAIL",
            "ENV_BBMAGIC_METHOD",
            f"Método Db2.{metodo} disponível",
            True,
            disponivel,
            "Integração e validação das fontes",
            "AMBIENTE",
        ))

    qualidade_codigo, registros_codigo = _validar_codigo_estatico(raiz)
    registros.extend(registros_codigo)

    ambiente = pd.DataFrame([{
        "python": platform.python_version(),
        "plataforma": platform.platform(),
        "raiz": str(raiz),
        "bbmagic_versao": versao_bbm,
        "modo_credencial": "ENV_BBMAGIC",
        "database": config.db2_database,
        "host_configurado": bool(config.db2_host),
        "chunksize_db2": config.chunksize_db2,
        "credenciais_ambiente_configuradas": bool(config.db2_user and config.db2_pass),
        "cliente_db2_fornecido": cliente_db2 is not None,
    }])
    return {
        "ambiente": ambiente,
        "pacotes": pd.DataFrame(pacotes),
        "estrutura": pd.DataFrame(estrutura),
        "sintaxe": pd.DataFrame(sintaxe),
        "qualidade_codigo": qualidade_codigo,
        "capacidades_bbmagic": pd.DataFrame([
            {"metodo": metodo, "disponivel": disponivel}
            for metodo, disponivel in capacidades.items()
        ]),
    }, registros


def _familia_tipo(tipo: Any) -> str:
    texto = str(tipo or "").upper()
    if any(item in texto for item in ("CHAR", "CLOB", "GRAPHIC")):
        return "CHARACTER"
    if any(item in texto for item in (
        "DECIMAL", "INTEGER", "BIGINT", "SMALLINT", "DOUBLE", "REAL", "NUMERIC"
    )):
        return "NUMERIC"
    if "TIMESTAMP" in texto:
        return "TIMESTAMP"
    if texto == "DATE":
        return "DATE"
    return texto or "DESCONHECIDO"


def _normalizar_colunas(frame: Any) -> pd.DataFrame:
    if not isinstance(frame, pd.DataFrame):
        frame = pd.DataFrame(frame)
    frame = frame.copy()
    frame.columns = [str(coluna).upper() for coluna in frame.columns]
    return frame


def _coluna_existente(frame: pd.DataFrame, opcoes: tuple[str, ...]) -> str | None:
    for opcao in opcoes:
        if opcao in frame.columns:
            return opcao
    return None


def _validar_banco(
    cliente: Any,
    chunksize: int,
) -> tuple[dict[str, pd.DataFrame], list[dict[str, Any]]]:
    registros: list[dict[str, Any]] = []
    capacidades = capacidades_bbmagic(cliente)
    capacidade_df = pd.DataFrame([
        {"metodo": metodo, "disponivel": disponivel}
        for metodo, disponivel in capacidades.items()
    ])
    for metodo in ("query", "show_tables", "syscolumns", "systabstats"):
        disponivel = capacidades.get(metodo, False)
        registros.append(_registro(
            "PASS" if disponivel else "FAIL",
            "DB2_METHOD",
            f"Db2.{metodo}",
            True,
            disponivel,
            "Validação nativa do catálogo",
            "FONTES",
        ))

    inicio = time.perf_counter()
    try:
        teste = executar_select(cliente, "VALUES 1", chunksize=None)
        conexao_ok = not teste.empty
        erro = None
    except Exception as exc:
        conexao_ok = False
        erro = type(exc).__name__
    tempo = round((time.perf_counter() - inicio) * 1000, 2)
    registros.append(_registro(
        "PASS" if conexao_ok else "FAIL",
        "DB2_CONN",
        "Conectividade por Db2.query",
        True,
        conexao_ok,
        erro or "Acesso às fontes",
        "FONTES",
    ))
    conexao = pd.DataFrame([{
        "conectado": conexao_ok,
        "tempo_ms": tempo,
        "erro_tipo": erro,
        "metodo": "Db2.query",
        "chunksize_transacional": chunksize,
    }])
    if not conexao_ok:
        return {
            "conexao": conexao,
            "capacidades_db2": capacidade_df,
            "fontes_ambiente": pd.DataFrame(),
            "contrato_colunas": pd.DataFrame(),
            "estatisticas_tabelas": pd.DataFrame(),
        }, registros

    objetos_por_schema: dict[str, pd.DataFrame] = {}
    for schema in sorted({fonte.schema for fonte in FONTES.values()}):
        try:
            objetos_por_schema[schema] = _normalizar_colunas(cliente.show_tables(schema))
            registros.append(_registro(
                "PASS", "DB2_SCHEMA_OBJECTS", f"Objetos do schema {schema}",
                "acessíveis", len(objetos_por_schema[schema]), "Existência das fontes", "FONTES"
            ))
        except Exception as exc:
            objetos_por_schema[schema] = pd.DataFrame()
            registros.append(_registro(
                "FAIL", "DB2_SCHEMA_OBJECTS", f"Objetos do schema {schema}",
                "acessíveis", type(exc).__name__, "Existência das fontes", "FONTES"
            ))

    fontes_rows: list[dict[str, Any]] = []
    contrato: list[dict[str, Any]] = []
    estatisticas: list[dict[str, Any]] = []

    for chave, fonte in FONTES.items():
        objetos = objetos_por_schema.get(fonte.schema, pd.DataFrame())
        coluna_nome = _coluna_existente(objetos, ("NAME", "TABNAME", "TABLE_NAME"))
        coluna_schema = _coluna_existente(objetos, ("SCHEMA", "TABSCHEMA", "TABLE_SCHEMA"))
        if coluna_nome:
            mascara = objetos[coluna_nome].astype(str).str.upper().eq(fonte.tabela.upper())
            if coluna_schema:
                mascara &= objetos[coluna_schema].astype(str).str.upper().eq(fonte.schema.upper())
            existe = bool(mascara.any())
        else:
            existe = False

        status_fonte = "PASS" if existe else ("FAIL" if fonte.obrigatoria else "WARN")
        registros.append(_registro(
            status_fonte,
            "DB2_TABLE",
            f"Fonte {chave} existe",
            True,
            existe,
            fonte.finalidade,
            "FONTES",
        ))

        meta_colunas = pd.DataFrame()
        erro_colunas = None
        if existe:
            try:
                meta_colunas = _normalizar_colunas(cliente.syscolumns(fonte.schema, fonte.tabela))
            except Exception as exc:
                erro_colunas = type(exc).__name__
                registros.append(_registro(
                    "FAIL" if fonte.obrigatoria else "WARN",
                    "DB2_SYSCOLUMNS",
                    f"Colunas de {chave}",
                    "acessíveis",
                    erro_colunas,
                    "Contrato físico",
                    "FONTES",
                ))

        coluna_colname = _coluna_existente(meta_colunas, ("COLNAME", "NAME", "COLUMN_NAME"))
        coluna_tipo = _coluna_existente(meta_colunas, ("TYPENAME", "TYPE", "DATA_TYPE"))
        mapa_colunas: dict[str, dict[str, Any]] = {}
        if coluna_colname:
            for linha in meta_colunas.to_dict("records"):
                mapa_colunas[str(linha.get(coluna_colname, "")).upper()] = linha

        for coluna in COLUNAS_POR_FONTE[chave]:
            linha = mapa_colunas.get(coluna.upper())
            presente = linha is not None
            esperado_tipo = TIPOS_CRITICOS_POR_FONTE.get(chave, {}).get(coluna)
            encontrado_tipo = _familia_tipo(linha.get(coluna_tipo)) if linha and coluna_tipo else None
            tipo_ok = presente and (
                esperado_tipo is None
                or encontrado_tipo == esperado_tipo
                or (esperado_tipo == "DATE" and encontrado_tipo == "TIMESTAMP")
            )
            contrato.append({
                "fonte": chave,
                "coluna": coluna,
                "presente": presente,
                "tipo_esperado": esperado_tipo,
                "tipo_encontrado": encontrado_tipo,
                "tipo_compativel": tipo_ok if esperado_tipo else None,
            })
            if not presente:
                registros.append(_registro(
                    "FAIL" if fonte.obrigatoria else "WARN",
                    "DB2_COLUMN",
                    f"{chave}.{coluna}",
                    True,
                    False,
                    "Contrato da fonte",
                    "FONTES",
                ))
            elif esperado_tipo and not tipo_ok:
                registros.append(_registro(
                    "FAIL",
                    "DB2_TYPE",
                    f"Tipo {chave}.{coluna}",
                    esperado_tipo,
                    encontrado_tipo,
                    "Conversão e cálculo",
                    "FONTES",
                ))

        estatistica_estado = "NAO_CONSULTADA"
        estatistica_linhas = None
        estatistica_erro = None
        if existe:
            try:
                stats = _normalizar_colunas(cliente.systabstats(fonte.schema, fonte.tabela))
                estatistica_estado = "CARREGADA"
                estatistica_linhas = len(stats)
            except Exception as exc:
                estatistica_estado = "INDISPONIVEL"
                estatistica_erro = type(exc).__name__
                registros.append(_registro(
                    "WARN",
                    "DB2_SYSTABSTATS",
                    f"Metadados estatísticos de {chave}",
                    "acessíveis",
                    estatistica_erro,
                    "Observabilidade da fonte; não bloqueia a consulta",
                    "FONTES",
                ))
        estatisticas.append({
            "fonte": chave,
            "tabela": fonte.nome_completo,
            "estado": estatistica_estado,
            "linhas_metadado": estatistica_linhas,
            "erro_tipo": estatistica_erro,
        })
        fontes_rows.append({
            "fonte": chave,
            "tabela": fonte.nome_completo,
            "existe_no_catalogo": existe,
            "colunas_encontradas": int(len(meta_colunas)),
            "obrigatoria": fonte.obrigatoria,
            "erro_colunas": erro_colunas,
        })

    return {
        "conexao": conexao,
        "capacidades_db2": capacidade_df,
        "fontes_ambiente": pd.DataFrame(fontes_rows),
        "contrato_colunas": pd.DataFrame(contrato),
        "estatisticas_tabelas": pd.DataFrame(estatisticas),
    }, registros


def _validar_sql(consulta: Any) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    comandos = {
        "transacoes": montar_sql_transacoes(consulta),
        "contas": montar_sql_contas(consulta),
        "complementos": montar_sql_complementos_conta(consulta),
        "categorias": montar_sql_categorias(),
        "grupos": montar_sql_grupos(),
        "perfil_renda": montar_sql_perfil_renda(consulta),
        "perfil_financeiro": montar_sql_perfil_financeiro(consulta),
    }
    rows: list[dict[str, Any]] = []
    registros: list[dict[str, Any]] = []
    identificador_texto = str(consulta.cd_cli)
    consultas_cliente = {
        "transacoes", "contas", "complementos", "perfil_renda", "perfil_financeiro"
    }

    for nome, comando in comandos.items():
        sql = str(comando)
        upper = sql.upper()
        try:
            contrato = validar_sql_parametrizado(comando)
            contrato_ok = True
            contrato_detalhe = "válido"
        except Exception as exc:
            contrato = {
                "quantidade_marcadores": contar_marcadores_sql(sql),
                "quantidade_parametros": len(getattr(comando, "params", ())),
            }
            contrato_ok = False
            contrato_detalhe = type(exc).__name__

        checks: dict[str, bool] = {
            "contrato_marcadores_parametros": contrato_ok,
            "sem_select_star": "SELECT *" not in upper,
            "sem_particao_fixa": "NR_PTC BETWEEN" not in upper,
            "identificador_fora_do_sql": identificador_texto not in sql,
            "sem_date_marker_nao_tipado": "DATE(?)" not in upper,
            "sem_time_marker_nao_tipado": "TIME(?)" not in upper,
            "sem_timestamp_marker_nao_tipado": "TIMESTAMP(?)" not in upper,
        }
        if nome in consultas_cliente:
            checks["cliente_parametrizado"] = (
                "CD_CLI = ?" in upper or "CD_CLI_TITR_CT = ?" in upper
            )
            checks["parametros_separados"] = len(getattr(comando, "params", ())) > 0
        if nome in {"transacoes", "complementos"}:
            checks.update({
                "periodo_inicio_parametrizado_tipado": (
                    "DT_TRAN >= CAST(? AS DATE)" in upper
                ),
                "periodo_fim_exclusivo_parametrizado_tipado": (
                    "DT_TRAN < CAST(? AS DATE)" in upper
                ),
                "moeda_parametrizada": "CD_TIP_MOE_CRR = ?" in upper,
            })
        if nome in {"perfil_renda", "perfil_financeiro"}:
            checks["datas_perfil_parametrizadas_tipadas"] = (
                "CAST(? AS DATE)" in upper and "DATE(?)" not in upper
            )

        for check, aprovado in checks.items():
            rows.append({
                "consulta": nome,
                "validacao": check,
                "aprovada": aprovado,
                "quantidade_marcadores": contrato.get("quantidade_marcadores"),
                "quantidade_parametros": contrato.get("quantidade_parametros"),
                "leitura_em_chunks": bool(getattr(comando, "usar_chunks", False)),
                "detalhe_contrato": contrato_detalhe,
            })
            registros.append(_registro(
                "PASS" if aprovado else "FAIL",
                "SQL_SAFE",
                f"{nome}: {check}",
                True,
                aprovado,
                "Segurança, compatibilidade Db2 e desempenho",
                "PIPELINE",
            ))
    return pd.DataFrame(rows), registros

def _perfil_frames(frames: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame]:
    resumo: list[dict[str, Any]] = []
    colunas: list[dict[str, Any]] = []
    for nome, frame in frames.items():
        dataframe = frame if isinstance(frame, pd.DataFrame) else pd.DataFrame()
        resumo.append({
            "fonte": nome,
            "linhas": len(dataframe),
            "colunas": len(dataframe.columns),
            "duplicadas_exatas": int(dataframe.duplicated().sum()) if not dataframe.empty else 0,
        })
        for coluna in dataframe.columns:
            serie = dataframe[coluna]
            colunas.append({
                "fonte": nome,
                "coluna": str(coluna),
                "tipo": str(serie.dtype),
                "nulos": int(serie.isna().sum()),
                "percentual_nulos": round(float(serie.isna().mean() * 100), 2),
                "distintos": int(serie.nunique(dropna=True)),
            })
    return pd.DataFrame(resumo), pd.DataFrame(colunas)


def _tabelas_execucao(
    pipeline: dict[str, Any],
    segredo: str,
    limite: int,
) -> dict[str, pd.DataFrame]:
    payload = _sanitizar(pipeline["payload"], segredo)
    frames = _sanitizar(pipeline["frames"], segredo)
    resumo_frames, qualidade_colunas = _perfil_frames(frames)
    qualidade = payload["evidencias_qualidade"]["qualidade"]
    fontes = pd.DataFrame([{"fonte": chave, **valor} for chave, valor in payload.get("fontes", {}).items()])
    integracao = pd.DataFrame([_sanitizar(pipeline.get("integracao_db2", {}), segredo)])
    duplicidades = pd.DataFrame(qualidade.get("grupos", []))
    pares = pd.DataFrame(payload["circulacao_bancos"].get("pares", []))
    rotas = pd.DataFrame(payload["circulacao_bancos"].get("rotas", []))
    bancos = pd.DataFrame(payload["circulacao_bancos"].get("instituicoes", []))
    fontes_renda = pd.DataFrame(payload["origem_renda"].get("fontes", []))
    entradas = pd.DataFrame(payload["origem_renda"].get("entradas", []))
    janelas = pd.DataFrame(payload["uso_dinheiro"].get("ciclos", {}).get("resumo_janelas", []))
    movimentos = pd.DataFrame(payload.get("movimentacoes", [])).head(limite)
    resumo_exec = pd.DataFrame(payload["jornada_dinheiro"].get("resumo_executivo", []))
    regras = pd.DataFrame([
        {"regra": chave, **valor}
        for chave, valor in {**REGISTRO_REGRAS, **REGISTRO_REGRAS_JORNADA}.items()
    ])
    return {
        "integracao_bbmagic": integracao,
        "carga_fontes": fontes,
        "frames": resumo_frames,
        "qualidade_colunas": qualidade_colunas,
        "duplicidades": duplicidades,
        "pares_circulacao": pares,
        "rotas": rotas,
        "papeis_bancarios": bancos,
        "fontes_renda": fontes_renda,
        "entradas": entradas,
        "janelas_pos_recebimento": janelas,
        "movimentacoes_amostra": movimentos,
        "resumo_executivo": resumo_exec,
        "regras": regras,
    }


def _validar_execucao(pipeline: dict[str, Any]) -> list[dict[str, Any]]:
    payload = pipeline["payload"]
    registros: list[dict[str, Any]] = []
    meta = payload["meta"]
    registros.append(_registro(
        "PASS" if meta["periodo"]["inicio"] and meta["periodo"]["fim"] else "FAIL",
        "RUN_PERIOD", "Período global presente", True, meta["periodo"],
        "Todas as análises", "EXECUCAO",
    ))
    observadas = payload["evidencias_qualidade"]["qualidade"]["resumo"]["movimentacoes_observadas"]
    cobertura = payload["cobertura"]["movimentacoes"]
    registros.append(_registro(
        "PASS" if observadas == cobertura else "FAIL",
        "RUN_GRAIN", "Movimentações reconciliam com cobertura", cobertura, observadas,
        "Integridade", "EXECUCAO",
    ))
    qualidade = payload["evidencias_qualidade"]["qualidade"]["resumo"]
    registros.append(_registro(
        "WARN" if qualidade["duplicidades_provaveis"] else "PASS",
        "RUN_DUP", "Duplicidades prováveis", 0, qualidade["duplicidades_provaveis"],
        "Revisão da base estimada", "EXECUCAO",
    ))
    circulacao = payload["circulacao_bancos"]["resumo"]
    registros.append(_registro(
        "WARN" if circulacao["quantidade_pares_ambiguos"] else "PASS",
        "RUN_CIRC_AMB", "Pares ambíguos", 0, circulacao["quantidade_pares_ambiguos"],
        "Circulação inconclusiva", "EXECUCAO",
    ))
    renda = payload["origem_renda"]["resumo"]
    total_componentes = (
        renda["entradas_externas_estimadas"]
        + renda["circulacao_interna_provavel"]
        + renda["duplicidades_neutralizadas"]
        + renda["entradas_inconclusivas"]
        + renda["outras_entradas_especificas"]
    )
    registros.append(_registro(
        "PASS" if abs(total_componentes - renda["entradas_observadas"]) <= 0.02 else "FAIL",
        "RUN_INCOME_REC", "Componentes das entradas reconciliam",
        renda["entradas_observadas"], round(total_componentes, 2),
        "Origem e renda", "EXECUCAO",
    ))
    principal = payload["origem_renda"].get("fonte_principal")
    registros.append(_registro(
        "INFO" if principal else "WARN",
        "RUN_INCOME_SOURCE", "Fonte recorrente principal", "quando houver evidência",
        principal.get("classificacao") if principal else "não identificada",
        "Leitura de renda", "EXECUCAO",
    ))
    metodo = pipeline.get("integracao_db2", {}).get("metodo_consulta")
    registros.append(_registro(
        "PASS" if metodo == "Db2.query" else "FAIL",
        "RUN_DB2_API", "API de consulta Db2", "Db2.query", metodo or "não informado",
        "Compatibilidade com bbmagic 3.1.7", "EXECUCAO",
    ))
    texto_payload = json.dumps(_json_seguro(payload), ensure_ascii=False).lower()
    registros.append(_registro(
        "PASS" if "cliente_codigo" not in texto_payload else "FAIL",
        "RUN_PRIVACY", "Payload sem identificador do cliente", True, "verificado",
        "Segurança", "EXECUCAO",
    ))
    return registros


def _resumo_texto(relatorio: dict[str, Any]) -> str:
    validacoes = relatorio["tabelas"]["validacoes"]
    contagem = validacoes["status"].value_counts().to_dict() if not validacoes.empty else {}
    linhas = [
        "VALIDAÇÃO DA JORNADA FINANCEIRA",
        f"Execução: {relatorio['id_execucao']}",
        f"Período: {relatorio['contexto']['periodo_inicio']} a {relatorio['contexto']['periodo_fim']}",
        f"Moeda: {relatorio['contexto']['moeda']}",
        "",
    ]
    for chave in ("estado_ambiente", "estado_fontes", "estado_pipeline", "estado_execucao"):
        linhas.append(f"{chave}: {relatorio[chave]}")
    linhas.extend([
        "",
        f"PASS: {contagem.get('PASS', 0)}",
        f"WARN: {contagem.get('WARN', 0)}",
        f"FAIL: {contagem.get('FAIL', 0)}",
        f"INFO: {contagem.get('INFO', 0)}",
    ])
    return "\n".join(linhas)


def exibir_relatorio_validacao(
    relatorio: dict[str, Any],
    *,
    limite_linhas: int = 100,
) -> None:
    print("=" * 72)
    print("VALIDAÇÃO DA JORNADA FINANCEIRA DO CLIENTE")
    print("=" * 72)
    print(f"Execução: {relatorio['id_execucao']}")
    print(f"Período: {relatorio['contexto']['periodo_inicio']} a {relatorio['contexto']['periodo_fim']}")
    print(f"Moeda: {relatorio['contexto']['moeda']}")
    print(f"Ambiente: {relatorio['estado_ambiente']}")
    print(f"Fontes: {relatorio['estado_fontes']}")
    print(f"Pipeline: {relatorio['estado_pipeline']}")
    print(f"Execução: {relatorio['estado_execucao']}")
    for nome, frame in relatorio["tabelas"].items():
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            continue
        print("\n" + "-" * 72)
        print(nome.replace("_", " ").upper())
        print("-" * 72)
        display(frame.head(limite_linhas))
    if relatorio.get("pacote_exportado"):
        print(f"\nPacote sanitizado: {relatorio['pacote_exportado']}")


def exportar_diagnostico(
    relatorio: dict[str, Any],
    *,
    pasta_saida: str | Path = "saida_validacoes",
    segredo: str = "",
) -> Path:
    destino = Path(pasta_saida)
    destino.mkdir(parents=True, exist_ok=True)
    id_execucao = relatorio["id_execucao"]
    pasta = destino / f"validacao_{id_execucao}"
    if pasta.exists():
        for arquivo in pasta.iterdir():
            arquivo.unlink()
    else:
        pasta.mkdir()

    for nome, frame in relatorio["tabelas"].items():
        if isinstance(frame, pd.DataFrame):
            seguro = _sanitizar(frame, segredo)
            _garantir_sem_segredo(seguro, segredo)
            seguro.to_csv(pasta / f"{nome}.csv", index=False, encoding="utf-8")

    resumo = _resumo_texto(relatorio)
    _garantir_sem_segredo(resumo, segredo)
    (pasta / "resumo.txt").write_text(resumo, encoding="utf-8")

    diagnostico = _sanitizar({
        "id_execucao": id_execucao,
        "contexto": relatorio["contexto"],
        "estados": {
            chave: relatorio[chave]
            for chave in ("estado_ambiente", "estado_fontes", "estado_pipeline", "estado_execucao")
        },
    }, segredo)
    _garantir_sem_segredo(diagnostico, segredo)
    (pasta / "diagnostico.json").write_text(
        json.dumps(diagnostico, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    zip_path = destino / f"validacao_{id_execucao}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as arquivo_zip:
        for arquivo in sorted(pasta.iterdir()):
            arquivo_zip.write(arquivo, arquivo.name)
    if segredo.encode() in zip_path.read_bytes():
        zip_path.unlink(missing_ok=True)
        raise RuntimeError("Pacote bloqueado por conter identificador restrito.")
    return zip_path


def executar_todas_validacoes(
    cd_cli: int | str,
    periodo_inicio: str,
    periodo_fim: str,
    *,
    moeda: str | None = None,
    instituicoes: Iterable[int] | None = None,
    env_path: str | Path = "desenv.env",
    cliente_db2: Any | None = None,
    verificar_banco: bool = True,
    exibir: bool = True,
    exportar: bool = True,
    pasta_saida: str | Path = "saida_validacoes",
    limite_amostra: int = 100,
) -> dict[str, Any]:
    segredo = _segredo(cd_cli)
    raiz = Path(__file__).resolve().parents[1]
    config = carregar_configuracao(env_path)
    consulta = criar_consulta(
        cd_cli=int(segredo),
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
        moeda=moeda or config.moeda_padrao,
        instituicoes=instituicoes,
        tela_inicial="jornada_dinheiro",
    )

    tabelas, registros = _validar_ambiente(raiz, cliente_db2, config)
    estado_ambiente = _estado(
        [item for item in registros if item["camada"] == "AMBIENTE"], "AMBIENTE"
    )

    cliente = cliente_db2
    if verificar_banco:
        try:
            cliente = cliente or criar_cliente_db2(config)
            tabelas_banco, registros_banco = _validar_banco(cliente, config.chunksize_db2)
        except Exception as exc:
            tabelas_banco = {
                "conexao": pd.DataFrame([{
                    "conectado": False,
                    "erro_tipo": type(exc).__name__,
                    "metodo": "Db2.query",
                }]),
                "capacidades_db2": pd.DataFrame(),
                "fontes_ambiente": pd.DataFrame(),
                "contrato_colunas": pd.DataFrame(),
                "estatisticas_tabelas": pd.DataFrame(),
            }
            registros_banco = [_registro(
                "FAIL", "DB2_CONN", "Conectividade Db2", True, False,
                type(exc).__name__, "FONTES",
            )]
        tabelas.update(tabelas_banco)
        registros.extend(registros_banco)

    estado_fontes = _estado(
        [item for item in registros if item["camada"] == "FONTES"], "FONTES"
    )
    tabela_sql, registros_sql = _validar_sql(consulta)
    tabelas["seguranca_sql"] = tabela_sql
    registros.extend(registros_sql)

    buffer = io.StringIO()
    try:
        with redirect_stdout(buffer):
            pipeline = executar_pipeline(
                cd_cli=int(segredo),
                periodo_inicio=periodo_inicio,
                periodo_fim=periodo_fim,
                moeda=moeda,
                instituicoes=instituicoes,
                tela_inicial="jornada_dinheiro",
                env_path=env_path,
                cliente_db2=cliente,
            )
        capturado = _substituir_segredo(buffer.getvalue(), segredo)
        if capturado.strip():
            registros.append(_registro(
                "WARN", "PIPE_STDOUT", "Pipeline sem prints", "silêncio",
                "saída capturada e suprimida", "Privacidade", "PIPELINE",
            ))
        tabelas.update(_tabelas_execucao(pipeline, segredo, limite_amostra))
        registros.extend(_validar_execucao(pipeline))
    except Exception as exc:
        pipeline = None
        tabelas["falha_pipeline"] = pd.DataFrame([{
            "etapa": "execucao_pipeline",
            "erro_tipo": type(exc).__name__,
            "mensagem_publica": "O pipeline não foi concluído; consulte as validações anteriores.",
        }])
        registros.append(_registro(
            "FAIL",
            "PIPE_RUN",
            "Execução do pipeline",
            "concluída",
            type(exc).__name__,
            "Pipeline analítico",
            "PIPELINE",
        ))
        registros.append(_registro(
            "FAIL",
            "RUN_NOT_EXECUTED",
            "Execução analítica disponível",
            True,
            False,
            "A execução não pode ser validada porque o pipeline falhou",
            "EXECUCAO",
        ))

    estado_pipeline = _estado(
        [item for item in registros if item["camada"] == "PIPELINE"], "PIPELINE"
    )
    estado_execucao = _estado(
        [item for item in registros if item["camada"] == "EXECUCAO"], "EXECUCAO"
    )
    tabelas["validacoes"] = pd.DataFrame(_sanitizar(registros, segredo))
    relatorio = {
        "id_execucao": _id_execucao(),
        "contexto": {
            "periodo_inicio": periodo_inicio,
            "periodo_fim": periodo_fim,
            "moeda": consulta.moeda,
            "instituicoes": list(consulta.instituicoes),
        },
        "estado_ambiente": estado_ambiente,
        "estado_fontes": estado_fontes,
        "estado_pipeline": estado_pipeline,
        "estado_execucao": estado_execucao,
        "tabelas": _sanitizar(tabelas, segredo),
        "pacote_exportado": None,
    }
    _garantir_sem_segredo(relatorio, segredo)
    if exportar:
        caminho = exportar_diagnostico(
            relatorio, pasta_saida=pasta_saida, segredo=segredo
        )
        relatorio["pacote_exportado"] = str(caminho)
    if exibir:
        exibir_relatorio_validacao(relatorio, limite_linhas=limite_amostra)

    segredo = ""
    return relatorio


__all__ = [
    "executar_todas_validacoes", "exibir_relatorio_validacao", "exportar_diagnostico"
]
