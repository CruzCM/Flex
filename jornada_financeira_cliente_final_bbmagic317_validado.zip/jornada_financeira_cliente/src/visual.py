"""Renderização HTML/Plotly da Jornada Financeira do Cliente no Jupyter."""
from __future__ import annotations

from html import escape
import json
from typing import Any
from uuid import uuid4

import plotly.graph_objects as go
from plotly.io import to_html
from plotly.offline import get_plotlyjs


class Visual:
    @staticmethod
    def aplicar_estilo() -> str:
        return """
<style>
:root{--pf-blue:#0b3b75;--pf-blue2:#15579b;--pf-bg:#f4f7fb;--pf-card:#fff;--pf-text:#172235;--pf-muted:#607086;--pf-line:#dce4ee;--pf-ok:#176b4d;--pf-warn:#9b5c00;--pf-bad:#a53b3b;--pf-soft:#eef4fb}
.pf-root{font-family:Inter,Segoe UI,Arial,sans-serif;color:var(--pf-text);background:var(--pf-bg);padding:18px;border-radius:16px;line-height:1.42}
.pf-header{background:linear-gradient(120deg,var(--pf-blue),var(--pf-blue2));color:#fff;padding:24px;border-radius:14px;box-shadow:0 12px 30px rgba(11,59,117,.18)}
.pf-header h1{font-size:28px;margin:0 0 5px}.pf-header p{margin:0;opacity:.9}.pf-meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:15px}.pf-pill{display:inline-flex;padding:5px 10px;border-radius:999px;background:rgba(255,255,255,.14);font-size:12px}
.pf-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:16px 0}.pf-tab{appearance:none;border:1px solid var(--pf-line);background:#fff;padding:10px 14px;border-radius:10px;font-weight:700;color:var(--pf-blue);cursor:pointer}.pf-tab[aria-selected=true]{background:var(--pf-blue);color:#fff;border-color:var(--pf-blue)}
.pf-panel{display:none}.pf-panel.active{display:block}.pf-section{margin:18px 0}.pf-section h2{font-size:21px;margin:0 0 5px}.pf-section-intro{color:var(--pf-muted);margin:0 0 12px}
.pf-grid{display:grid;gap:12px}.pf-grid-2{grid-template-columns:repeat(2,minmax(0,1fr))}.pf-grid-3{grid-template-columns:repeat(3,minmax(0,1fr))}.pf-grid-4{grid-template-columns:repeat(4,minmax(0,1fr))}
.pf-card{background:var(--pf-card);border:1px solid var(--pf-line);border-radius:12px;padding:15px;box-shadow:0 4px 14px rgba(23,34,53,.04)}.pf-card h3{margin:6px 0}.pf-card p{margin:6px 0;color:var(--pf-muted)}.pf-value{display:block;font-size:25px;color:var(--pf-blue);margin:6px 0}.pf-card small{color:var(--pf-muted)}
.pf-card.good{border-left:4px solid var(--pf-ok)}.pf-card.warn{border-left:4px solid var(--pf-warn)}.pf-card.bad{border-left:4px solid var(--pf-bad)}
.pf-status{display:inline-block;padding:4px 8px;border-radius:999px;background:#eaf1f8;color:var(--pf-blue);font-size:11px;font-weight:800}.pf-status.good{background:#e9f5ef;color:var(--pf-ok)}.pf-status.warn{background:#fff3df;color:var(--pf-warn)}.pf-status.bad{background:#fdeaea;color:var(--pf-bad)}
.pf-table-wrap{overflow:auto;background:#fff;border:1px solid var(--pf-line);border-radius:12px}.pf-table{width:100%;border-collapse:collapse;font-size:13px}.pf-table th{position:sticky;top:0;background:#edf3f9;color:#32455c;text-align:left;padding:10px;border-bottom:1px solid var(--pf-line)}.pf-table td{padding:9px 10px;border-bottom:1px solid #edf1f5;vertical-align:top}.pf-table tr:hover td{background:#f8fbff}.pf-money{text-align:right;white-space:nowrap}.pf-evidence{padding:10px;border-radius:9px;background:var(--pf-soft);font-size:12px;color:#334760;margin-top:8px}
.pf-details{background:#fff;border:1px solid var(--pf-line);border-radius:12px;margin:9px 0}.pf-details summary{cursor:pointer;padding:13px 15px;font-weight:750;color:var(--pf-blue);list-style:none}.pf-details summary::-webkit-details-marker{display:none}.pf-details summary:after{content:'＋';float:right}.pf-details[open] summary:after{content:'−'}.pf-details-body{padding:0 15px 15px}.pf-trace{display:grid;gap:6px;margin:10px 0}.pf-trace-step{padding:9px 11px;border-left:3px solid var(--pf-blue2);background:#f5f8fc;border-radius:0 8px 8px 0}
.pf-callout{padding:12px 14px;border-radius:10px;background:#fff8e8;border:1px solid #f0d99f;color:#614800}.pf-callout.info{background:#edf5ff;border-color:#bed7f3;color:#244b73}.pf-callout.bad{background:#fff0f0;border-color:#efc0c0;color:#7d2b2b}
.pf-input{width:100%;box-sizing:border-box;padding:9px;border:1px solid var(--pf-line);border-radius:8px;background:#fff}.pf-code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:12px;background:#f3f6f9;border-radius:7px;padding:3px 6px}.pf-kv{display:grid;grid-template-columns:minmax(150px,220px) 1fr;gap:5px 12px;font-size:13px}.pf-kv dt{font-weight:700}.pf-kv dd{margin:0;color:var(--pf-muted)}
@media(max-width:950px){.pf-grid-4,.pf-grid-3{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:650px){.pf-grid-4,.pf-grid-3,.pf-grid-2{grid-template-columns:1fr}.pf-root{padding:10px}.pf-header{padding:17px}.pf-header h1{font-size:23px}}
</style>
"""


def _moeda(valor: Any, codigo: str = "BRL") -> str:
    try:
        numero = float(valor or 0)
    except (TypeError, ValueError):
        return "Não calculável"
    simbolo = "R$" if codigo == "BRL" else codigo
    texto = f"{numero:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"{simbolo} {texto}"


def _pct(valor: Any) -> str:
    if valor is None:
        return "Não calculável"
    try:
        return f"{float(valor):.1f}%".replace(".", ",")
    except (TypeError, ValueError):
        return "Não calculável"


def _plot(fig: go.Figure, ident: str) -> str:
    fig.update_layout(
        template="plotly_white", height=390, margin=dict(l=40, r=25, t=55, b=45),
        font=dict(family="Inter, Segoe UI, Arial", size=12), legend=dict(orientation="h"),
    )
    return to_html(fig, include_plotlyjs=False, full_html=False, div_id=ident, config={"displayModeBar": False, "responsive": True})


def _grafico_cadeia(cadeia: dict[str, Any], ident: str) -> str:
    nos = cadeia.get("nos", [])
    ligacoes = cadeia.get("ligacoes", [])
    if not nos or not ligacoes:
        fig = go.Figure()
        fig.add_annotation(text="Sem cadeia estimada suficiente para exibição.", x=.5, y=.5, showarrow=False)
        return _plot(fig, ident)
    ids = [n["id"] for n in nos]
    labels = [n.get("rotulo") or n["id"] for n in nos]
    indice = {v: i for i, v in enumerate(ids)}
    validas = [x for x in ligacoes if x.get("origem") in indice and x.get("destino") in indice and float(x.get("valor") or 0) > 0]
    fig = go.Figure(go.Sankey(
        arrangement="snap",
        node=dict(label=labels, pad=18, thickness=18, line=dict(width=.5)),
        link=dict(
            source=[indice[x["origem"]] for x in validas],
            target=[indice[x["destino"]] for x in validas],
            value=[float(x["valor"]) for x in validas],
            customdata=[x.get("estado") for x in validas],
            hovertemplate="%{source.label} → %{target.label}<br>Valor: %{value:,.2f}<br>Estado: %{customdata}<extra></extra>",
        ),
    ))
    fig.update_layout(title="Cadeia estimada: fontes → instituições → circulação")
    return _plot(fig, ident)


def _grafico_renda(mensal: list[dict[str, Any]], ident: str) -> str:
    fig = go.Figure()
    meses = [x["mes"] for x in mensal]
    fig.add_bar(x=meses, y=[x["externas_provaveis"] for x in mensal], name="Externas prováveis")
    fig.add_bar(x=meses, y=[x["internas_provaveis"] for x in mensal], name="Circulação interna provável")
    fig.add_scatter(x=meses, y=[x["salario_provavel"] for x in mensal], name="Salário provável", mode="lines+markers")
    fig.update_layout(barmode="stack", title="Composição estimada das entradas por mês")
    return _plot(fig, ident)


def _grafico_bancos(instituicoes: list[dict[str, Any]], ident: str) -> str:
    fig = go.Figure()
    nomes = [x["instituicao"] for x in instituicoes]
    fig.add_bar(x=nomes, y=[x["entradas_externas"] for x in instituicoes], name="Recebimento externo")
    fig.add_bar(x=nomes, y=[x["transferido_para_outras_contas"] for x in instituicoes], name="Distribuição interna")
    fig.add_bar(x=nomes, y=[x["saidas_externas"] for x in instituicoes], name="Uso externo")
    fig.update_layout(barmode="group", title="Papéis observados por instituição")
    return _plot(fig, ident)


def _grafico_janelas(janelas: list[dict[str, Any]], ident: str) -> str:
    fig = go.Figure()
    x = ["Mesmo dia" if i["dias"] == 0 else f"Até {i['dias']} dias" for i in janelas]
    chaves = [
        ("transferencias_internas", "Transferências internas"),
        ("gastos_necessarios", "Gastos necessários"),
        ("gastos_ajustaveis", "Gastos ajustáveis"),
        ("destinacao_futuro", "Futuro"),
        ("credito_custos", "Crédito e custos"),
        ("saidas_a_identificar", "A identificar"),
    ]
    for chave, nome in chaves:
        fig.add_bar(x=x, y=[i.get(chave, 0) for i in janelas], name=nome)
    fig.update_layout(barmode="stack", title="Movimentações cumulativas após recebimentos prováveis")
    return _plot(fig, ident)


def _cards_resumo(payload: dict[str, Any], moeda: str) -> str:
    r = payload["origem_renda"]["resumo"]
    c = payload["circulacao_bancos"]["resumo"]
    itens = [
        ("Entradas observadas", _moeda(r["entradas_observadas"], moeda), "Tudo que chegou como crédito no período.", ""),
        ("Entradas externas prováveis", _moeda(r["entradas_externas_estimadas"], moeda), "Após sinais de duplicidade e circulação.", "good"),
        ("Renda recorrente estimada", _moeda(r["renda_recorrente_estimada"], moeda), "Fontes com recorrência e evidências suficientes.", "good"),
        ("Salário provável", _moeda(r["salario_provavel_estimado"], moeda), "Hipótese técnica, não comprovação de folha.", "warn"),
        ("Circulação interna provável", _moeda(r["circulacao_interna_provavel"], moeda), f"{c['quantidade_pares_fortes']} pares fortes selecionados.", "warn"),
        ("Entradas inconclusivas", _moeda(r["entradas_inconclusivas"], moeda), "Precisam de mais evidências ou contexto.", "warn"),
    ]
    return '<div class="pf-grid pf-grid-3">' + ''.join(
        f'<article class="pf-card {cls}"><small>{escape(t)}</small><strong class="pf-value">{escape(v)}</strong><p>{escape(d)}</p></article>'
        for t, v, d, cls in itens
    ) + '</div>'


def _resumo_executivo(frases: list[dict[str, Any]]) -> str:
    blocos = []
    for f in frases:
        evid = escape(json.dumps(f.get("evidencias", {}), ensure_ascii=False, default=str, indent=2))
        limite = f'<div class="pf-callout">{escape(f["limitacao"])}</div>' if f.get("limitacao") else ''
        blocos.append(f'''
<details class="pf-details"><summary>{escape(f['titulo'])}</summary><div class="pf-details-body">
<p>{escape(f['texto'])}</p><span class="pf-status">{escape(f['tipo'])}</span>
{limite}<div class="pf-evidence"><strong>Regra:</strong> {escape(f['id_regra'])}<pre>{evid}</pre></div>
</div></details>''')
    return ''.join(blocos)


def _fontes_cards(fontes: list[dict[str, Any]], moeda: str) -> str:
    if not fontes:
        return '<div class="pf-callout">Nenhuma fonte externa candidata pôde ser agrupada.</div>'
    saida = []
    for fonte in fontes:
        ev = ''.join(
            f'<li><span class="pf-code">{escape(e["codigo"])}</span> {escape(e["descricao"])} '
            f'<small>(peso {e.get("peso",0)})</small></li>' for e in fonte.get("evidencias", [])
        )
        movimentos = ', '.join(escape(x) for x in fonte.get("movimentos", [])[:30])
        status = 'good' if 'SALARIO' in fonte['classificacao'] else 'warn' if 'INCONCLUSIVA' in fonte['classificacao'] else ''
        saida.append(f'''
<details class="pf-details"><summary>{escape(fonte.get('rotulo','Fonte'))} · {escape(fonte['classificacao'].replace('_',' '))} · {_moeda(fonte['valor_total'], moeda)}</summary>
<div class="pf-details-body"><div class="pf-grid pf-grid-3">
<div><small>Valor típico</small><strong class="pf-value">{_moeda(fonte['valor_tipico'], moeda)}</strong></div>
<div><small>Meses observados</small><strong class="pf-value">{fonte['quantidade_meses']} / {fonte['quantidade_meses_periodo']}</strong></div>
<div><small>Dia mediano</small><strong class="pf-value">{escape(str(fonte.get('dia_mediano') or 'N/D'))}</strong></div>
</div>
<p><span class="pf-status {status}">índice técnico {fonte['pontuacao_tecnica']}</span> Recebida em {escape(fonte['instituicao_receptora'])} · {escape(fonte['conta_receptora'])}.</p>
<dl class="pf-kv"><dt>Descrição representativa</dt><dd>{escape(fonte['descricao_representativa'])}</dd><dt>Variação do valor</dt><dd>{escape(str(fonte.get('coeficiente_variacao')))}</dd><dt>Dispersão dos dias</dt><dd>{escape(str(fonte.get('dispersao_dias')))}</dd><dt>Método de assinatura</dt><dd>{escape(fonte['metodo_assinatura'])}</dd></dl>
<h4>Evidências</h4><ul>{ev}</ul><div class="pf-evidence"><strong>Movimentações:</strong> {movimentos}</div>
<div class="pf-callout">A fonte e o salário são prováveis. O painel não comprova vínculo empregatício, folha ou renda oficial.</div>
</div></details>''')
    return ''.join(saida)


def _tabela_entradas(entradas: list[dict[str, Any]], moeda: str) -> str:
    linhas = []
    for x in entradas:
        coer = x.get("coerencia_categoria_recebida", {})
        linhas.append(f'''<tr>
<td>{escape(str(x.get('data') or 'Sem data'))}<br><small>{escape(x['id_movimento'])}</small></td>
<td class="pf-money">{_moeda(x['valor'], moeda)}</td><td>{escape(x['instituicao'])}<br><small>{escape(x['conta'])}</small></td>
<td>{escape(x['tipo_analitico_nome'])}<br><small>{escape(str(x.get('fonte_classificacao') or ''))}</small></td>
<td>{escape(x['categoria_recebida'])}<br><small>{escape(coer.get('estado','NAO_AVALIADA'))}</small></td>
<td>{escape(x['descricao_protegida'])}</td></tr>''')
    if not linhas:
        linhas = ['<tr><td colspan="6">Nenhuma entrada observada.</td></tr>']
    return '<div class="pf-table-wrap"><table class="pf-table"><thead><tr><th>Data / ID</th><th>Valor</th><th>Conta</th><th>Interpretação analítica</th><th>Categoria recebida</th><th>Descrição</th></tr></thead><tbody>' + ''.join(linhas) + '</tbody></table></div>'


def _bancos_cards(insts: list[dict[str, Any]], moeda: str) -> str:
    if not insts:
        return '<div class="pf-callout">Sem instituições suficientes para calcular papéis.</div>'
    partes=[]
    for x in insts:
        papeis=' · '.join(escape(p['nome']) + f" ({_pct(p['indice_relativo']*100)})" for p in x.get('papeis_relevantes',[]))
        partes.append(f'''<details class="pf-details"><summary>{escape(x['instituicao'])} · {escape(x['papel_predominante_nome'])}</summary><div class="pf-details-body">
<div class="pf-grid pf-grid-3"><div><small>Entradas externas</small><strong class="pf-value">{_moeda(x['entradas_externas'],moeda)}</strong></div><div><small>Distribuído</small><strong class="pf-value">{_moeda(x['transferido_para_outras_contas'],moeda)}</strong></div><div><small>Saídas externas</small><strong class="pf-value">{_moeda(x['saidas_externas'],moeda)}</strong></div></div>
<p>{papeis}</p><div class="pf-evidence">{escape(json.dumps(x['evidencias'],ensure_ascii=False,indent=2))}</div><div class="pf-callout">{escape(x['limitacao'])}</div>
</div></details>''')
    return ''.join(partes)


def _tabela_pares(pares: list[dict[str, Any]], moeda: str) -> str:
    linhas=[]
    for p in pares[:300]:
        ev=', '.join(e['codigo'] for e in p.get('evidencias',[]))
        linhas.append(f'''<tr><td>{escape(p['id_par'])}</td><td>{escape(p['data_saida'])}<br><small>{escape(p['conta_origem'])}</small></td><td>{escape(p['data_entrada'])}<br><small>{escape(p['conta_destino'])}</small></td><td class="pf-money">{_moeda(p['valor'],moeda)}</td><td>{escape(p['estado_motor'].replace('_',' '))}<br><small>índice {p['indice_evidencia']}</small></td><td>{escape(ev)}</td></tr>''')
    if not linhas: linhas=['<tr><td colspan="6">Nenhum par candidato.</td></tr>']
    return '<div class="pf-table-wrap"><table class="pf-table"><thead><tr><th>Par</th><th>Saída</th><th>Entrada</th><th>Valor</th><th>Estado</th><th>Evidências</th></tr></thead><tbody>'+''.join(linhas)+'</tbody></table></div>'


def _ciclos_cards(ciclos: dict[str, Any], moeda: str) -> str:
    eventos=ciclos.get('eventos',[])
    if not eventos: return f'<div class="pf-callout">{escape(ciclos.get("limitacao","Sem ciclos calculados."))}</div>'
    partes=[]
    for c in eventos:
        linhas=[]
        for j in c.get('janelas',[]):
            linhas.append(f'''<tr><td>{'Mesmo dia' if j['dias']==0 else 'Até '+str(j['dias'])+' dias'}</td><td class="pf-money">{_moeda(j['transferencias_internas'],moeda)}</td><td class="pf-money">{_moeda(j['gastos_necessarios'],moeda)}</td><td class="pf-money">{_moeda(j['gastos_ajustaveis'],moeda)}</td><td class="pf-money">{_moeda(j['destinacao_futuro'],moeda)}</td><td class="pf-money">{_moeda(j['credito_custos'],moeda)}</td></tr>''')
        partes.append(f'''<details class="pf-details"><summary>{escape(c['data_recebimento'])} · {_moeda(c['valor_recebido'],moeda)} · {escape(c['instituicao_receptora'])}</summary><div class="pf-details-body"><p>Ciclo até {escape(c['fim_ciclo'])} ({c['duracao_dias']} dias).</p><div class="pf-table-wrap"><table class="pf-table"><thead><tr><th>Janela</th><th>Internas</th><th>Necessários</th><th>Ajustáveis</th><th>Futuro</th><th>Crédito</th></tr></thead><tbody>{''.join(linhas)}</tbody></table></div><div class="pf-callout">{escape(c['limitacao'])}</div></div></details>''')
    return ''.join(partes)


def _qualidade_cards(eq: dict[str, Any], moeda: str) -> str:
    q=eq['qualidade']['resumo']; c=eq['reconciliacao']
    cards=[('Movimentações observadas',str(q['movimentacoes_observadas']),'Base preservada.'),('Neutralizadas por duplicidade',str(q['movimentacoes_neutralizadas']),_moeda(q['valor_neutralizado'],moeda)),('Duplicidades prováveis',str(q['duplicidades_provaveis']),'Sinalizadas, não neutralizadas.'),('Ambiguidades de circulação',str(len(eq.get('ambiguidades_circulacao',[]))),'Não entram na estimativa.')]
    html='<div class="pf-grid pf-grid-4">'+''.join(f'<article class="pf-card"><small>{escape(t)}</small><strong class="pf-value">{escape(v)}</strong><p>{escape(d)}</p></article>' for t,v,d in cards)+'</div>'
    html+=f'<div class="pf-callout info">Diferença observada: {_moeda(c["diferenca_observada"],moeda)} · após duplicidades: {_moeda(c["diferenca_apos_duplicidades"],moeda)} · externa estimada: {_moeda(c["diferenca_externa_estimada"],moeda)}.</div>'
    return html


def _tabela_movimentos(movs: list[dict[str, Any]], moeda: str, uid: str) -> str:
    linhas=[]
    for m in movs[:3000]:
        interp=(m.get('interpretacao_entrada') or {}).get('tipo_analitico_nome','')
        busca=' '.join(str(x or '') for x in [m.get('id_movimento'),m.get('data'),m.get('instituicao'),m.get('conta'),m.get('descricao_protegida'),m.get('categoria_vigente_recebida'),interp]).lower()
        linhas.append(f'''<tr data-mov data-search="{escape(busca,quote=True)}" data-natureza="{escape(str(m.get('natureza') or ''),quote=True)}"><td>{escape(str(m.get('data') or 'Sem data'))}<br><small>{escape(m['id_movimento'])}</small></td><td>{escape(m['natureza'])}</td><td class="pf-money">{_moeda(m['valor'],moeda)}</td><td>{escape(m['instituicao'])}<br><small>{escape(m['conta'])}</small></td><td>{escape(m['categoria_vigente_recebida'])}<br><small>{escape(m['classificacao_0_9_nome'])}</small></td><td>{escape(interp)}</td><td>{escape(m['descricao_protegida'])}</td></tr>''')
    if not linhas: linhas=['<tr><td colspan="7">Sem movimentações.</td></tr>']
    return f'''<div class="pf-grid pf-grid-2"><label><small>Buscar</small><input class="pf-input" data-mov-search placeholder="Descrição, conta, categoria ou ID"></label><label><small>Natureza</small><select class="pf-input" data-mov-natureza><option value="">Todas</option><option value="C">Entradas</option><option value="D">Saídas</option></select></label></div><div class="pf-table-wrap" style="max-height:560px;margin-top:10px"><table class="pf-table"><thead><tr><th>Data / ID</th><th>Natureza</th><th>Valor</th><th>Instituição / conta</th><th>Categoria recebida</th><th>Interpretação</th><th>Descrição</th></tr></thead><tbody>{''.join(linhas)}</tbody></table></div>'''


def render_dashboard(payload: dict[str, Any], *, include_plotly: bool = True) -> str:
    uid='jf-'+uuid4().hex[:10]
    meta=payload['meta']; moeda=meta['moeda']; tela=meta.get('tela_inicial','jornada_dinheiro')
    validas={'jornada_dinheiro','origem_renda','circulacao_bancos','uso_dinheiro','evidencias_qualidade'}
    if tela not in validas: tela='jornada_dinheiro'
    plotly=f'<script>{get_plotlyjs()}</script>' if include_plotly else ''
    jornada=payload['jornada_dinheiro']; renda=payload['origem_renda']; circ=payload['circulacao_bancos']; uso=payload['uso_dinheiro']; eq=payload['evidencias_qualidade']
    principalidade=circ['principalidade']
    principal=f'''<div class="pf-callout info"><strong>Principalidade:</strong> {escape(principalidade['explicacao'])}''' + (f" Instituição central provável: {escape(principalidade['instituicao_central'])}." if principalidade.get('instituicao_central') else '') + '</div>'
    tabs=[('jornada_dinheiro','Jornada do dinheiro'),('origem_renda','Origem e renda'),('circulacao_bancos','Circulação e bancos'),('uso_dinheiro','Uso do dinheiro'),('evidencias_qualidade','Evidências e qualidade')]
    nav=''.join(f'<button class="pf-tab" data-tab="{k}" aria-selected="{str(k==tela).lower()}">{escape(n)}</button>' for k,n in tabs)
    limitacoes=''.join(f'<li>{escape(x)}</li>' for x in payload.get('limitacoes',[]))
    html=f'''<!doctype html><html><head><meta charset="utf-8">{plotly}{Visual.aplicar_estilo()}</head><body><div id="{uid}" class="pf-root">
<header class="pf-header"><h1>{escape(meta['produto'])}</h1><p>{escape(meta['subtitulo'])}</p><div class="pf-meta"><span class="pf-pill">Período: {escape(meta['periodo']['rotulo'])}</span><span class="pf-pill">Moeda: {escape(moeda)}</span><span class="pf-pill">{payload['cobertura']['movimentacoes']} movimentações</span><span class="pf-pill">{payload['cobertura']['instituicoes']} instituições</span></div></header>
<nav class="pf-tabs" aria-label="Áreas do painel">{nav}</nav>
<section class="pf-panel {'active' if tela=='jornada_dinheiro' else ''}" data-panel="jornada_dinheiro"><div class="pf-section"><h2>De onde veio, por onde passou e para onde foi</h2><p class="pf-section-intro">Uma leitura integrada do mesmo período, separando fatos observados de estimativas.</p>{_cards_resumo(payload,moeda)}</div><div class="pf-section"><h2>Resumo explicável</h2>{_resumo_executivo(jornada['resumo_executivo'])}</div><div class="pf-section"><h2>Cadeia estimada do dinheiro</h2><p class="pf-section-intro">As ligações são hipóteses rastreáveis. Não representam confirmação de titularidade ou causalidade.</p>{_grafico_cadeia(jornada['cadeia'],uid+'-cadeia')}</div><div class="pf-section"><h2>Organização bancária</h2>{principal}</div></section>
<section class="pf-panel {'active' if tela=='origem_renda' else ''}" data-panel="origem_renda"><div class="pf-section"><h2>Quais entradas parecem dinheiro novo?</h2><p class="pf-section-intro">Circulação, crédito, resgate, ajuste, duplicidade e origem inconclusiva são separados antes de estimar renda.</p>{_grafico_renda(renda['linha_tempo_mensal'],uid+'-renda')}</div><div class="pf-section"><h2>Fontes identificadas</h2>{_fontes_cards(renda['fontes'],moeda)}</div><div class="pf-section"><h2>Movimentações de entrada</h2>{_tabela_entradas(renda['entradas'],moeda)}</div></section>
<section class="pf-panel {'active' if tela=='circulacao_bancos' else ''}" data-panel="circulacao_bancos"><div class="pf-section"><h2>Papel de cada instituição</h2><p class="pf-section-intro">O painel não força um único banco principal; identifica recebimento, distribuição, operação, reserva, crédito e passagem.</p>{principal}{_grafico_bancos(circ['instituicoes'],uid+'-bancos')}{_bancos_cards(circ['instituicoes'],moeda)}</div><div class="pf-section"><h2>Pares candidatos entre contas</h2>{_tabela_pares(circ['pares'],moeda)}</div></section>
<section class="pf-panel {'active' if tela=='uso_dinheiro' else ''}" data-panel="uso_dinheiro"><div class="pf-section"><h2>O que foi observado depois do recebimento</h2><p class="pf-section-intro">Janelas cumulativas mostram sequência temporal, não causalidade.</p>{_grafico_janelas(uso['ciclos'].get('resumo_janelas',[]),uid+'-janelas')}{_ciclos_cards(uso['ciclos'],moeda)}</div><div class="pf-section"><h2>Com o que as saídas vieram categorizadas</h2><div class="pf-callout">A categoria é recebida e não é corrigida pelo projeto.</div></div></section>
<section class="pf-panel {'active' if tela=='evidencias_qualidade' else ''}" data-panel="evidencias_qualidade"><div class="pf-section"><h2>Integridade e incertezas</h2>{_qualidade_cards(eq,moeda)}</div><div class="pf-section"><h2>Todas as movimentações e camadas</h2>{_tabela_movimentos(payload['movimentacoes'],moeda,uid)}</div><div class="pf-section"><h2>Limitações</h2><div class="pf-card"><ul>{limitacoes}</ul></div></div></section>
</div><script>(function(){{const root=document.getElementById('{uid}');root.querySelectorAll('[data-tab]').forEach(btn=>btn.addEventListener('click',()=>{{root.querySelectorAll('[data-tab]').forEach(x=>x.setAttribute('aria-selected','false'));root.querySelectorAll('[data-panel]').forEach(x=>x.classList.remove('active'));btn.setAttribute('aria-selected','true');root.querySelector('[data-panel="'+btn.dataset.tab+'"]').classList.add('active');window.dispatchEvent(new Event('resize'));}}));const busca=root.querySelector('[data-mov-search]'),natureza=root.querySelector('[data-mov-natureza]');function filtrar(){{const q=(busca?.value||'').toLowerCase(),n=natureza?.value||'';root.querySelectorAll('[data-mov]').forEach(tr=>{{tr.style.display=((!q||tr.dataset.search.includes(q))&&(!n||tr.dataset.natureza===n))?'':'none';}});}}busca?.addEventListener('input',filtrar);natureza?.addEventListener('change',filtrar);}})();</script></body></html>'''
    return html


__all__=['Visual','render_dashboard']
