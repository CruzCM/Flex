"""Jornada Financeira do Cliente."""

from .app import executar_pipeline, exportar_html, fluxo_dashboard

__version__ = "2.2.0-bbmagic317-sqltyped"

__all__ = ["__version__", "executar_pipeline", "fluxo_dashboard", "exportar_html"]
