"""Normalização e análise integrada do cliente no período global."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from hashlib import sha256
import re
from typing import Any, Iterable

import pandas as pd

from .circulacao import executar_estudo_circulacao
from .jornada import executar_estudo_jornada
from .qualidade import executar_estudo_qualidade
from .renda import executar_estudo_renda
from .modelos import ConsultaPainel
from .regras import (
    BLOCOS,
    REFERENCIAS_RADAR,
    TEMAS,
    VERSAO_MACROCLASSIFICACAO,
    VERSAO_REFERENCIAS,
    VERSAO_REGRAS_ANALISE,
    VERSAO_REGRAS_CIRCULACAO,
    VERSAO_REGRAS_RADAR,
    VERSAO_REGRAS_QUALIDADE, VERSAO_REGRAS_RENDA, VERSAO_REGRAS_JORNADA,
    classificar_movimento,
    classificar_relacao_fluxo,
    mapear_perfil_financeiro,
    mapear_perfil_renda,
    normalizar_texto_regra,
    percentual_seguro,
    sinal_composicao,
    sinal_fluxo,
    sinal_segmentacao,
)

ZERO = Decimal("0")
CENTAVOS = Decimal("0.01")


def _normalizar_colunas(frame: pd.DataFrame | None) -> pd.DataFrame:
    resultado = frame.copy() if isinstance(frame, pd.DataFrame) else pd.DataFrame()
    resultado.columns = [str(coluna).upper() for coluna in resultado.columns]
    return resultado


def _texto(valor: Any) -> str | None:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return None
    if isinstance(valor, bytes):
        valor = valor.decode("utf-8", errors="replace")
    texto = str(valor).strip()
    return texto or None


def _inteiro(valor: Any) -> int | None:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return None
    try:
        return int(valor)
    except (TypeError, ValueError):
        return None


def _decimal(valor: Any) -> Decimal:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return ZERO
    try:
        return Decimal(str(valor)).quantize(CENTAVOS, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError):
        return ZERO


def _centavos(valor: Any) -> int:
    return int((_decimal(valor) * 100).to_integral_value(rounding=ROUND_HALF_UP))


def _data(valor: Any) -> pd.Timestamp | pd.NaT:
    return pd.to_datetime(valor, errors="coerce")


def _normalizar_numero_conta(valor: Any) -> str:
    texto = _texto(valor) or ""
    return re.sub(r"\D", "", texto).lstrip("0")


def _mascarar_conta(valor: Any, sequencial: Any) -> str:
    numero = _normalizar_numero_conta(valor)
    if numero:
        return f"•••• {numero[-4:]}"
    seq = _inteiro(sequencial)
    return f"Conta seq. {seq}" if seq is not None else "Conta não identificada"


def _proteger_descricao(valor: Any) -> str:
    texto = _texto(valor) or "Descrição não informada"
    texto = re.sub(r"(?<!\d)\d{5,}(?!\d)", "••••", texto)
    texto = re.sub(r"([\w.%-])[\w.%-]*@([\w.-]+)", r"\1•••@\2", texto)
    return texto[:180]


def _hash_curto(valor: str) -> str:
    return sha256(valor.encode("utf-8")).hexdigest()[:16].upper()


def _produto(codigo: Any) -> str:
    valor = _inteiro(codigo)
    if valor == 6:
        return "Conta corrente"
    if valor == 9:
        return "Cartão"
    return f"Produto {valor}" if valor is not None else "Produto não informado"


def _catalogos(categorias: pd.DataFrame, grupos: pd.DataFrame) -> dict[tuple[int, str], dict[str, Any]]:
    categorias = _normalizar_colunas(categorias)
    grupos = _normalizar_colunas(grupos)
    nomes_grupos: dict[int, str] = {}
    for _, linha in grupos.iterrows():
        codigo = _inteiro(linha.get("CD_GR_CTGR_TRAN"))
        if codigo is not None:
            nomes_grupos[codigo] = _texto(linha.get("TX_DCR_GR_CTGR")) or f"Grupo {codigo}"
    lookup: dict[tuple[int, str], dict[str, Any]] = {}
    for _, linha in categorias.iterrows():
        codigo = _inteiro(linha.get("CD_CTGR_TRAN"))
        natureza = (_texto(linha.get("CD_NTZ_CTB_TRAN")) or "").upper()
        grupo = _inteiro(linha.get("CD_GR_CTGR_TRAN"))
        if codigo is None or natureza not in {"C", "D"}:
            continue
        lookup[(codigo, natureza)] = {
            "nome": _texto(linha.get("TX_DCR_CTGR_TRAN")) or f"Categoria {codigo}",
            "grupo_codigo": grupo,
            "grupo_nome": nomes_grupos.get(grupo, f"Grupo {grupo}" if grupo is not None else "Grupo não informado"),
            "padrao_sistema": (_texto(linha.get("IN_CTGR_PDRO_SIS")) or "N").upper() == "S",
        }
    return lookup


def _normalizar_contas(contas: pd.DataFrame) -> tuple[dict[tuple[int | None, int | None], dict[str, Any]], set[str], list[dict[str, Any]]]:
    contas = _normalizar_colunas(contas)
    lookup: dict[tuple[int | None, int | None], dict[str, Any]] = {}
    documentos: set[str] = set()
    saida_segura: list[dict[str, Any]] = []
    for _, linha in contas.iterrows():
        marca = _inteiro(linha.get("NR_MCA_PCT_OPB"))
        seq = _inteiro(linha.get("NR_SEQL_CT_CLI"))
        instituicao = _inteiro(linha.get("CD_INST_PCT"))
        identificador = _texto(linha.get("CD_IDFR_CT"))
        numero = _normalizar_numero_conta(linha.get("CD_CT_TITR"))
        documento = _normalizar_numero_conta(linha.get("CD_CPF_CNPJ_TITR"))
        if documento:
            documentos.add(documento)
        materia = "|".join(str(x or "") for x in (instituicao, marca, seq, identificador, numero))
        conta_id = "CTA-" + _hash_curto(materia)
        rotulo = _mascarar_conta(linha.get("CD_CT_TITR"), seq)
        registro = {
            "conta_id": conta_id,
            "conta_rotulo": rotulo,
            "conta_numero_normalizado": numero,
            "conta_identificador_externo": identificador or "",
            "instituicao_codigo": instituicao,
            "instituicao_rotulo": f"Instituição {instituicao}" if instituicao is not None else "Instituição não informada",
            "marca_codigo": marca,
            "conta_sequencial": seq,
            "produto_codigo": _inteiro(linha.get("CD_PRD")),
            "produto": _produto(linha.get("CD_PRD")),
            "modalidade_codigo": _inteiro(linha.get("CD_MDLD_PRD")),
            "nome_identificacao": _proteger_descricao(linha.get("NM_IDFC_CT")) if _texto(linha.get("NM_IDFC_CT")) else None,
            "autorizacao_transacoes": _texto(linha.get("IN_AUTZ_EXB_TRAN")),
            "exibicao_dados": _texto(linha.get("IN_EXB_DADO_CT")),
            "estado_recurso": _inteiro(linha.get("CD_EST_RCS_OPB")),
            "ultima_atualizacao": _texto(linha.get("TS_ULT_ATL_TRAN") or linha.get("TS_ATL_INF")),
        }
        lookup[(marca, seq)] = registro
        saida_segura.append({k: v for k, v in registro.items() if k not in {"conta_numero_normalizado", "conta_identificador_externo"}})
    return lookup, documentos, saida_segura


def _normalizar_complementos(complementos: pd.DataFrame) -> dict[tuple[int | None, int | None], dict[str, Any]]:
    complementos = _normalizar_colunas(complementos)
    lookup: dict[tuple[int | None, int | None], dict[str, Any]] = {}
    for _, linha in complementos.iterrows():
        chave = (_inteiro(linha.get("NR_PTC")), _inteiro(linha.get("NR_TRAN_INST_PCT")))
        lookup[chave] = {
            "conta_identificador_externo": _texto(linha.get("CD_IDFR_CT")) or "",
            "contraparte_documento": _normalizar_numero_conta(linha.get("NR_CPF_CNPJ_PGDR")),
            "contraparte_instituicao": _inteiro(linha.get("CD_CPSO_PGDR_BNFC")),
            "contraparte_agencia": _inteiro(linha.get("NR_AG_PGDR_BNFC")),
            "contraparte_conta_normalizada": _normalizar_numero_conta(linha.get("CD_CT_PGDR_BNFC")),
            "contraparte_conta_id": "",
            "data_contabil": _texto(linha.get("DT_CTB_TRAN")),
            "identificador_transacao_externo": _texto(linha.get("CD_IDFR_TRAN_INST")),
            "nome_transacao": _proteger_descricao(linha.get("NM_TRAN_INST")) if _texto(linha.get("NM_TRAN_INST")) else None,
            "classificacao_atividade": _inteiro(linha.get("CD_CLSC_ATVD_ECNC")),
            "categoria_comercial": _texto(linha.get("CD_CTGR_CML")),
        }
    return lookup



def normalizar_movimentacoes(
    transacoes: pd.DataFrame,
    contas: pd.DataFrame,
    complementos_conta: pd.DataFrame,
    categorias: pd.DataFrame,
    grupos: pd.DataFrame,
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    """Normaliza o dado recebido sem corrigir ou substituir a categorização."""
    transacoes = _normalizar_colunas(transacoes)
    catalogo = _catalogos(categorias, grupos)
    contas_lookup, documentos_cliente, contas_seguras = _normalizar_contas(contas)
    complementos_lookup = _normalizar_complementos(complementos_conta)
    registros: list[dict[str, Any]] = []
    for indice, linha in transacoes.iterrows():
        particao = _inteiro(linha.get("NR_PTC"))
        numero_transacao = _inteiro(linha.get("NR_TRAN_INST_PCT"))
        id_evento_fisico = f"{particao or 0}-{numero_transacao if numero_transacao is not None else indice}"
        marca = _inteiro(linha.get("NR_MCA_PCT_OPB"))
        seq = _inteiro(linha.get("NR_SEQL_CT_CLI"))
        instituicao = _inteiro(linha.get("CD_INST_PCT"))
        conta = contas_lookup.get((marca, seq), {})
        complemento = complementos_lookup.get((particao, numero_transacao), {})
        numero_conta = _normalizar_numero_conta(linha.get("CD_CT_TITR")) or conta.get("conta_numero_normalizado", "")
        identificador_externo = complemento.get("conta_identificador_externo") or conta.get("conta_identificador_externo", "")
        materia = "|".join(str(x or "") for x in (instituicao, marca, seq, identificador_externo, numero_conta))
        conta_id = conta.get("conta_id") or (
            "CTA-" + _hash_curto(materia)
            if any((instituicao, marca, seq, identificador_externo, numero_conta))
            else "CONTA_NAO_IDENTIFICADA"
        )
        conta_rotulo = conta.get("conta_rotulo") or _mascarar_conta(linha.get("CD_CT_TITR"), seq)
        natureza = (_texto(linha.get("CD_NTZ_CTB_TRAN")) or "").upper()
        categoria_vigente_codigo = _inteiro(linha.get("CD_CTGR_TRAN"))
        categoria_original_codigo = _inteiro(linha.get("CD_CTGR_TRAN_OGNL"))
        vigente = catalogo.get((categoria_vigente_codigo, natureza), {})
        original = catalogo.get((categoria_original_codigo, natureza), {})
        classe = classificar_movimento(categoria_original_codigo, natureza)
        descricao_original = linha.get("TX_DCR_TRAN") or linha.get("TX_DCR_TRAN_OGNL") or linha.get("TX_CMPR_DCR_TRAN")
        contraparte_documento = complemento.get("contraparte_documento", "")
        registros.append({
            "id_evento_fisico": id_evento_fisico,
            "id_movimento": id_evento_fisico,
            "particao": particao,
            "numero_transacao": numero_transacao,
            "data": _data(linha.get("DT_TRAN")),
            "hora": _texto(linha.get("HR_TRAN")),
            "mes": _data(linha.get("DT_TRAN")).strftime("%Y-%m") if not pd.isna(_data(linha.get("DT_TRAN"))) else "Sem data",
            "valor_centavos": _centavos(linha.get("VL_TRAN")),
            "moeda": (_texto(linha.get("CD_TIP_MOE_CRR")) or "").upper(),
            "natureza": natureza or "NAO_RECONHECIDA",
            "instituicao_codigo": instituicao,
            "instituicao_rotulo": conta.get("instituicao_rotulo") or (
                f"Instituição {instituicao}" if instituicao is not None else "Instituição não informada"
            ),
            "marca_codigo": marca,
            "conta_sequencial": seq,
            "conta_id": conta_id,
            "conta_rotulo": conta_rotulo,
            "conta_numero_normalizado": numero_conta,
            "conta_identificador_externo": identificador_externo,
            "produto_codigo": _inteiro(linha.get("CD_PRD")),
            "produto": _produto(linha.get("CD_PRD")),
            "descricao_normalizada": normalizar_texto_regra(descricao_original),
            "descricao_protegida": _proteger_descricao(descricao_original),
            "categoria_original_codigo": categoria_original_codigo,
            "categoria_original": original.get("nome") or (
                f"Categoria {categoria_original_codigo}" if categoria_original_codigo is not None else "Categoria original não informada"
            ),
            "categoria_vigente_codigo": categoria_vigente_codigo,
            "categoria_vigente": vigente.get("nome") or (
                f"Categoria {categoria_vigente_codigo}" if categoria_vigente_codigo is not None else "Categoria vigente não informada"
            ),
            "categoria_alterada": categoria_original_codigo != categoria_vigente_codigo,
            "origem_categorizacao_codigo": _inteiro(linha.get("CD_CLSC_MTO_CTGR")),
            "grupo_codigo": vigente.get("grupo_codigo") if vigente else original.get("grupo_codigo"),
            "grupo_oficial": vigente.get("grupo_nome") or original.get("grupo_nome") or "Grupo não localizado",
            "macroclasse_codigo": classe["codigo"],
            "macroclasse_nome": classe["nome_comunicacao"],
            "macroclasse_nome_tecnico": classe["nome_tecnico"],
            "estado_classificacao": classe["estado_mapeamento"],
            "fl_agro": bool(classe["agro"]),
            "estado_transacao": _inteiro(linha.get("CD_EST_TRAN_INST")),
            "visibilidade_fluxo": _texto(linha.get("IN_VSLO_CX")),
            "visibilidade_consumo": _texto(linha.get("IN_VSLO_CSM")),
            "oculta": (_texto(linha.get("IN_OCTR_TRAN")) or "N").upper() == "S",
            "contraparte_conta_normalizada": complemento.get("contraparte_conta_normalizada", ""),
            "contraparte_conta_id": complemento.get("contraparte_conta_id", ""),
            "contraparte_instituicao": complemento.get("contraparte_instituicao"),
            "contraparte_titular_cliente": bool(contraparte_documento and contraparte_documento in documentos_cliente),
            "contraparte_fonte_hash": _hash_curto(f"ORIGEM|{contraparte_documento}") if contraparte_documento else "",
            "complemento_disponivel": bool(complemento),
        })
    base = pd.DataFrame(registros)
    if base.empty:
        return pd.DataFrame(columns=[
            "id_evento_fisico", "id_movimento", "data", "valor_centavos",
            "moeda", "natureza", "conta_id", "conta_rotulo", "instituicao_rotulo",
        ]), contas_seguras

    # Chaves físicas duplicadas recebem IDs internos únicos, preservando a chave
    # original em id_evento_fisico para a validação de duplicidade.
    ordem_repeticao = base.groupby("id_evento_fisico", sort=False).cumcount()
    base["id_movimento"] = [
        evento if repeticao == 0 else f"{evento}-R{repeticao + 1}"
        for evento, repeticao in zip(base["id_evento_fisico"], ordem_repeticao)
    ]
    base = base.sort_values(["data", "hora", "id_movimento"], na_position="last").reset_index(drop=True)
    return base, contas_seguras


def _resumo_base(base: pd.DataFrame) -> dict[str, Any]:
    if base.empty:
        return {
            "entradas": 0.0, "saidas": 0.0, "diferenca": 0.0,
            "quantidade_movimentacoes": 0, "contas": 0, "instituicoes": 0,
        }
    entradas = int(base.loc[base["natureza"].eq("C"), "valor_centavos"].sum())
    saidas = int(base.loc[base["natureza"].eq("D"), "valor_centavos"].sum())
    return {
        "entradas": entradas / 100,
        "saidas": saidas / 100,
        "diferenca": (entradas - saidas) / 100,
        "quantidade_movimentacoes": int(len(base)),
        "quantidade_entradas": int(base["natureza"].eq("C").sum()),
        "quantidade_saidas": int(base["natureza"].eq("D").sum()),
        "contas": int(base["conta_id"].nunique()),
        "instituicoes": int(base["instituicao_rotulo"].nunique()),
    }


def _evolucao_mensal(base: pd.DataFrame, consulta: ConsultaPainel) -> list[dict[str, Any]]:
    meses = [str(p) for p in pd.period_range(
        pd.Timestamp(consulta.periodo_inicio).to_period("M"),
        pd.Timestamp(consulta.periodo_fim).to_period("M"), freq="M"
    )]
    saida = []
    for mes in meses:
        grupo = base[base["mes"].eq(mes)] if not base.empty else base
        ent = int(grupo.loc[grupo["natureza"].eq("C"), "valor_centavos"].sum()) if not grupo.empty else 0
        sai = int(grupo.loc[grupo["natureza"].eq("D"), "valor_centavos"].sum()) if not grupo.empty else 0
        saida.append({
            "mes": mes, "entradas": ent / 100, "saidas": sai / 100,
            "diferenca": (ent - sai) / 100, "movimentacoes": int(len(grupo)),
        })
    return saida


def _concentracao_recebida(base: pd.DataFrame, natureza: str) -> list[dict[str, Any]]:
    if base.empty:
        return []
    grupo = base[base["natureza"].eq(natureza)]
    total = int(grupo["valor_centavos"].sum())
    if grupo.empty or total <= 0:
        return []
    agregado = grupo.groupby("categoria_vigente", dropna=False).agg(
        valor_centavos=("valor_centavos", "sum"), quantidade=("id_movimento", "count")
    ).reset_index()
    return [
        {
            "categoria_recebida": str(linha["categoria_vigente"]),
            "valor": int(linha["valor_centavos"]) / 100,
            "percentual": round(int(linha["valor_centavos"]) / total * 100, 2),
            "quantidade": int(linha["quantidade"]),
            "caracter": "CATEGORIA_RECEBIDA_SEM_CORRECAO_PELO_PROJETO",
        }
        for _, linha in agregado.sort_values("valor_centavos", ascending=False).iterrows()
    ]


def _coerencia_categoria_entrada(item: dict[str, Any]) -> dict[str, Any]:
    tipo = item.get("tipo_analitico")
    macro = item.get("macroclasse_recebida", "")
    if tipo == "MOVIMENTACAO_INTERNA_PROVAVEL" and "Renda" in macro:
        return {
            "estado": "CONFLITANTE_COM_CIRCULACAO",
            "motivo": "A categoria recebida sugere renda, mas existe saída forte associada em outra conta observada.",
        }
    if tipo == "DUPLICIDADE_PROVAVEL":
        return {"estado": "NAO_AVALIAVEL_DUPLICIDADE", "motivo": "A integridade do evento precisa ser esclarecida primeiro."}
    if tipo in {"SALARIO_PROVAVEL", "RENDA_RECORRENTE_PROVAVEL"} and "Renda" in macro:
        return {"estado": "COMPATIVEL_COM_EVIDENCIAS", "motivo": "Recorrência e categoria recebida apontam na mesma direção."}
    return {
        "estado": "NAO_AVALIADA",
        "motivo": "A categorização é recebida e preservada; o projeto não confirma sua correção econômica.",
    }


def _publicar_ids(
    base: pd.DataFrame,
    qualidade: dict[str, Any],
    circulacao: dict[str, Any],
    renda: dict[str, Any],
    jornada: dict[str, Any],
) -> tuple[dict[str, str], dict[str, str]]:
    movimentos = sorted(base["id_movimento"].astype(str).unique().tolist()) if not base.empty else []
    mapa_mov = {mid: f"MOV-{i:06d}" for i, mid in enumerate(movimentos, start=1)}
    pares = sorted({str(p["id_par"]) for p in circulacao.get("pares", [])})
    mapa_par = {pid: f"PAR-{i:05d}" for i, pid in enumerate(pares, start=1)}
    conta_rotulos = {
        str(linha.get("conta_id")): str(linha.get("conta_rotulo") or "Conta não informada")
        for _, linha in base.iterrows()
    }

    def mov(mid: Any) -> str:
        texto = str(mid)
        if texto.startswith("MOV-"):
            return texto
        return mapa_mov.get(texto, "MOV-NAO-LOCALIZADO")

    for grupo in qualidade.get("grupos", []):
        grupo["movimentos"] = [mov(x) for x in grupo.get("movimentos", [])]
    for par in circulacao.get("pares", []):
        par["id_par"] = mapa_par.get(str(par.get("id_par")), str(par.get("id_par")))
        par["id_saida"] = mov(par.get("id_saida"))
        par["id_entrada"] = mov(par.get("id_entrada"))
        par.pop("conta_origem_id", None)
        par.pop("conta_destino_id", None)
    for rota in circulacao.get("rotas", []):
        rota["ids_pares"] = [mapa_par.get(str(x), str(x)) for x in rota.get("ids_pares", [])]
        rota.pop("conta_origem_id", None)
        rota.pop("conta_destino_id", None)
    for item in renda.get("entradas", []):
        item["id_movimento"] = mov(item.get("id_movimento"))
        item["coerencia_categoria_recebida"] = _coerencia_categoria_entrada(item)
    for fonte in renda.get("fontes", []):
        fonte["movimentos"] = [mov(x) for x in fonte.get("movimentos", [])]
        fonte["conta_principal_id"] = fonte.get("conta_receptora")
    if renda.get("fonte_principal"):
        renda["fonte_principal"]["movimentos"] = [mov(x) for x in renda["fonte_principal"].get("movimentos", [])]
    ciclos = jornada.get("ciclos_pos_recebimento", {}).get("eventos", [])
    for ciclo in ciclos:
        ciclo["id_evento"] = mov(ciclo.get("id_evento"))
        ciclo["contas_acompanhadas"] = [
            conta_rotulos.get(str(x), "Conta não identificada")
            for x in ciclo.get("contas_acompanhadas", [])
        ]
        for elo in ciclo.get("cadeia_transferencias", []):
            elo["id_par"] = mapa_par.get(str(elo.get("id_par")), str(elo.get("id_par")))
        for janela in ciclo.get("janelas", []):
            janela["movimentos"] = [mov(x) for x in janela.get("movimentos", [])]
    return mapa_mov, mapa_par


def _movimentos_publicos(
    base: pd.DataFrame,
    mapa_mov: dict[str, str],
    renda: dict[str, Any],
    circulacao: dict[str, Any],
) -> list[dict[str, Any]]:
    entrada_lookup = {str(x.get("id_movimento_interno", x.get("id_movimento"))): x for x in []}
    # Depois da publicação de IDs, o vínculo é reconstruído pelo ID público.
    analise_entrada = {str(x.get("id_movimento")): x for x in renda.get("entradas", [])}
    circulacao_lookup: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for par in circulacao.get("pares", []):
        for campo in ("id_saida", "id_entrada"):
            circulacao_lookup[str(par.get(campo))].append({
                "id_par": par.get("id_par"), "estado": par.get("estado_motor"),
                "indice_evidencia": par.get("indice_evidencia"),
                "usado_estimativa": par.get("usado_estimativa"),
            })
    saida = []
    for _, linha in base.sort_values(["data", "hora", "id_movimento"], na_position="last").iterrows():
        interno = str(linha["id_movimento"])
        publico = mapa_mov.get(interno, "MOV-NAO-LOCALIZADO")
        item_entrada = analise_entrada.get(publico)
        data = pd.to_datetime(linha.get("data"), errors="coerce")
        saida.append({
            "id_movimento": publico,
            "data": None if pd.isna(data) else data.date().isoformat(),
            "hora": _texto(linha.get("hora")),
            "valor": int(linha.get("valor_centavos") or 0) / 100,
            "moeda": _texto(linha.get("moeda")),
            "natureza": _texto(linha.get("natureza")),
            "instituicao": _texto(linha.get("instituicao_rotulo")),
            "conta": _texto(linha.get("conta_rotulo")),
            "produto": _texto(linha.get("produto")),
            "descricao_protegida": _texto(linha.get("descricao_protegida")),
            "categoria_original_recebida": _texto(linha.get("categoria_original")),
            "categoria_vigente_recebida": _texto(linha.get("categoria_vigente")),
            "grupo_recebido": _texto(linha.get("grupo_oficial")),
            "classificacao_0_9_codigo": _inteiro(linha.get("macroclasse_codigo")),
            "classificacao_0_9_nome": _texto(linha.get("macroclasse_nome")),
            "classificacao_0_9_origem": "DERIVADA_DA_CATEGORIA_ORIGINAL_RECEBIDA_E_NATUREZA",
            "estado_mapeamento_0_9": _texto(linha.get("estado_classificacao")),
            "categoria_alterada_na_origem": bool(linha.get("categoria_alterada")),
            "duplicidade": {
                "estado": _texto(linha.get("estado_duplicidade")) or "SEM_SINAL",
                "usada_estimativa": bool(linha.get("duplicidade_usada_estimativa")),
                "evidencias": list(linha.get("duplicidade_evidencias") or []),
            },
            "circulacao": circulacao_lookup.get(publico, []),
            "interpretacao_entrada": item_entrada,
            "caracter": "FATO_OBSERVADO_COM_CAMADAS_ANALITICAS_SEPARADAS",
        })
    return saida


def _resumo_executivo(
    consulta: ConsultaPainel,
    base: pd.DataFrame,
    qualidade: dict[str, Any],
    circulacao: dict[str, Any],
    renda: dict[str, Any],
    jornada: dict[str, Any],
) -> list[dict[str, Any]]:
    frases: list[dict[str, Any]] = []
    resumo_base = _resumo_base(base)
    frases.append({
        "id_regra": "JORNADA_RES_001", "tipo": "OBSERVADO",
        "titulo": "Movimentação no período",
        "texto": (
            f"Foram observadas entradas de {consulta.moeda} {resumo_base['entradas']:,.2f} "
            f"e saídas de {consulta.moeda} {resumo_base['saidas']:,.2f}."
        ),
        "evidencias": resumo_base,
    })
    if qualidade["resumo"]["movimentacoes_neutralizadas"]:
        frases.append({
            "id_regra": "JORNADA_RES_002", "tipo": "SINAL_INFERIDO",
            "titulo": "Possíveis duplicidades",
            "texto": (
                f"A leitura estimada neutraliza {qualidade['resumo']['movimentacoes_neutralizadas']} "
                "repetições fortes, mantendo a base observada intacta."
            ),
            "evidencias": qualidade["resumo"],
        })
    renda_res = renda["resumo"]
    frases.append({
        "id_regra": "JORNADA_RES_003", "tipo": "CALCULADO",
        "titulo": "Origem provável das entradas",
        "texto": (
            f"Das entradas observadas, {consulta.moeda} {renda_res['entradas_externas_estimadas']:,.2f} "
            f"foram tratadas como externas prováveis e {consulta.moeda} "
            f"{renda_res['circulacao_interna_provavel']:,.2f} como circulação interna provável."
        ),
        "evidencias": renda_res,
    })
    principal = renda.get("fonte_principal")
    if principal:
        frases.append({
            "id_regra": "JORNADA_RES_004", "tipo": "SINAL_INFERIDO",
            "titulo": "Principal fonte recorrente provável",
            "texto": (
                f"{principal.get('rotulo', 'Uma fonte recorrente')} aparece em "
                f"{principal['quantidade_meses']} de {principal['quantidade_meses_periodo']} meses, "
                f"com valor típico de {consulta.moeda} {principal['valor_tipico']:,.2f} "
                f"e dia mediano {principal.get('dia_mediano') or 'não calculável'}."
            ),
            "evidencias": {
                "fonte_id": principal.get("fonte_id"),
                "classificacao": principal.get("classificacao"),
                "pontuacao_tecnica": principal.get("pontuacao_tecnica"),
                "evidencias": principal.get("evidencias"),
            },
            "limitacao": "A fonte é provável; não há comprovação automática de vínculo empregatício.",
        })
    principalidade = jornada["papeis_bancarios"]["principalidade"]
    frases.append({
        "id_regra": "JORNADA_RES_005", "tipo": "CALCULADO",
        "titulo": "Organização entre instituições",
        "texto": principalidade["explicacao"],
        "evidencias": principalidade,
    })
    return frases


def montar_painel(
    *, frames: dict[str, pd.DataFrame], consulta: ConsultaPainel, fontes: dict[str, Any]
) -> dict[str, Any]:
    base, contas_seguras = normalizar_movimentacoes(
        frames.get("transacoes", pd.DataFrame()), frames.get("contas", pd.DataFrame()),
        frames.get("complementos_conta", pd.DataFrame()), frames.get("categorias", pd.DataFrame()),
        frames.get("grupos", pd.DataFrame()),
    )
    qualidade = executar_estudo_qualidade(base)
    base_qualidade = qualidade.pop("base_anotada")
    base_sem_dup = qualidade.pop("base_sem_duplicidades")
    ids_dup = qualidade.pop("ids_neutralizados")

    circulacao = executar_estudo_circulacao(base_sem_dup)
    base_externa = circulacao.pop("base_estimada")
    circulacao.pop("candidatos", None)
    ids_internos = circulacao.pop("ids_neutralizados")

    # Reaplica as anotações de qualidade na base observada para as camadas seguintes.
    base = base_qualidade
    renda = executar_estudo_renda(base, base_sem_dup, circulacao["pares"], consulta)
    renda_base_interna = renda.pop("base_entradas_anotada", pd.DataFrame())
    jornada = executar_estudo_jornada(base_sem_dup, renda, circulacao["pares"], consulta)

    mapa_mov, _ = _publicar_ids(base, qualidade, circulacao, renda, jornada)
    movimentos = _movimentos_publicos(base, mapa_mov, renda, circulacao)

    # IDs de neutralização também são publicados; chaves físicas nunca saem do motor.
    qualidade["base_estimada"] = {
        "ids_neutralizados": [mapa_mov.get(x, "MOV-NAO-LOCALIZADO") for x in sorted(ids_dup)],
        "quantidade_movimentos": int(len(base_sem_dup)),
    }
    circulacao["base_estimada"] = {
        "ids_neutralizados": [mapa_mov.get(x, "MOV-NAO-LOCALIZADO") for x in sorted(ids_internos)],
        "quantidade_movimentos": int(len(base_externa)),
    }

    resumo_observado = _resumo_base(base)
    resumo_sem_dup = _resumo_base(base_sem_dup)
    resumo_externo = _resumo_base(base_externa)
    frases = _resumo_executivo(consulta, base, qualidade, circulacao, renda, jornada)

    limitacoes = [
        "A análise considera somente contas, instituições e movimentações disponíveis no recorte consultado.",
        "A categorização é recebida das fontes e não é corrigida pelo projeto.",
        "Salário, renda externa, duplicidade e movimentação interna são interpretações prováveis, não fatos confirmados.",
        "A sequência após um recebimento não comprova que aquela entrada financiou cada saída; dinheiro é fungível.",
        "A base observada permanece preservada. Leituras estimadas são apresentadas separadamente.",
        "O painel não representa saldo atual, patrimônio, renda oficial, vínculo empregatício ou dívida total.",
    ]
    if fontes.get("contas", {}).get("estado") == "INDISPONIVEL":
        limitacoes.append("A fonte de contas não foi carregada; a principalidade e as rotas têm menor evidência.")
    if fontes.get("complementos_conta", {}).get("estado") == "INDISPONIVEL":
        limitacoes.append("A fonte de contraparte não foi carregada; a origem das entradas tem menor evidência.")

    categorias_coerencia = defaultdict(int)
    for entrada in renda.get("entradas", []):
        categorias_coerencia[entrada["coerencia_categoria_recebida"]["estado"]] += 1

    payload = {
        "meta": {
            "produto": "Jornada Financeira do Cliente",
            "subtitulo": "De onde o dinheiro vem, como circula e para onde vai.",
            "periodo": {
                "inicio": consulta.periodo_inicio.isoformat(), "fim": consulta.periodo_fim.isoformat(),
                "rotulo": f"{consulta.periodo_inicio.strftime('%d/%m/%Y')} a {consulta.periodo_fim.strftime('%d/%m/%Y')}",
            },
            "moeda": consulta.moeda,
            "instituicoes_filtro": list(consulta.instituicoes),
            "gerado_em": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "tela_inicial": consulta.tela_inicial,
            "versoes": {
                "qualidade": VERSAO_REGRAS_QUALIDADE, "circulacao": VERSAO_REGRAS_CIRCULACAO,
                "renda": VERSAO_REGRAS_RENDA, "jornada": VERSAO_REGRAS_JORNADA,
                "analise": VERSAO_REGRAS_ANALISE, "macroclassificacao_compatibilidade": VERSAO_MACROCLASSIFICACAO,
                "radar_compatibilidade": VERSAO_REGRAS_RADAR,
            },
        },
        "fontes": fontes,
        "cobertura": {
            "movimentacoes": int(len(base)), "contas": int(len(contas_seguras)),
            "instituicoes": int(base["instituicao_rotulo"].nunique()) if not base.empty else 0,
            "movimentacoes_com_complemento": int(base["complemento_disponivel"].sum()) if not base.empty else 0,
            "naturezas_nao_reconhecidas": int((~base["natureza"].isin(["C", "D"])).sum()) if not base.empty else 0,
            "categorias_nao_mapeadas_0_9": int(base["estado_classificacao"].eq("FALLBACK_CATEGORIA_NAO_MAPEADA").sum()) if not base.empty else 0,
        },
        "jornada_dinheiro": {
            "resumo_executivo": frases,
            "observado": resumo_observado,
            "apos_duplicidades": resumo_sem_dup,
            "externo_estimado": resumo_externo,
            "cadeia": jornada["cadeia_dinheiro"],
            "evolucao_observada": _evolucao_mensal(base, consulta),
            "evolucao_externa_estimada": _evolucao_mensal(base_externa, consulta),
        },
        "origem_renda": renda,
        "circulacao_bancos": {
            "resumo": circulacao["resumo"], "pares": circulacao["pares"],
            "rotas": circulacao["rotas"], **jornada["papeis_bancarios"],
        },
        "uso_dinheiro": {
            "ciclos": jornada["ciclos_pos_recebimento"],
            "concentracao_categorias_recebidas": _concentracao_recebida(base_externa, "D"),
            "explicacao": (
                "A tela descreve movimentos posteriores aos recebimentos e utiliza a categoria recebida "
                "somente como rótulo auxiliar, sem recategorização ou afirmação causal."
            ),
        },
        "evidencias_qualidade": {
            "qualidade": qualidade, "ambiguidades_circulacao": [
                p for p in circulacao["pares"] if p.get("estado_motor") == "AMBIGUO"
            ],
            "coerencia_categoria_recebida_entradas": dict(categorias_coerencia),
            "reconciliacao": {
                "diferenca_observada": resumo_observado["diferenca"],
                "diferenca_apos_duplicidades": resumo_sem_dup["diferenca"],
                "diferenca_externa_estimada": resumo_externo["diferenca"],
                "observacao": "Duplicidades podem alterar a diferença; pares internos neutralizam uma entrada e uma saída do mesmo valor.",
            },
        },
        "movimentacoes": movimentos,
        "contas": contas_seguras,
        "metodologia": {
            "categorizacao": "Recebida e preservada; não é corrigida pelo projeto.",
            "classificacao_0_9": {str(codigo): dados["nome_comunicacao"] for codigo, dados in BLOCOS.items()},
            "papel_classificacao_0_9": "Compatibilidade e explicação auxiliar; não conduz a origem real do dinheiro.",
            "caracter_estimativas": "HEURISTICAS_VERSIONADAS_EM_VALIDACAO",
        },
        "limitacoes": limitacoes,
    }
    del renda_base_interna
    return payload


__all__ = ["normalizar_movimentacoes", "montar_painel"]
