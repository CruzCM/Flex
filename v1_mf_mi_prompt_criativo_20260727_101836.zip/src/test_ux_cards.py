import inspect
import io
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from src import motor
from src.app import Experiencia, FalhaFluxo, StatusAmbiente, Visual, fluxo_geracao
from src.modelos import (
    Apresentacao,
    ConjuntoGerado,
    Produto,
    Prompt,
    Publico,
    ResultadoEtapa,
    ResultadoPrompt,
)


class RecordingUI(Visual):
    def __init__(self, escolhas=None, decimais=None, numeros=None):
        self.escolhas = list(escolhas or [])
        self.decimais = list(decimais or [])
        self.numeros = list(numeros or [])
        self.secoes = []
        self.cards = []
        self.cards_diretos = []
        self.cards_com_secoes = []
        self.opcoes_por_indice = []
        self.finais = []

    def secao(self, texto):
        self.secoes.append(texto)

    def escolher_mapeado(self, mensagem, opcoes, **kwargs):
        return self.escolhas.pop(0)

    def escolher_mapeado_por_indice(self, mensagem, opcoes, **kwargs):
        self.opcoes_por_indice.append((mensagem, opcoes, kwargs))
        escolha = self.escolhas.pop(0)
        if isinstance(escolha, int):
            for indice, _, valor in opcoes:
                if indice == escolha:
                    return valor
        return escolha

    def decimal(self, mensagem, padrao):
        return self.decimais.pop(0)

    def numero(self, mensagem, padrao):
        return self.numeros.pop(0)

    def status(self, valor):
        return Visual().status(valor)

    def card(self, titulo, campos=None, **kwargs):
        self.cards.append((titulo, campos, kwargs))

    def card_direto(self, titulo, campos=None, **kwargs):
        self.cards_diretos.append((titulo, campos, kwargs))

    def card_com_secoes(
        self,
        titulo,
        campos_topo=None,
        secoes=None,
        detalhes_tecnicos=None,
        campos_rodape=None,
        **kwargs,
    ):
        self.cards_com_secoes.append(
            (titulo, campos_topo, secoes, detalhes_tecnicos, campos_rodape, kwargs)
        )

    def final(self, campos, **kwargs):
        self.finais.append((campos, kwargs))


class TestUXCards(unittest.TestCase):
    def setUp(self):
        self.ui = Visual()
        self.experiencia = Experiencia(
            motor,
            StatusAmbiente(Path("."), "3", "Ollama local"),
            "ollama",
        )

    def resultado_prompt(
        self,
        grupo="1_revisor_textual",
        nome="p1",
        output="Texto gerado",
        opcao="",
    ):
        prompt = Prompt(
            grupo=grupo,
            nome=nome,
            system="System",
            template="Template",
            origem=f"prompts/{grupo}/{nome}.yaml",
        )
        return ResultadoPrompt(
            prompt=prompt,
            system="System",
            template_original="Template",
            template_preenchido="Template preenchido",
            entrada="Entrada",
            opcao=opcao,
            parametros={
                "temperature": 0.7,
                "max_tokens": 100,
                "top_p": 1.0,
                "frequency_penalty": 0.0,
                "presence_penalty": 0.0,
                "best_of": 1,
            },
            output=output,
        )

    def test_fluxo_geracao_converte_erro_em_resultado_final_curto(self):
        with patch(
            "src.app.preparar_ambiente",
            return_value=StatusAmbiente(Path("."), "3", "Genera oficial"),
        ), patch(
            "src.app.Experiencia.rodar",
            side_effect=ValueError("Falha limpa"),
        ):
            saida = io.StringIO()
            with redirect_stdout(saida):
                resultado = fluxo_geracao()

        texto = saida.getvalue()
        self.assertIsInstance(resultado, FalhaFluxo)
        self.assertFalse(resultado)
        self.assertEqual(resultado.tipo, "ValueError")
        self.assertIn("Falha limpa", resultado.erro)
        self.assertIn("RESULTADO FINAL", texto)
        self.assertIn("Falha limpa", texto)
        self.assertNotIn("Traceback", texto)

    def test_fluxo_geracao_permite_traceback_quando_solicitado(self):
        with patch(
            "src.app.preparar_ambiente",
            return_value=StatusAmbiente(Path("."), "3", "Genera oficial"),
        ), patch(
            "src.app.Experiencia.rodar",
            side_effect=ValueError("Falha limpa"),
        ):
            with self.assertRaises(ValueError):
                fluxo_geracao(exibir_traceback=True)

    def conjunto_completo(self):
        etapas = [
            ("tendencia_cognitiva", "3_tendencia_cognitiva"),
            ("voz_bb", "4_voz_BB"),
            ("tagline", "5_tagline"),
            ("headline", "6_headline"),
            ("cta", "7_cta"),
        ]
        resultados = [
            self.resultado_prompt(
                grupo=grupo,
                output=f"Resultado {etapa_id}",
                opcao="Afinidade",
            )
            for etapa_id, grupo in etapas
        ]
        return ConjuntoGerado(
            id="1",
            contexto={},
            tendencia="Afinidade",
            prompts={
                etapa_id: resultado.prompt.identificador
                for (etapa_id, _), resultado in zip(etapas, resultados)
            },
            resultados=resultados,
        )

    def test_status_normalizado(self):
        casos = {
            "pronto": "Pronto",
            "pronta": "Pronto",
            "concluido": "Pronto",
            "não concluída": "Erro",
            "erro": "Erro",
            "selecionado": "Selecionado",
        }

        for entrada, esperado in casos.items():
            with self.subTest(entrada=entrada):
                self.assertEqual(self.ui.status(entrada), esperado)

    def test_cards_principais_iniciam_minimizados(self):
        html_simples = self.ui.html_card("Produto", {"Descrição": "Texto"})
        html_direto = self.ui.html_card_direto("Cartão Ouro", {"Descrição": "Texto"})
        html_secoes = self.ui.html_card_com_secoes(
            "Revisão Textual",
            secoes=[("Resultado", "Texto")],
        )

        for html in (html_simples, html_direto, html_secoes):
            with self.subTest(html=html[:80]):
                self.assertTrue(html.startswith("<details class='pc-wrap pc-card'"))
                abertura = html.split(">", 1)[0]
                self.assertNotIn("open", abertura)
                self.assertIn("<summary>", html)

    def test_card_direto_nao_cria_subcards_internos(self):
        html = self.ui.html_card_direto(
            "Cartão Ouro",
            {
                "Descrição": "Produto escolhido",
                "Benefício racional": "Benefício claro",
            },
        )

        self.assertIn("Cartão Ouro", html)
        self.assertIn("Descrição", html)
        self.assertIn("Produto escolhido", html)
        self.assertNotIn("<details class='pc-nested-card", html)

    def test_escolher_mapeado_respeita_numero_exibido(self):
        opcoes = [
            ("Primeira opção", "primeira"),
            ("Segunda opção", "segunda"),
            ("Terceira opção", "terceira"),
        ]

        for numero, esperado in [(1, "primeira"), (2, "segunda"), (3, "terceira")]:
            with self.subTest(numero=numero):
                with patch("builtins.input", return_value=str(numero)):
                    with redirect_stdout(io.StringIO()):
                        self.assertEqual(
                            self.ui.escolher_mapeado("Escolha", opcoes),
                            esperado,
                        )

    def test_escolher_mapeado_por_indice_respeita_numero_explicito(self):
        opcoes = [
            (2, "Prompt P2", "p2"),
            (4, "Prompt P4", "p4"),
        ]

        with patch("builtins.input", return_value="4"):
            with redirect_stdout(io.StringIO()):
                escolhido = self.ui.escolher_mapeado_por_indice(
                    "Escolha",
                    opcoes,
                    padrao=2,
                )

        self.assertEqual(escolhido, "p4")

    def test_escolhas_de_contexto_usam_nome_escolhido_em_card_direto(self):
        ui = RecordingUI(
            [
                "cartao_ouro",
                "familia_estabelecida",
                "encaixe_de_valor",
                "AIDA",
            ]
        )
        self.experiencia.ui = ui

        produto = self.experiencia.selecionar_produto()
        publico = self.experiencia.selecionar_publico()
        self.experiencia.selecionar_apresentacao(produto, publico)
        self.experiencia.selecionar_cenario()

        self.assertEqual(ui.secoes, ["Produto", "Público", "Apresentação", "Cenário"])
        self.assertEqual(ui.cards, [])
        self.assertEqual(len(ui.cards_diretos), 4)
        self.assertEqual(ui.cards_diretos[0][0], "Cartão Ouro")
        self.assertEqual(ui.cards_diretos[1][0], "Família Estabelecida")
        self.assertEqual(ui.cards_diretos[2][0], "Encaixe De Valor")
        self.assertEqual(ui.cards_diretos[3][0], "AIDA")

        campos_produto = ui.cards_diretos[0][1]
        campos_publico = ui.cards_diretos[1][1]
        campos_apresentacao = ui.cards_diretos[2][1]
        campos_cenario = ui.cards_diretos[3][1]
        self.assertEqual(
            [chave for chave, _ in campos_produto],
            ["PH_SGT_DCR", "PH_SGT_RCNL", "PH_SGT_EMOC"],
        )
        self.assertEqual(
            [chave for chave, _ in campos_publico],
            ["PH_PBCO_DCR", "PH_PBCO_RCNL", "PH_PBCO_EMOC"],
        )
        self.assertEqual(
            [chave for chave, _ in campos_apresentacao],
            ["Template padrão", "Template preenchido"],
        )
        template_preenchido = campos_apresentacao[1][1]
        self.assertTrue(template_preenchido["conteudo_html"])
        self.assertIn("pc-template-value", template_preenchido["conteudo"])
        self.assertNotIn("PH_SGT_DCR", template_preenchido["conteudo"])
        self.assertNotIn("PH_PBCO_DCR", template_preenchido["conteudo"])
        self.assertEqual(
            [chave for chave, _ in campos_cenario],
            ["Função", "Estrutura"],
        )

    def test_apresentacao_destaca_valores_preenchidos_inline(self):
        partes = [
            {"tipo": "fixo", "texto": "Texto fixo para "},
            {
                "tipo": "valor",
                "placeholder": "PH_PBCO_DCR",
                "texto": "Público <especial>",
            },
            {"tipo": "fixo", "texto": " com "},
            {
                "tipo": "valor",
                "placeholder": "PH_SGT_DCR",
                "texto": "Produto",
            },
            {"tipo": "fixo", "texto": "."},
        ]

        html = self.ui.html_apresentacao_preenchida(partes)
        terminal = self.ui.texto_apresentacao_preenchida(partes)

        self.assertIn("Texto fixo para", html)
        self.assertIn("pc-template-value", html)
        self.assertNotIn("PH_PBCO_DCR", html)
        self.assertNotIn("PH_SGT_DCR", html)
        self.assertIn("Público &lt;especial&gt;", html)
        self.assertNotIn("Público <especial>", html)
        self.assertEqual(
            terminal,
            "Texto fixo para Público <especial> com Produto.",
        )

    def test_parametros_geracao_automatico_renderiza_card_unico_direto(self):
        ui = RecordingUI()
        self.experiencia.ui = ui
        self.experiencia.parametros_automaticos = True

        self.experiencia.mostrar_parametros_geracao(100, 25)

        self.assertEqual(ui.cards, [])
        self.assertEqual(ui.cards_com_secoes, [])
        self.assertEqual(len(ui.cards_diretos), 1)
        titulo, campos, _ = ui.cards_diretos[0]
        self.assertEqual(titulo, "Parâmetros de Geração")

        campos_dict = dict(campos)
        self.assertEqual(campos_dict["Texto"], "100 caracteres")
        self.assertEqual(campos_dict["Título"], "25 caracteres")
        self.assertEqual(campos_dict["Modo"], "Automático")
        self.assertIn(
            "Revisão Textual: 2 prompts | temperatura 0.5 | max tokens 512",
            campos_dict["Fluxo iniciado"],
        )
        self.assertIn(
            "Voz BB: 2 prompts | temperatura 0.5 | max tokens 700",
            campos_dict["Fluxo iniciado"],
        )

    def test_parametros_geracao_manual_nao_exibe_temperatura_ou_max_tokens(self):
        ui = RecordingUI()
        self.experiencia.ui = ui
        self.experiencia.parametros_automaticos = False

        self.experiencia.mostrar_parametros_geracao(90, 30)

        titulo, campos, _ = ui.cards_diretos[0]
        campos_dict = dict(campos)
        self.assertEqual(titulo, "Parâmetros de Geração")
        self.assertEqual(campos_dict["Texto"], "90 caracteres")
        self.assertEqual(campos_dict["Título"], "30 caracteres")
        self.assertEqual(campos_dict["Modo"], "Manual")
        self.assertIn(
            "Revisão Textual: 2 prompts | parâmetros perguntados antes da etapa",
            campos_dict["Fluxo iniciado"],
        )
        self.assertNotIn("temperatura", campos_dict["Fluxo iniciado"])
        self.assertNotIn("max tokens", campos_dict["Fluxo iniciado"])

    def test_configuracao_manual_nao_cria_cards_extras_de_parametros(self):
        ui = RecordingUI(decimais=[0.2], numeros=[123])
        self.experiencia.ui = ui
        self.experiencia.parametros_automaticos = False
        prompt = self.resultado_prompt().prompt

        ajustes = self.experiencia.configurar_chamada(
            motor.ETAPAS[0],
            prompt,
            "",
            {
                "temperature": 0.5,
                "max_tokens": 512,
            },
        )

        self.assertEqual(ajustes, {"temperature": 0.2, "max_tokens": 123})
        self.assertEqual(ui.cards, [])
        self.assertEqual(ui.cards_diretos, [])
        self.assertEqual(ui.cards_com_secoes, [])

    def test_configurar_parametros_variacoes_nao_cria_card_extra(self):
        ui = RecordingUI(decimais=[0.1, 0.2, 0.3, 0.4, 0.5], numeros=[10, 20, 30, 40, 50])
        self.experiencia.ui = ui

        self.experiencia.configurar_parametros_variacoes()

        self.assertEqual(ui.cards, [])
        self.assertEqual(ui.cards_diretos, [])
        self.assertEqual(ui.cards_com_secoes, [])
        self.assertEqual(
            sorted(self.experiencia.parametros_por_etapa),
            ["cta", "headline", "tagline", "tendencia_cognitiva", "voz_bb"],
        )

    def test_resumo_da_geracao_nao_renderiza_card(self):
        ui = RecordingUI()
        self.experiencia.ui = ui

        self.experiencia.mostrar_configuracao(
            SimpleNamespace(nome="cartao_ouro"),
            SimpleNamespace(nome="familia_estabelecida"),
            SimpleNamespace(nome="encaixe_de_valor"),
            SimpleNamespace(nome="AIDA"),
            100,
            25,
            True,
        )

        self.assertEqual(ui.cards, [])
        self.assertEqual(ui.cards_diretos, [])
        self.assertEqual(ui.cards_com_secoes, [])

    def test_apresentacao_preenche_somente_placeholders_ph_necessarios(self):
        produto = Produto(
            nome="produto",
            descricao="Produto",
            beneficio_racional="Racional",
            beneficio_emocional="Emocional",
            dados={
                "PH_SGT_DCR": "Produto",
                "descricao": "Informação que não é placeholder",
            },
        )
        publico = Publico(
            nome="publico",
            descricao="Público",
            necessidade_racional="Necessidade",
            necessidade_emocional="Desejo",
            dados={
                "PH_PBCO_DCR": "Público",
                "observacao": "Também não é placeholder",
            },
        )
        apresentacao = Apresentacao(
            nome="apresentacao",
            template="{PH_PBCO_DCR} encontra {PH_SGT_DCR}.",
            descricao="Teste",
        )

        previa = apresentacao.montar(produto, publico)

        self.assertEqual(previa["texto"], "Público encontra Produto.")
        self.assertEqual(
            previa["placeholders_necessarios"],
            ["PH_PBCO_DCR", "PH_SGT_DCR"],
        )
        self.assertEqual(
            previa["placeholders_usados"],
            ["PH_PBCO_DCR", "PH_SGT_DCR"],
        )
        self.assertEqual(
            [
                parte.get("placeholder")
                for parte in previa["partes"]
                if parte.get("tipo") == "valor"
            ],
            ["PH_PBCO_DCR", "PH_SGT_DCR"],
        )
        self.assertNotIn("descricao", previa["placeholders_disponiveis"])
        self.assertNotIn("observacao", previa["placeholders_disponiveis"])
        self.assertEqual(previa["placeholders_ausentes"], [])

    def test_placeholder_ph_extra_avisa_sem_quebrar_apresentacao(self):
        produto = Produto(
            nome="produto",
            descricao="Produto",
            beneficio_racional="Racional",
            beneficio_emocional="Emocional",
            dados={
                "PH_SGT_DCR": "Produto",
                "PH_SGT_EXTRA": "Extra",
            },
        )
        publico = Publico(
            nome="publico",
            descricao="Público",
            necessidade_racional="Necessidade",
            necessidade_emocional="Desejo",
            dados={"PH_PBCO_DCR": "Público"},
        )
        apresentacao = Apresentacao(
            nome="apresentacao",
            template="{PH_PBCO_DCR} encontra {PH_SGT_DCR}.",
            descricao="Teste",
        )

        previa = apresentacao.montar(produto, publico)

        self.assertEqual(previa["texto"], "Público encontra Produto.")
        self.assertEqual(previa["placeholders_nao_utilizados"], ["PH_SGT_EXTRA"])
        self.assertIn("PH_SGT_EXTRA", previa["avisos"][0])

    def test_card_apresentacao_mostra_aviso_de_placeholder_nao_utilizado(self):
        produto = Produto(
            nome="produto",
            descricao="Produto",
            beneficio_racional="Racional",
            beneficio_emocional="Emocional",
            dados={
                "PH_SGT_DCR": "Produto",
                "PH_SGT_EXTRA": "Extra",
            },
        )
        publico = Publico(
            nome="publico",
            descricao="Público",
            necessidade_racional="Necessidade",
            necessidade_emocional="Desejo",
            dados={"PH_PBCO_DCR": "Público"},
        )
        ui = RecordingUI(["apresentacao_teste"])
        self.experiencia.ui = ui
        apresentacao = Apresentacao(
            nome="apresentacao_teste",
            template="{PH_PBCO_DCR} encontra {PH_SGT_DCR}.",
            descricao="Teste",
        )

        with patch.object(motor, "carregar_apresentacao", return_value=apresentacao):
            self.experiencia.selecionar_apresentacao(produto, publico)

        campos = dict(ui.cards_diretos[0][1])
        self.assertIn("Avisos", campos)
        self.assertIn("PH_SGT_EXTRA", campos["Avisos"])

    def test_placeholder_da_apresentacao_ausente_bloqueia_geracao(self):
        produto = Produto(
            nome="produto",
            descricao="Produto",
            beneficio_racional="Racional",
            beneficio_emocional="Emocional",
            dados={"PH_SGT_DCR": "Produto"},
        )
        publico = Publico(
            nome="publico",
            descricao="Público",
            necessidade_racional="Necessidade",
            necessidade_emocional="Desejo",
            dados={},
        )
        apresentacao = Apresentacao(
            nome="apresentacao",
            template="{PH_PBCO_DCR} encontra {PH_SGT_DCR}.",
            descricao="Teste",
        )

        with self.assertRaises(ValueError) as contexto:
            apresentacao.montar(produto, publico)

        self.assertIn("PH_PBCO_DCR", str(contexto.exception))

    def test_selecao_de_resultado_usa_numero_do_card_exibido(self):
        primeiro = self.resultado_prompt(nome="p1", output="", opcao="")
        primeiro.erro = "Falha simulada"
        segundo = self.resultado_prompt(nome="p2", output="Texto 2", opcao="")
        terceiro = self.resultado_prompt(nome="p3", output="Texto 3", opcao="")
        etapa = ResultadoEtapa(
            id="revisor_textual",
            titulo="Revisor textual",
            entrada_comum="Entrada",
            resultados_prompt=[primeiro, segundo, terceiro],
        )
        self.experiencia.numeros_resultados = {
            id(primeiro): 1,
            id(segundo): 2,
            id(terceiro): 3,
        }
        ui = RecordingUI([3])
        self.experiencia.ui = ui

        escolhido = self.experiencia.escolher_resultado(
            etapa,
            [segundo, terceiro],
        )

        self.assertEqual(escolhido, terceiro.identificador)
        _, opcoes, kwargs = ui.opcoes_por_indice[0]
        self.assertEqual(
            opcoes,
            [
                (2, "p2", segundo.identificador),
                (3, "p3", terceiro.identificador),
            ],
        )
        self.assertEqual(kwargs["padrao"], 2)

    def test_etapa_concluida_nao_renderiza_bloco_selecao(self):
        primeiro = self.resultado_prompt(nome="p1", output="", opcao="")
        primeiro.erro = "Falha simulada"
        segundo = self.resultado_prompt(nome="p2", output="Texto 2", opcao="")
        terceiro = self.resultado_prompt(nome="p3", output="Texto 3", opcao="")
        terceiro.escolhido = True
        etapa = ResultadoEtapa(
            id="revisor_textual",
            titulo="Revisor textual",
            entrada_comum="Entrada",
            resultados_prompt=[primeiro, segundo, terceiro],
        )
        self.experiencia.numeros_resultados = {
            id(primeiro): 1,
            id(segundo): 2,
            id(terceiro): 3,
        }
        ui = RecordingUI()
        self.experiencia.ui = ui

        self.experiencia.mostrar_etapa_concluida(etapa)

        self.assertEqual(ui.secoes, [])
        self.assertEqual(ui.cards, [])
        self.assertEqual(ui.cards_diretos, [])
        self.assertEqual(ui.cards_com_secoes, [])

    def test_subcards_internos_iniciam_minimizados(self):
        subcards = "".join(
            self.ui._html_subcard(titulo, titulo)
            for titulo in [
                "Resultado",
                "System",
                "Template preenchido",
                "Payload",
            ]
        )
        html = self.ui.html_card_com_secoes(
            "p1",
            secoes=[
                {
                    "titulo": "Copywriter com Tendência",
                    "conteudo": subcards,
                    "conteudo_html": True,
                }
            ],
        )

        self.assertGreaterEqual(html.count("<details class='pc-nested-card"), 5)
        for titulo in [
            "Copywriter com Tendência",
            "Resultado",
            "System",
            "Template preenchido",
            "Payload",
        ]:
            self.assertIn(f"<summary>{titulo}</summary>", html)

        for trecho in html.split("<details class='pc-nested-card")[1:]:
            abertura = trecho.split(">", 1)[0]
            self.assertNotIn("open", abertura)

    def test_template_llm_tem_ordem_oficial(self):
        resultado = self.resultado_prompt()
        secoes = self.experiencia.secoes_resultado_llm(motor.ETAPAS[0], resultado)
        titulos = [secao["titulo"] for secao in secoes]

        self.assertEqual(
            titulos,
            ["Resultado (0.7; 100)", "Template preenchido", "System", "Payload"],
        )
        self.assertEqual(titulos[-1], "Payload")
        self.assertTrue(secoes[0]["aberto"])
        self.assertEqual(secoes[0]["conteudo"], "Texto gerado")
        self.assertNotIn("Temperatura", secoes[0]["conteudo"])
        self.assertNotIn("Max tokens", secoes[0]["conteudo"])
        self.assertNotIn("Resumo", titulos)
        self.assertNotIn("Entrada", titulos)
        self.assertTrue(secoes[-1]["conteudo_html"])
        self.assertIn("<pre class='pc-json'>", secoes[-1]["conteudo"])

    def test_card_execucao_usa_nome_yaml_e_resultado_aberto(self):
        resultado = self.resultado_prompt()
        html = self.ui.html_card_com_secoes(
            "p1",
            secoes=self.experiencia.secoes_resultado_llm(motor.ETAPAS[0], resultado),
        )

        self.assertIn("<div class='pc-card-title'>p1</div>", html)
        self.assertNotIn("Alternativa", html)
        self.assertNotIn("Pronto", html)
        ordem = [
            html.index("<summary>Resultado (0.7; 100)</summary>"),
            html.index("<summary>Template preenchido</summary>"),
            html.index("<summary>System</summary>"),
            html.index("<summary>Payload</summary>"),
        ]
        self.assertEqual(ordem, sorted(ordem))
        abertura_resultado = html.split(
            "<summary>Resultado (0.7; 100)</summary>",
            1,
        )[0]
        abertura_resultado = abertura_resultado.rsplit("<details", 1)[1]
        self.assertIn("open", abertura_resultado.split(">", 1)[0])
        self.assertEqual(ordem[-1], html.index("<summary>Payload</summary>"))

    def test_fluxo_feliz_nao_chama_abertura_preparacao_ou_base_criativa(self):
        fonte_rodar = inspect.getsource(Experiencia.rodar)
        fonte_inicio_linear = inspect.getsource(Experiencia.mostrar_inicio_fluxo_linear)

        self.assertNotIn(".titulo(", fonte_rodar)
        self.assertNotIn("mostrar_status(", fonte_rodar)
        self.assertNotIn("Prompt Criativo", fonte_rodar)
        self.assertNotIn("Preparação", fonte_rodar)
        self.assertNotIn("Base Criativa", fonte_inicio_linear)

    def test_secoes_principais_da_execucao_sao_exibidas(self):
        ui = RecordingUI()
        self.experiencia.ui = ui

        self.experiencia.mostrar_secao_execucao(motor.ETAPAS[0])
        self.experiencia.mostrar_secao_execucao(motor.ETAPAS[1])
        self.experiencia.indices_tendencias = {"Transformacao": 1}
        self.experiencia.mostrar_tendencia("Transformacao")
        self.experiencia.mostrar_resultado(
            SimpleNamespace(
                conjuntos=[],
                headline="Headline",
                tagline="Tagline",
                cta="CTA",
                resumo_institucional="Texto final",
            )
        )

        self.assertEqual(
            ui.secoes,
            [
                "Revisão Textual",
                "Copywriter",
                "1. Transformacao",
                "Resultado Final",
            ],
        )

    def test_inicio_loop_mostra_aplicacao_de_tendencia_sem_card_resumo(self):
        ui = RecordingUI()
        self.experiencia.ui = ui

        self.experiencia.mostrar_inicio_loop()

        self.assertEqual(ui.secoes, ["Aplicação de Tendência (10 tendências)"])
        self.assertEqual(ui.cards, [])
        self.assertEqual(ui.cards_diretos, [])
        self.assertEqual(ui.cards_com_secoes, [])
        self.assertEqual(self.experiencia.indices_tendencias["Afinidade"], 1)

    def test_tendencia_tem_subcards_por_etapa_na_ordem_oficial(self):
        conjunto = self.conjunto_completo()
        secoes = self.experiencia.secoes_tendencia_conjunto(conjunto)

        self.assertEqual(
            [secao["titulo"] for secao in secoes],
            ["Copywriter com Tendência", "Voz BB", "Texto", "Título", "CTA"],
        )

        for secao in secoes:
            with self.subTest(secao=secao["titulo"]):
                self.assertTrue(secao["conteudo_html"])
                conteudo = secao["conteudo"]
                ordem = [
                    conteudo.index("<summary>Resultado (0.7; 100)</summary>"),
                    conteudo.index("<summary>Template preenchido</summary>"),
                    conteudo.index("<summary>System</summary>"),
                    conteudo.index("<summary>Payload</summary>"),
                ]
                self.assertEqual(ordem, sorted(ordem))
                self.assertNotIn("<summary>Entrada</summary>", conteudo)
                abertura_resultado = conteudo.split(
                    "<summary>Resultado (0.7; 100)</summary>",
                    1,
                )[0]
                abertura_resultado = abertura_resultado.rsplit("<details", 1)[1]
                self.assertIn("open", abertura_resultado.split(">", 1)[0])
                self.assertEqual(
                    ordem[-1],
                    conteudo.index("<summary>Payload</summary>"),
                )

    def test_fluxo_conjunto_renderiza_um_card_em_camadas(self):
        ui = RecordingUI()
        self.experiencia.ui = ui
        conjunto = self.conjunto_completo()

        self.experiencia.mostrar_fluxo_conjunto(conjunto, 1)

        self.assertEqual(ui.cards, [])
        self.assertEqual(len(ui.cards_com_secoes), 1)
        (
            titulo,
            campos_topo,
            secoes,
            detalhes_tecnicos,
            campos_rodape,
            _,
        ) = ui.cards_com_secoes[0]
        self.assertEqual(titulo, "p1")
        self.assertIsNone(campos_topo)
        self.assertIsNotNone(campos_rodape)
        self.assertEqual(campos_rodape[0][0], None)
        componente = campos_rodape[0][1]
        self.assertTrue(componente["conteudo_html"])
        self.assertTrue(componente["sem_wrapper"])
        self.assertIn("pc-final-shell", componente["conteudo"])
        self.assertIn("pc-final-overlay-radio", componente["conteudo"])
        self.assertIn("pc-final-simple-radio", componente["conteudo"])
        self.assertIn("checked", componente["conteudo"])
        self.assertIn(">Overlay</label>", componente["conteudo"])
        self.assertIn(">Simple</label>", componente["conteudo"])
        self.assertIn("pc-final-preview", componente["conteudo"])
        self.assertIn("pc-final-close", componente["conteudo"])
        self.assertIn("pc-final-title", componente["conteudo"])
        self.assertIn("Resultado headline", componente["conteudo"])
        self.assertIn("pc-final-message", componente["conteudo"])
        self.assertIn("Resultado tagline", componente["conteudo"])
        self.assertIn("pc-final-cta", componente["conteudo"])
        self.assertEqual(componente["conteudo"].count("class='pc-final-cta'"), 1)
        self.assertIn("Resultado cta", componente["conteudo"])
        self.assertIsNone(detalhes_tecnicos)
        self.assertEqual(
            [secao["titulo"] for secao in secoes],
            ["Copywriter com Tendência", "Voz BB", "Texto", "Título", "CTA"],
        )

    def test_card_final_usa_grupos_de_toggle_independentes(self):
        primeiro = self.conjunto_completo()
        segundo = self.conjunto_completo()
        segundo.id = "2"
        segundo.tendencia = "Escassez"

        html_primeiro = self.experiencia.html_componente_resultado_final(primeiro)
        html_segundo = self.experiencia.html_componente_resultado_final(segundo)

        self.assertIn("name='pc-final-style-1-afinidade'", html_primeiro)
        self.assertIn("name='pc-final-style-2-escassez'", html_segundo)
        self.assertNotIn("pc-final-style-2-escassez", html_primeiro)
        self.assertNotIn("pc-final-style-1-afinidade", html_segundo)

    def test_card_final_trunca_cta_visual_sem_alterar_terminal(self):
        conjunto = self.conjunto_completo()
        for resultado in conjunto.resultados:
            if resultado.prompt.grupo == "7_cta":
                resultado.output = "Consultar beneficios agora"

        html = self.experiencia.html_componente_resultado_final(conjunto)
        terminal = self.experiencia.texto_componente_resultado_final(conjunto)

        self.assertIn("Consultar beneficios\u2026", html)
        self.assertNotIn(">Consultar beneficios agora<", html)
        self.assertIn("Consultar beneficios agora", terminal)

    def test_css_card_final_define_limites_de_linha(self):
        fonte = inspect.getsource(Visual.aplicar_estilo)

        self.assertIn(".pc-final-title", fonte)
        self.assertIn("-webkit-line-clamp: 3", fonte)
        self.assertIn(".pc-final-message", fonte)
        self.assertIn("-webkit-line-clamp: 5", fonte)

    def test_css_geral_usa_tokens_do_padrao_simple(self):
        fonte = inspect.getsource(Visual.aplicar_estilo)

        self.assertIn("--pc-simple-bg: #f3f6ff", fonte)
        self.assertIn("--pc-simple-border: #d2d8e2", fonte)
        self.assertIn("--pc-simple-title: #25282c", fonte)
        self.assertIn("--pc-simple-text: #747b86", fonte)
        self.assertIn("background: var(--pc-simple-bg)", fonte)
        self.assertIn("border: 1px solid var(--pc-simple-border)", fonte)
        self.assertIn("background: var(--pc-simple-cta-bg)", fonte)
        self.assertIn("background: var(--pc-overlay-bg)", fonte)

    def test_componente_final_do_conjunto_nao_cria_acordeao(self):
        conjunto = self.conjunto_completo()
        campos_rodape = self.experiencia.campos_rodape_conjunto(conjunto)
        html = self.ui.html_card_com_secoes(
            "p1",
            secoes=self.experiencia.secoes_tendencia_conjunto(conjunto),
            campos_rodape=campos_rodape,
        )

        trecho_componente = html.split("<div class='pc-final-preview'>", 1)[1]
        trecho_componente = trecho_componente.split(
            "<details class='pc-nested-card",
            1,
        )[0]

        self.assertIn("Resultado headline", trecho_componente)
        self.assertIn("Resultado tagline", trecho_componente)
        self.assertIn("Resultado cta", trecho_componente)
        self.assertNotIn("<summary>", trecho_componente)
        self.assertGreater(
            html.index("<div class='pc-final-preview'>"),
            html.rindex("<details class='pc-nested-card"),
        )

    def test_rotulos_publicos_e_catalogos_usam_acentos(self):
        self.assertEqual(self.experiencia.rotulo_nome("cartao_ouro"), "Cartão Ouro")
        self.assertEqual(
            self.experiencia.rotulo_nome("familia_estabelecida"),
            "Família Estabelecida",
        )
        self.assertEqual(self.experiencia.rotulo_nome("Transformacao"), "Transformação")
        self.assertEqual(self.experiencia.rotulo_nome("AIDA"), "AIDA")
        self.assertEqual(
            self.experiencia.rotulo_etapa("revisor_textual"),
            "Revisão Textual",
        )
        self.assertEqual(self.experiencia.rotulo_prompt("p1"), "p1")

    def test_referencia_yaml_remove_caminho_extensao_e_opcao(self):
        nome_yaml = "prompt_custom"

        self.assertEqual(
            self.experiencia.rotulo_prompt(
                rf"prompts\3_tendencia_cognitiva\{nome_yaml}.yaml - Transformacao"
            ),
            nome_yaml,
        )
        self.assertEqual(
            self.experiencia.rotulo_prompt(f"prompts/5_tagline/{nome_yaml}.yml"),
            nome_yaml,
        )

    def test_tendencia_em_titulo_usa_nome_yaml_cru(self):
        resultado = self.resultado_prompt(
            grupo="3_tendencia_cognitiva",
            nome="prompt_teste",
            opcao="Transformacao",
        )
        etapa = motor.ETAPAS[2]

        titulo = self.experiencia.titulo_execucao(etapa, resultado)

        self.assertIn("Transformacao", titulo)
        self.assertNotIn(self.experiencia.rotulo_nome("Transformacao"), titulo)

    def test_pipeline_tendencia_na_ordem_oficial(self):
        conjunto = self.conjunto_completo()
        pipeline = self.experiencia.pipeline_conjunto(conjunto)
        esperado = [
            "Copywriter com Tendência p1",
            "Voz BB p1",
            "Texto p1",
            "Título p1",
            "CTA p1",
        ]

        posicoes = [pipeline.index(item) for item in esperado]
        self.assertEqual(posicoes, sorted(posicoes))

    def test_titulo_conjunto_exige_nome_de_yaml(self):
        conjunto = ConjuntoGerado(
            id="sem_prompt",
            contexto={},
            tendencia="Transformacao",
            prompts={},
            resultados=[],
        )

        with self.assertRaises(ValueError):
            self.experiencia.titulo_card_conjunto(conjunto)


if __name__ == "__main__":
    unittest.main()
