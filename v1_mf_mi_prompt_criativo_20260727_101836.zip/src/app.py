"""Experiencia guiada do notebook."""

from __future__ import annotations

import html
import importlib
import importlib.util
import json
import re
import sys
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


DEPENDENCIAS_BASE = {"yaml": "PyYAML"}
DEPENDENCIAS_OFICIAIS = {
    "dotenv": "python-dotenv",
    "requests": "requests",
    "urllib3": "urllib3",
}
DEPENDENCIAS_OLLAMA = {"requests": "requests"}


try:
    from IPython.display import HTML, Markdown, display
    from IPython import get_ipython
except Exception:
    HTML = None
    Markdown = None
    display = None
    get_ipython = None


@dataclass
class StatusAmbiente:
    raiz: Path
    python: str
    provedor: str
    dependencias_ausentes: list[str] = field(default_factory=list)


@dataclass
class FalhaFluxo:
    tipo: str
    erro: str

    @property
    def ok(self) -> bool:
        return False

    def __bool__(self) -> bool:
        return False

    def __repr__(self) -> str:
        return "Erro: " + self.erro

    def __str__(self) -> str:
        return self.erro


def raiz_projeto(inicio: Optional[Path] = None) -> Path:
    atual = Path(inicio or Path.cwd()).resolve()

    for pasta in [atual] + list(atual.parents):
        if (
            (pasta / "produtos").exists()
            and (pasta / "publicos").exists()
            and (pasta / "prompts").exists()
        ):
            return pasta

    raise RuntimeError("Nao foi possivel localizar a raiz do projeto.")


def dependencias_ausentes(dependencias: dict[str, str]) -> list[str]:
    ausentes = []

    for modulo, pacote in dependencias.items():
        if importlib.util.find_spec(modulo) is None:
            ausentes.append(pacote)

    return sorted(set(ausentes))


def normalizar_provedor(provedor: Optional[str]) -> Optional[str]:
    if provedor is None:
        return None

    valor = str(provedor).strip().lower()

    if valor == "ollama":
        return "ollama"

    raise ValueError(
        "Provedor invalido: "
        + str(provedor)
        + "\n\nValores aceitos:\n"
        + "- nenhum argumento, para usar o Genera oficial;\n"
        + '- "ollama", para usar o testador local.'
    )


def preparar_ambiente(provedor: Optional[str]) -> StatusAmbiente:
    raiz = raiz_projeto()

    if str(raiz) not in sys.path:
        sys.path.insert(0, str(raiz))

    dependencias = dict(DEPENDENCIAS_BASE)
    nome_provedor = "Genera oficial"

    if provedor == "ollama":
        dependencias.update(DEPENDENCIAS_OLLAMA)
        nome_provedor = "Ollama local"
    else:
        dependencias.update(DEPENDENCIAS_OFICIAIS)

    return StatusAmbiente(
        raiz=raiz,
        python=".".join(str(parte) for parte in sys.version_info[:3]),
        provedor=nome_provedor,
        dependencias_ausentes=dependencias_ausentes(dependencias),
    )


def resolver_criador_provedor(provedor: Optional[str]) -> Any:
    if provedor is None:
        from .modelos import Genera

        return Genera

    if provedor == "ollama":
        try:
            modulo = importlib.import_module("src.ollama_local")
        except ModuleNotFoundError as erro:
            if erro.name == "src.ollama_local":
                raise RuntimeError(
                    "O testador local Ollama nao esta disponivel.\n\n"
                    "Arquivo esperado:\n"
                    "src/ollama_local.py\n\n"
                    "O fluxo oficial continua disponivel por meio de fluxo_geracao()."
                )
            raise

        if not hasattr(modulo, "ollama"):
            raise RuntimeError(
                "O arquivo src/ollama_local.py deve exportar um objeto chamado ollama."
            )

        if hasattr(modulo, "verificar_disponivel"):
            modulo.verificar_disponivel()

        return getattr(modulo, "ollama")

    raise ValueError("Provedor invalido.")


def em_notebook() -> bool:
    if display is None or get_ipython is None:
        return False

    shell = get_ipython()
    return shell is not None and shell.__class__.__name__ == "ZMQInteractiveShell"


def texto_curto(texto: Any, largura: int = 88) -> str:
    linhas = []

    for linha in str(texto or "").splitlines():
        valor = " ".join(linha.strip().split())

        if not valor:
            linhas.append("")
            continue

        indentacao = ""
        marcador = re.match(r"^(\s*(?:[-*]|\d+[.])\s+)", linha)
        if marcador:
            indentacao = " " * len(marcador.group(1))

        linhas.append(
            textwrap.fill(
                valor,
                width=largura,
                subsequent_indent=indentacao,
            )
        )

    return "\n".join(linhas).strip()


class Visual:
    def aplicar_estilo(self) -> None:
        if not em_notebook() or HTML is None:
            return

        display(
            HTML(
                """
                <style>
                .pc-wrap {
                    --pc-simple-bg: #f3f6ff;
                    --pc-simple-bg-soft: #f8faff;
                    --pc-simple-border: #d2d8e2;
                    --pc-simple-divider: #e7ebf2;
                    --pc-simple-title: #25282c;
                    --pc-simple-text: #747b86;
                    --pc-simple-icon: #858e99;
                    --pc-simple-cta-bg: #e2e9ff;
                    --pc-simple-cta-text: #1f4dff;
                    --pc-overlay-bg: #4667ff;
                    --pc-overlay-cta-bg: #fff423;
                    max-width: 980px;
                    font-family: Arial, sans-serif;
                    color: var(--pc-simple-title);
                }
                .pc-hero {
                    border: 1px solid var(--pc-simple-border);
                    border-left: 4px solid var(--pc-simple-cta-text);
                    border-radius: 8px;
                    padding: 14px 18px;
                    background: var(--pc-simple-bg);
                    margin: 8px 0 18px;
                }
                .pc-section {
                    margin: 18px 0 8px;
                    padding-bottom: 4px;
                    border-bottom: 1px solid var(--pc-simple-border);
                    color: var(--pc-simple-title);
                    font-size: 20px;
                    font-weight: 700;
                }
                .pc-card {
                    border: 1px solid var(--pc-simple-border);
                    border-radius: 8px;
                    margin: 24px 0;
                    background: var(--pc-simple-bg);
                    box-shadow: none;
                }
                .pc-card > summary {
                    cursor: pointer;
                    list-style: none;
                }
                .pc-card > summary::-webkit-details-marker {
                    display: none;
                }
                .pc-card > summary .pc-card-title:before {
                    content: "+";
                    display: inline-block;
                    width: 20px;
                    color: var(--pc-simple-icon);
                }
                .pc-card[open] > summary .pc-card-title:before {
                    content: "-";
                }
                .pc-card-title {
                    padding: 16px 18px;
                    font-size: 20px;
                    font-weight: 800;
                    line-height: 1.3;
                    color: var(--pc-simple-title);
                }
                .pc-card-body {
                    padding: 0 18px 18px;
                }
                .pc-card-highlight {
                    border-color: var(--pc-simple-border);
                    background: var(--pc-simple-bg);
                }
                .pc-field {
                    margin: 16px 0 0;
                }
                .pc-field:first-child {
                    margin-top: 8px;
                }
                .pc-lead {
                    font-size: 17px;
                    font-weight: 800;
                    line-height: 1.45;
                    color: var(--pc-simple-title);
                    margin: 8px 0 16px;
                }
                .pc-label {
                    font-size: 12px;
                    font-weight: 700;
                    letter-spacing: 0;
                    text-transform: uppercase;
                    color: var(--pc-simple-text);
                    margin-bottom: 6px;
                }
                .pc-value {
                    color: var(--pc-simple-text);
                    white-space: pre-wrap;
                    line-height: 1.55;
                    max-width: 88ch;
                }
                .pc-template-preview {
                    max-width: 88ch;
                    line-height: 1.72;
                    white-space: normal;
                }
                .pc-template-value {
                    display: inline;
                    background: var(--pc-simple-cta-bg);
                    border: 1px solid var(--pc-simple-border);
                    border-radius: 4px;
                    color: var(--pc-simple-cta-text);
                    padding: 1px 4px;
                    box-decoration-break: clone;
                    -webkit-box-decoration-break: clone;
                }
                .pc-template-ph {
                    color: var(--pc-simple-cta-text);
                    font-family: Consolas, Monaco, monospace;
                    font-size: .78em;
                    font-weight: 700;
                    margin-right: 4px;
                }
                .pc-muted {
                    color: var(--pc-simple-text);
                    font-size: 13px;
                }
                .pc-nested-card {
                    border: 1px solid var(--pc-simple-border);
                    border-radius: 8px;
                    margin: 12px 0;
                    background: var(--pc-simple-bg-soft);
                }
                .pc-nested-card > summary {
                    cursor: pointer;
                    list-style: none;
                    padding: 12px 14px;
                    font-weight: 800;
                    color: var(--pc-simple-title);
                }
                .pc-nested-card > summary::-webkit-details-marker {
                    display: none;
                }
                .pc-nested-card > summary:before {
                    content: "+";
                    display: inline-block;
                    width: 18px;
                    color: var(--pc-simple-icon);
                }
                .pc-nested-card[open] > summary:before {
                    content: "-";
                }
                .pc-nested-body {
                    border-top: 1px solid var(--pc-simple-divider);
                    padding: 12px 14px 14px;
                }
                .pc-nested-compact {
                    background: var(--pc-simple-bg);
                }
                .pc-inner {
                    border-top: 1px solid var(--pc-simple-divider);
                    padding: 16px 0 0;
                    margin: 18px 0 0;
                }
                .pc-inner > summary,
                .pc-technical > summary {
                    cursor: pointer;
                    font-weight: 700;
                    list-style: none;
                    color: var(--pc-simple-title);
                }
                .pc-inner > summary::-webkit-details-marker,
                .pc-technical > summary::-webkit-details-marker {
                    display: none;
                }
                .pc-inner > summary:before,
                .pc-technical > summary:before {
                    content: "+";
                    display: inline-block;
                    width: 18px;
                    color: var(--pc-simple-icon);
                }
                .pc-inner[open] > summary:before,
                .pc-technical[open] > summary:before {
                    content: "-";
                }
                .pc-technical {
                    border-top: 1px solid var(--pc-simple-border);
                    margin: 22px 0 0;
                    padding: 16px 0 0;
                }
                .pc-technical .pc-hide {
                    display: none;
                }
                .pc-technical[open] .pc-show {
                    display: none;
                }
                .pc-technical[open] .pc-hide {
                    display: inline;
                }
                .pc-subsection {
                    border-top: 1px solid var(--pc-simple-divider);
                    margin-top: 18px;
                    padding-top: 18px;
                }
                .pc-subsection:first-child {
                    border-top: 0;
                    margin-top: 8px;
                    padding-top: 0;
                }
                .pc-subtitle {
                    font-size: 16px;
                    font-weight: 800;
                    color: var(--pc-simple-title);
                    margin: 0 0 10px;
                }
                .pc-stage {
                    border-left: 3px solid var(--pc-simple-border);
                    padding-left: 12px;
                    margin: 14px 0;
                }
                .pc-stage-title {
                    font-weight: 700;
                    margin-bottom: 8px;
                }
                .pc-output-list {
                    padding-top: 2px;
                }
                .pc-output-item {
                    border-top: 1px solid var(--pc-simple-divider);
                    padding: 18px 0 20px;
                    margin: 0;
                }
                .pc-output-item:first-child {
                    border-top: 0;
                    padding-top: 8px;
                }
                .pc-output-title {
                    font-size: 18px;
                    font-weight: 800;
                    line-height: 1.3;
                    color: var(--pc-simple-title);
                    margin: 0 0 12px;
                }
                .pc-output-text {
                    white-space: pre-wrap;
                    line-height: 1.55;
                    font-size: 15px;
                    color: var(--pc-simple-text);
                    max-width: 88ch;
                }
                .pc-output-main .pc-output-title {
                    font-size: 20px;
                    margin-bottom: 14px;
                }
                .pc-output-main .pc-output-text {
                    font-size: 16px;
                }
                .pc-output-compact {
                    background: var(--pc-simple-bg-soft);
                    border: 1px solid var(--pc-simple-border);
                    border-radius: 8px;
                    padding: 12px 14px;
                    margin: 12px 0;
                }
                .pc-output-compact .pc-output-title {
                    font-size: 14px;
                    margin-bottom: 6px;
                }
                .pc-final-shell {
                    max-width: 344px;
                    margin: 4px 0 14px;
                    position: relative;
                }
                .pc-final-radio {
                    height: 1px;
                    opacity: 0;
                    pointer-events: none;
                    position: absolute;
                    width: 1px;
                }
                .pc-final-toggle {
                    border: 1px solid var(--pc-simple-border);
                    border-radius: 6px;
                    display: inline-flex;
                    gap: 2px;
                    margin: 0 0 8px;
                    padding: 2px;
                }
                .pc-final-toggle-option {
                    border-radius: 4px;
                    color: var(--pc-simple-text);
                    cursor: pointer;
                    font-size: 12px;
                    font-weight: 800;
                    line-height: 1.2;
                    padding: 6px 10px;
                }
                .pc-final-overlay-radio:checked
                    ~ .pc-final-toggle .pc-final-toggle-overlay {
                    background: var(--pc-overlay-bg);
                    color: #ffffff;
                }
                .pc-final-simple-radio:checked
                    ~ .pc-final-toggle .pc-final-toggle-simple {
                    background: var(--pc-simple-cta-bg);
                    color: var(--pc-simple-cta-text);
                }
                .pc-final-preview {
                    background: var(--pc-overlay-bg);
                    border: 1px solid var(--pc-overlay-bg);
                    border-radius: 8px;
                    box-sizing: border-box;
                    color: #ffffff;
                    padding: 16px;
                    position: relative;
                    width: 100%;
                }
                .pc-final-simple-radio:checked ~ .pc-final-preview {
                    background: var(--pc-simple-bg);
                    border-color: var(--pc-simple-border);
                    color: var(--pc-simple-title);
                }
                .pc-final-title,
                .pc-final-message {
                    display: -webkit-box;
                    overflow: hidden;
                    -webkit-box-orient: vertical;
                }
                .pc-final-title {
                    -webkit-line-clamp: 3;
                    line-clamp: 3;
                    color: inherit;
                    font-size: 18px;
                    font-weight: 800;
                    line-height: 1.28;
                    margin: 0 28px 8px 0;
                    text-overflow: ellipsis;
                    white-space: normal;
                }
                .pc-final-message {
                    -webkit-line-clamp: 5;
                    line-clamp: 5;
                    color: rgba(255, 255, 255, .86);
                    font-size: 15px;
                    line-height: 1.45;
                    margin: 0 0 14px;
                    text-overflow: ellipsis;
                    white-space: normal;
                }
                .pc-final-simple-radio:checked ~ .pc-final-preview .pc-final-message {
                    color: var(--pc-simple-text);
                }
                .pc-final-close {
                    color: rgba(255, 255, 255, .92);
                    font-size: 24px;
                    font-weight: 700;
                    line-height: 1;
                    position: absolute;
                    right: 14px;
                    top: 12px;
                }
                .pc-final-simple-radio:checked ~ .pc-final-preview .pc-final-close {
                    color: var(--pc-simple-icon);
                }
                .pc-final-cta {
                    background: var(--pc-overlay-cta-bg);
                    border-radius: 5px;
                    box-sizing: border-box;
                    color: var(--pc-simple-cta-text);
                    display: block;
                    font-size: 12px;
                    font-weight: 800;
                    line-height: 1.2;
                    overflow-wrap: anywhere;
                    padding: 10px 12px;
                    text-align: center;
                    text-transform: uppercase;
                    white-space: normal;
                    width: 100%;
                }
                .pc-final-simple-radio:checked ~ .pc-final-preview .pc-final-cta {
                    background: var(--pc-simple-cta-bg);
                }
                .pc-pipeline {
                    display: grid;
                    gap: 7px;
                    margin-top: 6px;
                    max-width: 48ch;
                }
                .pc-pipeline-step {
                    display: grid;
                    grid-template-columns: 22px 1fr;
                    align-items: start;
                    line-height: 1.45;
                }
                .pc-pipeline-marker {
                    color: var(--pc-simple-icon);
                }
                .pc-json {
                    max-width: 100%;
                    overflow: auto;
                    white-space: pre-wrap;
                    background: #111827;
                    color: #f9fafb;
                    padding: 12px;
                    border-radius: 8px;
                    line-height: 1.45;
                }
                code {
                    background: var(--pc-simple-cta-bg);
                    border-radius: 4px;
                    color: var(--pc-simple-cta-text);
                    padding: 1px 4px;
                    font-family: Consolas, Monaco, monospace;
                    font-size: .95em;
                }
                .pc-progress {
                    border: 1px solid var(--pc-simple-border);
                    border-radius: 8px;
                    margin: 10px 0;
                    padding: 14px 16px;
                    background: var(--pc-simple-bg);
                }
                .pc-progress-title {
                    color: var(--pc-simple-title);
                    font-weight: 700;
                    margin-bottom: 4px;
                }
                .pc-progress-status {
                    color: var(--pc-simple-text);
                    font-size: 13px;
                    margin-bottom: 10px;
                    line-height: 1.45;
                }
                .pc-progress-track {
                    height: 10px;
                    border-radius: 999px;
                    background: var(--pc-simple-divider);
                    overflow: hidden;
                }
                .pc-progress-fill {
                    height: 100%;
                    border-radius: 999px;
                    background: var(--pc-simple-cta-text);
                    transition: width .25s ease;
                }
                .pc-progress-count {
                    color: var(--pc-simple-text);
                    font-size: 12px;
                    margin-top: 8px;
                }
                </style>
                """
            )
        )

    def titulo(self, texto: str, apoio: Optional[str] = None) -> None:
        if em_notebook() and HTML is not None:
            apoio_html = (
                f"<div class='pc-muted'>{html.escape(apoio)}</div>" if apoio else ""
            )
            display(
                HTML(
                    "<div class='pc-wrap pc-hero'>"
                    f"<h1 style='margin:0 0 6px'>{html.escape(texto)}</h1>"
                    f"{apoio_html}"
                    "</div>"
                )
            )
            return

        print("\n" + "=" * 80)
        print(texto.upper())
        if apoio:
            print(apoio)
        print("=" * 80)

    def secao(self, texto: str) -> None:
        if em_notebook() and HTML is not None:
            display(HTML(f"<div class='pc-wrap pc-section'>{html.escape(texto)}</div>"))
            return

        print("\n" + texto.upper())
        print("-" * len(texto))

    def _lista_campos(
        self,
        campos: Optional[Any],
    ) -> list[tuple[Optional[str], Any]]:
        if not campos:
            return []
        if isinstance(campos, dict):
            return list(campos.items())
        return list(campos)

    def _valor_html(self, valor: Any) -> str:
        conteudo = html.escape(str(valor or ""))

        def codigo(encontrado: re.Match[str]) -> str:
            return f"<code>{encontrado.group(1)}</code>"

        return re.sub(r"`([^`]+)`", codigo, conteudo)

    def _campo_html(self, valor: Any) -> str:
        if isinstance(valor, dict) and valor.get("conteudo_html"):
            return str(valor.get("conteudo", ""))

        return self._valor_html(valor)

    def _campo_rico(self, valor: Any) -> bool:
        return isinstance(valor, dict) and bool(
            {"conteudo", "conteudo_html", "texto_terminal"} & set(valor)
        )

    def _campo_terminal(self, valor: Any) -> Any:
        if isinstance(valor, dict) and "texto_terminal" in valor:
            return valor["texto_terminal"]

        if isinstance(valor, dict) and valor.get("conteudo_html"):
            return valor.get("conteudo", "")

        return valor

    def html_apresentacao_preenchida(self, partes: list[dict[str, Any]]) -> str:
        trechos = []

        for parte in partes:
            texto = html.escape(str(parte.get("texto", "")))
            if parte.get("tipo") != "valor":
                trechos.append(texto)
                continue

            trechos.append(
                f"<span class='pc-template-value'>{texto}</span>"
            )

        return "<div class='pc-template-preview'>" + "".join(trechos) + "</div>"

    def texto_apresentacao_preenchida(self, partes: list[dict[str, Any]]) -> str:
        trechos = []

        for parte in partes:
            texto = str(parte.get("texto", ""))
            trechos.append(texto)

        return " ".join("".join(trechos).split())

    def _html_subcard(
        self,
        titulo: str,
        conteudo: Any,
        *,
        compacto: bool = False,
        conteudo_html: bool = False,
        aberto: bool = False,
    ) -> str:
        classe = "pc-nested-card"
        if compacto:
            classe += " pc-nested-compact"

        corpo = str(conteudo or "") if conteudo_html else self._valor_html(conteudo)
        atributo_aberto = " open" if aberto else ""
        return (
            f"<details class='{classe}'{atributo_aberto}>"
            f"<summary>{html.escape(str(titulo))}</summary>"
            "<div class='pc-nested-body'>"
            f"<div class='pc-value'>{corpo}</div>"
            "</div></details>"
        )

    def _html_campos(self, campos: Optional[Any]) -> str:
        partes = []

        for chave, valor in self._lista_campos(campos):
            if chave in {None, ""}:
                if isinstance(valor, dict) and valor.get("sem_wrapper"):
                    partes.append(self._campo_html(valor))
                    continue

                partes.append(
                    "<div class='pc-lead'>"
                    + self._campo_html(valor)
                    + "</div>"
                )
                continue

            campo_rico = self._campo_rico(valor)
            partes.append(
                self._html_subcard(
                    str(chave),
                    valor.get("conteudo", "") if campo_rico else valor,
                    conteudo_html=bool(
                        campo_rico and valor.get("conteudo_html")
                    ),
                )
            )

        return "".join(partes)

    def _html_campos_diretos(self, campos: Optional[Any]) -> str:
        partes = []

        for chave, valor in self._lista_campos(campos):
            if chave in {None, ""}:
                partes.append(
                    "<div class='pc-lead'>"
                    + self._campo_html(valor)
                    + "</div>"
                )
                continue

            partes.append(
                "<div class='pc-field'>"
                f"<div class='pc-label'>{html.escape(str(chave))}</div>"
                f"<div class='pc-value'>{self._campo_html(valor)}</div>"
                "</div>"
            )

        return "".join(partes)

    def _html_secao(self, titulo: str, conteudo: Any, *, compacto: bool = False) -> str:
        return self._html_subcard(titulo, conteudo, compacto=compacto)

    def _html_secao_dict(self, secao: dict[str, Any]) -> str:
        titulo = str(secao.get("titulo", ""))
        conteudo = secao.get("conteudo", "")
        return self._html_subcard(
            titulo,
            conteudo,
            compacto=bool(secao.get("compacto")),
            conteudo_html=bool(secao.get("conteudo_html")),
            aberto=bool(secao.get("aberto")),
        )

    def html_card(
        self,
        titulo: str,
        campos: Optional[Any] = None,
        *,
        destaque: bool = False,
    ) -> str:
        classe = "pc-wrap pc-card"
        if destaque:
            classe += " pc-card-highlight"

        return (
            f"<details class='{classe}'>"
            "<summary>"
            f"<div class='pc-card-title'>{html.escape(str(titulo))}</div>"
            "</summary>"
            "<div class='pc-card-body'>"
            + self._html_campos(campos)
            + "</div></details>"
        )

    def html_card_direto(
        self,
        titulo: str,
        campos: Optional[Any] = None,
        *,
        destaque: bool = False,
    ) -> str:
        classe = "pc-wrap pc-card"
        if destaque:
            classe += " pc-card-highlight"

        return (
            f"<details class='{classe}'>"
            "<summary>"
            f"<div class='pc-card-title'>{html.escape(str(titulo))}</div>"
            "</summary>"
            "<div class='pc-card-body'>"
            + self._html_campos_diretos(campos)
            + "</div></details>"
        )

    def card(
        self,
        titulo: str,
        campos: Optional[Any] = None,
        *,
        aberto: bool = True,
        destaque: bool = False,
    ) -> None:
        if em_notebook() and HTML is not None:
            display(HTML(self.html_card(titulo, campos, destaque=destaque)))
            return

        self._imprimir_card(titulo, campos, destaque=destaque)

    def card_direto(
        self,
        titulo: str,
        campos: Optional[Any] = None,
        *,
        destaque: bool = False,
    ) -> None:
        if em_notebook() and HTML is not None:
            display(HTML(self.html_card_direto(titulo, campos, destaque=destaque)))
            return

        self._imprimir_card(titulo, campos, destaque=destaque)

    def _imprimir_card(
        self,
        titulo: str,
        campos: Optional[Any] = None,
        *,
        destaque: bool = False,
    ) -> None:
        marcador = "=" if destaque else "-"
        print("\n" + marcador * 80)
        print(str(titulo).upper())
        print(marcador * 80)

        self._imprimir_campos(campos)

    def _imprimir_campos(self, campos: Optional[Any]) -> None:
        for chave, valor in self._lista_campos(campos):
            if chave in {None, ""}:
                print("\n" + texto_curto(self._campo_terminal(valor)))
                continue

            print(f"\n{chave}")
            print()
            print(texto_curto(self._campo_terminal(valor)))

    def _secoes_ordenadas(self, secoes: Optional[Any]) -> list[dict[str, Any]]:
        itens = []
        for secao in secoes or []:
            if isinstance(secao, dict):
                itens.append(dict(secao))
            else:
                titulo, conteudo = secao
                itens.append({"titulo": titulo, "conteudo": conteudo})
        return itens

    def texto_json(self, dados: Any) -> str:
        return json.dumps(dados, indent=2, ensure_ascii=False, default=str)

    def json_bloco(self, dados: Any) -> str:
        return (
            "<pre class='pc-json'>"
            + html.escape(self.texto_json(dados))
            + "</pre>"
        )

    def _detalhes_ordenados(self, conteudo: Optional[Any]) -> list[dict[str, Any]]:
        secoes = self._secoes_ordenadas(conteudo)
        payloads = [
            secao
            for secao in secoes
            if str(secao.get("titulo", "")).strip().lower()
            in {"payload llm", "payload"}
        ]
        outros = [secao for secao in secoes if secao not in payloads]
        return outros + payloads

    def detalhes_tecnicos(self, conteudo: Optional[Any]) -> str:
        secoes = self._detalhes_ordenados(conteudo)
        if not secoes:
            return ""

        partes = []
        for secao in secoes:
            titulo = str(secao.get("titulo", ""))
            valor = secao.get("conteudo", "")
            if titulo in {"Payload LLM", "Payload"}:
                corpo = self.json_bloco(valor)
                partes.append(
                    self._html_subcard(
                        titulo,
                        corpo,
                        conteudo_html=True,
                    )
                )
                continue

            partes.append(self._html_secao(titulo, valor))

        return (
            "<details class='pc-technical'>"
            "<summary>"
            "<span class='pc-show'>Ver detalhes técnicos</span>"
            "<span class='pc-hide'>Ocultar detalhes técnicos</span>"
            "</summary>"
            + "".join(partes)
            + "</details>"
        )

    def html_card_com_secoes(
        self,
        titulo: str,
        campos_topo: Optional[Any] = None,
        secoes: Optional[Any] = None,
        detalhes_tecnicos: Optional[Any] = None,
        campos_rodape: Optional[Any] = None,
        *,
        destaque: bool = False,
    ) -> str:
        classe = "pc-wrap pc-card"
        if destaque:
            classe += " pc-card-highlight"

        partes = [self._html_campos(campos_topo)]

        for secao in self._secoes_ordenadas(secoes):
            partes.append(self._html_secao_dict(secao))

        partes.append(self._html_campos(campos_rodape))
        partes.append(self.detalhes_tecnicos(detalhes_tecnicos))

        return (
            f"<details class='{classe}'>"
            "<summary>"
            f"<div class='pc-card-title'>{html.escape(str(titulo))}</div>"
            "</summary>"
            "<div class='pc-card-body'>"
            + "".join(partes)
            + "</div></details>"
        )

    def card_com_secoes(
        self,
        titulo: str,
        campos_topo: Optional[Any] = None,
        secoes: Optional[Any] = None,
        detalhes_tecnicos: Optional[Any] = None,
        campos_rodape: Optional[Any] = None,
        *,
        destaque: bool = False,
    ) -> None:
        if em_notebook() and HTML is not None:
            display(
                HTML(
                    self.html_card_com_secoes(
                        titulo,
                        campos_topo,
                        secoes,
                        detalhes_tecnicos,
                        campos_rodape,
                        destaque=destaque,
                    )
                )
            )
            return

        self._imprimir_card(titulo, campos_topo, destaque=destaque)
        for secao in self._secoes_ordenadas(secoes):
            print(f"\n{secao.get('titulo', '')}")
            print()
            print(texto_curto(secao.get("texto_terminal", secao.get("conteudo", ""))))

        self._imprimir_campos(campos_rodape)

        detalhes = self._detalhes_ordenados(detalhes_tecnicos)
        if detalhes:
            print("\nVer detalhes técnicos")
            for secao in detalhes:
                print(f"\n{secao.get('titulo', '')}")
                print()
                valor = secao.get("conteudo", "")
                if secao.get("titulo") in {"Payload LLM", "Payload"}:
                    print(self.texto_json(valor))
                else:
                    print(texto_curto(valor))

    def ficha(self, titulo: str, dados: dict[str, Any]) -> None:
        self.card(titulo, dados)

    def bloco(self, titulo: str, texto: Any) -> None:
        self.card(titulo, [(None, texto)])

    def bloco_partes(self, titulo: str, partes: list[dict[str, str]]) -> None:
        texto = "".join(str(parte.get("texto", "")) for parte in partes)
        self.card(titulo, [(None, texto)])

    def final(self, dados: dict[str, Any]) -> None:
        self.card("Resultado Final", dados, destaque=True)

    def status(self, valor: Any) -> str:
        texto = " ".join(str(valor or "").strip().lower().split())
        mapa = {
            "pronto": "Pronto",
            "pronta": "Pronto",
            "concluido": "Pronto",
            "concluído": "Pronto",
            "concluida": "Pronto",
            "concluída": "Pronto",
            "tudo pronto": "Pronto",
            "processando": "Processando",
            "gerando": "Processando",
            "pendente": "Pendente",
            "selecionado": "Selecionado",
            "selecionada": "Selecionado",
            "erro": "Erro",
            "nao concluida": "Erro",
            "não concluída": "Erro",
            "nao concluido": "Erro",
            "não concluído": "Erro",
        }
        return mapa.get(texto, str(valor or "").strip() or "Pendente")

    def pipeline(self, titulo: str, etapas: list[str]) -> str:
        if not etapas:
            return ""

        return "\n".join(
            str(etapa) if indice == 0 else "-> " + str(etapa)
            for indice, etapa in enumerate(etapas)
        )

    def saida_item(
        self,
        titulo: str,
        valor: Any,
        *,
        compacto: bool = False,
    ) -> str:
        classe = "pc-output-item"
        if compacto:
            classe += " pc-output-compact"

        return (
            f"<div class='{classe}'>"
            f"<div class='pc-output-title'>{html.escape(str(titulo))}</div>"
            f"<div class='pc-output-text'>{self._valor_html(valor)}</div>"
            "</div>"
        )

    def progresso(
        self,
        titulo: str,
        atual: int,
        total: int,
        status: str,
        *,
        detalhe: str = "",
        handle: Any = None,
    ) -> Any:
        total_seguro = max(int(total or 1), 1)
        atual_seguro = max(0, min(int(atual), total_seguro))
        porcentagem = int((atual_seguro / total_seguro) * 100)

        if em_notebook() and HTML is not None:
            detalhe_html = (
                f"<br>{html.escape(detalhe)}"
                if detalhe
                else ""
            )
            conteudo = HTML(
                "<div class='pc-wrap pc-progress'>"
                f"<div class='pc-progress-title'>{html.escape(titulo)}</div>"
                "<div class='pc-progress-status'>"
                f"{html.escape(status)}{detalhe_html}"
                "</div>"
                "<div class='pc-progress-track'>"
                "<div class='pc-progress-fill' "
                f"style='width:{porcentagem}%'></div>"
                "</div>"
                "<div class='pc-progress-count'>"
                f"{atual_seguro}/{total_seguro} etapas concluídas"
                "</div>"
                "</div>"
            )

            if handle is not None and hasattr(handle, "update"):
                handle.update(conteudo)
                return handle

            return display(conteudo, display_id=True)

        print(f"{titulo}: {atual_seguro}/{total_seguro} - {status}")
        if detalhe:
            print(detalhe)
        return handle

    def limpar(self, handle: Any = None) -> None:
        if em_notebook() and HTML is not None:
            vazio = HTML("<div style='display:none'></div>")

            if handle is not None and hasattr(handle, "update"):
                handle.update(vazio)

    def opcoes(self, opcoes: list[str]) -> None:
        linhas = [
            f"{indice:>2}. {str(opcao).replace('_', ' ')}"
            for indice, opcao in enumerate(opcoes, start=1)
        ]

        if em_notebook() and Markdown is not None:
            display(Markdown("```text\n" + "\n".join(linhas) + "\n```"))
            return

        print("\n".join(linhas))

    def opcoes_com_indices(self, opcoes: list[tuple[int, str]]) -> None:
        linhas = [
            f"{indice:>2}. {str(rotulo).replace('_', ' ')}"
            for indice, rotulo in opcoes
        ]

        if em_notebook() and Markdown is not None:
            display(Markdown("```text\n" + "\n".join(linhas) + "\n```"))
            return

        print("\n".join(linhas))

    def escolher(
        self,
        mensagem: str,
        opcoes: list[str],
        *,
        padrao: Optional[str] = None,
    ) -> str:
        if not opcoes:
            raise ValueError(f"Nenhuma opcao disponivel para: {mensagem}")

        self.opcoes(opcoes)

        indice_padrao = None
        if padrao in opcoes:
            indice_padrao = opcoes.index(padrao) + 1

        while True:
            sufixo = f" [{indice_padrao}]" if indice_padrao else ""
            valor = input(f"{mensagem}{sufixo}: ").strip()

            if not valor and indice_padrao:
                return opcoes[indice_padrao - 1]

            try:
                indice = int(valor)
                if 1 <= indice <= len(opcoes):
                    return opcoes[indice - 1]
            except ValueError:
                if valor in opcoes:
                    return valor

            print("Opcao invalida.")

    def escolher_mapeado(
        self,
        mensagem: str,
        opcoes: list[tuple[str, str]],
        *,
        padrao: Optional[str] = None,
    ) -> str:
        if not opcoes:
            raise ValueError(f"Nenhuma opcao disponivel para: {mensagem}")

        rotulos = [rotulo for rotulo, _ in opcoes]
        valores = [valor for _, valor in opcoes]
        self.opcoes(rotulos)

        indice_padrao = None
        if padrao in valores:
            indice_padrao = valores.index(padrao) + 1

        while True:
            sufixo = f" [{indice_padrao}]" if indice_padrao else ""
            valor_digitado = input(f"{mensagem}{sufixo}: ").strip()

            if not valor_digitado and indice_padrao:
                return valores[indice_padrao - 1]

            try:
                indice = int(valor_digitado)
                if 1 <= indice <= len(opcoes):
                    return valores[indice - 1]
            except ValueError:
                pass

            for rotulo, valor in opcoes:
                if valor_digitado in {rotulo, valor}:
                    return valor

            print("Opcao invalida.")

    def escolher_mapeado_por_indice(
        self,
        mensagem: str,
        opcoes: list[tuple[int, str, str]],
        *,
        padrao: Optional[int] = None,
    ) -> str:
        if not opcoes:
            raise ValueError(f"Nenhuma opcao disponivel para: {mensagem}")

        por_indice = {indice: (rotulo, valor) for indice, rotulo, valor in opcoes}
        if len(por_indice) != len(opcoes):
            raise ValueError("Indices de opcao duplicados.")

        self.opcoes_com_indices(
            [(indice, rotulo) for indice, rotulo, _ in opcoes]
        )

        indice_padrao = padrao if padrao in por_indice else None

        while True:
            sufixo = f" [{indice_padrao}]" if indice_padrao else ""
            valor_digitado = input(f"{mensagem}{sufixo}: ").strip()

            if not valor_digitado and indice_padrao:
                return por_indice[indice_padrao][1]

            try:
                indice = int(valor_digitado)
                if indice in por_indice:
                    return por_indice[indice][1]
            except ValueError:
                pass

            for _, rotulo, valor in opcoes:
                texto_exibido = str(rotulo).replace("_", " ")
                if valor_digitado in {str(rotulo), str(valor), texto_exibido}:
                    return valor

            print("Opcao invalida.")

    def numero(self, mensagem: str, padrao: int) -> int:
        while True:
            valor = input(f"{mensagem} [{padrao}]: ").strip()

            if not valor:
                return padrao

            try:
                numero = int(valor)
                if numero > 0:
                    return numero
            except ValueError:
                pass

            print("Informe um numero inteiro positivo.")

    def decimal(self, mensagem: str, padrao: float) -> float:
        while True:
            valor = input(f"{mensagem} [{padrao}]: ").strip()

            if not valor:
                return padrao

            try:
                numero = float(valor.replace(",", "."))
                if numero >= 0:
                    return numero
            except ValueError:
                pass

            print("Informe um numero decimal maior ou igual a zero.")

    def confirmar(self, mensagem: str, padrao: bool = True) -> bool:
        dica = "S/n" if padrao else "s/N"

        while True:
            valor = input(f"{mensagem} [{dica}]: ").strip().lower()

            if not valor:
                return padrao
            if valor in {"s", "sim", "y", "yes"}:
                return True
            if valor in {"n", "nao", "no"}:
                return False

            print("Responda com sim ou nao.")

    def debug_json(self, titulo: str, dados: dict[str, Any]) -> None:
        conteudo = json.dumps(dados, indent=2, ensure_ascii=False, default=str)

        if em_notebook() and HTML is not None:
            display(
                HTML(
                    "<details class='pc-wrap pc-card'>"
                    "<summary>"
                    f"<div class='pc-card-title'>{html.escape(titulo)}</div>"
                    "</summary>"
                    "<div class='pc-card-body'>"
                    "<pre class='pc-value'>"
                    + html.escape(conteudo)
                    + "</pre></div></details>"
                )
            )
            return

        print(f"\n{titulo}")
        print(conteudo)


class Experiencia:
    def __init__(
        self,
        motor: Any,
        status: StatusAmbiente,
        provedor: Optional[str],
    ):
        self.motor = motor
        self.status = status
        self.provedor = provedor
        self.criador_provedor = None
        self.parametros_por_etapa: dict[str, dict[str, Any]] = {}
        self.parametros_automaticos = True
        self.grupo_execucao_atual = ""
        self.fluxo_linear_iniciado = False
        self.loop_iniciado = False
        self.progresso_chamadas: dict[int, Any] = {}
        self.progresso_fluxo_handle = None
        self.progresso_fluxo_tendencia = ""
        self.progresso_fluxo_concluidas: dict[str, Any] = {}
        self.progresso_fluxo_prompts: dict[str, str] = {}
        self.resultado_tendencia_base = None
        self.fluxos_por_tendencia: dict[str, int] = {}
        self.tendencias_exibidas: set[str] = set()
        self.indices_tendencias: dict[str, int] = {}
        self.secoes_execucao_exibidas: set[str] = set()
        self.fluxos_exibidos_ao_vivo = 0
        self.fluxos_lineares: dict[str, int] = {}
        self.numeros_resultados: dict[int, int] = {}
        self.ui = Visual()

    def rotulo_nome(self, nome: Any) -> str:
        texto = str(nome or "").replace("_", " ").strip()
        if not texto:
            return ""

        palavras_especiais = {
            "aida": "AIDA",
            "bab": "BAB",
            "bb": "BB",
            "cta": "CTA",
            "fab": "FAB",
            "cartao": "Cartão",
            "catalogos": "Catálogos",
            "cenario": "Cenário",
            "familia": "Família",
            "publico": "Público",
            "tendencia": "Tendência",
            "tendencias": "Tendências",
            "transformacao": "Transformação",
        }
        palavras = []

        for palavra in texto.split():
            chave = palavra.lower()
            if chave in palavras_especiais:
                palavras.append(palavras_especiais[chave])
            elif palavra.isupper() and len(palavra) <= 4:
                palavras.append(palavra)
            else:
                palavras.append(palavra[:1].upper() + palavra[1:].lower())

        return " ".join(palavras)

    def rotulo_prompt(self, nome: Any) -> str:
        return self.nome_yaml_referencia(nome)

    def nome_yaml_referencia(self, valor: Any) -> str:
        texto = str(valor or "").strip()
        if not texto:
            return ""

        texto = texto.split(" - ")[0].strip()
        texto = texto.replace("\\", "/")
        nome = texto.rsplit("/", 1)[-1]
        nome_minusculo = nome.lower()

        for extensao in (".yaml", ".yml"):
            if nome_minusculo.endswith(extensao):
                return nome[: -len(extensao)]

        return nome

    def rotulo_etapa(self, etapa_id: str) -> str:
        rotulos = {
            "tendencia_cognitiva": "Copywriter com Tendência",
            "voz_bb": "Voz BB",
            "tagline": "Texto",
            "headline": "Título",
            "cta": "CTA",
            "revisor_textual": "Revisão Textual",
            "copywriter": "Copywriter",
        }
        return rotulos.get(etapa_id, self.rotulo_nome(etapa_id))

    def rotulo_prompt_utilizado(self, etapa: Any, resultado: Any) -> str:
        nomes = {
            "revisor_textual": "Revisor textual",
            "copywriter": "Copywriter",
            "tendencia_cognitiva": "Copywriter com Tendência",
            "voz_bb": "Voz BB",
            "tagline": "Texto",
            "headline": "Título",
            "cta": "CTA",
        }
        return (
            nomes.get(etapa.id, self.rotulo_etapa(etapa.id))
            + " "
            + self.rotulo_prompt(resultado.prompt.nome)
        )

    def sim_nao(self, valor: bool) -> str:
        return "Sim" if valor else "Não"

    def limites_automaticos(self, limite_tagline: int, limite_headline: int) -> bool:
        return int(limite_tagline) == 100 and int(limite_headline) == 25

    def opcoes_catalogo(self, nomes: list[str]) -> list[tuple[str, str]]:
        return [(self.rotulo_nome(nome), nome) for nome in nomes]

    def rodar(self) -> Any:
        self.ui.aplicar_estilo()
        self.criador_provedor = resolver_criador_provedor(self.provedor)
        self.validar_catalogos()

        produto = self.selecionar_produto()
        publico = self.selecionar_publico()
        apresentacao = self.selecionar_apresentacao(produto, publico)
        cenario = self.selecionar_cenario()

        self.ui.secao("Parâmetros de Geração")
        limite_tagline = self.ui.numero("Limite de caracteres da tagline", 100)
        limite_headline = self.ui.numero("Limite de caracteres da headline", 25)

        selecao = self.motor.Selecao(
            produto=produto.nome,
            publico=publico.nome,
            apresentacao=apresentacao.nome,
            cenario=cenario.nome,
            limite_tagline=limite_tagline,
            limite_headline=limite_headline,
        )

        self.parametros_automaticos = self.ui.confirmar(
            "Usar parâmetros automáticos?",
            padrao=True,
        )

        self.mostrar_parametros_geracao(limite_tagline, limite_headline)

        resultado = self.motor.rodar_fluxo(
            selecao,
            criador_provedor=self.criador_provedor,
            configurar_chamada=self.configurar_chamada,
            escolher_resultado=self.escolher_resultado,
            ao_resultado_etapa=self.mostrar_etapa_concluida,
            ao_inicio_prompt=self.mostrar_inicio_prompt,
            ao_fim_prompt=self.mostrar_fim_prompt,
            ao_conjunto_final=self.mostrar_conjunto_final_ao_vivo,
        )
        self.mostrar_resultado(resultado)
        return resultado

    def mostrar_status(self) -> None:
        return

    def validar_catalogos(self) -> None:
        erros = self.motor.validar_catalogos()

        if erros:
            self.ui.card(
                "Preparação",
                {
                    "Status": self.ui.status("erro"),
                    "Erros": "\n".join(erros),
                },
            )
            raise RuntimeError("Catalogos com erros de validacao.")

    def campos_dados_placeholder(self, dados: dict[str, Any]) -> list[tuple[str, Any]]:
        placeholders = []
        informativos = []

        for chave, valor in dados.items():
            chave_texto = str(chave)
            if chave_texto.startswith("PH_"):
                placeholders.append((chave_texto, valor))
            else:
                informativos.append((self.rotulo_nome(chave_texto), valor))

        return placeholders + informativos

    def selecionar_produto(self) -> Any:
        self.ui.secao("Produto")
        nome = self.ui.escolher_mapeado(
            "Escolha o produto",
            self.opcoes_catalogo(self.motor.listar_produtos()),
        )
        produto = self.motor.carregar_produto(nome)
        self.ui.card_direto(
            self.rotulo_nome(produto.nome),
            self.campos_dados_placeholder(produto.dados),
        )
        return produto

    def selecionar_publico(self) -> Any:
        self.ui.secao("Público")
        nome = self.ui.escolher_mapeado(
            "Escolha o público",
            self.opcoes_catalogo(self.motor.listar_publicos()),
        )
        publico = self.motor.carregar_publico(nome)
        self.ui.card_direto(
            self.rotulo_nome(publico.nome),
            self.campos_dados_placeholder(publico.dados),
        )
        return publico

    def selecionar_apresentacao(self, produto: Any, publico: Any) -> Any:
        self.ui.secao("Apresentação")
        nome = self.ui.escolher_mapeado(
            "Escolha a apresentação",
            self.opcoes_catalogo(self.motor.listar_apresentacoes()),
        )
        apresentacao = self.motor.carregar_apresentacao(nome)
        try:
            previa = apresentacao.montar(produto, publico)
        except ValueError as erro:
            raise ValueError(
                "Apresentacao escolhida nao pode ser montada: "
                + self.rotulo_nome(apresentacao.nome)
                + "\nProduto: "
                + self.rotulo_nome(produto.nome)
                + "\nPublico: "
                + self.rotulo_nome(publico.nome)
                + "\n\n"
                + str(erro)
            ) from erro
        campos = [
            ("Template padrão", apresentacao.template),
            (
                "Template preenchido",
                {
                    "conteudo": self.ui.html_apresentacao_preenchida(
                        previa["partes"]
                    ),
                    "conteudo_html": True,
                    "texto_terminal": self.ui.texto_apresentacao_preenchida(
                        previa["partes"]
                    ),
                },
            ),
        ]

        if previa["avisos"]:
            campos.append(("Avisos", "\n".join(previa["avisos"])))

        self.ui.card_direto(
            self.rotulo_nome(apresentacao.nome),
            campos,
        )

        return apresentacao

    def selecionar_cenario(self) -> Any:
        self.ui.secao("Cenário")
        nome = self.ui.escolher_mapeado(
            "Escolha o cenário",
            self.opcoes_catalogo(self.motor.listar_cenarios()),
        )
        cenario = self.motor.carregar_cenario(nome)
        estrutura = str(cenario.exibir_usuario or "").strip()
        if estrutura.lower() in {"", "null", "none"}:
            estrutura = cenario.texto_prompt

        self.ui.card_direto(
            self.rotulo_nome(cenario.nome),
            [
                ("Função", cenario.funcao_prompt),
                ("Estrutura", estrutura),
            ],
        )
        return cenario

    def mostrar_configuracao(
        self,
        produto: Any,
        publico: Any,
        apresentacao: Any,
        cenario: Any,
        limite_tagline: int,
        limite_headline: int,
        parametros_automaticos: bool,
    ) -> None:
        return

    def mostrar_parametros_geracao(
        self,
        limite_tagline: int,
        limite_headline: int,
    ) -> None:
        self.ui.card_direto(
            "Parâmetros de Geração",
            [
                ("Texto", f"{limite_tagline} caracteres"),
                ("Título", f"{limite_headline} caracteres"),
                (
                    "Modo",
                    "Automático" if self.parametros_automaticos else "Manual",
                ),
                ("Fluxo iniciado", self.texto_fluxo_parametros_geracao()),
            ],
        )

    def texto_fluxo_parametros_geracao(self) -> str:
        linhas = []

        for etapa in self.motor.ETAPAS:
            quantidade = self.quantidade_prompts(etapa.grupo_prompt)
            palavra_prompt = "prompt" if quantidade == 1 else "prompts"
            base = (
                f"{self.rotulo_etapa(etapa.id)}: "
                f"{quantidade} {palavra_prompt}"
            )

            if self.parametros_automaticos:
                linhas.append(
                    base
                    + f" | temperatura {etapa.temperature}"
                    + f" | max tokens {etapa.max_tokens}"
                )
                continue

            linhas.append(base + " | parâmetros perguntados antes da etapa")

        return "\n".join(linhas)

    def numero_resultado(self, etapa: Any, resultado: Any) -> int:
        numero = self.numeros_resultados.get(id(resultado))
        if numero is not None:
            return numero

        for indice, item in enumerate(etapa.resultados_prompt, start=1):
            if item is resultado:
                return indice

        return 1

    def escolher_resultado(self, etapa: Any, validos: list[Any]) -> str:
        opcoes = [
            (
                self.numero_resultado(etapa, resultado),
                self.nome_prompt_yaml(resultado),
                resultado.identificador,
            )
            for resultado in validos
        ]
        return self.ui.escolher_mapeado_por_indice(
            "Escolha a alternativa que deve seguir no fluxo",
            opcoes,
            padrao=opcoes[0][0],
        )

    def titulo_execucao(self, etapa: Any, resultado: Any) -> str:
        if resultado.opcao and etapa.id == "tendencia_cognitiva":
            return (
                self.rotulo_etapa(etapa.id)
                + " - "
                + str(resultado.opcao)
                + " - "
                + self.rotulo_prompt(resultado.prompt.nome)
            )

        if resultado.opcao:
            return self.rotulo_prompt(resultado.prompt.nome)

        return (
            self.rotulo_etapa(etapa.id)
            + " - "
            + self.rotulo_prompt(resultado.prompt.nome)
        )

    def grupo_execucao(self, etapa: Any, resultado: Any) -> str:
        if resultado.opcao:
            return (
                "Tendência cognitiva - "
                + str(resultado.opcao)
            )

        return self.rotulo_etapa(etapa.id)

    def dados_entrada_execucao(self, resultado: Any) -> dict[str, Any]:
        dados = {
            "Template preenchido": resultado.template_preenchido,
            "System": resultado.system,
        }

        if resultado.opcao:
            dados["Opção"] = str(resultado.opcao)

        return dados

    def mostrar_entrada_execucao(
        self,
        resultado: Any,
        titulo: Optional[str] = None,
    ) -> None:
        self.ui.card(
            "Entrada",
            [(None, titulo or resultado.identificador)]
            + list(self.dados_entrada_execucao(resultado).items()),
        )

    def mostrar_saida_execucao(
        self,
        resultado: Any,
        titulo: Optional[str] = None,
    ) -> None:
        titulo = titulo or resultado.identificador

        if resultado.valido:
            self.ui.card(
                "Resultado",
                {
                    "Texto gerado": resultado.output,
                },
            )
            return

        self.ui.card(
            "Resultado",
            {
                "Erro": resultado.erro,
            },
        )

    def mostrar_cards_execucao(self, resultado: Any, titulo: Optional[str] = None) -> None:
        titulo = titulo or resultado.identificador
        self.mostrar_entrada_execucao(resultado, titulo)
        self.mostrar_saida_execucao(resultado, titulo)

    def quantidade_prompts(self, grupo: str) -> int:
        try:
            return len(self.motor.listar_prompts(grupo))
        except Exception:
            return 0

    def mostrar_inicio_fluxo_linear(self) -> None:
        if self.fluxo_linear_iniciado:
            return

        self.fluxo_linear_iniciado = True

    def mostrar_inicio_loop(self, resultado: Any = None) -> None:
        if self.loop_iniciado:
            return

        tendencias = self.motor.listar_tendencias()
        total_tendencias = len(tendencias)
        self.indices_tendencias = {
            tendencia: indice
            for indice, tendencia in enumerate(tendencias, start=1)
        }
        palavra = "tendência" if total_tendencias == 1 else "tendências"
        self.ui.secao(
            f"Aplicação de Tendência ({total_tendencias} {palavra})"
        )
        self.loop_iniciado = True

    def configurar_parametros_variacoes(self) -> None:
        etapas = [
            etapa
            for etapa in self.motor.ETAPAS
            if self.etapa_automatica(etapa)
        ]

        if all(etapa.id in self.parametros_por_etapa for etapa in etapas):
            return

        for etapa in etapas:
            temperatura = self.ui.decimal(
                f"{self.rotulo_etapa(etapa.id)} - temperatura",
                float(etapa.temperature),
            )
            max_tokens = self.ui.numero(
                f"{self.rotulo_etapa(etapa.id)} - máximo de tokens",
                int(etapa.max_tokens),
            )
            self.parametros_por_etapa[etapa.id] = {
                "temperature": temperatura,
                "max_tokens": max_tokens,
            }

    def etapa_automatica(self, etapa: Any) -> bool:
        return etapa.id in {
            "tendencia_cognitiva",
            "voz_bb",
            "tagline",
            "headline",
            "cta",
        }

    def mostrar_tendencia(self, tendencia: str) -> None:
        nome = tendencia or "Sem tendencia"

        if nome in self.tendencias_exibidas:
            return

        indice = self.indices_tendencias.get(nome)
        if indice is None:
            indice = len(self.tendencias_exibidas) + 1

        self.ui.secao(f"{indice}. {nome}")
        self.tendencias_exibidas.add(nome)

    def mostrar_secao_execucao(self, etapa: Any) -> None:
        if etapa.id in self.secoes_execucao_exibidas:
            return

        self.ui.secao(self.rotulo_etapa(etapa.id))
        self.secoes_execucao_exibidas.add(etapa.id)

    def mostrar_secao_selecao(self) -> None:
        return

    def caminho_progresso_fluxo(self) -> str:
        partes = []

        for etapa_id, _, _ in self.etapas_fluxo_final():
            prompt = self.progresso_fluxo_prompts.get(etapa_id)
            if prompt:
                partes.append(
                    f"{self.rotulo_etapa(etapa_id)} {prompt}"
                )

        return " -> ".join(partes)

    def preparar_progresso_automatico(self, etapa: Any, resultado: Any) -> None:
        if etapa.id == "tendencia_cognitiva":
            self.progresso_fluxo_handle = None
            self.progresso_fluxo_tendencia = resultado.opcao
            self.progresso_fluxo_concluidas = {}
            self.progresso_fluxo_prompts = {
                etapa.id: resultado.prompt.nome,
            }
            return

        if self.progresso_fluxo_handle is None:
            self.progresso_fluxo_tendencia = resultado.opcao
            self.progresso_fluxo_concluidas = {}
            self.progresso_fluxo_prompts = {}

            if (
                self.resultado_tendencia_base is not None
                and self.resultado_tendencia_base.opcao == resultado.opcao
            ):
                self.progresso_fluxo_concluidas["tendencia_cognitiva"] = (
                    self.resultado_tendencia_base
                )
                self.progresso_fluxo_prompts["tendencia_cognitiva"] = (
                    self.resultado_tendencia_base.prompt.nome
                )

        self.progresso_fluxo_prompts[etapa.id] = resultado.prompt.nome

    def atualizar_progresso_automatico(
        self,
        etapa: Any,
        resultado: Any,
        status: str,
    ) -> None:
        titulo = "Gerando " + str(self.progresso_fluxo_tendencia or resultado.opcao)
        detalhe = self.caminho_progresso_fluxo()
        atual = len(self.progresso_fluxo_concluidas)

        self.progresso_fluxo_handle = self.ui.progresso(
            titulo,
            atual,
            5,
            status,
            detalhe=detalhe,
            handle=self.progresso_fluxo_handle,
        )

    def mostrar_inicio_prompt(self, etapa: Any, resultado: Any) -> None:
        if etapa.id in {"revisor_textual", "copywriter"}:
            self.mostrar_inicio_fluxo_linear()
            self.mostrar_secao_execucao(etapa)

        if self.etapa_automatica(etapa):
            self.mostrar_inicio_loop(resultado)
            self.mostrar_tendencia(resultado.opcao)
            self.preparar_progresso_automatico(etapa, resultado)
            self.atualizar_progresso_automatico(
                etapa,
                resultado,
                (
                    "Gerando "
                    + self.rotulo_etapa(etapa.id)
                    + " "
                    + self.rotulo_prompt(resultado.prompt.nome)
                    + "..."
                ),
            )
            return

        titulo = self.titulo_execucao(etapa, resultado)
        self.progresso_chamadas[id(resultado)] = self.ui.progresso(
            titulo,
            0,
            1,
            "Gerando resultado...",
        )

    def mostrar_fim_prompt(self, etapa: Any, resultado: Any) -> None:
        if self.etapa_automatica(etapa):
            if resultado.valido:
                self.progresso_fluxo_concluidas[etapa.id] = resultado
                self.progresso_fluxo_prompts[etapa.id] = resultado.prompt.nome

                if etapa.id == "tendencia_cognitiva":
                    self.resultado_tendencia_base = resultado

            self.atualizar_progresso_automatico(
                etapa,
                resultado,
                (
                    f"{self.rotulo_etapa(etapa.id)} concluída."
                    if resultado.valido
                    else f"{self.rotulo_etapa(etapa.id)} não concluída."
                ),
            )
            return

        titulo = self.titulo_execucao(etapa, resultado)
        handle = self.progresso_chamadas.pop(id(resultado), None)
        self.ui.limpar(handle)
        self.mostrar_fluxo_linear(etapa, resultado)

    def configurar_chamada(
        self,
        etapa: Any,
        prompt: Any,
        opcao: str,
        parametros: dict[str, Any],
    ) -> dict[str, Any]:
        if self.parametros_automaticos:
            return dict(parametros)

        if self.etapa_automatica(etapa):
            self.mostrar_inicio_loop()
            self.configurar_parametros_variacoes()
            return dict(self.parametros_por_etapa[etapa.id])

        if etapa.id in self.parametros_por_etapa:
            return dict(self.parametros_por_etapa[etapa.id])

        temperatura = self.ui.decimal(
            f"Temperatura - {self.rotulo_etapa(etapa.id)}",
            float(parametros["temperature"]),
        )
        max_tokens = self.ui.numero(
            f"Quantidade máxima de tokens - {self.rotulo_etapa(etapa.id)}",
            int(parametros["max_tokens"]),
        )

        ajustes = {
            "temperature": temperatura,
            "max_tokens": max_tokens,
        }
        self.parametros_por_etapa[etapa.id] = ajustes
        return dict(ajustes)

    def mostrar_etapa_concluida(self, etapa: Any) -> None:
        return

    def prompt_oficial_resultado(self, etapa: Any, resultado: Any) -> dict[str, Any]:
        return {
            "etapa": etapa.titulo,
            "prompt": resultado.prompt.nome,
            "arquivo_prompt": resultado.prompt.identificador,
            "opcao": resultado.opcao,
            "mensagens_enviadas": [
                {
                    "role": "system",
                    "content": resultado.system,
                },
                {
                    "role": "user",
                    "tipo": "template",
                    "content": resultado.template_preenchido,
                },
                {
                    "role": "user",
                    "tipo": "entrada",
                    "content": resultado.entrada,
                },
            ],
            "parametros": {
                "temperature": resultado.parametros.get("temperature"),
                "max_tokens": resultado.parametros.get("max_tokens"),
                "top_p": resultado.parametros.get("top_p"),
                "frequency_penalty": resultado.parametros.get("frequency_penalty"),
                "presence_penalty": resultado.parametros.get("presence_penalty"),
                "best_of": resultado.parametros.get("best_of"),
            },
        }

    def html_prompt_oficial_resultado(self, etapa: Any, resultado: Any) -> str:
        return self.ui.json_bloco(self.prompt_oficial_resultado(etapa, resultado))

    def nome_prompt_yaml(self, resultado: Any) -> str:
        nome = self.nome_yaml_referencia(resultado.prompt.nome)
        if nome:
            return nome

        return self.nome_yaml_referencia(resultado.prompt.identificador)

    def texto_resultado_llm(self, resultado: Any) -> str:
        saida = resultado.output if resultado.valido else resultado.erro
        return str(saida or "")

    def valor_parametro_curto(self, valor: Any) -> str:
        if valor is None:
            return "-"
        if isinstance(valor, float):
            return f"{valor:g}"
        return str(valor)

    def titulo_resultado_llm(self, resultado: Any) -> str:
        temperatura = self.valor_parametro_curto(
            resultado.parametros.get("temperature")
        )
        max_tokens = self.valor_parametro_curto(
            resultado.parametros.get("max_tokens")
        )
        return f"Resultado ({temperatura}; {max_tokens})"

    def detalhes_tecnicos_resultado(
        self,
        etapa: Any,
        resultado: Any,
    ) -> list[dict[str, Any]]:
        return [
            {
                "titulo": "Prompt utilizado",
                "conteudo": self.rotulo_prompt_utilizado(etapa, resultado),
            },
            {
                "titulo": "Template preenchido",
                "conteudo": resultado.template_preenchido,
            },
            {
                "titulo": "System",
                "conteudo": resultado.system,
            },
            {
                "titulo": "Payload",
                "conteudo": self.prompt_oficial_resultado(etapa, resultado),
            },
        ]

    def secoes_resultado_llm(
        self,
        etapa: Any,
        resultado: Any,
    ) -> list[dict[str, Any]]:
        payload = self.prompt_oficial_resultado(etapa, resultado)
        return [
            {
                "titulo": self.titulo_resultado_llm(resultado),
                "conteudo": self.texto_resultado_llm(resultado),
                "aberto": True,
            },
            {
                "titulo": "Template preenchido",
                "conteudo": resultado.template_preenchido,
            },
            {
                "titulo": "System",
                "conteudo": resultado.system,
            },
            {
                "titulo": "Payload",
                "conteudo": self.ui.json_bloco(payload),
                "conteudo_html": True,
                "texto_terminal": self.ui.texto_json(payload),
            },
        ]

    def html_subcards_resultado_llm(
        self,
        etapa: Any,
        resultado: Any,
    ) -> str:
        return "".join(
            self.ui._html_secao_dict(secao)
            for secao in self.secoes_resultado_llm(etapa, resultado)
        )

    def texto_terminal_resultado_llm(
        self,
        etapa: Any,
        resultado: Any,
    ) -> str:
        partes = []
        for secao in self.secoes_resultado_llm(etapa, resultado):
            partes.append(
                str(secao["titulo"])
                + "\n\n"
                + texto_curto(secao.get("texto_terminal", secao.get("conteudo", "")))
            )

        return "\n\n".join(partes)

    def mostrar_fluxo_linear(self, etapa: Any, resultado: Any) -> None:
        numero = self.fluxos_lineares.get(etapa.id, 0) + 1
        self.fluxos_lineares[etapa.id] = numero
        self.numeros_resultados[id(resultado)] = numero
        self.ui.card_com_secoes(
            self.nome_prompt_yaml(resultado),
            secoes=self.secoes_resultado_llm(etapa, resultado),
        )

    def mostrar_conjunto_final_ao_vivo(self, conjunto: Any) -> None:
        tendencia = conjunto.tendencia or "Sem tendencia"
        numero = self.fluxos_por_tendencia.get(tendencia, 0) + 1
        self.fluxos_por_tendencia[tendencia] = numero

        self.progresso_fluxo_concluidas = {
            resultado.prompt.grupo: resultado
            for resultado in conjunto.resultados
        }
        self.progresso_fluxo_prompts = {
            etapa_id: self.prompt_do_conjunto(conjunto, etapa_id)
            for etapa_id, _, _ in self.etapas_fluxo_final()
        }
        self.progresso_fluxo_tendencia = tendencia

        self.ui.progresso(
            "Variação: " + str(tendencia),
            5,
            5,
            f"Fluxo {numero} pronto.",
            detalhe=self.caminho_fluxo(conjunto),
            handle=self.progresso_fluxo_handle,
        )
        self.ui.limpar(self.progresso_fluxo_handle)
        self.mostrar_fluxo_conjunto(conjunto, numero)
        self.fluxos_exibidos_ao_vivo += 1
        self.progresso_fluxo_handle = None
        self.progresso_fluxo_concluidas = {}
        self.progresso_fluxo_prompts = {}

    def mostrar_resultado(self, resultado: Any) -> None:
        self.ui.secao("Resultado Final")

        if resultado.conjuntos:
            if self.fluxos_exibidos_ao_vivo == 0:
                self.mostrar_conjuntos(resultado.conjuntos)

            self.ui.final(
                {
                    "Total de conjuntos gerados": len(resultado.conjuntos),
                    "Regra": "Cada conjunto representa uma tendência.",
                }
            )
        else:
            self.ui.final(
                {
                    "Headline": resultado.headline,
                    "Tagline": resultado.tagline,
                    "CTA": resultado.cta,
                    "Texto final": resultado.resumo_institucional,
                }
            )

    def prompt_do_conjunto(self, conjunto: Any, etapa_id: str) -> str:
        return self.nome_yaml_referencia(conjunto.prompts.get(etapa_id, ""))

    def etapas_fluxo_final(self) -> list[tuple[str, str, str]]:
        return [
            ("tendencia_cognitiva", "Tendência cognitiva", "3_tendencia_cognitiva"),
            ("voz_bb", "Voz Institucional BB", "4_voz_BB"),
            ("tagline", "Tagline", "5_tagline"),
            ("headline", "Headline", "6_headline"),
            ("cta", "CTA", "7_cta"),
        ]

    def etapa_por_id(self, etapa_id: str) -> Any:
        for etapa in self.motor.ETAPAS:
            if etapa.id == etapa_id:
                return etapa

        raise KeyError("Etapa desconhecida: " + str(etapa_id))

    def resultado_conjunto_etapa(self, conjunto: Any, grupo_prompt: str) -> Any:
        for resultado in conjunto.resultados:
            if resultado.prompt.grupo == grupo_prompt:
                return resultado

        return None

    def saida_conjunto_etapa(self, conjunto: Any, etapa_id: str) -> str:
        for item_etapa_id, _, grupo_prompt in self.etapas_fluxo_final():
            if item_etapa_id != etapa_id:
                continue

            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is None:
                return ""

            return str(resultado.output or "")

        return ""

    def id_componente_resultado_final(self, conjunto: Any) -> str:
        base = "-".join(
            str(valor)
            for valor in [
                getattr(conjunto, "id", ""),
                getattr(conjunto, "tendencia", ""),
            ]
            if str(valor or "").strip()
        )
        if not base:
            base = str(id(conjunto))

        token = re.sub(r"[^A-Za-z0-9_-]+", "-", base).strip("-").lower()
        return token or str(id(conjunto))

    def texto_cta_card_final(self, cta: Any) -> str:
        palavras = str(cta or "").split()

        if len(palavras) <= 2:
            return " ".join(palavras)

        return " ".join(palavras[:2]) + "\u2026"

    def html_componente_resultado_final(self, conjunto: Any) -> str:
        titulo = self.saida_conjunto_etapa(conjunto, "headline")
        texto = self.saida_conjunto_etapa(conjunto, "tagline")
        cta = self.saida_conjunto_etapa(conjunto, "cta")

        if not any([titulo, texto, cta]):
            return ""

        componente_id = self.id_componente_resultado_final(conjunto)
        nome_controle = "pc-final-style-" + componente_id
        id_overlay = nome_controle + "-overlay"
        id_simple = nome_controle + "-simple"
        partes = [
            "<div class='pc-final-shell'>",
            "<input class='pc-final-radio pc-final-overlay-radio' "
            "type='radio' "
            f"name='{html.escape(nome_controle)}' "
            f"id='{html.escape(id_overlay)}' checked>",
            "<input class='pc-final-radio pc-final-simple-radio' "
            "type='radio' "
            f"name='{html.escape(nome_controle)}' "
            f"id='{html.escape(id_simple)}'>",
            "<div class='pc-final-toggle' aria-label='Estilo do card final'>",
            "<label class='pc-final-toggle-option pc-final-toggle-overlay' "
            f"for='{html.escape(id_overlay)}'>Overlay</label>",
            "<label class='pc-final-toggle-option pc-final-toggle-simple' "
            f"for='{html.escape(id_simple)}'>Simple</label>",
            "</div>",
            "<div class='pc-final-preview'>",
            "<div class='pc-final-close' aria-hidden='true'>&times;</div>",
        ]

        if titulo:
            partes.append(
                "<div class='pc-final-title'>"
                + html.escape(titulo)
                + "</div>"
            )

        if texto:
            partes.append(
                "<div class='pc-final-message'>"
                + html.escape(texto)
                + "</div>"
            )

        partes.append(
            "<div class='pc-final-cta'>"
            + html.escape(self.texto_cta_card_final(cta))
            + "</div>"
        )

        partes.append("</div></div>")
        return "".join(partes)

    def texto_componente_resultado_final(self, conjunto: Any) -> str:
        titulo = self.saida_conjunto_etapa(conjunto, "headline")
        texto = self.saida_conjunto_etapa(conjunto, "tagline")
        cta = self.saida_conjunto_etapa(conjunto, "cta")
        partes = [valor for valor in [titulo, texto, cta] if valor]
        return "\n\n".join(partes)

    def campos_rodape_conjunto(
        self,
        conjunto: Any,
    ) -> Optional[list[tuple[Optional[str], Any]]]:
        componente = self.html_componente_resultado_final(conjunto)
        if not componente:
            return None

        return [
            (
                None,
                {
                    "conteudo": componente,
                    "conteudo_html": True,
                    "texto_terminal": self.texto_componente_resultado_final(
                        conjunto
                    ),
                    "sem_wrapper": True,
                },
            )
        ]

    def campos_topo_conjunto(
        self,
        conjunto: Any,
    ) -> Optional[list[tuple[Optional[str], Any]]]:
        return self.campos_rodape_conjunto(conjunto)

    def caminho_fluxo(self, conjunto: Any) -> str:
        partes = []

        for etapa_id, _, _ in self.etapas_fluxo_final():
            prompt = self.prompt_do_conjunto(conjunto, etapa_id)
            if prompt:
                partes.append(f"{self.rotulo_etapa(etapa_id)} {prompt}")

        return " -> ".join(partes)

    def html_valor(self, chave: str, valor: Any) -> str:
        return (
            "<div style='margin:8px 0'>"
            f"<div class='pc-label'>{html.escape(str(chave))}</div>"
            f"<div class='pc-value'>{html.escape(str(valor or ''))}</div>"
            "</div>"
        )

    def html_saida_valor(
        self,
        titulo: str,
        valor: Any,
        *,
        destaque: bool = False,
    ) -> str:
        classe = "pc-output-item pc-output-main" if destaque else "pc-output-item"
        return (
            f"<div class='{classe}'>"
            f"<div class='pc-output-title'>{html.escape(str(titulo))}</div>"
            f"<div class='pc-output-text'>{html.escape(str(valor or ''))}</div>"
            "</div>"
        )

    def html_saida_lista(
        self,
        itens: list[tuple[str, Any]],
        *,
        destaque_primeiro: bool = False,
    ) -> str:
        partes = []

        for indice, (titulo, valor) in enumerate(itens):
            partes.append(
                self.html_saida_valor(
                    titulo,
                    valor,
                    destaque=destaque_primeiro and indice == 0,
                )
            )

        return "<div class='pc-output-list'>" + "".join(partes) + "</div>"

    def html_templates_resultados(
        self,
        resultados: list[Any],
    ) -> str:
        partes = []

        for indice, resultado in enumerate(resultados, start=1):
            partes.append(
                "<div class='pc-stage'>"
                f"<div class='pc-stage-title'>{indice}. "
                f"{html.escape(resultado.prompt.identificador)}</div>"
                + self.html_valor(
                    "Template preenchido",
                    resultado.template_preenchido,
                )
                + "</div>"
            )

        return "".join(partes)

    def html_system_resultados(
        self,
        resultados: list[Any],
    ) -> str:
        vistos: dict[str, list[str]] = {}

        for resultado in resultados:
            vistos.setdefault(str(resultado.system or ""), []).append(
                resultado.prompt.identificador
            )

        partes = []

        for indice, (system, prompts) in enumerate(vistos.items(), start=1):
            titulo = (
                "System"
                if len(vistos) == 1
                else f"System {indice}"
            )
            partes.append(
                "<div class='pc-stage'>"
                f"<div class='pc-stage-title'>{html.escape(titulo)}</div>"
                + self.html_valor("Usado em", ", ".join(prompts))
                + self.html_valor("Conteudo", system)
                + "</div>"
            )

        return "".join(partes)

    def html_entrada_resultados(self, resultados: list[Any]) -> str:
        return (
            "<details class='pc-inner'>"
            "<summary>Templates com placeholders preenchidos</summary>"
            + self.html_templates_resultados(resultados)
            + "</details>"
            "<details class='pc-inner'>"
            "<summary>System enviado</summary>"
            + self.html_system_resultados(resultados)
            + "</details>"
        )

    def html_entrada_fluxo(self, conjunto: Any) -> str:
        resultados = []

        for _, _, grupo_prompt in self.etapas_fluxo_final():
            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is not None:
                resultados.append(resultado)

        return self.html_entrada_resultados(resultados)

    def html_saida_fluxo(self, conjunto: Any) -> str:
        saidas = [
            ("3_tendencia_cognitiva", "Texto com Tendência"),
            ("4_voz_BB", "Texto com Voz BB"),
            ("5_tagline", "Tagline"),
            ("6_headline", "Headline"),
            ("7_cta", "CTA"),
        ]
        itens = []

        for grupo_prompt, titulo in saidas:
            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is None:
                continue

            itens.append((titulo, resultado.output))

        return self.html_saida_lista(itens, destaque_primeiro=True)

    def resultados_do_conjunto(self, conjunto: Any) -> list[Any]:
        resultados = []

        for _, _, grupo_prompt in self.etapas_fluxo_final():
            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is not None:
                resultados.append(resultado)

        return resultados

    def texto_templates_resultados(self, resultados: list[Any]) -> str:
        partes = []

        for indice, resultado in enumerate(resultados, start=1):
            partes.append(
                "\n\n".join(
                    [
                        f"{indice}. `{resultado.prompt.identificador}`",
                        "Template preenchido",
                        resultado.template_preenchido,
                    ]
                )
            )

        return "\n\n---\n\n".join(partes)

    def texto_system_resultados(self, resultados: list[Any]) -> str:
        vistos: dict[str, list[str]] = {}

        for resultado in resultados:
            vistos.setdefault(str(resultado.system or ""), []).append(
                resultado.prompt.identificador
            )

        partes = []
        for indice, (system, prompts) in enumerate(vistos.items(), start=1):
            campos = ["Usado em", ", ".join(prompts), "Conteúdo", system]
            if len(vistos) > 1:
                campos = [f"System {indice}"] + campos

            partes.append("\n\n".join(campos))

        return "\n\n---\n\n".join(partes)

    def pipeline_conjunto(self, conjunto: Any) -> str:
        etapas = []

        for etapa_id, _, _ in self.etapas_fluxo_final():
            prompt = self.prompt_do_conjunto(conjunto, etapa_id)
            if prompt:
                etapas.append(f"{self.rotulo_etapa(etapa_id)} {prompt}")

        return self.ui.pipeline("Pipeline", etapas)

    def detalhes_tecnicos_conjunto(self, conjunto: Any) -> list[dict[str, Any]]:
        resultados = self.resultados_do_conjunto(conjunto)
        return [
            {
                "titulo": "Entrada",
                "conteudo": self.texto_templates_resultados(resultados),
            },
            {
                "titulo": "System",
                "conteudo": self.texto_system_resultados(resultados),
            },
            {
                "titulo": "Payload",
                "conteudo": self.prompt_oficial_fluxo(conjunto),
            },
        ]

    def prompt_oficial_fluxo(self, conjunto: Any) -> dict[str, Any]:
        etapas = []

        for _, titulo, grupo_prompt in self.etapas_fluxo_final():
            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is None:
                continue

            etapas.append(
                {
                    "etapa": titulo,
                    "prompt": resultado.prompt.nome,
                    "arquivo_prompt": resultado.prompt.identificador,
                    "opcao": resultado.opcao,
                    "mensagens_enviadas": [
                        {
                            "role": "system",
                            "content": resultado.system,
                        },
                        {
                            "role": "user",
                            "tipo": "template",
                            "content": resultado.template_preenchido,
                        },
                        {
                            "role": "user",
                            "tipo": "entrada",
                            "content": resultado.entrada,
                        },
                    ],
                    "parametros": {
                        "temperature": resultado.parametros.get("temperature"),
                        "max_tokens": resultado.parametros.get("max_tokens"),
                        "top_p": resultado.parametros.get("top_p"),
                        "frequency_penalty": resultado.parametros.get(
                            "frequency_penalty"
                        ),
                        "presence_penalty": resultado.parametros.get(
                            "presence_penalty"
                        ),
                        "best_of": resultado.parametros.get("best_of"),
                    },
                }
            )

        return {
            "tendencia": conjunto.tendencia,
            "caminho": self.caminho_fluxo(conjunto),
            "etapas": etapas,
        }

    def html_prompt_oficial_fluxo(self, conjunto: Any) -> str:
        return self.ui.json_bloco(self.prompt_oficial_fluxo(conjunto))

    def titulo_card_conjunto(self, conjunto: Any) -> str:
        nomes = []

        for etapa_id, _, grupo_prompt in self.etapas_fluxo_final():
            if self.quantidade_prompts(grupo_prompt) <= 1:
                continue

            nome_prompt = self.prompt_do_conjunto(conjunto, etapa_id)
            if nome_prompt:
                nomes.append(nome_prompt)

        if not nomes:
            for etapa_id, _, _ in self.etapas_fluxo_final():
                nome_prompt = self.prompt_do_conjunto(conjunto, etapa_id)
                if nome_prompt:
                    nomes.append(nome_prompt)
                    break

        if not nomes:
            for resultado in conjunto.resultados:
                nome_prompt = self.nome_prompt_yaml(resultado)
                if nome_prompt:
                    nomes.append(nome_prompt)
                    break

        if not nomes:
            raise ValueError("Conjunto sem nome de prompt YAML para exibir.")

        return " / ".join(nomes)

    def secoes_tendencia_conjunto(self, conjunto: Any) -> list[dict[str, Any]]:
        secoes = []

        for etapa_id, _, grupo_prompt in self.etapas_fluxo_final():
            resultado = self.resultado_conjunto_etapa(conjunto, grupo_prompt)
            if resultado is None:
                continue

            etapa = self.etapa_por_id(etapa_id)
            secoes.append(
                {
                    "titulo": self.rotulo_etapa(etapa_id),
                    "conteudo": self.html_subcards_resultado_llm(etapa, resultado),
                    "conteudo_html": True,
                    "texto_terminal": self.texto_terminal_resultado_llm(
                        etapa,
                        resultado,
                    ),
                }
            )

        return secoes

    def mostrar_fluxo_conjunto(
        self,
        conjunto: Any,
        numero: int,
    ) -> None:
        self.ui.card_com_secoes(
            self.titulo_card_conjunto(conjunto),
            secoes=self.secoes_tendencia_conjunto(conjunto),
            campos_rodape=self.campos_rodape_conjunto(conjunto),
        )

    def mostrar_conjuntos(self, conjuntos: list[Any]) -> None:
        self.mostrar_inicio_loop()
        grupos: dict[str, list[Any]] = {}

        for conjunto in conjuntos:
            grupos.setdefault(conjunto.tendencia or "Sem tendencia", []).append(conjunto)

        for tendencia, conjuntos_tendencia in grupos.items():
            self.mostrar_tendencia(tendencia)

            for numero, conjunto in enumerate(conjuntos_tendencia, start=1):
                self.mostrar_fluxo_conjunto(conjunto, numero)


def mostrar_falha_fluxo(erro: Exception) -> FalhaFluxo:
    mensagem = texto_curto(str(erro))
    if not mensagem:
        mensagem = erro.__class__.__name__

    falha = FalhaFluxo(
        tipo=erro.__class__.__name__,
        erro=mensagem,
    )
    ui = Visual()
    ui.aplicar_estilo()
    ui.final(
        {
            "Status": ui.status("erro"),
            "Tipo": falha.tipo,
            "Erro": falha.erro,
        }
    )
    return falha


def fluxo_geracao(
    provedor: Optional[str] = None,
    *,
    exibir_traceback: bool = False,
) -> Any:
    """Entrada unica chamada pela rotina-principal.ipynb."""

    try:
        provedor_normalizado = normalizar_provedor(provedor)
        status = preparar_ambiente(provedor_normalizado)

        if status.dependencias_ausentes:
            raise RuntimeError(
                "Dependencias ausentes: "
                + ", ".join(status.dependencias_ausentes)
                + "\n\nInstale as dependencias do projeto antes de executar o fluxo."
            )

        motor = importlib.import_module("src.motor")

        return Experiencia(
            motor=motor,
            status=status,
            provedor=provedor_normalizado,
        ).rodar()
    except Exception as erro:
        if exibir_traceback:
            raise

        return mostrar_falha_fluxo(erro)
