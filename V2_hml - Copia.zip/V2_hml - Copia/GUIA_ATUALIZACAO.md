# Guia de Atualização do Projeto via WSL (Para Desenvolvedores)

Este guia foi desenhado de forma simples e direta para ajudar na atualização completa do código deste projeto no ambiente corporativo, utilizando o terminal do WSL (Windows Subsystem for Linux). Siga os passos com atenção.

## Passo 1: Atualizar o Repositório e Criar uma Branch

Antes de qualquer modificação, precisamos garantir que estamos trabalhando com a versão mais recente e em uma branch (ramificação) isolada e segura.

```bash
# 1. Entre na pasta onde o repositório do projeto já está clonado no seu WSL
cd /caminho/para/a/pasta/do/projeto

# 2. Mude para a branch principal (pode se chamar "main" ou "master")
git checkout main

# 3. Baixe as atualizações mais recentes do servidor
git pull origin main

# 4. Crie uma nova branch para aplicar a nossa atualização. Isso protege o código original.
git checkout -b feature/atualizacao-novo-codigo
```

## Passo 2: Substituir o Código Antigo pelo Novo

Precisamos limpar os arquivos antigos para não deixar restos de código morto, mas **sem apagar a pasta do Git**.

```bash
# 1. Apague todos os arquivos e pastas locais (EXCETO a pasta oculta .git, que guarda o repositório).
# Copie e cole exatamente o comando abaixo no terminal:
find . -mindepth 1 -maxdepth 1 ! -name '.git' -exec rm -rf {} +
```
> **Dica**: Após rodar o comando acima, a pasta parecerá vazia se você usar o comando `ls`. Isso é esperado e o histórico do repositório está seguro!

**Ação Manual (Fora do Terminal):**
1. Pegue o **arquivo ZIP** com o novo código atualizado.
2. Descompacte o arquivo.
3. Copie **todo o conteúdo extraído** (como a pasta `iaa_agent_mf_edu_fin`, `tests`, e arquivos como `README.md`, `requirements.txt`) para dentro dessa pasta do projeto no WSL que você acabou de limpar.

## Passo 3: Registrar as Alterações no Git (Commit)

Agora que os arquivos novos estão na pasta correta, o Git vai notar a diferença. Precisamos "salvar" essa alteração.

```bash
# 1. Prepare todos os novos arquivos para serem "salvos" no commit
git add .

# 2. (Opcional) Digite git status e veja que os arquivos foram reconhecidos (ficarão verdes)
git status

# 3. Salve a alteração com uma mensagem clara sobre o que foi feito
git commit -m "feat: substituição e atualização completa do código da aplicação"
```

## Passo 4: Configurar e Rodar os Testes (Primeira Vez)

Para projetos em Python, a regra de ouro é sempre usar um "ambiente virtual". Isso evita que as bibliotecas do projeto se misturem com as do seu próprio computador.

```bash
# 1. Crie o ambiente virtual (isso vai criar uma pasta chamada .venv)
python3 -m venv .venv

# 2. Ative o ambiente virtual no seu terminal WSL
source .venv/bin/activate

# 3. Instale todas as dependências do projeto
pip install -r requirements.txt

# 4. Instale as configurações do próprio projeto localmente 
pip install -e .
```

### Validando se está tudo funcionando
Deixamos testes criados para garantir a segurança da aplicação.

```bash
# Rode a suíte de testes dentro da pasta "tests/" 
pytest tests/ -v
```

**Os testes passaram? Ficou tudo verdinho?**
Maravilha! Você já pode subir o seu código para o servidor:

```bash
# Envie a sua branch para o repositório remoto (ex: GitHub, GitLab, Bitbucket)
git push origin feature/atualizacao-novo-codigo
```

A partir daqui, é só seguir o processo padrão da empresa (abrir o Pull Request / Merge Request para a main). Bom trabalho!
