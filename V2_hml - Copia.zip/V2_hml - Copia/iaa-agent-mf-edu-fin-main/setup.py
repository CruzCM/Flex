# -*- encoding: utf-8 -*-
# Referência: https://packaging.python.org/guides/distributing-packages-using-setuptools/

import io
import re

from setuptools import find_packages, setup

common_requirements = [
    'pytest',
    'pytest-asyncio',
    'httpx>=0.27',
]

dev_requirements = [
    'bandit',
    'flake8',
    'isort',
] + common_requirements

unit_test_requirements = common_requirements

integration_test_requirements = common_requirements

# Uma única lista evita divergência entre instalação do pacote e imagem.
with io.open('requirements.txt', encoding='utf8') as requirements_file:
    run_requirements = [
        line.strip() for line in requirements_file
        if line.strip() and not line.lstrip().startswith('#')
    ]

with io.open('./iaa_agent_mf_edu_fin/__init__.py', encoding='utf8') as version_f:
    version_match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]",
                              version_f.read(), re.M)
    if version_match:
        version = version_match.group(1)
    else:
        raise RuntimeError("Não foi possível encontrar a string de versão.")

with io.open('README.md', encoding='utf8') as readme:
    long_description = readme.read()

setup(
    name="iaa_agent_mf_edu_fin",
    version=version,
    author="Banco do Brasil S.A.",
    author_email="ditec@bb.com.br",
    packages=find_packages(exclude=['tests', 'tests.*']),
    include_package_data=True,
    url="https://canais.fontes.intranet.bb.com.br/iaa/iaa-agent-mf-edu-fin/iaa-agent-mf-edu-fin",
    license="COPYRIGHT",
    description="Agente stateless com execução linear, FastAPI, RAG e guardrails.",
    long_description=long_description,
    zip_safe=False,
    install_requires=run_requirements,
    extras_require={
         'dev': dev_requirements,
         'unit': unit_test_requirements,
         'integration': integration_test_requirements,
    },
    python_requires='>=3.11',
    classifiers=[
        'Intended Audience :: Information Technology',
        'Natural Language :: Portuguese (Brazilian)',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3.11'
    ],
    keywords=[],
    entry_points={
        'console_scripts': [
            'iaa_agent_mf_edu_fin = iaa_agent_mf_edu_fin.__main__:main'
        ],
    },
)
