# iaa-agent-mf-edu-fin

Agente stateless de educação financeira com FastAPI, RAG e execução linear em
Python. Cada chamada usa somente a pergunta recebida e os documentos recuperados
para ela. Não há memória de conversa nem persistência de respostas.

A simplificação arquitetural é deliberada: a aplicação controla a ordem das
operações, e o componente de inteligência participa apenas por um contrato de
entrada e saída. Comentários explicam a intenção de cada bloco.

## Fluxo

Guardrails de entrada → escopo → recuperação documental → avaliação de contexto
→ prompt seguro → geração → validadores → guardrails de saída.

- Fora do escopo: resposta configurada, sem recuperação ou modelo.
- Escopo indeterminado: continua para recuperação.
- Ausência documental: resposta própria, sem avaliação ou geração.
- Erro ou contexto inconsistente: indisponibilidade, sem geração alternativa.
- Contexto válido: o judge mede qualidade; score baixo ou falha não bloqueia.
- Geração: documentos delimitados como dados, separados da instrução de sistema.
- Saída: toxicidade, não aconselhamento e PII são avaliados; o middleware aplica
  também bloqueio de frases e redação de dados pessoais.

## Responsabilidades

| Componente | Responsabilidade |
| --- | --- |
| `domain.py` | Contratos Python de mensagem, recuperação e modelo |
| `workflow.py` | `AgentWorkflow.run(question: str) -> str`, assíncrono |
| `bootstrap.py` | Composição com configuração capturada por instância |
| `app.py` | Contratos HTTP, ciclo de vida e dependência do workflow |
| `rag/client.py` | Payload HTTP, parser e classificação da recuperação |
| `llm/` | Adapter LangChain, factory e transporte Gateway |
| `validators/` | Qualidade de contexto e regras de resposta |
| `utils/` | Guardrails e instrumentação operacional |

`LanguageModel.generate(messages) -> str` e
`ContextRetriever.retrieve(question) -> RAGResponse` são assíncronos.
`PromptMessage` carrega apenas papel e texto. Nenhum objeto do SDK chega ao
workflow, à API ou aos validadores. O LangChain fica exclusivamente no adapter.

Clientes são construídos sob demanda e reutilizados; perguntas, documentos e
respostas são locais à chamada. O shutdown fecha os pools HTTP. Cancelamento da
requisição não é convertido em aprovação do judge.

## API

| Rota | Contrato |
| --- | --- |
| `POST /chat` | Entrada `message` e `session_id` opcional |
| `GET /metrics` | Uptime, requisições, identidade do agente |
| `GET /health/live` | Processo ativo |
| `GET /health/ready` | Configuração operacional e workflow inicializado |

A resposta de chat contém `reply`, `session_id` e `tool_calls_made`.
`session_id` é somente ecoado; `tool_calls_made` permanece zero por compatibilidade.
Estrutura inválida retorna 422, bloqueio de entrada retorna 400 e falha de execução
retorna 500 com mensagem genérica. Saídas controladas preservam HTTP 200.

Probes não consultam serviços externos. Readiness 200 não comprova integração.

## Configuração

`agent_config.yaml` define identidade, instruções, política de escopo, respostas,
parâmetros do modelo, RAG e guardrails. Nesta cópia, `rag.enabled: false` mantém
indisponibilidade para perguntas elegíveis e readiness 503.

O RAG usa `data.retrieved_contexts[*].passage_text`. `index_id` tem precedência
sobre `agent_id`. Itens inválidos são falha técnica; textos vazios são descartados.

O judge usa temperatura 0.0 e `top_p=1.0`; a geração usa os parâmetros configurados.
Ambos usam o provider selecionado. O transporte preserva endpoint, modelo, versão
da API, limite de tokens, TLS e autenticação do Gateway, sem retries.

Credenciais são fornecidas pelo ambiente: `RAG_CLIENT_ID`,
`GATEWAY_OUTBOUND_GW_APP_KEY` e, quando habilitado, `GUARDRAIL_EXTERNAL_CLIENT_ID`.
Certificados e CAs usam as variáveis já previstas no provider. Não gravar valores
secretos nos arquivos de configuração.

## Observabilidade

OpenTelemetry registra escopo, resultado e duração do RAG e da geração, além de
score, ação e duração dos validadores. Não registrar perguntas, documentos,
respostas, credenciais ou justificativas livres do judge.

A exportação Azure Monitor depende de configuração explícita. A presença da
configuração não demonstra que um collector recebeu dados.

## Validação local

Requer Python 3.11 ou superior. `requirements.txt` é a lista única de execução,
também usada pelo empacotamento. Os testes usam `pytest` e `pytest-asyncio`.

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD = '1'
$testTemp = Join-Path (Get-Location) ('.pytest-tmp-' + [guid]::NewGuid().ToString('N'))
./.venv/Scripts/python.exe -m pytest -p pytest_asyncio.plugin -q --basetemp=$testTemp
```

Os testes bloqueiam rede e usam doubles nas integrações, HTTP em memória e exporter
em memória. Exercitam regras, payloads, concorrência, contratos e ciclo de vida.
Esses resultados são **VALIDAÇÃO LOCAL**, não disponibilidade ou autenticação real.

Serviços, certificados, imagens e execução corporativa permanecem
**NÃO VALIDADOS CORPORATIVAMENTE**. Não executar a aplicação contra esses serviços
neste workspace. Consulte [as decisões da refatoração](REFATORACAO.md).
