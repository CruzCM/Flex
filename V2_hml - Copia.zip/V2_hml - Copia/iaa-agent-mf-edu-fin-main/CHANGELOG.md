# Changelog

Todas as mudanças notáveis serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](http://keepachangelog.com/pt-BR/1.0.0/) e este projeto adere ao padrão [Semantic Versioning](http://semver.org/lang/pt-BR/spec/v2.0.0.html).

## [Não liberado]

### Adicionado

### Corrigido

### Modificado

### Obsoleto

### Removido

## [0.1.0-SNAPSHOT](https://canais.fontes.intranet.bb.com.br/iaa/iaa-agent-mf-edu-fin/iaa-agent-mf-edu-fin/tags/0.1.0-SNAPSHOT) - aaaa-mm-dd

### Adicionado
- Primeira versão
