# Decisões e validação da refatoração

## Resultado arquitetural

A aplicação executa cada pergunta por `AgentWorkflow.run`, com recuperação,
avaliação, geração e validação explícitas. O domínio usa contratos Python. O
LangChain fica restrito ao adapter LLM e seus testes específicos.

A simplificação e a retirada de capacidades sem uso no fluxo são intencionais.
Não há mecanismo alternativo de execução, memória conversacional nem persistência.

## Justificativas

| Mudança | Necessidade e compatibilidade | Alternativa considerada |
| --- | --- | --- |
| Contratos e workflow | Isolar inteligência e tornar a ordem explícita; mantém as regras de chat | Envolver a implementação anterior manteria o acoplamento |
| Adapter e factory | Conter mensagens e falhas do SDK; mantém transporte e parâmetros do Gateway | Converter apenas na rota deixaria o judge acoplado |
| RAG e judge | Usar contratos próprios; mantém parser, payload e avaliação observacional | Manter wrappers sem uso acrescentaria dependências |
| Composição e lifecycle | Reutilizar clientes sem conteúdo compartilhado; fecha pools | Construir clientes a cada chamada desperdiçaria conexões |
| Configuração | Retirar opções sem implementação; mantém configuração ativa e fallback do índice | Aceitar configurações mortas sugeriria capacidades inexistentes |
| Testes | Verificar contratos e isolamento, substituindo apenas fronteiras externas | Testar somente doubles do workflow não demonstraria suas regras |
| Dependências e manifesto | Usar uma lista única e incluir requisitos no pacote fonte | Listas duplicadas poderiam voltar a divergir |
| Documentos e comentários | Descrever arquitetura mantida e intenção dos blocos | Conservar descrições antigas confundiria a manutenção |
| Exclusões de artefatos | Evitar temporários e evidências locais na imagem | Copiar todo o workspace incluiria materiais sem função no runtime |

As interfaces Python de execução foram substituídas deliberadamente. A API HTTP
mantém `message`, `reply`, `session_id` ecoado e `tool_calls_made=0`. A mensagem de
readiness passa a descrever inicialização do workflow.

## Evidência local

O baseline teve 224 aprovações e nove falhas por dependências ausentes.
O ambiente virtual existente foi completado com pacotes públicos; nenhum serviço
corporativo foi acessado. Testes bloqueiam rede e usam HTTP e exporters em memória.

A suíte cobre decisões, prompts, respostas, concorrência, transporte, probes,
telemetria e isolamento de bibliotecas. O teste de SDK real usa transporte em
memória: demonstra a adaptação local, não integração corporativa.

Resultados finais são registrados no encerramento desta execução. A runtime
utilizada é Python 3.13; execução na imagem corporativa Python 3.11 não foi feita.
Não há metadados Git disponíveis para comprovar branch, commit ou limpeza inicial.

## Limite da limpeza

A revisão automática de aprovação bloqueou a exclusão recursiva agrupada de
materiais históricos e da cópia antiga de dependências, com a razão genérica
“blocked by policy”. Os documentos foram atualizados no próprio lugar.

As pastas `.deps311` e `evidencias_a0_v2` ainda contêm material histórico e não
integram o runtime validado, o pacote construído ou a imagem descrita pelo
Dockerfile. Não usar seus resultados como evidência desta implementação.
A limpeza física integral dessas pastas permanece pendente.

Toda conclusão desta entrega é **VALIDAÇÃO LOCAL**. Serviços, publicação, deploy,
autenticação e telemetria corporativos são **NÃO VALIDADOS CORPORATIVAMENTE**.
