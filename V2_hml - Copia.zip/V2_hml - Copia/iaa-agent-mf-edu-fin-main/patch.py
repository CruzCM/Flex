with open('tests/unit/test_rag_client.py', 'r', encoding='utf-8') as f:
    code = f.read()
code = code.replace('.chunks .chunks', '.chunks')
with open('tests/unit/test_rag_client.py', 'w', encoding='utf-8') as f:
    f.write(code)
