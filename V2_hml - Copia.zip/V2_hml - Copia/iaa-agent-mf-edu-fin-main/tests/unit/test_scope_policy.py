"""Corpus de aceite local da política determinística de escopo do MVP."""

from pathlib import Path

import yaml

from iaa_agent_mf_edu_fin.config import load_agent_config
from iaa_agent_mf_edu_fin.scope_policy import KeywordScopePolicy, ScopeResult


# Caminhos fixos ligam o teste à configuração e ao corpus reais da instância.
_ROOT = Path(__file__).parents[2]
_CORPUS = _ROOT / "tests" / "fixtures" / "scope_policy_mvp_v1.yaml"


def _load_policy_and_cases():
    config = load_agent_config(_ROOT / "agent_config.yaml")
    policy = KeywordScopePolicy.from_config(config.scope)
    corpus = yaml.safe_load(_CORPUS.read_text(encoding="utf-8"))
    return policy, corpus


def test_scope_policy_matches_versioned_corpus():
    policy, corpus = _load_policy_and_cases()

    # Impede executar um corpus antigo contra uma versão nova da política.
    assert corpus["policy_version"] == policy.version
    for case in corpus["cases"]:
        assert policy.evaluate(case["message"]).value == case["expected"], case["id"]


def test_scope_policy_is_deterministic():
    policy, _ = _load_policy_and_cases()
    message = "Como organizar meu planejamento financeiro?"

    # Repetições idênticas devem produzir um único resultado.
    results = {policy.evaluate(message) for _ in range(20)}

    assert results == {ScopeResult.IN_SCOPE}


def test_scope_policy_ignores_case_and_accents():
    policy, _ = _load_policy_and_cases()

    # Normalização permite texto sem acento sem ampliar o significado da regra.
    assert policy.evaluate("COMO MONTAR MEU ORCAMENTO?") is ScopeResult.IN_SCOPE
