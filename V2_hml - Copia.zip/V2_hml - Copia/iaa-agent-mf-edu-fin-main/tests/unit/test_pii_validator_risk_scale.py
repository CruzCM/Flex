"""Unit tests for PII validator risk score semantics (1 = risk, 0 = clean)."""

import pytest

from iaa_agent_mf_edu_fin.validators.pii_validator import PIIValidator


def test_pii_clean_text_has_zero_risk():
    validator = PIIValidator()

    result = validator.validate("sem dados sensiveis aqui")

    assert result.passed is True
    assert result.score == pytest.approx(0.0)


def test_pii_detected_text_has_full_risk():
    validator = PIIValidator()

    result = validator.validate("meu email e pessoa@empresa.com")

    assert result.passed is False
    assert result.score == pytest.approx(1.0)
    assert "email" in result.metadata["pii_types"]


def test_pii_invalid_cpf_keeps_zero_risk():
    validator = PIIValidator()

    result = validator.validate("meu cpf e 123.456.789-00")

    assert result.passed is True
    assert result.score == pytest.approx(0.0)
