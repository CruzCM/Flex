"""Testes unitários para iaa_agent_mf_edu_fin/config.py."""

import textwrap
from pathlib import Path

import pytest

from unittest.mock import patch

from iaa_agent_mf_edu_fin.config import (
    AgentConfig,
    LLMConfig,
    RAGConfig,
    get_config,
    load_agent_config,
)


# ---------------------------------------------------------------------------
# Auxiliares
# ---------------------------------------------------------------------------

MINIMAL_YAML = textwrap.dedent("""\
    agent_id: "test-agent"
    agent_name: "Test Agent"
    deployment: "test"
    instructions: "Be helpful."
    agent_description: "A test agent."
    temperature: 0.5
    top_p: 0.9
    llm:
      provider: "gateway_outbound"
      gateway_outbound:
        base_url: "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"
        model: "cambio-non-prod-gpt4o"
        api_version: "2024-12-01-preview"
        max_tokens: 4096
    guardrails:
      enabled: false
      url: "https://fake-guardrail/gateway/agent"
      user_id: "test-user"
      uor: "12345"
      agent_id: "agente-curador-iagen"
      timeout: 3.0
    rag:
      enabled: false
      url: "https://fake-rag/gateway/core"
      uor: "12345"
      user_id: "test-user"
      index_id: "idx-test"
      agent_id: "legacy-test-rag-agent"
      total_context: 3
      timeout: 15.0
    scope:
      enabled: true
      policy: "keyword"
      version: "test-v1"
      in_scope_terms: ["orçamento"]
      out_of_scope_terms: ["previsão do tempo"]
    responses:
      out_of_scope: "fora"
      no_context: "sem contexto"
      unavailable: "indisponível"
    metadata:
      owner: "test-team"
      version: "1.2.3"
      created_at: "2026-01-01"
""")


@pytest.fixture()
def config_file(tmp_path: Path) -> Path:
    """Escreve um agent_config.yaml mínimo em um diretório temporário."""
    p = tmp_path / "agent_config.yaml"
    p.write_text(MINIMAL_YAML, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# load_agent_config
# ---------------------------------------------------------------------------


def test_load_returns_agent_config(config_file):
    cfg = load_agent_config(config_file)
    assert isinstance(cfg, AgentConfig)


def test_load_scalar_fields(config_file):
    cfg = load_agent_config(config_file)
    assert cfg.agent_id == "test-agent"
    assert cfg.agent_name == "Test Agent"
    assert cfg.temperature == pytest.approx(0.5)
    assert cfg.top_p == pytest.approx(0.9)


def test_load_metadata(config_file):
    cfg = load_agent_config(config_file)
    assert cfg.metadata.version == "1.2.3"
    assert cfg.metadata.owner == "test-team"


def test_load_llm_provider(config_file):
    cfg = load_agent_config(config_file)
    assert isinstance(cfg.llm, LLMConfig)
    assert cfg.llm.provider == "gateway_outbound"


def test_load_rag_prefers_index_id(config_file):
    cfg = load_agent_config(config_file)
    # index_id é o contrato atual e sempre vence o agent_id legado.
    assert cfg.rag.index_id == "idx-test"
    assert cfg.rag.resolved_index_id == "idx-test"


def test_rag_uses_legacy_agent_id_only_as_fallback():
    cfg = RAGConfig(index_id="", agent_id="legacy-index")
    # O fallback evita quebrar configurações antigas ainda não migradas.
    assert cfg.resolved_index_id == "legacy-index"


def test_load_scope_and_responses(config_file):
    cfg = load_agent_config(config_file)
    # O loader deve expor política versionada e os três fast-exits.
    assert cfg.scope.version == "test-v1"
    assert cfg.scope.in_scope_terms == ["orçamento"]
    assert cfg.responses.out_of_scope == "fora"
    assert cfg.responses.no_context == "sem contexto"
    assert cfg.responses.unavailable == "indisponível"


def test_load_raises_when_file_missing(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_agent_config(tmp_path / "nonexistent.yaml")


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------


def test_load_raises_when_no_candidates_found(tmp_path, monkeypatch):
    """load_agent_config(path=None) deve lançar FileNotFoundError quando nenhum
    candidato padrão existe (cobre o bloco else do for-else em config.py)."""
    monkeypatch.chdir(tmp_path)
    # Faz todos os candidatos retornarem is_file() == False
    from pathlib import Path as _Path

    def _never_exists(self):
        return False

    monkeypatch.setattr(_Path, "is_file", _never_exists)
    with pytest.raises(FileNotFoundError, match="agent_config.yaml"):
        load_agent_config(path=None)


def test_load_auto_discovers_config_in_cwd(tmp_path, monkeypatch):
    """load_agent_config(path=None) deve encontrar o arquivo no cwd quando o
    primeiro candidato (raiz do repo) não existir."""
    cfg_file = tmp_path / "agent_config.yaml"
    cfg_file.write_text(MINIMAL_YAML, encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    from pathlib import Path as _Path

    def _only_cwd(self):
        # Somente o candidato que aponta para cwd existe
        return str(self) == str(tmp_path / "agent_config.yaml")

    monkeypatch.setattr(_Path, "is_file", _only_cwd)
    cfg = load_agent_config(path=None)
    assert isinstance(cfg, AgentConfig)
    assert cfg.agent_id == "test-agent"


def test_get_config_returns_agent_config(config_file, monkeypatch):
    """Cobre o corpo de get_config() na primeira chamada (linhas 181-183)."""
    import iaa_agent_mf_edu_fin.config as _cm

    monkeypatch.setattr(_cm, "_config", None)
    with patch("iaa_agent_mf_edu_fin.config.load_agent_config", return_value=load_agent_config(config_file)):
        result = get_config()
    assert isinstance(result, AgentConfig)


def test_get_config_returns_cached_on_second_call(config_file, monkeypatch):
    """get_config() deve retornar o mesmo objeto em chamadas sucessivas (path cacheado)."""
    import iaa_agent_mf_edu_fin.config as _cm

    real_cfg = load_agent_config(config_file)
    monkeypatch.setattr(_cm, "_config", None)
    with patch.object(_cm, "load_agent_config", return_value=real_cfg):
        first = _cm.get_config()
        second = _cm.get_config()

    assert first is second
