"""A aplicação depende de contratos próprios; SDKs ficam na fronteira LLM."""

import ast
from pathlib import Path


def test_sdk_imports_are_confined_to_adapter_package():
    package = Path(__file__).parents[2] / "iaa_agent_mf_edu_fin"
    for path in package.rglob("*.py"):
        if path.is_relative_to(package / "llm"):
            continue
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
            imports = ([node.module or ""] if isinstance(node, ast.ImportFrom)
                       else [alias.name for alias in node.names] if isinstance(node, ast.Import) else [])
            assert all(not name.startswith(("langchain", "openai")) for name in imports), path


def test_domain_imports_only_standard_library():
    domain = Path(__file__).parents[2] / "iaa_agent_mf_edu_fin" / "domain.py"
    allowed = {"dataclasses", "enum", "typing"}
    for node in ast.walk(ast.parse(domain.read_text(encoding="utf-8"))):
        if isinstance(node, ast.ImportFrom):
            assert node.module in allowed
        if isinstance(node, ast.Import):
            assert all(alias.name in allowed for alias in node.names)
