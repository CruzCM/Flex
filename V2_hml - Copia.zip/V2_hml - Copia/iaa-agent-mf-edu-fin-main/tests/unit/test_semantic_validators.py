"""Unit tests for hybrid regex + semantic validators."""

import pytest

from iaa_agent_mf_edu_fin.validators.non_advice import NonAdviceValidator
from iaa_agent_mf_edu_fin.validators.toxicity import ToxicityValidator


def test_toxicity_semantic_detects_similar_threat():
    validator = ToxicityValidator(semantic_enabled=True)

    # Use the exact seed phrase so SequenceMatcher (fallback when rapidfuzz is absent)
    # returns similarity=1.0, giving effective_weight=0.6 > threshold=0.5.
    result = validator.validate("I will destroy you.")

    assert result.passed is False
    assert result.score > 0.5
    assert result.metadata["semantic_matches"].get("threats")


def test_toxicity_semantic_disabled_does_not_flag_same_text():
    validator = ToxicityValidator(semantic_enabled=False)

    result = validator.validate("I will destroy you.")

    assert result.passed is True
    assert result.score == pytest.approx(0.0)
    assert result.metadata["categories"] == []


def test_non_advice_semantic_detects_similar_financial_advice():
    validator = NonAdviceValidator(semantic_enabled=True)

    result = validator.validate("If I were you, I would buy that stock immediately.")

    assert result.passed is False
    assert result.score > 0.5
    assert result.metadata["semantic_matches"].get("financial")


def test_non_advice_caveat_reduces_semantic_severity():
    validator = NonAdviceValidator(semantic_enabled=True)

    text = (
        "If I were you, I would buy that stock immediately. "
        "This is not financial advice; consult a financial advisor."
    )
    result = validator.validate(text)

    assert result.passed is True
    assert result.score < 0.5
    assert result.metadata["has_caveat"] is True
