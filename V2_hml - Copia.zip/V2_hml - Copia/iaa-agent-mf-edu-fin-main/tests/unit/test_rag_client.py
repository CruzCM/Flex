"""Testes unitários para iaa_agent_mf_edu_fin/rag/client.py."""

import json
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

import iaa_agent_mf_edu_fin.rag.client as rag_module
from iaa_agent_mf_edu_fin.rag.client import _call_gateway, _extract_contexts, RAGResult


# ---------------------------------------------------------------------------
# Auxiliares
# ---------------------------------------------------------------------------

def _make_rag_cfg(enabled=True, client_id="cid", index_id="idx-test", agent_id=""):
    cfg = MagicMock()
    cfg.rag.enabled = enabled
    cfg.rag.index_id = index_id
    cfg.rag.agent_id = agent_id
    cfg.rag.resolved_index_id = index_id or agent_id
    cfg.rag.uor = "uor"
    cfg.rag.user_id = "uid"
    cfg.rag.url = "https://rag.invalid/gateway/core"
    cfg.rag.total_context = 5
    cfg.rag.timeout = 5.0
    return cfg, client_id


@contextmanager
def _patch_rag(enabled=True, client_id="cid", index_id="idx-test", agent_id=""):
    """Patcha get_config e RAG_CLIENT_ID, e reseta o cliente HTTP entre testes."""
    cfg, cid = _make_rag_cfg(
        enabled=enabled,
        client_id=client_id,
        index_id=index_id,
        agent_id=agent_id,
    )
    rag_module._http_client = None  # força recriação do cliente
    with patch("iaa_agent_mf_edu_fin.rag.client.get_config", return_value=cfg):
        with patch.dict("os.environ", {"RAG_CLIENT_ID": cid} if cid else {}, clear=False):
            if not cid:
                import os
                os.environ.pop("RAG_CLIENT_ID", None)
            yield


def _mock_response(body: dict, status_code: int = 200):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = body
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    else:
        resp.raise_for_status.return_value = None
    return resp


def _mock_http_client(post_return=None, post_side_effect=None):
    """Cria um mock de AsyncClient e injeta no módulo."""
    mock_client = MagicMock(spec=httpx.AsyncClient)
    if post_side_effect:
        mock_client.post = AsyncMock(side_effect=post_side_effect)
    else:
        mock_client.post = AsyncMock(return_value=post_return)
    rag_module._http_client = mock_client
    return mock_client


# ---------------------------------------------------------------------------
# _call_gateway - desativado / não configurado
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_disabled_returns_empty():
    with _patch_rag(enabled=False):
        result = await _call_gateway("test query")
    assert result.chunks == []
    assert result.result == RAGResult.INFRA_ERROR


@pytest.mark.asyncio
async def test_missing_client_id_returns_empty():
    with _patch_rag(client_id=""):
        result = await _call_gateway("test query")
    assert result.chunks == []
    assert result.result == RAGResult.INFRA_ERROR


@pytest.mark.asyncio
async def test_missing_index_id_returns_empty():
    with _patch_rag(index_id="", agent_id=""):
        result = await _call_gateway("test query")
    assert result.chunks == []
    assert result.result == RAGResult.INFRA_ERROR


# ---------------------------------------------------------------------------
# _call_gateway - contrato oficial de índice direto
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_success_uses_documented_synthetic_fixture():
    # Fixture sintética baseada no guia representa data.retrieved_contexts[*].passage_text.
    fixture_path = Path(__file__).parents[1] / "fixtures" / "generabb_retrieved_contexts.json"
    body = json.loads(fixture_path.read_text(encoding="utf-8"))
    resp = _mock_response(body)

    with _patch_rag():
        _mock_http_client(post_return=resp)
        result = await _call_gateway("what is X?")

    assert result.chunks == [
        "Uma reserva de emergência deve ser planejada de acordo com as despesas essenciais e a realidade do orçamento familiar.",
        "Registrar receitas e despesas ajuda a identificar oportunidades de ajuste no orçamento.",
    ]


@pytest.mark.asyncio
async def test_success_with_no_context_returns_empty():
    resp = _mock_response({"data": {"retrieved_contexts": [], "similarities": []}})

    with _patch_rag():
        _mock_http_client(post_return=resp)
        result = await _call_gateway("what is X?")

    assert result.chunks == []
    assert result.result == RAGResult.NO_CONTEXT


def test_malformed_context_item_is_not_coerced_to_string():
    # Campos legados desconhecidos não podem ser aceitos silenciosamente.
    assert _extract_contexts({"data": {"retrieved_contexts": [{"content": "legacy"}]}}) .chunks == []


@pytest.mark.asyncio
async def test_success_custom_total_context():
    """Payload usa action, query híbrida e index_id sem histórico."""
    resp = _mock_response({"data": {"retrieved_contexts": [{"passage_text": "x"}]}})

    with _patch_rag():
        mock_client = _mock_http_client(post_return=resp)
        result = await _call_gateway("query", total_context=3)

    assert result.chunks == ["x"]
    call_kwargs = mock_client.post.call_args
    payload = call_kwargs.kwargs.get("json") or call_kwargs.args[1]
    # Confirma o contrato de índice direto e a ausência de histórico/agent_id.
    assert payload["action"] == "recuperar-contexto-indice"
    assert payload["body"]["data"]["input"] == "query"
    assert payload["body"]["data"]["index_id"] == "idx-test"
    assert payload["body"]["data"]["context"]["query_type"] == "hybrid"
    assert payload["body"]["data"]["context"]["total_context"] == 3
    assert "messages" not in payload["body"]["data"]["context"]
    assert "agent_id" not in payload


@pytest.mark.asyncio
async def test_unexpected_context_shape_returns_empty():
    """Estrutura inválida é INFRA_ERROR; não é ausência documental."""
    resp = _mock_response({"body": {"data": {"context": "not-a-list"}}})

    with _patch_rag():
        _mock_http_client(post_return=resp)
        result = await _call_gateway("query")

    assert result.chunks == []
    assert result.result == RAGResult.INFRA_ERROR


# ---------------------------------------------------------------------------
# _call_gateway - tratamento de erros
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_timeout_returns_empty():
    with _patch_rag():
        _mock_http_client(post_side_effect=httpx.TimeoutException("timed out"))
        result = await _call_gateway("query")

    assert result.chunks == []
    assert result.result == RAGResult.INFRA_ERROR


@pytest.mark.asyncio
async def test_http_4xx_returns_empty():
    resp = _mock_response({}, status_code=404)

    with _patch_rag():
        _mock_http_client(post_return=resp)
        result = await _call_gateway("query")

    assert result.chunks == []
    assert result.result == RAGResult.INFRA_ERROR


@pytest.mark.asyncio
async def test_generic_exception_returns_empty():
    with _patch_rag():
        _mock_http_client(post_side_effect=RuntimeError("unexpected"))
        result = await _call_gateway("query")

    assert result.chunks == []
    assert result.result == RAGResult.INFRA_ERROR


# ---------------------------------------------------------------------------
