"""Contratos HTTP com aplicação real e dependência textual controlada."""
import importlib
from types import SimpleNamespace
from unittest.mock import AsyncMock
import httpx
import pytest
import pytest_asyncio


@pytest.fixture
def mock_workflow(monkeypatch):
    appmod = importlib.import_module("iaa_agent_mf_edu_fin.app")
    workflow = SimpleNamespace(run=AsyncMock(return_value="Resposta de teste."))
    monkeypatch.setattr(appmod.app.state, "workflow", workflow, raising=False)
    return workflow


@pytest_asyncio.fixture
async def client(mock_workflow):
    appmod = importlib.import_module("iaa_agent_mf_edu_fin.app")
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=appmod.app), base_url="http://test") as client:
        yield client


@pytest.mark.asyncio
async def test_health_live_returns_200(client):
    response = await client.get("/health/live")
    assert response.status_code == 200
    assert response.json() == {"status": "alive"}


@pytest.mark.asyncio
async def test_ready_configuration_and_initialization(client, monkeypatch):
    appmod = importlib.import_module("iaa_agent_mf_edu_fin.app")
    from iaa_agent_mf_edu_fin.config import load_agent_config
    cfg = load_agent_config()
    cfg.rag.enabled = True
    cfg.rag.user_id, cfg.rag.uor = "controlled-user", "controlled-uor"
    monkeypatch.setenv("RAG_CLIENT_ID", "controlled-token")
    monkeypatch.setenv("GATEWAY_OUTBOUND_GW_APP_KEY", "controlled-key")
    monkeypatch.setattr(appmod, "get_config", lambda: cfg)
    assert (await client.get("/health/ready")).status_code == 200
    monkeypatch.setattr(appmod.app.state, "workflow", None)
    response = await client.get("/health/ready")
    assert response.status_code == 503
    assert response.json()["detail"] == "Workflow ainda não inicializado."
    monkeypatch.setattr(appmod, "get_config", lambda: 1 / 0)
    assert (await client.get("/health/ready")).status_code == 503


@pytest.mark.asyncio
async def test_metrics_count_and_shape(client):
    before = (await client.get("/metrics")).json()
    await client.post("/chat", json={"message": "orçamento"})
    after = (await client.get("/metrics")).json()
    assert set(after) == {"uptime_seconds", "total_requests", "agent_id", "agent_name"}
    assert after["total_requests"] == before["total_requests"] + 1
    assert isinstance(after["uptime_seconds"], float)


@pytest.mark.asyncio
@pytest.mark.parametrize("session_id", [None, "same-session"])
@pytest.mark.parametrize("reply", ["Resposta de teste.", "", "  espaços preservados  "])
async def test_chat_contract(client, mock_workflow, session_id, reply):
    mock_workflow.run.return_value = reply
    for question in ("primeira pergunta", "segunda pergunta"):
        response = await client.post("/chat", json={"message": question, "session_id": session_id})
        assert response.status_code == 200
        assert response.json() == {"reply": reply, "session_id": session_id, "tool_calls_made": 0}
        mock_workflow.run.assert_awaited_with(question)


@pytest.mark.asyncio
async def test_execution_error_is_generic(client, mock_workflow, caplog):
    mock_workflow.run.side_effect = RuntimeError("SEGREDO_SENTINELA")
    response = await client.post("/chat", json={"message": "orçamento"})
    assert response.status_code == 500
    assert response.json() == {"detail": "Erro interno do servidor."}
    assert "SEGREDO_SENTINELA" not in caplog.text


@pytest.mark.asyncio
async def test_missing_message(client, mock_workflow):
    assert (await client.post("/chat", json={})).status_code == 422
    mock_workflow.run.assert_not_called()
