"""Qualidade observacional com contrato Python e respostas controladas."""
from types import SimpleNamespace
from unittest.mock import AsyncMock
import pytest
from iaa_agent_mf_edu_fin.domain import PromptMessage
from iaa_agent_mf_edu_fin.validators.context_precision import ContextPrecisionValidator


@pytest.mark.asyncio
@pytest.mark.parametrize("context,score", [
    (None, 1.0), ({"query": ""}, 1.0), ({"query": "q", "chunks": []}, 0.0),
])
async def test_skips_without_usable_input(context, score):
    judge = SimpleNamespace(generate=AsyncMock())
    result = await ContextPrecisionValidator(judge).avalidate("", context)
    assert result.score == score
    judge.generate.assert_not_called()


@pytest.mark.asyncio
@pytest.mark.parametrize("content,score", [
    ('{"score": 0.8, "reason": "relevante"}', 0.8),
    ('```json\n{"score": 0.1}\n```', 0.1),
    ('{"score": 2}', 1.0), ('{"score": -1}', 0.0),
    ('{"reason": "sem score"}', 0.0), ('[]', 0.0), ('inválido', 0.0),
])
async def test_real_prompt_parser_and_score(content, score):
    judge = SimpleNamespace(generate=AsyncMock(return_value=content))
    validator = ContextPrecisionValidator(judge)
    result = await validator.avalidate("", {"query": "orçamento", "chunks": ["a" * 600, "segundo"]})
    assert result.score == pytest.approx(score)
    assert result.passed == (score >= validator.threshold)
    messages = judge.generate.call_args.args[0]
    assert all(isinstance(message, PromptMessage) for message in messages)
    assert [message.role for message in messages] == ["system", "user"]
    assert "orçamento" in messages[-1].content
    assert "a" * 500 in messages[-1].content and "a" * 501 not in messages[-1].content
    assert "[Chunk 2]: segundo" in messages[-1].content


@pytest.mark.asyncio
async def test_judge_failure_is_observational(caplog):
    judge = SimpleNamespace(generate=AsyncMock(side_effect=RuntimeError("SEGREDO_SENTINELA")))
    result = await ContextPrecisionValidator(judge).avalidate("", {"query": "q", "chunks": ["c"]})
    assert result.passed and result.score == 0.5
    assert result.metadata == {"error": "judge_error"}
    assert "SEGREDO_SENTINELA" not in caplog.text
