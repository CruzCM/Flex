"""Decisões, isolamento e ciclo de vida do fluxo de uma pergunta."""

import asyncio
import importlib
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from iaa_agent_mf_edu_fin.bootstrap import create_workflow
from iaa_agent_mf_edu_fin.config import load_agent_config
from iaa_agent_mf_edu_fin.domain import InvalidModelResponse, RAGResponse, RAGResult
from iaa_agent_mf_edu_fin.workflow import AgentWorkflow


@pytest.fixture
def dependencies():
    config = load_agent_config()
    retriever = SimpleNamespace(retrieve=AsyncMock(return_value=RAGResponse(["documento"], RAGResult.SUCCESS)))
    judge = SimpleNamespace(generate=AsyncMock(return_value='{"score": 0.8}'))
    generator = SimpleNamespace(generate=AsyncMock(return_value="resposta"))
    return config, retriever, judge, generator


@pytest.mark.asyncio
async def test_scope_exit_without_external_calls(dependencies):
    config, retriever, judge, generator = dependencies
    assert await AgentWorkflow(*dependencies).run("previsão do tempo") == config.responses.out_of_scope
    retriever.retrieve.assert_not_called()
    judge.generate.assert_not_called()
    generator.generate.assert_not_called()


@pytest.mark.asyncio
@pytest.mark.parametrize("response", [None, {}, RAGResponse(["x"], "success"),
                                      RAGResponse(["x"], RAGResult.INFRA_ERROR)])
async def test_bad_retrieval_never_reaches_models(dependencies, response):
    config, retriever, judge, generator = dependencies
    retriever.retrieve.return_value = response
    assert await AgentWorkflow(*dependencies).run("orçamento") == config.responses.unavailable
    judge.generate.assert_not_called()
    generator.generate.assert_not_called()


@pytest.mark.asyncio
async def test_invalid_model_response_is_controlled(dependencies):
    config, _, judge, generator = dependencies
    generator.generate.side_effect = InvalidModelResponse()
    assert await AgentWorkflow(*dependencies).run("orçamento") == config.responses.unavailable
    judge.generate.assert_awaited_once()


@pytest.mark.asyncio
async def test_generation_error_propagates(dependencies):
    generator = dependencies[-1]
    generator.generate.side_effect = RuntimeError("controlled")
    with pytest.raises(RuntimeError, match="controlled"):
        await AgentWorkflow(*dependencies).run("orçamento")


@pytest.mark.asyncio
async def test_cancellation_propagates_without_generation(dependencies):
    dependencies[2].generate.side_effect = asyncio.CancelledError()
    with pytest.raises(asyncio.CancelledError):
        await AgentWorkflow(*dependencies).run("orçamento")
    dependencies[-1].generate.assert_not_called()


@pytest.mark.asyncio
async def test_concurrent_http_requests_have_no_shared_context(dependencies, monkeypatch):
    appmod = importlib.import_module("iaa_agent_mf_edu_fin.app")
    config, retriever, judge, generator = dependencies
    questions = [f"orçamento item {i}" for i in range(12)]

    async def retrieve(question):
        await asyncio.sleep(0)
        return RAGResponse([f"documento: {question}"], RAGResult.SUCCESS)

    async def generate(messages):
        await asyncio.sleep(0)
        question = messages[-1].content
        document = messages[1].content.removeprefix("<DOCUMENTOS_JSON>\n").removesuffix("\n</DOCUMENTOS_JSON>")
        assert json.loads(document) == {"chunks": [f"documento: {question}"]}
        assert len(messages) == 3
        return question

    retriever.retrieve.side_effect = retrieve
    generator.generate.side_effect = generate
    workflow = AgentWorkflow(*dependencies)
    config.instructions = "alteração posterior"
    monkeypatch.setattr(appmod.app.state, "workflow", workflow, raising=False)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=appmod.app), base_url="http://test") as client:
        results = await asyncio.gather(*(
            client.post("/chat", json={"message": question, "session_id": "same-session"})
            for question in questions
        ))
    assert [result.json()["reply"] for result in results] == questions
    assert all(result.status_code == 200 for result in results)
    assert all(result.json()["session_id"] == "same-session" for result in results)
    assert judge.generate.await_count == generator.generate.await_count == len(questions)
    assert all(call.args[0][0].content != config.instructions for call in generator.generate.call_args_list)


@pytest.mark.asyncio
async def test_fast_exits_never_construct_gateway_clients(monkeypatch):
    from iaa_agent_mf_edu_fin.llm.gateway_outbound import GatewayOutboundProvider
    rag = importlib.import_module("iaa_agent_mf_edu_fin.rag.client")
    build = MagicMock(side_effect=AssertionError("Modelo proibido"))
    monkeypatch.setattr(GatewayOutboundProvider, "build", build)
    workflow = create_workflow()
    await workflow.run("previsão do tempo")
    for result in (RAGResult.NO_CONTEXT, RAGResult.INFRA_ERROR):
        monkeypatch.setattr(rag, "_call_gateway", AsyncMock(return_value=RAGResponse([], result)))
        await workflow.run("orçamento")
    build.assert_not_called()


@pytest.mark.asyncio
async def test_startup_failure_still_closes_all_pools(monkeypatch):
    appmod = importlib.import_module("iaa_agent_mf_edu_fin.app")
    closers = []
    for module, name in (("rag.client", "close_http_client"),
                         ("llm.gateway_outbound", "close_http_clients"),
                         ("utils.genera_safe_guardrails", "close_http_client")):
        close = AsyncMock()
        monkeypatch.setattr(importlib.import_module("iaa_agent_mf_edu_fin." + module), name, close)
        closers.append(close)
    monkeypatch.setattr(appmod, "create_workflow", MagicMock(side_effect=ValueError("controlled")))
    async with appmod.lifespan(appmod.app):
        assert appmod.app.state.workflow is None
    for close in closers:
        close.assert_awaited_once()
    assert appmod.app.state.workflow is None
