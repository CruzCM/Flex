"""Conversões da fronteira LLM, incluindo respostas incompatíveis."""

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from iaa_agent_mf_edu_fin.domain import InvalidModelResponse, ModelInvocationError, PromptMessage
from iaa_agent_mf_edu_fin.llm.adapter import LangChainAdapter


@pytest.mark.asyncio
@pytest.mark.parametrize("content,expected", [
    ("  texto  ", "  texto  "), ("", ""), ([], ""),
    ([{"type": "text", "text": " A "}, "B"], "A  B"),
    ([{"type": "text", "text": "A"}, {"type": "text", "text": "B"}], "A B"),
    ([{"type": "image", "url": "ignored"}], ""),
])
async def test_response_conversion_and_prompt_roles(content, expected):
    model = MagicMock(ainvoke=AsyncMock(return_value=AIMessage(content=content)))
    adapter = LangChainAdapter(lambda: model)
    assert await adapter.generate([PromptMessage("system", "instrução"), PromptMessage("user", "q")]) == expected
    sent = model.ainvoke.call_args.args[0]
    assert isinstance(sent[0], SystemMessage) and sent[0].content == "instrução"
    assert isinstance(sent[1], HumanMessage) and sent[1].content == "q"


@pytest.mark.asyncio
@pytest.mark.parametrize("response", [
    HumanMessage(content="texto"), None,
    AIMessage(content="", tool_calls=[{"name": "unsupported", "args": {}, "id": "1"}]),
])
async def test_incompatible_response(response):
    model = MagicMock(ainvoke=AsyncMock(return_value=response))
    with pytest.raises(InvalidModelResponse):
        await LangChainAdapter(lambda: model).generate([PromptMessage("user", "q")])


@pytest.mark.asyncio
async def test_concurrent_calls_share_client_without_accumulating_messages():
    async def invoke(messages):
        await asyncio.sleep(0)
        return AIMessage(content=messages[-1].content)

    model = MagicMock(ainvoke=AsyncMock(side_effect=invoke))
    build = MagicMock(return_value=model)
    adapter = LangChainAdapter(build)
    replies = await asyncio.gather(*(adapter.generate([PromptMessage("user", str(i))]) for i in range(12)))
    assert replies == [str(i) for i in range(12)]
    build.assert_called_once()
    assert all(len(call.args[0]) == 1 for call in model.ainvoke.call_args_list)


@pytest.mark.asyncio
async def test_sdk_error_does_not_cross_adapter_boundary():
    model = MagicMock(ainvoke=AsyncMock(side_effect=RuntimeError("SEGREDO_SENTINELA")))
    with pytest.raises(ModelInvocationError, match="Integração LLM indisponível") as error:
        await LangChainAdapter(lambda: model).generate([PromptMessage("user", "q")])
    assert error.value.__suppress_context__
    assert "SEGREDO_SENTINELA" not in str(error.value)


@pytest.mark.asyncio
async def test_real_sdk_and_gateway_transport_with_in_memory_http(monkeypatch):
    import json
    import httpx
    from iaa_agent_mf_edu_fin.config import load_agent_config
    from iaa_agent_mf_edu_fin.llm.factory import LLMFactory
    from iaa_agent_mf_edu_fin.llm.gateway_outbound import close_http_clients

    cfg = load_agent_config().llm
    cfg.gateway_outbound.base_url = "https://llm.invalid/v1"
    cfg.gateway_outbound.model = "controlled-model"
    monkeypatch.setenv("GATEWAY_OUTBOUND_GW_APP_KEY", "controlled-key")
    captured = []

    async def handle(transport, request):
        await request.aread()
        captured.append(request)
        return httpx.Response(200, request=request, json={
            "id": "controlled", "object": "chat.completion", "created": 1,
            "model": "controlled-model", "choices": [{
                "index": 0, "finish_reason": "stop",
                "message": {"role": "assistant", "content": "Resposta controlada."},
            }],
        })

    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", handle)
    try:
        adapter = LLMFactory.create("gateway_outbound", 0.7, 0.95, config=cfg)
        reply = await adapter.generate([PromptMessage("system", "instrução"), PromptMessage("user", "pergunta")])
        assert reply == "Resposta controlada."
        assert len(captured) == 1
        request = captured[0]
        assert request.url.path == "/v1/cambio-chat-completion"
        assert request.url.params["api-version"] == cfg.gateway_outbound.api_version
        assert request.headers["x-application-key"] == "controlled-key"
        assert "authorization" not in request.headers
        payload = json.loads(request.content)
        assert payload["messages"] == [{"role": "system", "content": "instrução"},
                                       {"role": "user", "content": "pergunta"}]
        assert payload["model"] == "controlled-model"
        assert payload["temperature"] == 0.7 and payload["top_p"] == 0.95
    finally:
        await close_http_clients()
