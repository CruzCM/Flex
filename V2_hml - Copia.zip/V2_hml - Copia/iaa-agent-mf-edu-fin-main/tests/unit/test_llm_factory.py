"""A composição entrega adapters preguiçosos e captura sua configuração."""
from unittest.mock import AsyncMock, MagicMock
import pytest
from langchain_core.messages import AIMessage
from iaa_agent_mf_edu_fin.config import load_agent_config
from iaa_agent_mf_edu_fin.domain import ModelInvocationError, PromptMessage
from iaa_agent_mf_edu_fin.llm.factory import LLMFactory
from iaa_agent_mf_edu_fin.llm.gateway_outbound import GatewayOutboundProvider


@pytest.mark.asyncio
async def test_lazy_construction_and_configuration_snapshot(monkeypatch):
    cfg = load_agent_config().llm
    original_model = cfg.gateway_outbound.model
    constructed = []

    def build(provider, temperature, top_p):
        constructed.append((provider._config.model, temperature, top_p))
        return MagicMock(ainvoke=AsyncMock(return_value=AIMessage(content="texto")))

    monkeypatch.setattr(GatewayOutboundProvider, "build", build)
    adapter = LLMFactory.create("gateway_outbound", 0.3, 0.8, config=cfg)
    cfg.gateway_outbound.model = "changed-after-composition"
    assert constructed == []
    for _ in range(2):
        assert await adapter.generate([PromptMessage("user", "q")]) == "texto"
    assert constructed == [(original_model, 0.3, 0.8)]


@pytest.mark.asyncio
async def test_unknown_provider_rejected_on_use():
    adapter = LLMFactory.create("unknown", 0.5, 1.0)
    with pytest.raises(ModelInvocationError):
        await adapter.generate([PromptMessage("user", "q")])


@pytest.mark.asyncio
async def test_registered_provider_is_wrapped(monkeypatch):
    provider = MagicMock()
    provider.return_value.build.return_value.ainvoke = AsyncMock(return_value=AIMessage(content="ok"))
    monkeypatch.setattr(LLMFactory, "_registry", {})
    LLMFactory.register("controlled", provider)
    adapter = LLMFactory.create("controlled", 0.1, 0.9)
    provider.assert_not_called()
    assert await adapter.generate([PromptMessage("user", "q")]) == "ok"
    provider.return_value.build.assert_called_once_with(0.1, 0.9)
