"""Testes unitários para iaa_agent_mf_edu_fin/utils/genera_safe_guardrails.py."""

from contextlib import contextmanager
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

import iaa_agent_mf_edu_fin.utils.genera_safe_guardrails as gsg_module
from iaa_agent_mf_edu_fin.utils.genera_safe_guardrails import check_external_guardrail


def _make_gsg_cfg(enabled=True, client_id="client-id-test"):
    cfg = MagicMock()
    cfg.guardrails.enabled = enabled
    cfg.guardrails.uor = "uor-test"
    cfg.guardrails.user_id = "user-test"
    cfg.guardrails.agent_id = "agente-curador-iagen"
    cfg.guardrails.url = "https://fake-gateway/agent"
    cfg.guardrails.timeout = 5.0
    return cfg, client_id


@contextmanager
def _patch_gsg(**overrides):
    """Patcha get_config e GUARDRAIL_EXTERNAL_CLIENT_ID, e reseta o cliente HTTP."""
    enabled = overrides.get("ENABLED", True)
    client_id = overrides.get("CLIENT_ID", "client-id-test")
    cfg, cid = _make_gsg_cfg(enabled=enabled, client_id=client_id)
    gsg_module._http_client = None  # força recriação do cliente
    with patch("iaa_agent_mf_edu_fin.utils.genera_safe_guardrails.get_config", return_value=cfg):
        env_patch = {"GUARDRAIL_EXTERNAL_CLIENT_ID": cid} if cid else {}
        with patch.dict("os.environ", env_patch, clear=False):
            if not cid:
                import os
                os.environ.pop("GUARDRAIL_EXTERNAL_CLIENT_ID", None)
            yield


def _mock_http_client(post_return=None, post_side_effect=None):
    """Cria um mock de AsyncClient e injeta no módulo."""
    mock_client = MagicMock(spec=httpx.AsyncClient)
    if post_side_effect:
        mock_client.post = AsyncMock(side_effect=post_side_effect)
    else:
        mock_client.post = AsyncMock(return_value=post_return)
    gsg_module._http_client = mock_client
    return mock_client


def _mock_http_response(body: dict, status_code: int = 200):
    """Cria um mock de resposta httpx."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = body
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    else:
        resp.raise_for_status.return_value = None
    return resp


# ---------------------------------------------------------------------------
# Verificações de curto-circuito (sem chamada HTTP)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_disabled_returns_none():
    with _patch_gsg(ENABLED=False):
        result = await check_external_guardrail("qualquer mensagem")
    assert result is None


@pytest.mark.asyncio
async def test_empty_client_id_returns_none():
    with _patch_gsg(CLIENT_ID=""):
        result = await check_external_guardrail("qualquer mensagem")
    assert result is None


# ---------------------------------------------------------------------------
# Resposta allow (None esperado)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_allowed_true_returns_none():
    resp = _mock_http_response({"allowed": True})
    with _patch_gsg():
        _mock_http_client(post_return=resp)
        result = await check_external_guardrail("mensagem segura")
    assert result is None


@pytest.mark.asyncio
async def test_allowed_missing_key_returns_none():
    """Resposta sem chave 'allowed' deve retornar None (permissivo por padrão)."""
    resp = _mock_http_response({"status": "ok"})
    with _patch_gsg():
        _mock_http_client(post_return=resp)
        result = await check_external_guardrail("mensagem")
    assert result is None


# ---------------------------------------------------------------------------
# Resposta de bloqueio (string de motivo esperada)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_allowed_false_returns_reason():
    resp = _mock_http_response({"allowed": False, "reason": "conteudo_inapropriado"})
    with _patch_gsg():
        _mock_http_client(post_return=resp)
        result = await check_external_guardrail("mensagem ruim")
    assert result == "conteudo_inapropriado"


@pytest.mark.asyncio
async def test_allowed_false_no_reason_returns_default():
    resp = _mock_http_response({"allowed": False})
    with _patch_gsg():
        _mock_http_client(post_return=resp)
        result = await check_external_guardrail("mensagem ruim")
    assert result == "external_guardrail_rejection"


@pytest.mark.asyncio
async def test_status_blocked_returns_reason():
    resp = _mock_http_response({"status": "blocked", "reason": "violacao_politica"})
    with _patch_gsg():
        _mock_http_client(post_return=resp)
        result = await check_external_guardrail("mensagem ruim")
    assert result == "violacao_politica"


@pytest.mark.asyncio
async def test_status_rejected_returns_default_reason():
    resp = _mock_http_response({"status": "rejected"})
    with _patch_gsg():
        _mock_http_client(post_return=resp)
        result = await check_external_guardrail("mensagem")
    assert result == "external_guardrail_rejection"


# ---------------------------------------------------------------------------
# Falhas em aberto (erros de rede → None)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_timeout_fails_open():
    with _patch_gsg():
        _mock_http_client(post_side_effect=httpx.TimeoutException("timeout"))
        result = await check_external_guardrail("mensagem")
    assert result is None


@pytest.mark.asyncio
async def test_http_status_error_fails_open():
    bad_resp = MagicMock(spec=httpx.Response)
    bad_resp.status_code = 503
    bad_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
        "server error", request=MagicMock(), response=bad_resp
    )
    with _patch_gsg():
        _mock_http_client(post_return=bad_resp)
        result = await check_external_guardrail("mensagem")
    assert result is None


@pytest.mark.asyncio
async def test_generic_exception_fails_open():
    with _patch_gsg():
        _mock_http_client(post_side_effect=ConnectionError("unreachable"))
        result = await check_external_guardrail("mensagem")
    assert result is None


# ---------------------------------------------------------------------------
# Passagem do histórico de mensagens
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_messages_list_forwarded_in_payload():
    """O parâmetro messages deve ser incluído no payload enviado ao gateway."""
    resp = _mock_http_response({"allowed": True})
    history = [{"role": "user", "content": "oi"}, {"role": "assistant", "content": "olá"}]
    captured_payload = {}

    async def _fake_post(url, json, headers, timeout):  # noqa: ARG001
        captured_payload.update(json)
        return resp

    with _patch_gsg():
        _mock_http_client()
        gsg_module._http_client.post = AsyncMock(side_effect=_fake_post)
        await check_external_guardrail("mensagem", messages=history)

    assert captured_payload["body"]["data"]["context"]["messages"] == history
