"""Isolamento local anterior à coleta.

Os testes comprovam esta cópia com doubles explícitos; não acessam rede,
credenciais, collectors ou exporters corporativos.
"""
import os
import socket
from contextvars import ContextVar

# Remover herança impede uso acidental de credenciais ou exportadores reais.
for key in list(os.environ):
    if key.startswith(("OTEL_", "LANGSMITH_", "LANGCHAIN_")) or key in {
        "APPLICATION_INSIGHTS_CONNECTION_STRING", "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "RAG_CLIENT_ID", "GUARDRAIL_EXTERNAL_CLIENT_ID", "GATEWAY_OUTBOUND_GW_APP_KEY",
        "REQUESTS_CA_BUNDLE", "TRUST_STORE_CA_PATH", "KEY_STORE_CERT_PATH", "KEY_STORE_KEY_PATH",
    }:
        os.environ.pop(key, None)
os.environ.update(OTEL_SDK_DISABLED="true", OTEL_TRACES_EXPORTER="none",
                  OTEL_METRICS_EXPORTER="none", OTEL_LOGS_EXPORTER="none",
                  LANGCHAIN_TRACING_V2="false", LANGSMITH_TRACING="false")


def _deny_network(*args, **kwargs):
    raise AssertionError("Rede real proibida na validação local; use double explícito")


# ASGITransport e MockTransport funcionam sem sockets; DNS também fica bloqueado.
# O socketpair local do event loop Windows é a única exceção permitida.
socket.getaddrinfo = _deny_network
socket.create_connection = _deny_network
_original_connect = socket.socket.connect
_original_socketpair = socket.socketpair
_creating_socketpair = ContextVar("creating_socketpair", default=False)


def _connect_only_socketpair(sock, address):
    # No Windows o event loop implementa socketpair por TCP exclusivamente local.
    if _creating_socketpair.get() and address[0] in ("127.0.0.1", "::1"):
        return _original_connect(sock, address)
    return _deny_network()


def _local_socketpair(*args, **kwargs):
    token = _creating_socketpair.set(True)
    try:
        return _original_socketpair(*args, **kwargs)
    finally:
        _creating_socketpair.reset(token)


socket.socketpair = _local_socketpair
socket.socket.connect = _connect_only_socketpair
socket.socket.connect_ex = _deny_network
