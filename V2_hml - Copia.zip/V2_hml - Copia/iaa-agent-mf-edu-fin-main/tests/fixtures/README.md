# Fixtures da Etapa 0

Estas fixtures são insumos controlados para validar contratos locais. Elas não
representam disponibilidade, autenticação ou payload capturado do GeneraBB.

- `generabb_retrieved_contexts.json`: fixture sintética construída com base no contrato
  documentado em `GUIA_RAG_GENERA_INDICE_DIRETO.md`. O JSON não contém
  comentários porque comentários tornariam o arquivo inválido. Não é captura real
  sanitizada: GATE-001 permanece aberto até evidência corporativa aplicável.
- `scope_policy_mvp_v1.yaml`: corpus mínimo e versionado da política de escopo.

O JSON de recuperação é sintético e baseado no guia documental disponível; o
GATE-001 continua aberto até existir payload real sanitizado com origem e contrato
identificados. As fixtures comprovam somente parsing e regras locais controladas.
