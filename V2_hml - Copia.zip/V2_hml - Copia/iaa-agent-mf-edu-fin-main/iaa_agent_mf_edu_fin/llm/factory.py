"""factory.py - Instancia o provedor LLM definido em agent_config.yaml.

Para adicionar um novo provedor:
  1. Crie iaa_agent_mf_edu_fin/llm/<nome>.py com classe herdando LLMProvider.
  2. Registre: LLMFactory.register("nome", MinhaClasse)
  3. Atualize agent_config.yaml: llm.provider: "nome"
"""

from __future__ import annotations

from typing import Dict, Type

from copy import deepcopy

from iaa_agent_mf_edu_fin.domain import LanguageModel
from iaa_agent_mf_edu_fin.llm.adapter import LangChainAdapter

from iaa_agent_mf_edu_fin.llm.base import LLMProvider
from iaa_agent_mf_edu_fin.llm.gateway_outbound import GatewayOutboundProvider


class LLMFactory:
    # O registry permite providers adicionais; o A0 instancia somente o provider
    # selecionado pela configuração capturada daquela instância.
    _registry: Dict[str, Type[LLMProvider]] = {
        "gateway_outbound": GatewayOutboundProvider,
    }

    @classmethod
    def register(cls, name: str, provider_cls: Type[LLMProvider]) -> None:
        cls._registry[name] = provider_cls

    @classmethod
    def create(cls, provider: str, temperature: float, top_p: float, *, config=None) -> LanguageModel:
        provider_cls = cls._registry.get(provider)
        captured = deepcopy(config)

        def build_model():
            if provider_cls is None:
                raise ValueError("Provedor LLM desconhecido")
            instance = (
                provider_cls(captured.gateway_outbound)
                if captured is not None and provider_cls is GatewayOutboundProvider else provider_cls()
            )
            return instance.build(temperature, top_p)

        return LangChainAdapter(build_model)
