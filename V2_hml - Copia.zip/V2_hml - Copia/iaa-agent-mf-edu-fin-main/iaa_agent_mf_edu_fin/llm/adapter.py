"""Fronteira exclusiva de conversão entre os contratos locais e o LangChain."""

from collections.abc import Callable, Sequence

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from iaa_agent_mf_edu_fin.domain import InvalidModelResponse, ModelInvocationError, PromptMessage


class LangChainAdapter:
    def __init__(self, build_model: Callable[[], BaseChatModel]):
        self._build_model = build_model
        self._model: BaseChatModel | None = None

    async def generate(self, messages: Sequence[PromptMessage]) -> str:
        converted = []
        for message in messages:
            if message.role == "system":
                converted.append(SystemMessage(content=message.content))
            elif message.role == "user":
                converted.append(HumanMessage(content=message.content))
            else:
                raise ValueError("Papel de mensagem inválido")
        try:
            # A construção síncrona não cede o event loop; apenas o cliente é reutilizado.
            if self._model is None:
                self._model = self._build_model()
            response = await self._model.ainvoke(converted)
        except Exception:
            raise ModelInvocationError("Integração LLM indisponível") from None
        if not isinstance(response, AIMessage) or response.tool_calls:
            raise InvalidModelResponse("Resposta do modelo incompatível")
        content = response.content
        # Strings preservam espaços; blocos seguem a representação textual HTTP.
        if isinstance(content, list):
            return " ".join(
                block.get("text", "") if isinstance(block, dict) else str(block)
                for block in content
            ).strip()
        return str(content)
