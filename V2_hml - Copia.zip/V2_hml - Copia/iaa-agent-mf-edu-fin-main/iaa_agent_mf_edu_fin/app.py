"""app.py - Aplicação FastAPI que expõe o agente de execução linear.

Rotas
-----
POST /chat          - Envia uma mensagem e recebe a resposta do agente.
GET  /metrics       - Métricas básicas de execução (uptime, contagem de requisições).
GET  /health/live   - Liveness probe: retorna 200 enquanto o processo está em execução.
GET  /health/ready  - Readiness probe: retorna 200 quando as dependências estão prontas.

Swagger UI disponível em /docs (built-in do FastAPI).
"""

from __future__ import annotations

import logging
import threading
import time
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from iaa_agent_mf_edu_fin.config import get_config, a0_config_errors
from iaa_agent_mf_edu_fin.bootstrap import create_workflow
from iaa_agent_mf_edu_fin.workflow import AgentWorkflow
from iaa_agent_mf_edu_fin.utils.guardrails_middleware import GuardrailsMiddleware

from iaa_agent_mf_edu_fin.utils.tracing import configure_azure_monitor

logger = logging.getLogger(__name__)

config = get_config()

# Bootstrap Azure Monitor exporter (safe no-op if connection string is unset)
# O exporter só é anexado quando explicitamente configurado; localmente fica inerte.
configure_azure_monitor()


@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    """Inicializa localmente e fecha pools mesmo após falha no ciclo de vida."""
    from iaa_agent_mf_edu_fin.rag.client import close_http_client
    from iaa_agent_mf_edu_fin.llm.gateway_outbound import close_http_clients
    from iaa_agent_mf_edu_fin.utils.genera_safe_guardrails import close_http_client as close_guardrail
    # Startup prepara somente dependências locais; probes não fazem chamadas a dependências.
    app_instance.state.workflow = None
    try:
        try:
            app_instance.state.workflow = create_workflow()
        except Exception:
            logger.warning("Workflow indisponível: configuration_or_initialization")
        yield
    finally:
        # Pools são fechados no shutdown para não deixar conexões abertas entre ciclos.
        await close_http_client()
        await close_guardrail()
        await close_http_clients()
        app_instance.state.workflow = None


app = FastAPI(
    title=config.agent_name,
    description=config.agent_description,
    version=config.metadata.version or "0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

_START_TIME = time.time()
_request_count: int = 0
_request_count_lock = threading.Lock()

app.add_middleware(GuardrailsMiddleware)


class ChatRequest(BaseModel):
    # O endpoint recebe somente a pergunta atual e um identificador ecoado.
    message: str
    session_id: Optional[str] = None

    model_config = {
        "json_schema_extra": {
            "examples": [{"message": "Quanto é 2 + 2?", "session_id": "sessao-exemplo"}]
        }
    }


class ChatResponse(BaseModel):
    # tool_calls_made permanece por compatibilidade e vale zero no A0.
    reply: str
    session_id: Optional[str] = None
    tool_calls_made: int = 0


class MetricsResponse(BaseModel):
    uptime_seconds: float
    total_requests: int
    agent_id: str
    agent_name: str


async def get_workflow(request: Request) -> AgentWorkflow:
    workflow = getattr(request.app.state, "workflow", None)
    if workflow is None:
        # Permite recuperação após configuração corrigida, sem criar clientes de rede.
        try:
            workflow = create_workflow()
        except Exception as exc:
            raise HTTPException(status_code=500, detail="Erro interno do servidor.") from exc
        request.app.state.workflow = workflow
    return workflow


@app.post(
    "/chat",
    response_model=ChatResponse,
    summary="Envia uma mensagem para o agente",
    tags=["Agente"],
)
async def chat(request: ChatRequest, workflow: AgentWorkflow = Depends(get_workflow)) -> ChatResponse:
    # O contador mede requisições recebidas, não qualidade ou disponibilidade externa.
    global _request_count
    with _request_count_lock:
        _request_count += 1

    logger.info("chat iniciado")
    t0 = time.perf_counter()
    try:
        reply = await workflow.run(request.message)
    except Exception as exc:
        logger.error("Erro na execução do agente: internal_error")
        raise HTTPException(status_code=500, detail="Erro interno do servidor.") from exc

    # Campo público preservado por compatibilidade.
    tool_calls_made = 0
    elapsed_ms = (time.perf_counter() - t0) * 1000
    logger.info(
        "chat concluído: tool_calls=%d elapsed_ms=%.0f",
        tool_calls_made,
        elapsed_ms,
    )

    return ChatResponse(
        reply=reply,
        session_id=request.session_id,
        tool_calls_made=tool_calls_made,
    )


@app.get(
    "/metrics",
    response_model=MetricsResponse,
    summary="Métricas de execução",
    tags=["Operações"],
)
async def metrics() -> MetricsResponse:
    # Estes quatro campos formam o contrato operacional JSON já existente.
    cfg = get_config()
    return MetricsResponse(
        uptime_seconds=round(time.time() - _START_TIME, 2),
        total_requests=_request_count,
        agent_id=cfg.agent_id,
        agent_name=cfg.agent_name,
    )


@app.get(
    "/health/live",
    summary="Liveness probe",
    tags=["Health"],
)
async def health_live() -> JSONResponse:
    """Liveness local; não representa conectividade ou prontidão de dependências."""
    return JSONResponse(content={"status": "alive"})


@app.get(
    "/health/ready",
    summary="Readiness probe",
    tags=["Health"],
)
async def health_ready() -> JSONResponse:
    """Readiness local: configuração operacional e workflow inicializado.

    A ausência de RAG, credenciais ou parâmetros locais retorna 503 sem sondagem remota.
    """
    try:
        errors = a0_config_errors(get_config())
        if errors:
            return JSONResponse(status_code=503, content={
                "status": "not ready", "detail": "Configuração A0 pendente", "missing": errors,
            })
    except Exception:  # noqa: BLE001
        return JSONResponse(
            status_code=503,
            content={"status": "not ready", "detail": "Configuração A0 inválida"},
        )
    if getattr(app.state, "workflow", None) is None:
        return JSONResponse(
            status_code=503,
            content={"status": "not ready", "detail": "Workflow ainda não inicializado."},
        )
    return JSONResponse(content={"status": "ready"})
