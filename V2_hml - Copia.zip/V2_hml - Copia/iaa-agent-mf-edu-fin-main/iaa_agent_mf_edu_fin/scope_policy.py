"""Política determinística de escopo da instância de educação financeira."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from enum import Enum
from typing import Protocol

from iaa_agent_mf_edu_fin.config import ScopeConfig


# Três estados evitam transformar dúvida de escopo em bloqueio indevido.
# UNDETERMINED segue para RAG conforme a arquitetura do A0.
class ScopeResult(Enum):
    IN_SCOPE = "in_scope"
    OUT_OF_SCOPE = "out_of_scope"
    UNDETERMINED = "undetermined"


# Interface comum para políticas determinísticas de outras instâncias do template.
# A taxonomia concreta permanece na configuração da instância.
class ScopePolicy(Protocol):
    version: str

    def evaluate(self, message: str) -> ScopeResult:
        """Classifica a mensagem sem usar modelo generativo."""
        ...


# Normalização e comparação exata mantêm o resultado reproduzível e auditável.
# Não há classificação generativa nesta fronteira.
_NON_ALPHANUMERIC = re.compile(r"[^a-z0-9]+")


def _normalize(value: str) -> str:
    decomposed = unicodedata.normalize("NFKD", value.casefold())
    without_accents = "".join(char for char in decomposed if not unicodedata.combining(char))
    return _NON_ALPHANUMERIC.sub(" ", without_accents).strip()


def _contains_term(message: str, term: str) -> bool:
    normalized_term = _normalize(term)
    if not normalized_term:
        return False
    return f" {normalized_term} " in f" {message} "


@dataclass(frozen=True)
class KeywordScopePolicy:
    """MVP auditável: termos positivos vencem para evitar falso bloqueio.

    Mensagens sem correspondência inequívoca retornam ``UNDETERMINED`` e,
    conforme a arquitetura V2, devem seguir para o RAG.
    """

    version: str
    in_scope_terms: tuple[str, ...]
    out_of_scope_terms: tuple[str, ...]

    @classmethod
    def from_config(cls, config: ScopeConfig) -> "KeywordScopePolicy":
        # A política é rejeitada antes do uso quando não possui versão, corpus ou termos válidos.
        if not config.enabled:
            raise ValueError("A política de escopo está desabilitada")
        if config.policy != "keyword":
            raise ValueError(f"Política de escopo não suportada: {config.policy}")
        if not config.version.strip():
            raise ValueError("A versão da política de escopo é obrigatória")
        if not config.in_scope_terms or not config.out_of_scope_terms:
            raise ValueError("A política de escopo exige termos internos e externos")
        # Termos vazios ou tipos inválidos não formam uma política operacional.
        if any(not isinstance(term, str) or not _normalize(term)
               for term in (*config.in_scope_terms, *config.out_of_scope_terms)):
            raise ValueError("Termos de escopo inválidos")
        return cls(
            version=config.version,
            in_scope_terms=tuple(config.in_scope_terms),
            out_of_scope_terms=tuple(config.out_of_scope_terms),
        )

    def evaluate(self, message: str) -> ScopeResult:
        # Precedência documentada: interno, externo e, por fim, indeterminado.
        normalized_message = _normalize(message)
        # Precedência: termo interno, termo externo e, sem evidência, UNDETERMINED.
        if any(_contains_term(normalized_message, term) for term in self.in_scope_terms):
            return ScopeResult.IN_SCOPE
        if any(_contains_term(normalized_message, term) for term in self.out_of_scope_terms):
            return ScopeResult.OUT_OF_SCOPE
        return ScopeResult.UNDETERMINED
