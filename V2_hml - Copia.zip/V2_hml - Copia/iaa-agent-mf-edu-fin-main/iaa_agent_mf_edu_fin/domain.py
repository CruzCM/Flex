"""Contratos da aplicação, independentes de transporte e de bibliotecas de IA."""

from dataclasses import dataclass
from enum import Enum
from typing import Literal, Protocol, Sequence


@dataclass(frozen=True)
class PromptMessage:
    role: Literal["system", "user"]
    content: str


class RAGResult(str, Enum):
    SUCCESS = "success"
    NO_CONTEXT = "no_context"
    INFRA_ERROR = "infra_error"


@dataclass
class RAGResponse:
    chunks: list[str]
    result: RAGResult
    error_detail: str = ""


class InvalidModelResponse(Exception):
    """O modelo não entregou uma resposta textual compatível com a aplicação."""


class ModelInvocationError(Exception):
    """Falha da integração sem expor tipos ou conteúdo do SDK ao chamador."""


class LanguageModel(Protocol):
    async def generate(self, messages: Sequence[PromptMessage]) -> str: ...


class ContextRetriever(Protocol):
    async def retrieve(self, question: str) -> RAGResponse: ...
