"""Composição das dependências do processo, sem consultas externas no startup."""

from copy import deepcopy

from iaa_agent_mf_edu_fin.config import AgentConfig, a0_config_errors, get_config
from iaa_agent_mf_edu_fin.llm import LLMFactory
from iaa_agent_mf_edu_fin.rag.client import RAGClient
from iaa_agent_mf_edu_fin.workflow import AgentWorkflow


def create_workflow(config: AgentConfig | None = None) -> AgentWorkflow:
    cfg = deepcopy(config if config is not None else get_config())
    errors = a0_config_errors(cfg, operational=False)
    if errors:
        raise ValueError("Configuração A0 inválida: " + ", ".join(errors))
    return AgentWorkflow(
        cfg, RAGClient(cfg.rag),
        LLMFactory.create(cfg.llm.provider, 0.0, 1.0, config=cfg.llm),
        LLMFactory.create(cfg.llm.provider, cfg.temperature, cfg.top_p, config=cfg.llm),
    )
