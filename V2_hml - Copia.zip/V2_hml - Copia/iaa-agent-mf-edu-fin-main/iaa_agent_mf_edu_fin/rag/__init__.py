"""Recuperação documental por HTTP, independente do modelo de linguagem."""

from iaa_agent_mf_edu_fin.rag.client import RAGClient

__all__ = ["RAGClient"]
