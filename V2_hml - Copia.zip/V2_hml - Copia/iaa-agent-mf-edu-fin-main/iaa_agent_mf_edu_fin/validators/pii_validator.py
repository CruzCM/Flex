"""pii_validator.py - Enhanced PII detection with CPF/CNPJ checksum validation.

Extends the original regex patterns (email, phone, SSN, card) with
Brazilian-specific identifiers and checksum verification to reduce
false positives.  Fully on-premises.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

from iaa_agent_mf_edu_fin.validators import BaseValidator, ValidationResult, ValidatorAction

# ---------------------------------------------------------------------------
# Padrões de PII usam regex e checksum quando aplicável.
# O valor identificado não é exportado como atributo de telemetria.
# ---------------------------------------------------------------------------


def _cpf_checksum_valid(digits: str) -> bool:
    """Validate CPF using the official modulus-11 algorithm."""
    if len(digits) != 11 or digits == digits[0] * 11:
        return False
    for i in (9, 10):
        total = sum(int(digits[j]) * ((i + 1) - j) for j in range(i))
        remainder = (total * 10) % 11
        if remainder == 10:
            remainder = 0
        if int(digits[i]) != remainder:
            return False
    return True


def _cnpj_checksum_valid(digits: str) -> bool:
    """Validate CNPJ using the official modulus-11 algorithm."""
    if len(digits) != 14:
        return False
    weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    total = sum(int(digits[i]) * weights1[i] for i in range(12))
    d1 = 0 if total % 11 < 2 else 11 - total % 11
    if int(digits[12]) != d1:
        return False
    total = sum(int(digits[i]) * weights2[i] for i in range(13))
    d2 = 0 if total % 11 < 2 else 11 - total % 11
    return int(digits[13]) == d2


# (regex, label, checksum_fn or None)
_PII_RULES: List[Tuple[re.Pattern, str, Any]] = [
    # Email
    (re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"), "email", None),
    # Phone (international and BR)
    (re.compile(r"\b(?:\+?1[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}\b"), "phone", None),
    (re.compile(r"\b(?:\+55[\s\-.]?)?\(?\d{2}\)?[\s\-.]?9?\d{4}[\s\-.]?\d{4}\b"), "phone_br", None),
    # SSN (US)
    (re.compile(r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"), "ssn", None),
    # Credit card
    (re.compile(r"\b(?:\d[ \-]?){13,19}\b"), "credit_card", None),
    # CPF (with checksum validation)
    (re.compile(r"\b(\d{3})[.\s-]?(\d{3})[.\s-]?(\d{3})[.\s-]?(\d{2})\b"), "cpf", _cpf_checksum_valid),
    # CNPJ (with checksum validation)
    (re.compile(r"\b(\d{2})[.\s-]?(\d{3})[.\s-]?(\d{3})[/.\s-]?(\d{4})[.\s-]?(\d{2})\b"), "cnpj", _cnpj_checksum_valid),
]


class PIIValidator(BaseValidator):
    # O validator registra risco após a geração; a redação efetiva é responsabilidade
    # do guardrail de saída do middleware.
    """Detects PII in text. Score: 1.0 = PII risk found, 0.0 = no PII.

    For CPF/CNPJ, a checksum verification step filters false positives.
    """

    name = "pii"
    default_action = ValidatorAction.BLOCK
    threshold = 0.01  # any PII risk above this fails

    def _validate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        if not text.strip():
            return ValidationResult(passed=True, validator_name=self.name, score=0.0)

        found: Dict[str, List[str]] = {}

        for pattern, label, checksum_fn in _PII_RULES:
            for m in pattern.finditer(text):
                matched_text = m.group(0)
                if checksum_fn is not None:
                    digits = re.sub(r"\D", "", matched_text)
                    if not checksum_fn(digits):
                        continue  # false positive - skip
                found.setdefault(label, []).append(matched_text)

        if not found:
            return ValidationResult(passed=True, validator_name=self.name, score=0.0)

        total = sum(len(v) for v in found.values())
        details_parts = [f"{label}({len(vals)})" for label, vals in found.items()]

        return ValidationResult(
            passed=False,
            validator_name=self.name,
            score=1.0,
            action=self.default_action,
            details=f"PII detected: {', '.join(details_parts)}",
            metadata={"pii_types": list(found.keys()), "pii_count": total},
        )


def redact_pii(text: str) -> str:
    """Replace detected PII tokens with placeholders.  Checksum-validated for CPF/CNPJ."""
    _REDACT_MAP = {
        "email": "[EMAIL]",
        "phone": "[PHONE]",
        "phone_br": "[PHONE]",
        "ssn": "[SSN]",
        "credit_card": "[CARD]",
        "cpf": "[CPF]",
        "cnpj": "[CNPJ]",
    }
    for pattern, label, checksum_fn in _PII_RULES:
        placeholder = _REDACT_MAP.get(label, "[PII]")

        def _replace(m: re.Match, checksum_fn=checksum_fn, placeholder=placeholder) -> str:
            if checksum_fn is not None:
                digits = re.sub(r"\D", "", m.group(0))
                if not checksum_fn(digits):
                    return m.group(0)  # keep - not real PII
            return placeholder

        text = pattern.sub(_replace, text)
    return text
