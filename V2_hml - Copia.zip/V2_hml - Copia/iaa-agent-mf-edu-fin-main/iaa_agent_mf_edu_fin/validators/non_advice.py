"""non_advice.py - Detects financial, legal, and medical advice in agent output.

The agent should NOT give direct advice on regulated topics.  This validator
flags phrases like "you should invest", "I recommend buying", etc.

Supports PT-BR and EN patterns.  Fully on-premises.
"""

from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Tuple

from iaa_agent_mf_edu_fin.validators import BaseValidator, ValidationResult, ValidatorAction
from iaa_agent_mf_edu_fin.validators.semantic_similarity import best_similarity

# ---------------------------------------------------------------------------
# Padrões de aconselhamento por domínio (pattern, weight, domain).
# A regra identifica risco de recomendação; não gera orientação alternativa.
# ---------------------------------------------------------------------------

_ADVICE_RULES: List[Tuple[re.Pattern, float, str]] = [
    (re.compile(p, re.IGNORECASE), w, d)
    for p, w, d in [
        # Financial - EN
        (r"\b(you\s+should|i\s+recommend|i\s+advise\s+you\s+to)\s+(invest|buy|sell|trade)\b", 0.8, "financial"),
        (r"\b(guaranteed\s+return|risk[- ]free\s+investment)\b", 0.9, "financial"),
        (r"\b(buy\s+(this\s+)?stock|sell\s+your\s+(shares?|position))\b", 0.7, "financial"),
        (r"\b(put\s+your\s+money\s+(in|into))\b", 0.6, "financial"),
        (r"\b(financial\s+advice|investment\s+advice)\b.*\b(is|would\s+be)\b", 0.5, "financial"),
        # Financial - PT-BR
        (r"\b(voc[eê]\s+deve(ria)?|eu\s+recomendo|eu\s+aconselho)\s+(investir|comprar|vender)\b", 0.8, "financial"),
        (r"\b(retorno\s+garantido|investimento\s+sem\s+risco)\b", 0.9, "financial"),
        (r"\b(compre\s+(essa\s+)?a[cç][aã]o|venda\s+suas?\s+posi[cç][oõ]es?)\b", 0.7, "financial"),
        (r"\b(coloque\s+seu\s+dinheiro\s+em)\b", 0.6, "financial"),
        # Legal - EN
        (r"\b(you\s+should\s+sue|file\s+a\s+lawsuit|legal\s+advice)\b", 0.7, "legal"),
        (r"\b(my\s+legal\s+opinion\s+is|legally\s+you\s+(should|must))\b", 0.8, "legal"),
        (r"\b(plead\s+(guilty|not\s+guilty)|sign\s+this\s+contract)\b", 0.7, "legal"),
        # Legal - PT-BR
        (r"\b(voc[eê]\s+deve(ria)?\s+(processar|entrar\s+com\s+(uma\s+)?a[cç][aã]o))\b", 0.7, "legal"),
        (r"\b(minha\s+opini[aã]o\s+jur[ií]dica|legalmente\s+voc[eê]\s+deve)\b", 0.8, "legal"),
        # Medical - EN
        (r"\b(you\s+should\s+take|i\s+recommend\s+taking|take\s+this\s+medication)\b", 0.8, "medical"),
        (r"\b(stop\s+taking\s+your\s+(medication|medicine|pills?))\b", 0.9, "medical"),
        (r"\b(your\s+diagnosis\s+is|you\s+(have|suffer\s+from))\b", 0.5, "medical"),
        (r"\b(increase|decrease)\s+your\s+(dosage|dose)\b", 0.8, "medical"),
        # Medical - PT-BR
        (r"\b(voc[eê]\s+deve(ria)?\s+tomar|eu\s+recomendo\s+tomar|tome\s+esse\s+rem[eé]dio)\b", 0.8, "medical"),
        (r"\b(pare\s+de\s+tomar\s+seu\s+(rem[eé]dio|medicamento))\b", 0.9, "medical"),
        (r"\b(seu\s+diagn[oó]stico\s+[eé]|voc[eê]\s+(tem|sofre\s+de))\b", 0.5, "medical"),
    ]
]

# Allowlist: educational context that should not be flagged
_ALLOWLIST_PATTERNS: List[re.Pattern] = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"\b(in\s+general|generally\s+speaking|it\s+is\s+common\s+to)\b",
        r"\b(consult\s+(a|your)\s+(doctor|lawyer|financial\s+advisor))\b",
        r"\b(consulte\s+(um|seu|sua)\s+(m[eé]dico|advogado|consultor\s+financeiro))\b",
        r"\b(this\s+is\s+not\s+(financial|legal|medical)\s+advice)\b",
        r"\b(isso\s+n[aã]o\s+[eé]\s+(conselho|recomenda[cç][aã]o)\s+(financeiro|jur[ií]dico|m[eé]dico))\b",
    ]
]

_SEMANTIC_SEEDS: Dict[str, List[str]] = {
    "financial": [
        "if i were you i would buy that stock immediately",
        "put your savings into this investment now",
        "se eu fosse voce compraria essa acao agora",
        "coloque todo seu dinheiro nesse investimento",
    ],
    "legal": [
        "you should sue them right now",
        "my legal opinion is that you must sign this",
        "voce deve entrar com uma acao",
        "minha opiniao juridica e que voce deve assinar",
    ],
    "medical": [
        "you need to take this medication",
        "stop taking your pills immediately",
        "voce deve tomar esse remedio",
        "pare de tomar seu medicamento",
    ],
}

_SEMANTIC_DOMAIN_WEIGHT: Dict[str, float] = {
    "financial": 0.7,
    "legal": 0.75,
    "medical": 0.8,
}


class NonAdviceValidator(BaseValidator):
    # No A0, o workflow aplica a decisão BLOCK; a redação de PII permanece no middleware.
    """Detects regulated advice in agent output.

    Score: 1.0 = strong advice risk detected, 0.0 = no advice detected.
    """

    name = "non_advice"
    default_action = ValidatorAction.BLOCK
    threshold = 0.5

    def __init__(
        self,
        semantic_enabled: bool | None = None,
        semantic_threshold: float | None = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        env_enabled = os.getenv("GUARDRAIL_SEMANTIC_ENABLED", "true").lower() == "true"
        self.semantic_enabled = semantic_enabled if semantic_enabled is not None else env_enabled
        self.semantic_threshold = semantic_threshold if semantic_threshold is not None else 0.84

    def _accumulate_regex_matches(
        self,
        text: str,
        has_caveat: bool,
    ) -> tuple[float, Dict[str, List[str]]]:
        accumulated = 0.0
        matched_domains: Dict[str, List[str]] = {}

        for pattern, weight, domain in _ADVICE_RULES:
            m = pattern.search(text)
            if m:
                effective_weight = weight * 0.4 if has_caveat else weight
                accumulated += effective_weight
                matched_domains.setdefault(domain, []).append(m.group(0))

        return accumulated, matched_domains

    def _accumulate_semantic_matches(
        self,
        text: str,
        has_caveat: bool,
        matched_domains: Dict[str, List[str]],
    ) -> tuple[float, Dict[str, Dict[str, float | str]]]:
        if not self.semantic_enabled:
            return 0.0, {}

        added = 0.0
        semantic_matches: Dict[str, Dict[str, float | str]] = {}
        for domain, seeds in _SEMANTIC_SEEDS.items():
            if domain in matched_domains:
                continue
            match = best_similarity(text, seeds)
            if not match or match.score < self.semantic_threshold:
                continue

            max_weight = _SEMANTIC_DOMAIN_WEIGHT.get(domain, 0.6)
            scaled_weight = ((match.score - self.semantic_threshold) / (1 - self.semantic_threshold)) * max_weight
            effective_weight = max(0.0, min(max_weight, scaled_weight))
            if has_caveat:
                effective_weight *= 0.4

            added += effective_weight
            matched_domains.setdefault(domain, []).append(f"semantic:{match.phrase}")
            semantic_matches[domain] = {
                "phrase": match.phrase,
                "score": round(match.score, 3),
            }

        return added, semantic_matches

    def _validate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        if not text.strip():
            return ValidationResult(passed=True, validator_name=self.name, score=0.0)

        # Check allowlist - if educational caveats are present, reduce severity
        has_caveat = any(p.search(text) for p in _ALLOWLIST_PATTERNS)

        accumulated, matched_domains = self._accumulate_regex_matches(text, has_caveat)
        semantic_added, semantic_matches = self._accumulate_semantic_matches(
            text, has_caveat, matched_domains
        )
        accumulated += semantic_added

        score = min(accumulated, 1.0)
        passed = score <= self.threshold

        details = ""
        if matched_domains:
            parts = [f"{d}: {', '.join(ms)}" for d, ms in matched_domains.items()]
            details = "; ".join(parts)
            if has_caveat:
                details += " [caveat present - severity reduced]"

        return ValidationResult(
            passed=passed,
            validator_name=self.name,
            score=round(score, 3),
            action=self.default_action if not passed else ValidatorAction.LOG_ONLY,
            details=details,
            metadata={
                "domains": list(matched_domains.keys()),
                "has_caveat": has_caveat,
                "semantic_enabled": self.semantic_enabled,
                "semantic_matches": semantic_matches,
            },
        )
