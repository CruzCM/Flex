"""Mede a qualidade do contexto por LLM, sem bloquear a geração."""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List

from iaa_agent_mf_edu_fin.domain import LanguageModel, PromptMessage

from iaa_agent_mf_edu_fin.validators import BaseValidator, ValidationResult, ValidatorAction

logger = logging.getLogger(__name__)

# O judge retorna apenas score e justificativa curta; o score é observacional.
_SYSTEM_PROMPT = "You are a precise evaluator. Respond only with valid JSON."

_JUDGE_PROMPT = """Evaluate how relevant and useful the retrieved context is for answering the user's query.

Score from 0.0 to 1.0:
- 1.0 = Context is highly relevant, directly addresses the query, and is sufficient to formulate an answer.
- 0.7 = Context is mostly relevant with some useful information, but may have minor gaps.
- 0.4 = Context is partially relevant - some chunks relate to the topic but don't directly answer the query.
- 0.1 = Context is mostly irrelevant or misleading.
- 0.0 = Context has no relation to the query whatsoever.

Respond ONLY with valid JSON in this exact format:
{{"score": <float>, "reason": "<brief explanation>"}}

---
User Query: {query}

Retrieved Context Chunks:
{chunks}
"""


def _parse_judge_response(content: str) -> tuple[float, str]:
    # A análise aceita JSON direto ou cercado por markdown, mas nunca usa
    # campos alternativos para inferir um score ausente.
    content = content.strip()
    if content.startswith("```json"):
        content = content[7:]
    elif content.startswith("```"):
        content = content[3:]
    if content.endswith("```"):
        content = content[:-3]
    content = content.strip()
    try:
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            return 0.0, "not a dict"
        # Mantém compatibilidade com respostas legadas que serializaram as chaves.
        score_val = parsed.get("score")
        if score_val is None and '"score"' in parsed:
            score_val = parsed.get('"score"')
        score = max(0.0, min(1.0, float(score_val) if score_val is not None else 0.0))
        reason = str(parsed.get("reason", parsed.get('"reason"', "")))
        return score, reason
    except Exception:
        logger.warning("Context precision: invalid_judge_json")
        return 0.0, "parse_error"


async def _call_llm_judge_async(query: str, chunks: List[str], llm: LanguageModel) -> tuple[float, Dict[str, Any]]:
    """Transporte assíncrono com modelo da mesma instância do A0."""

    chunks_text = "\n---\n".join(
        f"[Chunk {i+1}]: {chunk[:500]}" for i, chunk in enumerate(chunks)
    )
    prompt = _JUDGE_PROMPT.format(query=query, chunks=chunks_text)

    content = await llm.generate([
        PromptMessage("system", _SYSTEM_PROMPT),
        PromptMessage("user", prompt),
    ])

    score, reason = _parse_judge_response(content)

    return score, {
        "reason": reason,
        "chunk_count": len(chunks),
        "method": "llm_as_judge_async",
    }


class ContextPrecisionValidator(BaseValidator):
    """Validates RAG retrieval quality using LLM-as-a-Judge.

    Pass ``context={"query": "...", "chunks": ["...", ...]}`` to ``avalidate()``.
    The ``text`` argument is ignored (use empty string).
    """

    # Esta é a métrica RAG atualmente usada no A0; não mede recall ou ranking.
    name = "context_precision"
    default_action = ValidatorAction.LOG_ONLY
    threshold = 0.3

    def __init__(self, judge: LanguageModel):
        super().__init__()
        self._judge = judge

    def validate(self, text: str, context=None):
        raise TypeError("A avaliação de contexto exige await avalidate")

    def _validate(self, text: str, context=None):
        raise TypeError("A avaliação de contexto exige await avalidate")

    async def _avalidate(self, text: str, context: Dict[str, Any] | None = None) -> ValidationResult:
        # O A0 usa este caminho assíncrono para compartilhar o transporte do provider.
        if context is None:
            return ValidationResult(
                passed=True, validator_name=self.name, score=1.0,
                details="no context provided - skipping",
            )

        query = context.get("query", "")
        chunks = context.get("chunks", [])

        if not query:
            return ValidationResult(
                passed=True, validator_name=self.name, score=1.0,
                details="no query in context - skipping",
            )

        if not chunks:
            return ValidationResult(
                passed=False, validator_name=self.name, score=0.0,
                action=self.default_action,
                details="no chunks retrieved",
                metadata={"reason": "empty_chunks"},
            )

        try:
            score, meta = await _call_llm_judge_async(query, chunks, self._judge)
        except Exception:
            logger.warning("LLM judge failed: judge_error")
            return ValidationResult(
                passed=True, validator_name=self.name, score=0.5,
                details="judge error (fail-open)",
                metadata={"error": "judge_error"},
            )

        passed = score >= self.threshold

        return ValidationResult(
            passed=passed,
            validator_name=self.name,
            score=score,
            action=self.default_action,
            details="llm_judge",
            metadata=meta,
        )
