# Arquitetura A0 V2 — fluxo detalhado e observabilidade

Atualizado em **01/10/2026**, a partir do código desta cópia e da decisão
`DEC-ISS419-001`. Mantém o padrão visual da V1: etapas funcionais em caixas,
cores por responsabilidade e observabilidade ao lado. A V1 permanece como
histórico; esta versão descreve o fluxo implementado, sem a proposta de
persistência de interações.

**Estado observado no YAML:** Scope Gate habilitado; RAG, Genera Safe e MCP
estão desabilitados. Com essa configuração, entradas aceitas pelo escopo chegam
ao adapter RAG e recebem indisponibilidade sem consulta externa. O percurso
RAG → judge → geração está implementado, mas exige configuração operacional
válida. Este diagrama não comprova que esse percurso esteja ativo corporativamente.

**Mudança de saída:** toxicidade e aconselhamento deixaram de ser apenas
observacionais no A0. Quando um deles reprova com ação `BLOCK`, o grafo substitui
a resposta por uma recusa segura. `context_precision` continua observacional,
e a redação de PII permanece no middleware.

## 1. Fluxo principal

Setas contínuas representam processamento. Ligações pontilhadas sem seta
associam uma etapa à sua instrumentação; não são chamadas de negócio.

- Roxo: contrato e resposta HTTP.
- Vermelho: guardrails e substituição de segurança.
- Azul: processamento interno do grafo.
- Laranja: integração externa ou resposta de erro.
- Verde-azulado pontilhado: observabilidade.

As caixas detalham operações internas; nem todas correspondem a nós registrados
no LangGraph. Em particular, validação e substituição pós-geração ocorrem dentro
de `llm_call`.

```mermaid
%%{init: {"theme":"base","flowchart":{"htmlLabels":true,"wrappingWidth":620,"nodeSpacing":35,"rankSpacing":45,"padding":22},"themeVariables":{"fontSize":"17px"}}}%%
flowchart TD
    classDef endpoint fill:#f3e5f5,stroke:#4a148c,stroke-width:2px,color:#000
    classDef guardrail fill:#ffebee,stroke:#b71c1c,stroke-width:2px,color:#000
    classDef langgraph fill:#e3f2fd,stroke:#0d47a1,stroke-width:2px,color:#000
    classDef external fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#000
    classDef obs fill:#e0f2f1,stroke:#00695c,stroke-width:2px,stroke-dasharray:5,color:#000
    classDef failure fill:#fff3e0,stroke:#bf360c,stroke-width:2px,color:#000

    API["<b>POST /chat — entrada HTTP</b>

message: texto obrigatório da pergunta atual
session_id: texto opcional ou null
Não recebe histórico conversacional
session_id é apenas ecoado na resposta"]:::endpoint


    Middleware["<b>Guardrails de entrada — middleware</b>

1. Tamanho: até 4.096 caracteres por padrão
2. Regex de prompt injection e jailbreak
3. Bloqueio de PII, habilitado por padrão:
e-mail, telefone BR/internacional, SSN, cartão, CPF e CNPJ
Regras específicas de CPF/CNPJ verificam dígitos
4. Genera Safe opcional, desligado no YAML
Quando habilitado com credencial, consulta política externa;
falhas e timeouts permitem continuar

Rejeição: HTTP 400 com error, code e detail"]:::guardrail
    InputFailure["<b>Entrada recusada ou contrato inválido</b>

HTTP 400: guardrail_violation e motivo
HTTP 422: erro de validação do contrato
Não entra no grafo"]:::failure
    Contract["<b>Contrato HTTP e preparação do estado</b>

FastAPI/Pydantic valida JSON e tipos de ChatRequest
Após validação, o handler incrementa total_requests
Cria uma HumanMessage com a pergunta atual
session_id não entra no AgentState

Invoca AgentGraph sem memória persistida"]:::endpoint
    MidObs["<b>Observabilidade do middleware</b>

Span: guardrails.middleware.chat
Métricas: guardrail.requests, guardrail.blocked,
guardrail.redactions, guardrail.latency_ms

Atributos conforme o caminho:
guardrail.blocked, guardrail.blocked_layer,
guardrail.blocked_code, guardrail.output_redacted,
guardrail.latency_ms

Bloqueio de PII de entrada não chama _record_block;
não incrementa guardrail.blocked atualmente"]:::obs

    Scope["<b>scope_gate_node — decisão de domínio</b>

KeywordScopePolicy configurada no YAML
Normaliza caixa, acentos e pontuação
Termo interno tem precedência sobre termo externo
Sem correspondência: UNDETERMINED
Não usa LLM para classificar
Zera rag_context e rag_result antes da recuperação"]:::langgraph
    ScopeObs["<b>Observabilidade de escopo</b>

Span: ScopePolicy.evaluate
Atributos: scope.result, scope.policy_version"]:::obs
    CondScope{"scope_result"}
    OOS["<b>OUT_OF_SCOPE — resposta configurada</b>

Usa cfg.responses.out_of_scope
Não consulta RAG nem chama judge ou gerador
Resposta funcional HTTP 200"]:::langgraph

    Retrieve["<b>retrieve_context_node — adapter RAG</b>

Valida habilitação, parâmetros e credencial
<b>YAML atual: rag.enabled = false</b>
Configuração inválida retorna INFRA_ERROR
sem consulta externa

Com configuração válida, chama o GeneraBB
Não usa Tool Calling ou MCP"]:::langgraph
    Genera["<b>GeneraBB — POST /gateway/core</b>

action: recuperar-contexto-indice
input: pergunta atual; query_type: hybrid
index_id configurado: idx-mf-edu-fin
total_context: 5; timeout: 20 segundos

Lê data.retrieved_contexts e passage_text
Aceita textos não vazios; estrutura inválida é erro
Contrato e disponibilidade externos não validados"]:::external
    RAGObs["<b>Observabilidade RAG</b>

Span: RAG.gateway_core
Atributos: rag.result, rag.chunk_count,
rag.duration_ms, rag.error quando houver erro

O span também cobre falha de configuração
A chamada externa pode não ter ocorrido"]:::obs
    CondRAG{"rag_result"}
    NoCtx["<b>NO_CONTEXT — ausência documental</b>

Estrutura válida, sem texto utilizável
Usa cfg.responses.no_context
Não chama judge nem gerador
Resposta funcional HTTP 200"]:::langgraph
    ErrCtx["<b>INFRA_ERROR — indisponibilidade</b>

Configuração, transporte, HTTP, timeout ou schema inválido
Usa cfg.responses.unavailable
Não chama judge nem gerador
Resposta funcional HTTP 200"]:::langgraph

    Precision["<b>context_precision_node — LLM judge</b>

Executa somente depois de rag_result = SUCCESS
Avalia pergunta e até 500 caracteres por chunk
Usa o provider configurado, temperature 0 e top_p 1
Score de 0 a 1; limiar atual 0,3

Observacional: score baixo ou falha do judge
não bloqueia geração nem reclassifica o RAG"]:::langgraph
    PrecisionObs["<b>Observabilidade do judge</b>

Span: validate.context_precision
Atributos: validator.name, validator.passed,
validator.score, validator.action, validator.duration_ms
Também emite as métricas comuns de validators"]:::obs
    LLM["<b>llm_call — geração</b>

Exige SUCCESS e chunks não vazios
Provider: gateway_outbound
Modelo configurado: cambio-non-prod-gpt4o
Envia instruções + DOCUMENTOS_JSON + pergunta
Prompt orienta fundamentação nos documentos

Exige AIMessage sem tool_calls
Retorno incompatível usa cfg.responses.unavailable
Nenhuma ferramenta solicitada é executada"]:::langgraph
    LLMObs["<b>Observabilidade da geração</b>

Span: LLM.generate
Atributos: llm.result, llm.duration_ms
Esses atributos não comprovam tokens ou custo"]:::obs
    PostVal["<b>Validators pós-LLM — quando há texto</b>

toxicity: ameaças, assédio, ódio e autolesão
non_advice: aconselhamento financeiro, jurídico e médico
pii: dados pessoais e identificadores

Executa os três nesta ordem antes de decidir
Toxicidade e aconselhamento podem bloquear
PII continua sendo redigida no middleware
Erro interno no cálculo mantém fail-open
Tool Correctness é usado somente no legado"]:::langgraph
    PostValObs["<b>Observabilidade dos validators</b>

Spans: validate.toxicity, validate.non_advice, validate.pii
Atributos: validator.name, validator.passed,
validator.score, validator.action

Métricas: validator.invocations, validator.passed,
validator.failed, validator.score, validator.latency_ms
Duração síncrona é métrica;
o span não recebe validator.duration_ms
A substituição no grafo não incrementa guardrail.blocked"]:::obs

    ResponseBody["<b>Montagem de ChatResponse</b>

reply: geração, resposta funcional ou recusa segura
session_id: valor recebido ou null
tool_calls_made: sempre 0"]:::endpoint
    OutGuard["<b>Guardrails de saída — HTTP 200 em JSON</b>

1. Blocklist: padrões de exposição de system prompt,
atuação irrestrita ou afirmação de ignorar diretrizes
Se corresponder, substitui reply por recusa fixa

2. Se não houver correspondência na blocklist:
mascara PII, quando habilitado, com marcadores
EMAIL, PHONE, SSN, CARD, CPF e CNPJ
Preserva os demais campos da resposta"]:::guardrail
    GraphError["<b>Erro de execução — HTTP 500</b>

Handler trata exceções da invocação do grafo
e prepara detalhe genérico de erro interno
Não passa pelo tratamento de saída de HTTP 200"]:::failure
    OutObs["<b>Observabilidade da saída</b>

Usa o mesmo span guardrails.middleware.chat
Blocklist: guardrail.blocked e atributos do bloqueio
Mascaramento: guardrail.redactions
e atributo guardrail.output_redacted
Não cria outro span de middleware"]:::obs

    Resp["<b>Resposta HTTP — envio ao cliente</b>

200: reply, session_id, tool_calls_made = 0
400, 422 ou 500: corpo de erro correspondente"]:::endpoint

    Middleware -->|Bloqueio| InputFailure
    Middleware -->|Sem bloqueio| Contract
    Middleware -.- MidObs
    Contract -->|Inválido| InputFailure
    Contract -->|Válido| Scope
    Contract -->|Exceção na invocação do grafo| GraphError
    Scope --> CondScope
    Scope -.- ScopeObs
    CondScope -->|OUT_OF_SCOPE| OOS
    CondScope -->|IN_SCOPE ou UNDETERMINED| Retrieve
    Retrieve -->|Configuração válida| Genera
    Retrieve -->|Configuração inválida| ValidateRAG
    Genera --> ValidateRAG
    ValidateRAG --> CondRAG
    Retrieve -.- RAGObs
    CondRAG -->|NO_CONTEXT| NoCtx
    CondRAG -->|INFRA_ERROR| ErrCtx
    CondRAG -->|SUCCESS| Precision
    Precision -.- PrecisionObs
    Precision --> LLM
    LLM -.- LLMObs
    LLM -->|AIMessage sem tool_calls| HasText
    LLM -->|Pré-condição ou retorno inválido| UnavailableOutput
    PostVal -.- PostValObs
    OOS --> ResponseBody
    NoCtx --> ResponseBody
    ErrCtx --> ResponseBody
    PostVal --> CondOutput
    ResponseBody --> OutGuard
    OutGuard -.- OutObs

    ValidateRAG["<b>Conferência do resultado no grafo</b>

Valida RAGResponse, RAGResult e consistência dos chunks
SUCCESS exige lista não vazia de textos utilizáveis
Resultado inconsistente vira INFRA_ERROR"]:::langgraph
    HasText{"Há texto utilizável<br/>na resposta?"}
    CondOutput{"Toxicidade OU aconselhamento:<br/>passed = false E action = BLOCK?"}
    SafeReply["<b>Bloqueio determinístico de saída — A0</b>

Substitui por nova AIMessage:
Desculpe, nao posso fornecer essa informacao.

HTTP permanece 200; não repete a geração
Decisão local, sem nova consulta ao LLM
Não usa o score do context_precision para bloquear"]:::guardrail
    UnavailableOutput["<b>Proteção da geração</b>

Sem SUCCESS/chunks, não chama o gerador
Retorno que não seja AIMessage ou contenha tool_calls
também usa cfg.responses.unavailable
Não executa ferramentas nem validators pós-LLM"]:::langgraph

    API --> Middleware
    HasText -->|Sim| PostVal
    HasText -->|Não| ResponseBody
    CondOutput -->|Sim| SafeReply
    CondOutput -->|Não| ResponseBody
    SafeReply --> ResponseBody
    UnavailableOutput --> ResponseBody
    OutGuard --> Resp
    InputFailure --> Resp
    GraphError --> Resp
```

### Como interpretar os caminhos

- `OUT_OF_SCOPE`, `NO_CONTEXT` e `INFRA_ERROR` encerram o processamento funcional
  antes do judge e da geração. As respostas ainda passam pelo middleware de saída.
- A decisão do RAG precede `context_precision`; resultado inconsistente é tratado
  como indisponibilidade antes de alcançar o judge.
- O judge avalia até 500 caracteres por chunk. A geração recebe os chunks
  completos. Score baixo ou falha do judge não bloqueiam a geração.
- Toxicidade, aconselhamento e PII executam nessa ordem quando há texto. A decisão
  de substituição ocorre depois dos três; não interrompe suas avaliações.
- O bloqueio exige simultaneamente reprovação e ação `BLOCK` de toxicidade ou
  aconselhamento. `LOG_ONLY` não bloqueia, e `BLOCK` com aprovação não bloqueia.
- A decisão de bloqueio é determinística para os mesmos resultados. Os detectores
  usam regras e similaridade textual locais; geração e judge usam LLM.
- A política de erro interno dos validators permanece fail-open. A presença dos
  filtros não comprova cobertura completa de conteúdo inadequado.
- O bloqueio pós-geração não economiza os tokens já consumidos nem repete chamadas
  a RAG, judge ou gerador. O overhead de latência não foi medido.
- A resposta segura segue com HTTP 200, `session_id` ecoado e
  `tool_calls_made=0`. A recusa não constitui um novo estado de `rag_result`.
- A substituição no grafo usa a telemetria dos validators. Não cria outro span de
  bloqueio nem incrementa o contador `guardrail.blocked` do middleware.
- HTTP 400/422 de entrada e HTTP 500 tratado pelo handler seguem como erros;
  não passam pelo tratamento de saída reservado a HTTP 200 em JSON.

## 2. Rotas operacionais e destino da telemetria

As rotas operacionais não percorrem o grafo de conversa. `/metrics` fornece
contadores locais em JSON; não consulta nem expõe os instrumentos OTel.
A exportação depende da configuração e dos providers do processo.

```mermaid
%%{init: {"theme":"base","flowchart":{"htmlLabels":true,"wrappingWidth":580,"padding":24,"rankSpacing":40},"themeVariables":{"fontSize":"17px"}}}%%
flowchart TD
    classDef endpoint fill:#f3e5f5,stroke:#4a148c,stroke-width:2px,color:#000
    classDef obs fill:#e0f2f1,stroke:#00695c,stroke-width:2px,color:#000
    API["<b>Rotas operacionais existentes</b>

Não percorrem o grafo de conversa
Não passam pelos guardrails específicos de POST /chat"]:::endpoint
    Metrics["<b>GET /metrics — JSON operacional</b>

uptime_seconds: tempo do processo
total_requests: entradas no handler de /chat
agent_id e agent_name: identidade configurada

Não inclui bloqueios anteriores ao handler
Contagem em memória, local ao processo
Não é formato Prometheus"]:::obs
    Live["<b>GET /health/live</b>

HTTP 200 com status alive
Indica que a aplicação respondeu
Não consulta dependências externas"]:::obs
    Ready["<b>GET /health/ready</b>

Verifica configuração operacional e grafo compilado
HTTP 200 ou 503 conforme requisitos locais
Com RAG desligado, configuração não está pronta
Não testa conectividade com RAG, LLM ou Collector"]:::obs
    OTel["<b>OpenTelemetry — exportação independente</b>

Instrumentos do fluxo usam providers do runtime
Docker prevê opentelemetry-instrument no início
OTLP para Collector conforme ambiente
Exporter Azure adicional de traces é opcional

Chegada ao backend: NÃO VALIDADO CORPORATIVAMENTE"]:::obs
    API --> Metrics
    API --> Live
    API --> Ready
    Runtime["<b>Processo instrumentado</b>

Emissão pelos providers configurados
Independente de consultas a GET /metrics"]:::endpoint
    Runtime -.- OTel
```

## 3. Fontes, alteração e evidência

As referências abaixo sustentam os caminhos e os nomes usados nos diagramas:

- [Contrato HTTP e rotas operacionais][app].
- [Fluxo A0 e decisão de bloqueio][graph].
- [Middleware de entrada e saída][middleware].
- [Padrões de injection, PII e blocklist][patterns].
- [Adapter RAG e classificação do resultado][rag].
- [Instrumentação e política de erro dos validators][validators].
- [Judge de contexto][judge].
- [Configuração da instância][config] e [exporter opcional][tracing].
- [Decisão arquitetural DEC-ISS419-001][architecture].
- [Adendo de requisitos e critérios de aceite][requirements].
- [Relatório da implementação e validação local][report].

[app]: iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/app.py
[graph]: iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/graph.py
[middleware]: iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/guardrails_middleware.py
[patterns]: iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/filter_patterns.py
[rag]: iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/rag/rag_tool.py
[validators]: iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/validators/__init__.py
[judge]: iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/validators/context_precision.py
[config]: iaa-agent-mf-edu-fin-main/agent_config.yaml
[tracing]: iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/utils/tracing.py
[architecture]: plano_arquitetura_a0_versao2.md
[requirements]: especificacao_requisitos_a0_versao2.md
[report]: RELATORIO_A0_V2.md

A V2 é necessária para representar a decisão de bloqueio já implementada e retirar
os caminhos propostos de persistência do desenho atual. Preserva o padrão visual,
o contrato HTTP e as distinções entre fluxo funcional, segurança e observabilidade.
A alternativa de apenas anotar a V1 manteria no mesmo desenho comportamentos
implementados e propostos; por isso foi criada uma versão separada.

A implementação correspondente foi verificada em 30/09/2026 com **233 testes
aprovados**, Flake8 sem apontamentos e compilação sintática concluída. Esses
resultados pertencem à alteração de código registrada no relatório; a edição
deste diagrama não representa uma nova execução da suíte.

Conferência documental em 01/10/2026: Markdownlint sem apontamentos; os dois
diagramas foram renderizados com `mmdc` e inspecionados visualmente. O timeout
inicial do Puppeteer foi contornado com configuração temporária de renderização.

**Limite: VALIDAÇÃO LOCAL; NÃO VALIDADO CORPORATIVAMENTE.** O diagrama não atesta
implantação, aprovação no Actions, contrato real do GeneraBB/Gateway Outbound ou
chegada da telemetria ao backend. Não acrescenta autenticação, correlação,
memória, MCP ou persistência ausentes do fluxo A0. Nenhum arquivo da aplicação ou
configuração de deploy foi alterado nesta atualização documental.
