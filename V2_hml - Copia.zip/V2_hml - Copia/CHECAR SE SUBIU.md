# Limites da verificação nesta cópia

Esta cópia permite verificar código, contratos HTTP em memória, configuração
local e testes controlados. Ela não permite confirmar publicação, deploy,
conectividade, autenticação ou recebimento de telemetria no ambiente corporativo.

## Sinais locais

- `/health/live` informa que o processo está ativo.
- `/health/ready` verifica configuração operacional e workflow inicializado.
- `/metrics` informa uptime, número de requisições e identidade do agente.
- Spans `ScopePolicy.evaluate`, `RAG.gateway_core`, `LLM.generate` e
  `validate.context_precision` descrevem etapas do processamento.

Nenhum desses contratos locais comprova implantação ou integração remota.
Não executar probes corporativas neste workspace.

A arquitetura mantida e os limites dos testes estão no
[README da aplicação](iaa-agent-mf-edu-fin-main/README.md).
