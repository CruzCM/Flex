# Alterações mínimas para o primeiro deploy em homologação

**Projeto:** `iaa-agent-mf-edu-fin`
**Escopo:** Mudanças nos repositórios do GitHub.

## 1. Repositório da Aplicação (`bbvinet/iaa-agent-mf-edu-fin`)

**Arquivo:** `aic.json`

Aplique as seguintes alterações:
- `"versaoPython"`: de `"3.8"` para `"3.11"`
- `"publicarPacoteEImagem"`:  `false` (ler GUIA_GERAL_GITHUB_GITLAB_ARGOCD.md)

*Nota: Mantenha a versão da aplicação no `__init__.py` como `0.1.0.dev0`. Nenhuma outra alteração de arquivo é necessária neste repositório para o primeiro deploy.*

## 2. Ordem de Execução e Verificação da Tag

1. Faça o commit e push das alterações no repositório da **aplicação**.
2. Acompanhe a execução da GitHub Actions e **anote a tag exata** da imagem publicada no log.

## 3. Repositório de Deploy (`bbvinet/deploy-iaa-agent-mf-edu-fin`)

**Branch:** `cloud/homologacao`
**Arquivo:** `values.yaml`

Aplique as seguintes alterações:

**3.1. Habilitar o Service:**
Altere `enable: false` para `true` em `service`.

**3.2. Referenciar a Secret Operacional:**
Em `deployment.containers.envFrom`, substitua a lista vazia pela referência à secret:
```yaml
      envFrom:
        - secretRef:
            name: env
```

**3.3. Configurar a Tag da Imagem:**
Em `deployment.containers.tag`, o valor padrão é `"0.1.0-SNAPSHOT"`. 
- **Ação obrigatória:** Verifique se a tag anotada no Passo 2 (GitHub Actions) é `"0.1.0-SNAPSHOT"`. Caso a esteira tenha gerado um valor diferente, atualize esta propriedade com a tag exata publicada.

**3.4. Configurar o Custodiante do Certificado:**
Em `custodianteCertificado.matriculaBB`, informe a matrícula (chave) da pessoa que pediu o provisionamento. Essa pessoa receberá os e-mails enviados pela PKI BB e pelo Portal OaaS.

4. Faça o commit e push dessas alterações na branch `cloud/homologacao` e acompanhe a esteira de deploy.
