# Arquitetura atual

A descrição mantida do projeto está no
[README da aplicação](iaa-agent-mf-edu-fin-main/README.md).
As decisões e seus limites estão no
[registro da refatoração](iaa-agent-mf-edu-fin-main/REFATORACAO.md).

O fluxo é linear e stateless: guardrails de entrada, escopo, RAG, judge
observacional, prompt seguro, geração, validação e guardrails de saída.
A API não recebe histórico, não mantém memória e não persiste respostas.

A documentação e os testes desta cópia não comprovam o ambiente corporativo.
