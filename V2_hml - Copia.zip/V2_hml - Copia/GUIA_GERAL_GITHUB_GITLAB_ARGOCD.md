# Guia geral: GitHub, GitLab, publicação de imagens e Argo CD

## 1. Objetivo

Este documento explica um modelo de CI/CD e GitOps no qual o código-fonte, a
construção da aplicação, a publicação da imagem e o deploy podem passar por
repositórios e ferramentas diferentes.

O fluxo apresentado é um exemplo de arquitetura. Ele não determina como uma
organização ou um projeto específico está configurado. Para conhecer o fluxo
real, é necessário conferir as configurações e os registros de execução do
projeto analisado.

## 2. Componentes e responsabilidades

| Componente | Responsabilidade possível |
| --- | --- |
| GitHub | Hospedar o código-fonte e executar workflows de CI/CD. |
| GitLab | Hospedar código-fonte, repositórios de release ou o estado GitOps de cada ambiente. |
| GitHub Actions | Testar, construir, empacotar e acionar processos de publicação ou autodeploy. |
| Jenkins | Executar uma rota de CI/CD histórica, alternativa ou paralela. |
| Registry | Armazenar imagens de container identificadas por nome, tag e digest. |
| Repositório GitOps | Guardar `values.yaml`, charts ou manifests que descrevem o estado desejado. |
| Argo CD | Comparar o estado desejado no Git com o cluster e executar a sincronização. |
| OpenShift ou Kubernetes | Executar os containers implantados. |

Um projeto pode usar apenas parte desses componentes. A presença simultânea de
um `Jenkinsfile` e de workflows do GitHub, por exemplo, não demonstra qual rota
está ativa nem se as duas são executadas.

## 3. Exemplo de fluxo híbrido

```mermaid
flowchart LR
    DEV[Desenvolvedor] --> SRC[Código-fonte no GitHub]
    SRC --> CI[GitHub Actions]
    CI --> REG[Registry de imagens]
    CI --> SYNC[Mecanismo de atualização]
    SYNC --> DEPLOY[Repositório GitOps no GitLab]
    DEPLOY --> ARGO[Argo CD]
    ARGO --> CLUSTER[OpenShift ou Kubernetes]
    REG --> CLUSTER
```

Nesse exemplo, o GitHub mantém o código desenvolvido e executa a esteira. A
imagem gerada é enviada ao registry. Separadamente, um processo atualiza no
repositório GitOps a tag que deverá ser implantada. O Argo CD acompanha esse
repositório e sincroniza o cluster.

O bloco **Mecanismo de atualização** foi mantido genérico porque pode representar:

- um push Git feito pelo próprio workflow;
- uma chamada de API;
- um espelhamento entre repositórios;
- uma automação corporativa intermediária;
- uma alteração aprovada por outro processo.

O fato de um workflow receber os parâmetros `versao` e `repositorio` não prova
qual desses mecanismos ele utiliza. Para comprovar o mecanismo, é preciso
consultar sua implementação, documentação aplicável ou registros de execução.

## 4. Código-fonte e repositório GitOps são coisas diferentes

O repositório de código contém a aplicação, seus testes, o `Dockerfile` e as
configurações de construção. O repositório GitOps descreve o que deve rodar em
um ambiente. É comum que eles tenham ciclos de acesso e responsabilidades
diferentes.

Um repositório GitOps pode conter, por exemplo:

```yaml
servico-exemplo:
  deployment:
    containers:
      tag: "1.4.2"
```

Esse valor declara a versão desejada. Ele não armazena a imagem. A imagem deve
existir no registry configurado para o cluster.

Por isso, existem duas alterações independentes para uma implantação:

1. publicar uma imagem no registry;
2. atualizar o estado GitOps para apontar para essa imagem.

Se apenas a imagem for publicada, o Argo CD pode continuar aplicando a tag
anterior. Se apenas a tag for atualizada e a imagem não existir ou não puder ser
acessada, o cluster poderá falhar ao baixá-la.

## 5. Por que o Argo CD pode apontar para o GitLab

O Argo CD não precisa acompanhar o repositório no qual os desenvolvedores
alteram o código. Ele acompanha a fonte configurada na aplicação, normalmente
em campos equivalentes aos seguintes:

```yaml
spec:
  source:
    repoURL: https://git.exemplo/area/release-servico-exemplo.git
    targetRevision: HEAD
    path: .
```

Assim, é possível usar GitHub para o código e para a CI/CD, enquanto o Argo CD
acompanha no GitLab um repositório separado de release. Para afirmar que esse é
o desenho de um projeto real, é necessário verificar o `repoURL` efetivamente
configurado no Argo CD ou obter evidência operacional equivalente.

Em um fluxo corporativo de provisionamento, essa separação pode ser criada
desde o início. Um mesmo processo pode:

1. definir no GitLab as URLs dos projetos de release de desenvolvimento,
   homologação e produção;
2. criar um repositório de release para cada ambiente;
3. provisionar um workload GitOps;
4. criar separadamente o repositório de código da aplicação.

Quando essas etapas aparecem concluídas na mesma execução de provisionamento,
elas documentam o que o provisionador declarou ter criado naquele momento. Essa
evidência não comprova, sozinha, que o Argo CD tenha passado a acompanhar esses
repositórios, nem mostra seu `repoURL` atual, o mecanismo que os atualiza ou qual
pipeline de CI está ativo. O apontamento do Argo CD deve ser confirmado na
configuração da Application ou por evidência operacional equivalente.

A migração do código-fonte para o GitHub também não comprova que os repositórios
de release foram migrados, nem que uma rota anterior de Jenkins foi desativada.

## 6. O parâmetro `publicarPacoteEImagem`

Uma configuração de esteira pode conter:

```json
{
  "pipeline": {
    "publicarPacoteEImagem": false
  }
}
```

Pelo nome, o campo expressa uma configuração relacionada à publicação de pacote
e imagem. O efeito efetivo depende da versão da esteira que lê o arquivo. A mera
presença do campo não comprova que um workflow específico o processe.

### 6.1 Por que o valor pode ser `false`

Como prática geral, manter a publicação desabilitada pode ser intencional para:

- permitir que um projeto recém-criado execute validações antes da primeira
  publicação;
- evitar que branches de trabalho publiquem artefatos definitivos;
- aguardar a definição da versão e a configuração de credenciais, permissões e
  registry;
- separar pipelines de validação das pipelines de release;
- deixar a publicação sob responsabilidade de outra rota oficial de CI/CD (ex: Jenkins ou GitLab CI) que atende aos ambientes, mantendo o GitHub Actions atuando apenas como validador de código (Pull Requests e testes);
- impedir a criação acidental de pacotes ou imagens durante a preparação do
  repositório.

Esses são motivos possíveis de desenho. Eles não revelam, por si sós, por que
um projeto específico recebeu o valor `false`.

### 6.2 O que `false` não comprova

Sem examinar a esteira aplicável, o valor `false` não comprova que:

- nenhuma imagem será construída;
- nenhuma imagem será publicada por outra rota;
- o deploy inevitavelmente falhará;
- Jenkins ou outro publicador está ativo;
- o campo seja considerado em todas as branches;
- o campo tenha o mesmo significado em todas as versões do workflow.

Uma imagem existente no registry também não demonstra que ela foi publicada
enquanto o campo estava em `false`. A imagem pode ter sido criada em outro
momento, por outra configuração ou por outra esteira.

### 6.3 Quando considerar o valor `true`

A alteração para `true` pode ser apropriada quando:

- a documentação aplicável e vigente exigir a publicação;
- a implementação ou o contrato do workflow confirmar que o campo é lido;
- a branch e a versão estiverem autorizadas a gerar o artefato;
- o registry e as credenciais estiverem configurados;
- a etapa atual do processo realmente exigir uma nova imagem.

Mesmo nesse caso, `true` não garante o sucesso. A publicação ainda pode falhar
por autenticação, versão inválida, testes, política de branch ou indisponibilidade
do registry.

## 7. Prescrição documental e necessidade técnica

Estas perguntas devem ser respondidas separadamente:

1. **O processo manda alterar a configuração?**
2. **A esteira realmente depende dela para publicar ou implantar?**

Um checklist vigente e aplicável pode comprovar uma exigência processual. Ele
não comprova sozinho o mecanismo técnico nem permite concluir que o sistema
sempre falhará sem a alteração.

Antes de aplicar um checklist, é necessário confirmar seu projeto, tecnologia,
versão, ambiente e data de validade. Um documento criado para outro serviço
pode servir como referência, mas não estabelece automaticamente uma obrigação.

## 8. Como identificar o fluxo real

Use evidências correlacionadas, preferencialmente para o mesmo commit, versão e
período.

### 8.1 No repositório de código

- identifique os eventos e branches que acionam a CI;
- examine os workflows locais e os componentes reutilizáveis chamados;
- verifique se existe `Jenkinsfile` ou outra definição de esteira;
- localize o arquivo que declara versão e opções de publicação;
- não deduza a implementação de um workflow apenas pelo nome.

### 8.2 Nos registros da esteira

- confirme qual pipeline executou;
- procure o carregamento do arquivo de configuração;
- verifique se o log informa a decisão de publicar ou não publicar;
- anote commit, versão, tag, digest, branch e horário;
- identifique o envio ao registry e a atualização do repositório GitOps.

### 8.3 No repositório GitOps

- localize o commit que alterou a tag;
- confira autor, data e origem da automação;
- verifique a branch ou revisão observada pelo Argo CD;
- compare a tag desejada com a imagem publicada.

### 8.4 No Argo CD

- consulte `repoURL`, `targetRevision` e `path`;
- confira a revisão Git aplicada;
- diferencie `Healthy` de `Synced`;
- verifique a imagem e o digest presentes no workload;
- trate capturas antigas como registros históricos, não como estado atual.

## 9. Estados do Argo CD

Dois estados respondem a perguntas diferentes:

| Estado | Pergunta respondida |
| --- | --- |
| `Healthy` | Os recursos executados parecem saudáveis? |
| `Synced` | O estado do cluster corresponde ao estado desejado no Git? |
| `OutOfSync` | Existe diferença detectada entre o Git e o cluster? |

Uma aplicação pode estar `Healthy` e `OutOfSync` ao mesmo tempo. Isso indica que
o workload pode estar funcionando, embora exista divergência em relação ao Git.
Não identifica sozinho quem provocou a diferença nem se uma sincronização é
segura.

## 10. Além do Argo CD: Gateways e Catálogos de API

Um status `Healthy` e `Synced` no Argo CD comprova apenas que os recursos do Kubernetes (como Deployments e Services) foram aplicados com sucesso e estão rodando no cluster. No entanto, a disponibilidade real da aplicação para consumo frequentemente depende de plataformas externas ao cluster:

- **Catálogos e Gateways de API:** O tráfego externo, o controle de acesso (OAuth, tokens, app keys) e a exposição das rotas (ex: `/chat`) costumam ser gerenciados por soluções de Gateway.
- **Ciclo de implantação paralelo:** A configuração da API e seu credenciamento representam operações de deploy próprias, distintas da publicação da imagem. Uma aplicação pode estar `Healthy` no Argo CD, mas inacessível se a implantação no Catálogo de IAs ou no Gateway falhar ou não estiver no ambiente correto.

Portanto, um ambiente apenas pode ser considerado completamente configurado para tráfego se houver evidência simultânea de sincronização do workload (Argo CD) e da publicação das rotas e credenciais aplicáveis no Gateway.

## 11. Cenários de arquitetura possíveis

### Cenário A — GitHub em todo o fluxo

O código e o repositório GitOps ficam no GitHub. GitHub Actions publica a imagem
e atualiza o repositório observado pelo Argo CD.

### Cenário B — GitLab em todo o fluxo

Código, CI/CD e GitOps permanecem no GitLab. O Argo CD acompanha um repositório
de release na mesma plataforma.

### Cenário C — GitHub para código e GitLab para GitOps

O desenvolvimento e a construção ocorrem no GitHub. Uma automação atualiza um
repositório de release no GitLab, que é acompanhado pelo Argo CD.

### Cenário D — Jenkins e GitHub coexistem

GitHub Actions pode validar o código enquanto Jenkins publica, ou cada rota pode
atender branches e tipos de release diferentes. A presença das configurações
não comprova a divisão; ela precisa ser verificada nos históricos de execução.

## 12. Erros de interpretação comuns

- concluir que migrar o código para o GitHub removeu o GitLab do deploy;
- concluir que a chegada de GitHub Actions desativou automaticamente o Jenkins;
- confundir o repositório do código com o repositório observado pelo Argo CD;
- assumir que um workflow altera arquivos porque recebe versão e repositório;
- relacionar uma imagem publicada a uma configuração capturada em outra data;
- tratar `Healthy` como prova de sincronização com o Git;
- transformar uma orientação de checklist em prova de impossibilidade técnica;
- afirmar que `publicarPacoteEImagem: false` sempre impede qualquer publicação;
- concluir que o ambiente está configurado apenas por evidências do Argo CD, ignorando gateways e catálogos.

## 13. Classificação das conclusões

Ao documentar uma investigação, classifique as afirmações relevantes:

| Classificação | Uso |
| --- | --- |
| Observado na configuração | Está explícito em um arquivo, mas pode não ter sido executado. |
| Observado no provisionamento | Uma operação registrada criou ou configurou determinado recurso naquele momento. |
| Observado na execução | Aparece em log ou resultado correlacionado à execução analisada. |
| Documentado | Está descrito em uma fonte aplicável, identificada e vigente. |
| Relatado | Foi informado por uma pessoa ou equipe, sem comprovação independente. |
| Inferido | É uma explicação compatível com os indícios, mas ainda não comprovada. |
| Desconhecido | A evidência disponível não permite responder. |

Ao combinar registros, confirme se eles pertencem ao mesmo projeto, ambiente,
branch, commit, versão e intervalo de tempo. A presença de duas evidências no
mesmo diretório não estabelece relação causal entre elas.

## 14. Checklist de validação

- [ ] Identifiquei o repositório do código-fonte.
- [ ] Identifiquei o repositório observado pelo Argo CD.
- [ ] Confirmei qual pipeline executou para o commit analisado.
- [ ] Verifiquei quem construiu e quem publicou a imagem.
- [ ] Registrei tag e digest da imagem.
- [ ] Localizei a alteração correspondente no repositório GitOps.
- [ ] Confirmei o mecanismo entre os repositórios ou o marquei como desconhecido.
- [ ] Verifiquei se `publicarPacoteEImagem` foi realmente lido.
- [ ] Separei exigência documental de dependência técnica.
- [ ] Diferenciei configuração atual de registros históricos.
- [ ] Declarei inferências e pontos desconhecidos sem apresentá-los como fatos.
- [ ] Verifiquei o registro e exposição em Gateways/Catálogos quando aplicável.
