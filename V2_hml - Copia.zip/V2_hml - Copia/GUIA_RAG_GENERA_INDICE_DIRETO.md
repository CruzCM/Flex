# Recuperação documental por índice

## Contrato observado no código

O cliente da aplicação está em
[rag/client.py](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/rag/client.py).
A consulta é controlada pelo workflow e recebe somente a pergunta atual.

O payload contém a ação `recuperar-contexto-indice` e `body.data` com `input`,
`index_id` e `context` (`query_type: hybrid` e `total_context`).
`index_id` tem precedência sobre `agent_id`. O header `X-Client-Id` recebe o valor
de `RAG_CLIENT_ID`; `UOR` e `userIdentification` vêm da configuração.

O parser aceita apenas `data.retrieved_contexts[*].passage_text`. Textos vazios são
descartados. Lista sem textos úteis resulta em ausência documental; estrutura
inválida, timeout, falha HTTP ou configuração incompleta resultam em falha técnica.

## Qualidade e segurança

Somente contexto válido permite avaliação e geração. O judge mede qualidade de
forma observacional; uma avaliação negativa não altera o resultado do RAG.
Documentos entram no prompt como dados delimitados, sem autoridade de sistema.

Spans do cliente registram resultado, quantidade de trechos, duração e categoria
de erro. Não registram conteúdo, headers nem credenciais.

## Evidência

Os testes de `test_rag_client.py` e `test_workflow_acceptance.py` exercitam payload,
parser e decisões com transportes em memória. Isso é **VALIDAÇÃO LOCAL**.
O contrato vigente e a integração real são **NÃO VALIDADOS CORPORATIVAMENTE**.
Não consultar endpoints corporativos a partir desta cópia.
