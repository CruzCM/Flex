# Arquitetura A0 V3 — Fluxo Refatorado (Linear e Stateless)

Atualizado a partir do código desta cópia e das decisões de refatoração consolidadas em `REFATORACAO.md`. Mantém o padrão visual da V2: etapas funcionais em caixas, cores por responsabilidade e observabilidade ao lado, mas reflete a **remoção total do LangGraph** e a adoção de um fluxo Python estrito e linear via `AgentWorkflow.run`.

**Estado observado:** O RAG continua desligado na configuração local. Todo o fluxo é processado requisição a requisição, sem persistência ou histórico de sessão.

## 1. Fluxo principal

Setas contínuas representam processamento. Ligações pontilhadas sem seta associam uma etapa à sua instrumentação.

- Roxo: contrato e resposta HTTP.
- Vermelho: guardrails e substituição de segurança.
- Azul: processamento linear do domínio (Workflow puro, sem LangGraph).
- Laranja: integração externa ou resposta de erro.
- Verde-azulado pontilhado: observabilidade.

```mermaid
%%{init: {"theme":"base","flowchart":{"htmlLabels":true,"wrappingWidth":620,"nodeSpacing":35,"rankSpacing":45,"padding":22},"themeVariables":{"fontSize":"17px"}}}%%
flowchart TD
    classDef endpoint fill:#f3e5f5,stroke:#4a148c,stroke-width:2px,color:#000
    classDef guardrail fill:#ffebee,stroke:#b71c1c,stroke-width:2px,color:#000
    classDef domain fill:#e3f2fd,stroke:#0d47a1,stroke-width:2px,color:#000
    classDef external fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#000
    classDef obs fill:#e0f2f1,stroke:#00695c,stroke-width:2px,stroke-dasharray:5,color:#000
    classDef failure fill:#fff3e0,stroke:#bf360c,stroke-width:2px,color:#000

    API["<b>POST /chat — entrada HTTP</b>

message: texto obrigatório da pergunta atual
session_id: texto opcional ou null
Não recebe histórico conversacional
session_id é apenas ecoado na resposta"]:::endpoint


    Middleware["<b>Guardrails de entrada — middleware</b>

1. Tamanho: até 4.096 caracteres
2. Regex de prompt injection e jailbreak
3. Bloqueio de PII de entrada (CPF, etc.)
4. Genera Safe (opcional)

Rejeição: HTTP 400 com error, code e detail"]:::guardrail
    InputFailure["<b>Entrada recusada ou contrato inválido</b>

HTTP 400: guardrail_violation e motivo
HTTP 422: erro de validação do contrato
Não chega ao AgentWorkflow"]:::failure
    Contract["<b>Contrato HTTP e Bootstrap</b>

FastAPI valida JSON e tipos
Chama AgentWorkflow.run(question)
sem repassar estado do SDK"]:::endpoint
    MidObs["<b>Observabilidade do middleware</b>

Span: guardrails.middleware.chat
Métricas: guardrail.requests, guardrail.blocked..."]:::obs

    Scope["<b>KeywordScopePolicy.evaluate</b>

Avalia o escopo financeiro permitido
Sem correspondência: OUT_OF_SCOPE
Não usa LLM para classificar"]:::domain
    ScopeObs["<b>Observabilidade de escopo</b>

Span: ScopePolicy.evaluate
Atributos: scope.result, scope.policy_version"]:::obs
    CondScope{"scope == OUT_OF_SCOPE?"}
    OOS["<b>Retorno: out_of_scope</b>

Usa cfg.responses.out_of_scope
Retorna antes do RAG e LLM"]:::domain

    Retrieve["<b>ContextRetriever.retrieve (RAGClient)</b>

Valida habilitação
<b>YAML atual: rag.enabled = false</b>
Configuração inválida retorna falha técnica sem consulta"]:::domain
    Genera["<b>GeneraBB — POST /gateway/core</b>

action: recuperar-contexto-indice
Retorna chunks documentais
Contrato externo não validado corporativamente"]:::external
    RAGObs["<b>Observabilidade RAG</b>

Span: RAG.gateway_core
Atributos: rag.result, rag.chunk_count"]:::obs
    CondRAG{"RAGResponse.result"}
    NoCtx["<b>NO_CONTEXT — ausência documental</b>

Sem texto utilizável
Usa cfg.responses.no_context"]:::domain
    ErrCtx["<b>INFRA_ERROR — indisponibilidade</b>

Erro técnico ou inconsistência
Usa cfg.responses.unavailable"]:::domain

    Precision["<b>ContextPrecisionValidator</b>

Executa somente se RAG = SUCCESS
Mede qualidade do contexto retornado
Score baixo ou falha não bloqueiam o fluxo principal"]:::domain
    PrecisionObs["<b>Observabilidade do judge</b>

Span: validate.context_precision
Atributos: validator.passed, validator.score..."]:::obs
    LLM["<b>LanguageModel.generate</b>

Isola DOCUMENTOS_JSON como payload de dados estritos
Adiciona a instrução do sistema e a pergunta
Provider: gateway_outbound
Exige resposta em texto"]:::domain
    LLMObs["<b>Observabilidade da geração</b>

Span: LLM.generate
Atributos: llm.result, llm.duration_ms"]:::obs
    PostVal["<b>Validadores Locais de Saída</b>

ToxicityValidator
NonAdviceValidator
PIIValidator

Executados sequencialmente sobre a resposta gerada"]:::domain
    PostValObs["<b>Observabilidade dos validators</b>

Spans individuais por validador
Atributos: validator.action, validator.passed"]:::obs

    ResponseBody["<b>Montagem de ChatResponse</b>

reply: resposta final
session_id: valor recebido
tool_calls_made: 0"]:::endpoint
    OutGuard["<b>Guardrails de saída — HTTP 200</b>

Aplica Blocklist e redige PII
Mascara dados sensíveis mantendo a estrutura"]:::guardrail
    WorkflowError["<b>Erro de execução — HTTP 500</b>

Exceções não tratadas no workflow
Retorna erro interno genérico"]:::failure
    OutObs["<b>Observabilidade da saída</b>

Span contínuo do middleware
Métricas de redação"]:::obs

    Resp["<b>Resposta HTTP — envio ao cliente</b>

200: resposta estruturada
400/422/500: corpos de erro"]:::endpoint

    Middleware -->|Bloqueio| InputFailure
    Middleware -->|Sem bloqueio| Contract
    Middleware -.- MidObs
    Contract -->|Inválido| InputFailure
    Contract -->|Válido| Scope
    Contract -->|Exceção no workflow| WorkflowError
    Scope --> CondScope
    Scope -.- ScopeObs
    CondScope -->|Sim| OOS
    CondScope -->|Não| Retrieve
    Retrieve -->|Configuração válida| Genera
    Retrieve -->|Configuração inválida ou Falha| ValidateRAG
    Genera --> ValidateRAG
    ValidateRAG --> CondRAG
    Retrieve -.- RAGObs
    CondRAG -->|NO_CONTEXT| NoCtx
    CondRAG -->|INFRA_ERROR| ErrCtx
    CondRAG -->|SUCCESS| Precision
    Precision -.- PrecisionObs
    Precision --> LLM
    LLM -.- LLMObs
    LLM -->|Erro no Modelo| ErrCtx
    LLM -->|Resposta Textual| PostVal
    PostVal -.- PostValObs
    OOS --> ResponseBody
    NoCtx --> ResponseBody
    ErrCtx --> ResponseBody
    PostVal --> CondOutput
    ResponseBody --> OutGuard
    OutGuard -.- OutObs

    ValidateRAG["<b>Conferência do resultado RAG</b>

Retorna SUCCESS, NO_CONTEXT ou INFRA_ERROR
Sem estado em grafo, apenas lógica de domínio"]:::domain
    CondOutput{"Toxicity ou NonAdvice<br/>action == BLOCK?"}
    SafeReply["<b>Bloqueio determinístico de saída</b>

Retorna: 'Desculpe, nao posso fornecer essa informacao.'
Decisão local e explícita no AgentWorkflow"]:::guardrail

    API --> Middleware
    CondOutput -->|Sim| SafeReply
    CondOutput -->|Não| ResponseBody
    SafeReply --> ResponseBody
    OutGuard --> Resp
    InputFailure --> Resp
    WorkflowError --> Resp
```

## 2. Rotas operacionais e destino da telemetria

As rotas operacionais e a exportação OTel permanecem inalteradas, mas sem a instrumentação residual do LangGraph.

```mermaid
%%{init: {"theme":"base","flowchart":{"htmlLabels":true,"wrappingWidth":580,"padding":24,"rankSpacing":40},"themeVariables":{"fontSize":"17px"}}}%%
flowchart TD
    classDef endpoint fill:#f3e5f5,stroke:#4a148c,stroke-width:2px,color:#000
    classDef obs fill:#e0f2f1,stroke:#00695c,stroke-width:2px,color:#000
    API["<b>Rotas operacionais existentes</b>

Não percorrem o fluxo funcional de chat"]:::endpoint
    Metrics["<b>GET /metrics — JSON operacional</b>

uptime_seconds e total_requests locais"]:::obs
    Live["<b>GET /health/live</b>"]:::obs
    Ready["<b>GET /health/ready</b>"]:::obs
    OTel["<b>OpenTelemetry — exportação independente</b>

Chegada ao backend: NÃO VALIDADO CORPORATIVAMENTE"]:::obs
    API --> Metrics
    API --> Live
    API --> Ready
    Runtime["<b>Processo instrumentado (Python Puro)</b>"]:::endpoint
    Runtime -.- OTel
```

## 3. Fontes, alteração e evidência

- [Contrato HTTP e rotas operacionais](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/app.py).
- [Fluxo Workflow Linear e decisão de bloqueio](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/workflow.py).
- [Contratos de Domínio Python](iaa-agent-mf-edu-fin-main/iaa_agent_mf_edu_fin/domain.py).

**Limite: VALIDAÇÃO LOCAL; NÃO VALIDADO CORPORATIVAMENTE.** 
