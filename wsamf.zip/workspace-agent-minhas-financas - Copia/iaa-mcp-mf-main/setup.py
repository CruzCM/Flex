# -*- encoding: utf-8 -*-
# Source: https://packaging.python.org/guides/distributing-packages-using-setuptools/

import io
import re

from setuptools import find_packages, setup

run_requirements = [
    "fastmcp==2.13.0",
    "uvicorn[standard]==0.38.0",
    "starlette>=0.27.0",
    "httpx==0.28.1",
    "python-dotenv>=1.0,<2.0",
    "python-multipart==0.0.18",
    "opentelemetry-api>=1.20.0",
    "opentelemetry-sdk>=1.20.0",
    "opentelemetry-exporter-otlp>=1.20.0",
    "opentelemetry-instrumentation-httpx>=0.41b0",
]

_test_base_requirements = run_requirements + [
    "pytest>=8.2",
    "pytest-asyncio>=1.3.0",
    "pytest-cov",
]

dev_requirements = _test_base_requirements + [
    "black",
    "flake8",
    "mypy",
]

unit_test_requirements = _test_base_requirements

integration_test_requirements = _test_base_requirements

with io.open(
    "./iaa_mcp_mf/__init__.py", encoding="utf8"
) as version_f:
    version_match = re.search(
        r"^__version__ = ['\"]([^'\"]*)['\"]", version_f.read(), re.M
    )
    if version_match:
        version = version_match.group(1)
    else:
        raise RuntimeError("Unable to find version string.")

with io.open("README.md", encoding="utf8") as readme:
    long_description = readme.read()

setup(
    name="mcp-server",
    version=version,
    author="BB",
    author_email="ditec@bb.com.br",
    packages=find_packages(where="."),
    package_dir={"": "."},
    include_package_data=True,
    url="https://canais.fontes.intranet.bb.com.br/iaa/iaa-mcp-mf/iaa-mcp-mf",
    license="COPYRIGHT",
    description="Model Context Protocol (MCP) Server for BB",
    long_description=long_description,
    long_description_content_type="text/markdown",
    zip_safe=False,
    install_requires=run_requirements,
    extras_require={
        "dev": dev_requirements,
        "unit": unit_test_requirements,
        "integration": integration_test_requirements,
    },
    python_requires=">=3.11",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Natural Language :: English",
        "Operating System :: POSIX :: Linux",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords=[],
    entry_points={
        "console_scripts": [
            "mcp-server=iaa_mcp_mf.__main__:main",
        ],
    },
)
