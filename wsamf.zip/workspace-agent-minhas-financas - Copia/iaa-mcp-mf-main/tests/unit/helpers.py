from __future__ import annotations


class FakeMCP:
    """Substituto de FastMCP - captura registros de tools, resources e prompts."""

    def __init__(self, name: str = "test"):
        self.name = name
        self.tools: dict = {}
        self.resources: dict = {}
        self.prompts: list = []

    def tool(self, **kwargs):
        def decorator(fn):
            self.tools[kwargs.get("name", fn.__name__)] = fn
            return fn
        return decorator

    def resource(self, uri, **kwargs):
        def decorator(fn):
            self.resources[uri] = fn
            return fn
        return decorator

    def prompt(self, fn_or_first=None, **kwargs):
        if callable(fn_or_first):
            self.prompts.append(fn_or_first)
            return fn_or_first

        def decorator(fn):
            self.prompts.append(fn)
            return fn
        return decorator
