from __future__ import annotations

import sys
import os
from pathlib import Path

import httpx
import pytest


def pytest_configure():
    repo_root = Path(__file__).resolve().parents[2]
    pkg_root = repo_root / "iaa_mcp_mf"
    if pkg_root.exists() and str(pkg_root.parent) not in sys.path:
        sys.path.insert(0, str(pkg_root.parent))


@pytest.fixture(autouse=True)
def isolated_unit_environment(monkeypatch, tmp_path):
    """Não ler .env privado nem permitir transporte HTTP real nos testes."""
    monkeypatch.setattr(os, "environ", os.environ.copy())
    for name in tuple(os.environ):
        if name.startswith(("RAG_FAQ_", "RAG_EDUCACAO_")) or name in (
            "REQUESTS_CA_BUNDLE", "MCP_SERVER_NAME", "PYTHON_DOTENV_DISABLED",
        ):
            monkeypatch.delenv(name, raising=False)
    monkeypatch.chdir(tmp_path)

    def blocked_http(*args, **kwargs):
        raise AssertionError("Transporte HTTP real proibido na suíte unitária; use MockTransport.")

    async def blocked_async_http(*args, **kwargs):
        blocked_http()

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", blocked_http)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", blocked_async_http)
