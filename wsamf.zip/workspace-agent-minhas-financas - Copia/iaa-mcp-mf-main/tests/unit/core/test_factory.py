from __future__ import annotations

import pytest

import iaa_mcp_mf.core.factory as factory_module
from iaa_mcp_mf.core.factory import MCPToolBase, MCPToolFactory
from tests.unit.helpers import FakeMCP


class DummyService(MCPToolBase):
    def __init__(self, tool_count: int = 1):
        super().__init__()
        self._tool_count = tool_count
        self.registered = False

    @property
    def tool_count(self) -> int:
        return self._tool_count

    def register_tools(self, mcp) -> None:
        self.registered = True


def test_factory_register_and_summary():
    factory = MCPToolFactory()
    service = DummyService(tool_count=2)
    factory.register_service(service)

    summary = factory.get_tool_summary()
    assert summary["total_services"] == 1
    assert summary["total_tools"] == 2
    assert summary["services"]["DummyService"]["tool_count"] == 2


def test_factory_create_mcp_server_registers_tools(monkeypatch):
    factory = MCPToolFactory()
    service = DummyService()
    factory.register_service(service)

    monkeypatch.setattr(factory_module, "FastMCP", FakeMCP)

    mcp = factory.create_mcp_server(name="Test")
    assert isinstance(mcp, FakeMCP)
    assert service.registered is True


def test_factory_register_duplicado_levanta_erro():
    factory = MCPToolFactory()
    factory.register_service(DummyService())
    with pytest.raises(ValueError, match="DummyService"):
        factory.register_service(DummyService())


def test_get_service():
    """Retorna a instância registrada e None para serviço ausente."""
    factory = MCPToolFactory()
    service = DummyService()
    factory.register_service(service)
    assert factory.get_service(DummyService) is service
    assert factory.get_service(type("Outro", (MCPToolBase,), {})) is None


def test_get_all_services():
    """Retorna todos os serviços e o dict é uma cópia independente."""
    factory = MCPToolFactory()
    service = DummyService()
    factory.register_service(service)
    services = factory.get_all_services()
    assert "DummyService" in services and services["DummyService"] is service
    services["intruso"] = DummyService()
    assert "intruso" not in factory.get_all_services()


def test_get_tool_summary_multiplos_servicos():
    class ServiceA(MCPToolBase):
        @property
        def tool_count(self):
            return 3

        def register_tools(self, mcp):
            """Serviço sem tools - apenas para teste de contagem."""

    class ServiceB(MCPToolBase):
        @property
        def tool_count(self):
            return 2

        def register_tools(self, mcp):
            """Serviço sem tools - apenas para teste de contagem."""

    factory = MCPToolFactory()
    factory.register_service(ServiceA())
    factory.register_service(ServiceB())
    summary = factory.get_tool_summary()
    assert summary["total_services"] == 2
    assert summary["total_tools"] == 5
    assert "ServiceA" in summary["services"]
    assert "ServiceB" in summary["services"]
