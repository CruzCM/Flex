from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from iaa_mcp_mf.core.tracing import trace_tool


class FakeSpan:
    """Substituto de span OpenTelemetry para testes."""

    def __init__(self):
        self.attrs: dict = {}
        self.recorded_exceptions: list = []
        self.status_calls: list = []

    def set_attribute(self, key, value):
        self.attrs[key] = value

    def set_status(self, code, description=""):
        self.status_calls.append((code, description))

    def record_exception(self, exc):
        self.recorded_exceptions.append(exc)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


@pytest.fixture()
def fake_tracer():
    span = FakeSpan()
    tracer = MagicMock()
    tracer.start_as_current_span.return_value = span
    with patch("iaa_mcp_mf.core.tracing.tracer", tracer):
        yield tracer, span


def test_trace_tool_sincrono_retorna_valor_correto():
    @trace_tool("soma")
    def soma(a: int, b: int) -> int:
        return a + b

    assert soma(a=2, b=3) == 5


def test_trace_tool_sincrono_registra_args_e_resultado(fake_tracer):
    tracer, span = fake_tracer

    @trace_tool("soma")
    def soma(a: int, b: int) -> int:
        return a + b

    soma(a=3, b=4)

    tracer.start_as_current_span.assert_called_once_with("soma")
    assert span.attrs["tool.arg.a"] == "3"
    assert span.attrs["tool.arg.b"] == "4"
    assert span.attrs["tool.result"] == "7"


def test_trace_tool_sincrono_propaga_excecao(fake_tracer):
    _, span = fake_tracer

    @trace_tool("tool_com_erro")
    def tool_com_erro(x: int) -> int:
        raise ValueError("erro intencional")

    with pytest.raises(ValueError, match="erro intencional"):
        tool_com_erro(x=1)

    assert len(span.recorded_exceptions) == 1
    assert isinstance(span.recorded_exceptions[0], ValueError)
    assert len(span.status_calls) == 1


async def test_trace_tool_assincrono_retorna_valor_correto():
    @trace_tool("saudar")
    async def saudar(nome: str) -> str:
        return f"Olá, {nome}!"

    assert await saudar(nome="Maria") == "Olá, Maria!"


async def test_trace_tool_assincrono_registra_args_e_resultado(fake_tracer):
    tracer, span = fake_tracer

    @trace_tool("saudar")
    async def saudar(nome: str) -> str:
        return f"Olá, {nome}!"

    await saudar(nome="João")

    tracer.start_as_current_span.assert_called_once_with("saudar")
    assert span.attrs["tool.arg.nome"] == "João"
    assert span.attrs["tool.result"] == "Olá, João!"


async def test_trace_tool_assincrono_propaga_excecao(fake_tracer):
    _, span = fake_tracer

    @trace_tool("tool_async_com_erro")
    async def tool_async_com_erro() -> str:
        raise RuntimeError("erro async")

    with pytest.raises(RuntimeError, match="erro async"):
        await tool_async_com_erro()

    assert len(span.recorded_exceptions) == 1
    assert isinstance(span.recorded_exceptions[0], RuntimeError)
    assert len(span.status_calls) == 1
