"""Contratos e isolamento dos RAGs, exclusivamente com dados sintéticos e mocks."""

import asyncio
import json
import logging
from pathlib import Path
import ssl
from types import SimpleNamespace

import certifi
from fastmcp import Client
import httpx
import pytest

from iaa_mcp_mf.services import service_rag as rag_module
from iaa_mcp_mf.services.service_rag import ServiceRAG
from iaa_mcp_mf.__main__ import create_app
from tests.unit.helpers import FakeMCP


RAGS = ("FAQ", "EDUCACAO")
TOOL_NAMES = ("consultar_faq_minhas_financas", "consultar_educacao_financeira")


@pytest.fixture
def configured_rags(monkeypatch):
    """Identidades deliberadamente diferentes; nenhum JWT ou ID corporativo."""
    settings = {}
    for number, rag in enumerate(RAGS, start=1):
        values = {
            "URL": f"https://{rag.lower()}.example.invalid/gateway/core",
            "INDEX_ID": f"indice-sintetico-{rag.lower()}",
            "CLIENT_ID": f"jwt-ficticio-{rag.lower()}",
            "UOR": f"uor-ficticia-{rag.lower()}",
            "USER_ID": f"usuario-ficticio-{rag.lower()}",
            "TIMEOUT": str(number + 2),
            "TOTAL_CONTEXT": str(number + 5),
            "QUERY_TYPE": "hybrid",
        }
        for key, value in values.items():
            monkeypatch.setenv(f"RAG_{rag}_{key}", value)
        settings[rag] = values
    return settings


@pytest.fixture
def mock_http(monkeypatch):
    """Executa HTTPX real com transporte em memória; mantém fechamento observável."""
    original_client = httpx.AsyncClient
    state = SimpleNamespace(requests=[], clients=[], options=[], handler=None)

    async def handle(request):
        state.requests.append(request)
        if state.handler is not None:
            result = state.handler(request)
            return await result if asyncio.iscoroutine(result) else result
        return httpx.Response(200, json={"data": {"retrieved_contexts": [{"passage_text": "Trecho sintético"}]}})

    def client_factory(**kwargs):
        state.options.append(kwargs.copy())
        client = original_client(transport=httpx.MockTransport(handle), trust_env=False, **kwargs)
        state.clients.append(client)
        return client

    monkeypatch.setattr(rag_module.httpx, "AsyncClient", client_factory)
    return state


def assert_failure(result, status):
    assert set(result) == {"status", "mensagem", "total_contextos", "contextos"}
    assert result["status"] == status
    assert result["mensagem"]
    assert result["contextos"] == []
    assert result["total_contextos"] == 0


def test_registration_and_count_are_idempotent():
    service = ServiceRAG()
    mcp = FakeMCP()
    assert service.tool_count == 0
    service.register_tools(mcp)
    service.register_tools(mcp)
    assert set(mcp.tools) == set(TOOL_NAMES)
    assert service.tool_count == 2


async def test_real_mcp_tools_return_structured_results(configured_rags, mock_http):
    async with Client(create_app()) as client:
        for rag, tool_name in zip(RAGS, TOOL_NAMES):
            result = await client.call_tool(tool_name, {"pergunta": "pergunta sintética", "top_k": 2})
            assert result.data == {
                "status": "sucesso", "mensagem": "Contextos recuperados.",
                "total_contextos": 1, "contextos": ["Trecho sintético"],
            }
            request = mock_http.requests[-1]
            assert request.headers["X-Client-Id"] == configured_rags[rag]["CLIENT_ID"]
            assert json.loads(request.content)["body"]["data"]["context"]["total_context"] == 2
    assert all(client.is_closed for client in mock_http.clients)


@pytest.mark.parametrize("rag,tool_name", zip(RAGS, TOOL_NAMES))
@pytest.mark.parametrize("top_k", [None, 3])
async def test_tool_sends_own_payload_headers_url_and_timeout(configured_rags, mock_http, rag, tool_name, top_k):
    mcp = FakeMCP()
    ServiceRAG().register_tools(mcp)
    result = await mcp.tools[tool_name]("  pergunta sintética  ", top_k)
    expected = configured_rags[rag]
    assert result == {
        "status": "sucesso", "mensagem": "Contextos recuperados.",
        "total_contextos": 1, "contextos": ["Trecho sintético"],
    }
    assert len(mock_http.requests) == 1
    request = mock_http.requests[0]
    assert request.method == "POST"
    assert str(request.url) == expected["URL"]
    assert dict(request.headers)["x-client-id"] == expected["CLIENT_ID"]
    assert request.headers["UOR"] == expected["UOR"]
    assert request.headers["userIdentification"] == expected["USER_ID"]
    assert request.headers["accept"] == "application/json"
    assert request.headers["content-type"] == "application/json"
    assert "authorization" not in request.headers
    assert json.loads(request.content) == {
        "action": "recuperar-contexto-indice",
        "body": {"data": {
            "input": "pergunta sintética", "index_id": expected["INDEX_ID"],
            "context": {"query_type": "hybrid", "total_context": int(expected["TOTAL_CONTEXT"]) if top_k is None else top_k},
        }},
    }
    assert mock_http.options[0] == {"verify": False, "timeout": float(expected["TIMEOUT"]), "follow_redirects": False}
    assert mock_http.clients[0].is_closed


@pytest.mark.parametrize("rag,index", [("FAQ", "ix-mf-faq"), ("EDUCACAO", "idx-minhas-financas")])
@pytest.mark.parametrize("blank", [None, "", "   "])
def test_non_sensitive_defaults(configured_rags, monkeypatch, rag, index, blank):
    for suffix in ("URL", "INDEX_ID", "TIMEOUT", "TOTAL_CONTEXT", "QUERY_TYPE"):
        name = f"RAG_{rag}_{suffix}"
        if blank is None:
            monkeypatch.delenv(name)
        else:
            monkeypatch.setenv(name, blank)
    cfg = rag_module._load_config(rag)
    assert cfg.url == "https://generabb-acs.gbb.servicos.bb.com.br/gateway/core"
    assert cfg.index_id == index
    assert cfg.timeout == 20.0
    assert cfg.total_context == 5
    assert cfg.query_type == "hybrid"


@pytest.mark.parametrize("suffix,value", [
    ("URL", "http://example.invalid/core"), ("URL", "not-a-url"),
    ("URL", "https://u:p@example.invalid/core"), ("URL", "https://example.invalid/core?q=x"),
    ("URL", "https://example.invalid/core#fragment"),
    ("TIMEOUT", "abc"), ("TIMEOUT", "0"), ("TIMEOUT", "-1"), ("TIMEOUT", "nan"), ("TIMEOUT", "inf"),
    ("TOTAL_CONTEXT", "abc"), ("TOTAL_CONTEXT", "1.5"), ("TOTAL_CONTEXT", "0"), ("TOTAL_CONTEXT", "-2"),
    ("QUERY_TYPE", "outro"), ("CLIENT_ID", "falso\ntoken"), ("UOR", "com espaço"), ("USER_ID", "usuário"),
])
async def test_invalid_config_never_falls_back_or_connects(configured_rags, mock_http, monkeypatch, suffix, value):
    monkeypatch.setenv(f"RAG_FAQ_{suffix}", value)
    result = await ServiceRAG()._consultar("FAQ", "pergunta", None)
    assert_failure(result, "configuracao_invalida")
    assert mock_http.requests == []
    assert mock_http.clients == []


@pytest.mark.parametrize("rag", RAGS)
@pytest.mark.parametrize("suffix,status", [("UOR", "nao_configurado"), ("USER_ID", "nao_configurado"), ("CLIENT_ID", "credencial_ausente")])
async def test_missing_identity_or_jwt_only_disables_selected_rag(configured_rags, mock_http, monkeypatch, rag, suffix, status):
    monkeypatch.delenv(f"RAG_{rag}_{suffix}")
    service = ServiceRAG()
    assert_failure(await service._consultar(rag, "pergunta", None), status)
    other = "EDUCACAO" if rag == "FAQ" else "FAQ"
    assert (await service._consultar(other, "pergunta", None))["status"] == "sucesso"
    assert len(mock_http.requests) == 1
    assert mock_http.requests[0].headers["X-Client-Id"] == configured_rags[other]["CLIENT_ID"]


async def test_invalid_config_does_not_affect_other_rag(configured_rags, mock_http, monkeypatch):
    monkeypatch.setenv("RAG_FAQ_TIMEOUT", "inválido")
    service = ServiceRAG()
    assert_failure(await service._consultar("FAQ", "pergunta", None), "configuracao_invalida")
    assert (await service._consultar("EDUCACAO", "pergunta", None))["status"] == "sucesso"


async def test_both_credentials_absent_without_http(configured_rags, mock_http, monkeypatch):
    for rag in RAGS:
        monkeypatch.delenv(f"RAG_{rag}_CLIENT_ID")
        assert_failure(await ServiceRAG()._consultar(rag, "pergunta", None), "credencial_ausente")
    assert mock_http.clients == []


async def test_missing_index_when_no_fallback(configured_rags, mock_http, monkeypatch):
    monkeypatch.setitem(rag_module._DEFAULTS["FAQ"], "INDEX_ID", "")
    monkeypatch.delenv("RAG_FAQ_INDEX_ID")
    assert_failure(await ServiceRAG()._consultar("FAQ", "pergunta", None), "nao_configurado")
    assert mock_http.requests == []


@pytest.mark.parametrize("pergunta,top_k", [("", None), ("   ", None), (None, None), ("p", 0), ("p", -1), ("p", True), ("p", 1.5), ("p", "2")])
async def test_invalid_inputs_do_not_connect(mock_http, pergunta, top_k):
    assert_failure(await ServiceRAG()._consultar("FAQ", pergunta, top_k), "entrada_invalida")
    assert mock_http.clients == []


@pytest.mark.parametrize("items,expected,status", [
    ([], [], "sem_resultados"),
    ([{"passage_text": " B "}, {"passage_text": "A", "score": 9}, {"passage_text": "B"}], ["B", "A", "B"], "sucesso"),
])
async def test_context_text_order_duplicates_and_no_extra_metadata(configured_rags, mock_http, items, expected, status):
    mock_http.handler = lambda request: httpx.Response(200, json={"data": {"retrieved_contexts": items}})
    result = await ServiceRAG()._consultar("FAQ", "pergunta", None)
    assert set(result) == {"status", "mensagem", "total_contextos", "contextos"}
    assert result["status"] == status
    assert result["contextos"] == expected
    assert result["total_contextos"] == len(expected)


@pytest.mark.parametrize("body", [
    None, [], {}, {"data": None}, {"data": []}, {"data": {}},
    {"data": {"retrieved_contexts": None}}, {"data": {"retrieved_contexts": "texto"}},
    {"data": {"retrieved_contexts": [None]}}, {"data": {"retrieved_contexts": [{}]}},
    {"data": {"retrieved_contexts": [{"passage_text": 123}]}},
    {"data": {"retrieved_contexts": [{"passage_text": " "}]}},
    {"data": {"retrieved_contexts": [{"passage_text": "válido"}, {}]}},
    {"data": {"output": {"text": [{"retrieved_contexts": []}]}}},
])
async def test_malformed_response_is_not_empty_success(configured_rags, mock_http, body):
    mock_http.handler = lambda request: httpx.Response(200, content=json.dumps(body).encode())
    assert_failure(await ServiceRAG()._consultar("FAQ", "pergunta", None), "resposta_inesperada")
    assert mock_http.clients[0].is_closed


async def test_invalid_json(configured_rags, mock_http):
    mock_http.handler = lambda request: httpx.Response(200, content=b"not JSON")
    assert_failure(await ServiceRAG()._consultar("FAQ", "pergunta", None), "resposta_inesperada")


@pytest.mark.parametrize("code,status", [(301, "erro_http"), (400, "erro_http"), (401, "credencial_invalida"), (403, "acesso_negado"), (404, "erro_http"), (429, "erro_http"), (500, "erro_http")])
async def test_http_errors_and_no_redirect_or_retry(configured_rags, mock_http, code, status):
    mock_http.handler = lambda request: httpx.Response(code, text="corpo sigiloso fictício", headers={"Location": "https://other.example.invalid"})
    result = await ServiceRAG()._consultar("FAQ", "pergunta", None)
    assert_failure(result, status)
    assert "corpo sigiloso" not in result["mensagem"]
    assert len(mock_http.requests) == 1
    assert mock_http.clients[0].is_closed


@pytest.mark.parametrize("exception,status", [
    (httpx.ConnectTimeout("segredo fictício"), "timeout"),
    (httpx.ReadTimeout("segredo fictício"), "timeout"),
    (httpx.WriteTimeout("segredo fictício"), "timeout"),
    (httpx.PoolTimeout("segredo fictício"), "timeout"),
    (httpx.ConnectError("segredo fictício"), "erro_conexao"),
    (httpx.ReadError("segredo fictício"), "erro_conexao"),
    (ssl.SSLError("segredo fictício"), "erro_tls"),
    (RuntimeError("segredo fictício"), "erro_interno"),
])
async def test_transport_and_internal_errors_are_sanitized(configured_rags, mock_http, exception, status, caplog):
    def fail(request):
        raise exception
    mock_http.handler = fail
    with caplog.at_level(logging.INFO, logger=rag_module.__name__):
        result = await ServiceRAG()._consultar("FAQ", "pergunta", None)
    assert_failure(result, status)
    assert "segredo fictício" not in json.dumps(result) + caplog.text
    assert len(mock_http.requests) == 1
    assert mock_http.clients[0].is_closed


@pytest.mark.parametrize("chain", ["cause", "context"])
async def test_tls_wrapped_by_httpx(configured_rags, mock_http, chain):
    def fail(request):
        try:
            raise ssl.SSLCertVerificationError("certificado sintético recusado")
        except ssl.SSLError as exc:
            if chain == "cause":
                raise httpx.ConnectError("transporte") from exc
            raise httpx.ConnectError("transporte")
    mock_http.handler = fail
    assert_failure(await ServiceRAG()._consultar("FAQ", "pergunta", None), "erro_tls")
    assert len(mock_http.clients) == 1
    assert mock_http.clients[0].is_closed


async def test_total_deadline_closes_client(configured_rags, mock_http, monkeypatch):
    monkeypatch.setenv("RAG_FAQ_TIMEOUT", "0.02")
    cancelled = []
    async def slow(request):
        try:
            await asyncio.Event().wait()
        finally:
            cancelled.append(True)
    mock_http.handler = slow
    result = await asyncio.wait_for(ServiceRAG()._consultar("FAQ", "pergunta", None), timeout=2)
    assert_failure(result, "timeout")
    assert cancelled == [True]
    assert mock_http.clients[0].is_closed


@pytest.mark.parametrize("value", [None, "", "   "])
async def test_absent_ca_disables_tls_with_warning(configured_rags, mock_http, monkeypatch, caplog, value):
    if value is not None:
        monkeypatch.setenv("REQUESTS_CA_BUNDLE", value)
    with caplog.at_level(logging.WARNING, logger=rag_module.__name__):
        assert (await ServiceRAG()._consultar("FAQ", "pergunta", None))["status"] == "sucesso"
    assert mock_http.options[0]["verify"] is False
    assert "tls_desabilitado" in caplog.text


async def test_valid_ca_builds_verified_context(configured_rags, mock_http, monkeypatch, caplog):
    monkeypatch.setenv("REQUESTS_CA_BUNDLE", certifi.where())
    assert (await ServiceRAG()._consultar("FAQ", "pergunta", None))["status"] == "sucesso"
    context = mock_http.options[0]["verify"]
    assert isinstance(context, ssl.SSLContext)
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname is True
    assert "tls_desabilitado" not in caplog.text


@pytest.mark.parametrize("kind", ["missing", "directory", "invalid", "unreadable"])
async def test_invalid_ca_blocks_http_without_insecure_fallback(configured_rags, mock_http, monkeypatch, tmp_path, kind):
    path = tmp_path / "ca.pem"
    if kind == "directory":
        path.mkdir()
    elif kind == "invalid":
        path.write_text("não é um certificado", encoding="utf-8")
    elif kind == "unreadable":
        def denied(**kwargs):
            raise PermissionError("caminho privado sintético")
        monkeypatch.setattr(rag_module.ssl, "create_default_context", denied)
    monkeypatch.setenv("REQUESTS_CA_BUNDLE", str(path))
    result = await ServiceRAG()._consultar("FAQ", "pergunta", None)
    assert_failure(result, "configuracao_invalida")
    assert str(path) not in result["mensagem"]
    assert mock_http.clients == []


async def test_concurrent_calls_keep_bases_and_credentials_separate(configured_rags, mock_http):
    ready = asyncio.Event()
    arrivals = []
    async def handle(request):
        arrivals.append(request)
        if len(arrivals) == 2:
            ready.set()
        await ready.wait()
        rag = "FAQ" if request.url.host.startswith("faq") else "EDUCACAO"
        values = configured_rags[rag]
        assert request.headers["X-Client-Id"] == values["CLIENT_ID"]
        assert request.headers["UOR"] == values["UOR"]
        assert request.headers["userIdentification"] == values["USER_ID"]
        assert json.loads(request.content)["body"]["data"]["index_id"] == values["INDEX_ID"]
        assert "cookie" not in request.headers
        return httpx.Response(200, json={"data": {"retrieved_contexts": [{"passage_text": rag}]}})
    mock_http.handler = handle
    service = ServiceRAG()
    results = await asyncio.wait_for(asyncio.gather(*(service._consultar(rag, "pergunta", None) for rag in RAGS)), timeout=2)
    assert [result["contextos"] for result in results] == [["FAQ"], ["EDUCACAO"]]
    assert len({id(client) for client in mock_http.clients}) == 2
    assert all(client.is_closed for client in mock_http.clients)


async def test_configuration_is_read_again_per_call(configured_rags, mock_http, monkeypatch):
    service = ServiceRAG()
    await service._consultar("FAQ", "pergunta", None)
    monkeypatch.setenv("RAG_FAQ_CLIENT_ID", "novo-token-ficticio")
    await service._consultar("FAQ", "pergunta", None)
    assert [request.headers["X-Client-Id"] for request in mock_http.requests] == [
        configured_rags["FAQ"]["CLIENT_ID"], "novo-token-ficticio",
    ]


async def test_logs_do_not_expose_query_context_or_identity(configured_rags, mock_http, caplog):
    question, passage = "PERGUNTA_PRIVADA_SINTETICA", "DOCUMENTO_PRIVADO_SINTETICO"
    mock_http.handler = lambda request: httpx.Response(200, json={"data": {"retrieved_contexts": [{"passage_text": passage}]}})
    with caplog.at_level(logging.INFO):
        result = await ServiceRAG()._consultar("FAQ", question, None)
    assert result["status"] == "sucesso"
    for sensitive in (question, passage, *(configured_rags["FAQ"][key] for key in ("CLIENT_ID", "UOR", "USER_ID"))):
        assert sensitive not in caplog.text
    assert "status=sucesso" in caplog.text
    assert "total_contextos=1" in caplog.text
    assert "duracao_ms=" in caplog.text
    assert "categoria=nenhuma" in caplog.text
    cfg = rag_module._load_config("FAQ")
    assert cfg.client_id not in repr(cfg)
    assert cfg.uor not in repr(cfg)
    assert cfg.user_id not in repr(cfg)


def test_private_dotenv_is_excluded_from_git_and_docker():
    root = Path(__file__).resolve().parents[3]
    gitignore = (root / ".gitignore").read_text(encoding="utf-8").splitlines()
    dockerignore = (root / ".dockerignore").read_text(encoding="utf-8").splitlines()
    assert ".env" in gitignore and ".env.*" in gitignore and "!.env.example" in gitignore
    assert ".env" in dockerignore and ".env.*" in dockerignore
    assert "!.env" not in dockerignore
