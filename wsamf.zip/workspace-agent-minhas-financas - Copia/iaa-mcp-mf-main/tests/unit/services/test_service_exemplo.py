from __future__ import annotations

from iaa_mcp_mf.services.service_exemplo import ServiceExemplo
from tests.unit.helpers import FakeMCP


def test_service_registro_e_contagem():
    """register_tools registra 3 tools, 1 resource, 1 prompt e tool_count == 3."""
    mcp = FakeMCP()
    service = ServiceExemplo()
    service.register_tools(mcp)

    assert "somar_numeros" in mcp.tools
    assert "ola_mundo" in mcp.tools
    assert "ping" in mcp.tools
    assert "exemplo://info" in mcp.resources
    assert len(mcp.prompts) == 1
    assert service.tool_count == 3


def test_service_tool_count_idempotente():
    mcp = FakeMCP()
    service = ServiceExemplo()
    service.register_tools(mcp)
    service.register_tools(mcp)

    assert service.tool_count == 3


def test_tools_retornam_valores_esperados():
    """somar_numeros, ola_mundo e ping retornam os valores corretos."""
    mcp = FakeMCP()
    ServiceExemplo().register_tools(mcp)

    assert mcp.tools["somar_numeros"](2, 3) == 5
    assert mcp.tools["somar_numeros"](-1, 1) == 0
    assert mcp.tools["ola_mundo"]("Maria") == "Olá, Maria!"
    assert mcp.tools["ping"]() == "pong"


def test_resource_info_contem_tools():
    mcp = FakeMCP()
    service = ServiceExemplo()
    service.register_tools(mcp)

    resultado = mcp.resources["exemplo://info"]()
    assert resultado["servico"] == "exemplo"
    assert "somar_numeros" in resultado["tools"]
    assert "ping" in resultado["tools"]


def test_prompt_saudar_contem_nome():
    mcp = FakeMCP()
    ServiceExemplo().register_tools(mcp)

    resultado = mcp.prompts[0](nome="João")
    assert "João" in resultado
