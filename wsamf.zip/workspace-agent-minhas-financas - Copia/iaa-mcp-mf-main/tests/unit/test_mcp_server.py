from __future__ import annotations

import sys
import runpy
import os
from unittest.mock import MagicMock

from fastmcp import Client, FastMCP
import pytest

from iaa_mcp_mf import __main__ as mcp_server_module
from iaa_mcp_mf.services import service_rag as rag_module


def test_create_app_returns_fastmcp_instance():
    app = mcp_server_module.create_app()
    assert isinstance(app, FastMCP)


def test_main_parametros(monkeypatch):
    """main() usa valores padrão e também repassa args customizados via CLI."""
    calls = {}

    class _FakeMCP:
        def run(self, **kwargs):
            calls["kwargs"] = kwargs

    monkeypatch.setattr(mcp_server_module, "create_app", lambda: _FakeMCP())

    monkeypatch.setattr("sys.argv", ["prog"])
    mcp_server_module.main()
    assert calls["kwargs"] == {"transport": "streamable-http", "host": "0.0.0.0", "port": 8080, "stateless_http": True}

    monkeypatch.setattr("sys.argv", ["prog", "--host", "127.0.0.1", "--port", "8080"])
    mcp_server_module.main()
    assert calls["kwargs"]["host"] == "127.0.0.1"
    assert calls["kwargs"]["port"] == 8080
    assert calls["kwargs"]["stateless_http"] is True


def test_health_handlers():
    """health_check e readiness_check retornam 200 OK."""
    request = MagicMock()

    resp = mcp_server_module.health_check(request)
    assert resp.status_code == 200
    assert resp.body == b"OK"

    resp = mcp_server_module.readiness_check(request)
    assert resp.status_code == 200
    assert resp.body == b"OK"


def test_dunder_main_guard(monkeypatch):
    """Bloco if __name__ == '__main__' invoca main()."""

    called = {}
    monkeypatch.setattr(FastMCP, "run", lambda self, **kw: called.update(kw))
    monkeypatch.setattr("sys.argv", ["prog"])

    key = "iaa_mcp_mf.__main__"
    cached = sys.modules.pop(key, None)
    try:
        runpy.run_module(key, run_name="__main__", alter_sys=False)
    finally:
        if cached is not None:
            sys.modules[key] = cached

    assert called.get("transport") == "streamable-http"


@pytest.mark.parametrize("invalid_configuration", [False, True])
async def test_real_mcp_catalog_and_examples_without_credentials(monkeypatch, invalid_configuration):
    if invalid_configuration:
        monkeypatch.setenv("RAG_FAQ_TIMEOUT", "inválido")
        monkeypatch.setenv("REQUESTS_CA_BUNDLE", "arquivo-inexistente.pem")
    app = mcp_server_module.create_app()
    async with Client(app) as client:
        tools = {tool.name: tool for tool in await client.list_tools()}
        assert set(tools) == {
            "ping", "somar_numeros", "ola_mundo",
            "consultar_faq_minhas_financas", "consultar_educacao_financeira",
        }
        for name in ("consultar_faq_minhas_financas", "consultar_educacao_financeira"):
            schema = tools[name].inputSchema
            assert set(schema["properties"]) == {"pergunta", "top_k"}
            assert schema["required"] == ["pergunta"]
            assert schema["properties"]["top_k"]["default"] is None
            result = await client.call_tool(name, {"pergunta": "pergunta sintética"})
            expected = "configuracao_invalida" if invalid_configuration and name == "consultar_faq_minhas_financas" else "nao_configurado"
            assert result.data["status"] == expected
            assert result.data["contextos"] == []
        assert (await client.call_tool("ping", {})).content[0].text == "pong"
        assert (await client.call_tool("somar_numeros", {"a": 2, "b": 3})).content[0].text == "5"
        assert (await client.call_tool("ola_mundo", {"nome": "Teste"})).content[0].text == "Olá, Teste!"
        assert {str(resource.uri) for resource in await client.list_resources()} == {"exemplo://info"}
        assert {prompt.name for prompt in await client.list_prompts()} == {"saudar"}
    assert mcp_server_module.health_check(MagicMock()).status_code == 200
    assert mcp_server_module.readiness_check(MagicMock()).status_code == 200


def test_startup_without_dotenv(tmp_path):
    assert not (tmp_path / ".env").exists()
    assert isinstance(mcp_server_module.create_app(), FastMCP)
    assert "RAG_FAQ_CLIENT_ID" not in os.environ
    assert "RAG_EDUCACAO_CLIENT_ID" not in os.environ


def test_dotenv_is_loaded_before_service_construction(monkeypatch, tmp_path):
    (tmp_path / ".env").write_text("RAG_FAQ_UOR=uor-sintetica-do-arquivo\n", encoding="utf-8")
    original = mcp_server_module.ServiceRAG
    observed = []

    class ObservedService(original):
        def __init__(self):
            observed.append(os.getenv("RAG_FAQ_UOR"))
            super().__init__()

    monkeypatch.setattr(mcp_server_module, "ServiceRAG", ObservedService)
    mcp_server_module.create_app()
    assert observed == ["uor-sintetica-do-arquivo"]


@pytest.mark.parametrize("rag,index", [("FAQ", "ix-mf-faq"), ("EDUCACAO", "idx-minhas-financas")])
def test_process_dotenv_and_python_fallback_precedence(monkeypatch, tmp_path, rag, index):
    prefix = f"RAG_{rag}_"
    (tmp_path / ".env").write_text(
        f"{prefix}CLIENT_ID=jwt-ficticio-arquivo\n"
        f"{prefix}UOR=uor-ficticia-arquivo\n"
        f"{prefix}USER_ID=usuario-ficticio-arquivo\n"
        f"{prefix}TIMEOUT=9\n"
        f"{prefix}TOTAL_CONTEXT=7\n"
        f"{prefix}INDEX_ID=\n",
        encoding="utf-8",
    )
    monkeypatch.setenv(prefix + "CLIENT_ID", "jwt-ficticio-processo")
    monkeypatch.setenv(prefix + "TIMEOUT", "4")
    mcp_server_module.create_app()
    cfg = rag_module._load_config(rag)
    assert cfg.client_id == "jwt-ficticio-processo"
    assert cfg.timeout == 4
    assert cfg.uor == "uor-ficticia-arquivo"
    assert cfg.user_id == "usuario-ficticio-arquivo"
    assert cfg.total_context == 7
    assert cfg.index_id == index
    assert cfg.query_type == "hybrid"


@pytest.mark.parametrize("process_value,expected_status", [("", None), ("   ", None), ("inválido", "configuracao_invalida")])
def test_existing_blank_or_invalid_env_is_not_replaced_by_dotenv(monkeypatch, tmp_path, process_value, expected_status):
    (tmp_path / ".env").write_text(
        "RAG_FAQ_TIMEOUT=9\nRAG_FAQ_UOR=uor-ficticia\n"
        "RAG_FAQ_USER_ID=usuario-ficticio\nRAG_FAQ_CLIENT_ID=jwt-ficticio\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("RAG_FAQ_TIMEOUT", process_value)
    mcp_server_module.create_app()
    assert os.environ["RAG_FAQ_TIMEOUT"] == process_value
    if expected_status:
        with pytest.raises(rag_module._RAGError) as caught:
            rag_module._load_config("FAQ")
        assert caught.value.status == expected_status
    else:
        assert rag_module._load_config("FAQ").timeout == 20.0
