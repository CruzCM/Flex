# Guia de Configuração dos dois RAGs — MCP Minhas Finanças (HML)

Este guia foi elaborado para que **qualquer pessoa consiga configurar os dois RAGs no OpenShift de Homologação (HML) diretamente pela tela do navegador**, sem necessidade de utilizar linhas de comando, terminal ou editar arquivos técnicos.

---

## 1. O que você precisa saber antes de começar

Para que o MCP consulte as bases de dados de **FAQ** e de **Educação Financeira** no GeneraBB, ele precisa de **seis valores oficiais**:

1. Dois tokens de autorização (JWTs).
2. Duas Unidades Organizacionais (UORs).
3. Duas matrículas ou identidades técnicas (User IDs).

### Entendendo os termos:
- **Secret:** É uma pasta protegida dentro do OpenShift que guarda senhas, chaves e identificadores de forma segura.
- **Key (Chave):** É o nome exato da configuração que o programa procura.
- **Value (Valor):** É o dado verdadeiro que você recebeu da equipe responsável.

---

## Tabela de Configurações Obrigatórias

Todos os seis campos abaixo serão cadastrados em **uma única Secret** chamada **`iaa-mcp-mf-rag-credentials`**:

| Nome do Campo (Key) | O que representa | O que preencher (Value) | Onde obter |
| :--- | :--- | :--- | :--- |
| `RAG_FAQ_CLIENT_ID` | Token de acesso ao FAQ | Token JWT do FAQ (cole apenas o token, sem a palavra `Bearer`) | Responsável pelo acesso GeneraBB ao FAQ |
| `RAG_FAQ_UOR` | Unidade responsável pelo FAQ | Número da UOR autorizada para o FAQ | Responsável pela integração do FAQ |
| `RAG_FAQ_USER_ID` | Identidade técnica do FAQ | Matrícula ou User ID técnico autorizado para o FAQ | Responsável pela integração do FAQ |
| `RAG_EDUCACAO_CLIENT_ID` | Token de acesso à Educação Financeira | Token JWT de Educação (cole apenas o token, sem a palavra `Bearer`) | Responsável pelo acesso GeneraBB à Educação |
| `RAG_EDUCACAO_UOR` | Unidade de Educação Financeira | Número da UOR autorizada para Educação Financeira | Responsável pela integração de Educação |
| `RAG_EDUCACAO_USER_ID` | Identidade de Educação Financeira | Matrícula ou User ID técnico de Educação Financeira | Responsável pela integração de Educação |

> [!IMPORTANT]
> **Campos que você NÃO precisa cadastrar:**  
> O código do programa já possui valores padrão automáticos para o endereço de consulta (URL do GeneraBB Core), para os nomes dos índices (`ix-mf-faq` e `idx-minhas-financas`), para o prazo limite de resposta (`20.0` segundos) e para a quantidade de trechos (`5`). Você só precisará informá-los se a equipe do GeneraBB solicitar expressamente um valor diferente.

> [!WARNING]
> **Certificado Corporativo (TLS / SSL):**  
> Caso a equipe de infraestrutura oriente o uso de um certificado corporativo próprio, a variável `REQUESTS_CA_BUNDLE` poderá ser configurada com o caminho do arquivo de certificados confirmado dentro do container. Sem esse certificado, o sistema opera com validação temporária de HML, registrando aviso no log.

---

## 2. Passo a Passo: Cadastrando a Secret pela Interface Gráfica

Siga rigorosamente os 7 passos abaixo dentro da console visual do OpenShift:

### Passo 1 — Acessar a console do OpenShift de Homologação
1. Abra o navegador de internet e acerte o endereço do console web do OpenShift de Homologação (HML) do Banco do Brasil.
2. Faça o login utilizando sua chave e senha de rede corporativa.

### Passo 2 — Selecionar o projeto correto
1. No topo da tela, localize a caixa de seleção de projetos (geralmente identificada como **Project** ou **Projeto**).
2. Clique na caixa e selecione o projeto: **`iaa-mcp-mf`**.
> [!CAUTION]
> **Atenção:** Certifique-se de escolher **`iaa-mcp-mf`**. Não selecione o projeto `iaa-agent-minhas-financas`, pois ele pertence ao Agente e não ao servidor MCP.

### Passo 3 — Encontrar a tela de Secrets
1. No menu de navegação localizado na lateral esquerda da tela, confirme que você está na visão **Administrator** (Administrador).
2. Clique no menu **Workloads** (ou **Cargas de trabalho**).
3. No submenu que se expande, clique em **Secrets**.

### Passo 4 — Iniciar a criação da Secret
1. No canto superior direito da página de Secrets, localize e clique no botão azul **Create** (Criar).
2. No menu suspenso que se abre, clique na opção **Key/value secret** (Secret de chave/valor).
3. No formulário que aparece, localize o campo **Secret name** (Nome da Secret) e digite exatamente:
   ```text
   iaa-mcp-mf-rag-credentials
   ```

### Passo 5 — Cadastrar os seis campos
No formulário, você verá campos para preencher **Key** (Chave) e **Value** (Valor). Preencha linha por linha:

1. **Primeiro campo:**
   - No campo **Key**, digite: `RAG_FAQ_CLIENT_ID`
   - No campo **Value**, cole o token JWT completo do FAQ (sem espaços extras e sem a palavra `Bearer`).

2. Clique no botão **Add key/value** (Adicionar chave/valor) abaixo do campo recém-preenchido:
   - No novo campo **Key**, digite: `RAG_FAQ_UOR`
   - No novo campo **Value**, digite a UOR autorizada do FAQ.

3. Clique novamente no botão **Add key/value**:
   - No novo campo **Key**, digite: `RAG_FAQ_USER_ID`
   - No novo campo **Value**, digite a matrícula/User ID autorizado do FAQ.

4. Clique novamente no botão **Add key/value**:
   - No novo campo **Key**, digite: `RAG_EDUCACAO_CLIENT_ID`
   - No novo campo **Value**, cole o token JWT completo de Educação Financeira (sem `Bearer`).

5. Clique novamente no botão **Add key/value**:
   - No novo campo **Key**, digite: `RAG_EDUCACAO_UOR`
   - No novo campo **Value**, digite a UOR autorizada de Educação Financeira.

6. Clique novamente no botão **Add key/value**:
   - No novo campo **Key**, digite: `RAG_EDUCACAO_USER_ID`
   - No novo campo **Value**, digite a matrícula/User ID autorizado de Educação Financeira.

### Passo 6 — Conferir antes de salvar
Antes de concluir, faça uma checagem visual cuidadosa:
- O projeto no topo é **`iaa-mcp-mf`**?
- O nome da Secret é **`iaa-mcp-mf-rag-credentials`**?
- Foram cadastradas exatamente as **seis chaves** listadas acima?
- Os valores foram colados corretamente sem quebras de linha?

Estando tudo correto, role até o final da página e clique no botão azul **Create** (ou **Salvar**).

### Passo 7 — Confirmar que a Secret foi criada
1. A tela retornará para a lista principal de Secrets do projeto `iaa-mcp-mf`.
2. Digite `iaa-mcp-mf-rag-credentials` na barra de busca (Search by name).
3. Confirme que a Secret aparece na tabela com status ativo.
> [!NOTE]
> Por segurança, nunca fotografe, copie ou compartilhe capturas de tela que exibam os valores dos tokens JWT ou identificadores.

---

## 3. Como essa Secret chega até o programa do MCP?

Você **não precisa editar nenhum arquivo YAML manualmente no ambiente corporativo**.

1. **Configuração prévia já concluída:**  
   O arquivo de configuração do deploy (`deploy-iaa-mcp-mf-cloud-homologacao/values.yaml`) já foi preparado localmente com a instrução `envFrom` apontando para a Secret `iaa-mcp-mf-rag-credentials`.
2. **Entrada em vigor:**  
   Assim que o merge for realizado na branch de homologação e o Argo CD sincronizar o ambiente, o OpenShift entregará automaticamente as seis variáveis para o container.
3. **Importante sobre pods já em execução:**  
   Criar ou alterar uma Secret não altera automaticamente um pod que já estava ligado. Se a Secret for cadastrada depois que o pod já estiver em execução, solicite um novo rollout (reinício controlado) do Deployment na tela do OpenShift para que o novo pod carregue as variáveis.

---

## 4. Validação Local Concluída

Antes de preparar esta entrega para merge, todo o comportamento do MCP foi validado localmente por meio de testes unitários automatizados com respostas simuladas (mocks):

- **124 testes executados e 124 aprovados (100% de sucesso).**
- O isolamento completo entre o FAQ e a Educação Financeira foi comprovado.
- Os tratamentos de erros de rede, credenciais ausentes, recusa de acesso e falhas de resposta foram testados e aprovados.
- Nenhum acesso a sistemas corporativos reais foi realizado e nenhum token real foi colocado no repositório.

---

## 5. Checklist Rápido de Homologação

### Antes de acessar o OpenShift:
- [ ] Obter os seis valores oficiais com os responsáveis pelo GeneraBB e pelas áreas de negócio.

### Na tela do OpenShift HML:
- [ ] Acessar o console web e selecionar o projeto **`iaa-mcp-mf`**.
- [ ] Entrar em **Workloads → Secrets** e clicar em **Create → Key/value secret**.
- [ ] Criar a Secret com o nome **`iaa-mcp-mf-rag-credentials`**.
- [ ] Adicionar as seis chaves e seus valores correspondentes.
- [ ] Salvar e conferir que a Secret aparece na lista do projeto.

### No deploy / esteira:
- [ ] Realizar o merge no repositório do MCP (`iaa-mcp-mf`).
- [ ] Acompanhar a execução do GitHub Actions.
- [ ] Realizar o merge no repositório de deploy (`deploy-iaa-mcp-mf-cloud-homologacao`) e acompanhar a sincronização do Argo CD.
- [ ] Confirmar que o novo pod subiu com sucesso e sem erros.
