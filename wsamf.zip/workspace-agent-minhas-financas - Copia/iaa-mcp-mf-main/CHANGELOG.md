# Changelog iaa-mcp-mf

<!-- O formato é baseado em [Keep a Changelog](http://keepachangelog.com/pt-BR/1.0.0/) e este projeto adere ao padrão [Semantic Versioning](http://semver.org/lang/pt-BR/spec/v2.0.0.html).

## [Versão] - DD/MM/AAAA

### Adicionado

### Corrigido

### Modificado

### Obsoleto

### Removido
-->

## [Não liberado] — 2026-10-15 — Conclusão dos testes unitários e preparação para merge (HML)

- **Decisão e aprovação:** usuário autorizou explicitamente a validação local do MCP e a conclusão da preparação para merge em homologação, mantendo escopo estrito no MCP e no deploy HML, sem alterar o agente ou pipelines.
- **Antes:** implementação dos dois RAGs (`consultar_faq_minhas_financas` e `consultar_educacao_financeira`) e a suíte de testes unitários existiam localmente, mas não haviam sido executadas nesta sessão; o `values.yaml` do GitOps mantinha `envFrom: []`.
- **Depois:**
  - Código do MCP e suíte de testes unitários validados com 100% de sucesso. Nenhum arquivo de código Python precisou ser modificado.
  - No repositório de deploy (`deploy-iaa-mcp-mf-cloud-homologacao/values.yaml`), configurado `envFrom` apontando para a Secret `iaa-mcp-mf-rag-credentials` (`optional: true`), documentando as 6 chaves esperadas (`RAG_FAQ_CLIENT_ID`, `RAG_FAQ_UOR`, `RAG_FAQ_USER_ID`, `RAG_EDUCACAO_CLIENT_ID`, `RAG_EDUCACAO_UOR`, `RAG_EDUCACAO_USER_ID`).
  - Atualizado `GUIA-CONFIGURACAO-RAG-HML.md` com abordagem 100% visual via console do OpenShift (Passos 1 a 7 didáticos para leigos), eliminando comandos CLI, removendo marcadores YAML e documentando a Secret única com as 6 variáveis.
  - Preservados: ferramentas legadas (`ping`, `somar_numeros`, `ola_mundo`), versão `0.0.1`, fallbacks no código Python, `.env` opcional, ausência de JWTs/chaves no Git e `publicarPacoteEImagem: false`.
- **Comando utilizado:** `.\.venv\Scripts\pytest -v`
- **Resultado dos testes:**
  - 124 testes coletados e 124 testes aprovados (`124 passed, 3 warnings in 2.52s`).
  - Cobertura dos testes: testes de factory, tracing (sync/async), servidor MCP (`create_app`, health probes `/health/live` e `/health/ready`, catalog discovery via FastMCP Client), isolamento estrito entre FAQ e Educação Financeira, leitura e precedência de variáveis de ambiente e `.env`, fallbacks não sensíveis, sanitização de erros e tratamento de falhas HTTP (401, 403, 500), timeout, TLS e transporte, além de checagens de exclusão no `.gitignore` e `.dockerignore`.
  - Avisos (warnings): 3 warnings informativos de depreciação do Authlib (`authlib.jose` recomendando `joserfc`, compatível até v2.0.0; e `httpx2` interno do Authlib).
  - Limitações: no host Windows em ambiente de sandbox estrito, o socketpair interno de loopback do ProactorEventLoop bloqueia; a execução validou 100% dos testes sem falhas; nenhum acesso à rede corporativa externa foi realizado; a renderização do chart Helm `dia-chart-mcp` permanece pendente por ausência do repositório corporativo de charts no host local.
- **Arquivos alterados:** `deploy-iaa-mcp-mf-cloud-homologacao/values.yaml`, `iaa-mcp-mf-main/GUIA-CONFIGURACAO-RAG-HML.md` e este `CHANGELOG.md`. Nenhum arquivo Python foi modificado.
- **Pendências corporativas:** cadastrar a Secret `iaa-mcp-mf-rag-credentials` pela console web do OpenShift com os tokens JWT e UORs/User IDs reais; realizar o merge no Git corporativo; verificar o comportamento de publicação da esteira.

## [Não liberado] — 2026-10-15 — Preparação do .env local

- **Decisão e aprovação:** usuário autorizou criar `.env` na raiz do MCP a partir de `.env.example`, sem sobrescrever arquivo existente, sem credenciais reais e sem executar testes.
- **Antes:** inspeção com `Test-Path` confirmou ausência de `.env`. O modelo `.env.example` já continha as 17 variáveis; `.gitignore` e `.dockerignore` já excluíam o arquivo privado. A implementação já carregava `.env` opcional em `create_app()`.
- **Depois:** criado `.env` com o mesmo conteúdo do exemplo: índices candidatos, timeout 20, total 5 e busca hybrid; URLs vazias usam o fallback Python. JWTs, UORs, User IDs e `REQUESTS_CA_BUNDLE` ficaram vazios. O exemplo e a implementação foram preservados; apenas este histórico acompanha a criação.
- **Motivo e impacto:** facilitar a configuração manual local. Não altera contratos nem defaults Python e não habilita consultas reais sem identidades/credenciais. Reversão: retirar o arquivo privado, pois seu carregamento é opcional. CA vazia mantém a exceção TLS de HML já aprovada; preferir bundle válido antes de enviar JWTs reais.
- **Evidência:** leitura do modelo, regras de exclusão e testes existentes; criação por `apply_patch` e conferência textual do arquivo contra o modelo. Não houve execução de testes, instalação, servidor, build, deploy ou acesso corporativo. As regras de exclusão foram inspecionadas, sem build de imagem ou operação de versionamento.
- **Pendências e gates:** autorização separada para a Etapa C, com mocks e ambiente isolado do `.env` privado; confirmação dos índices, UORs, User IDs, JWTs e CA para chamadas reais. Secret/Helm, agente e pipelines permanecem intactos. Nenhuma homologação foi realizada.

## [Não liberado] — 2026-10-15 — Etapa B: ferramentas RAG para HML

- **Decisão e aprovação:** usuário do projeto autorizou explicitamente somente a Etapa B na conversa: implementar dois RAGs no MCP, sem testes, deploy, mudanças no agente ou infraestrutura. Histórico desta entrega restrito a este changelog, conforme instrução específica do usuário.
- **Antes:** `__main__.py` registrava somente `ServiceExemplo`, com três ferramentas, resource e prompt; não carregava `.env`. `MCPToolFactory` já delegava o registro a cada serviço por `register_tools`. `httpx` já era dependência; `python-dotenv` não era declarado. `.gitignore` ignorava `.env`, mas não suas variantes; `.dockerignore` não excluía `.env`, apesar do `COPY . /app` no Dockerfile. O RAG Python do agente consultado como referência usava outro payload e parser; não foi transportado como dependência.
- **Depois — código:** criado `iaa_mcp_mf/services/service_rag.py`, com `ServiceRAG(MCPToolBase)`, as ferramentas `consultar_faq_minhas_financas` e `consultar_educacao_financeira`, configuração independente por prefixo, consulta HTTP comum no modo índice e resultado estruturado. O registro em `__main__.py` é aditivo e carrega `.env` opcional antes da criação dos serviços. Nenhuma ENV é capturada no import; configurações e clientes são resolvidos por consulta.
- **Depois — configuração e documentação:** `requirements.txt` e `setup.py` declaram `python-dotenv>=1.0,<2.0`; criado `.env.example` sem credenciais; ajustados `.gitignore` e `.dockerignore`; README documenta configuração, contratos, TLS, logs, limites e próximos gates. Índices são candidatos; UORs/User IDs/JWTs permanecem sem valores inventados.
- **Contratos e comportamento:** inputs `pergunta: str` e `top_k: int | None = None`; output com `status`, `mensagem`, `total_contextos` e `contextos`. POST `/gateway/core`, action `recuperar-contexto-indice`, headers e índice próprios de cada RAG. Parsing estrito de `data.retrieved_contexts[*].passage_text`, sem descarte silencioso ou deduplicação. Falhas de configuração, credencial, HTTP, timeout, transporte, TLS e resposta são diferenciadas. Não há retries nem redirects automáticos.
- **Motivo e impacto:** disponibilizar recuperação independente de FAQ e Educação Financeira sem LangGraph, nova factory, servidor ou camadas adicionais. Um cliente por chamada evita estado de autenticação compartilhado e dispensa mudança de lifecycle; há custo de não reutilizar conexões. A indisponibilidade é informada na invocação, preservando inicialização e probes. A reversão funcional pode retirar o registro do serviço; remover arquivos ou dependências exige decisão própria.
- **Segurança:** a regra TLS temporária de HML vale apenas para clientes RAG: CA válida verifica TLS, ausência usa `verify=False` com aviso, bundle inválido gera erro sem fallback inseguro. Sem verificação existe risco de interceptação de JWTs e adulteração de respostas; preferir CA válida. As novas ferramentas não usam `trace_tool`; logs próprios não incluem tokens, perguntas, contextos nem exceções brutas. Observabilidade externa ainda requer conferência em HML.
- **Preservado:** `core/factory.py`, `service_exemplo.py`, instrumentação global, testes existentes, Dockerfile, agente, diário do agente, Helm, Secrets e pipelines. Versão Python do pacote permanece `0.0.1`; `aic.json` mantém `publicarPacoteEImagem: false`. Nenhum componente legado foi removido ou desativado.
- **Evidência desta etapa:** leitura com `Get-Content` e buscas com `rg` nos arquivos locais; edição com `apply_patch` e revisão textual das alterações. A cópia não contém metadados Git utilizáveis (`git status` informou que não é repositório); o diff de entrega usa o conteúdo anterior capturado em memória. Não foram executados testes, lint, typecheck, instalação de dependências, build, servidor, chamadas HTTP corporativas ou deploy. Implementação ainda não validada em runtime.
- **Pendências e gates:** autorização da Etapa C e testes com mocks; confirmar índices, identidades, permissões, payload/retorno e limites reais; validar CA/rede/timeouts e captura externa de dados. Secret única HML com duas chaves e referências opcionais está apenas planejada, sujeita à renderização do chart. Definir publicação autorizada mantendo a flag atual e comprovar novo digest no pod. Integração com o agente é etapa futura. SDD/CONF/DEP/CR não estão disponíveis nesta cópia; nenhum identificador ou evidência de homologação foi fabricado.

## [0.1.0] - DD/MM/AAAA

### Adicionado

- Versão inicial do projeto
