# MCP Server - Python

> **Atenção!**
> **Configuração inicial de deploy em produção deve ser elaborada manualmente**
>
> A configuração do ambiente de deploy de produção **não é gerada automaticamente** por este template e deve ser elaborada manualmente pela equipe responsável, respeitando as políticas de infraestrutura e segurança vigentes.
>
> Os arquivos `Chart.yaml` e `values.yaml` (Helm chart) com a **configuração inicial esperada** estão disponíveis ao final deste documento. Eles podem ser utilizados de forma integral para a primeira versão do deploy — veja a seção [Configuração Inicial do Helm Chart](#configuração-inicial-do-helm-chart).

Template de servidor [Model Context Protocol (MCP)](https://modelcontextprotocol.io/) baseado em FastMCP, desenvolvido pela BB Internal Developer Platform.

Use este repositório como ponto de partida para criar novos servidores MCP no ecossistema BB.

1. [Funcionalidades](#funcionalidades)
2. [Estrutura](#estrutura)
3. [Serviços disponíveis](#serviços-disponíveis)
4. [Conectando ao VS Code via catálogo de APIs](#conectando-ao-vs-code-via-catálogo-de-apis)
5. [Execução local](#execução-local)
6. [OpenTelemetry](#opentelemetry)
7. [Adicionando novos serviços](#adicionando-novos-serviços)
8. [Referência de componentes](#referência-de-componentes)
9. [Testes](#testes)
10. [RAGs Minhas Finanças — HML](#rags-minhas-finanças--hml)

## Funcionalidades

- **FastMCP**: implementação com transporte `streamable-http` em modo stateless (`stateless_http=True`), expondo o servidor na porta `8080`
- **Factory Pattern**: `MCPToolFactory` + `MCPToolBase` para registro desacoplado de serviços; métodos `get_service()`, `get_all_services()` e `get_tool_summary()` para introspecção em runtime
- **Health Checks HTTP**: endpoints `/health/live` e `/health/ready` integrados ao servidor
- **OpenTelemetry Tracing**: decorator `@trace_tool` para instrumentar tools com spans; exporter configurável via variável de ambiente
- **Testes**: suite unitária completa com `pytest` e `FakeMCP` para isolamento

## Estrutura

```plaintext
iaa_mcp_mf/
├── __init__.py              # Versão do pacote
├── __main__.py              # Entry point: args, create_app(), main()
├── core/
│   ├── factory.py           # MCPToolFactory, MCPToolBase
│   └── tracing.py           # trace_tool decorator (OpenTelemetry)
└── services/
    ├── service_exemplo.py   # Serviço de exemplo: 3 tools + 1 resource + 1 prompt
    └── service_rag.py       # FAQ e Educação Financeira: 2 tools independentes

tests/
├── unit/
│   ├── helpers.py              # FakeMCP: substituto de FastMCP para testes
│   ├── conftest.py             # Configuração de sys.path
│   ├── test_mcp_server.py      # Testes do entry point (__main__)
│   ├── core/                   # Testes de factory e tracing
│   └── services/               # Testes dos serviços
└── integration/                # Testes de integração
```

## Serviços disponíveis

### ServiceExemplo

| Tipo     | Nome             | Descrição                                            |
| -------- | ---------------- | ---------------------------------------------------- |
| tool     | `somar_numeros`  | Soma dois inteiros                                   |
| tool     | `ola_mundo`      | Retorna saudação com o nome informado                |
| tool     | `ping`           | Verifica se o servidor responde (`pong`)             |
| resource | `exemplo://info` | Retorna info do serviço e lista de tools registradas |
| prompt   | `saudar`         | Gera prompt de saudação personalizada                |

## RAGs Minhas Finanças — HML

Etapa B implementada para revisão, sem testes executados e sem homologação.
`ServiceRAG(MCPToolBase)` registra duas ferramentas na factory existente:

| Ferramenta | Finalidade |
| --- | --- |
| `consultar_faq_minhas_financas` | Documentação de funcionalidades, uso e navegação do aplicativo |
| `consultar_educacao_financeira` | Conteúdos educativos sobre orçamento, dívidas, poupança e organização financeira |

Ambas recebem `pergunta: str` e `top_k: int | None = None`. O índice, a identidade e o JWT são definidos pelo MCP.
O registro é independente da configuração: credenciais ausentes não impedem startup, probes, exemplos ou catálogo.
A FAQ não comprova disponibilidade ou elegibilidade de funcionalidades para um cliente.

### Configuração independente e .env

Iniciar a aplicação a partir da raiz deste projeto. `create_app()` carrega somente `.env` do diretório corrente,
com `python-dotenv` e `override=False`, antes da criação dos serviços. O arquivo é opcional; não há leitura de ENV
no import de `service_rag.py`. As configurações são resolvidas a cada consulta, sem compartilhar identidades.

Precedência: ENV do processo, depois `.env` somente quando a variável não existir, depois fallback Python.
Uma ENV existente vazia não é substituída pelo `.env`; vazio ou somente espaços aciona o fallback.
Valor preenchido inválido gera `configuracao_invalida`, sem fallback silencioso.

| FAQ | Educação Financeira | Fallback e regra |
| --- | --- | --- |
| `RAG_FAQ_URL` | `RAG_EDUCACAO_URL` | `https://generabb-acs.gbb.servicos.bb.com.br/gateway/core`; HTTPS sem credenciais, query ou fragmento |
| `RAG_FAQ_INDEX_ID` | `RAG_EDUCACAO_INDEX_ID` | `ix-mf-faq` / `idx-minhas-financas`, candidatos não confirmados |
| `RAG_FAQ_CLIENT_ID` | `RAG_EDUCACAO_CLIENT_ID` | Nenhum JWT no código; obrigatório para a consulta correspondente |
| `RAG_FAQ_UOR` | `RAG_EDUCACAO_UOR` | Vazio até confirmação; obrigatório para consultar |
| `RAG_FAQ_USER_ID` | `RAG_EDUCACAO_USER_ID` | Vazio até confirmação da identidade técnica; obrigatório para consultar |
| `RAG_FAQ_TIMEOUT` | `RAG_EDUCACAO_TIMEOUT` | `20.0` segundos; finito e positivo |
| `RAG_FAQ_TOTAL_CONTEXT` | `RAG_EDUCACAO_TOTAL_CONTEXT` | `5`; inteiro positivo |
| `RAG_FAQ_QUERY_TYPE` | `RAG_EDUCACAO_QUERY_TYPE` | `hybrid`; único tipo suportado nesta etapa |

`top_k` informado prevalece sobre o total configurado; a configuração deve permanecer válida mesmo com esse override.
Não há limite máximo de contextos inventado: confirmar o limite aceito pelo provedor antes de uso real.
Se identificadores e JWT estiverem ausentes simultaneamente, a consulta informa primeiro os identificadores faltantes.

`.env.example` contém as duas seções e `REQUESTS_CA_BUNDLE`, sem tokens ou identidades fictícias.
O `.env` privado e suas variantes são ignorados pelo Git; `.env.example` é a exceção versionada.
O contexto Docker exclui `.env` e `.env.*`, inclusive o exemplo. O pod não depende de arquivo `.env`.

### Consulta, resultado e erros

A implementação HTTP comum faz POST em `/gateway/core`, com `action=recuperar-contexto-indice`.
O payload contém `body.data.input`, `body.data.index_id` e `body.data.context` com `query_type` e `total_context`.
Os headers `X-Client-Id`, `UOR` e `userIdentification` pertencem exclusivamente ao RAG selecionado.
Não há modo agente legado, retries ou redirects automáticos. Cada chamada cria e fecha seu `httpx.AsyncClient`;
o timeout HTTP e o prazo total da operação usam o timeout daquele RAG. Não há pool/cookies compartilhados.

A saída tem `status`, `mensagem`, `total_contextos` e `contextos: list[str]`.
Os textos vêm exclusivamente de `data.retrieved_contexts[*].passage_text`, com espaços externos removidos,
ordem e duplicidades preservadas. Nenhum score, título ou URL é sintetizado.
Uma lista vazia significa `sem_resultados`; campo ausente, item malformado ou texto vazio invalida a resposta inteira.

| Condição | Status |
| --- | --- |
| Contextos válidos / lista vazia | `sucesso` / `sem_resultados` |
| Índice, UOR ou User ID ausente | `nao_configurado` |
| URL, número, query type, header ou CA inválido | `configuracao_invalida` |
| JWT ausente / HTTP 401 / HTTP 403 | `credencial_ausente` / `credencial_invalida` / `acesso_negado` |
| Prazo excedido / demais erros HTTP | `timeout` / `erro_http` |
| Falha TLS identificada / outro erro de transporte | `erro_tls` / `erro_conexao` |
| JSON ou estrutura inválida | `resposta_inesperada` |
| Pergunta vazia ou top_k inválido / falha imprevista | `entrada_invalida` / `erro_interno` |

Erros de tipo seguem a validação FastMCP. Falhas tratadas pelo serviço retornam lista vazia e total zero,
com status específico e mensagem controlada, sem repassar corpos HTTP ou texto bruto de exceções.

### TLS e observabilidade

`REQUESTS_CA_BUNDLE` é compartilhado apenas como configuração de confiança dos clientes RAG:

- Preenchido e válido: carregar com `ssl.create_default_context(cafile=...)` e verificar TLS.
- Vazio ou ausente: `verify=False`, com aviso operacional, conforme exceção temporária aprovada para HML.
- Caminho ilegível/inexistente ou bundle inválido: erro de configuração, sem conexão insegura de fallback.
- Falha TLS durante a conexão: `erro_tls`, sem nova tentativa com verificação desabilitada.

Sem validação TLS, um intermediário pode capturar JWTs e perguntas ou adulterar os contextos.
Preferir bundle válido desde o primeiro teste autenticado; durante a exceção, usar JWTs de HML com permissões mínimas
e validade curta. Os caminhos `/etc/pki/tls/certs/ca-bundle.crt` e `/app/certs/ca.crt` ainda não foram validados aqui.
Nenhuma configuração SSL global do MCP é alterada.

As ferramentas RAG não usam `trace_tool`, pois esse decorator registra argumentos e resultados completos.
Seus logs contêm apenas ferramenta, status, total, duração e categoria; o aviso TLS não contém dados da consulta.
A instrumentação existente permanece intacta. A captura externa de headers e conteúdo por observabilidade deve ser
verificada no ambiente autorizado antes de chamadas autenticadas; o código local não comprova essa configuração.

### Etapas posteriores, ainda não executadas

- Etapa C: testes de registro, ENV/.env/fallback, inputs, payloads e headers separados, parsing, erros,
  timeout/TLS, fechamento dos clientes, logs sanitizados, concorrência, independência e regressão dos exemplos/probes.
- Confirmar índices, UORs, User IDs técnicos, permissões/JWTs, contrato físico, limites e conectividade GeneraBB.
- HML: disponibilizar uma Secret `iaa-mcp-mf-rag-credentials`, namespace `iaa-mcp-mf`, somente com
  `RAG_FAQ_CLIENT_ID` e `RAG_EDUCACAO_CLIENT_ID`; jamais versionar tokens, mesmo em base64.
- Injetar cada chave com `valueFrom.secretKeyRef` e `optional: true`, preservando `envFrom: []`, somente após
  conferir a renderização do chart corporativo. Secret/chave ausente não deve impedir startup do container.
- Configurar UORs/User IDs por ENV enquanto não houver fallbacks confirmados. Demais ENV só quando necessário.
- Verificar apenas presença/ausência de conteúdo das ENV no pod, sem exibir valores. Rotação exige atualização
  dos processos/pods que consomem Secret por ENV, em operação aprovada separadamente.
- Definir publicação autorizada e comprovar commit/build/digest executado: a tag `0.0.1` com `IfNotPresent`
  não garante atualização. Manter `publicarPacoteEImagem: false`; nenhuma mudança de pipeline foi realizada.
- Validar `tools/list`, `ping` e as duas consultas via gateway corporativo autorizado, com documentos esperados,
  ausência de mistura entre bases e prazo compatível com o timeout externo.

Nenhum teste, instalação de dependências, build, deploy, acesso corporativo ou alteração de Helm/Secret integra a Etapa B.
A integração com o agente depende de autorização posterior. A documentação de template abaixo permanece como referência.

## Conectando ao VS Code via catálogo de APIs

> **Pré-requisito:** o servidor precisa estar em execução e acessível na URL configurada. A aplicação deve estar publicada e disponível no catálogo de APIs.

Para usar as tools deste servidor em qualquer projeto no VS Code, conecte diretamente à URL do ambiente desejado no catálogo interno de APIs.

Escolha o escopo de configuração:

**Somente neste projeto** — crie `.vscode/mcp.json` na raiz do repositório:

```json
{
    "servers": {
        "iaa-mcp-server": {
            "type": "http",
            "url": "<URL_DO_AMBIENTE>/mcp"
        }
    }
}
```

**Em todos os projetos** — adicione ao `settings.json` do usuário (`Ctrl+Shift+P` -> **Preferences: Open User Settings (JSON)**):

```json
{
    "mcp": {
        "servers": {
            "iaa-mcp-server": {
                "type": "http",
                "url": "<URL_DO_AMBIENTE>/mcp"
            }
        }
    }
}
```

Substitua `<URL_DO_AMBIENTE>` pela URL correspondente ao ambiente:

| Ambiente        | URL base                                                       |
| --------------- | -------------------------------------------------------------- |
| Local           | `http://localhost:8080`                                        |
| Desenvolvimento | `https://api.intranet.desenv.bb.com.br/iaa-mcp-mf/v1` |
| Homologação     | `https://api.intranet.hm.bb.com.br/iaa-mcp-mf/v1`     |
| Produção        | `https://api.intranet.bb.com.br/iaa-mcp-mf/v1`        |

Após salvar, abra a paleta de comandos e execute **MCP: List Servers** para confirmar a conexão. As tools ficam disponíveis automaticamente no Copilot Chat no modo **Agent**.

## Execução local

### Instalação

> **Pré-requisito:** Python 3.11 ou superior.

```bash
pip install -r requirements.txt
```

### Iniciando o servidor

```bash
python -m iaa_mcp_mf
```

Opcionalmente, informe host e porta:

```bash
python -m iaa_mcp_mf --host 127.0.0.1 --port 8080
```

### Verificando os health checks

```bash
curl http://localhost:8080/health/live
curl http://localhost:8080/health/ready
```

## OpenTelemetry

O módulo `core/tracing.py` fornece o decorator `@trace_tool` para instrumentar tools com spans OpenTelemetry.

### Como funciona

Cada chamada à tool cria um span com o nome informado, registra os argumentos e o resultado como atributos, e captura exceções automaticamente:

```python
from ..core.tracing import trace_tool

@mcp.tool(name="minha_tool", description="Exemplo com tracing.")
@trace_tool("minha_tool")
def minha_tool(parametro: str) -> str:
    return f"Resultado: {parametro}"
```

Funciona igualmente com funções `async`.

## Adicionando novos serviços

Cada serviço é uma classe que herda de `MCPToolBase` e implementa `register_tools`, onde tools, resources e prompts são declarados diretamente com os decorators do FastMCP. O atributo `_tool_names` rastreia as tools registradas e é usado por `tool_count` — necessário para o factory calcular o total de tools do servidor.

**Passo 1** — Crie `iaa_mcp_mf/services/meu_servico.py`:

```python
from fastmcp import FastMCP
from ..core.factory import MCPToolBase
from ..core.tracing import trace_tool

class MeuServico(MCPToolBase):
    def __init__(self):
        super().__init__()
        self._tool_names: list[str] = []

    @property
    def tool_count(self) -> int:
        return len(self._tool_names)

    def register_tools(self, mcp: FastMCP) -> None:
        self._tool_names.clear()

        @mcp.tool(name="minha_tool", description="Descrição clara do que a tool faz.")
        @trace_tool("minha_tool")
        def minha_tool(parametro: str) -> str:
            return f"Resultado: {parametro}"

        self._tool_names.append("minha_tool")
```

**Passo 2** — Registre o serviço em `__main__.py`:

```python
from .services.meu_servico import MeuServico

def create_app() -> FastMCP:
    factory = MCPToolFactory()
    factory.register_service(ServiceExemplo())
    factory.register_service(MeuServico())  # adicione aqui
    ...
```

Consulte a seção [Referência de componentes](#referência-de-componentes) para exemplos completos de tools assíncronas, resources e prompts.

## Referência de componentes

### Tools

**Tool síncrona** — parâmetros anotados geram o schema JSON automaticamente:

```python
@mcp.tool(name="minha_tool", description="O que esta tool faz, em uma frase clara.")
def minha_tool(parametro: str) -> str:
    return f"Resultado para: {parametro}"

self._tool_names.append("minha_tool")
```

**Tool assíncrona** — use `async` ao chamar APIs externas, banco de dados, etc.:

```python
@mcp.tool(name="minha_tool_async", description="Exemplo assíncrono.")
async def minha_tool_async(id: int) -> dict:
    resultado = await algum_cliente_http.get(f"/recurso/{id}")
    return resultado

self._tool_names.append("minha_tool_async")
```

**Tool com confirmação (`ctx.elicit`)** — pausa e solicita confirmação interativa ao usuário:

```python
from fastmcp import Context

@mcp.tool(name="acao_sensivel", description="Pede confirmação antes de executar.")
async def acao_sensivel(ctx: Context, item_id: int) -> dict:
    r = await ctx.elicit(f"Confirma a exclusão do item {item_id}?")
    if r.action == "accept":
        return {"status": "removido", "id": item_id}
    return {"status": "cancelado"}

self._tool_names.append("acao_sensivel")
```

### Resources

Expõe dados somente-leitura via URI. Use `{variavel}` na URI para resources parametrizados:

```python
# Resource estático
@mcp.resource(
    "meuservico://config",
    name="get_config",
    description="Retorna a configuração do serviço.",
    mime_type="application/json",
)
def get_config() -> dict:
    return {"servico": "meu_servico", "ativo": True}

# Resource parametrizado
@mcp.resource(
    "meuservico://itens/{item_id}",
    name="get_item",
    description="Retorna um item pelo ID.",
    mime_type="application/json",
)
def get_item(item_id: int) -> dict:
    return {"id": item_id, "nome": f"Item {item_id}"}
```

### Prompts

Templates de instrução reutilizáveis para o LLM. Devem retornar uma `str` ou lista de mensagens:

```python
@mcp.prompt
def instrucao_analise(contexto: str) -> str:
    """Gera uma instrução de análise com o contexto fornecido."""
    return f"Analise o seguinte contexto e forneça uma resposta objetiva: {contexto}"
```

## Testes

```bash
# Testes unitários (configurados em pytest.ini)
pytest

# Com cobertura
pytest --cov=iaa_mcp_mf

# Arquivo específico
pytest tests/unit/services/test_service_exemplo.py -v
```
---

## Configuração Inicial do Helm Chart

Os arquivos abaixo representam a **configuração inicial esperada** para o deploy em produção. Eles podem ser copiados integralmente para a primeira versão.

---

### `Chart.yaml`

```yaml
apiVersion: v2
appVersion: "0.0.1"
description: Chart padrão e suas dependências do projeto iaa-mcp-mf
name: chart-iaa-mcp-mf
version: 0.0.1
dependencies:
- name: dia-chart-mcp
  version: ~1.0.0
  alias: iaa-mcp-mf
  repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/dia

- name: bbcert
  version: ~1.0.7
  repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/psc
```

---

### `values.yaml`

```yaml
iaa-mcp-mf:
  projetoPiloto: false
  multEnv: false
  service:
    enable: true
    name: iaa-mcp-mf
    type: ClusterIP
    ports:
    - name: http
      port: 80
      targetPort: 8080

  hpa:
    enable: false
    minReplicas: 2
    maxReplicas: 5
    memory: {}
    cpu: {}

  deployment:
    enable: true
    imagePullSecrets: atfregistry
    replicaCount: 1
    extraLabels: {}
    containers:
      tag: "0.1.0-SNAPSHOT"
      imagePullPolicy: IfNotPresent
      environments:
        - name: MP_OPENAPI_SERVERS
          value: https://iaa-mcp-mf.iaa.intranet.bb.com.br
        - name: ENABLE_INDEX
          value: index.html
        - name: ENABLE_SWAGGER
          value: "false"
        - name: OTEL_K8S_NODE_IP
          valueFrom:
            fieldRef:
              fieldPath: status.hostIP
        - name: "OTEL_EXPORTER_OTLP_ENDPOINT"
          value: "http://$(OTEL_K8S_NODE_IP):4317"
        - name: OTEL_PYTHON_EXCLUDED_URLS
          value: "v1/health/.*,metrics"
        - name: KEY_STORE_CERT_PATH
          value: /app/certs/tls.crt
        - name: KEY_STORE_KEY_PATH
          value: /app/certs/tls.key
        - name: TRUST_STORE_CA_PATH
          value: /app/certs/ca.crt
      envFrom: []
      ports: []
      resources:
        requests:
          cpu: 50m         # Valor em millicores/millicpu (m)
          memory: 250Mi     # Valor em megabyte (MiB)
        limits:
          cpu: 3001m         # Valor em millicores/millicpu (m)
          memory: 375Mi    # Valor em megabyte (MiB)
      livenessProbe:
        initialDelaySeconds: 30
        periodSeconds: 10
        timeoutSeconds: 10
        failureThreshold: 6
        successThreshold: 1
        httpGet:
          path: "/health/live"
          port: 8080
      readinessProbe:
        initialDelaySeconds: 30
        periodSeconds: 10
        timeoutSeconds: 10
        failureThreshold: 6
        successThreshold: 1
        httpGet:
          path: "/health/ready"
          port: 8080

      volumeMounts:
        - name: tls-certs-volume
          mountPath: /app/certs
          readOnly: true
    volumes:
      - name: tls-certs-volume
        secret:
          secretName: idh-mtls
          items:
            - key: tls.crt
              path: tls.crt
            - key: tls.key
              path: tls.key
            - key: ca.crt
              path: ca.crt

    strategy:
      type: RollingUpdate
    nodeSelector: {}
    tolerations: []
    hostAliases: []
    initContainer:
      enable: false
      image: bb/psc/busybox #será concatenado à atf.intranet.bb.com.br:5001
      tag: "1.31.1"
      imagePullPolicy: IfNotPresent
      environments: []
      envFrom: []
      resources:
        requests:
          cpu: 100m       # Valor em millicores/millicpu (m)
          memory: 250Mi   # Valor em megabyte (MiB)
        limits:
          cpu: 150m       # Valor em millicores/millicpu (m)
          memory: 375Mi   # Valor em megabyte (MiB)
      volumeMounts: []

  ingress:
    enable: true
    hostname: iaa-mcp-mf.iaa.intranet.bb.com.br
    servicePort: 80
    annotations:
      kubernetes.io/ingress.class: ingress-interno-iib
      haproxy.org/timeout-connect: "30s"
      haproxy.org/timeout-server: "1800s"
      haproxy.org/timeout-client: "1800s"
    paths:
      - path: "/"
        backend:
          serviceName: iaa-mcp-mf
          servicePort: 80
    tls:
      - secretName: iaa-mcp-mf-tls
        hosts:
          - iaa-mcp-mf.iaa.intranet.bb.com.br

  dnsingress:
    urls:
      - hostname: "iaa-mcp-mf.iaa.intranet.bb.com.br"
        ingressClass: ingress-interno-iib

  idhmtls:
    enabled: true
    renewTime: 365
    secretName: "idh-mtls"
    nomesAlternativos: []

bbcert:
  enabled: true

  custodianteCertificado:
    # Informe a matricula do funcionário que receberá os e-mails enviados pela
    # PKI BB e pelo Portal OaaS, no formato 'F99999999'.
    matriculaBB: "F99999999"

  # Todos os campos de 'dadosCertificado' são 'imutáveis', não podendo ser alterados
  # após a criação do objeto BBCert, caso seja necessário alterar algum desses
  # dados então crie um novo objeto BBCert e após criação apague o anterior.
  dadosCertificado:
    # 'ambientePKI' indica qual servidor PKI irá assinar esse certificado,
    # valores aceitos "des", "hml" ou "prd".
    ambientePKI: "prd"
    # 'commomName' é a URL principal a ser autenticada neste certificado, por
    # exemplo 'sigla.hm.bb.com.br'.
    commomName: "iaa-mcp-mf.iaa.intranet.bb.com.br"
    # 'alternativesNames' é um array de strings, com as URL´s alternativas /
    # adicionais, a serem autenticadas juntamente neste certificado, por exemplo:
    # - "*.sigla.hm.bb.com.br"
    # - "outra-url.sigla.hm.bb.com.br"
    alternativesNames:
      - "*.iaa-mcp-mf.iaa.intranet.bb.com.br"
    # 'ttl' determina a validade do certificado, valor máximo e default '365'.
    ttl: 365
    # 'secretNameToExport' indica o nome da Secret onde será armazenado o
    # certificado gerado.
    secretNameToExport: "iaa-mcp-mf-tls"

  # A secção de 'autoRenew' trata da renovação automatica do certificado.
  autoRenew:
    # Habilita ou não o controle da renovação pelo BBCert Operator.
    enabled: true
    # 'qtDaysBeforeCertExpirion' indica com quantos dias antes do vencimento o
    # BBCert Operator deve providenciar a renovação do certificado e atualização
    # da Secret
    qtDaysBeforeCertExpirion: 30
```
