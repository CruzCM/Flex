"""Pacote do servidor MCP."""

__version__ = "0.0.1"
