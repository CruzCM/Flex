"""Utilitários de rastreamento OpenTelemetry para tools MCP."""

import asyncio
import functools
import logging
from typing import Callable

from opentelemetry import trace

tracer = trace.get_tracer(__name__)
logger = logging.getLogger(__name__)


def trace_tool(tool_name: str) -> Callable:
    """Decorator que envolve uma tool MCP em um span OpenTelemetry."""
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with tracer.start_as_current_span(tool_name) as span:
                try:
                    logger.info("tool=%s chamada args=%s", tool_name, kwargs)
                    for key, value in kwargs.items():
                        span.set_attribute(f"tool.arg.{key}", str(value))
                    result = fn(*args, **kwargs)
                    span.set_attribute("tool.result", str(result))
                    logger.info("tool=%s resultado=%s", tool_name, result)
                    return result
                except Exception as exc:
                    span.record_exception(exc)
                    span.set_status(trace.StatusCode.ERROR, str(exc))
                    logger.exception("tool=%s erro: %s", tool_name, exc)
                    raise

        @functools.wraps(fn)
        async def async_wrapper(*args, **kwargs):
            with tracer.start_as_current_span(tool_name) as span:
                try:
                    logger.info("tool=%s chamada args=%s", tool_name, kwargs)
                    for key, value in kwargs.items():
                        span.set_attribute(f"tool.arg.{key}", str(value))
                    result = await fn(*args, **kwargs)
                    span.set_attribute("tool.result", str(result))
                    logger.info("tool=%s resultado=%s", tool_name, result)
                    return result
                except Exception as exc:
                    span.record_exception(exc)
                    span.set_status(trace.StatusCode.ERROR, str(exc))
                    logger.exception("tool=%s erro: %s", tool_name, exc)
                    raise

        return async_wrapper if asyncio.iscoroutinefunction(fn) else wrapper

    return decorator
