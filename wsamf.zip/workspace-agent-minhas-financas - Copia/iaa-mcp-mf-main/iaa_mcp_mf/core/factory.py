"""Componentes principais do servidor MCP."""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from fastmcp import FastMCP


class MCPToolBase(ABC):
    """Classe base para serviços de tools MCP."""

    @abstractmethod
    def register_tools(self, mcp: FastMCP) -> None:
        """Registra as tools no servidor MCP."""

    @property
    @abstractmethod
    def tool_count(self) -> int:
        """Número de tools deste serviço."""


class MCPToolFactory:
    """Fábrica de tools MCP."""

    def __init__(self):
        self._services: Dict[str, MCPToolBase] = {}

    def register_service(self, service: MCPToolBase) -> None:
        """Registra um serviço na fábrica."""
        key = service.__class__.__name__
        if key in self._services:
            raise ValueError(f"Serviço '{key}' já registrado.")
        self._services[key] = service

    def create_mcp_server(
        self, name: str = "MCPServer"
    ) -> FastMCP:
        """Cria e configura o servidor MCP com os serviços registrados."""
        mcp = FastMCP(name)

        for service in self._services.values():
            service.register_tools(mcp)

        return mcp

    def get_service(self, service_class: type) -> Optional[MCPToolBase]:
        """Retorna o serviço pelo tipo da classe."""
        return self._services.get(service_class.__name__)

    def get_all_services(self) -> Dict[str, MCPToolBase]:
        """Retorna todos os serviços registrados."""
        return self._services.copy()

    def get_tool_summary(self) -> Dict[str, Any]:
        """Retorna um resumo de tools e serviços."""
        summary = {
            "total_services": len(self._services),
            "total_tools": sum(
                service.tool_count for service in self._services.values()
            ),
            "services": {},
        }

        for name, service in self._services.items():
            summary["services"][name] = {
                "tool_count": service.tool_count,
            }

        return summary
