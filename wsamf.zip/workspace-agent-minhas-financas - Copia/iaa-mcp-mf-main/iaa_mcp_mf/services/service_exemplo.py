"""Serviço de exemplo com implementações de tools, resource e prompt."""

from fastmcp import FastMCP
from ..core.factory import MCPToolBase
from ..core.tracing import trace_tool


class ServiceExemplo(MCPToolBase):
    """Serviço de exemplo com tools, resource e prompt."""

    def __init__(self):
        super().__init__()
        self._tool_names: list[str] = []

    @property
    def tool_count(self) -> int:
        """Número de tools registradas."""
        return len(self._tool_names)

    def register_tools(self, mcp: FastMCP) -> None:
        """Registra tools, resource e prompt de exemplo no servidor."""
        self._tool_names.clear()

        # --- tools ---

        @mcp.tool(name="somar_numeros", description="Soma dois números inteiros.")
        @trace_tool("somar_numeros")
        def somar_numeros(a: int, b: int) -> int:
            return a + b

        self._tool_names.append("somar_numeros")

        @mcp.tool(name="ola_mundo", description="Retorna uma saudação com o nome informado.")
        @trace_tool("ola_mundo")
        def ola_mundo(nome: str) -> str:
            return f"Olá, {nome}!"

        self._tool_names.append("ola_mundo")

        @mcp.tool(name="ping", description="Verifica se o servidor responde. Retorna 'pong'.")
        @trace_tool("ping")
        def ping() -> str:
            return "pong"

        self._tool_names.append("ping")

        # --- resource ---

        @mcp.resource(
            "exemplo://info",
            name="obter_info",
            description="Retorna informações básicas sobre o serviço de exemplo.",
            mime_type="application/json",
        )
        def obter_info() -> dict:
            return {"servico": "exemplo", "status": "ok", "tools": self._tool_names}

        # --- prompt ---

        @mcp.prompt
        def saudar(nome: str) -> str:
            """Gera um prompt de saudação personalizado."""
            return f"Cumprimente o usuário chamado {nome} de forma cordial e profissional."
