"""Duas ferramentas de recuperação por índice GeneraBB, destinadas a HML."""

import asyncio
from dataclasses import dataclass, field
import logging
import math
import os
import ssl
from time import monotonic

from fastmcp import FastMCP
import httpx

from ..core.factory import MCPToolBase

logger = logging.getLogger(__name__)

# Somente constantes: nenhuma ENV é capturada durante o import.
_DEFAULTS = {
    "FAQ": {
        "URL": "https://generabb-acs.gbb.servicos.bb.com.br/gateway/core",
        "INDEX_ID": "ix-mf-faq",  # Candidato: confirmar antes das chamadas reais.
        "CLIENT_ID": "",
        "UOR": "",
        "USER_ID": "",
        "TIMEOUT": "20.0",
        "TOTAL_CONTEXT": "5",
        "QUERY_TYPE": "hybrid",
    },
    "EDUCACAO": {
        "URL": "https://generabb-acs.gbb.servicos.bb.com.br/gateway/core",
        "INDEX_ID": "idx-minhas-financas",  # Candidato: confirmar em HML.
        "CLIENT_ID": "",
        "UOR": "",
        "USER_ID": "",
        "TIMEOUT": "20.0",
        "TOTAL_CONTEXT": "5",
        "QUERY_TYPE": "hybrid",
    },
}

_TOOL_NAMES = {
    "FAQ": "consultar_faq_minhas_financas",
    "EDUCACAO": "consultar_educacao_financeira",
}


@dataclass(frozen=True)
class _RAGConfig:
    url: str
    index_id: str
    client_id: str = field(repr=False)
    uor: str = field(repr=False)
    user_id: str = field(repr=False)
    timeout: float
    total_context: int
    query_type: str


class _RAGError(Exception):
    """Erro esperado; mensagem contém apenas texto controlado, nunca dados HTTP."""

    def __init__(self, status: str, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def _load_config(rag: str) -> _RAGConfig:
    prefix = f"RAG_{rag}_"
    values = {
        key: os.getenv(prefix + key, "").strip() or fallback
        for key, fallback in _DEFAULTS[rag].items()
    }
    try:
        url = httpx.URL(values["URL"])
    except (httpx.InvalidURL, ValueError):
        raise _RAGError("configuracao_invalida", f"{prefix}URL inválida.") from None
    if url.scheme != "https" or not url.host or url.userinfo or url.query or url.fragment:
        raise _RAGError(
            "configuracao_invalida",
            f"{prefix}URL deve ser HTTPS, com host e sem credenciais, query ou fragmento.",
        )
    try:
        timeout = float(values["TIMEOUT"])
        total_context = int(values["TOTAL_CONTEXT"])
    except (ValueError, OverflowError):
        raise _RAGError(
            "configuracao_invalida", f"{prefix}TIMEOUT ou {prefix}TOTAL_CONTEXT inválido."
        ) from None
    if not math.isfinite(timeout) or timeout <= 0 or total_context <= 0:
        raise _RAGError(
            "configuracao_invalida", "Timeout deve ser finito e positivo; total de contextos deve ser positivo."
        )
    if values["QUERY_TYPE"] != "hybrid":
        raise _RAGError("configuracao_invalida", f"{prefix}QUERY_TYPE suportado nesta etapa: hybrid.")

    missing = [prefix + key for key in ("INDEX_ID", "UOR", "USER_ID") if not values[key]]
    if missing:
        raise _RAGError("nao_configurado", "Configuração ausente: " + ", ".join(missing) + ".")
    if not values["CLIENT_ID"]:
        raise _RAGError("credencial_ausente", f"{prefix}CLIENT_ID não configurado.")
    for key in ("CLIENT_ID", "UOR", "USER_ID"):
        if any(ord(char) < 33 or ord(char) > 126 for char in values[key]):
            raise _RAGError("configuracao_invalida", f"{prefix}{key} contém caracteres inválidos para o header.")

    return _RAGConfig(
        url=str(url), index_id=values["INDEX_ID"], client_id=values["CLIENT_ID"],
        uor=values["UOR"], user_id=values["USER_ID"], timeout=timeout,
        total_context=total_context, query_type=values["QUERY_TYPE"],
    )


def _resolve_verify(tool_name: str) -> ssl.SSLContext | bool:
    ca_bundle = os.getenv("REQUESTS_CA_BUNDLE", "").strip()
    if not ca_bundle:
        logger.warning("tool=%s categoria=tls_desabilitado verificacao_tls=false uso=HML", tool_name)
        return False
    try:
        return ssl.create_default_context(cafile=ca_bundle)
    except (OSError, ValueError):
        raise _RAGError(
            "configuracao_invalida", "REQUESTS_CA_BUNDLE não aponta para um bundle CA válido e legível."
        ) from None


def _parse_contexts(data: object) -> list[str]:
    response_data = data.get("data") if isinstance(data, dict) else None
    items = response_data.get("retrieved_contexts") if isinstance(response_data, dict) else None
    if not isinstance(items, list):
        raise _RAGError("resposta_inesperada", "Resposta sem uma lista data.retrieved_contexts válida.")
    contexts = []
    for item in items:
        passage = item.get("passage_text") if isinstance(item, dict) else None
        if not isinstance(passage, str) or not passage.strip():
            raise _RAGError("resposta_inesperada", "Contexto sem passage_text textual e não vazio.")
        contexts.append(passage.strip())
    return contexts


def _is_tls_error(exc: BaseException) -> bool:
    """Inspeciona tipos na cadeia, sem depender de mensagens potencialmente sensíveis."""
    pending = [exc]
    visited = set()
    while pending:
        current = pending.pop()
        if id(current) in visited:
            continue
        visited.add(id(current))
        if isinstance(current, ssl.SSLError):
            return True
        for nested in (current.__cause__, current.__context__):
            if nested is not None:
                pending.append(nested)
    return False


def _result(tool_name: str, started: float, status: str, message: str, contexts: list[str] | None = None) -> dict:
    contexts = contexts if contexts is not None else []
    category = "nenhuma" if status in ("sucesso", "sem_resultados") else status
    logger.info(
        "tool=%s status=%s total_contextos=%d duracao_ms=%.1f categoria=%s",
        tool_name, status, len(contexts), (monotonic() - started) * 1000, category,
    )
    return {"status": status, "mensagem": message, "total_contextos": len(contexts), "contextos": contexts}


class ServiceRAG(MCPToolBase):
    """Registra as duas tools sem ler configuração nem acessar o GeneraBB no startup."""

    def __init__(self):
        self._tool_names: list[str] = []

    @property
    def tool_count(self) -> int:
        return len(self._tool_names)

    def register_tools(self, mcp: FastMCP) -> None:
        self._tool_names.clear()

        # Não aplicar trace_tool: ele registra argumentos e resultados completos.
        @mcp.tool(
            name=_TOOL_NAMES["FAQ"],
            description="Recupera documentação sobre funcionalidades, uso e passos de navegação do aplicativo "
                        "Minhas Finanças. Não consulta dados financeiros pessoais nem comprova elegibilidade "
                        "de funcionalidades para um cliente.",
        )
        async def consultar_faq_minhas_financas(pergunta: str, top_k: int | None = None) -> dict:
            return await self._consultar("FAQ", pergunta, top_k)

        self._tool_names.append(_TOOL_NAMES["FAQ"])

        @mcp.tool(
            name=_TOOL_NAMES["EDUCACAO"],
            description="Recupera conteúdos educativos sobre orçamento, dívidas, poupança e organização financeira. "
                        "Não fornece passos de navegação do aplicativo nem consulta dados financeiros pessoais.",
        )
        async def consultar_educacao_financeira(pergunta: str, top_k: int | None = None) -> dict:
            return await self._consultar("EDUCACAO", pergunta, top_k)

        self._tool_names.append(_TOOL_NAMES["EDUCACAO"])

    async def _consultar(self, rag: str, pergunta: str, top_k: int | None) -> dict:
        started = monotonic()
        tool_name = _TOOL_NAMES[rag]
        try:
            if not isinstance(pergunta, str) or not pergunta.strip():
                raise _RAGError("entrada_invalida", "pergunta deve conter texto não vazio.")
            if top_k is not None and (type(top_k) is not int or top_k <= 0):
                raise _RAGError("entrada_invalida", "top_k deve ser um inteiro positivo ou omitido.")

            cfg = _load_config(rag)
            verify = _resolve_verify(tool_name)
            payload = {
                "action": "recuperar-contexto-indice",
                "body": {
                    "data": {
                        "input": pergunta.strip(),
                        "index_id": cfg.index_id,
                        "context": {
                            "query_type": cfg.query_type,
                            "total_context": cfg.total_context if top_k is None else top_k,
                        },
                    },
                },
            }
            headers = {
                "accept": "application/json",
                "Content-Type": "application/json",
                "X-Client-Id": cfg.client_id,
                "UOR": cfg.uor,
                "userIdentification": cfg.user_id,
            }
            # Cliente por chamada: sem cookies, headers ou pool compartilhados entre RAGs.
            async with asyncio.timeout(cfg.timeout):
                async with httpx.AsyncClient(verify=verify, timeout=cfg.timeout, follow_redirects=False) as client:
                    response = await client.post(cfg.url, json=payload, headers=headers)
                    response.raise_for_status()
                    try:
                        data = response.json()
                    except (ValueError, UnicodeError):
                        raise _RAGError("resposta_inesperada", "Resposta não contém JSON válido.") from None
                    contexts = _parse_contexts(data)
            if contexts:
                return _result(tool_name, started, "sucesso", "Contextos recuperados.", contexts)
            return _result(tool_name, started, "sem_resultados", "Nenhum contexto encontrado.")
        except _RAGError as exc:
            status, message = exc.status, exc.message
        except (httpx.TimeoutException, TimeoutError):
            status, message = "timeout", "Prazo da consulta ao RAG excedido."
        except httpx.HTTPStatusError as exc:
            code = exc.response.status_code
            if code == 401:
                status, message = "credencial_invalida", "Credencial recusada pelo GeneraBB (HTTP 401)."
            elif code == 403:
                status, message = "acesso_negado", "Acesso ao RAG negado (HTTP 403)."
            else:
                status, message = "erro_http", f"GeneraBB retornou HTTP {code}."
        except ssl.SSLError:
            status, message = "erro_tls", "Falha TLS na conexão com o RAG."
        except httpx.RequestError as exc:
            if _is_tls_error(exc):
                status, message = "erro_tls", "Falha TLS na conexão com o RAG."
            else:
                status, message = "erro_conexao", "Falha de transporte na consulta ao RAG."
        except Exception:  # Não expor texto de exceções, payloads ou credenciais.
            status, message = "erro_interno", "Falha interna ao consultar o RAG."
        return _result(tool_name, started, status, message)
