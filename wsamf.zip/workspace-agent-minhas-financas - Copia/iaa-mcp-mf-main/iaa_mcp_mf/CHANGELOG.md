# Changelog

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](http://keepachangelog.com/pt-BR/1.0.0/) e este projeto adere ao [Semantic Versioning](http://semver.org/lang/pt-BR/spec/v2.0.0.html).

## [Não liberado]

<!-- Documente suas mudanças aqui -->

## [0.1.0] - AAAA-MM-DD

### Adicionado
- Versão inicial do projeto
