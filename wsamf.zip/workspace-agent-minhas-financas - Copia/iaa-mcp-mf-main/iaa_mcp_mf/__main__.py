"""Ponto de entrada do servidor MCP."""

import argparse
import logging
import os

from dotenv import load_dotenv
from fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import PlainTextResponse

from .core.factory import MCPToolFactory
from .services.service_exemplo import ServiceExemplo
from .services.service_rag import ServiceRAG


class _HealthCheckFilter(logging.Filter):
    """Filtra logs de requisições HTTP para /health/* (health checks do K8s)."""

    _SILENT_PATTERNS = ("GET /health/live", "GET /health/ready")

    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        return not any(pattern in message for pattern in _HealthCheckFilter._SILENT_PATTERNS)


def health_check(request: Request) -> PlainTextResponse:
    """Liveness probe."""
    return PlainTextResponse("OK")


def readiness_check(request: Request) -> PlainTextResponse:
    """Readiness probe."""
    return PlainTextResponse("OK")


def create_app() -> FastMCP:
    """Cria e configura o servidor MCP. Isolado em função para facilitar testes."""
    load_dotenv(dotenv_path=".env", override=False)
    factory = MCPToolFactory()
    factory.register_service(ServiceExemplo())
    factory.register_service(ServiceRAG())
    _mcp = factory.create_mcp_server(name=os.getenv("MCP_SERVER_NAME", "BBMCPServer"))

    _mcp.custom_route("/health/live", methods=["GET"])(health_check)
    _mcp.custom_route("/health/ready", methods=["GET"])(readiness_check)

    return _mcp


def _configure_logging() -> None:
    """Configura formato e nível de log da aplicação."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    logging.getLogger("uvicorn.access").addFilter(_HealthCheckFilter())


def main():
    """Inicializa e executa o servidor MCP via streamable-http."""
    parser = argparse.ArgumentParser(description="BB MCP Server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()

    _configure_logging()

    app = create_app()
    app.run(transport="streamable-http", host=args.host, port=args.port, stateless_http=True)


if __name__ == "__main__":
    main()
