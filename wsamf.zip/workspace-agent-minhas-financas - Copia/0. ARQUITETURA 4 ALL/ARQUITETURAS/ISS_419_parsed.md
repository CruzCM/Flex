# issues/419

ADR - Proposta de Arquitetura para Sistemas Multiagentes no EMPRESA

1 - OBJETIVO

O objetivo desta ADR é prover padrões arquiteturais, boas práticas e referências para a criação, execução, governança e controle de agentes e sistemas multiagentes, no Empresa, estabelecendo padrões técnicos que permitam escalonamento seguro e eficiente.

2 - CONTEXTO

O conceito de “agentes” já é conhecido na academia, tanto na área de Inteligência Artificial quanto na Engenharia de Software. No entanto, foi com o avanço recente dos grandes modelos de IA Generativa no setor industrial — capazes de resolver problemas complexos antes restritos à atuação humana — que o tema ganhou destaque no mercado. Esse crescimento está diretamente ligado ao uso dos LLMs (Large Language Models) como mecanismo de raciocínio para agentes implementados em hardware ou software.

Desde 2016, o Empresa já utilizava modelos de Processamento de Linguagem Natural, com o lançamento de um dos primeiros chatbots em português no país. Antes mesmo do GPT surgir comercialmente, já havíamos desenvolvido o EMPRESA Bert — um modelo de linguagem treinado com o vocabulário da empresa, baseado em uma arquitetura precursora dos LLMs, e usado com sucesso na análise inteligente de atendimentos.

Com o avanço dos modelos de IA Generativa, evoluímos nossas soluções de negócio e TI por meio do módulo Genera EMPRESA, parte da Plataforma A2B2. Essa ferramenta permite o uso interno de modelos certificados e a criação de assistentes e agentes inteligentes. A prática com o Genera EMPRESA aprofundou nosso conhecimento institucional sobre IA Generativa.

Diante da rápida evolução da área, ampliamos nossa atuação com parceiros estratégicos, realizando testes e projetos em ambientes de inovação (“garagens”), focando em criação, operação e governança de agentes de IA em nuvem.

Nesse contexto, torna-se essencial definir uma arquitetura corporativa de referência, que garanta padronização, segurança, escalabilidade e integração entre ambientes locais e em nuvem. Essa arquitetura deve também permitir conexão com o ecossistema nacional e internacional de IA, alinhado ao novo paradigma da Web Agêntica.

3 - VISÃO DE NEGÓCIO

3.1 Agentes

Agentes são sistemas de hardware ou software que atuam de forma autônoma ou semiautônoma, tomando decisões e executando tarefas com base em dados recebidos e objetivos definidos. Eles processam informações do ambiente em que estão inseridos e agem para alcançar melhores resultados, usando desde regras simples até modelos avançados de IA Generativa (Adaptado de Google).

3.1.1 Autonomia

A autonomia de um agente varia conforme a necessidade de intervenção humana. Ele pode ser:

Semiautônomo: depende de aprovação humana em algum momento;

Autônomo: realiza ações sem necessidade de validação humana.

3.1.2 Inteligência

O nível de inteligência de um agente depende da sua capacidade de realizar ações com precisão. Isso pode ir de regras básicas até o uso de modelos complexos de IA.

Importante: autonomia e inteligência são características distintas — um agente muito inteligente pode ainda depender de validação humana.

Além disso, agentes podem usar ferramentas (como APIs, bancos de dados, funções definidas pelo usuário, etc.) e interagir com outros agentes. Para garantir segurança, eficiência e integração em ambientes corporativos e financeiros, é recomendável o uso de protocolos abertos e padrões bem definidos, amplamente adotados pela comunidade.

Características de um Agente de IA

Um agente de IA é composto por cinco elementos principais:

Persona: Define o comportamento do agente. É um conjunto de instruções que orienta como ele deve agir. Exemplo: “Você é um agente que resume e-mails com tom formal”.

Ações: Representa tudo que o agente pode fazer: enviar e-mails, consultar bancos de dados, executar operações, entre outros.

Memória: Guarda informações das interações. Pode ser:

Curto prazo: o que foi dito na sessão atual;

Longo prazo: histórico de conversas e dados;

Episódica: eventos específicos vivenciados;

Semântica: compreensão de termos e conceitos do negócio;

Consenso: dados compartilhados entre agentes para atingir objetivos comuns.

Ferramentas Recursos externos que o agente pode acessar, como APIs, bases de dados, operações IIB, entre outros. Uma das formas de buscar informações é o RAG (Retrieval Augmented Generation).

Modelo É o “cérebro” do agente, responsável por decidir o que fazer com base na persona, memória e ferramentas. Pode ser:

Multimodal: aceita texto, imagem, áudio, etc;

Somente texto: aceita apenas texto;

General Purpose: modelos genéricos como GPT-4o-mini;

Foundation Models: treinados com dados específicos, como modelos financeiros.

Definições de agentes na IN 1230-1.

Por que usar sistemas com múltiplos agentes?

Limitações dos LLMs: Cada modelo tem um limite de contexto (quantidade de informações que consegue processar) e número de ferramentas que pode usar com precisão. Exemplo: GPT-4o-mini aceita até 128 mil tokens; o EMPRESA recomenda de 5 a 10 ferramentas por agente.

Especialização: Agentes especializados para tarefas específicas são mais assertivos do que modelos genéricos.

Governança e segurança: Cada agente pode, num cenário mais complexo, ter regras próprias, facilitando o controle, manutenção e escalabilidade do sistema.

Escalabilidade: Para garantir que a arquitetura seja escalável, é mais eficiente criar agentes reutilizáveis em diferentes cenários, em vez de duplicá-los para cada tarefa. Com uma estrutura modular, é possível reaproveitar agentes existentes, facilitar a criação de processos mais complexos e escalar componentes de forma independente, o que reduz falhas, melhora o controle de custos e permite ajustes específicos por domínio.

FinOps: Agentes especializados podem usar modelos mais simples, economizando recursos como tokens e infraestrutura. Cada agente pode ter sua própria configuração, como memória, CPU ou GPU, conforme a criticidade da tarefa.

Autonomia de Deploy: Os times podem publicar agentes de forma independente, sem afetar o sistema como um todo. Isso permite entregas contínuas e ajustes rápidos.

Para o avanço das soluções do EMPRESA no contexto de uso de agentes e multiagentes, entendemos que a definição de uma arquitetura de referência (ADR) faz-se necessária, devendo ser baseada em padrões de mercado, permitindo flexibilidade, escalabilidade, controle e segurança.

Cada agente terá autonomia limitada, com escopo bem definido para cada tarefa ou transação. Nos casos críticos, será exigida validação humana (“human in the loop”), sempre respeitando as diretrizes de Governança e Segurança. Para garantir segurança, seguimos o princípio do mínimo privilégio: cada agente executa apenas o que lhe foi designado, dentro de seu domínio.

Por fim, é importante diferenciar Agentes Inteligentes de Assistentes Inteligentes ou Automações/Bots. Para tarefas simples e bem definidas, uma simples automação ou bot (robô) já é suficiente — não sendo necessário criar agentes ou assistentes inteligentes e autônomos.

Fonte: Adaptado de Google.

Diretrizes para Governança e Segurança em Ecossistemas de Agentes de IA

Para garantir o uso seguro e eficiente de agentes de IA no EMPRESA, é essencial que os processos e mecanismos adotados sigam princípios básicos de governança, segurança e controle. Os principais pontos são:

Princípios Fundamentais

Autonomia com limites claros, transparência nas ações e possibilidade de auditoria. Segurança e privacidade dos dados, com uso de guardrails para evitar abusos. Alinhamento com políticas de negócio e controle humano em tarefas críticas (human-in-the-loop). Monitoramento de uso, custo e desempenho, com rastreabilidade via transaction_id e user_id. Conexão restrita ao AI Gateway, apenas por aplicativos autorizados.

Avaliação e Feedback

Coleta de feedback do usuário sobre a qualidade das respostas. Avaliação automática ou humana conforme o tipo de interação.

Filtros de Conteúdo Sensível

As respostas dos agentes devem ser filtradas para evitar:

Violência ou apologia a armas e terrorismo;

Conteúdo sexual explícito;

Incentivo à automutilação ou suicídio;

Discurso de ódio ou discriminação.

Medidas de Segurança Recomendadas (baseadas na OWASP GenAI Top 10)

Princípio do menor privilégio: cada agente só acessa o que é necessário;

Validação de entradas e saídas: controle de formatos, URLs, dados sensíveis e risco;

Políticas de segurança de conteúdo (CSPs): bloqueio de scripts, controle de rede e sanitização de dados;

Guardrails para modelos de IA: Uso de moderadores de IA e testes contínuos.

Declaração e Jornada de Agentes Inteligentes nas Plataformas Habilitadoras de Tecnologia

A criação de sistemas baseados em agentes e multiagentes no EMPRESA será feita por meio de um processo orquestrado na Plataforma A2B2 (por meio de um Orquestrador EMPRESA), integrado às demais Plataformas Tecnológicas, no âmbito de suas atuações, e esteiras de fornecedores de nuvem pública e privada.

Após aprovação, o sistema baseado em agente e multiagentes será implementado on premises ou em nuvem pública — conforme as características de cada solução.

Os agentes serão disponibilizados com jornadas específicas, definidas de acordo com o tipo de problema que resolvem, seus objetivos e capacidades.

Para garantir padronização, adotamos protocolos únicos para:

Comunicação entre agentes (A2A - Agent to Agent);

Acesso a ferramentas (MCP - Model Context Protocol).

Ciclo de Vida e Implantação de Agentes no EMPRESA

A implantação de agentes no EMPRESA seguirá as esteiras de CI/CD de software já existentes, como GitHub, GitLab, Jenkins, Actions e Argo, integradas à Plataforma A2B2 e demais plataformas intervenientes.

Etapas do Processo

Experimentação: Definir objetivos, bases de dados, ferramentas, interações (system prompt) e saídas esperadas;

Validação Inicial: Verificar se já existe agente semelhante, evitar acessos indevidos e garantir conformidade com políticas internas;

Testes de Qualidade: Avaliar ações do agente em ambiente controlado, usando datasets e ajustes finos (prompt/context engineering);

Ajustes ou Aprovação: Se aprovado, segue para integração. Caso contrário, retorna à etapa de validação;

Integração Técnica: Encapsular a lógica do agente, adaptar à infraestrutura (e.g. Kubernetes, nuvem, padrões como flake8);

Otimização Operacional: Monitorar desempenho e ajustar recursos (memória, CPU) conforme necessidade;

Auditoria e Segurança: Rastrear dados de entrada, ações, consumo de recursos e revisar privilégios e vulnerabilidades;

Deploy em Produção: Após aprovação, o agente é liberado para uso corporativo.

Governança via GAIA

Todo uso de LLM ou agente deve ser catalogado no GAIA (módulo de governança de IA integrante da Plataforma A2B2), que avalia segurança, qualidade de dados e prompts antes da produção. Os modelos utilizados vêm de um catálogo específico e a aplicação passa por esteira de governança pré-produção.

Extensões e Padronização

Catálogo de agentes e ferramentas;

Templates para criação de agentes;

Protocolos padronizados para comunicação entre agentes e acesso a ferramentas.

N0 - Visão Geral

![N0 - Visão Geral](./extracted_images/iss419/word/media/image1.png)


Desenho do fluxo de criação e implementação de um Agente

![Desenho do fluxo de criação e implementação de um Agente](./extracted_images/iss419/word/media/image2.png)


Desenho do fluxo de consumo e acionamento dos Agentes

![Desenho do fluxo de consumo e acionamento dos Agentes](./extracted_images/iss419/word/media/image3.png)


4 - Arquitetura

Componentes Essenciais para Agentes

Para criar e executar agentes, alguns componentes arquiteturais são indispensáveis:

Camada de Aplicação (Interface com o Usuário): Camada que recebe a requisição (em linguagem natural, comandos etc) e a envia para a camada de orquestração.

Camada de Orquestração: Interpreta a intenção do usuário, valida políticas de segurança e governança, identifica agentes disponíveis, define o plano de execução e coordena as interações.

Camada de Sub Orquestração: Responsável por centralizar e orquestrar eventuais agentes de nicho (ex: CRM, etc.) de forma centralizada e especializada, fornecendo sempre à camada de orquestração principal os dados e insumos de monitoramento e qualidade das atividades dos agentes especializados de forma tempestiva e padronizada.

Camada de Conhecimento: Conjunto de dados e informações relevantes ao negócio que os agentes podem acessar.

Camada de Estado/Contexto: Guarda histórico de interações, estado do agente (i.e., "pronto", "executando") e dados específicos.

Camada de Ferramentas: Acesso a funções, APIs e recursos que o agente pode utilizar.

Agentes: Os sistemas que executam as tarefas planejadas.

Governança, Segurança e Monitoramento/Qualidade (a nível de software e IA - Evaluation) devem estar presentes em todas as camadas, seguindo as diretrizes definidas pelo EMPRESA.

N0 - Arquitetura Geral Lógica

![N0 - Arquitetura Geral Lógica](./extracted_images/iss419/word/media/image4.png)


Arquitetura de Referência Adaptada da Microsoft para Multiagentes no EMPRESA, com a inclusão/destaque para as camadas de segurança e governança (de TI e IA), bem como de uma futura camada de sub orquestração para integração com agentes/orquestradores de nicho que devidamente atendam aos padrões multiagentes do EMPRESA.

N1 - Arquitetura Geral Em Componentes

![N1 - Arquitetura Geral Em Componentes](./extracted_images/iss419/word/media/image5.png)


Na arquitetura proposta, toda comunicação passa por um "AI Gateway", que, inclusive, aplica regras e políticas definidas pela Segurança.

Esse modelo garante controle e moderação do conteúdo trocado, além de maior segurança no acionamento de agentes em nuvens públicas ou privadas.

Em conjunto com o "AI Gateway", um componente denominado "Orquestrador EMPRESA" fará a orquestração, controle de comunicação, monitoração e qualidade dos acionamentos, a nível de IA. Tal componente será responsável por conhecer e acionar os agentes, coordenar suas interações e garantir conformidade com as diretrizes corporativas de IA.

N2 - Arquitetura Em Camadas

![N2 - Arquitetura Em Camadas](./extracted_images/iss419/word/media/image6.png)


Detalhamento do Componente "Orquestrador EMPRESA"

![Detalhamento do Componente "Orquestrador EMPRESA"](./extracted_images/iss419/word/media/image7.png)


Em tempo e a pedido de fóruns executivos, sentimos a necessidade de clarificar/explicitar alguns pontos elencados acima (sem alterar qualquer conteúdo ou discussão realizada, apenas como complemento e para fins de maior elucidação e didática). São eles:

1. Diferenciação entre Automações, Assistentes e Agentes Inteligentes no EMPRESA (seguindo IN 1230-1):

Automação/Robôs(Bots) – Softwares que executam ações simples, bem definidas e previamente mapeadas/explicitadas por seus criadores, de forma pré-definida e determinística, muito com o intuito de acelerar a execução de tarefas e processos;

Assistentes Inteligentes – Softwares que interagem (geralmente em linguagem natural) no intuito de fornecer informações e apoiar as decisões/ações do usuário (eles não decidem nem agem por si só, apenas dão subsídios ou sugerem ações possíveis). Apesar de também serem construídos de forma bem definida (com prompts formalmente declarados para sua atividade fim, por exemplo) e com funcionalidades previamente mapeadas/explícitas por seus criadores, suas respostas podem ser não determinísticas, podendo variar de acordo com o modelo de IA e configurações usadas, bem como de acordo com a forma da pergunta do usuário. Atuam basicamente apoiando atividades corriqueiras como tirando dúvidas, gerando conteúdo básico (textos, imagens, etc.), analisando documentos e artefatos de posse do usuário, dentre outros;

Agentes Inteligentes – Softwares que tomam decisões e executam ações (das mais simples às mais complexas e críticas) em nome do usuário. Tais ações não necessariamente precisam estar bem definidas e mapeadas/explicitadas de início (o agente interpreta o pedido/necessidade – muitas vezes em linguagem natural - decide o que tem de ser feito e executa). A própria execução da tarefa solicitada pode ser não determinística, isto é, o agente (ou sistemas com múltiplos agentes) decide como atuar de formas diferentes dependendo do contexto e forma da requisição do usuário.Agentes inteligentes atuam consumindo ferramentas, bases de dados, acionando transações, dentro outros. Vale lembrar que os agentes inteligentes podem ser autônomos ou semiautônomos. Agentes inteligentes autônomos decidem e agem de forma completamente independente, enquanto os agentes semiautônomos requerem algum grau de validação ou supervisão humana para a tomada de decisão ou execução de ações. Em geral, tarefas críticas nunca devem ser delegadas para um agente completamente autônomo, isto é, deve sempre haver um ser humano no topo da decisão ou aprovando a ação do agente antes de sua realização, seguindo o conceito human-in-the-loop, amplamente difundido na esfera da Inteligência Artificial.

OBS: Conceitos já trazidos nas seções 2 e 3 desta issue e aqui apenas sumarizados/clarificados.

2. Definição Complementar - Identidade dos Agentes Inteligentes na empresa:

Conceitualmente, como já trazido anteriormente, agentes inteligentes são entidades de software ou hardware que recebem sinais de entrada, processam-nos usando algum mecanismo lógico/de inteligência, e atuam em seu meio, seja físico ou virtual.

Apesar de serem sistemas/aplicações por natureza, por poderem apresentar comportamento não determinístico, como dito, ou atuar em nome de outrem em alguns casos, dependendo de seu escopo e atribuições, para questões de governança e segurança, o ciclo de vida e gestão da identidade dos agentes inteligentes merecem trato não só enquanto aplicações, mas também trazendo conceitos e mecanismos do gerenciamento de identidade de pessoas/usuários.

Deste modo, faz-se necessário um novo paradigma de identidade – uma identidade híbrida entre aplicações e pessoas/usuários.

Premissas básicas na gestão desta nova identidade:

Agentes são software – Há necessidade de identificação e de mecanismos de autorização para o agente, como para qualquer outro software (seguindo os mesmos padrões de software);

Escopo e autonomia limitada – Em casos de delegação ou pedido de execução de tarefas por uma pessoa/usuário, ou mesmo por outros softwares ou agentes, o agente fim deve ter identificador diferente do requerente, com rastreio de vínculo e de chamada, e apresentar escopo restrito, no máximo, aos recursos e tarefas que o ente acionador pode acessar ou realizar. OBS: Todos os acionamentos devem estar registrados para fins de controle, auditoria e qualidade.

Necessidade de tratamento pessoal – Embora sejam software, é recomendável gerenciá-los, complementarmente, usando protocolos empresariais tipicamente projetados para pessoas/usuários, contemplando:

a) Onboarding/Offboarding: Agentes exigem processos formais para criação e "desprovisionamento" (assim como funcionários fazem ao ingressar ou deixar uma empresa);

b) Entidades de Primeira Classe: Organizações devem provisionar serviços corporativos aos agentes "assim como fornecem aos funcionários humanos", com seus próprios atributos, proprietários e membros de grupos, respeitando sempre o item 2 (escopo e autonomia limitada).

Em suma:

O agente deve ser visto como um aplicativo que possui uma identidade delegada;

Tecnicamente é considerado uma carga de trabalho de software;

Administrativamente deve ser tratado como uma entidade de primeira classe (semelhante a uma pessoa/funcionário humano) que requer governança de ciclo de vida;

Funcionalmente é um ente delegado que atua em nome de uma pessoa (ou mesmo sistema/outro agente), mas claramente distinto dela.

OBS: Definições alinhadas ao trazido na seção 3 desta issue.

3. Atualização do Desenho N2 (Arquitetura em Camadas):

A pedido e apenas para clarificar o desenho, movemos o componente Grafeno para a camada de Integração, Segurança e Orquestração de IA no desenho N2 (nada mais foi alterado no desenho/texto).

Segue a versão final:

![Segue a versão final:](./extracted_images/iss419/word/media/image8.png)
