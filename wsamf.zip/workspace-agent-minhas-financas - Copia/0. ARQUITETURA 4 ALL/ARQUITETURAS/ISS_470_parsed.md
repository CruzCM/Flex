issues/470

ADR — Modernização do Assistente Conversacional EMPRESA (AEMPRESA)

[NOVO] Legenda de marcações editoriais:

trechos destacados (exibição varia conforme engine Markdown/Navegador) indicam conteúdo introduzido ou ajustado em revisões posteriores à versão inicial desta ADR.

Os rótulos utilizados nesses trechos têm o seguinte significado:

O rótulo "[NOVO]" identifica conteúdo inteiramente novo, inexistente na versão anterior;

O rótulo [ALTERAÇÃO] identifica conteúdo já existente na versão anterior que foi modificado (reescrito, expandido ou reorganizado) na versão atual.

Trechos sem destaque e sem rótulo correspondem ao conteúdo original mantido sem alteração.

[NOVO] Versão: V1 - 14/05/2026

[NOVO] Versão inicial: a arquitetura alvo (TO-BE) de modernização do Assistente Conversacional EMPRESA (AEMPRESA), mantendo o núcleo do AEMPRESA (orquestração de interações, de integrações de execução de transações) como no modelo atual (AS-IS) sob responsabilidade do EMPRESA, e substituindo o componente do fornecedor baseado em NLP (IBM Watson Assistant) por componente baseado em orquestração de agentes de IA (IBM watsonx Orchestrate).

[NOVO] Versão: v2 — 01/06/2026

[NOVO] Ajustes incorporados nesta versão (v2): revisão realizada em atendimento às colocações dos especialistas. Principais eixos de ajuste: (1) observabilidade alinhada ao padrão corporativo Stack O11y / OpenTelemetry, com unificação de trace ID ponta a ponta e exportação para a PlatMoob (R07); (2) guardrails expandidos com controles concretos, plano de resposta a incidentes e evaluation pipeline contínuo (R01–R05); (3) reforço da estratégia de desacoplamento e portabilidade de fornecedor (R08); (4) posicionamento da arquitetura como agente de canal no caminho evolutivo para multiagentes por domínio (R09, R10); (5) critérios operacionais de avanço e rollback adicionados à Lista 7; (6) tabela de riscos da arquitetura alvo (TO-BE) incorporada na seção Arquitetura Alvo em fidelidade à referência consolidada, com coluna Motivador vinculando cada risco aos motivadores M1–M6, descrição contextualizada e mitigações detalhadas (defesa em camadas, esteira GAIA, Red-Team EMPRESA DE SEGURANÇA, certificação empresa analitica, Granite Guardian, padrões abertos MCP/A2A/Agent Connect e modelo federado com RACI); (7) novas decisões arquiteturais incluídas na Tabela 9 (estratégia de saída de fornecedor e localização de bases RAG).

Índice de elementos

Tabelas

Tabela 1 – Perímetro de sistemas

Tabela 2 – N0 - Visão de Negócio Atual

Tabela 3 – N2 - Arquitetura em Camadas Atual

[NOVO] Tabela 4 – Riscos e mitigações da arquitetura alvo (TO-BE)

Tabela 5 – N0 - Visão de Negócio Alvo

Tabela 6 – N2 - Arquitetura em Camadas Alvo

Tabela 7 – Governança de artefatos - RACI

Tabela 8 – Controle de acesso e execução de gatilhos

Tabela 9 – Decisões arquiteturais consolidadas

Diagramas

Diagrama 1 - N0 - Visão de Negócio Atual



Diagrama 2 - N2 - Arquitetura em Camadas Atual



Diagrama 3 - N3 - Fluxo de Execução Transacional Atual



Diagrama 4 - N0 - Visão de Negócio Alvo



Diagrama 5 - N2 - Arquitetura em Camadas Alvo



Diagrama 6 - N3 - Fluxo de Execução Transacional Alvo



Listas

Lista 1 – Análise comparativa de modelos

Lista 2 – Riscos e limitações da solução atual

Lista 3 – Modelo de confiança - controles da fronteira EMPRESA fornecedor

Lista 4 – Política de minimização de dados no retorno ao fornecedor

Lista 5 – Cadeia de observabilidade e auditoria por camada

Lista 6 – Estratégia de modernização

Lista 7 – Indicadores para acompanhamento da modernização

Objetivo

Submeter à aprovação a arquitetura alvo (TO-BE) de modernização do Assistente Conversacional EMPRESA (AEMPRESA), mantendo o núcleo do AEMPRESA (orquestração de interações, de integrações de execução de transações) como no modelo atual (AS-IS) sob responsabilidade do EMPRESA, e substituindo o componente do fornecedor baseado em NLP (IBM Watson Assistant) por componente baseado em orquestração de agentes de IA (IBM watsonx Orchestrate).

Ponto central desta ADR: o fornecedor não executa diretamente ou obtém detalhes de APIs transacionais (Grafeno e Operação IIB) nem dados sensíveis (senha/token transacional); e a aplicação EMPRESA mantém o controle da execução de transações, como no modelo atual.

Tabela 1 - Perímetro de sistemas


[TABELA]

Papel | Sistemas

Assistente Conversacional EMPRESA (AEMPRESA) (alvo da ADR) | NEC (Orquestração de interações, integrações e execução de transações)

Negócios em Inteligência Artificial (alvo da ADR) | NIA (Integração com serviços de Inteligência Artificial)

Integração de rede EMPRESA<->IBM do EMPRESA | Satelite (gateway de borda do EMPRESA para controle de endpoints entre IBM watsonx Orchestrate e NIA, via link privado)

Serviço de Inteligência Conversacional (dependência externa ao EMPRESA) | IBM Watson Assistant atual (AS-IS), IBM watsonx Orchestrate alvo (TO-BE)

Transacional EMPRESA | Serviços Grafeno (ex. cfe-empresar, cfe-pgr), Operações IIB

Canais Digitais | Interfaces de canais (ex. App EMPRESA e WhatsApp)

Usuários | Usuários finais (clientes EMPRESA, PF e PJ)

[/TABELA]


Contexto e Motivadores

A solução atual é baseada em NLP com fluxos conversacionais determinísticos e construção de corpus manual (IBM Watson Assistant). A modernização substitui esse componente por um modelo de orquestração por agentes de IA (IBM watsonx Orchestrate), mantendo integralmente o controle de execução transacional no EMPRESA (NEC e NIA).

O modelo atual apresenta limitações estruturais que se agravam com o crescimento do assistente: o conhecimento está acoplado a fluxos determinísticos de difícil manutenção, a escalabilidade de novos domínios exige reorganização global, e a governança é opaca, com baixa visibilidade sobre falhas e lacunas. O modelo novo, baseado em LLM e orquestração por agentes, separa conhecimento de fluxo, reduz o custo marginal de evolução, permite conversação adaptativa e oferece governança por camadas com observabilidade semântica. Além disso, reduz o risco de lock-in tecnológico e cria base para multicanal e personalização avançada.

A análise comparativa a seguir detalha os motivadores técnicos e estratégicos em seis dimensões.

Lista 1 - Análise comparativa de modelos

M1 — Modelo de conhecimento e escalabilidade funcional

Modelo atual (NLP):

Conhecimento implementado como fluxos conversacionais acoplados.

Criação manual e pouco automatizada de corpus.

Tendência à construção de corpus monolítico, pela dificuldade de orquestrar domínios independentes.

Inclusão de novos domínios exige reorganização do diálogo existente.

Baixa reutilização de conhecimento entre jornadas.

Modelo novo (LLM/agentes):

Conhecimento tratado como ativo reutilizável, separado do fluxo.

Inclusão de novos temas por adição de fontes ou ferramentas, sem reestruturação global.

Escalabilidade funcional incremental e controlada.

M2 — Flexibilidade conversacional e aderência ao comportamento do usuário

Modelo atual (NLP):

Jornadas essencialmente determinísticas.

Dificuldade em lidar com: perguntas compostas, mudanças de assunto, exceções e ambiguidades.

Experiência percebida como mecânica.

Modelo novo (LLM/agentes):

Conversação contextual e adaptativa, orientada a objetivos.

Melhor tratamento de cenários ambíguos, incompletos ou fora do script.

Atendimento mais eficaz em interações longas e multifásicas.

Redução de transbordos desnecessários para humanos.

M3 — Custo de evolução e manutenção

Modelo atual (NLP):

Crescimento de custo não linear à medida que o assistente evolui.

Alto esforço para: criar novas intenções semelhantes, manter exemplos de treinamento, ajustar regras e prioridades.

Deploys com impacto elevado e risco de regressão.

Manutenção onerosa com múltiplas jornadas sobrepostas.

Modelo novo (LLM/agentes):

Menor custo marginal para novos casos de uso.

Redução drástica na criação de intenções redundantes.

Atualização de conteúdo sem retreinamento explícito.

Aceleração da experimentação e entrega de valor.

M4 — Governança, controle e observabilidade

Modelo atual (NLP):

Governança centrada em intenções e fluxos.

Baixa visibilidade sobre: objetivos efetivamente atendidos, lacunas de automação, causas de falha semântica.

Governança complexa em cenários com múltiplas jornadas e equipes.

Modelo novo (LLM/agentes):

Governança por camadas bem definidas: linguagem, raciocínio, regras, execução.

Observabilidade semântica orientada a objetivos.

Identificação clara de lacunas de conhecimento e automação.

Evolução mais segura, auditável e previsível.

M5 — Dependência de fornecedor e sustentabilidade tecnológica

Modelo atual (NLP):

Forte vendor lock-in: DSL proprietária, modelos internos de diálogo, baixo suporte a padrões abertos.

Alto custo e atrito na migração entre plataformas.

Risco elevado de obsolescência funcional.

Modelo novo (LLM/agentes):

Maior adesão a padrões abertos e arquiteturas desacopladas.

Possibilidade real de intercambiar: modelos, fornecedores, ferramentas.

[NOVO] Pontos concretos de desacoplamento previstos na arquitetura, com separação de responsabilidades claras por componentes.

[NOVO] Escolha de solução (IBM watsonx Orchestrate) que permite troca de modelo LLM; e provê conectividade com ecossistemas externos via padrões abertos, como MCP, A2A, Agent Connect/Chat Completions API.

Ecossistema mais ativo e competitivo.

Menor risco estratégico de longo prazo.

M6 — Preparação para o futuro dos canais digitais

Modelo atual (NLP):

Evolução limitada para: multicanal real, multimodalidade, personalização contextual avançada.

Assistente tratado como produto isolado.

Modelo novo (LLM/agentes):

Fundamento adequado para multicanal, multimodal e personalização.

Integração natural com novos tipos de dados e interações.

Assistente evolui de projeto para plataforma estratégica.

Arquitetura Atual

A descrição da arquitetura atual tem como objetivo estabelecer o ponto de partida da modernização: delimitar o que será preservado, o que será substituído e quais controles e responsabilidades já existem no domínio EMPRESA. Esse baseline é essencial para validar que a arquitetura alvo mantém as garantias de segurança e controle transacional já presentes hoje.

N0 — Visão de Negócio Atual

O cliente interage via App EMPRESA/Mov ou WhatsApp. Os canais encaminham as mensagens ao Assistente Conversacional EMPRESA (AEMPRESA), que orquestra o diálogo e mantém o controle da execução transacional no domínio EMPRESA. O AEMPRESA aciona o IBM Watson Assistant (NLP) para reconhecimento de intenção e composição de respostas, e executa transações negociais diretamente nos sistemas internos (Grafeno/IIB). Em caso de necessidade, o atendimento é transbordado para um agente humano via FaleCom.

Tabela 2 - N0 - Visão de Negócio Atual


[TABELA]

Componente | Responsabilidade

Usuário — Cliente EMPRESA (PF e PJ) | Interage com o assistente para consultar informações e iniciar jornadas conversacionais e transacionais.

Canais Digitais — App EMPRESA/Mov e WhatsApp | Interface de entrada/saída das mensagens do usuário. Encaminham solicitações ao AEMPRESA e exibem as respostas retornadas.

Assistente Conversacional EMPRESA (AEMPRESA) — Orquestração Conversacional e Transacional | Solução de atendimento conversacional do EMPRESA. Orquestra o diálogo ponta a ponta, integra com os canais de atendimento e mantém o controle da execução transacional no domínio EMPRESA.

Transbordo para Atendimento Humano (FaleCom) – Encaminha o cliente para troca de mensagens com um atendente humano | Solução para atendimento humano, usado em caso de falha, de preferência do cliente, de dificuldade do cliente ou de fluxo ainda não disponibilizado no canal.

Transações Negociais (diversas siglas/sistemas) – Sistemas de negócio do EMPRESA | São diversas soluções do EMPRESA acessadas para prover produtos e serviços ao cliente.

Serviço de Inteligência Conversacional — IBM Watson Assistant | Serviço de inteligência e orquestração conversacional externo ao EMPRESA, sem acesso direto a endpoints transacionais, acionado pelo AEMPRESA.

[/TABELA]


Diagrama 1 - N0 - Visão de Negócio Atual

![Diagrama 1 - N0 - Visão de Negócio Atual](./extracted_images/iss470/word/media/image1.png)


Fluxo 1 – Entrada, cliente envia mensagem:

[USUÁRIO] Cliente EMPRESA -> [CANAIS] App EMPRESA/Mov ou WhatsApp

[CANAIS] App EMPRESA/Mov ou WhatsApp -> [AEMPRESA] Assistente Conversacional EMPRESA

Fluxo 2 – Transbordo para atendimento humano:

[AEMPRESA] Assistente Conversacional EMPRESA -> [TRANSBORDO] Atendimento Humano

Fluxo 3 – Jornada informacional:

[AEMPRESA] Assistente Conversacional EMPRESA -> [ATENDIMENTO] Informacional

[ATENDIMENTO] Informacional -> [FORNECEDOR] IBM Watson Assistant

[FORNECEDOR] IBM Watson Assistant -> [ATENDIMENTO] Informacional

[ATENDIMENTO] Informacional -> [AEMPRESA] Assistente Conversacional EMPRESA

Segue para o fluxo 5.

Fluxo 4 – Jornada transacional:

[AEMPRESA] Assistente Conversacional EMPRESA -> [ATENDIMENTO] Transacional

[ATENDIMENTO] Transacional -> [NEGOCIO] Transações Negociais

[ATENDIMENTO] Transacional -> [FORNECEDOR] IBM Watson Assistant

[FORNECEDOR] IBM Watson Assistant -> [ATENDIMENTO] Transacional

[ATENDIMENTO] Transacional -> [AEMPRESA] Assistente Conversacional EMPRESA

Segue para o fluxo 5.

Fluxo 5 – Retorno de mensagem para o cliente:

[AEMPRESA] Assistente Conversacional EMPRESA -> [CANAIS] App EMPRESA/Mov ou WhatsApp

[CANAIS] App EMPRESA/Mov ou WhatsApp -> [USUÁRIO] Cliente EMPRESA

N2 — Visão Geral da Arquitetura em Camadas Atual

A visão em camadas expõe a decomposição interna do AEMPRESA em sistemas e componentes (NEC, NIA, Satelite, Grafeno), os contratos de integração entre eles e a fronteira explícita entre domínio EMPRESA e fornecedor — evidenciando onde residem os controles de autenticação, autorização e execução transacional.

Tabela 3 - N2 - Arquitetura em Camadas Atual


[TABELA]

Componente | Responsabilidade

App EMPRESA (MOV) — Canal interno mobile | Interface de entrada/saída do assistente no canal App EMPRESA/Mov; captura mensagens do usuário e exibe respostas do assistente.

WhatsApp EMPRESA (NEC) — Canal externo WhatsApp | Capturar mensagens do usuário via WhatsApp (Meta Cloud API) e encaminhar ao backend do assistente; exibir respostas no canal externo.

Satelite (EMPRESA) — Gateway de borda de rede EMPRESA↔IBM | Controlar os endpoints de rede autorizados entre EMPRESA e IBM watsonx Orchestrate via link privado (whitelist de endpoints).

cfe-nec (NEC / Grafeno) — Serviço de borda do canal App EMPRESA | Manter as conexões com os dispositivos e normalizar mensagens recebidas do canal App EMPRESA/Mov; ponto de entrada do canal interno no domínio NEC, implantado sobre o Grafeno.

adapter-app (NEC) — Adapter do canal App | Receber mensagens do cfe-nec e roteá-las ao orquestrador conversacional (bot-cc); capturar a identidade do cliente no canal.

bot-cc (NEC) — Orquestrador Conversacional (Conversation Core) | Orquestrar o fluxo de diálogo ponta a ponta: acionar o assistente cognitivo (ac), detectar gatilhos de transação na resposta e coordenar a execução transacional.

Liberação de Dispositivo (ATO) | Realizar e controlar a liberação de dispositivos do cliente; sistema interveniente no fluxo de identificação e autenticação.

ac (NEC) — Gateway para os serviços conversacionais | Receber mensagens do bot-cc, encaminhar à fachada-nlp para reconhecimento de intenção pelo Watson, gerenciar contexto e retornar resposta (incluindo sinais de gatilho de transação).

fachada-nlp (NIA) — Fachada de integração com NLP/LLM | Intermediar chamadas entre ac e o serviço IBM Watson Assistant; encapsular o contrato de integração com o fornecedor de IA.

runtime (NIA) — Orquestrador de acesso aos serviços de IA de fornecedores | Mantém os contratos e as credenciais de acesso ao serviço de conversação do fornecedor.

IBM Watson Assistant — Serviço de inteligência conversacional (fornecedor) | Processar linguagem natural, identificar intenção e compor resposta conversacional no ambiente do fornecedor; sem acesso direto a endpoints transacionais do EMPRESA.

Grafenos de Negócio (diversas siglas) — Camada de execução de transações negociais para Canais Digitais de Atendimento | Executar operações transacionais acionadas pelo NEC, aplicando autenticação/autorização (token) e controles de acesso; camada negocial por cliente/canal; observabilidade via AppDynamics.

Operações de Negócio (diversas siglas) | Fornecer os produtos e serviços bancários aos clientes do EMPRESA.

[/TABELA]


Diagrama 2 - N2 - Arquitetura em Camadas Atual

![Diagrama 2 - N2 - Arquitetura em Camadas Atual](./extracted_images/iss470/word/media/image2.png)


N3 — Fluxo de execução transacional (gatilhos) atual

A visão N3 descreve a dimensão temporal do fluxo de execução em três sub-fluxos sequenciais: envio de mensagem, execução de gatilho transacional no domínio EMPRESA e retorno de resposta ao canal — evidenciando os pontos de controle, os limites de responsabilidade entre domínio EMPRESA e fornecedor, e onde autenticação, autorização e execução transacional são realizadas.

Diagrama 3 - N3 - Fluxo de Execução Transacional Atual

![Diagrama 3 - N3 - Fluxo de Execução Transacional Atual](./extracted_images/iss470/word/media/image3.png)


N3.1 — Fluxo de envio de mensagem pelo cliente

Canal ↔ Gateway/Adapter de canal (NEC)

Gateway/Adapter de canal (NEC) ↔ Orquestrador de Integração Conversacional (bot-cc / NEC)

Orquestrador de Integração Conversacional (bot-cc / NEC) ↔ NIA Gateway IA (fachada-nlp / NIA)

NIA Gateway IA (fachada-nlp / NIA) ↔ IBM Watson Assistant (NLU/NLP) — processamento de linguagem natural e orquestração de diálogo

IBM Watson Assistant (NLU/NLP) ↔ NIA Gateway IA (fachada-nlp / NIA) — intenção identificada / resposta selecionada

N3.2 — Fluxo de execução transacional (gatilhos)

Aplica-se quando o passo 5 do N3.1 resulta em intenção de execução de gatilho.

O fluxo conversacional apenas sinaliza a intenção/necessidade de acionar um gatilho.

A decisão de permissão e o controle são realizados no Orquestrador de Execução Transacional (NEC): apenas gatilhos explicitamente mapeados podem ser executados.

A execução de endpoints transacionais ocorre exclusivamente no domínio EMPRESA:

Orquestrador de Execução Transacional (NEC) — realiza a chamada aos endpoints Grafeno, controlando a sessão do cliente e o token;

Grafeno — aplica autenticação/autorização (token), controles próprios e executa as operações negociais;

Operação IIB — executa regras negociais e de autorização (limites, restrições por cliente e canal).

O resultado retorna ao Orquestrador de Execução Transacional (NEC).

O Orquestrador de Execução Transacional (NEC) sinaliza o resultado ao NIA Gateway IA (fachada-nlp / NIA) para continuidade do diálogo.

O NIA Gateway IA (fachada-nlp / NIA) encaminha o resultado ao IBM Watson Assistant para continuidade do diálogo.

O IBM Watson Assistant processa o resultado e retorna a resposta ao NIA Gateway IA (fachada-nlp / NIA).

Segue o passo 1 do N3.3 para continuidade do diálogo.

N3.3 — Fluxo retorno de mensagem para o cliente

NIA Gateway IA (fachada-nlp / NIA) ↔ Orquestrador de Integração Conversacional (bot-cc / NEC)

Orquestrador de Integração Conversacional (bot-cc / NEC) ↔ Gateway/Adapter de canal (NEC)

Gateway/Adapter de canal (NEC) ↔ Canal

Riscos e limitações da solução atual

Os itens abaixo derivam da análise comparativa em Contexto e Motivadores.

Lista 2 - Riscos e limitações da solução atual

(M1) Escalabilidade de conhecimento: corpus monolítico com baixa reutilização entre jornadas; inclusão de novos domínios exige reorganização global do diálogo.

(M2) Rigidez conversacional: jornadas determinísticas com alta taxa de transbordo para humanos em cenários ambíguos ou fora do script.

(M3) Custo de manutenção crescente: evolução com custo não linear; deploys de alto risco por acoplamento de intenções e fluxos.

(M4) Observabilidade limitada: baixa visibilidade sobre objetivos atendidos, lacunas de automação e causas de falha semântica.

(M5) Lock-in tecnológico: DSL proprietária e baixo suporte a padrões abertos aumentam custo e atrito de migração; risco de obsolescência funcional.

(M6) Evolução de canais bloqueada: limitações estruturais para multicanal real, multimodalidade e personalização contextual avançada.

Considerações da solução atual

A solução atual foi construída sobre um modelo NLP determinístico que acopla fortemente jornada conversacional, conhecimento, canal e execução transacional em um único fluxo monolítico. Esse acoplamento gera custos em cascata: adicionar um novo canal, atualizar o conhecimento ou introduzir uma nova jornada transacional exige reorganização global da estrutura conversacional. A dependência da DSL proprietária do fornecedor amplifica essa fragilidade — qualquer evolução de comportamento ou conhecimento impõe retreinamento explícito e alto risco de regressão. Ao mesmo tempo, a rigidez determinística limita a capacidade expressiva do assistente: lacunas, ambiguidades e desvios de jornada resultam em transbordo ou falha de atendimento, ao invés de resolução adaptativa.

O modelo atual tornou-se estruturalmente insuficiente para o mercado atual. A decisão de modernizar é a resposta a um limite atingido: o custo de manutenção crescente, a agilidade insuficiente para construção de novas jornadas e a perda progressiva de competitividade configuram um ponto de inflexão claro. A modernização preserva o núcleo EMPRESA (NEC/NIA, orquestração e controle transacional) e substitui apenas o componente de IA do fornecedor — uma mudança calculada e delimitada.

Arquitetura Alvo

A arquitetura alvo preserva o núcleo do Assistente Conversacional EMPRESA (AEMPRESA) — NEC e NIA, com orquestração e controle transacional sob responsabilidade do EMPRESA — e substitui o componente de IA do fornecedor por orquestração de agentes de IA (IBM watsonx Orchestrate).

A modernização é orientada por quatro princípios:

Separação de responsabilidades (IA sugere; EMPRESA decide e executa);

Mínimo privilégio com toolset explícito e auditável por agente;

Superfície mínima de integração com o fornecedor, sem exposição de endpoints internos nem trânsito de credenciais transacionais;

E contratos de gatilhos formais e versionados como fronteira entre os domínios.

Dois novos componentes intermediários são introduzidos no domínio EMPRESA: o NIA Tool Handler, único ponto de entrada de gatilhos, responsável por validar o catálogo, restringir campos e sanitizar payloads; e o Satelite, gateway de borda com whitelist de endpoints de rede entre EMPRESA e IBM.

Essa arquitetura tem como referência conceitual a ADR - Proposta de Arquitetura para Sistemas Multiagentes no EMPRESA e considera futura evolução para a plataforma corporativa de IA.

[NOVO] Cadeia de rastreabilidade — Motivadores -> Riscos -> Decisões. A arquitetura alvo é sustentada por uma cadeia explícita: os motivadores estruturais M1–M6 (Lista 1) fundamentam a identificação dos riscos R01–R11 (Tabela 4 a seguir), que por sua vez orientam as decisões arquiteturais consolidadas na Tabela 9 (coluna Riscos endereçados) e os controles operacionais descritos em Modelo de confiança, Guardrails, Auditoria e Indicadores.

Tabela 4 - Riscos e mitigações da arquitetura alvo (TO-BE)

[NOVO] A tabela a seguir consolida os riscos identificados para a arquitetura alvo, vinculando-os aos motivadores estruturais (M1–M6) descritos em Lista 1 – Análise comparativa de modelos e detalhando, para cada risco, a descrição contextualizada e a disposição/mitigação prevista, com defesa em camadas envolvendo NIA Tool Handler, NEC Transaction Executor, agentes e bases segregadas, guardrails (Granite Guardian e nos próprios agentes), esteira GAIA, Red-Team EMPRESA DE SEGURANÇA, certificação do modelo LLM pela empresa analitica, padrões abertos (MCP, A2A, Agent Connect/Chat Completions API) e exportação de telemetria em OpenTelemetry para a PlatMoob. Os códigos de risco (R01–R11) são referenciados nas decisões e controles desta ADR.


[TABELA]

# | Risco / Incerteza | Motivador | Descrição | Disposição / Mitigação

R01 | Injeção de prompt (prompt injection) | M4 | Entrada manipulada pode induzir o agente a ignorar políticas, solicitar gatilhos indevidos ou tentar expor o contexto. | Defesa em camadas: Lista de gatilhos (toolset) estática por agente (whitelist), mesmo com injeção apenas gatilhos já mapeados e autorizados podem ser executados pelo agente; NIA Tool Handler registra, valida e sanitiza o payload antes de qualquer execução; NEC Transaction Executor mantém controle independente do estado do LLM, correlacionando as sessões conversacional e transacional do cliente, impedindo execução cruzada da sessão de um cliente em outra; Minimização de contexto sensível, com a ausência de tokens e credenciais no contexto do fornecedor, limitando o impacto em caso de manipulação ou exposição de dados; Definições de guardrails no Granite Guardian, recurso especializado em bloquear tentativas de manipulação do IBM watsonx Orchestrate; Guardrails de comportamento definidos em cada agente; Todos os agentes também passam pela esteira GAIA, para obter parecer da empresa analítica, empresa de risco, empresa  de segunça, empresa empresa dicoi e pelo Red-Team da empresa segurança para validação e verificação de vulnerabilidades; Certificação do modelo LLM para uso corporativo pela EMPRESA ANALITICA.

R02 | Alucinação, geração de conteúdo com vieses ou indevido | M1, M2, M4 | Modelos generativos podem produzir respostas factualmente incorretas (alucinações), enviesadas, com conteúdo ofensivo/inadequado ou incompatíveis com as políticas institucionais, mesmo com barreiras de proteção (guardrails), sendo reconhecido que 0% de ocorrência é improvável. | Segregação de agentes e de bases de conhecimento por domínios específicos, o que restringe o escopo de respostas e reduz alucinações; Guardrails de conteúdo, políticas de resposta por domínio; Rota de fuga (fallback) para menu do App EMPRESA, transbordo para atendimento humano e resposta neutra; E também segue os mecanismos de mitigação apontados em R01, com destaque ao uso da esteira GAIA, Red-Team da EMPRESA DE SEGURANÇA e certificação do modelo LLM pela EMPRESA ANALITICA.

R03 | Uso indevido de gatilhos (tools) | M1, M4 | O agente pode solicitar gatilho inadequado para a intenção do usuário ou com parâmetros indevidos. | Segue os mecanismos de mitigação apontados em R02, com destaque a: Segregação de agentes e de bases de conhecimento por domínios específicos; Lista de gatilhos (toolset) estática por agente (whitelist); NIA Tool Handler registra, valida e sanitiza o payload antes de qualquer execução; NEC Transaction Executor mantém controle independente do estado do LLM; Auditoria com correlação de ponta-a-ponta; e Minimização de contexto sensível.

R04 | Execução de gatilhos fora de estado | M2, M4 | Gatilho autorizado pode ser chamado em momento inválido da jornada (pré-condição não atendida). | Segue os mecanismos de mitigação apontados em R02, com destaque a: Segregação de agentes e de bases de conhecimento por domínios específicos; Lista de gatilhos (toolset) estática por agente (whitelist); NIA Tool Handler registra, valida e sanitiza o payload antes de qualquer execução; NEC Transaction Executor mantém controle independente do estado do LLM.

R05 | Contaminação de RAG | M4, M6 | Bases podem receber conteúdo incorreto, desatualizado ou malicioso, degradando qualidade e segurança das respostas. | Bases de conhecimento são segregadas por domínios específicos; Metadados que permitem filtragem e identificação de data de atualização, vigência, produto, modalidade, público e fonte de informação primária; Esteira de validação de conteúdos de bases de conhecimento, com fluxos de revisão, aprovação e publicação, para uso dos gestores de produtos e serviços em andamento; Métricas de avaliação das bases de conhecimento, como pontuação para tom de voz, conteúdo e formatação; Métricas de qualidade do modelo (groundness, faithfulness, precision, recall, context relevance) via IBM Governance. Em andamento exportação das métricas do ecossistema da IBM para base corporativa.

R06 | Retenção de dados no ambiente do fornecedor | M4, M5 | A retenção de dados no fornecedor aumenta exposição. | Inalterado, sem mudança em relação à solução anterior com o IBM Watson Assistant, o risco e seu tratamento permanecem os mesmos, com filtro de informações pessoais (PII) no fornecedor, e mantidos contrato e termos do serviço com a IBM.

R07 | Rastreabilidade ponta a ponta insuficiente | M4, M5 | Risco de insuficiência de rastreabilidade ponta a ponta (logs, correlação de eventos, identificadores únicos de requisição) em uma solução distribuída em múltiplas camadas (orquestrador, agentes, ferramentas, RAG, fornecedor), dificultando o diagnóstico de falhas, a correlação de incidentes, a auditoria das decisões tomadas pelo agente. | Histórico e observabilidade canônicos no EMPRESA (NEC/NIA); Unificação de ID de rastreamento (OpenTelemetry tracing) entre camadas (NEC, NIA e IBM); Trabalho em andamento com a PlatMoob para exportação das métricas, no padrão OpenTelemetry, do ecossistema da IBM para a empresa; Retenção segura de histórico conversacional e de gatilhos no EMPRESA, com prazo atual de 6 meses (com plano de 30 dias para acesso imediato e 1 ano em arquivo), finalidade e registro mínimo necessário para auditoria. O Assistente usa a camada Grafeno do canal hospedeiro, no escopo desta ADR o Assistente usa o servidor Grafeno Mobile, sendo a observabilidade e rastreabilidade de responsabilidade do canal Mobile, porém o canal Mobile tem observabilidade e rastreabilidade maduras da camada do Grafeno, com AppDynamics, alertas e painéis.

R08 | Lock-in com fornecedor/produto IBM watsonx Orchestrate | M5 | Dependência de capacidades proprietárias pode aumentar custo e atrito de migração futura. | Inalterado, sem mudança em relação à solução anterior com o IBM Watson Assistant, com objetivo de migração para a Plataforma e Esteira de IA corporativa, conforme disponibilidade; Com destaque a redução significativa do risco de lock-in, em relação à solução anterior baseada em NLP, dado a maior portabilidade de agentes como instruções LLM, e tools como wrappers sem regras negociais para gatilhos no EMPRESA, abstração via NIA Fachada IA, NIA Tool Handler e NEC Transaction Executor, uso mais extensivo de padrões abertos (como tools MCP, A2A, Agent Connect/Chat Completions API).

R09 | Encadeamento de agentes: latência vs segregação por domínio | M2, M3 | Encadeamento excessivo aumenta tempo de resposta e variabilidade de performance. | Estrutura utiliza um único agente supervisor e agentes colaboradores por domínio, com diretrizes para prevenir acionamento (handoff) repetido de agentes colaboradores, com limites de profundidade de encadeamento, timeout por etapa, roteamento direto para agente de domínio e estrutura de fallback (rota de fuga) para menus do App, para o caso de não ser encontrado agente adequado, evitando loopings e latência excessiva.

R10 | Agentes segregados por domínio: governança vs complexidade | M3, M4 | Segregação melhora controle, mas aumenta número de artefatos, integrações e esforço operacional. | Escopo restrito: Agentes e bases de conhecimento segregadas e com metadados, o que facilita a gestão e acionamento dos gestores; Catálogo central de gatilhos (tools); Trilha futura: Em andamento a automações de validação de gatilhos, bases de dados e agentes, usando esteiras consolidadas e em andamento (GAIA, Red-Team etc.); Revisão arquitetural quando cabível.

R11 | Gestão descentralizada de agentes por tema (RAG, tools e tecnologias) | M3, M4, M6 | Evolução por equipes distintas pode gerar deriva de padrões, segurança e observabilidade. | Escopo restrito: RACI explícito por artefato, baseline obrigatório (segurança, observabilidade, testes), trilhas de aprovação (esteira GAIA e Red-Team); Trilha futura: Modelo federado com governança central, trilhas de aprovação automatizadas.

[/TABELA]


N0 — Visão de Negócio Alvo

A visão de negócio alvo foca inicialmente no canal App EMPRESA, mantém o AEMPRESA como orquestrador central e o transbordo para atendimento humano — preservando a experiência do cliente e os controles transacionais do domínio EMPRESA. A mudança nesta camada é a substituição do IBM Watson Assistant (NLP) pelo IBM watsonx Orchestrate (LLM/agentes), que passa a oferecer conversação adaptativa, melhor tratamento de ambiguidades e base para evolução multicanal, sem alterar as responsabilidades de execução transacional já consolidadas no AEMPRESA.

Tabela 5 - N0 - Visão de Negócio Alvo


[TABELA]

Componente | Responsabilidade

Usuário — Cliente EMPRESA (PF e PJ) | Interage com o assistente para consultar informações e iniciar jornadas conversacionais e transacionais.

Canais Digitais — App EMPRESA/Mov e WhatsApp | Interface de entrada/saída das mensagens do usuário. Encaminham solicitações ao AEMPRESA e exibem as respostas retornadas. Foco inicial no canal App EMPRESA.

Assistente Conversacional EMPRESA (AEMPRESA) — Orquestração Conversacional e Transacional | Solução de atendimento conversacional do EMPRESA. Orquestra o diálogo ponta a ponta, integra com os canais de atendimento e mantém o controle da execução transacional no domínio EMPRESA. Composto por NEC e NIA.

Transbordo para Atendimento Humano (Falecom) – Encaminha o cliente para troca de mensagens com um atendente humano | Solução para atendimento humano, usado em caso de falha, de preferência do cliente, de dificuldade do cliente ou de fluxo ainda não disponibilizado no canal.

Transações Negociais (diversas siglas/sistemas) – Sistemas de negócio do EMPRESA | São diversas soluções do EMPRESA acessadas para prover produtos e serviços ao cliente.

Serviço de Inteligência Conversacional — IBM watsonx Orchestrate | Serviço de orquestração por agentes de IA (LLM) externo ao EMPRESA, sem acesso direto a endpoints transacionais, acionado pelo AEMPRESA.

[/TABELA]


Diagrama 4 - N0 - Visão de Negócio Alvo

![Diagrama 4 - N0 - Visão de Negócio Alvo](./extracted_images/iss470/word/media/image4.png)


Descrição textual:

Fluxo 1 – Entrada, cliente envia mensagem:

[USUÁRIO] Cliente EMPRESA -> [CANAIS] App EMPRESA/Mov ou WhatsApp

[CANAIS] App EMPRESA/Mov ou WhatsApp -> [AEMPRESA] Assistente Conversacional EMPRESA

Fluxo 2 – Transbordo para atendimento humano:

[AEMPRESA] Assistente Conversacional EMPRESA -> [TRANSBORDO] Atendimento Humano

Fluxo 3 – Jornada informacional:

[AEMPRESA] Assistente Conversacional EMPRESA -> [ATENDIMENTO] Informacional

[ATENDIMENTO] Informacional -> [FORNECEDOR] IBM watsonx Orchestrate

[FORNECEDOR] IBM watsonx Orchestrate -> [ATENDIMENTO] Informacional

[ATENDIMENTO] Informacional -> [AEMPRESA] Assistente Conversacional EMPRESA

Segue para o fluxo 5.

Fluxo 4 – Jornada transacional:

[AEMPRESA] Assistente Conversacional EMPRESA -> [ATENDIMENTO] Transacional

[ATENDIMENTO] Transacional -> [NEGOCIO] Transações Negociais

[ATENDIMENTO] Transacional -> [FORNECEDOR] IBM watsonx Orchestrate

[FORNECEDOR] IBM watsonx Orchestrate -> [ATENDIMENTO] Transacional

[ATENDIMENTO] Transacional -> [AEMPRESA] Assistente Conversacional EMPRESA

Segue para o fluxo 5.

Fluxo 5 – Retorno de mensagem para o cliente:

[AEMPRESA] Assistente Conversacional EMPRESA -> [CANAIS] App EMPRESA/Mov ou WhatsApp

[CANAIS] App EMPRESA/Mov ou WhatsApp -> [USUÁRIO] Cliente EMPRESA

N2 — Visão Geral da Arquitetura em Camadas Alvo

A visão em camadas alvo mantém a estrutura de sistemas e componentes do AEMPRESA, preservando as responsabilidades de orquestração e controle transacional no domínio EMPRESA, e substitui o componente de IA do fornecedor por um modelo de orquestração por agentes (IBM watsonx Orchestrate).

O NIA Tool Handler é introduzido como camada de controle de gatilhos, e o Satelite é mantido como gateway de borda para controle de endpoints entre EMPRESA e IBM. A arquitetura é desenhada para garantir que o fornecedor não tenha acesso a endpoints transacionais nem a dados sensíveis, e que o EMPRESA mantenha o controle total da execução de transações, como no modelo atual.

Tabela 6 - N2 - Arquitetura em Camadas Alvo


[TABELA]

Componente | Responsabilidade

App EMPRESA (MOV) — Canal interno mobile | Interface de entrada/saída do assistente no canal App EMPRESA/Mov; captura mensagens do usuário e exibe respostas do assistente.

WhatsApp EMPRESA (NEC) — Canal externo WhatsApp | Capturar mensagens do usuário via WhatsApp (Meta Cloud API) e encaminhar ao backend do assistente; exibir respostas no canal externo.

Satelite (EMPRESA) — Gateway de borda de rede EMPRESA↔IBM | Controlar os endpoints de rede autorizados entre EMPRESA e IBM watsonx Orchestrate via link privado (whitelist de endpoints).

cfe-nec (NEC / Grafeno) — Serviço de borda do canal App EMPRESA | Manter as conexões com os dispositivos e normalizar mensagens recebidas do canal App EMPRESA/Mov; ponto de entrada do canal interno no domínio NEC, implantado sobre o Grafeno.

adapter-app (NEC) — Adapter do canal App | Receber mensagens do cfe-nec e roteá-las ao orquestrador conversacional (bot-cc); capturar a identidade do cliente no canal.

bot-cc (NEC) — Orquestrador Conversacional (Conversation Core) | Orquestrar o fluxo de diálogo ponta a ponta: acionar o assistente cognitivo (ac), detectar gatilhos de transação na resposta e coordenar a execução transacional.

Liberação de Dispositivo (ATO) | Realizar e controlar a liberação de dispositivos do cliente; sistema interveniente no fluxo de identificação e autenticação.

ac (NEC) — Gateway para os serviços conversacionais | Receber mensagens do bot-cc, encaminhar à fachada-ia para processamento pelo fornecedor de IA, gerenciar contexto e retornar resposta (incluindo sinais de gatilho de transação).

transaction-executor (NEC) — Executor de Transações | Controlar permissão e execução de gatilhos transacionais no domínio EMPRESA: realiza autenticação (senha) e autorização (token) exclusivamente no EMPRESA e aciona os Grafenos de Negócio.

fachada-ia (NIA) — Fachada de integração com IA | Intermediar chamadas entre ac (NEC) e o IBM watsonx Orchestrate, encapsulando o contrato de integração com o fornecedor; roteia mensagens via Satelite.

tool handler (NIA) — Controlador de Gatilhos | Controlar o catálogo de transações negociais abstraídas como gatilhos: valida schema, restringe campos e parâmetros, sanitiza o payload e encaminha ao transaction-executor; único ponto de entrada de gatilhos no domínio EMPRESA provenientes do fornecedor. Atuar como um whitelist de endpoints.

IBM watsonx Orchestrate — Orquestrador IA (LLM/agentes) — fornecedor | Processar linguagem natural, orquestrar diálogo com agentes de IA e solicitar execução de gatilhos conforme toolset atribuído por agente; gerenciar o contexto conversacional da sessão ativa; sem acesso direto a endpoints transacionais do EMPRESA.

Grafenos de Negócio (diversas siglas) — Camada de execução de transações negociais para Canais Digitais de Atendimento | Executar operações transacionais acionadas pelo NEC, aplicando autenticação/autorização (token) e controles de acesso; camada negocial por cliente/canal; observabilidade via AppDynamics.

Operações de Negócio (diversas siglas) | Fornecer os produtos e serviços bancários aos clientes do EMPRESA.

[/TABELA]


Diagrama 5 - N2 - Arquitetura em Camadas Alvo

![Diagrama 5 - N2 - Arquitetura em Camadas Alvo](./extracted_images/iss470/word/media/image5.png)


N3 — Fluxo de execução transacional (gatilhos) alvo

Em relação ao atual (AS-IS), o fluxo alvo introduz dois pontos de controle adicionais no caminho de execução de gatilhos: o NIA Tool Handler, que valida o catálogo, restringe campos e sanitiza o payload antes de encaminhar ao executor transacional. O resultado retorna ao fornecedor filtrado pelo schema do gatilho — mínimo necessário para a jornada. O encadeamento Satelite → NIA → NEC garante que o fornecedor nunca execute gatilhos diretamente no domínio EMPRESA.

Diagrama 6 - N3 - Fluxo de Execução Transacional Alvo

![Diagrama 6 - N3 - Fluxo de Execução Transacional Alvo](./extracted_images/iss470/word/media/image6.png)


Descrição textual:

N3.1 — Fluxo de envio de mensagem pelo cliente

Canal ↔ Gateway/Adapter de canal (NEC)

Gateway/Adapter de canal (NEC) ↔ Orquestrador de Integração Conversacional (bot-cc / NEC)

Orquestrador de Integração Conversacional (bot-cc / NEC) ↔ NIA Gateway IA (fachada-ia / NIA)

NIA Gateway IA (fachada-ia / NIA) ↔ Gateway Satelite (EMPRESA)

Gateway Satelite (EMPRESA) ↔ IBM watsonx Orchestrate (LLM/agentes) — orquestração por agentes de IA

N3.2 — Fluxo de execução transacional (gatilhos)

Aplica-se quando o passo 5 do N3.1 resulta em solicitação de execução de gatilho pelo agente.

IBM watsonx Orchestrate solicita execução de gatilho ao gerenciador de gatilhos — conforme toolset atribuído ao agente.

Gerenciador de gatilhos ↔ Gateway Satelite (EMPRESA) via link privado — o Satelite valida o endpoint de rede conforme whitelist.

Gateway Satelite (EMPRESA) ↔ NIA Tool Handler (tool handler / NIA) — único endpoint de entrada de gatilhos no domínio EMPRESA.

NIA Tool Handler valida conforme catálogo e restrições:

gatilho autorizado (presente no catálogo e permitido para o agente);

campos e parâmetros restritos ao schema definido (sem exposição de parâmetros além do contrato do gatilho);

sanitização/normalização do payload.

NIA Tool Handler (tool handler / NIA) encaminha payload restrito ao Orquestrador de Execução Transacional (transaction-executor / NEC).

Orquestrador de Execução Transacional (transaction-executor / NEC) executa endpoints via Grafeno/IIB, realizando autenticação (senha) e autorização (token) exclusivamente no domínio EMPRESA.

Resultado retorna ao NIA Tool Handler (tool handler / NIA), é minimizado/filtrado segundo o schema do gatilho (mínimo necessário para a jornada) e encaminhado via Gateway Satelite ao IBM watsonx Orchestrate para continuidade do diálogo.

Segue o passo 1 do N3.3 para continuidade do diálogo.

N3.3 — Fluxo retorno de mensagem para o cliente

IBM watsonx Orchestrate (LLM/agentes) ↔ Gateway Satelite (EMPRESA)

Gateway Satelite (EMPRESA) ↔ NIA Gateway IA (fachada-ia / NIA)

NIA Gateway IA (fachada-ia / NIA) ↔ Orquestrador de Integração Conversacional (bot-cc / NEC)

Orquestrador de Integração Conversacional (bot-cc / NEC) ↔ Gateway/Adapter de canal (NEC)

Gateway/Adapter de canal (NEC) ↔ Canal

Ponto sensível (controle): o agente nunca executa gatilhos no ambiente do EMPRESA diretamente; sempre por meio do encadeamento Satelite → NIA → NEC.

Governança de Artefatos

Todos os artefatos referenciados neste documento são definidos e mantidos pela equipe responsável no EMPRESA, conforme a [ALTERAÇÃO] Tabela 7 abaixo. O catálogo de gatilhos e seus schemas (contratos machine-readable com descrição negocial) são mantidos no NIA e constituem a fonte de verdade para validação e controle de superfície exposta ao fornecedor. O toolset por agente é configurado pela equipe EMPRESA diretamente na solução IBM watsonx Orchestrate. As bases de conhecimento (RAG) são curadas e atualizadas pelos gestores do canal ou produto; o processo de revisão periódica será definido na fase de implantação, com controle de acesso às bases e revisão de conteúdo antes da publicação para prevenir injeção de conteúdo indevido. A whitelist do Satelite segue processo já mapeado no EMPRESA e está fora do escopo desta ADR.

Tabela 7 - Governança de artefatos - RACI

Legenda: R = Responsável (executa); A = Aprovador (decide/autoriza); C = Consultado; I = Informado.


[TABELA]

Artefato | Criação | Revisão | Publicação em produção | Aprovação de exceção

Catálogo de gatilhos (NIA) | Analista (R) | Analista (R) | Analista, se requisitos mínimos atendidos (R); caso contrário, Gestor (A) | Gestor do canal / Gestor de produto (A)

Schema / Contrato de gatilho | Analista (R) | Analista (R) | Analista, se requisitos mínimos atendidos (R); caso contrário, Gestor (A) | Gestor do canal / Gestor de produto (A)

Versionamento e deprecação de schemas | Segue processo existente do Grafeno/IIB; fora do escopo desta ADR | Analista / Desenvolvedor (C) | Segue processo existente do Grafeno/IIB; fora do escopo desta ADR | Segue processo existente do Grafeno/IIB; fora do escopo desta ADR

Toolset por agente (Orchestrate) | Analista / Assessor (R) | Analista / Desenvolvedor (C) | Gestor do canal / Gestor de produto (A) | Gestor do canal / Gestor de produto (A)

Bases de conhecimento / RAG | Analista (R) | Analista (R) | Analista, se requisitos mínimos atendidos (R); caso contrário, Gestor (A) | Gestor do canal / Gestor de produto (A)

Whitelist do Satelite (endpoints de rede) | Processo do Satelite já mapeado no EMPRESA; fora do escopo desta ADR | Processo do Satelite já mapeado no EMPRESA; fora do escopo desta ADR | Processo do Satelite já mapeado no EMPRESA; fora do escopo desta ADR | Processo do Satelite já mapeado no EMPRESA; fora do escopo desta ADR

[/TABELA]


[NOVO] Nota (RAG): a publicação de bases RAG em produção requer validação de conteúdo, controle de versão e revisão por gestor antes de qualquer atualização, prevenindo contaminação por conteúdo incorreto, desatualizado ou malicioso. O processo detalhado de revisão periódica será definido na fase de implantação. Alinhado a R01, R02, R03, R04, R05.

Segurança e Compliance

A estratégia de segurança é organizada em cinco camadas complementares: modelo de confiança (onde a fronteira EMPRESA/fornecedor é delimitada e os segredos são mantidos no domínio EMPRESA), minimização de dados (o que trafega para o fornecedor), controle de acesso em camadas (quem pode acionar o quê), guardrails (limites de comportamento do agente) e auditoria (rastreabilidade ponta a ponta). Essas camadas são projetadas para funcionar de forma independente — a falha ou opacidade de uma não compromete as demais.

Modelo de confiança e exposição mínima

O modelo de confiança é baseado no princípio de que o fornecedor opera exclusivamente no espaço de diálogo: solicita a execução de gatilhos, mas não os executa diretamente — não recebe segredos, não acessa endpoints transacionais e não retém dados entre sessões. A fronteira EMPRESA/IBM é controlada em rede (Satelite) e em dados (NEC/Redis).

[NOVO] Os controles listados a seguir são as contrapartes operacionais das mitigações descritas na Tabela 4 - Riscos e mitigações da arquitetura alvo (TO-BE), endereçando especialmente R01 (prompt injection), R03 (uso indevido de gatilhos), R06 (retenção de dados no fornecedor) e R08 (lock-in com fornecedor).

Lista 3 - Modelo de confiança - controles da fronteira EMPRESA fornecedor

Comunicação EMPRESA<->IBM via link privado, mediada pelo Satelite, gateway com whitelist de acesso.

NEC mantém segredos e execução transacional: senha e token não trafegam nem permanecem no fornecedor.

Contexto conversacional gerenciado pelo fornecedor na sessão ativa: o estado do diálogo em curso é gerenciado pelo IBM watsonx Orchestrate dentro da sessão; encerrada a sessão, não há persistência de dados de conversa no ambiente externo.

Sem troca de "contexto persistente" com o fornecedor: fora da sessão ativa, existe apenas troca transitória de payload de gatilhos; nenhum dado de sessão anterior persiste no fornecedor.

Sessão de autenticação e autorização no EMPRESA (Redis): tokens e credenciais são mantidos exclusivamente no domínio EMPRESA via Redis (componente session/Redis do NEC); o fornecedor nunca recebe ou armazena credenciais de acesso.

Payloads transacionais transitórios: resultados de gatilhos trafegam de forma transitória — mínimo necessário conforme schema do gatilho —, sem persistência no fornecedor.

[NOVO] Controle de integridade das bases de conhecimento (RAG): bases de conhecimento são segregadas por domínio, versionadas e submetidas a processo de revisão, aprovação e validação de conteúdo antes da publicação, prevenindo contaminação por conteúdo incorreto, desatualizado ou malicioso. Alinhado a R01, R02, R03, R04 e R05.

[NOVO] Retenção segura de histórico no domínio EMPRESA: histórico conversacional e de acionamentos de gatilhos retido exclusivamente no EMPRESA (NEC/NIA), com prazo atual de 6 meses (plano de 30 dias para acesso imediato e 1 ano em arquivo), finalidade e registro mínimo necessário para auditoria. Alinhado a R07.

Política de minimização de dados no retorno ao fornecedor

O schema do gatilho define o teto do que pode retornar ao fornecedor após a execução de uma transação — o NIA Tool Handler aplica essa restrição mecanicamente, sem depender de julgamento em tempo de execução. A responsabilidade de classificar os campos mínimos necessários é do gestor/desenvolvedor da jornada, antes da publicação do schema.

As regras abaixo definem responsabilidades, restrições e a fonte de verdade para o controle de dados retornados ao fornecedor.

Lista 4 - Política de minimização de dados no retorno ao fornecedor

O gestor/desenvolvedor de cada jornada é responsável por classificar e definir os campos mínimos necessários para a realização da jornada.

O NIA Tool Handler (tool handler / NIA) aplica filtragem no payload de retorno, limitando aos campos definidos no schema do gatilho.

Senhas e tokens de sessão não são incluídos no retorno ao fornecedor.

Dados sensíveis só são incluídos no retorno ao fornecedor quando estritamente necessários para a conclusão da jornada e explicitamente autorizados no schema do gatilho.

O schema do gatilho é a fonte de verdade para os campos permitidos no trânsito com o fornecedor.

[NOVO] Não há troca de dados contextuais adicionais com o fornecedor além da mensagem do usuário e do payload de gatilhos definido no schema; quaisquer informações adicionais necessárias para a jornada devem ser obtidas via gatilhos (tools).

Controle de acesso em camadas e mínimo privilégio (gatilhos)

O controle de acesso é implementado em profundidade: nenhuma camada confia cegamente na anterior, e cada uma restringe o que a camada seguinte pode fazer. A restrição de acesso é aplicada em cinco planos complementares (ver convenção em Governança de Artefatos).

Tabela 8 - Controle de acesso e execução de gatilhos


[TABELA]

Plano | Componente | O que controla

Rede | Satelite | Endpoints de rede permitidos entre IBM watsonx Orchestrate e NIA (IBM ↔ EMPRESA); whitelist de endpoints

Gatilhos/Campos | NIA Tool Handler (tool handler / NIA) | Transações negociais abstraídas como gatilhos, com restrição de campos e parâmetros expostos; catálogo, schemas e validações entre IBM watsonx Orchestrate, NEC e cada transação negocial

Agente <-> Gatilho | IBM watsonx Orchestrate | Atribuição de toolset (conjunto de gatilhos) por agente: define quais gatilhos (expostos pelo NIA Tool Handler) cada agente pode solicitar

Execução de transações | NEC (transaction-executor) | Execução de endpoints por meio de mecanismos internos (Grafeno/IIB/endpoints), realizando autenticação (senha) e autorização (token) exclusivamente no domínio EMPRESA

[NOVO] Coerência semântica | NIA Tool Handler (tool handler / NIA) | Validação da coerência entre a intenção detectada e o gatilho solicitado, impedindo acionamentos fora de contexto ou induzidos por manipulação semântica. Alinhado a R01, R03, R04.

Transacional EMPRESA | Grafeno/IIB | Aplicação de regras negociais e de autorização, como limites, restrições por cliente e canal

[/TABELA]


Guardrails e controles recomendados

Como diretriz, adotar controles alinhados à ADR corporativa de multiagentes: mínimo privilégio, validação de entradas/saídas, filtros de conteúdo sensível, guardrails de comportamento do agente e rastreabilidade ponta a ponta.

[NOVO] Os controles a seguir complementam essa diretriz geral, aplicados nas camadas da arquitetura alvo (alinhados a R01, R02, R03, R04, R05, R09 e R10):

Mitigação de prompt injection: esteira GAIA, Red-Team e Granite Guardrail, toolset estático por agente (whitelist); NIA Tool Handler registra, valida e saneia payload antes de qualquer execução; NEC Transaction Executor mantém controle independente do estado do LLM. Alinhado a R01, R03.

Integridade de bases RAG: validação de conteúdo, versionamento e revisão das bases antes da publicação (ver Lista 3 e Tabela 7). Alinhado a R05.

Guardrails de comportamento do agente: definidos por agente no IBM watsonx Orchestrate, incluindo uso do Granite Guardian para bloqueio de tentativas de manipulação. Alinhado a R02.

Validação de coerência semântica: o NIA Tool Handler valida a coerência entre a intenção detectada e o gatilho solicitado, impedindo acionamentos fora de contexto ou induzidos por manipulação semântica. Alinhado a R01, R03, R04.

Esteira GAIA e Red-Team: todos os agentes passam pela esteira GAIA para obter parecer de EMPRESA ANALITICA, EMPRESA DE RISCO, EMPRESA EMPRESA DICOI e EMPRESA DE SEGURANÇA, e pelo Red-Team da EMPRESA DE SEGURANÇA para validação de vulnerabilidades.

Aviso ao usuário: o assistente adota práticas de mercado para IA generativa; o cliente é informado sobre o uso de tecnologia generativa e sobre riscos inerentes (alucinações, viés, conteúdo indevido).

[NOVO] Plano de resposta a ocorrências de IA generativa (alinhado a R01–R05): em caso de ocorrência de alucinação, viés ou conteúdo indevido, o plano de resposta segue seis etapas:

Detecção: identificação da ocorrência via guardrails, monitoramento semântico ou reporte de usuário.

Avaliação de impacto: classificação do risco (informacional vs. transacional; risco de imagem vs. financeiro; abrangência da exposição).

Registro de incidente: registro formal nos canais corporativos de incidente.

Comunicação hierárquica: notificação em níveis conforme gravidade — gestores do produto → fornecedor (IBM) → gestores da linha → executivos → EMPRESA DE SEGURANÇA/EMPRESA ANALITICA/EMPRESA DE RISCO/EMPRESA DICOI.

Contenção: ação proporcional ao risco — observação com monitoramento ampliado, rollback de modelo ou base de conhecimento, ou bloqueio temporário do agente/jornada afetada.

Correção: ajuste de guardrails, bases RAG, prompts ou toolset; nova validação antes da retomada.

[NOVO] Evaluation pipeline contínuo (alinhado a R01–R05): processo de avaliação contínua da qualidade das respostas do agente, composto por amostragem periódica, avaliação humana e métricas automatizadas de qualidade e assertividade (groundness, faithfulness, precision, recall, context relevance). Métricas em andamento de exportação para a base corporativa do EMPRESA via IBM Governance.

Auditoria e rastreabilidade

A rastreabilidade é garantida por camada própria no EMPRESA, independente do fornecedor — cada componente registra o que acionou, o que decidiu e o resultado, permitindo auditoria ponta a ponta mesmo em caso de opacidade ou falha do fornecedor. [NOVO] O padrão OpenTelemetry é adotado nas camadas NEC e NIA, com trace ID unificado propagado entre todas as camadas até o fornecedor, viabilizando correlação de eventos e diagnóstico distribuído. A observabilidade nativa do IBM watsonx Orchestrate é aproveitada como camada complementar, com exportação de métricas para a base corporativa da PlatMoob em andamento. Alinhado a R07.

Lista 5 - Cadeia de observabilidade e auditoria por camada

Grafeno: observabilidade nativa via AppDynamics (execução de operações transacionais).

[ALTERAÇÃO] NEC: registra acionamentos de transações (mapeadas como gatilhos) via Stack O11y no padrão OpenTelemetry — gatilho solicitado, parâmetros usados, decisão de execução e resultado. Alinhado a R07.

[ALTERAÇÃO] NIA: registra histórico de mensagens e acionamentos de gatilhos via Stack O11y no padrão OpenTelemetry — validações de catálogo, schemas, parâmetros permitidos, saneamento e encaminhamento. Alinhado a R07.

[ALTERAÇÃO] IBM watsonx Orchestrate (fornecedor): exportação de telemetria e métricas em formato OpenTelemetry para pipeline da PlatMoob; trabalho em andamento para integração com a base corporativa de observabilidade do EMPRESA. Alinhado a R07.

[NOVO] Rastreamento ponta a ponta: identificador único de rastreamento (trace ID OpenTelemetry) propagado entre todas as camadas — canal, NEC, NIA e IBM watsonx Orchestrate —, permitindo correlação de eventos e auditoria ponta a ponta de qualquer jornada. Alinhado a R07.

[NOVO] Monitoramento de qualidade e segurança das respostas: amostragem periódica de respostas com classificação automatizada e coleta para ciclo de avaliação contínua (evaluation pipeline), cobrindo qualidade semântica, aderência a políticas e segurança das respostas do agente. Alinhado a R01, R02, R03, R04 e R05.

Decisões Arquiteturais Consolidadas

As decisões abaixo registram as escolhas estruturais da arquitetura alvo, com as alternativas consideradas e a justificativa técnica para cada uma — rastreando cada decisão aos motivadores M1–M6 que a fundamentam [NOVO] e aos riscos R01–R11 que ela endereça (ver Tabela 4).

Tabela 9 - Decisões arquiteturais consolidadas


[TABELA]

Domínio | Decisão | Alternativas consideradas | Escolha | Justificativa técnica | [NOVO] Riscos endereçados

Execução transacional | Onde executar gatilhos transacionais | Execução direta pelo agente no fornecedor vs execução controlada pelo EMPRESA | Execução controlada pelo EMPRESA via NEC (transaction-executor) | Preserva segredos (senha/token), reduz superfície exposta, mantém controle e auditoria (M4) | R01, R03, R04, R06

Integração EMPRESA<->IBM | Mediação por gateway dedicado | Acesso direto vs gateway de borda | Satelite (gateway com whitelist) | Reduz superfície de rede e cria ponto de controle explícito | R01

Governança de gatilhos | Fonte da verdade no catálogo do NIA | Fornecedor vs EMPRESA | NIA (tool handler) | EMPRESA controla conjunto de gatilhos (toolset), schemas e validações; reduz alucinação e ruído (M1, M4) | R01, R02, R03

Contratos de gatilhos | Forma de contrato | Informal vs formal | Formal (machine-readable) + descrição negocial | Controle de schema e validação; integração auditável (M1) | R03, R08

Abstração de endpoint de gatilho | Forma de invocação do gatilho pelo fornecedor | URL direta exposta ao fornecedor vs identificador/nome abstrato | Invocação por nome — endpoint real abstraído pelo NIA Tool Handler (tool handler / NIA); fornecedor nunca conhece a URL de execução | [ALTERAÇÃO] Reduz superfície exposta ao fornecedor; decoupling reforçado via fachada-ia, NIA Tool Handler e contratos formais de gatilhos, reduzindo risco de lock-in tecnológico (R08); impede acesso direto a endpoints transacionais (M4, M1) | R01, R08

Segregação por agente de IA | Conjunto de gatilhos (toolset) por agente | Dinâmico vs estático | Estático (whitelist) — relação com agente de IA configurada pela equipe responsável no EMPRESA, limitada aos gatilhos e contratos expostos pelo NIA Tool Handler (tool handler / NIA) | [ALTERAÇÃO] Mínimo privilégio e auditabilidade; EMPRESA mantém controle mesmo sobre a configuração residente no fornecedor; posicionamento como agente de canal, com evolução para multiagentes por domínio prevista como trilha futura (R09, R10) (M4) | R01, R03, R09, R10, R11

Contexto com o fornecedor — separação de dados sensíveis | Segregação de credenciais e tokens do contexto conversacional | Credenciais no fornecedor vs domínio EMPRESA | Sessão de autenticação/autorização mantida exclusivamente no Redis (EMPRESA); payloads transacionais trafegam de forma transitória, sem persistência no fornecedor | [ALTERAÇÃO] Elimina risco de exposição de credenciais ao fornecedor; credenciais e tokens nunca são transmitidos ao IBM watsonx Orchestrate; separa responsabilidades de forma auditável (M4, M5) | R01, R06

Contexto com o fornecedor — contexto conversacional | Onde manter o estado do diálogo ativo | Contexto persistente no EMPRESA vs contexto na sessão do fornecedor | Contexto conversacional (estado do diálogo ativo) gerenciado pelo fornecedor na sessão ativa; sem contexto persistente entre sessões | O LLM necessita de contexto para orquestrar o diálogo; a sessão é encerrada ao fim da conversa, sem acúmulo de dados (M4, M5) | R06

Minimização de payload no retorno | Volume de dados retornados ao fornecedor após execução transacional | Payload completo da transação vs payload filtrado pelo schema do gatilho | Payload filtrado pelo NIA Tool Handler (tool handler / NIA) — apenas campos definidos no schema do gatilho, conforme mínimo necessário para a jornada | Reduz exposição de dados sensíveis ao fornecedor; gestor/desenvolvedor da jornada é responsável pela classificação dos campos (M4) | R06

Observabilidade e Rastreabilidade | Telemetria e correlação | Apenas logs vs tracing distribuído | [ALTERAÇÃO] Tracing + métricas por etapa no EMPRESA (Stack O11y / OpenTelemetry) e na solução do fornecedor | Trace ID unificado propagado entre NEC, NIA e IBM watsonx Orchestrate; exportação de métricas para a PlatMoob em andamento; diagnóstico e auditoria ponta a ponta. Alinhado a R07. | R07

Observabilidade de gatilhos | Dependência da observabilidade do fornecedor | Depender exclusivamente da observabilidade nativa do IBM watsonx Orchestrate vs camada própria no EMPRESA | [ALTERAÇÃO] Camada de observabilidade canônica no EMPRESA (independente do fornecedor) + logs nativos do Orchestrate como complemento e exportação para o EMPRESA. | Garante rastreabilidade e auditoria dos acionamentos de gatilhos mesmo em caso de opacidade ou falha do fornecedor; métricas exportadas via OpenTelemetry para pipeline da PlatMoob. Alinhado a R07 (M4) | R07

Rollout | Estratégia de implantação | Big bang vs gradual | [ALTERAÇÃO] Gradual: App EMPRESA (seguindo cronograma do App 5.0) → inicialmente para funcionários e com jornadas limitadas | Reduz risco e permite controle (M2, M3) | R02, R09

[NOVO] Estratégia de saída de fornecedor | Portabilidade e desacoplamento | Dependência total vs desacoplamento controlado | Camadas de abstração (fachada-ia, NIA Tool Handler, NEC transaction-executor) e contratos formais de gatilhos desacoplam a arquitetura do IBM watsonx Orchestrate | Viabiliza troca de fornecedor, modelo ou plataforma com menor custo de migração; IBM watsonx Orchestrate suporta troca de LLM e conectividade via MCP/A2A. Alinhado a R08 (M5) | R08

[/TABELA]


Estratégia de Modernização (aplicada)

A modernização é executada em três movimentos complementares: encapsulamento do fornecedor, substituição gradual por canal/público/jornada e reescrita seletiva dos componentes de controle no EMPRESA — minimizando risco e preservando operação contínua durante a transição.

Lista 6 - Estratégia de modernização

Encapsulamento: encapsular componentes do fornecedor por meio de NIA + Satelite, reduzindo acoplamento e exposição.

Substituição gradual (strangler): migração progressiva por canal (App EMPRESA primeiro), por público (funcionários primeiro) e por conjunto de jornadas (Pix, cartões e informacionais).

Reescrita seletiva: criação de novos componentes no EMPRESA (NIA Tool Handler / tool handler) e adaptação do Orquestrador de Execução Transacional (transaction-executor) no NEC para suportar o novo modelo de gatilhos.

Lista 7 - Indicadores para acompanhamento da modernização

[NOVO] Indicadores operacionais (alinhados a R01–R05 e R07 — baseline em definição):

Saturação, latência, erro e vazão (SLEV): métricas operacionais por camada (NEC, NIA, IBM watsonx Orchestrate); limiares quantitativos de avanço e rollback serão definidos em fase de implantação.

Taxa de erro do assistente: acompanhamento contínuo por fase; gatilho de rollback acionado em caso de degradação significativa ou contínua.

Avaliação dos clientes: feedback de satisfação por jornada.

Ausência de incidentes de segurança relacionados ao assistente na fase: critério de avanço entre fases.

Rollback ao modelo atual (que permanece em uso no WhatsApp) testado e validado antes de avançar para a próxima fase.

[NOVO] Indicadores de segurança semântica e qualidade (alinhados a R01–R05):

Taxa de bloqueio por guardrails: percentual de respostas bloqueadas ou redirecionadas pelos mecanismos de guardrail ativo.

Taxa de feedback negativo: proporção de interações com feedback negativo explícito do usuário.

Reincidência de respostas indevidas: acompanhamento de padrões de falha semântica.

[NOVO] Indicadores de efetividade do atendimento (alinhados a R01–R05):

Taxa de resolução sem transbordo: percentual de interações resolvidas sem transferência para atendimento humano.

Taxa de feedback positivo/negativo: métricas de satisfação e qualidade percebida.

Métricas de avaliação automatizada: groundness, faithfulness, precision, recall e context relevance, via IBM Governance — exportação para base corporativa em andamento.

Considerações finais

A modernização substitui o componente de IA do fornecedor sem alterar a estrutura de responsabilidades e controles da arquitetura atual: NEC e NIA continuam sendo os responsáveis pela orquestração das interações, pela execução das transações negociais e pela custódia de segredos e credenciais — exatamente como no modelo atual. O fornecedor permanece no espaço de diálogo, sem acesso direto a endpoints transacionais, sem retenção de credenciais e sem execução autônoma de gatilhos.

Os ganhos da modernização são estruturais: escalabilidade de conhecimento sem reorganização global, conversação adaptativa com menor taxa de transbordo, custo marginal de evolução reduzido, observabilidade semântica por camadas e menor risco de lock-in tecnológico. O escopo inicial é deliberadamente restrito — canal App EMPRESA e jornadas selecionadas — para validar os controles em condições controladas antes de ampliar o rollout.

A arquitetura é desenhada para ser evolutiva, permitindo a introdução de novos canais, públicos e jornadas, e a eventual adoção da plataforma corporativa de IA, sem alterar os princípios estruturais de controle e orquestração definidos nesta ADR. [NOVO] Os pontos de desacoplamento previstos — fachada-ia (integração com fornecedor), NIA Tool Handler (catálogo/mapa de gatilhos [tools], contratos formais de gatilhos), NEC Transaction Executor (acionamento de Grafeno e abstração de sessão) —, além das tecnologias e padrões suportados — LLM, suporte a múltiplos modelos, MCP, A2A, Agent Connect/Chat Completions API —, reduzem significativamente o risco de lock-in em relação ao modelo anterior, facilitando futura troca de fornecedor, para modelo ou plataforma com menor custo de migração (R08). A presente arquitetura posiciona o assistente como agente multicanal; e alinha a evolução com uma arquitetura alvo com multiagentes por domínio, tendo como alvo à ADR corporativa de multiagentes (R09, R10, R08, R01).

Glossário

[NOVO] MCP (Model Context Protocol): protocolo aberto para exposição padronizada de ferramentas a agentes de IA. Nesta ADR, o MCP é mencionado no contexto de portabilidade e interoperabilidade do fornecedor IBM watsonx Orchestrate; no domínio EMPRESA, o NIA Tool Handler não utiliza MCP internamente — opera via HTTP convencional como catálogo de endpoints para os Grafenos de Negócio; o controle de execução permanece no NEC Transaction Executor.

AEMPRESA (Assistente Conversacional EMPRESA): solução de atendimento conversacional do EMPRESA. É composta pelos sistemas internos NEC e NIA, com execução transacional sob controle do EMPRESA.

Solução de Assistentes Conversacionais: denominação equivalente ao AEMPRESA (Assistente Conversacional EMPRESA) nesta ADR.

NEC: Sistema EMPRESA que concentra gateway/adapters de canal, orquestração do assistente e motor transacional.

NIA: Sistema EMPRESA para integração de IA; inclui NIA Gateway IA (fachada-ia) e NIA Tool Handler (tool handler) — responsável pelo controle de gatilhos (transações abstraídas com restrição de campos) entre IBM watsonx Orchestrate, NEC e transações negociais.

Gateway Satelite: Sistema interno do EMPRESA (gateway de borda) que controla os endpoints de rede entre IBM watsonx Orchestrate e NIA (IBM ↔ EMPRESA) via link privado, com whitelist de endpoints de rede permitidos.

NIA Tool Handler (tool handler / NIA): Componente do NIA responsável pelo controle das transações negociais abstraídas como gatilhos, com restrição de campos e parâmetros expostos, entre o IBM watsonx Orchestrate, o NEC e cada transação negocial.

Orquestrador de Integração Conversacional (bot-cc / NEC): Componente do NEC responsável por orquestrar o fluxo de diálogo ponta a ponta, acionar o assistente cognitivo (ac), detectar gatilhos de transação na resposta e coordenar a execução transacional.

Orquestrador de Execução Transacional (transaction-executor / NEC): Componente do NEC responsável por controlar permissão e execução de gatilhos transacionais; realiza autenticação (senha) e autorização (token) exclusivamente no domínio EMPRESA.

NIA Gateway IA (fachada-ia / NIA): Componente do NIA responsável por intermediar chamadas entre ac (NEC) e o IBM watsonx Orchestrate, encapsulando o contrato de integração com o fornecedor.

Gatilho (tool): Acionamento solicitado pelo orquestrador IA, abstraído com invocação por nome, não por URL, e com restrição de campos, validado pelo NIA Tool Handler e executado no EMPRESA. Equivale à 'tool' do fornecedor (IBM).

Contrato de gatilho: Schema formal (machine-readable) + descrição negocial para humanos e LLM.

Grafeno: Gateway corporativo usado para integração de canais internos e acesso a operações via operação IIB.

RAG: Retrieval-Augmented Generation (bases documentais temáticas para suporte a agentes).

Whitelist: Lista explícita de gatilhos/endpoints/parâmetros permitidos.

Transbordo: Transferência controlada da interação com o cliente para um agente humano (atendente). Ocorre quando o assistente não consegue resolver autonomamente ou necessita de intervenção humana especializada.

Strangler pattern: Estratégia de modernização que envolve a substituição gradual de um sistema legado por meio da criação de uma nova aplicação que "estrangula" o sistema antigo, assumindo suas funcionalidades progressivamente até que o legado seja completamente substituído.

DSL proprietária: Linguagem de domínio específico desenvolvida e controlada por um fornecedor, com baixo suporte a padrões abertos, que pode criar dependência e dificultar migrações futuras.

NLU/NLP: Natural Language Understanding / Natural Language Processing — tecnologias de processamento de linguagem natural usadas para interpretar e gerar texto em assistentes conversacionais.

LLM: Large Language Model — modelo de linguagem de grande escala, como os usados em soluções de IA generativa, que pode ser treinado para realizar tarefas complexas de compreensão e geração de texto, permitindo uma conversação mais fluida e adaptativa.

Guardrails: Conjunto de regras, restrições e validações implementadas para garantir que o comportamento de um sistema de IA permaneça dentro de limites seguros, éticos e alinhados aos objetivos do negócio, prevenindo ações indesejadas ou prejudiciais.

Vendor lock-in: Situação em que um cliente se torna dependente de um fornecedor específico para produtos ou serviços, dificultando a migração para alternativas concorrentes sem incorrer em custos significativos ou perda de funcionalidade.

Multicanal: Capacidade de um sistema de atendimento ou comunicação de operar em múltiplos canais (ex. app, web, WhatsApp) de forma integrada e consistente.

cfe-nec: Serviço de borda do canal App EMPRESA/Mov com o Assistente Conversacional (NEC); responsável por protocolar e normalizar mensagens do canal interno.

WhatsApp Cloud API: API do WhatsApp (Meta) para envio e recebimento de mensagens no canal externo. Sistema externo ao EMPRESA, acionado pelo NEC via webhook.

ATO (Sistema de Liberação de Dispositivos): Sistema EMPRESA responsável por realizar OTP e controlar a liberação de dispositivos do cliente no fluxo de identificação e autenticação.

Redis: Armazenamento de dados em memória utilizado pelo NEC. No atual (AS-IS): gerenciamento de sessão do cliente e contexto de conversa. No alvo (TO-BE): gerenciamento de sessão de autenticação e autorização do cliente (o contexto conversacional é gerenciado pelo fornecedor na sessão ativa).