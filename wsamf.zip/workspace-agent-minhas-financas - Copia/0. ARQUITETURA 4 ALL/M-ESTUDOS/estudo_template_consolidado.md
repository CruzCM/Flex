# Fluxo conceitual consolidado do template

Este diagrama reúne, em uma única visão, a montagem do serviço e o ciclo completo de uma chamada HTTP. O processamento interno do agente aparece apenas como uma caixa-preta: o foco está na infraestrutura, na API, nas validações, nos retornos e na observabilidade.

Em cada caixa técnica, a linha **Código** informa o arquivo e a classe, função ou configuração responsável. Nos arquivos Python, o caminho é relativo ao pacote `iaa_agent_mf_edu_fin/`.

```mermaid
flowchart TB

    %% ================================================================
    %% 1. PREPARAÇÃO E PUBLICAÇÃO
    %% ================================================================
    subgraph PREP["1 — Preparação e publicação"]
        direction LR
        P1["Código-fonte do serviço<br/>+ configurações do template<br/><b>Código:</b> pacote Python + agent_config.yaml"]
        P2["Pipeline de validação, build e publicação<br/>conforme as flags do template<br/><b>Código:</b> Jenkinsfile · pythonBuildPipeline"]
        P3["Imagem do container<br/>com aplicação e dependências<br/><b>Código:</b> Dockerfile"]
        P4["Deploy no Kubernetes / OpenShift<br/>Deployment + Pod + Container<br/><b>Código:</b> Chart.yaml + values.yaml"]
        P1 --> P2 --> P3 --> P4
    end

    %% ================================================================
    %% 2. INICIALIZAÇÃO DA APLICAÇÃO
    %% ================================================================
    subgraph STARTUP["2 — Inicialização do serviço dentro do container — uma vez por processo"]
        direction TB
        S1["Container inicia o comando<br/>python -m pacote_do_serviço<br/><b>Código:</b> Dockerfile · CMD"]
        S2["Python executa o ponto de entrada<br/><b>Código:</b> __main__.py · main()"]
        S3["O ponto de entrada configura<br/>host, porta, workers e nível de log<br/><b>Código:</b> __main__.py · main() + argparse"]
        S4["Uvicorn inicia o servidor HTTP/ASGI<br/>0.0.0.0:8080<br/><b>Código:</b> __main__.py · main() → uvicorn.run()"]
        S5["Uvicorn importa app.py<br/>e procura o objeto global app<br/><b>Código:</b> __main__.py · uvicorn.run(...app:app)"]
        S6["Carga das configurações<br/>arquivo YAML + variáveis de ambiente<br/><b>Código:</b> config.py · get_config() + load_agent_config()<br/><b>Dados:</b> agent_config.yaml"]
        S7["Preparação dos recursos transversais<br/>logs, métricas, tracing e guardrails<br/><b>Código:</b> tracing.py · configure_azure_monitor()<br/><b>Código:</b> utils/guardrails_middleware.py · carga do módulo"]
        S8["Criação da aplicação FastAPI<br/><b>Código:</b> app.py · app = FastAPI(...)"]
        S9["Acoplamento do middleware<br/>de entrada e saída<br/><b>Código:</b> app.py · app.add_middleware()<br/><b>Classe:</b> GuardrailsMiddleware"]
        S10["Registro dos contratos e rotas<br/>POST /chat · health · ready · metrics<br/>docs e redoc<br/><b>Código:</b> app.py · ChatRequest/ChatResponse/MetricsResponse<br/><b>Funções:</b> chat() · health_live() · health_ready() · metrics()"]
        S11["Execução do ciclo de startup<br/><b>Código:</b> app.py · lifespan()"]
        S12["Inicialização do componente de processamento<br/>detalhes internos fora do escopo<br/><b>Fronteira:</b> graph.py · AgentGraph.compile()"]
        S13{"Inicialização concluída?<br/><b>Código:</b> app.py · lifespan()<br/><b>Runtime:</b> Uvicorn/FastAPI"}
        S14["Serviço indisponível ou não pronto<br/>corrigir configuração/dependência<br/>antes de receber tráfego<br/><b>Responsável:</b> lifespan + runtime Uvicorn"]
        READY["APLICAÇÃO PRONTA<br/>Uvicorn aceitando requisições<br/><b>Objeto:</b> app.py · app<br/><b>Runtime:</b> Uvicorn"]

        S1 --> S2 --> S3 --> S4 --> S5 --> S6 --> S7 --> S8 --> S9 --> S10 --> S11 --> S12 --> S13
        S13 -- "Não" --> S14
        S13 -- "Sim" --> READY
    end

    P4 --> S1

    %% ================================================================
    %% 3. CAMINHO DE REDE E ENTRADA NO SERVIÇO
    %% ================================================================
    subgraph NETWORK["3 — Caminho conceitual da chamada até a aplicação — repete a cada requisição"]
        direction LR
        C1["Sistema consumidor / canal<br/>origem real ainda a confirmar<br/><b>Responsável:</b> sistema externo"]
        C2["HTTPS + DNS + certificado<br/>e autenticação, se houver<br/><b>Configuração:</b> values.yaml · ingress/tls + bbcert<br/><b>Autenticação:</b> ainda a confirmar"]
        C3["Ingress interno<br/>recebe a URL pública do serviço<br/><b>Configuração:</b> values.yaml · ingress"]
        C4["Service do Kubernetes<br/>porta 80 → targetPort 8080<br/>precisa estar habilitado<br/><b>Configuração:</b> values.yaml · service"]
        C5["Pod / Container<br/><b>Configuração:</b> values.yaml · deployment<br/><b>Imagem:</b> Dockerfile"]
        C6["Uvicorn recebe HTTP<br/>e entrega a requisição ao app ASGI<br/><b>Código:</b> __main__.py · main()/uvicorn.run()<br/><b>Runtime:</b> Uvicorn"]
        C1 --> C2 --> C3 --> C4 --> C5 --> C6
    end

    READY --> C6

    %% ================================================================
    %% 4. SELEÇÃO DA ROTA
    %% ================================================================
    subgraph ROUTING["4 — Primeira decisão da aplicação"]
        direction TB
        R1["Middleware recebe a requisição<br/>antes da função da rota<br/><b>Código:</b> utils/guardrails_middleware.py<br/><b>Classe/função:</b> GuardrailsMiddleware.dispatch()"]
        R2{"É exatamente<br/>POST /chat?<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> GuardrailsMiddleware.dispatch()"}
        R3["Encaminha sem os guardrails<br/>específicos do chat<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> dispatch() → call_next()"]
        R4{"FastAPI reconhece<br/>método e caminho?<br/><b>Registro:</b> app.py · decoradores @app<br/><b>Roteamento:</b> FastAPI/Starlette"}
        R5["Rotas operacionais e documentação<br/>health, ready, metrics, docs e redoc<br/><b>Código:</b> app.py · health_live()/health_ready()/metrics()<br/><b>Automático:</b> FastAPI · /docs e /redoc"]
        E404["Resposta padrão da API<br/>HTTP 404 ou HTTP 405<br/><b>Responsável:</b> roteador FastAPI/Starlette"]

        C6 --> R1 --> R2
        R2 -- "Não" --> R3 --> R4
        R4 -- "Sim" --> R5
        R4 -- "Não" --> E404
    end

    %% ================================================================
    %% 5. CONTRATO DE ENTRADA E GUARDRAILS
    %% ================================================================
    subgraph INPUT["5 — Entrada do POST /chat"]
        direction TB
        I0["Contrato atual do template<br/>message: texto obrigatório<br/>session_id: texto opcional<br/><b>Código:</b> app.py · classe ChatRequest"]
        I1["Inicia contador, span e cronômetro<br/>dos guardrails<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> GuardrailsMiddleware._guard_chat()"]
        I2["Lê o corpo HTTP bruto<br/>e preserva uma cópia para o FastAPI<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> _guard_chat() · request.body()/_replay_receive()"]
        I3["Tenta interpretar o JSON<br/>e extrai somente o campo message<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> _guard_chat() · json.loads()/body.get()"]
        I4{"Mensagem respeita<br/>o limite de tamanho?<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> _guard_chat() · _MAX_INPUT_LEN"}
        I5{"Foi detectado padrão<br/>de prompt injection / jailbreak?<br/><b>Código:</b> utils/filter_patterns.py<br/><b>Função:</b> check_injection()"}
        I6{"Bloqueio de dados pessoais está ativo<br/>e foi detectada PII?<br/><b>Código:</b> utils/filter_patterns.py<br/><b>Função:</b> contains_pii()"}
        I7["Consulta o guardrail externo<br/>quando estiver habilitado<br/><b>Código:</b> utils/genera_safe_guardrails.py<br/><b>Função:</b> check_external_guardrail()"]
        I8{"Guardrail externo<br/>rejeitou a mensagem?<br/><b>Código:</b> genera_safe_guardrails.py<br/><b>Função:</b> check_external_guardrail()"}
        I9["Falha técnica do guardrail externo<br/>não bloqueia a chamada: fail-open<br/><b>Código:</b> genera_safe_guardrails.py<br/><b>Função:</b> check_external_guardrail() · try/except"]
        I10["Entrada aprovada<br/>call_next encaminha ao FastAPI<br/>e o middleware aguarda a resposta<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> _guard_chat() → call_next()"]
        E400A["HTTP 400 — input_too_long<br/><b>Código:</b> guardrails_middleware.py · _blocked()"]
        E400B["HTTP 400 — prompt_injection<br/><b>Código:</b> guardrails_middleware.py · _blocked()"]
        E400C["HTTP 400 — pii_detected<br/><b>Código:</b> guardrails_middleware.py · _blocked()"]
        E400D["HTTP 400 — external_guardrail<br/><b>Código:</b> guardrails_middleware.py · _blocked()"]
        E400["Corpo de erro do guardrail<br/>error + code + detail<br/><b>Código:</b> guardrails_middleware.py · _blocked()"]

        R2 -- "Sim" --> I0 --> I1 --> I2 --> I3 --> I4
        I4 -- "Não" --> E400A --> E400
        I4 -- "Sim" --> I5
        I5 -- "Sim" --> E400B --> E400
        I5 -- "Não" --> I6
        I6 -- "Sim" --> E400C --> E400
        I6 -- "Não" --> I7 --> I8
        I8 -- "Sim" --> E400D --> E400
        I8 -- "Não / aprovado" --> I10
        I7 -. "Indisponível / erro" .-> I9 --> I10
    end

    %% ================================================================
    %% 6. VALIDAÇÃO DO CONTRATO E EXECUÇÃO DA ROTA
    %% ================================================================
    subgraph CHAT["6 — Validação e execução da rota /chat"]
        direction TB
        V1["FastAPI localiza a rota POST /chat<br/><b>Código:</b> app.py · @app.post('/chat')<br/><b>Função:</b> chat()"]
        V2["Pydantic valida o JSON<br/>tipos e campos obrigatórios<br/><b>Código:</b> app.py · classe ChatRequest<br/><b>Runtime:</b> FastAPI/Pydantic"]
        V3{"O corpo atende<br/>ao contrato ChatRequest?<br/><b>Código:</b> app.py · ChatRequest<br/><b>Validação:</b> Pydantic"}
        E422["HTTP 422<br/>JSON ausente/inválido, message ausente<br/>ou tipo incompatível<br/><b>Responsável:</b> FastAPI/Pydantic"]
        H1["Início da função chat<br/>incrementa contador global com lock<br/><b>Código:</b> app.py · chat()<br/><b>Objetos:</b> _request_count + _request_count_lock"]
        H2["Registra session_id no log<br/>e inicia o tempo da chamada<br/><b>Código:</b> app.py · chat()"]
        H3["Adapta apenas message<br/>para a entrada do processamento<br/><b>Código:</b> app.py · chat()<br/><b>Objeto:</b> HumanMessage + initial_state"]
        NOTE1["Limite atual do contrato<br/>session_id é apenas identificado e devolvido;<br/>não envia histórico nem cria memória<br/><b>Origem:</b> app.py · ChatRequest + chat()"]
        AGENT["PROCESSAMENTO DO AGENTE<br/>CAIXA-PRETA — FORA DO ESCOPO<br/>recebe a mensagem e devolve um resultado<br/><b>Única fronteira mostrada:</b> graph.py · AgentGraph.ainvoke()"]
        H4{"Processamento terminou<br/>sem exceção?<br/><b>Código:</b> app.py · chat() · try/except"}
        E500["HTTP 500<br/>Erro interno do servidor<br/>sem expor detalhes internos<br/><b>Código:</b> app.py · chat() → HTTPException"]
        H5["Recebe o resultado do processamento<br/><b>Código:</b> app.py · chat() · result"]
        H6["Seleciona a resposta final<br/>e converte o conteúdo para texto<br/><b>Código:</b> app.py · chat() · messages/raw_content/reply"]
        H7["Conta as chamadas de ferramentas<br/>e calcula o tempo decorrido<br/><b>Código:</b> app.py · chat() · tool_calls_made/elapsed_ms"]
        H8["Cria ChatResponse<br/>reply · session_id devolvido · tool_calls_made<br/><b>Código:</b> app.py · classe ChatResponse"]
        H9["FastAPI serializa o modelo<br/>como resposta JSON<br/><b>Contrato:</b> app.py · ChatResponse<br/><b>Runtime:</b> FastAPI/Pydantic"]

        I10 --> V1 --> V2 --> V3
        V3 -- "Não" --> E422
        V3 -- "Sim" --> H1 --> H2 --> H3 --> AGENT --> H4
        H3 -. "Regra do template" .-> NOTE1
        H4 -- "Não" --> E500
        H4 -- "Sim" --> H5 --> H6 --> H7 --> H8 --> H9
    end

    %% ================================================================
    %% 7. TRATAMENTO DA RESPOSTA PELO MESMO MIDDLEWARE
    %% ================================================================
    subgraph OUTPUT["7 — Volta da resposta pelo middleware"]
        direction TB
        O1["call_next termina<br/>e devolve a resposta ao middleware<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> GuardrailsMiddleware._guard_chat()"]
        O2{"Resposta é HTTP 200<br/>com conteúdo JSON?<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> _guard_chat()"}
        O3["Mantém a resposta como veio<br/>inclui erros 404, 405, 422 e 500<br/><b>Código:</b> guardrails_middleware.py · _guard_chat()"]
        O4["Lê o JSON e extrai reply<br/><b>Código:</b> guardrails_middleware.py<br/><b>Função:</b> _guard_chat() · json.loads()/payload.get()"]
        O5{"Reply contém expressão<br/>da lista de bloqueio?<br/><b>Código:</b> utils/filter_patterns.py<br/><b>Função:</b> check_output_blocklist()"}
        O6["Substitui reply por<br/>uma mensagem genérica segura<br/><b>Código:</b> guardrails_middleware.py · _guard_chat()"]
        O7{"Redação de dados pessoais<br/>está habilitada e encontrou PII?<br/><b>Código:</b> utils/filter_patterns.py<br/><b>Função:</b> redact_pii()"}
        O8["Substitui os dados pessoais<br/>por marcadores de redação<br/><b>Código:</b> utils/filter_patterns.py · redact_pii()"]
        O9["Mantém reply sem alteração<br/><b>Código:</b> guardrails_middleware.py · _guard_chat()"]
        O10["Reconstrói a resposta JSON<br/>e atualiza o tamanho do conteúdo<br/><b>Código:</b> guardrails_middleware.py · _guard_chat()<br/><b>Classe:</b> Starlette Response"]
        O11["Finaliza cronômetro e span<br/>e registra a latência total<br/><b>Código:</b> guardrails_middleware.py · _guard_chat() · finally"]

        H9 --> O1
        E422 --> O1
        E500 --> O1
        O1 --> O2
        O2 -- "Não" --> O3 --> O11
        O2 -- "Sim" --> O4 --> O5
        O5 -- "Sim" --> O6 --> O10
        O5 -- "Não" --> O7
        O7 -- "Sim" --> O8 --> O10
        O7 -- "Não" --> O9 --> O10
        O10 --> O11
        E400 --> O11
    end

    %% ================================================================
    %% 8. RESPOSTA AO CONSUMIDOR
    %% ================================================================
    subgraph RETURN["8 — Retorno ao sistema consumidor"]
        direction LR
        B1["Uvicorn converte a resposta ASGI<br/>em resposta HTTP<br/><b>Runtime:</b> Uvicorn<br/><b>Inicialização:</b> __main__.py · main()"]
        B2["Container :8080<br/><b>Configuração:</b> Dockerfile + values.yaml · deployment"]
        B3["Service :80<br/><b>Configuração:</b> values.yaml · service"]
        B4["Ingress / HTTPS<br/><b>Configuração:</b> values.yaml · ingress/tls + bbcert"]
        B5["Sistema consumidor recebe<br/>a resposta HTTP<br/><b>Responsável:</b> sistema externo"]
        BQ{"Qual foi o<br/>status HTTP?<br/><b>Responsável:</b> protocolo HTTP + consumidor"}
        B6["Sucesso HTTP 200<br/>reply + session_id + tool_calls_made<br/><b>Contrato:</b> app.py · classe ChatResponse"]
        B7["Erros possíveis<br/>400, 404, 405, 422, 500<br/>e 503 nas verificações de prontidão<br/><b>Origem:</b> middleware + app.py + FastAPI/Pydantic"]

        O11 --> B1 --> B2 --> B3 --> B4 --> B5 --> BQ
        R5 --> B1
        E404 --> B1
        BQ -- "200" --> B6
        BQ -- "Outro status" --> B7
    end

    %% ================================================================
    %% 9. OPERAÇÃO E OBSERVABILIDADE TRANSVERSAL
    %% ================================================================
    subgraph OPS["9 — Operação e observabilidade durante todo o ciclo"]
        direction LR
        X1["GET /health/live<br/>processo está vivo<br/><b>Código:</b> app.py · health_live()"]
        X2["GET /health/ready<br/>configuração e processamento estão prontos<br/><b>Código:</b> app.py · health_ready()"]
        X3["GET /metrics<br/>uptime, total de chamadas<br/>e identificação do serviço<br/><b>Código:</b> app.py · metrics() + MetricsResponse"]
        X4["Logs estruturados<br/>início, fim e erros<br/><b>Código:</b> app.py/graph.py/utils · logger.*()"]
        X5["Métricas<br/>requisições, bloqueios, redações e latência<br/><b>Código:</b> guardrails_middleware.py · Counter/Histogram<br/><b>Código:</b> app.py · _request_count"]
        X6["Tracing<br/>spans e atributos da chamada<br/><b>Código:</b> tracing.py · get_tracer()<br/><b>Código:</b> guardrails_middleware.py · _tracer"]
        X7["Exportação opcional<br/>Azure Monitor / Application Insights / OTLP<br/><b>Código:</b> tracing.py · configure_azure_monitor()<br/><b>Configuração:</b> variáveis OTEL/Azure"]

        X1 --> X4
        X2 --> X4
        X3 --> X5
        X4 --> X7
        X5 --> X7
        X6 --> X7
    end

    R5 -. "Seleciona conforme a rota" .-> X1
    R5 -. "Seleciona conforme a rota" .-> X2
    R5 -. "Seleciona conforme a rota" .-> X3
    S7 -. "Configura" .-> X4
    S7 -. "Configura" .-> X5
    S7 -. "Configura" .-> X6
    I1 -. "Registra" .-> X5
    I1 -. "Registra" .-> X6
    H2 -. "Registra" .-> X4
    O11 -. "Conclui" .-> X5
    O11 -. "Conclui" .-> X6

    %% ================================================================
    %% DESTAQUES VISUAIS
    %% ================================================================
    classDef boundary stroke-width:3px,stroke-dasharray:7 4;
    classDef decision stroke-width:2px;
    classDef error stroke-width:2px,stroke-dasharray:3 2;
    classDef ready stroke-width:3px;
    classDef note stroke-dasharray:5 4;

    class AGENT boundary;
    class R2,R4,S13,I4,I5,I6,I8,V3,H4,O2,O5,O7,BQ decision;
    class E400A,E400B,E400C,E400D,E400,E404,E422,E500,S14 error;
    class READY,B6 ready;
    class NOTE1 note;
```

O diagrama representa o contrato atual do template. A origem da chamada, a autenticação e a eventual presença de outros campos ainda precisam ser confirmadas com o sistema responsável pela integração.
