# Catálogo de Evaluation Dimensions

| Conceito | Categoria | Tipo | Descrição | Obrigatório | Pode virar Guardrail | Direção |
|---|---|---|---|---|---|---|
| Topic Adherence | Aderência | Evaluation Dimension | Avalia se a resposta permanece dentro do tema e do escopo solicitado pelo usuário. | Não | Sim | Maior é melhor |
| Answer Relevance | Qualidade | Evaluation Dimension | Mede o quanto a resposta é diretamente relevante para a pergunta ou necessidade apresentada. | Não | Possível | Maior é melhor |
| Average Precision | Classificação / Ranking | Metric | Resume a precisão obtida ao longo de diferentes níveis de recall, sendo útil em classificação e recuperação ranqueada. | Não | Não | Maior é melhor |
| Bias | Safety / Fairness | Evaluation Dimension | Detecta vieses indevidos, estereótipos ou tratamento desigual em relação a grupos ou características. | Não | Sim | Menor é melhor |
| Bleu Score | Similaridade | Metric | Mede sobreposição de n-grams entre uma resposta gerada e um texto de referência. | Não | Não | Maior é melhor |
| ChrF Score | Similaridade | Metric | Mede similaridade entre textos com base em n-grams de caracteres. | Não | Não | Maior é melhor |
| Code Vulnerability | Segurança técnica | Evaluation Dimension | Avalia se código produzido ou analisado contém vulnerabilidades, padrões inseguros ou riscos conhecidos. | Não | Sim | Menor é melhor |
| Coherence | Qualidade | Evaluation Dimension | Avalia se as ideias da resposta são apresentadas de forma organizada, conectada e compreensível. | Não | Possível | Maior é melhor |
| Completeness | Qualidade | Evaluation Dimension | Mede se a resposta cobre todos os elementos necessários para atender adequadamente à solicitação. | Não | Possível | Maior é melhor |
| Compliance Risk | Compliance | Evaluation Dimension | Avalia o risco de a resposta violar políticas internas, requisitos regulatórios ou regras de negócio. | Não | Sim | Menor é melhor |
| Context Precision | Contexto / RAG | Evaluation Dimension | Mede a proporção das informações recuperadas no contexto que são efetivamente relevantes para responder à pergunta. | Não | Não | Maior é melhor |
| Context Recall | Contexto / RAG | Evaluation Dimension | Mede quanto das informações relevantes necessárias para responder foi recuperado ou fornecido no contexto. | Não | Não | Maior é melhor |
| Context Relevance | Contexto / RAG | Evaluation Dimension | Avalia se o contexto fornecido ou recuperado é relevante para a pergunta atual. | Não | Não | Maior é melhor |
| User Frustration | Experiência do usuário | Evaluation Dimension | Detecta sinais de frustração, insatisfação, impaciência ou dificuldade do usuário durante a interação. | Não | Possível | Menor é melhor |
| Usefulness | Qualidade / UX | Evaluation Dimension | Avalia o quanto a resposta ajuda efetivamente o usuário a alcançar seu objetivo. | Não | Não | Maior é melhor |
| Toxicity | Safety | Evaluation Dimension | Detecta conteúdo tóxico, ofensivo, abusivo, hostil ou potencialmente prejudicial. | Sim | Sim | Menor é melhor |
| Tool Output Utilization | Agentes / Tools | Evaluation Dimension | Avalia se o agente utilizou corretamente e de forma suficiente o conteúdo retornado pelas ferramentas. | Não | Possível | Maior é melhor |
| Tool Correctness | Agentes / Tools | Evaluation Dimension | Avalia se a ferramenta escolhida e sua utilização são adequadas para a tarefa executada. | Não | Sim | Maior é melhor |
| Tool Call Success | Agentes / Tools | Evaluation Dimension | Mede se uma chamada de ferramenta foi executada com sucesso, sem erros técnicos ou funcionais. | Não | Possível | Maior é melhor |
| Tool Call Efficiency | Agentes / Tools | Evaluation Dimension | Avalia se o agente utiliza ferramentas de forma eficiente, evitando chamadas redundantes ou desnecessárias. | Não | Não | Maior é melhor |
| Tone | Experiência do usuário | Evaluation Dimension | Avalia se o tom adotado é adequado ao contexto, público, papel e instruções do sistema. | Não | Possível | Maior é melhor |
| Text Reading Ease | Legibilidade | Metric | Mede a facilidade de leitura do texto produzido por meio de fórmulas de legibilidade. | Não | Não | Maior geralmente é melhor |
| Text Grade Level | Legibilidade | Metric | Estima o nível educacional necessário para compreender o texto apresentado. | Não | Não | Depende do público-alvo |
| Task Completion | Agentes / Aderência | Evaluation Dimension | Avalia se o sistema conseguiu concluir integralmente a tarefa solicitada pelo usuário. | Não | Possível | Maior é melhor |
| Summarization | Qualidade | Evaluation Dimension | Avalia a qualidade de um resumo quanto à cobertura, concisão, fidelidade e relevância. | Não | Não | Maior é melhor |
| String Similarity | Similaridade | Metric | Mede a similaridade textual ou lexical entre duas strings. | Não | Não | Maior é melhor |
| String Presence | Estrutura / Validação | Check | Verifica se determinada palavra, expressão ou sequência de caracteres está presente ou ausente na saída. | Não | Sim | Depende da regra |
| Spearman Ranking | Ranking | Metric | Mede a correlação entre duas ordenações usando o coeficiente de correlação de postos de Spearman. | Não | Não | Maior é melhor |
| Sexual Content | Safety | Evaluation Dimension | Detecta conteúdo sexual, sexualmente explícito ou inadequado de acordo com a política definida. | Não | Sim | Menor é melhor |
| Sentiment | NLP / UX | Evaluation Dimension | Classifica ou mede a polaridade emocional do texto, como positiva, neutra ou negativa. | Não | Possível | Depende do caso |
| Semantic Similarity | Similaridade | Metric | Mede o grau de proximidade de significado entre dois textos, independentemente da correspondência literal. | Não | Não | Maior é melhor |
| Secrets Present | Segurança / Privacidade | Evaluation Dimension | Detecta exposição de segredos como senhas, tokens, chaves de API, certificados ou credenciais. | Não | Sim | Menor é melhor |
| Rouge Score | Similaridade | Metric | Mede sobreposição entre texto gerado e referência, sendo especialmente utilizado para avaliação de sumarização. | Não | Não | Maior é melhor |
| Role Adherence | Aderência | Evaluation Dimension | Avalia se o agente permanece dentro do papel, persona ou responsabilidade atribuída nas instruções. | Não | Sim | Maior é melhor |
| Regex Match | Estrutura / Validação | Check | Verifica se a saída corresponde a um padrão definido por expressão regular. | Não | Sim | Passa / Falha |
| Reciprocal Rank | Ranking / Retrieval | Metric | Mede a posição do primeiro resultado relevante em uma lista ranqueada por meio do inverso dessa posição. | Não | Não | Maior é melhor |
| Protected Materials | Compliance / Propriedade Intelectual | Evaluation Dimension | Detecta exposição, reprodução ou utilização inadequada de conteúdo protegido por direitos autorais ou outras restrições. | Não | Sim | Menor é melhor |
| Prompt Uncertainty | Incerteza | Evaluation Dimension | Avalia se a solicitação do usuário possui ambiguidade, insuficiência de informações ou múltiplas interpretações plausíveis. | Não | Possível | Depende do caso |
| Plan Quality | Agentes | Evaluation Dimension | Avalia se o plano elaborado pelo agente é lógico, adequado, completo, seguro e executável. | Não | Possível | Maior é melhor |
| Plan Adherence | Agentes | Evaluation Dimension | Mede se a execução do agente permanece alinhada ao plano previamente definido. | Não | Possível | Maior é melhor |
| PII Leakage | Privacidade | Evaluation Dimension | Detecta exposição indevida de informações pessoais identificáveis em entradas, contexto ou respostas. | Não | Sim | Menor é melhor |
| NonAdvice | Compliance / Financeiro | Evaluation Dimension | Avalia se o agente evita fornecer aconselhamento financeiro, jurídico ou outro aconselhamento regulado quando não autorizado. | Sim | Sim | Maior é melhor |
| Noise Sensitivity | Contexto / Robustez | Evaluation Dimension | Avalia quanto informações irrelevantes ou ruidosas no contexto prejudicam o desempenho ou a resposta do modelo. | Não | Não | Menor é melhor |
| Misuse | Safety | Evaluation Dimension | Detecta solicitações ou respostas relacionadas ao uso indevido, abusivo, perigoso ou não autorizado do sistema. | Não | Sim | Menor é melhor |
| METEOR | Similaridade | Metric | Mede similaridade entre resposta e referência considerando correspondência lexical, variações e alinhamento textual. | Não | Não | Maior é melhor |
| Logical Consistency | Qualidade | Evaluation Dimension | Avalia se a resposta mantém consistência lógica e não apresenta contradições internas relevantes. | Não | Possível | Maior é melhor |
| Language Adherence | Aderência | Evaluation Dimension | Verifica se o agente respondeu no idioma, variante linguística ou padrão solicitado. | Não | Sim | Maior é melhor |
| Knowledge Retention | Contexto / Memória | Evaluation Dimension | Avalia se o sistema preserva e utiliza corretamente informações relevantes fornecidas anteriormente. | Não | Possível | Maior é melhor |
| KL Divergence | Distribuição / Estatística | Metric | Mede a divergência entre duas distribuições de probabilidade, indicando o quanto uma difere da outra. | Não | Não | Menor é melhor |
| Json Correctness | Estrutura / Validação | Check | Verifica se a saída é um JSON válido e, quando aplicável, compatível com o schema esperado. | Não | Sim | Passa / Falha |
| JS Divergence | Distribuição / Estatística | Metric | Mede a diferença entre distribuições de probabilidade de forma simétrica e limitada, baseada na divergência de Jensen-Shannon. | Não | Não | Menor é melhor |
| Hit Rate | Retrieval / Ranking | Metric | Mede a frequência com que pelo menos um item relevante aparece dentro dos resultados recuperados. | Não | Não | Maior é melhor |
| Hallucination | Grounding / Factualidade | Evaluation Dimension | Detecta informações inventadas, sem suporte no contexto ou apresentadas como fatos sem fundamento adequado. | Não | Sim | Menor é melhor |
| Guidelines | Aderência / Compliance | Evaluation Dimension | Avalia se a resposta respeita as guidelines, regras ou critérios específicos definidos para o caso de uso. | Não | Sim | Maior é melhor |
| Fluency | Qualidade | Evaluation Dimension | Avalia naturalidade, clareza linguística, gramática e fluidez da resposta. | Não | Não | Maior é melhor |
| Faithfulness | Grounding / Factualidade | Evaluation Dimension | Avalia se as afirmações da resposta estão sustentadas pelas informações presentes no contexto ou fontes utilizadas. | Não | Sim | Maior é melhor |
| F1 Score | Classificação | Metric | Calcula a média harmônica entre Precision e Recall para avaliar tarefas de classificação ou extração. | Não | Não | Maior é melhor |
| Exact Match | Similaridade / Validação | Metric | Verifica se a saída corresponde exatamente ao valor ou resposta de referência. | Não | Possível | Maior é melhor |
| Evasiveness | Qualidade / Comportamento | Evaluation Dimension | Avalia se o agente evita responder de forma desnecessária, vaga ou indireta quando poderia responder adequadamente. | Não | Possível | Menor é melhor |
| Detect Jailbreak | Segurança | Evaluation Dimension | Detecta tentativas de contornar instruções, políticas de segurança ou restrições impostas ao agente. | Não | Sim | Menor é melhor |
| Correctness | Qualidade | Evaluation Dimension | Avalia se a resposta, conclusão ou ação produzida pelo sistema está correta em relação ao esperado ou à realidade factual. | Não | Sim | Maior é melhor |
| Conversation Degeneration | Conversação / Robustez | Evaluation Dimension | Detecta degradação progressiva da conversa, como repetição excessiva, perda de contexto, incoerência ou ciclos improdutivos. | Não | Possível | Menor é melhor |

## Estrutura conceitual recomendada

```text
Evaluation
├── Category
├── Dimension
│   ├── name
│   ├── description
│   ├── mandatory
│   ├── direction
│   └── guardrail_capable
├── Evaluator
│   ├── implementation
│   ├── model
│   ├── version
│   └── configuration
├── Result
│   ├── score
│   ├── label
│   ├── passed
│   └── reason
└── Policy / Guardrail
    ├── threshold
    ├── condition
    └── action
```
