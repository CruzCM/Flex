# Diário de evolução do AGENTE MINHAS FINANÇAS

## 2026-10-15 — Preparação inicial do primeiro deploy técnico do agente

- **Tarefa/etapa:** preparação do primeiro deploy técnico na branch `feat/primeiro-deploy-agente`.
- **Responsável pela decisão:** usuário do projeto; aprovação recebida na conversa para continuar o processo.
- **Antes:** `iaa-agent-minhas-financas-main/aic.json` declarava Python 3.8, enquanto `setup.py` e `Dockerfile` exigem Python 3.11. No chart externo de homologação, o Service estava desabilitado e `deployment.containers.envFrom` estava vazio, embora o snapshot local do OpenShift registre o Secret `env` com `GATEWAY_OUTBOUND_GW_APP_KEY`.
- **Depois:** o `aic.json` passa a declarar Python 3.11; o Service do chart externo é habilitado; o Deployment passa a referenciar o Secret `env`. A versão do pacote permanece `0.1.0.dev0` para a branch de desenvolvimento. A URL do Gateway de homologação e a publicação da imagem permanecem pendentes de confirmação. As cópias internas duplicadas não foram utilizadas nem alteradas.
- **Motivo e impacto:** alinhar a versão da esteira com o runtime do projeto, criar o Service necessário ao roteamento interno e tornar disponível ao container a AppKey já registrada no OpenShift. Não houve alteração de API, payload, contrato, cálculo financeiro, MCP, RAG ou certificados. As mudanças são reversíveis por configuração.
- **Evidência:** inspeção estática dos arquivos locais; validação anterior de sintaxe em Python, YAML e JSON sem erros. Nenhum acesso ao OpenShift, build, deploy ou integração corporativa foi executado nesta cópia.
- **Pendências e gates:** confirmar `LLM_GATEWAY_BASE_URL` de homologação; confirmar a esteira responsável pela publicação da imagem e o comportamento de `publicarPacoteEImagem`; validar a referência do Secret no Deployment real; executar a validação local autorizada; obter evidência corporativa de build, deploy e smoke test. A SDD e os registros CONF/DEP/CR continuam ausentes nesta cópia.

## 2026-10-15 — Etapa 1: Configuração LLM para HML (agent_config.yaml)

- **Tarefa/etapa:** Etapa 1 — Configuração LLM para HML (preparação incremental do primeiro deploy em HML / Plano B).
- **Responsável pela decisão:** usuário do projeto; aprovação explícita registrada na instrução anterior para a Etapa 1.
- **Antes:** `iaa-agent-minhas-financas-main/agent_config.yaml` definia `gateway_url` com fallback padrão para desenv: `"${LLM_GATEWAY_BASE_URL:https://llms-agentes-ia.outbound.api.desenv.bb.com.br/v1}"`. Não havia menção documental ao modelo legado da codebase anterior (`cambio-non-prod-gpt4o`).
- **Depois:** `agent_config.yaml` passa a ter o fallback de `gateway_url` apontando para homologação: `"${LLM_GATEWAY_BASE_URL:https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1}"`. Foi adicionado comentário documentando que o modelo `cambio-non-prod-gpt4o` era utilizado na codebase anterior e poderá ser recuperado futuramente caso necessário. `gpt-5-mini` permanece como profile padrão. Nenhum arquivo Python (`factory.py`, `gateway_outbound.py`, `config.py`, etc.), MCP, RAG ou Guardrails foi alterado. Nenhuma Secret foi adicionada.
- **Motivo e impacto:** viabilizar fallback gracioso do agente para o Gateway Outbound de homologação caso a variável `LLM_GATEWAY_BASE_URL` não esteja cadastrada no OpenShift, preservando a precedência caso a variável de ambiente seja fornecida. Compatibilidade mantida. Risco registrado: o template envia incondicionalmente `temperature=0.7` via `ChatOpenAI`; se o backend corporativo do Gateway Outbound para `gpt-5-mini` rejeitar customização de temperatura (comportamento de modelos reasoning puros), haverá erro HTTP 400 em HML a ser validado no primeiro teste integrado real. Reversibilidade imediata restaurando a URL no YAML.
- **Evidência:** validação local executada com sucesso via script de teste (`load_agent_config` e `validate_config`), comprovando: (1) resolução de `base_url` para `https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1/openai/deployments/gpt-5-mini` sem variáveis de ambiente; (2) sobrescrita e precedência garantida quando `LLM_GATEWAY_BASE_URL` é definida no ambiente; (3) validação estrutural `validate_config(cfg)` retornando `True`. Nenhum acesso a ambiente externo corporativo foi realizado.
- **Pendências e gates:** teste real em HML de chamada à LLM para confirmar se o deployment `gpt-5-mini` está provisionado no Gateway Outbound HML e se aceita a requisição com `temperature=0.7` e `api-version=2024-12-01-preview`; confirmação da Secret `env` e certificados mTLS no cluster.

## 2026-10-15 — Finalização da codebase: Ajuste de versão base no __init__.py

- **Tarefa/etapa:** Finalização da codebase do Agente Minhas Finanças para o primeiro deploy em homologação.
- **Responsável pela decisão:** usuário do projeto; aprovação explícita concedida na instrução para atualizar `__init__.py` para `0.1.0` com comentário sobre branches de desenvolvimento.
- **Antes:** `iaa-agent-minhas-financas-main/iaa_agent_minhas_financas/__init__.py` continha `__version__ = '0.1.0.dev0'`. O `setup.py` lia essa versão por expressão regular.
- **Depois:** `__init__.py` passa a declarar `__version__ = "0.1.0"` e inclui comentário orientando o uso do sufixo `.devN` em futuras branches de desenvolvimento. A versão exposta pelo pacote em runtime agora é `"0.1.0"`. Nenhum outro arquivo de versionamento, lógica de negócio, infraestrutura ou integrações (MCP, RAG, Guardrails) foi alterado.
- **Motivo e impacto:** estabilizar a versão base de entrega da aplicação para o primeiro deploy em homologação, alinhando o `__init__.py` com o campo `metadata.version` de `agent_config.yaml` (`0.1.0`). Sem impacto em contratos de API ou modelos de dados. Reversibilidade trivial via edição de texto.
- **Evidência:** validação local executada com sucesso via Python 3.13: (1) `py_compile` validou a sintaxe do `__init__.py`; (2) importação do módulo `iaa_agent_minhas_financas` confirmou `__version__ == "0.1.0"`; (3) teste de regex do `setup.py` confirmou extração correta de `"0.1.0"`; (4) revalidação do carregamento de `agent_config.yaml` e execução de `validate_config(cfg)` com retorno `True`. Limitação: suíte `pytest` completa não foi executada no host Windows por ausência das dependências corporativas instaladas globalmente (estas são providas dentro do container Docker / esteira CI/CD).
- **Pendências e gates:** execução do build da imagem e testes integrados no pipeline corporativo; smoke test em HML.

## 2026-10-15 — Etapa 5: integração Agente → MCP para HML

- **Tarefa e aprovação:** implementação do `PLANO-INTEGRACAO-AGENTE-MCP-HML-REVISADO.md`,
  aprovada expressamente pelo usuário na conversa, incluindo `.env` sem credenciais,
  dependências já declaradas, guia para iniciantes, testes e Flake8. Responsável pela
  decisão: usuário do projeto. Nenhum identificador de aprovação foi presumido.
- **Antes verificado:** na cópia principal `iaa-agent-minhas-financas-main`, o YAML
  ativava `local-mcp`, deixava o endpoint corporativo sem fallback e tinha instruções
  genéricas. `AgentFactory` já descobria ferramentas por servidor, mas oferecia todas.
  `app.py` recebia `message`/`session_id` e devolvia `reply`, `session_id` e
  `tool_calls_made`. O grafo não tinha checkpointer nem histórico persistido por sessão.
  O header `gw-dev-app-key`, mTLS, telemetria e guardrails já existiam.
- **Depois:** `agent_config.yaml` usa o gateway MCP HML como fallback e orienta FAQ ×
  Educação, respostas fundamentadas e tratamento de falhas. Somente a entrada ativa
  `local-mcp` foi retirada da configuração HML; nenhuma implementação foi removida.
  `graph.py` filtra apenas o servidor `mcp-corporativo`, usa o mesmo catálogo no modelo
  e no `ToolNode` e expõe a descoberta como tupla de nomes. Os outros servidores e o
  RAG legado conservam o comportamento anterior. A topologia não foi alterada.
- **Contrato aditivo:** `app.py` aceita `incluir_diagnostico_mcp=false` por padrão.
  Sem opt-in, o JSON permanece com seus três campos anteriores, inclusive
  `session_id: null`; o diagnóstico não aparece. Com opt-in, correlaciona
  `AIMessage.tool_calls` e `ToolMessage.tool_call_id` no turno corrente. Lê JSON
  textual, blocos e `artifact.structured_content`, observados no adaptador 0.3.2.
  `execucoes` preserva todos os resultados correlacionados e os campos simples
  resumem o último. O significado de `tool_calls_made` foi mantido.
- **Ajuste mínimo ao fluxo real:** uma exceção de transporte pode interromper
  `ainvoke` antes de retornar mensagens. Somente com diagnóstico, a fachada consome
  `astream(stream_mode="values")` do mesmo grafo, conservando callbacks e metadados
  OTel e guardando o último estado em lista local à requisição. Erros HTTP conservam
  status e `detail`; acrescentam diagnóstico opt-in. Chamadas sem resultado ficam
  em `chamadas_sem_resultado` com `sem_retorno`, fora das execuções confirmadas.
  Não foram criados nós, serviços, clientes alternativos, classes ou dependências.
- **Retornos desconhecidos e segurança:** `erro_execucao` e
  `retorno_nao_interpretavel` são classificações locais, documentadas, com contagem
  `null` quando desconhecida. Status públicos são aceitos por lista fechada conforme
  o código MCP inspecionado; o diagnóstico não copia mensagens, contextos, headers,
  credenciais ou exceções. Tentativas sem resultado não comprovam execução remota.
- **Arquivos complementares:** criado `tests/unit/test_mcp_hml.py`; criado `.env`
  local a partir de `.env.example`, com endpoint HML e credenciais vazias, protegido
  pelas exclusões Git/Docker existentes. Criados guia e relatório na raiz; atualizado
  o changelog do pacote. O exemplo e as cópias internas duplicadas ficaram intactos.
- **Compatibilidade e reversão:** versão `0.1.0`, endpoints anteriores, autenticação,
  certificados, telemetria, guardrails, MCP, Helm, GitOps, pipelines e
  `publicarPacoteEImagem: false` preservados. Consumidores antigos não precisam
  alterar requisições. A reversão restaura os três arquivos funcionais arquivados
  antes da edição; guia/testes/registros acompanham a entrega, sem apagar histórico.
- **Evidências locais:** dependências declaradas instaladas em ambiente isolado com
  Python 3.11.9, sem alterar manifests. Baseline: 156 testes aprovados. Entrega:
  228 testes aprovados, dos quais 72 novos, incluindo o adaptador MCP e o `ToolNode`
  reais com serviços simulados. Flake8 dos três arquivos Python novos/alterados:
  saída 0. Varredura geral: somente `__init__.py:4:1 W391`, igualmente presente antes;
  arquivo não alterado. `pip check`: sem inconsistências. Logs e comandos constam
  no relatório. Falhas iniciais de pasta temporária e OpenSSL fora do PATH foram
  resolvidas no ambiente de execução, sem alterar código ou testes legados.
- **Limitações e gates:** esta cópia não tem metadados Git nem SDD/CONF/DEP/CR.
  A comparação usa originais arquivados e SHA-256, sem alegar `git diff`.
  O MCP e os serviços corporativos não foram acessados. Ficam para HML a AppKey
  autorizada, Secret carregada, certificados, endpoint efetivo, imagem/digest novo,
  disponibilidade das bases e seleção semântica real da LLM no Insomnia.
  A tag histórica do chart (`0.1.0.dev0`) e a publicação desabilitada permanecem
  intactas; a entrega da imagem deve ser confirmada pela esteira responsável.
  Nenhum push, merge ou deploy foi executado.

## 2026-10-16 — Organização final da entrega da Etapa 5

- **Tarefa e aprovação:** usuário do projeto autorizou expressamente mover o guia
  para a raiz do agente, ajustar links, atualizar a comparação e excluir somente
  os temporários inventariados. Sem autorização para mudar a integração funcional.
- **Antes verificado:** o guia estava na raiz do workspace e não havia arquivo
  com o mesmo nome no destino. O patch incluía também registros externos ao agente.
  O ambiente Python 3.13 antigo, cinco diretórios temporários de testes e sete
  caches do agente ainda existiam após a rejeição anterior da limpeza.
- **Depois:** guia movido para
  `iaa-agent-minhas-financas-main/GUIA-CONFIGURACAO-AGENTE-MCP-HML.md`, sem sobrescrita.
  Links internos usam caminhos relativos; documentos do MCP e de revisão externa
  são identificados pelo nome e localização, sem inventar URLs. Instruções de
  OpenShift e Insomnia preservadas. Relatório e manifesto ajustados; o patch
  compara somente os seis arquivos aprovados para merge, com o guia no agente.
  Este diário, relatório, originais e evidências continuam fora do repositório.
- **Motivo e impacto:** reduzir o material do merge ao escopo aprovado, mantendo
  rastreabilidade local. Nenhuma alteração em código, testes, dependências, API,
  autenticação, configurações executáveis, MCP, infraestrutura ou pasta duplicada.
  Preservados versão `0.1.0`, `publicarPacoteEImagem: false`, `.env` privado e
  ambiente `.venv-etapa5-py311`. Reversão documental possível pelos originais
  da entrega e pelo registro desta movimentação, sem substituir o template.
- **Evidência:** comparação estática SHA-256 confirmou os cinco arquivos já
  entregues no agente inalterados e os mesmos 153 originais preservados.
  Conferidos destino do guia, ausência de links locais absolutos, existência
  do link relativo, versão, publicação desabilitada e exclusões de `.env`.
  `git apply --check ../alteracoes.patch` no diretório dos originais e
  `markdownlint` do guia/relatório, com `--disable MD013 --` como antes,
  retornaram saída 0. Conferidas também as 103 cópias originais arquivadas.
  Nenhum teste ou Flake8 foi repetido: não houve alteração executável.
- **Limpeza pendente:** a revisão automática rejeitou o comando de exclusão antes
  da execução com `blocked by policy`, sem motivo adicional. Nada foi excluído
  e a proteção não foi contornada. Os 13 caminhos permanecem listados no
  `RELATORIO-ENTREGA-ETAPA5-MCP-HML.md`, fora do patch e da seleção de merge;
  os caches internos continuam ignorados pelo `.gitignore` existente.
- **Pendências e gates:** remoção local dos temporários ainda pendente. Permanecem
  as validações corporativas já registradas para AppKey, Secret, certificados,
  imagem e uso real no Insomnia. Nenhum serviço corporativo foi acessado e nenhum
  push, merge ou deploy foi realizado. SDD/CONF/DEP/CR seguem ausentes nesta cópia.

## 2026-10-16 — Revisão final dos projetos e tentativa de limpeza segura

- **Tarefa e aprovação:** usuário do projeto autorizou a limpeza de resíduos
  comprovadamente temporários e a resolução da duplicação após comprovação,
  preservando implementações, versões, ambientes úteis e evidências. Aprovação
  recebida na instrução de organização final, sem identificador presumido.
- **Antes verificado:** projetos Agente, MCP e deploys independentes; guias nas
  raízes corretas; cópia interna do agente e temporários ainda presentes.
  Comparação recursiva por nomes/SHA-256 encontrou 51 arquivos na cópia interna:
  45 idênticos, seis versões anteriores e nenhum exclusivo. Seus arquivos
  coincidem com a cópia arquivada nas evidências. Não foram encontradas referências
  explícitas à pasta nos arquivos locais de código, testes, scripts ou build.
- **Conclusão sobre a duplicação:** a cópia interna é dispensável para a aplicação
  principal. O `COPY . /app` poderia carregá-la para a imagem, sem utilizá-la como
  dependência. Sua remoção não apagaria o pacote legítimo com sublinhados nem a
  cópia arquivada. Não foi possível determinar commit de origem sem metadados Git.
- **Execução e resultado:** foi tentada a exclusão delimitada da cópia interna,
  `.venv-etapa5`, cinco diretórios `tmp-*`, sete caches do agente e oito caches
  do MCP. O comando verificava limites do workspace e links antes de remover.
  A revisão automática rejeitou o comando antes da execução, com
  `blocked by policy`, sem motivo adicional. Nada foi excluído ou movido;
  não houve tentativa de contorno. Os 22 caminhos permanecem no relatório.
- **Depois:** atualizado somente o relatório existente para registrar comparação,
  exclusões inspecionadas, resultado bloqueado e seleção de merge; acrescentada
  esta entrada e sincronizados os hashes desses registros no manifesto local.
  O patch funcional e seus seis arquivos permanecem preservados. Não foram
  criados documentos, funcionalidades, testes ou estruturas adicionais.
- **Motivo e impacto:** deixar explícito o que está pronto para merge e o que
  permanece como resíduo local por bloqueio do ambiente. Compatibilidade, APIs,
  ferramentas, dados e dependências não mudaram. Atualização documental
  reversível; originais, logs, `.env` privados e ambientes úteis preservados.
- **Exclusões e limitações:** os `.gitignore` e `.dockerignore` dos dois projetos
  protegem os `.env` e `.venv` de suas raízes; caches/bytecode são ignorados no Git.
  Cobertura recursiva incompleta no contexto Docker foi registrada com proposta
  mínima, sem editar configurações ou ampliar os seis arquivos do merge.
  A consulta WMI de processos foi negada; `Get-Process` não encontrou processos
  Python/pip e `VIRTUAL_ENV` estava vazio. Os registros finais usam Python 3.11.
- **Evidência:** comparação recursiva e leitura de scripts, pipelines e registros;
  conferidos guias sem links locais absolutos e preservação das versões
  `0.1.0`/`0.0.1`, publicação desabilitada e separação dos projetos. Não houve
  nova execução da suíte de testes ou Flake8 por inexistir alteração executável.
  Conferência final confirmou os seis arquivos e o patch inalterados, 103 cópias
  arquivadas intactas e os 22 diretórios pendentes ainda presentes.
  `git apply --check ../alteracoes.patch` nos originais e `markdownlint` do
  relatório com `--disable MD013 --` retornaram saída 0.
- **Pendências e gates:** limpeza física dos 22 caminhos ainda bloqueada;
  integração pronta para revisão/merge dos seis arquivos. Em HML permanecem
  AppKey autorizada, Secrets/variáveis/certificados, imagem efetiva, gateway e
  testes reais no Insomnia. Nenhum acesso corporativo, push, merge ou deploy.
  SDD/CONF/DEP/CR seguem ausentes nesta cópia.
