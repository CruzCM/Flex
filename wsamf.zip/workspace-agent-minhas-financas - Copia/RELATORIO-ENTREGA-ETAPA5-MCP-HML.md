# Entrega local — Etapa 5: integração Agente → MCP HML

Implementação local concluída com base no plano revisado aprovado pelo usuário.
O aceite local passou: **228 testes aprovados**, incluindo **72 novos**, e
**Flake8 sem erros nos arquivos Python novos/alterados**. A versão continua
`0.1.0`. A homologação real permanece a cargo do usuário no Insomnia após o merge.

## 1. Arquivos da entrega

Somente os seis arquivos abaixo compõem o merge desta entrega. Os caminhos são
relativos a `iaa-agent-minhas-financas-main/`; os demais arquivos preexistentes
do projeto permanecem preservados.

| Arquivo | Mudança |
| --- | --- |
| `agent_config.yaml` | Fallback MCP HML, instruções FAQ/Educação, retirada da entrada ativa `local-mcp` somente da configuração HML |
| `iaa_agent_minhas_financas/graph.py` | Filtro por servidor, catálogo de descoberta e captura opt-in do estado da requisição |
| `iaa_agent_minhas_financas/app.py` | Flag opcional, parsing seguro e diagnóstico correlacionado ao resultado real |
| `tests/unit/test_mcp_hml.py` | Novo: 72 cenários parametrizados e testes de integração local |
| `CHANGELOG.md` | Registro da integração na seção não liberada, sem alterar versão |
| `GUIA-CONFIGURACAO-AGENTE-MCP-HML.md` | Guia movido para a raiz do agente: configuração gráfica do OpenShift, testes Insomnia e checklist |

O `.env` permanece somente local, na raiz do agente, protegido pelas exclusões
Git/Docker existentes e fora do patch. Contém endpoints HML e credenciais vazias.

Na raiz do workspace, fora do merge:

| Arquivo | Mudança |
| --- | --- |
| `CHANGELOG-AGENTE-MINHAS-FINANCAS.md` | Entrada completa de antes/depois, aprovação, evidência e pendências |
| `RELATORIO-ENTREGA-ETAPA5-MCP-HML.md` | Este relatório |
| `evidencias-etapa5/` | Originais, hashes, comparação, logs e executor offline; não é código da aplicação |

**Sem Git nesta cópia:** não foi produzido nem alegado um `git diff`.
A [comparação unificada](evidencias-etapa5/alteracoes.patch) foi gerada por
`difflib.unified_diff` contra os arquivos arquivados **antes da edição** e foi
atualizada para conter somente os seis arquivos do merge, incluindo o guia
na localização definitiva dentro do agente.
O [manifesto anterior](evidencias-etapa5/sha256-antes.json) permite verificar
integridade dos originais e ausência de mudanças fora do escopo.
O [manifesto de alterações](evidencias-etapa5/alteracoes.json) lista hashes
anteriores/posteriores e arquivos novos. Nenhum arquivo original foi apagado.

O `.env` não integra o patch destinado ao código: sua preparação está na
[comparação local separada](evidencias-etapa5/env-local.diff), sem credenciais.
Não leve `.env`, ambientes virtuais, certificados de teste nem o diretório de
originais arquivados ao commit corporativo.

## 2. Comportamento e interfaces

O servidor configurado `mcp-corporativo` agora tem o fallback:

```text
https://iaa-mcp-mf.ai-interno.api.hm.bb.com.br/v1/mcp
```

`MCP_CTL_ENDPOINT` não vazia continua prevalecendo. O header existente
`gw-dev-app-key` usa `MCP_APP_KEY`; não foram alterados mTLS, certificados,
headers, timeouts ou a lógica de autenticação do cliente.

Somente as duas ferramentas RAG desse servidor entram no catálogo final.
Ferramentas de outros servidores, inclusive uma `ping` legítima, são preservadas.
O mesmo catálogo alimenta `llm.bind_tools()` e o `ToolNode` existentes.
Os testes exercitam ambas as ferramentas e a ferramenta de outro servidor.

### Contrato HTTP

- Rota interna: `POST /chat`. Externa: `/v1/chat` no endpoint já usado pelo usuário.
- Entrada: `message: str`, `session_id: str | null = null` e
  `incluir_diagnostico_mcp: bool = false`.
- Sem diagnóstico: `reply`, `session_id` e `tool_calls_made` exatamente como antes.
  A chave `diagnostico_mcp` fica ausente; `session_id: null` permanece presente.
- Com diagnóstico: adiciona catálogo descoberto, resultados correlacionados de
  todas as chamadas RAG e resumo do último resultado. Não deriva execução de
  texto da LLM. `tool_calls_made` continua contando todas as `ToolMessage`.
- `total_contextos` usa o valor recebido. Quando não interpretável ou em mensagem
  de ferramenta com erro, é `null`; ausência de chamada conserva o zero do plano.
- `erro_execucao` e `retorno_nao_interpretavel` são classificações locais explícitas.
  Status públicos do MCP são preservados quando reconhecidos e acompanhados de
  uma contagem inteira não negativa. Texto arbitrário não é copiado como status.
- Chamadas sem resultado correspondente aparecem em `chamadas_sem_resultado`
  com `sem_retorno`, sem serem contabilizadas como execuções confirmadas.
- Se o grafo lançar erro, o código HTTP e `detail` anteriores permanecem; a flag
  acrescenta o diagnóstico observado até a falha. Bloqueios/validações anteriores
  à invocação conservam as respostas existentes.

As assinaturas internas receberam parâmetros opcionais compatíveis:
`AgentFactory.create(..., rag_tools=None)` disponibiliza o catálogo de startup;
`AgentGraph.ainvoke(..., execution_messages=None)` permite coleta local à chamada.
Quando há opt-in, a fachada usa `astream(stream_mode="values")` do mesmo grafo,
com os callbacks e metadados OTel existentes. Isso conserva o último estado em
falhas que, no `ainvoke` direto, não retornariam mensagens. Não há estado de
requisição armazenado em atributos compartilhados, novos nós ou novas classes.

O parser contempla o formato efetivo de `langchain-mcp-adapters==0.3.2`:
blocos textuais e `artifact.structured_content`, além de JSON textual.
O adaptador transforma erros do protocolo MCP em `ToolMessage(status="error")`;
falhas de transporte continuam seguindo o tratamento HTTP preexistente.

### Uso no Insomnia

Na requisição existente, envie este corpo JSON com método POST:

```json
{
  "message": "Como faço para visualizar meus gastos no Minhas Finanças?",
  "incluir_diagnostico_mcp": true
}
```

O [guia para iniciantes](iaa-agent-minhas-financas-main/GUIA-CONFIGURACAO-AGENTE-MCP-HML.md) contém respostas
JSON completas e cenários FAQ, Educação, saudação, erro, ausência de resultados
e compatibilidade. Todos os exemplos são identificados como sintéticos.

## 3. Validação local executada

Ambiente isolado: `.venv-etapa5-py311`, Python **3.11.9**, alinhado à família
3.11 do projeto. Instalados os requirements existentes e as dependências de
teste/desenvolvimento já declaradas: pytest 9.1.1, pytest-asyncio 1.4.0 e
Flake8 7.4.1. Nenhum manifest de dependências foi editado.

A instalação usou o índice público PyPI com configuração pip corporativa
desabilitada para esse processo (`PIP_CONFIG_FILE=NUL`). Não acessou o índice
interno configurado no `pip.conf`. A tentativa inicial com Python 3.13 parou na
compilação do tiktoken 0.7.0 e foi encerrada, substituída pelo Python 3.11 já
instalado. O ambiente 3.11 instalou todas as versões declaradas com sucesso.

### Comandos

Comandos de preparação executados a partir da raiz do workspace:

```powershell
& 'C:/Users/manue/AppData/Local/Programs/Python/Python311/python.exe' -m venv .venv-etapa5-py311
```

A instalação foi executada por subprocesso Python com `PIP_CONFIG_FILE=NUL`,
sem variáveis `PIP_*` herdadas, usando os argumentos:

```text
.venv-etapa5-py311/Scripts/python.exe -m pip install
  --index-url https://pypi.org/simple --disable-pip-version-check --no-cache-dir
  -r iaa-agent-minhas-financas-main/requirements.txt
  pytest==9.1.1 pytest-asyncio==1.4.0 flake8
```

O bloco acima quebra linhas apenas para leitura; o log completo está em
[instalacao-py311.log](evidencias-etapa5/instalacao-py311.log).

Com diretório corrente `iaa-agent-minhas-financas-main`, a validação final usou
os comandos abaixo. O PATH do processo incluía `C:/Program Files/Git/usr/bin`,
que contém o OpenSSL já instalado, necessário a dois testes antigos.

```powershell
..\.venv-etapa5-py311\Scripts\python.exe ..\evidencias-etapa5\pytest_offline.py tests/unit -q -p no:cacheprovider --basetemp ..\evidencias-etapa5\tmp-entrega --tb=short
..\.venv-etapa5-py311\Scripts\python.exe -m flake8 iaa_agent_minhas_financas/app.py iaa_agent_minhas_financas/graph.py tests/unit/test_mcp_hml.py
..\.venv-etapa5-py311\Scripts\python.exe -m flake8 iaa_agent_minhas_financas tests
..\.venv-etapa5-py311\Scripts\python.exe -m pip check
```

O executor [pytest_offline.py](evidencias-etapa5/pytest_offline.py) chama pytest,
desabilita exportadores externos e bloqueia DNS/conexões externas no processo
dos testes. Loopback permanece permitido para o funcionamento do asyncio.
Ele não substitui bibliotecas da aplicação por stubs. Somente chamadas a serviços
e respostas da LLM são simuladas nos testes da integração.

| Verificação | Resultado real |
| --- | --- |
| Suíte original arquivada, mesmo ambiente | 156 aprovados em 5,92 s |
| Suíte final do agente | 228 aprovados em 6,12 s; saída 0 |
| Flake8 dos arquivos Python novos/alterados | Saída 0, nenhum apontamento |
| Flake8 geral antes/depois | Mesmo único W391 em `__init__.py:4:1`; saída 1 |
| `pip check` | Saída 0, sem dependências incompatíveis |

Nenhum warning foi listado nos resumos finais do pytest. A configuração `.flake8`
original foi usada (`max-line-length = 140`), sem nova regra ou supressão.
Os quatro `# noqa: E402` antigos de `app.py` foram mantidos; nenhum foi acrescentado.
O W391 é uma linha em branco final preexistente no arquivo de versão, que ficou
intacto por estar fora do escopo. Isso não é um erro introduzido pela integração.

As primeiras tentativas da regressão expuseram problemas locais de execução:
permissão da pasta temporária padrão e OpenSSL fora do PATH. Ambos foram resolvidos
com `--basetemp` no workspace e PATH do processo, sem editar testes legados.
Os resultados finais acima substituem esses resultados intermediários; os logs
intermediários foram conservados para rastreabilidade.

### Evidências e cobertura

- [Testes finais](evidencias-etapa5/pytest-final.log) e
  [baseline original](evidencias-etapa5/pytest-baseline-final.log).
- [Flake8 alterados](evidencias-etapa5/flake8-alterados.log),
  [antes](evidencias-etapa5/flake8-antes.log) e
  [depois](evidencias-etapa5/flake8-depois.log).
- [Dependências instaladas](evidencias-etapa5/dependencias-instaladas.txt) e
  [pip check](evidencias-etapa5/pip-check.log).
- [Schema real do `/chat`](evidencias-etapa5/contrato-chat.json), extraído do OpenAPI
  da aplicação implementada.

Também foram validados 11 exemplos JSON do guia/relatório com os modelos reais
`ChatRequest`/`ChatResponse` quando aplicáveis. A validação Markdown dos dois
documentos novos passou com `markdownlint ... --disable MD013 --`; somente a
regra de comprimento de linha foi dispensada para tabelas e comandos didáticos,
sem qualquer mudança na configuração Flake8. O patch passou em
`git apply --check ../alteracoes.patch`, executado no diretório dos originais,
sem aplicar alterações e sem necessitar de repositório Git.

Os 72 testes novos cobrem catálogo por servidor; consumo das duas ferramentas;
preservação de outra ferramenta MCP; falha de startup; JSON, blocos e artifact;
sucesso, resultados vazios e erros públicos do MCP; `isError` do protocolo;
transporte com/sem diagnóstico; falsa evidência textual; IDs e nomes divergentes;
contagens inválidas e ausência de campos; múltiplas chamadas; sessões/concorrência;
ausência de vazamento no diagnóstico; telemetria; precedência ENV/header;
versão e publicação. Adaptador MCP, `ToolNode`, grafo compilado e rota ASGI reais
participam dos testes de encadeamento. As regressões antigas exercitam guardrails,
telemetria, health checks, configuração, LLM e RAG legado.

## 4. Preservação e limites

Não houve mudanças no MCP, nos charts, GitOps, pipelines, `.flake8`, dependências,
versionamento ou cópias duplicadas. `publicarPacoteEImagem` permanece `false`.
Nenhum push, merge ou deploy foi executado. Não há valores reais de credenciais
no `.env` criado, nos testes novos ou nos registros desta entrega.

O template continua usando FastAPI, LangGraph, `AgentFactory`,
`MultiServerMCPClient`, `llm_call` e `ToolNode`. O RAG legado não foi desligado:
seu default anterior `false` e a possibilidade de ativação por ENV permanecem.
Não houve cópia da lógica GeneraBB para o agente.

Em 2026-10-16, o usuário autorizou mover o guia, corrigir seus links e excluir
somente os temporários inventariados. O guia foi movido sem sobrescrever arquivo
existente. As instruções de OpenShift e Insomnia foram preservadas; referências
a documentos externos ao agente agora informam o nome e onde encontrá-los.

Na revisão final do workspace, a tentativa de excluir a cópia redundante e os
temporários comprovados foi rejeitada pela revisão automática antes da execução
(`blocked by policy`), sem detalhamento adicional. Nenhum arquivo foi excluído
e não houve tentativa de contornar a proteção. Permanecem pendentes estes
22 diretórios, relativos à raiz do workspace:

```text
iaa-agent-minhas-financas-main/iaa-agent-minhas-financas-main/
.venv-etapa5/
evidencias-etapa5/tmp-entrega/
evidencias-etapa5/tmp-pytest-baseline/
evidencias-etapa5/tmp-pytest-baseline-final/
evidencias-etapa5/tmp-pytest-final/
evidencias-etapa5/tmp-suite-final/
iaa-agent-minhas-financas-main/.pytest_cache/
iaa-agent-minhas-financas-main/iaa_agent_minhas_financas/__pycache__/
iaa-agent-minhas-financas-main/iaa_agent_minhas_financas/llm/__pycache__/
iaa-agent-minhas-financas-main/iaa_agent_minhas_financas/rag/__pycache__/
iaa-agent-minhas-financas-main/iaa_agent_minhas_financas/utils/__pycache__/
iaa-agent-minhas-financas-main/tests/__pycache__/
iaa-agent-minhas-financas-main/tests/unit/__pycache__/
iaa-mcp-mf-main/.pytest_cache/
iaa-mcp-mf-main/iaa_mcp_mf/__pycache__/
iaa-mcp-mf-main/iaa_mcp_mf/core/__pycache__/
iaa-mcp-mf-main/iaa_mcp_mf/services/__pycache__/
iaa-mcp-mf-main/tests/__pycache__/
iaa-mcp-mf-main/tests/unit/__pycache__/
iaa-mcp-mf-main/tests/unit/core/__pycache__/
iaa-mcp-mf-main/tests/unit/services/__pycache__/
```

O ambiente antigo e os temporários de testes estão fora do repositório do agente;
os caches internos são ignorados pelos `.gitignore` dos respectivos projetos.
A cópia duplicada não tem regra de exclusão e deve ficar fora da seleção do merge.
Nenhum desses itens integra o patch ou os seis arquivos de merge. Os temporários
incluem certificados sintéticos de testes e devem permanecer locais até a limpeza.
Não há exclusão global do workspace: não se deve copiá-lo inteiro para o merge.

Permanecem locais e preservados `.venv-etapa5-py311/`, `.env`, o diário na raiz,
este relatório e `evidencias-etapa5/`, incluindo `originais/`, logs, manifestos
e `alteracoes.patch`. A pasta duplicada preexistente não foi alterada.

A organização não alterou código, testes ou configuração executável. A comparação
SHA-256 confirmou os cinco arquivos já entregues no agente byte a byte iguais
à entrega anterior e os mesmos 153 arquivos originais inalterados, incluindo
MCP, infraestrutura, versão e cópia duplicada. Os 228 testes e o Flake8 não foram
repetidos nesta organização; os resultados da seção 3 são da implementação.

Na verificação final desta organização, `git apply --check ../alteracoes.patch`
(em `evidencias-etapa5/originais`) e `markdownlint` do guia e deste relatório
(`--disable MD013 --`, como antes) retornaram saída 0. Foram conferidos os seis
caminhos do patch, os hashes finais, os 16 links relativos do guia/relatório e
as 103 cópias arquivadas existentes. Os demais originais, incluindo MCP e deploy,
foram comparados ao manifesto SHA-256 anterior, sem alteração.

A reversão do código pode restaurar os três arquivos funcionais a partir de
`evidencias-etapa5/originais/`. Correções no diário devem ser acrescentadas,
sem apagar a entrada histórica. Não se deve substituir toda a árvore do template.

## 5. Pendências exclusivamente corporativas

1. Obter a AppKey autorizada do MCP; preencher `MCP_APP_KEY` na Secret **`env`**
   do projeto **`iaa-agent-minhas-financas`**. Preservar a chave existente da LLM.
2. Conferir `MCP_CTL_ENDPOINT`, a referência `envFrom`, possíveis sobrescritas,
   certificados montados e acesso do pod ao gateway HML.
3. Garantir MCP com as duas ferramentas, Secret de credenciais válida e bases
   FAQ/Educação disponíveis, com os índices e permissões reais confirmados.
4. Fazer o merge e acompanhar a esteira autorizada. Confirmar imagem e digest
   efetivamente implantados: o chart contém a tag histórica `0.1.0.dev0` e a
   publicação permanece desabilitada; nenhum desses itens foi alterado aqui.
5. Iniciar/reiniciar o agente após a disponibilidade do MCP e executar os testes
   do guia no Insomnia, verificando seleção real da LLM e respostas fundamentadas.

A SDD e os registros CONF/DEP/CR não estão nesta cópia; não foram inventados gates
ou evidências de homologação. Não há pendência de implementação local conhecida.

## 6. Revisão final da estrutura do workspace

### Raízes e documentos

As raízes válidas continuam sendo `iaa-agent-minhas-financas-main/` para o agente
e `iaa-mcp-mf-main/` para o MCP. Os dois projetos de deploy e a pasta de arquitetura
permanecem separados. Nenhum arquivo foi movido nesta revisão final.
Os pacotes com sublinhados `iaa_agent_minhas_financas/` e `iaa_mcp_mf/`, assim como
os demais arquivos originais dos templates, continuam intactos.

O guia do agente está na raiz do agente e o guia RAG está na raiz do MCP.
Ambos foram inspecionados: não contêm referências `C:\Users\...` ou `file:///`.
O link relativo do guia do agente existe; não foi necessário editar os guias.
O diário, plano, relatório e evidências continuam fora dos projetos de aplicação.

### Evidência sobre a cópia interna do agente

A comparação recursiva, por nomes e SHA-256, desconsiderando caches, encontrou
51 arquivos na pasta `iaa-agent-minhas-financas-main/iaa-agent-minhas-financas-main/`:
45 idênticos à principal, seis diferentes e nenhum exclusivo.

| Arquivo diferente | Conteúdo antigo na cópia interna |
| --- | --- |
| `agent_config.yaml` | Gateway LLM de desenvolvimento, `local-mcp` ativo, sem configuração/orientações da integração HML |
| `iaa_agent_minhas_financas/app.py` | Sem o diagnóstico opcional da Etapa 5 |
| `iaa_agent_minhas_financas/graph.py` | Sem o filtro e coleta de execução da Etapa 5 |
| `iaa_agent_minhas_financas/__init__.py` | Versão `0.1.0.dev0`; principal está em `0.1.0` |
| `aic.json` | Python 3.8; principal declara Python 3.11 |
| `CHANGELOG.md` | Sem o registro da integração da Etapa 5 |

Sua origem provável é uma cópia anterior do mesmo template; não há metadados Git
para determinar o commit de origem. A pesquisa nos arquivos locais de código,
testes, scripts e build não encontrou referências explícitas ao nome dessa pasta.
Os imports, entrypoint e configuração dos testes apontam para a estrutura principal.
O `COPY . /app` copia conteúdo da raiz e pode levar a duplicação para a imagem,
mas não constitui uma dependência funcional dessa cópia.

A pasta foi inventariada e arquivada nas evidências da Etapa 5: seus 51 arquivos
coincidem integralmente com a cópia em
`evidencias-etapa5/originais/iaa-agent-minhas-financas-main/iaa-agent-minhas-financas-main/`.
O patch usa os arquivos da raiz principal, não os da cópia interna. A cópia
arquivada permanece preservada; remover a duplicação do projeto não apagaria
essa evidência nem os arquivos legítimos da aplicação.

Conclusão da inspeção local: cópia redundante e dispensável, sem alteração
exclusiva a incorporar. A exclusão autorizada foi tentada e bloqueada; a pasta
permanece no disco. Não foram acessadas bibliotecas ou esteiras corporativas.

### Ambientes virtuais e exclusões

- `.venv-etapa5/`: Python 3.13.5, substituído; candidato à limpeza bloqueada.
- `.venv-etapa5-py311/`: Python 3.11.9, usado nos resultados finais; preservado.
- `iaa-mcp-mf-main/.venv/`: Python 3.13.5, ambiente próprio do MCP; preservado.

A consulta WMI de processos foi negada pelo ambiente. A consulta disponível via
`Get-Process` não encontrou processos `python`, `pythonw`, `pip` ou `pip3`, e
`VIRTUAL_ENV` estava vazio. Os registros de execução e os comandos da entrega
usam explicitamente o ambiente Python 3.11. Nenhuma dependência foi ajustada.

Os `.gitignore` e `.dockerignore` foram lidos separadamente na raiz de cada
aplicação. Ambos os projetos excluem o `.env` e o `.venv` locais. Os `.gitignore`
também excluem caches, bytecode, logs e formatos temporários existentes.
Os ambientes `.venv-etapa5*` e as evidências estão fora da raiz do agente;
nenhuma regra interna protege o workspace inteiro contra uma cópia indevida.

Há uma limitação preexistente no contexto Docker: o agente só possui regras de
caches/bytecode para a raiz, e o MCP não possui essas regras. Nenhum dos projetos
exclui a duplicação por nome. Isso não inclui tais itens no patch, mas impede
afirmar que um build usando a pasta local inteira estaria livre de resíduos.

Correção mínima proposta, sem execução: acrescentar `**/__pycache__/`,
`**/.pytest_cache/` e `**/*.pyc` aos `.dockerignore`, preservando suas regras.
Se a cópia interna for mantida, sua exclusão explícita dos contextos Git/Docker
do agente também pode ser avaliada. Não foi alterado o MCP nem acrescentado
arquivo à entrega de seis itens; o merge deve selecionar somente os seis arquivos
da seção 1. Os guias e changelogs úteis não devem ser excluídos por padrões genéricos.

### Estado para merge

**PRONTO PARA MERGE: SIM**, para os seis arquivos aprovados. A organização física
do workspace permanece pendente nos 22 caminhos bloqueados; não foi declarada
como concluída. Não há correção funcional local identificada para essa entrega.
A versão do MCP permanece `0.0.1`; a do agente, `0.1.0`. A publicação permanece
`false` nos dois projetos. Código, testes, Dockerfiles, pipelines, Helm, GitOps,
arquivos de exclusão e credenciais locais permaneceram inalterados.

Não houve nova execução de pytest ou Flake8, nem build, push, merge, deploy ou
acesso a serviços corporativos. Os resultados da seção 3 são os já registrados.
O patch conserva os seis arquivos e a localização definitiva do guia.

A conferência final confirmou os hashes dos seis arquivos e do patch sem
alteração, as 103 cópias arquivadas intactas, os ambientes úteis presentes e
os 22 diretórios bloqueados ainda existentes. `git apply --check ../alteracoes.patch`
no diretório dos originais e `markdownlint` deste relatório com `--disable MD013 --`
retornaram saída 0. Os hashes do relatório e diário foram sincronizados no
manifesto local, sem incluí-los no patch do agente.
