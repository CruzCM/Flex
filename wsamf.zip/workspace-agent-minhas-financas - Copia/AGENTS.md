# AGENTS.md — AGENTE MINHAS FINANÇAS

## 1. Onde estamos

Este workspace contém um **template de referência**, fora do ambiente corporativo, que servirá de base para construir o **AGENTE MINHAS FINANÇAS**. O produto-alvo ainda não está implementado nem homologado. O que existe no template não comprova o comportamento dos serviços e ambientes reais.

**Não há autorização geral para programar.** A documentação e as 12 etapas planejadas não autorizam alterações por si só. Trabalhar apenas em tarefas e mudanças expressamente aprovadas pelo usuário; nunca iniciar automaticamente outra etapa.

O projeto poderá criar muitos componentes novos e, ao final da transição, **deixar de usar o template**. O objetivo não é conservar todo o código legado para sempre; é **evitar apagar ou reescrever componentes sem necessidade e sem autorização**.

## 2. Fonte principal e autoridade

Começar por `sdd/00-fonte-principal-do-desenvolvimento.md` (baseline documental de referência: **SDD 1.2.4**; conferir a versão vigente no workspace). Consultar apenas os capítulos, contratos, testes e registros pertinentes à tarefa.

- `sdd/11-decisoes-pendencias-e-riscos.md`: decisões aprovadas, ADR, DEP/CR.
- Seção 18 do Documento Mestre e `sdd/09-plano-de-implementacao.md`: etapas e critérios de aceite.
- Seção 19.6 e `sdd/rastreabilidade/matriz-confirmacoes-validacoes-pendentes.csv`: confirmações CONF e gates.
- `sdd/contratos/`, `sdd/testes/` e `sdd/insomnia/`: detalhes específicos, quando necessários.

A proposta negocial, os contratos externos efetivamente homologados e os registros normativos conservam suas autoridades próprias. O Documento Mestre é o guia operacional, não um substituto dos contratos. Exemplos, código do colega, fixtures e laboratório não são evidência de homologação.

**Não confundir:** o `sdd/CHANGELOG.md` registra revisões da especificação; o `CHANGELOG-AGENTE-MINHAS-FINANCAS.md`, na raiz, registra **a evolução efetiva deste projeto em relação ao template**.

## 3. Aprovação explícita antes de mudar

**Antes de qualquer alteração de arquivo, código, configuração, dependência, schema, contrato, API, teste, documentação do produto ou infraestrutura:**

1. Inspecionar o estado atual e apresentar **o que será mudado e por quê**.
2. Identificar os arquivos/componentes envolvidos, comportamento atual e resultado esperado.
3. Indicar impacto em compatibilidade, consumidores, requisitos, testes, segurança, dados, outras etapas e reversibilidade.
4. Explicar se basta **não usar**, **desativar por configuração/flag** ou adaptar pontualmente o componente atual; justificar qualquer remoção.
5. **Pedir aprovação explícita do usuário e aguardar a confirmação** antes de editar.

A aprovação vale somente para as mudanças e o escopo apresentados. **Não inferir permissão para alterações correlatas**, refatorações oportunistas, atualizações de dependências, mudanças de interface ou avanço de etapa. Se surgir outra mudança necessária, apresentar novo pedido de aprovação.

Alterações em **schemas, contratos, assinaturas, payloads, headers, modelos de domínio, enums, cálculos financeiros e interfaces externas/internas** exigem destaque individual na proposta, indicando consumidores afetados e se há quebra de compatibilidade. Não corrigir esses itens silenciosamente, nem para facilitar testes.

Inspeções e comandos locais estritamente **não mutáveis** podem ser realizados para fundamentar a proposta; executar testes que escrevam arquivos, gerem artefatos, alterem configurações ou dependam de integrações requer escopo autorizado.

## 4. Transição cuidadosa a partir do template

O template é **ponto de partida, não requisito permanente de execução**. Distinguir o comportamento atual do caminho novo do agente.

- Se o código legado não for necessário, **simplesmente não o utilizar** no novo fluxo.
- Se necessário para impedir execução acidental ou conflito, preferir **desativar por configuração, flag ou roteamento**, com testes e autorização.
- **Adaptar pontualmente** apenas quando houver benefício demonstrável para o escopo aprovado.
- Não apagar módulos, endpoints, fluxos, arquivos ou diretórios em massa por estarem fora da arquitetura-alvo. **Exclusão é uma decisão explícita**, com avaliação de dependentes e aprovação específica.
- Não manter componentes antigos *ativos* só para preservá-los. Evitar dois runtimes/execuções concorrentes sem razão aprovada.
- Comentar blocos de código não é estratégia padrão de desativação; só utilizar quando fizer sentido tecnicamente e for aprovado.
- Não criar substitutos, estrutura vazia, infraestrutura paralela ou refatoração antecipatória.

Quando o agente passar a operar independentemente do template, **registrar a transição no diário**, com evidências de quais dependências foram eliminadas ou desativadas. A eventual limpeza/remoção do legado será uma **missão separada e expressamente autorizada**, nunca consequência automática de uma etapa.

## 5. Diário de evolução obrigatório

Manter `CHANGELOG-AGENTE-MINHAS-FINANCAS.md` na raiz do projeto. **Toda mudança aprovada e realizada deve produzir, na mesma entrega, uma entrada que explique como era o template e o que mudou.** Não basta uma linha “ajustado X”.

Cada entrada deve conter:

- **Data, tarefa/etapa, responsável pela decisão e aprovação recebida** (sem fabricar identificadores).
- **Antes:** caminhos, fluxo e comportamento do template verificados; se algo não foi inspecionado, declarar essa limitação.
- **Depois:** caminhos, novo comportamento, componentes criados/adaptados/**não utilizados**/**desativados** e o que permanece intacto.
- **Motivo e impacto:** por que mudou, alternativas consideradas, compatibilidade, riscos, dependências e eventual caminho de reversão.
- **Evidência:** testes/comandos realmente executados, resultado e limite da validação local.
- **Pendências e gates:** CONF/DEP/CR afetados, sem alegar homologação inexistente.

O diário acompanha alterações reais, **não propostas recusadas ou não executadas** (essas podem ser citadas como decisões sem implementação, claramente separadas). Não reescrever entradas anteriores: acrescentar correção explícita quando necessário. Não registrar cópias sintéticas como operação corporativa.

## 6. Limites de ambiente e validação

**Proibido tentar acessar ou testar ambientes corporativos a partir desta cópia.** Não sondar DNS/hosts internos, não chamar endpoints institucionais, não usar credenciais/tokens/certificados, nem executar deploy, `git push`, CI/CD ou comandos de cluster contra infraestrutura corporativa. Arquivos de configuração e URLs são objeto de análise, **não autorização de conexão**.

Com autorização, usar testes locais, linters, verificações estáticas, mocks e fixtures sem acesso corporativo e sem infraestrutura paralela desnecessária. Distinguir sempre:

- **Observado no template:** leitura/inspeção efetivamente feita.
- **Validado localmente:** comando realmente executado e resultado obtido nesta cópia.
- **Especificado/proposto:** regra documental ou hipótese de engenharia.
- **Não validado corporativamente:** contrato, identidade, tool, RAG, IBM, deploy ou serviço real ainda não comprovado.

Não inventar resultados, versões implantadas, dados financeiros, credenciais nem garantias de cobertura. Mocks não homologam integrações. Proteger informações sensíveis antes de qualquer compartilhamento.

## 7. Regras técnicas que não podem ser presumidas

- **IBM:** a fronteira Chat Completions documentada é proposta; particularidades reais serão confirmadas no gate apropriado. `X-IBM-THREAD-ID` não autoriza FIN.
- **LangGraph:** arquitetura-alvo controlada, catálogo fechado, sem ReAct livre ou memória persistente própria no MVP.
- **FIN/GFP:** `op5580103v7` e o programa do colega são referência técnica. O contrato físico da nossa tool ainda exige confirmação. Sem deduplicação heurística, perdas silenciosas ou cálculos monetários pelo LLM.
- **EDU/APP:** nomes de índices não comprovam schema dos chunks. EDU depende do RAG educativo; APP separa Feature Manifest (existência/elegibilidade) de RAG NAV (passos).
- **CONF:** `etapa_limite` pode ser entrada, execução, aceite ou homologação. Pendência de integração futura **não bloqueia automaticamente** um incremento com contratos propostos e fixtures.

## 8. Prestação de contas

Após uma tarefa **aprovada**, entregar: estado anterior verificado, modificações exatas, arquivos afetados, entrada correspondente no diário, testes locais executados, limitações e pendências. Se a tarefa for apenas análise, **não editar nada**, salvo autorização específica.

**Regra final:** primeiro inspecionar e propor; depois obter confirmação; só então alterar, validar localmente e registrar o antes/depois. **Não apagar o template por impulso nem tratá-lo como algo que precisará ser preservado para sempre.**
