# iaa-agent-minhas-financas

> **Atenção!**
> **Configuração inicial de deploy em produção deve ser elaborada manualmente**
>
> A configuração do ambiente de deploy de produção **não é gerada automaticamente** por este template e deve ser elaborada manualmente pela equipe responsável, respeitando as políticas de infraestrutura e segurança vigentes.
>
> Os arquivos `Chart.yaml` e `values.yaml` com a **configuração inicial esperada** estão disponíveis ao final deste documento, sendo necessária alteração para a matrícula correta no campo `custodianteCertificado`. Veja a seção [Configuração Inicial do Helm Chart](#configuração-inicial-do-helm-chart).

Microsserviço de agente de IA - agente LLM com suporte a RAG e ferramentas MCP, construído com FastAPI e LangGraph (LangChain).

> **Documentação do pipeline:** <https://fontes.intranet.bb.com.br/aic/publico/atendimento/-/wikis/Pipelines/Python>

---

## Sumário

- [Visão Geral](#visão-geral)
- [Estrutura do Projeto](#estrutura-do-projeto)
- [Endpoints](#endpoints)
- [Configuração do Agente](#configuração-do-agente)
- [Variáveis de Ambiente](#variáveis-de-ambiente)
- [Guardrails](#guardrails)
- [RAG - Recuperação de Contexto](#rag--recuperação-de-contexto)
- [Ferramentas MCP](#ferramentas-mcp)
- [Executando Localmente](#executando-localmente)
- [Executando com Docker](#executando-com-docker)
- [Testes](#testes)
- [Uso como Template](#uso-como-template)
- [Configuração Inicial do Helm Chart](#configuração-inicial-do-helm-chart)

---

## Visão Geral

Este serviço expõe um agente de IA como um microsserviço REST. Cada requisição é processada pelo agente LangGraph que:

1. Aplica **guardrails de entrada** (tamanho, injeção de prompt, PII, curador externo)
2. Monta o estado inicial com a mensagem do usuário
3. Chama o **LLM** (Gateway Outbound BB por padrão) - podendo invocar ferramentas **MCP** e/ou **RAG**
4. Aplica **guardrails de saída** (lista de bloqueio, redação de PII)
5. Retorna a resposta estruturada

O provedor LLM, as instruções do sistema, a temperatura, o `top_p` e os servidores MCP são todos configuráveis via `agent_config.yaml`, sem necessidade de alterar o código.

---

## Estrutura do Projeto

```
iaa_agent_minhas_financas/
├── __init__.py              # Versão do pacote
├── __main__.py              # Entrypoint Uvicorn (python -m iaa_agent_minhas_financas)
├── app.py                   # Aplicação FastAPI - todos os endpoints HTTP
├── config.py                # Carregador do agent_config.yaml (dataclasses tipadas)
├── graph.py                 # Agente LangGraph - AgentFactory + ToolNode
│
├── llm/
│   ├── base.py              # Classe abstrata LLMProvider
│   ├── gateway_outbound.py  # Provedor Gateway Outbound BB (padrão)
│   └── factory.py           # LLMFactory - registro e instanciação de provedores
│
├── rag/
│   └── rag_tool.py          # Ferramenta LangChain para recuperação via gateway Genera BB
│
└── utils/
    ├── filter_patterns.py        # Guardrails síncronos: injeção de prompt, PII, blocklist
    ├── genera_safe_guardrails.py # Guardrail externo via curador-iagen (Genera Safe)
    ├── guardrails_middleware.py  # Middleware Starlette que orquestra os guardrails
    ├── ssl_context.py            # Construção de SSLContext para mTLS (cert/key/CA)
    └── tracing.py               # Bootstrap OpenTelemetry + Azure Monitor exporter

agent_config.yaml            # Configuração do agente (LLM, MCP, RAG, guardrails, instruções)
tests/
├── conftest.py              # Configuração do sys.path e desativação de exporters OTel nos testes
├── unit/                    # Testes unitários (config, graph, llm, rag, tracing, app)
└── integration/             # Placeholder para testes de integração

Dockerfile                   # Imagem dev-python 3.11 (BB) com uv
requirements.txt             # Dependências de runtime
setup.py                     # Metadados do pacote
.env.example                 # Template de variáveis de ambiente
```

---

## Endpoints

URL base para desenvolvimento local: `http://localhost:8080`

### Agente

| Método | Rota | Descrição |
|--------|------|-----------|
| `POST` | `/chat` | Envia uma mensagem ao agente e recebe a resposta |

**Corpo da requisição** (`/chat`):

```json
{
  "message": "Quais são as diretrizes de IA ética e responsável?",
  "session_id": "sessao-123"
}
```

| Campo | Obrigatório | Descrição |
|-------|-------------|-----------|
| `message` | **Sim** | Mensagem de texto enviada ao agente |
| `session_id` | Não | Identificador opcional da sessão (ecoado na resposta) |

**Corpo da resposta**:

```json
{
  "reply": "As diretrizes de IA ética e responsável incluem...",
  "session_id": "sessao-123",
  "tool_calls_made": 1
}
```

| Campo | Descrição |
|-------|-----------|
| `reply` | Resposta gerada pelo agente |
| `session_id` | Identificador da sessão (mesmo valor enviado na requisição) |
| `tool_calls_made` | Número de ferramentas invocadas durante a resposta |

---

### Observabilidade

| Método | Rota | Descrição |
|--------|------|-----------|
| `GET` | `/health/live` | **Liveness probe** - retorna `200` enquanto o processo estiver em execução |
| `GET` | `/health/ready` | **Readiness probe** - verifica se a configuração está carregada |
| `GET` | `/metrics` | Contadores em processo: total de requisições, uptime, nome do agente |

**Resposta do `/metrics`**:

```json
{
  "uptime_seconds": 3612.5,
  "total_requests": 42,
  "service_name": "iaa-agent-minhas-financas"
}
```

---

### Documentação da API (gerada automaticamente)

| Método | Rota | Descrição |
|--------|------|-----------|
| `GET` | `/docs` | Swagger UI |
| `GET` | `/redoc` | ReDoc UI |

---

## Configuração do Agente

O comportamento do agente é controlado pelo arquivo `agent_config.yaml` na raiz do projeto. Nenhuma alteração de código é necessária para trocar o LLM, as instruções do sistema, a temperatura ou os servidores MCP.

O arquivo utiliza **placeholders de variáveis de ambiente** no formato `${VAR:default}`, que são resolvidos no carregamento. Isso permite manter o mesmo `agent_config.yaml` em múltiplos ambientes (desenvolvimento, homologação, produção) e sobrescrever qualquer valor via `.env`:

```yaml
llm:
  provider: "${LLM_PROVIDER:gateway_outbound}"
  gateway_url: "${LLM_GATEWAY_BASE_URL}"          # varia por ambiente (desenv/hml/prod)
  profile: "${LLM_PROFILE:gpt-5-mini}"            # profiles: gpt-5 | gpt-5-mini
  api_version: "${LLM_API_VERSION:2024-12-01-preview}"
  max_tokens: ${LLM_MAX_TOKENS:4096}

instructions: |
  Você é um assistente de IA prestativo. Use as ferramentas disponíveis
  para responder às perguntas dos usuários com precisão.

agent_description: "${AGENT_DESCRIPTION:Agente baseado em LangGraph com suporte a múltiplos servidores MCP.}"
temperature: ${LLM_TEMPERATURE:0.7}
top_p: ${LLM_TOP_P:0.95}

guardrails:
  enabled: ${GUARDRAILS_ENABLED:false}
  url: "${GUARDRAIL_EXTERNAL_URL}"
  user_id: "${GUARDRAIL_EXTERNAL_USER_ID}"
  uor: "${GUARDRAIL_EXTERNAL_UOR}"
  agent_id: "${GUARDRAIL_EXTERNAL_AGENT_ID}"
  timeout: ${GUARDRAIL_EXTERNAL_TIMEOUT:30.0}

rag:
  enabled: ${RAG_ENABLED:false}
  url: "${RAG_URL}"
  user_id: "${RAG_USER_ID}"
  uor: "${RAG_UOR}"
  agent_id: "${RAG_AGENT_ID}"
  total_context: ${RAG_TOTAL_CONTEXT:10}
  timeout: ${RAG_TIMEOUT:30.0}
  tool_name: "${RAG_TOOL_NAME:retrieve_context}"
  tool_description: "${RAG_TOOL_DESCRIPTION:Recupera contexto relevante para responder a pergunta do usuário.}"

mcp:
  servers:
    - name: "local-mcp"
      description: "Servidor MCP local para desenvolvimento e testes"
      transport:
        type: "http"
        endpoint: "${MCP_LOCAL_ENDPOINT:http://localhost:9000/mcp}"
      authentication:
        type: "none"

    - name: "mcp-corporativo"
      description: "Servidor MCP corporativo BB (streamable HTTP + mTLS)"
      transport:
        type: "streamable_http"
        endpoint: "${MCP_CTL_ENDPOINT}"             # preenchido no .env
      headers:
        gw-dev-app-key: "${MCP_APP_KEY}"            # preenchido no .env
      authentication:
        type: "cert"
        cert_path: "${KEY_STORE_CERT_PATH}"         # preenchido no .env
        key_path: "${KEY_STORE_KEY_PATH}"           # preenchido no .env
        ca_bundle: "${TRUST_STORE_CA_PATH}"         # preenchido no .env
```

> O `profile` do LLM resolve automaticamente o nome do modelo e o path do endpoint
> (ex: `gpt-5-mini` -> `{gateway_url}/openai/deployments/gpt-5-mini`), então basta
> definir `LLM_GATEWAY_BASE_URL` no `.env` de cada ambiente.

### Validação no startup

A aplicação valida a configuração durante o startup do FastAPI. Se campos críticos estiverem vazios (ex: `instructions`, `llm.provider`, `llm.gateway_url` ou `llm.profile` inválido/ausente para o provedor `gateway_outbound`, `guardrails.agent_id` quando habilitado, `rag.agent_id` quando habilitado, ou token bearer de um servidor MCP), o processo falha imediatamente com a lista de erros.

Endpoints MCP que ainda são placeholders não resolvidos (ex: `${MCP_CTL_ENDPOINT}` sem valor definido) **não bloqueiam** o startup, para que o repositório possa ser usado como template sem exigir todas as variáveis de ambiente preenchidas.

### Adicionando um novo provedor LLM

O `LLMFactory` suporta registro de provedores customizados. O único provedor registrado por padrão é `gateway_outbound`:

```python
from iaa_agent_minhas_financas.llm import LLMFactory, LLMProvider


class MeuProvedor(LLMProvider):
    def build(self, temperature: float, top_p: float):
        # retorne um BaseChatModel
        ...

LLMFactory.register("meu_provedor", MeuProvedor)
```

Em seguida, defina `provider: "meu_provedor"` no `agent_config.yaml`.

---

## Variáveis de Ambiente

Copie `.env.example` para `.env` e preencha com os valores reais. **Nunca faça commit do `.env`.**

### Gateway Outbound BB

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `GATEWAY_OUTBOUND_GW_APP_KEY` | **Sim** | - | AppKey da aplicação registrada no Outbound Gateway BB |

### mTLS - Certificados de autenticação mútua

O Gateway Outbound BB exige autenticação mTLS com certificado cliente. Os certificados são obtidos nas secrets do container provisionado da aplicação.

Ajuste os caminhos conforme o ambiente de execução:
- **Container BB:** `/app/certs/...`
- **WSL/Ubuntu local:** `/home/wsl/esteira/certs/...` (ou o diretório onde os certificados foram baixados)

| Variável | Obrigatória | Descrição |
|----------|-------------|-----------|
| `KEY_STORE_CERT_PATH` | **Sim** | Caminho absoluto para o certificado cliente `.crt` |
| `KEY_STORE_KEY_PATH` | **Sim** | Caminho absoluto para a chave privada `.key` |
| `TRUST_STORE_CA_PATH` | Recomendado | CA do BB para validar o certificado do servidor gateway |
| `REQUESTS_CA_BUNDLE` | Recomendado | Bundle de CAs do sistema. No WSL com proxy BB, use o `al-bundle.pem` do Alfred (`/home/wsl/.aic-alfred/certs/al-bundle.pem`) |
| `SSL_CERT_FILE` | Recomendado | Alias para `REQUESTS_CA_BUNDLE` (usado por alguns SDKs Python) |

### RAG - Recuperação de Contexto

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `RAG_CLIENT_ID` | Se ativado | - | Token JWT para o header `X-Client-Id` |

> As demais configurações RAG (URL, agent_id, total_context, timeout, user_id, uor) ficam em `agent_config.yaml` na seção `rag:`.

### Guardrails Externos

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `GUARDRAIL_EXTERNAL_CLIENT_ID` | Se ativado | - | Token JWT para o header `X-Client-Id` |

> As demais configurações de guardrail externo (URL, agent_id, timeout, user_id, uor) ficam em `agent_config.yaml` na seção `guardrails:`.

### Guardrails de Entrada/Saída

| Variável | Obrigatória | Padrão | Descrição |
|----------|-------------|--------|-----------|
| `GUARDRAIL_MAX_INPUT_LEN` | Não | `4096` | Tamanho máximo da mensagem em caracteres |
| `GUARDRAIL_BLOCK_PII_INPUT` | Não | `true` | Bloqueia mensagens com PII na entrada |
| `GUARDRAIL_REDACT_PII_OUTPUT` | Não | `true` | Redige PII na resposta do agente |

---

## Guardrails

O middleware `GuardrailsMiddleware` protege o endpoint `/chat` em duas etapas:

### Verificações de entrada (em ordem)

| # | Verificação | Comportamento ao reprovar |
|---|-------------|--------------------------|
| 1 | **Tamanho** - mensagem acima de `GUARDRAIL_MAX_INPUT_LEN` | Retorna HTTP 400 `input_too_long` |
| 2 | **Injeção de prompt / jailbreak** - padrões regex conhecidos | Retorna HTTP 400 `prompt_injection` |
| 3 | **PII na entrada** - e-mail, telefone, CPF, CNPJ, cartão, SSN | Retorna HTTP 400 `pii_detected` |
| 4 | **Curador externo** - avaliação pelo agente `curador-iagen` (opcional) | Retorna HTTP 400 `external_guardrail` |

### Verificações de saída

| # | Verificação | Comportamento |
|---|-------------|---------------|
| 5 | **Lista de bloqueio** - frases proibidas na resposta | Substitui a resposta por mensagem genérica |
| 6 | **Redação de PII** - PII detectado na resposta | Substitui tokens por `[EMAIL]`, `[CPF]`, etc. |

> Todos os guardrails externos ignoram falhas de rede - erros nunca bloqueiam o tráfego.

---

## RAG - Recuperação de Contexto

Quando `rag.enabled: true` em `agent_config.yaml`, a ferramenta `retrieve_context` (nome configurável via `rag.tool_name`) é adicionada automaticamente ao conjunto de ferramentas do agente. O agente decide autonomamente quando chamá-la com base nas instruções do sistema.

A ferramenta realiza uma chamada `POST` ao gateway Genera BB com a ação `recuperar-contexto` e retorna uma lista de blocos de contexto que são incorporados à resposta do LLM.

---

## Ferramentas MCP

O agente carrega ferramentas de servidores MCP configurados em `agent_config.yaml`. Se um servidor estiver inacessível no momento da inicialização da requisição, o agente e opera sem as ferramentas daquele servidor, registrando um aviso nos logs.

Autenticação suportada por servidor MCP:

| Tipo | Configuração |
|------|-------------|
| `none` | Sem autenticação |
| `bearer` | Token lido de variável de ambiente (`token_env_var`), enviado como `Authorization: Bearer <token>` |
| `cert` | Certificado mTLS (`cert_path` + `key_path`, com `ca_bundle` opcional) |

Além da autenticação, cada servidor aceita `headers` HTTP adicionais - é o caso dos gateways
corporativos do BB, que exigem o header `gw-dev-app-key` (veja o servidor `mcp-corporativo`
no exemplo da seção [Configuração do Agente](#configuração-do-agente)). O AppKey é definido
via variável de ambiente no `.env` (ex: `MCP_APP_KEY`) e referenciado no YAML como placeholder.

> Não confunda com `GATEWAY_OUTBOUND_GW_APP_KEY`: essa variável é o AppKey do provedor LLM
> (`gateway_outbound`), usada nas chamadas ao modelo, e não dos servidores MCP.

---

## Executando Localmente

```bash
# 1. Criar o ambiente virtual
python -m venv .venv && source .venv/bin/activate

# 2. Instalar as dependências
pip install -r requirements.txt
pip install -e .

# 3. Configurar o ambiente
cp .env.example .env
# edite o .env com os valores reais

# 4. Iniciar o serviço
python -m iaa_agent_minhas_financas
# ou
uvicorn iaa_agent_minhas_financas.app:app --host 0.0.0.0 --port 8080 --reload
```

O Swagger UI estará disponível em: <http://localhost:8080/docs>

---

## Executando com Docker

```bash
# Build e inicialização
cp .env.example .env   # preencha os segredos
docker build --build-arg versao=dev -t iaa-agent:local .
docker run --rm --env-file .env -p 8080:8080 iaa-agent:local

# Verificações rápidas
curl http://localhost:8080/health/live
curl http://localhost:8080/health/ready
curl http://localhost:8080/metrics

# Invocar o agente
curl -s -X POST http://localhost:8080/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Quais são as diretrizes de IA ética e responsável?",
    "session_id": "exemplo-001"
  }' | python3 -m json.tool
```

---

## Testes

```bash
# Criar ambiente virtual e instalar dependências
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install -e ".[dev]"

# Rodar todos os testes
pytest

# Apenas testes unitários
pytest tests/unit/

# Apenas testes de integração
pytest tests/integration/

# Com cobertura
pytest --cov=iaa_agent_minhas_financas --cov-report=term-missing
```

Os testes desabilitam automaticamente os exporters OTel via `tests/conftest.py` para evitar threads de exportação em background e erros de rede não relacionados aos testes.


---

## Uso como Template

Este repositório pode servir de base para novos microsserviços de agente de IA baseados em **FastAPI + LangGraph**. Siga os passos abaixo para adaptá-lo a um novo projeto.

### 1. Renomear o pacote Python

Substitua `iaa_agent_minhas_financas` pelo slug do novo projeto (use underscores). Arquivos que precisam de atenção:

- `setup.py` - `name`, `entry_points` e `packages`
- `README.md` - título e referências ao pacote
- `Dockerfile` - módulo de entrypoint no `CMD`
- `iaa_agent_minhas_financas/` - renomeie a pasta
- `tests/` - imports dos testes
- `sonar-project.properties` - `sonar.projectKey`

### 2. Ajustar a identidade do agente

Edite `agent_config.yaml`:

```yaml
agent_description: "Descrição do agente"
instructions: |
  Você é ...
```

### 3. Configurar o provedor LLM

Por padrão o template traz `gateway_outbound`, que espera:

```bash
GATEWAY_OUTBOUND_GW_APP_KEY=<sua-chave>
LLM_GATEWAY_BASE_URL=<url-do-gateway-do-ambiente>
LLM_PROFILE=gpt-5-mini   # ou gpt-5
```

Para adicionar outro provedor, crie uma classe em `iaa_agent_minhas_financas/llm/` herdando de `LLMProvider` e registre-a na `LLMFactory` (veja a seção [Adicionando um novo provedor LLM](#adicionando-um-novo-provedor-llm)).

### 4. Configurar servidores MCP

Liste os servidores em `agent_config.yaml`.

### 5. Habilitar/desabilitar componentes

```bash
# Desabilitar guardrails externos
GUARDRAILS_ENABLED=false

# Desabilitar RAG
RAG_ENABLED=false
```

### 6. Build e execução

```bash
docker build --build-arg versao=dev -t iaa-agente:local .
docker run --rm --env-file .env -p 8080:8080 iaa-agente:local
```

---

## Configuração Inicial do Helm Chart

Os arquivos abaixo representam a **configuração inicial esperada** para o deploy em produção. Eles podem ser copiados integralmente para a primeira versão, sendo necessário apenas habilitar o `Service` no `values.yaml` antes da execução (campo `service.enable: true`).

---

### `Chart.yaml`

```yaml
apiVersion: v2
appVersion: "0.0.1"
description: Chart padrão e suas dependências do projeto iaa-agent-minhas-financas
name: chart-iaa-agent-minhas-financas
version: 0.0.1
dependencies:
- name: dia-chart-agent
  version: ~1.0.5
  alias: iaa-agent-minhas-financas
  repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/dia

- name: bbcert
  version: ~1.0.7
  repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/psc

- name: idh-operator-chart
  version: 0.0.13
  repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/idh
```

---

### `values.yaml`

```yaml
iaa-agent-minhas-financas:
  projetoPiloto: false
  multEnv: false
  service:
    name: iaa-agent-minhas-financas
    enable: true
    type: ClusterIP
    ports:
      - name: http
        port: 80
        targetPort: 8080

  # Horizontal Pod Autoscaler
  # https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/
  hpa:
    enable: false
    minReplicas: 2
    maxReplicas: 5
    memory: {}
      # averageUtilization: 70
    cpu: {}
      #averageUtilization: 70

  deployment:
    enable: true
    imagePullSecrets: atfregistry
    replicaCount: 1
    extraLabels: {}
      # key: value
    opentelemetry: {}
    #  resource.opentelemetry.io/bb.domain: "iaa"
    containers:
      #Informe apenas a Tag da sua imagem que está no ATF (atf.intranet.bb.com.br).
      tag: "0.1.0-dev0"
      imagePullPolicy: IfNotPresent
      # command: '[ "sh", "/tmp/cmd.sh" ]'
      environments:
        - name: MP_OPENAPI_SERVERS
          value: https://iaa-agent-minhas-financas.iaa.intranet.bb.com.br
        - name: ENABLE_INDEX
          value: index.html
        - name: ENABLE_SWAGGER
          value: "false"
        - name: KEY_STORE_CERT_PATH
          value: /app/certs/tls.crt
        - name: KEY_STORE_KEY_PATH
          value: /app/certs/tls.key
        - name: TRUST_STORE_CA_PATH
          value: /app/certs/ca.crt
        - name: REQUESTS_CA_BUNDLE
          value: /etc/pki/tls/certs/ca-bundle.crt
        - name: SSL_CERT_FILE
          value: /etc/pki/tls/certs/ca-bundle.crt
      # Se Habilitar o bbcert é necessário mudar a MP_OPENAPI_SERVERS para https
      envFrom:
        - secretRef:
            name: env
      ports: []
      #  - name: http
      #    containerPort: 8080
      resources:
        requests:
          cpu: 50m         # Valor em millicores/millicpu (m)
          memory: 250Mi    # Valor em megabyte (MiB)
        limits:
          cpu: 3001m       # Valor em millicores/millicpu (m)
          memory: 375Mi    # Valor em megabyte (MiB)
      livenessProbe:
        initialDelaySeconds: 30
        periodSeconds: 10
        timeoutSeconds: 10
        failureThreshold: 6
        successThreshold: 1
        httpGet:
          path: "/health/live"
          port: 8080
      readinessProbe:
        initialDelaySeconds: 30
        periodSeconds: 10
        timeoutSeconds: 10
        failureThreshold: 6
        successThreshold: 1
        httpGet:
          path: "/health/ready"
          port: 8080

      volumeMounts:
        - name: tls-certs-volume
          mountPath: /app/certs
          readOnly: true
    volumes:
      - name: tls-certs-volume
        secret:
          secretName: idh-mtls
          items:
            - key: tls.crt
              path: tls.crt
            - key: tls.key
              path: tls.key
            - key: ca.crt
              path: ca.crt

    strategy:
      type: RollingUpdate
      # rollingUpdate:
      #     maxSurge: 1
      #     maxUnavailable: 0
    nodeSelector: {}
    # key: value
    tolerations: []
    #- key: "key"
    #  operator: "Equal"
    #  value: "value"
    #  effect: "NoSchedule"
    hostAliases: []
    # serviceAccountName: service-account
    initContainer:
      enable: false
      image: bb/psc/busybox #será concatenado à atf.intranet.bb.com.br:5001
      tag: "1.31.1"
      imagePullPolicy: IfNotPresent
      #command: '[ "sh", "/tmp/cmd.sh" ]'
      environments: []
      #- name: key
      #  value: "value"
      envFrom: []
      #- configMapRef:
      #    name: app-configmap
      #- secretRef:
      #    name: app-secret
      resources:
        requests:
          cpu: 100m       # Valor em millicores/millicpu (m)
          memory: 250Mi   # Valor em megabyte (MiB)
        limits:
          cpu: 150m       # Valor em millicores/millicpu (m)
          memory: 375Mi   # Valor em megabyte (MiB)
      volumeMounts: []
      #- mountPath: /folder-aplic
      #  name: data

  deploymentCanario:
    enable: false
    deploymentControle: false   # Criação do deployment de controle
    imagePullSecrets: atfregistry
    replicaCount: 1
    extraLabels: {}
      # key: value
    containers:
      tag: "0.0.2"
      imagePullPolicy: IfNotPresent
      # command: '[ "sh", "/tmp/cmd.sh" ]'
      environments: []
      envFrom: []
      ports: []
      livenessProbe: {}
      readinessProbe: {}
      resources:
        requests:
          cpu: 100m         # Valor em millicores/millicpu (m)
          memory: 250Mi     # Valor em megabyte (MiB)
        limits:
          cpu: 150m         # Valor em millicores/millicpu (m)
          memory: 375Mi     # Valor em megabyte (MiB)
      volumeMounts: []
    # serviceAccountName: service-account
    volumes: []
    nodeSelector: {}
    tolerations: []
    strategy: {}
    hostAliases: []
    initContainer:
      enable: false
      image: bb/psc/busybox # path da imagem dentro do atf.intranet.bb.com.br:5001
      tag: "1.31.1"
      imagePullPolicy: IfNotPresent
      #command: '[ "sh", "/tmp/cmd.sh" ]'
      environments: []
      envFrom: []
      resources:
        requests:
          cpu: 100m       # Valor em millicores/millicpu (m)
          memory: 200Mi   # Valor em megabyte (MiB)
        limits:
          cpu: 300m       # Valor em millicores/millicpu (m)
          memory: 200Mi   # Valor em megabyte (MiB)
      volumeMounts: []

  ingress:
    enable: true
    hostname: iaa-agent-minhas-financas.iaa.intranet.bb.com.br
    servicePort: 80
    annotations:
      kubernetes.io/ingress.class: ingress-interno-iib
      haproxy.org/timeout-connect: "30s"
      haproxy.org/timeout-server: "1800s"
      haproxy.org/timeout-client: "1800s"
    paths:
      - path: "/"
        backend:
          serviceName: iaa-agent-minhas-financas
          servicePort: 80
    tls:
      - secretName: iaa-agent-minhas-financas-tls
        hosts:
          - iaa-agent-minhas-financas.iaa.intranet.bb.com.br

  ingressExterno:
    enable: false
    hostname: iaa-agent-minhas-financas.iaa.intranet.bb.com.br
    path: "/"
    servicePort: 80
    annotations:
      kubernetes.io/ingress.class: nginx-externo
    paths: []
    tls: []

  serviceMonitor:
    enable: false
    monitorNamespace: #xyz-monitor
    labels: {}
      # sigla: xyz # sua sigla!
    endpoints: []
      # - port: http
      #   interval: 10s
      #   path: /metrics
    sampleLimit: 40000

  persistenceVolume:
    enable: false
    persistentVolumeClaim: pvc-name
    storageClass: nas-client
    storageSize: 1Gi

  configMaps:
  #   - name: configmap1
  #     data:
  #       file1.sh: |
  #         #!/usr/bin/env bash
  #         echo "Hello world"
  #       file2.ini: |
  #         [BBAPLIC]
  #         Name = bb-aplic
  #         Company = Banco do Brasil S.A.
  #         [bb.com.br]
  #         Team = bb-cloud
  #   - name: configmap2
  #     data:
  #       file3.yaml: |
  #         struct1:
  #           name: bb-aplic
  #           company: Banco do Brasil S.A.
  #         struct2:
  #           team: bb-cloud

  # Lista de conectividade da aplicação
  conectividade: []
  #   - nome: api-xpto                # Nome da conectividade
  #     destino:                      # Lista de destinos que a sua aplicação deve ter acesso.
  #       - url: api.xpto.bb.com.br   # URL ou ip de destino
  #         protocolo: tcp            # Protocolo (TCP ou UDP)
  #         porta:                    # Lista de portas
  #           - 443
  #           - 80
  #       - url: 127.0.0.1
  #         protocolo: tcp
  #         porta:
  #           - 80
  #   - nome: ldap-des
  #     destino:
  #       - url: ldp0pb1.bb.com.br
  #         protocolo: tcp
  #         porta:
  #           - 636

  # Processamento com feature de CPU AVX
  processamentoAVX: false

  # Processamento com feature de GPU
  processamentoGPU: false
  processamentoGPUmem: 3    # Qtd de vcuda-memory / 1 vcuda-memory = 256MiB

  # Acesso ao proxy corporativo cache.bb
  acessoProxy: false

dnsingress:
  urls:
    - hostname: iaa-agent-minhas-financas.iaa.intranet.bb.com.br
      ingressClass: ingress-interno-iib

idhmtls:
  enabled: true
  renewTime: 365
  secretName: "idh-mtls"
  nomesAlternativos: []

bbcert:
  enabled: true

  custodianteCertificado:
    # Informe a matricula do funcionário que receberá os e-mails enviados pela
    # PKI BB e pelo Portal OaaS, no formato 'F99999999'.
    matriculaBB: "F99999999"

  # Todos os campos de 'dadosCertificado' são 'imutáveis', não podendo ser alterados
  # após a criação do objeto BBCert, caso seja necessário alterar algum desses
  # dados então crie um novo objeto BBCert e após criação apague o anterior.
  dadosCertificado:
    # 'ambientePKI' indica qual servidor PKI irá assinar esse certificado,
    # valores aceitos "des", "hml" ou "prd".
    ambientePKI: "prd"
    # 'commomName' é a URL principal a ser autenticada neste certificado, por
    # exemplo 'sigla.hm.bb.com.br'.
    commomName: "iaa-agent-minhas-financas.iaa.intranet.bb.com.br"
    # 'alternativesNames' é um array de strings, com as URL´s alternativas /
    # adicionais, a serem autenticadas juntamente neste certificado, por exemplo:
    # - "*.sigla.hm.bb.com.br"
    # - "outra-url.sigla.hm.bb.com.br"
    alternativesNames:
      - "*.iaa-agent-minhas-financas.iaa.intranet.bb.com.br"
    # 'ttl' determina a validade do certificado, valor máximo e default '365'.
    ttl: 365
    # 'secretNameToExport' indica o nome da Secret onde será armazenado o
    # certificado gerado.
    secretNameToExport: "iaa-agent-minhas-financas-tls"

  # A secção de 'autoRenew' trata da renovação automatica do certificado.
  autoRenew:
    # Habilita ou não o controle da renovação pelo BBCert Operator.
    enabled: true
    # 'qtDaysBeforeCertExpirion' indica com quantos dias antes do vencimento o
    # BBCert Operator deve providenciar a renovação do certificado e atualização
    # da Secret
    qtDaysBeforeCertExpirion: 30

```