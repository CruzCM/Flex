"""app.py - Aplicação FastAPI que expõe o agente LangGraph."""

from __future__ import annotations

import json
import logging
import threading
import time
from contextlib import asynccontextmanager
from typing import Any, Optional

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from pydantic import BaseModel, Field

from iaa_agent_minhas_financas.utils.tracing import configure_telemetry, get_service_name, get_tracer, instrument_fastapi
configure_telemetry()

from opentelemetry import trace as otel_trace  # noqa: E402
from iaa_agent_minhas_financas.config import get_config, validate_config  # noqa: E402
from iaa_agent_minhas_financas.graph import MCP_RAG_TOOLS, graph  # noqa: E402
from iaa_agent_minhas_financas.utils.guardrails_middleware import GuardrailsMiddleware  # noqa: E402

logger = logging.getLogger(__name__)

_tracer = get_tracer(__name__)

config = get_config()


@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    """Valida configuração e compila o grafo no startup."""
    cfg = get_config()
    valid, errors = validate_config(cfg)
    if not valid:
        raise RuntimeError(f"Configuração inválida: {'; '.join(errors)}")

    await graph.compile()
    yield


app = FastAPI(
    title=get_service_name(),
    description=config.agent_description,
    version=config.metadata.version or "0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)
instrument_fastapi(app)

_START_TIME = time.time()
_request_count: int = 0
_request_count_lock = threading.Lock()

app.add_middleware(GuardrailsMiddleware)


class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    incluir_diagnostico_mcp: bool = False

    model_config = {
        "json_schema_extra": {
            "examples": [{"message": "Quanto é 2 + 2?", "session_id": "sessao-exemplo"}]
        }
    }


class ChatResponse(BaseModel):
    reply: str
    session_id: Optional[str] = None
    tool_calls_made: int = 0
    diagnostico_mcp: dict[str, Any] | None = Field(default=None, exclude_if=lambda value: value is None)


class MetricsResponse(BaseModel):
    uptime_seconds: float
    total_requests: int
    service_name: str


def _tool_result(message: ToolMessage) -> tuple[str, int | None]:
    """Lê somente status e contagem; não copia conteúdo ou erros para a API."""
    if message.status == "error":
        return "erro_execucao", None

    artifact = message.artifact
    payload = artifact.get("structured_content") if isinstance(artifact, dict) else None
    if payload is None:
        content = message.content
        candidates = [content] if isinstance(content, str) else [
            block.get("text") for block in content
            if isinstance(block, dict) and block.get("type") == "text"
        ]
        decoded = []
        for candidate in candidates:
            if not isinstance(candidate, str):
                continue
            try:
                value = json.loads(candidate)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                decoded.append(value)
        payload = decoded[0] if len(decoded) == 1 else None

    # Status públicos observados no service_rag.py; texto arbitrário não é diagnóstico.
    statuses = {
        "sucesso", "sem_resultados", "credencial_ausente", "nao_configurado", "timeout",
        "erro_http", "erro_tls", "erro_conexao", "erro_interno", "entrada_invalida",
        "configuracao_invalida", "resposta_inesperada", "credencial_invalida", "acesso_negado",
    }
    if isinstance(payload, dict):
        status, total = payload.get("status"), payload.get("total_contextos")
        if isinstance(status, str) and status in statuses and type(total) is int and total >= 0:
            return status, total
    return "retorno_nao_interpretavel", None


def _mcp_diagnostic(messages: list[BaseMessage]) -> dict[str, Any]:
    """Correlaciona apenas o turno corrente; chamadas sem resultado não são execuções confirmadas."""
    start = next((i + 1 for i in range(len(messages) - 1, -1, -1) if isinstance(messages[i], HumanMessage)), 0)
    pending: dict[str, str] = {}
    executions: list[dict[str, Any]] = []
    for message in messages[start:]:
        if isinstance(message, AIMessage):
            for call in message.tool_calls:
                if call.get("name") in MCP_RAG_TOOLS and call.get("id"):
                    pending[call["id"]] = call["name"]
        elif isinstance(message, ToolMessage) and message.tool_call_id in pending:
            name = pending[message.tool_call_id]
            if message.name and message.name != name:
                continue
            del pending[message.tool_call_id]
            status, total = _tool_result(message)
            executions.append({"ferramenta": name, "status": status, "total_contextos": total})

    last = executions[-1] if executions else {}
    diagnostic = {
        "ferramentas_rag_disponiveis": list(graph.ferramentas_rag_disponiveis),
        "ferramenta_executada": last.get("ferramenta"),
        "status_ferramenta": last.get("status"),
        "total_contextos": last.get("total_contextos", 0),
        "execucoes": executions,
    }
    if pending:
        diagnostic["chamadas_sem_resultado"] = [
            {"ferramenta": name, "status": "sem_retorno"} for name in pending.values()
        ]
    return diagnostic


async def _invoke_agent(
    request: ChatRequest,
    execution_messages: list[BaseMessage] | None = None,
) -> dict[str, Any]:
    """Executa o grafo dentro de um span OTel."""
    initial_state = {
        "messages": [HumanMessage(content=request.message)],
    }
    with _tracer.start_as_current_span(
        "agent.chat",
        kind=otel_trace.SpanKind.INTERNAL,
        attributes={
            "session_id": request.session_id or "",
            "message.length": len(request.message),
        },
    ) as span:
        try:
            if execution_messages is not None:
                return await graph.ainvoke(initial_state, execution_messages=execution_messages)
            return await graph.ainvoke(initial_state)
        except HTTPException:
            raise
        except (ValueError, TypeError) as exc:
            logger.exception("Erro de validação no agente: session_id=%s", request.session_id)
            span.set_status(otel_trace.Status(otel_trace.StatusCode.ERROR, str(exc)))
            raise HTTPException(status_code=400, detail=f"Requisição inválida: {exc}") from exc
        except (TimeoutError, httpx.TimeoutException) as exc:
            logger.exception("Timeout ao executar agente: session_id=%s", request.session_id)
            span.set_status(otel_trace.Status(otel_trace.StatusCode.ERROR, "timeout"))
            raise HTTPException(status_code=504, detail="Tempo limite excedido ao processar a requisição.") from exc
        except (httpx.HTTPError, ConnectionError) as exc:
            logger.exception("Erro de conexão no agente: session_id=%s", request.session_id)
            span.set_status(otel_trace.Status(otel_trace.StatusCode.ERROR, "connection_error"))
            raise HTTPException(status_code=502, detail="Falha de comunicação com serviço externo.") from exc
        except Exception as exc:
            logger.exception("Erro inesperado na execução do agente: session_id=%s", request.session_id)
            span.set_status(otel_trace.Status(otel_trace.StatusCode.ERROR, str(exc)))
            raise HTTPException(status_code=500, detail="Erro interno do servidor.") from exc


@app.post(
    "/chat",
    response_model=ChatResponse,
    summary="Envia uma mensagem para o agente",
    tags=["Agente"],
    responses={500: {"description": "Erro interno do servidor."}},
)
async def chat(request: ChatRequest) -> ChatResponse | JSONResponse:
    global _request_count
    with _request_count_lock:
        _request_count += 1

    logger.info(
        "chat iniciado: session_id=%s mensagem='%s'",
        request.session_id,
        request.message[:200],
    )
    t0 = time.perf_counter()
    execution_messages: list[BaseMessage] | None = [] if request.incluir_diagnostico_mcp else None
    try:
        result = await _invoke_agent(request, execution_messages)
    except HTTPException as exc:
        if execution_messages is None:
            raise
        return JSONResponse(
            status_code=exc.status_code,
            headers=exc.headers,
            content={"detail": exc.detail, "diagnostico_mcp": _mcp_diagnostic(execution_messages)},
        )

    messages = result.get("messages", [])
    raw_content = messages[-1].content if messages else ""

    if isinstance(raw_content, list):
        reply = " ".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in raw_content
        ).strip()
    else:
        reply = str(raw_content)

    tool_calls_made = sum(1 for m in messages if isinstance(m, ToolMessage))
    elapsed_ms = (time.perf_counter() - t0) * 1000
    logger.info(
        "chat concluído: session_id=%s tool_calls=%d elapsed_ms=%.0f resposta='%s'",
        request.session_id,
        tool_calls_made,
        elapsed_ms,
        reply[:200],
    )

    return ChatResponse(
        reply=reply,
        session_id=request.session_id,
        tool_calls_made=tool_calls_made,
        diagnostico_mcp=_mcp_diagnostic(messages) if request.incluir_diagnostico_mcp else None,
    )


@app.get(
    "/metrics",
    summary="Métricas de execução",
    tags=["Operações"],
)
async def metrics() -> MetricsResponse:
    return MetricsResponse(
        uptime_seconds=round(time.time() - _START_TIME, 2),
        total_requests=_request_count,
        service_name=get_service_name(),
    )


@app.get(
    "/health/live",
    summary="Liveness probe",
    tags=["Health"],
)
async def health_live() -> JSONResponse:
    return JSONResponse(content={"status": "alive"})


@app.get(
    "/health/ready",
    summary="Readiness probe",
    tags=["Health"],
)
async def health_ready() -> JSONResponse:
    try:
        get_config()
    except (FileNotFoundError, ValueError, RuntimeError) as exc:
        return JSONResponse(
            status_code=503,
            content={"status": "not ready", "detail": str(exc)},
        )
    if not graph.is_ready:
        return JSONResponse(
            status_code=503,
            content={"status": "not ready", "detail": "Grafo ainda não compilado."},
        )
    return JSONResponse(content={"status": "ready"})
