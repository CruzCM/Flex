# Versão base da codebase principal.
# Em futuras branches de desenvolvimento, utilizar o sufixo .devN.
__version__ = "0.1.0"

