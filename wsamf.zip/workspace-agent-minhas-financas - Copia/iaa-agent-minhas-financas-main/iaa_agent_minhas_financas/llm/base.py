"""base.py - Classe base abstrata para provedores LLM."""

from __future__ import annotations

from abc import ABC, abstractmethod

from langchain_core.language_models import BaseChatModel


class LLMProvider(ABC):
    """Contrato que todo provedor LLM deve implementar."""

    @abstractmethod
    def build(self, temperature: float, top_p: float) -> BaseChatModel:
        """Instancia e retorna um chat model LangChain pronto para uso."""
