"""factory.py - Instancia o provedor LLM definido em agent_config.yaml.

Para adicionar um novo provedor:
  1. Crie iaa_agent_minhas_financas/llm/<nome>.py com classe herdando LLMProvider.
  2. Registre: LLMFactory.register("nome", MinhaClasse)
  3. Atualize agent_config.yaml: llm.provider: "nome"
"""

from __future__ import annotations


from langchain_core.language_models import BaseChatModel

from iaa_agent_minhas_financas.llm.base import LLMProvider
from iaa_agent_minhas_financas.llm.gateway_outbound import GatewayOutboundProvider


class LLMFactory:
    _registry: dict[str, type[LLMProvider]] = {
        "gateway_outbound": GatewayOutboundProvider,
    }

    @classmethod
    def register(cls, name: str, provider_cls: type[LLMProvider]) -> None:
        cls._registry[name] = provider_cls

    @classmethod
    def create(cls, provider: str, temperature: float, top_p: float) -> BaseChatModel:
        if provider not in cls._registry:
            raise ValueError(
                f"Provedor LLM desconhecido '{provider}'. "
                f"Disponíveis: {sorted(cls._registry)}"
            )
        return cls._registry[provider]().build(temperature, top_p)
