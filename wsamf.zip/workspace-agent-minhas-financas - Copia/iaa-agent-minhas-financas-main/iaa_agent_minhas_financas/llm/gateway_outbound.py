"""gateway_outbound.py - Provedor LLM para o gateway Outbound BB."""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

from langchain_core.language_models import BaseChatModel

from iaa_agent_minhas_financas.config import get_config
from iaa_agent_minhas_financas.llm.base import LLMProvider
from iaa_agent_minhas_financas.utils.ssl_context import build_ssl_context

_logger = logging.getLogger(__name__)


class _GatewayTransport(httpx.AsyncHTTPTransport):
    """Injeta x-application-key, api-version e, opcionalmente, reescreve o path."""

    def __init__(
        self,
        gw_app_key: str,
        api_version: str = "2024-12-01-preview",
        path_rewrite: str = "",
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._gw_app_key = gw_app_key
        self._api_version = api_version
        self._rewrite_from: str | None = None
        self._rewrite_to: str | None = None
        if path_rewrite and ":" in path_rewrite:
            parts = path_rewrite.split(":", 1)
            self._rewrite_from = parts[0]
            self._rewrite_to = parts[1]

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        new_path = request.url.path
        if self._rewrite_from and self._rewrite_to:
            new_path = new_path.replace(self._rewrite_from, self._rewrite_to)

        params = dict(request.url.params)
        params["api-version"] = self._api_version

        new_url = request.url.copy_with(path=new_path, params=params)

        headers = {
            k: v for k, v in request.headers.items()
            if k.lower() != "authorization"
        }
        headers["x-application-key"] = self._gw_app_key

        request = request.__class__(
            method=request.method,
            url=new_url,
            headers=headers,
            stream=request.stream,
            extensions=request.extensions,
        )
        return await super().handle_async_request(request)


class GatewayOutboundProvider(LLMProvider):
    def build(self, temperature: float, top_p: float) -> BaseChatModel:
        from langchain_openai import ChatOpenAI

        cfg = get_config().llm.gateway_outbound
        gw_app_key = os.environ.get("GATEWAY_OUTBOUND_GW_APP_KEY")
        if not gw_app_key:
            raise RuntimeError(
                "GATEWAY_OUTBOUND_GW_APP_KEY não está definida. "
                "Essa variável é obrigatória ao usar o provedor 'gateway_outbound'."
            )

        ssl_cert_path = os.environ.get("KEY_STORE_CERT_PATH")
        ssl_key_path = os.environ.get("KEY_STORE_KEY_PATH")
        ca_path = os.environ.get("TRUST_STORE_CA_PATH") or os.environ.get("REQUESTS_CA_BUNDLE")

        _logger.debug(
            "SSL config: cert=%s (exists=%s), key=%s (exists=%s), ca=%s (exists=%s)",
            ssl_cert_path, os.path.isfile(ssl_cert_path) if ssl_cert_path else False,
            ssl_key_path, os.path.isfile(ssl_key_path) if ssl_key_path else False,
            ca_path, os.path.isfile(ca_path) if ca_path else False,
        )

        verify = build_ssl_context(
            ca_bundle=ca_path,
            cert_path=ssl_cert_path,
            key_path=ssl_key_path,
        )

        transport_kwargs: dict = {"verify": verify}

        http_client = httpx.AsyncClient(
            transport=_GatewayTransport(
                gw_app_key=gw_app_key,
                api_version=cfg.api_version,
                path_rewrite=cfg.path_rewrite,
                **transport_kwargs,
            ),
        )

        missing = [field for field in ("base_url", "model") if not getattr(cfg, field)]
        if missing:
            raise RuntimeError(
                f"Configuração incompleta do provedor 'gateway_outbound': "
                f"{', '.join(missing)} não estão definidos no agent_config.yaml."
            )

        llm_kwargs: dict[str, Any] = {
            "base_url": cfg.base_url,
            "model": cfg.model,
            "api_key": "dummy",
            "http_async_client": http_client,
            "temperature": temperature,
        }

        if cfg.use_completion_tokens:
            llm_kwargs["max_completion_tokens"] = cfg.max_tokens
        else:
            llm_kwargs["top_p"] = top_p
            llm_kwargs["max_tokens"] = cfg.max_tokens

        return ChatOpenAI(**llm_kwargs)
