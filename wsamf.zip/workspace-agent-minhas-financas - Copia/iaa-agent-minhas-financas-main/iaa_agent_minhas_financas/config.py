"""config.py - Carrega e expõe as configurações do agent_config.yaml.

Suporta placeholders ``$VAR``, ``${VAR}`` e ``${VAR:default}`` para
sobrescrita via variáveis de ambiente.
"""

from __future__ import annotations

import os
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, List, Optional

import yaml


# Profiles de modelo LLM pré-configurados. O profile define o sufixo de path
# (após a base_url) e o nome do modelo. A base_url do gateway é definida via
# LLM_GATEWAY_BASE_URL no .env, pois varia por ambiente.

LLM_PROFILES: dict[str, dict[str, str | bool]] = {
    "gpt-5": {
        "path_suffix": "/openai/deployments/gpt-5",
        "model": "gpt-5",
        "path_rewrite": "",
        "use_completion_tokens": True,
    },
    "gpt-5-mini": {
        "path_suffix": "/openai/deployments/gpt-5-mini",
        "model": "gpt-5-mini",
        "path_rewrite": "",
        "use_completion_tokens": True,
    },
}


# Expansão de variáveis de ambiente no YAML

_ENV_RE = re.compile(
    r"\$\{(?P<name>\w+)(?::(?P<default>[^}]*))?\}|\$(?P<name2>\w+)"
)


def _replace_placeholder(match: "re.Match[str]") -> str:
    """Substitui um placeholder pelo valor da env var ou pelo default."""
    name = match.group("name") or match.group("name2")
    default = match.group("default")
    value = os.environ.get(name)
    if value:
        return value
    if default is not None:
        return default
    return match.group(0)


def _coerce_string(value: str, original: Any) -> Any:
    """Converte strings expandidas para bool/int/float."""
    lowered = value.lower()
    if lowered in {"true", "1", "yes", "on"}:
        return True
    if lowered in {"false", "0", "no", "off"}:
        return False
    if isinstance(original, bool):
        return lowered in {"true", "1", "yes", "on"}
    if isinstance(original, int):
        try:
            return int(value)
        except ValueError:
            return value
    if isinstance(original, float):
        try:
            return float(value)
        except ValueError:
            return value
    return value


def _expand_string(value: str, original: Any) -> Any:
    """Expande placeholders em uma string e converte o tipo resultante."""
    expanded = _ENV_RE.sub(_replace_placeholder, value)
    return _coerce_string(expanded, original) if isinstance(expanded, str) else expanded


def _map_values(obj: Any, original: Any, mapper: "Callable[[Any, Any], Any]") -> Any:
    """Aplica ``mapper`` recursivamente em dicts e lists."""
    if isinstance(obj, dict):
        return {
            k: _map_values(
                v,
                original.get(k) if isinstance(original, dict) else v,
                mapper,
            )
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [
            _map_values(
                v,
                original[i] if isinstance(original, list) and i < len(original) else v,
                mapper,
            )
            for i, v in enumerate(obj)
        ]
    return mapper(obj, original)


def _expand_env_vars(obj: Any) -> Any:
    """Expande ``$VAR``, ``${VAR}`` e ``${VAR:default}`` recursivamente.

    Valores que não puderem ser expandidos (variável não definida e sem default)
    permanecem literais. Números inteiros/decimais em strings são convertidos
    quando o YAML original os representava como números.
    """
    first_pass = _map_values(obj, obj, lambda v, orig: _expand_string(v, orig) if isinstance(v, str) else v)
    return _map_values(first_pass, first_pass, lambda v, orig: _coerce_string(v, orig) if isinstance(v, str) else v)


# Data-classes que espelham o schema YAML


@dataclass
class MCPTransport:
    type: str
    endpoint: str

    @property
    def mcp_url(self) -> str:
        return self.endpoint


@dataclass
class MCPAuthentication:
    type: str = "none"            # "none" | "bearer" | "cert"
    token_env_var: Optional[str] = None   # obrigatório quando type=bearer
    cert_path: Optional[str] = None       # obrigatório quando type=cert; suporta $ENV_VAR
    key_path: Optional[str] = None        # obrigatório quando type=cert; suporta $ENV_VAR
    ca_bundle: Optional[str] = None       # caminho CA personalizado; suporta $ENV_VAR


@dataclass
class MCPServer:
    name: str
    description: str
    transport: MCPTransport
    authentication: Optional[MCPAuthentication] = None
    headers: Optional[dict] = None        # cabeçalhos HTTP adicionais (ex.: gw-dev-app-key)

    def resolve_token(self) -> Optional[str]:
        if self.authentication is None or self.authentication.type != "bearer":
            return None
        if not self.authentication.token_env_var:
            return None
        return os.getenv(self.authentication.token_env_var)

    def resolve_cert(self) -> Optional[tuple]:
        """Retorna (cert_path, key_path, ca_bundle|None) para autenticação mTLS.

        Os valores em ``cert_path``, ``key_path`` e ``ca_bundle`` podem ser
        caminhos literais ou referências a variáveis de ambiente no formato
        ``$NOME_VAR`` - ambos são resolvidos via :func:`os.path.expandvars`.
        """
        if self.authentication is None or self.authentication.type != "cert":
            return None
        cert_path = os.path.expandvars(self.authentication.cert_path or "")
        key_path = os.path.expandvars(self.authentication.key_path or "")
        if not cert_path or not key_path:
            return None
        ca_bundle_raw = self.authentication.ca_bundle or ""
        ca_bundle: Optional[str] = None
        if ca_bundle_raw:
            expanded = os.path.expandvars(ca_bundle_raw)
            if not expanded.startswith("$"):
                ca_bundle = expanded
        return cert_path, key_path, ca_bundle


@dataclass
class MCPConfig:
    servers: List[MCPServer] = field(default_factory=list)


@dataclass
class GatewayOutboundConfig:
    base_url: str = ""
    model: str = ""
    api_version: str = "2024-12-01-preview"
    max_tokens: int = 4096
    path_rewrite: str = ""
    use_completion_tokens: bool = False


@dataclass
class GuardrailsConfig:
    enabled: bool = False
    url: str = "${GUARDRAIL_EXTERNAL_URL}"
    user_id: str = ""
    uor: str = ""
    agent_id: str = "${GUARDRAIL_EXTERNAL_AGENT_ID}"
    timeout: float = 5.0


@dataclass
class RAGConfig:
    enabled: bool = False
    url: str = "${RAG_URL}"
    uor: str = ""
    user_id: str = ""
    agent_id: str = "${RAG_AGENT_ID}"
    total_context: int = 5
    timeout: float = 10.0
    tool_name: str = "retrieve_context"
    tool_description: str = "Recupera contexto relevante para responder a pergunta do usuário."


@dataclass
class LLMConfig:
    provider: str = "gateway_outbound"  # gateway_outbound - extensível via LLMFactory.register()
    gateway_outbound: GatewayOutboundConfig = field(default_factory=GatewayOutboundConfig)


@dataclass
class Metadata:
    owner: str
    version: str
    created_at: str


@dataclass
class AgentConfig:
    instructions: str
    agent_description: str
    temperature: float
    top_p: float
    mcp: MCPConfig
    metadata: Metadata
    llm: LLMConfig = field(default_factory=LLMConfig)
    guardrails: GuardrailsConfig = field(default_factory=GuardrailsConfig)
    rag: RAGConfig = field(default_factory=RAGConfig)


# Loader


def load_agent_config(path: str | Path | None = None) -> AgentConfig:
    """Carrega agent_config.yaml e retorna um AgentConfig tipado."""
    if path is None:
        explicit_path = os.environ.get("AGENT_CONFIG_PATH")
        if explicit_path:
            candidates = [Path(explicit_path)]
        else:
            # Heurística de busca: raiz do repositório (dois níveis acima) → cwd
            candidates = [
                Path(__file__).parent.parent / "agent_config.yaml",
                Path.cwd() / "agent_config.yaml",
            ]
        for candidate in candidates:
            if candidate.is_file():
                path = candidate
                break
        else:
            searched = [str(c) for c in candidates]
            raise FileNotFoundError(
                "agent_config.yaml not found. "
                f"Searched: {searched}. "
                "Defina AGENT_CONFIG_PATH para apontar explicitamente o arquivo."
            )

    with open(path, "r", encoding="utf-8") as fh:
        raw: dict = yaml.safe_load(fh)

    raw = _expand_env_vars(raw)

    # MCP servers
    mcp_raw = raw.get("mcp", {})
    servers: List[MCPServer] = []
    for srv in mcp_raw.get("servers", []):
        transport_raw = srv.get("transport", {})
        auth_raw = srv.get("authentication", {})
        servers.append(
            MCPServer(
                name=srv["name"],
                description=srv.get("description", ""),
                transport=MCPTransport(
                    type=transport_raw.get("type", "http"),
                    endpoint=transport_raw["endpoint"],
                ),
                authentication=MCPAuthentication(
                    type=auth_raw.get("type", "none"),
                    token_env_var=auth_raw.get("token_env_var"),
                    cert_path=auth_raw.get("cert_path"),
                    key_path=auth_raw.get("key_path"),
                    ca_bundle=auth_raw.get("ca_bundle"),
                ) if auth_raw else None,
                headers=srv.get("headers") or None,
            )
        )

    # Metadata
    meta_raw = raw.get("metadata", {})
    metadata = Metadata(
        owner=meta_raw.get("owner", ""),
        version=meta_raw.get("version", ""),
        created_at=meta_raw.get("created_at", ""),
    )

    # LLM provider
    llm_raw = raw.get("llm", {})

    def _val(v: Any) -> str:
        """Retorna vazio se o valor é um placeholder não resolvido (ex: ${VAR})."""
        s = str(v) if v else ""
        return "" if s.startswith("$") else s

    profile_name = _val(llm_raw.get("profile", "")).strip().lower()
    profile = LLM_PROFILES.get(profile_name, {})

    gateway_base = _val(llm_raw.get("gateway_url", "")).strip().rstrip("/")
    base_url = (gateway_base + profile.get("path_suffix", "")) if gateway_base and profile else ""

    llm_config = LLMConfig(
        provider=llm_raw.get("provider", "gateway_outbound"),
        gateway_outbound=GatewayOutboundConfig(
            base_url=base_url,
            model=profile.get("model", ""),
            api_version=llm_raw.get("api_version", "2024-12-01-preview"),
            max_tokens=int(llm_raw.get("max_tokens", 4096)),
            path_rewrite=profile.get("path_rewrite", ""),
            use_completion_tokens=bool(profile.get("use_completion_tokens", False)),
        ),
    )

    # Guardrails
    gr_raw = raw.get("guardrails", {})
    guardrails_config = GuardrailsConfig(
        enabled=bool(gr_raw.get("enabled", False)),
        url=gr_raw.get("url", ""),
        user_id=gr_raw.get("user_id", ""),
        uor=str(gr_raw.get("uor", "")),
        agent_id=gr_raw.get("agent_id", ""),
        timeout=float(gr_raw.get("timeout", 5.0)),
    )

    # RAG
    rag_raw = raw.get("rag", {})
    rag_config = RAGConfig(
        enabled=bool(rag_raw.get("enabled", False)),
        url=rag_raw.get("url", ""),
        uor=str(rag_raw.get("uor", "")),
        user_id=rag_raw.get("user_id", ""),
        agent_id=rag_raw.get("agent_id", ""),
        total_context=int(rag_raw.get("total_context", 5)),
        timeout=float(rag_raw.get("timeout", 10.0)),
        tool_name=rag_raw.get("tool_name", "retrieve_context"),
        tool_description=rag_raw.get(
            "tool_description", "Recupera contexto relevante para responder a pergunta do usuário."
        ),
    )

    return AgentConfig(
        instructions=raw["instructions"],
        agent_description=raw.get("agent_description", ""),
        temperature=float(raw.get("temperature", 0.7)),
        top_p=float(raw.get("top_p", 1.0)),
        mcp=MCPConfig(servers=servers),
        metadata=metadata,
        llm=llm_config,
        guardrails=guardrails_config,
        rag=rag_config,
    )


_config: Optional[AgentConfig] = None
_config_lock = threading.Lock()


def get_config() -> AgentConfig:
    """Singleton thread-safe do AgentConfig."""
    global _config
    if _config is None:
        with _config_lock:
            if _config is None:
                _config = load_agent_config()
    return _config


def validate_config(cfg: AgentConfig) -> tuple[bool, list[str]]:
    """Valida campos críticos da configuração no startup.

    Retorna ``(True, [])`` quando a configuração está válida, ou
    ``(False, [erro1, erro2, ...])`` quando há problemas.
    """
    errors: list[str] = []

    if not cfg.instructions:
        errors.append("instructions não pode estar vazio")
    if not cfg.llm.provider:
        errors.append("llm.provider não definido")

    if cfg.llm.provider == "gateway_outbound":
        gw = cfg.llm.gateway_outbound
        if not gw.base_url:
            errors.append("llm.gateway_outbound.base_url não definido")
        if not gw.model:
            errors.append("llm.gateway_outbound.model não definido")

    if cfg.guardrails.enabled and not cfg.guardrails.agent_id:
        errors.append("guardrails habilitado mas agent_id não definido")

    if cfg.rag.enabled and not cfg.rag.agent_id:
        errors.append("RAG habilitado mas agent_id não definido")

    for srv in cfg.mcp.servers:
        endpoint = srv.transport.endpoint or ""
        if not endpoint:
            errors.append(f"MCP server '{srv.name}' não possui endpoint definido")
        elif endpoint.startswith("$"):
            continue
        if srv.authentication and srv.authentication.type == "bearer":
            token_var = srv.authentication.token_env_var
            if token_var and not os.environ.get(token_var):
                errors.append(
                    f"MCP server '{srv.name}' usa bearer mas {token_var} não está definido"
                )

    return len(errors) == 0, errors
