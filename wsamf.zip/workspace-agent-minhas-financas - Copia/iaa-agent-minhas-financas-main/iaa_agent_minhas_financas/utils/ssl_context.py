"""ssl_context.py - Construção centralizada de ssl.SSLContext."""

from __future__ import annotations

import logging
import os
import ssl

logger = logging.getLogger(__name__)


def build_ssl_context(
    ca_bundle: str | None = None,
    cert_path: str | None = None,
    key_path: str | None = None,
    purpose: ssl.Purpose = ssl.Purpose.SERVER_AUTH,
) -> ssl.SSLContext:
    """Cria um ssl.SSLContext com TLS 1.2+.

    Args:
        ca_bundle: Caminho para o bundle de CAs a ser usado na verificação.
        cert_path: Caminho para o certificado cliente (mTLS).
        key_path: Caminho para a chave privada do certificado cliente (mTLS).
        purpose: Propósito do contexto (padrão: SERVER_AUTH).
    """
    ssl_ctx = ssl.create_default_context(purpose=purpose)
    ssl_ctx.minimum_version = ssl.TLSVersion.TLSv1_2

    if ca_bundle:
        if os.path.isfile(ca_bundle):
            ssl_ctx.load_verify_locations(cafile=ca_bundle)
        else:
            logger.warning("CA bundle não encontrado: %s", ca_bundle)

    if cert_path and key_path:
        if os.path.isfile(cert_path) and os.path.isfile(key_path):
            ssl_ctx.load_cert_chain(certfile=cert_path, keyfile=key_path)
        else:
            logger.warning("Certificado cliente não encontrado: cert=%s key=%s", cert_path, key_path)

    return ssl_ctx
