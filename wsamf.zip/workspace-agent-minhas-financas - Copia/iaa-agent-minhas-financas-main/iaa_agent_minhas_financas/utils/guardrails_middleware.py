"""guardrails_middleware.py - Middleware Starlette para guardrails de entrada e saída."""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any, Awaitable, Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from iaa_agent_minhas_financas.utils.filter_patterns import (
    check_injection,
    check_output_blocklist,
    contains_pii,
    redact_pii,
)
from iaa_agent_minhas_financas.utils.genera_safe_guardrails import check_external_guardrail
from iaa_agent_minhas_financas.utils.tracing import get_meter, get_telemetry_attributes, get_tracer

logger = logging.getLogger(__name__)

_tracer = get_tracer("agent.guardrails")
_meter = get_meter("agent.guardrails")

_guardrail_requests = _meter.create_counter(
    "guardrail.requests",
    description="Total number of /chat requests processed by guardrails middleware",
)
_guardrail_blocks = _meter.create_counter(
    "guardrail.blocked",
    description="Total number of guardrail blocks by layer/rule",
)
_guardrail_redactions = _meter.create_counter(
    "guardrail.redactions",
    description="Total number of output redactions applied by guardrails",
)
_guardrail_latency = _meter.create_histogram(
    "guardrail.latency_ms",
    description="Guardrails middleware latency in milliseconds",
)

_MAX_INPUT_LEN: int = int(os.getenv("GUARDRAIL_MAX_INPUT_LEN", "4096"))
_BLOCK_PII_INPUT: bool = os.getenv("GUARDRAIL_BLOCK_PII_INPUT", "true").lower() == "true"
_REDACT_PII_OUTPUT: bool = os.getenv("GUARDRAIL_REDACT_PII_OUTPUT", "true").lower() == "true"
_CHAT_ROUTE = "/chat"
_ATTR_ROUTE_KEY = "guardrail.route"

_EXTRA_ATTRS: dict = get_telemetry_attributes()


def _parse_body(body_bytes: bytes) -> dict:
    try:
        return json.loads(body_bytes)
    except (json.JSONDecodeError, AttributeError):
        return {}


def _replay_receive(body_bytes: bytes):
    async def receive():
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    return receive


def _check_input_guardrails(message: str, span: Any) -> JSONResponse | None:
    if len(message) > _MAX_INPUT_LEN:
        logger.warning("Guardrail: entrada muito longa (%d chars)", len(message))
        _record_block(span, code="input_too_long", layer="input")
        return _blocked(
            "input_too_long",
            f"A mensagem excede o tamanho maximo permitido de {_MAX_INPUT_LEN} caracteres.",
        )

    matched = check_injection(message)
    if matched:
        logger.warning("Guardrail: injecao detectada: %r", matched)
        _record_block(span, code="prompt_injection", layer="input")
        return _blocked("prompt_injection", "A mensagem contem conteudo nao permitido.")

    if _BLOCK_PII_INPUT and contains_pii(message):
        logger.warning("Guardrail: PII detectado na entrada")
        return _blocked(
            "pii_detected",
            "A mensagem parece conter informacoes pessoais (PII). "
            "Por favor, remova-as antes de enviar.",
        )

    return None


async def _check_external_guardrail(message: str, span: Any) -> JSONResponse | None:
    ext_reason = await check_external_guardrail(message, None)
    if ext_reason:
        logger.warning("Guardrail: verificacao externa bloqueou a mensagem: %r", ext_reason)
        _record_block(span, code="external_guardrail", layer="input")
        return _blocked("external_guardrail", "Mensagem rejeitada pela politica de conteudo.")
    return None


def _apply_output_guardrails(payload: dict, span: Any) -> None:
    reply: str = payload.get("reply", "")

    matched_out = check_output_blocklist(reply)
    if matched_out:
        logger.warning("Guardrail: frase bloqueada na saida: %r", matched_out)
        _record_block(span, code="output_blocklist", layer="output")
        payload["reply"] = "Desculpe, nao posso fornecer essa informacao."
        return

    if _REDACT_PII_OUTPUT:
        redacted = redact_pii(reply)
        if redacted != reply:
            logger.info("Guardrail: PII redigido na saida")
            _guardrail_redactions.add(1, {
                _ATTR_ROUTE_KEY: _CHAT_ROUTE,
                "guardrail.layer": "output",
                "guardrail.rule": "pii_redaction",
                **_EXTRA_ATTRS,
            })
            span.set_attribute("guardrail.output_redacted", True)
        payload["reply"] = redacted


async def _build_json_response(response: Any, span: Any) -> Response:
    raw = b""
    body_iterator = getattr(response, "body_iterator", None)
    if body_iterator is not None:
        async for chunk in body_iterator:
            raw += chunk
    else:
        body = getattr(response, "body", None)
        if body is None:
            return response
        raw = body

    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, AttributeError):
        return response

    _apply_output_guardrails(payload, span)

    return JSONResponse(
        content=payload,
        status_code=response.status_code,
        headers={"x-guardrails-applied": "true"},
    )


class GuardrailsMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        if request.method == "POST" and request.url.path == _CHAT_ROUTE:
            return await self._guard_chat(request, call_next)
        return await call_next(request)

    async def _guard_chat(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        attrs_base = {_ATTR_ROUTE_KEY: _CHAT_ROUTE, **_EXTRA_ATTRS}
        _guardrail_requests.add(1, attrs_base)

        with _tracer.start_as_current_span(
            "guardrails.chat",
            attributes={**attrs_base, "span.kind": "internal", "guardrails.layer": "middleware"},
        ) as span:
            t0 = time.perf_counter()
            body_bytes = await request.body()
            request = Request(request.scope, _replay_receive(body_bytes))
            parsed = _parse_body(body_bytes)
            message = parsed.get("message", "")
            session_id = parsed.get("session_id", "")
            if session_id:
                span.set_attribute("session.id", session_id)

            try:
                blocked = _check_input_guardrails(message, span)
                if blocked:
                    return blocked

                external_block = await _check_external_guardrail(message, span)
                if external_block:
                    return external_block

                response = await call_next(request)

                if response.status_code == 200 and "application/json" in response.headers.get(
                    "content-type", ""
                ):
                    return await _build_json_response(response, span)

                return response
            finally:
                elapsed_ms = (time.perf_counter() - t0) * 1000
                _guardrail_latency.record(elapsed_ms, attrs_base)
                span.set_attribute("guardrail.latency_ms", elapsed_ms)


def _record_block(span: Any, code: str, layer: str) -> None:
    attrs = {
        _ATTR_ROUTE_KEY: _CHAT_ROUTE,
        "guardrail.layer": layer,
        "guardrail.code": code,
        **_EXTRA_ATTRS,
    }
    _guardrail_blocks.add(1, attrs)
    span.set_attribute("guardrail.blocked", True)
    span.set_attribute("guardrail.blocked_layer", layer)
    span.set_attribute("guardrail.blocked_code", code)


def _blocked(code: str, detail: str) -> JSONResponse:
    return JSONResponse(
        status_code=400,
        content={"error": "guardrail_violation", "code": code, "detail": detail},
    )
