"""tracing.py - Inicialização centralizada de OpenTelemetry.

Configura traces, métricas e logs para exportação paralela aos backends
habilitados: Azure Application Insights e/ou OTLP (gRPC).
"""

from __future__ import annotations

import logging
import os
from functools import lru_cache
from typing import Any

from opentelemetry import metrics, trace

logger = logging.getLogger(__name__)

_BOOTSTRAP_DONE: bool = False

# Leitura de configuração


def get_appinsights_connection_string() -> str:
    return os.environ.get("APPLICATIONINSIGHTS_CONNECTION_STRING", "").strip()


def get_otlp_endpoint() -> str:
    return os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "").strip().rstrip("/")


def get_service_name() -> str:
    return (
        os.environ.get("OTEL_SERVICE_NAME", "").strip()
        or os.environ.get("SERVICE_NAME", "").strip()
        or "agent"
    )


def get_deploy_env() -> str:
    return os.environ.get("DEPLOY_ENV", "").strip()


def get_export_targets() -> list[str]:
    targets: list[str] = []
    if get_appinsights_connection_string():
        targets.append("azure")
    if get_otlp_endpoint():
        targets.append("otlp")
    return targets


@lru_cache(maxsize=1)
def get_telemetry_attributes() -> dict[str, str]:
    attrs = {"service.name": get_service_name()}
    deploy_env = get_deploy_env()
    if deploy_env:
        attrs["deploy.environment"] = deploy_env
    return attrs


# Resource e providers


def _build_resource() -> Any:
    from opentelemetry.sdk.resources import Resource

    return Resource.create(get_telemetry_attributes())


def _get_tracer_provider(resource: Any) -> Any:
    from opentelemetry.sdk.trace import TracerProvider

    current = trace.get_tracer_provider()
    if isinstance(current, TracerProvider):
        return current

    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)
    return provider


def _get_meter_provider() -> Any | None:
    from opentelemetry.sdk.metrics import MeterProvider

    current = metrics.get_meter_provider()
    return current if isinstance(current, MeterProvider) else None


def _get_logger_provider(resource: Any) -> Any:
    from opentelemetry._logs import get_logger_provider, set_logger_provider
    from opentelemetry.sdk._logs import LoggerProvider

    current = get_logger_provider()
    if isinstance(current, LoggerProvider):
        return current

    provider = LoggerProvider(resource=resource)
    set_logger_provider(provider)
    return provider


# Detecção de exporters já instalados


def _trace_exporter_names(provider: Any) -> set[str]:
    active = getattr(provider, "_active_span_processor", None)
    processors: list[Any] = getattr(active, "_span_processors", [active]) if active else []
    return {
        type(proc.span_exporter).__name__
        for proc in processors
        if proc and getattr(proc, "span_exporter", None) is not None
    }


def _log_exporter_names(provider: Any) -> set[str]:
    multi = getattr(provider, "_multi_log_record_processor", None)
    processors = getattr(multi, "_log_record_processors", []) or []
    names: set[str] = set()
    for proc in processors:
        batch = getattr(proc, "_batch_processor", None)
        exporter = getattr(batch, "_exporter", None)
        if exporter:
            names.add(type(exporter).__name__)
    return names


def _metric_reader_exporters(provider: Any) -> set[str]:
    readers = getattr(provider, "_metric_readers", []) or []
    return {
        type(getattr(reader, "_exporter", None)).__name__
        for reader in readers
        if getattr(reader, "_exporter", None) is not None
    }


# Configuração de signals


def _configure_tracing(resource: Any, conn_str: str, otlp_endpoint: str) -> None:
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    provider = _get_tracer_provider(resource)
    existing = _trace_exporter_names(provider)

    if conn_str and "AzureMonitorTraceExporter" not in existing:
        from azure.monitor.opentelemetry.exporter import AzureMonitorTraceExporter

        provider.add_span_processor(
            BatchSpanProcessor(AzureMonitorTraceExporter(connection_string=conn_str))
        )

    if otlp_endpoint and "OTLPSpanExporter" not in existing:
        provider.add_span_processor(
            BatchSpanProcessor(OTLPSpanExporter(endpoint=otlp_endpoint))
        )


def _configure_metrics(resource: Any, conn_str: str, otlp_endpoint: str) -> None:
    from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader

    if _get_meter_provider() is not None:
        return

    readers: list[Any] = []

    if conn_str:
        from azure.monitor.opentelemetry.exporter import AzureMonitorMetricExporter

        readers.append(
            PeriodicExportingMetricReader(
                AzureMonitorMetricExporter(connection_string=conn_str)
            )
        )

    if otlp_endpoint:
        readers.append(
            PeriodicExportingMetricReader(OTLPMetricExporter(endpoint=otlp_endpoint))
        )

    if readers:
        metrics.set_meter_provider(MeterProvider(resource=resource, metric_readers=readers))


def _configure_logging(resource: Any, conn_str: str, otlp_endpoint: str) -> None:
    from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
    from opentelemetry.instrumentation.logging.handler import LoggingHandler
    from opentelemetry.sdk._logs.export import BatchLogRecordProcessor

    provider = _get_logger_provider(resource)
    existing = _log_exporter_names(provider)

    if conn_str and "AzureMonitorLogExporter" not in existing:
        from azure.monitor.opentelemetry.exporter import AzureMonitorLogExporter

        provider.add_log_record_processor(
            BatchLogRecordProcessor(AzureMonitorLogExporter(connection_string=conn_str))
        )

    if otlp_endpoint and "OTLPLogExporter" not in existing:
        provider.add_log_record_processor(
            BatchLogRecordProcessor(OTLPLogExporter(endpoint=otlp_endpoint))
        )

    root_logger = logging.getLogger()
    if not any(isinstance(h, LoggingHandler) for h in root_logger.handlers):
        root_logger.addHandler(
            LoggingHandler(level=logging.NOTSET, logger_provider=provider)
        )


# Instrumentações automáticas


def _instrument_httpx() -> None:
    try:
        from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor

        instrumentor = HTTPXClientInstrumentor()
        if not instrumentor.is_instrumented_by_opentelemetry:
            instrumentor.instrument()
    except Exception as exc:
        logger.warning("Falha ao instrumentar httpx: %s", exc)


def instrument_fastapi(app: Any) -> None:
    """Instrumenta a aplicação FastAPI com OpenTelemetry."""
    try:
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

        FastAPIInstrumentor.instrument_app(
            app,
            excluded_urls=os.environ.get("OTEL_PYTHON_EXCLUDED_URLS", ""),
        )
    except ImportError:
        pass
    except Exception as exc:
        logger.warning("Falha ao instrumentar FastAPI: %s", exc)


# API pública


def configure_telemetry() -> None:
    """Inicializa OpenTelemetry: traces, métricas e logs para Azure e OTLP."""
    global _BOOTSTRAP_DONE
    if _BOOTSTRAP_DONE:
        return

    conn_str = get_appinsights_connection_string()
    otlp_endpoint = get_otlp_endpoint()

    if not conn_str and not otlp_endpoint:
        logger.warning(
            "Nenhum exporter OTel configurado - defina "
            "APPLICATIONINSIGHTS_CONNECTION_STRING e/ou OTEL_EXPORTER_OTLP_ENDPOINT."
        )
        return

    try:
        resource = _build_resource()
        _configure_tracing(resource, conn_str, otlp_endpoint)
        _configure_metrics(resource, conn_str, otlp_endpoint)
        _configure_logging(resource, conn_str, otlp_endpoint)
        _instrument_httpx()
        _BOOTSTRAP_DONE = True
        logger.info(
            "OTel configurado: targets=%s service.name=%s deploy.env=%s",
            ",".join(get_export_targets()),
            get_service_name(),
            get_deploy_env() or "<unset>",
        )
    except ImportError as exc:
        logger.warning("Dependência de telemetria indisponível (%s).", exc)
    except Exception as exc:
        logger.exception("Falha ao configurar telemetria: %s", exc)


def get_langchain_tracer() -> Any | None:
    """Cria o AzureAIOpenTelemetryTracer para callbacks do LangChain/LangGraph.

    Retorna None quando o callback está desabilitado via env var ou quando a
    dependência langchain-azure-ai não está disponível.
    """
    if os.getenv("OTEL_LANGCHAIN_CALLBACK_ENABLED", "true").lower() == "false":
        return None

    try:
        from langchain_azure_ai.callbacks.tracers import AzureAIOpenTelemetryTracer
    except ImportError:
        logger.info("langchain-azure-ai não disponível - tracer LangChain desabilitado.")
        return None

    name = get_service_name()
    if name == "agent":
        name = "iaa-agent-minhas-financas"

    return AzureAIOpenTelemetryTracer(
        connection_string=None,
        enable_content_recording=os.getenv("OTEL_RECORD_CONTENT", "true").lower() == "true",
        name=name,
        auto_configure_azure_monitor=False,
    )


def silence_noisy_loggers() -> None:
    """Silencia loggers verbosos do Azure SDK e OpenTelemetry."""
    import warnings

    warnings.filterwarnings("ignore", category=UserWarning, module="azure.monitor.opentelemetry")
    warnings.filterwarnings("ignore", category=UserWarning, module="opentelemetry.instrumentation")
    warnings.filterwarnings("ignore", category=UserWarning, module="azure.ai.projects.telemetry")
    warnings.filterwarnings("ignore", category=UserWarning, module="langchain_openai")

    for name in [
        "azure",
        "azure.core.pipeline.policies.http_logging_policy",
        "azure.monitor",
        "azure.monitor.opentelemetry",
        "azure.monitor.opentelemetry.exporter",
        "azure.monitor.opentelemetry.exporter._quickpulse",
        "azure.ai.projects.telemetry",
        "opentelemetry",
        "urllib3.connectionpool",
    ]:
        logging.getLogger(name).setLevel(logging.WARNING)

    targets = get_export_targets()
    if targets:
        logger.info("Telemetria habilitada para: %s", ", ".join(targets))


def get_tracer(name: str = "agent") -> trace.Tracer:
    return trace.get_tracer(name)


def get_meter(name: str = "agent") -> metrics.Meter:
    return metrics.get_meter(name)
