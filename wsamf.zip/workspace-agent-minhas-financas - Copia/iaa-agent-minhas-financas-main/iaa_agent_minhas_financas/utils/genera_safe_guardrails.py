"""genera_safe_guardrails.py - Guardrail externo genérico via HTTP.

Erros de rede ou timeout nunca bloqueiam o tráfego.
"""

from __future__ import annotations

import logging
import os

import httpx

from iaa_agent_minhas_financas.config import get_config
from iaa_agent_minhas_financas.utils.ssl_context import build_ssl_context

logger = logging.getLogger(__name__)

_http_client: httpx.AsyncClient | None = None


def _get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None:
        ca_bundle = os.environ.get("REQUESTS_CA_BUNDLE")
        ssl_verify = build_ssl_context(ca_bundle=ca_bundle) if ca_bundle else True
        _http_client = httpx.AsyncClient(verify=ssl_verify)
    return _http_client


async def check_external_guardrail(
    message: str,
    messages: list | None = None,
) -> str | None:

    cfg = get_config().guardrails
    client_id = os.environ.get("GUARDRAIL_EXTERNAL_CLIENT_ID", "")

    if not cfg.enabled or not client_id:
        return None

    payload = {
        "action": "conversar",
        "body": {
            "data": {
                "input": message,
                "context": {"messages": messages or []},
            }
        },
        "agent_id": cfg.agent_id,
    }
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "X-Client-Id": client_id,
        "UOR": cfg.uor,
        "userIdentification": cfg.user_id,
    }

    try:
        client = _get_http_client()
        resp = await client.post(cfg.url, json=payload, headers=headers, timeout=cfg.timeout)
        logger.info("Guardrail[externo]: status recebido %d", resp.status_code)
        resp.raise_for_status()
        data = resp.json()
        if not data.get("allowed", True):
            return data.get("reason", "external_guardrail_rejection")
        if data.get("status") in ("blocked", "rejected", "violation"):
            return data.get("reason", "external_guardrail_rejection")
    except httpx.TimeoutException:
        logger.warning("Guardrail[externo]: timeout - ignorando bloqueio")
    except httpx.HTTPStatusError as exc:
        logger.warning(
            "Guardrail[externo]: HTTP %d - ignorando bloqueio", exc.response.status_code
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Guardrail[externo]: erro (%s) - ignorando bloqueio", exc)

    return None
