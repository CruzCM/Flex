"""rag/rag_tool.py - Ferramenta LangChain para recuperação via RAG (gateway Genera BB)."""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx
from langchain_core.tools import tool as _tool

from iaa_agent_minhas_financas.config import get_config
from iaa_agent_minhas_financas.utils.ssl_context import build_ssl_context

logger = logging.getLogger(__name__)

_http_client: httpx.AsyncClient | None = None


def _get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None:
        ca_bundle = os.environ.get("REQUESTS_CA_BUNDLE")
        ssl_verify = build_ssl_context(ca_bundle=ca_bundle) if ca_bundle else True
        _http_client = httpx.AsyncClient(verify=ssl_verify)
    return _http_client


async def _call_gateway(
    query: str,
    messages: list | None = None,
    total_context: int | None = None,
) -> list[Any]:
    cfg = get_config().rag
    client_id = os.environ.get("RAG_CLIENT_ID", "")

    if not cfg.enabled or not client_id or not cfg.agent_id:
        logger.debug("RAG: desativado ou não configurado - ignorando recuperação")
        return []

    payload = {
        "action": "recuperar-contexto",
        "body": {
            "data": {
                "input": query,
                "context": {
                    "messages": messages or [],
                    "total_context": total_context if total_context is not None else cfg.total_context,
                },
            }
        },
        "agent_id": cfg.agent_id,
    }
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "X-Client-Id": client_id,
        "UOR": cfg.uor,
        "userIdentification": cfg.user_id,
    }

    try:
        client = _get_http_client()
        resp = await client.post(cfg.url, json=payload, headers=headers, timeout=cfg.timeout)
        resp.raise_for_status()
        data = resp.json()
        context = (
            data.get("data", {})
            .get("output", {})
            .get("text", [{}])[0]
            .get("retrieved_contexts")
        )
        if isinstance(context, list):
            return context
        logger.warning("RAG: formato de contexto inesperado: %r", type(context))
        return []
    except httpx.TimeoutException:
        logger.warning("RAG: requisição expirou - retornando contexto vazio")
    except httpx.HTTPStatusError as exc:
        logger.warning("RAG: HTTP %d - retornando contexto vazio", exc.response.status_code)
    except Exception as exc:  # noqa: BLE001
        logger.warning("RAG: erro (%s) - retornando contexto vazio", exc)

    return []


def build_rag_tool(tool_name: str | None = None, tool_description: str | None = None):
    """Cria a ferramenta RAG com nome e descrição definidos em agent_config.yaml.

    Args:
        tool_name: Nome da ferramenta. Quando não informado, lê de
            ``agent_config.yaml`` via ``get_config().rag.tool_name``.
        tool_description: Descrição da ferramenta. Quando não informado, lê de
            ``get_config().rag.tool_description``.
    """
    cfg = get_config().rag
    name = tool_name if tool_name is not None else cfg.tool_name
    description = tool_description if tool_description is not None else cfg.tool_description

    @_tool(name, description=description)
    async def _retrieve(query: str, total_context: int = 5) -> list[Any]:
        return await _call_gateway(query, messages=None, total_context=total_context)

    return _retrieve
