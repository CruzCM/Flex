"""rag/__init__.py - API pública do módulo RAG.

A lógica de recuperação vive em :mod:`iaa_agent_minhas_financas.rag.rag_tool`, que a expõe tanto como
ferramenta LangChain (para o agente LangGraph) quanto como função async pura
para chamadores Python diretos.
"""

from iaa_agent_minhas_financas.rag.rag_tool import _call_gateway as retrieve  # noqa: F401

__all__ = ["retrieve"]
