"""graph.py - Agente LangGraph com suporte a MCP, RAG e OpenTelemetry."""

from __future__ import annotations

import asyncio
import logging
import ssl
from collections.abc import Callable
from typing import Annotated, Any

import httpx

from langchain_core.messages import AIMessage, BaseMessage, SystemMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from typing_extensions import TypedDict

from iaa_agent_minhas_financas.config import AgentConfig, get_config
from iaa_agent_minhas_financas.llm import LLMFactory
from iaa_agent_minhas_financas.rag.rag_tool import build_rag_tool
from iaa_agent_minhas_financas.utils.ssl_context import build_ssl_context
from iaa_agent_minhas_financas.utils.tracing import get_langchain_tracer

config = get_config()

_azure_tracer = get_langchain_tracer()

logger = logging.getLogger(__name__)

MCP_RAG_SERVER = "mcp-corporativo"
MCP_RAG_TOOLS = ("consultar_faq_minhas_financas", "consultar_educacao_financeira")


class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]


class AgentFactory:
    """Constrói um agente LangGraph compilado a partir de um AgentConfig."""

    @staticmethod
    def _make_httpx_client(ssl_ctx: ssl.SSLContext) -> Callable[..., httpx.AsyncClient]:
        def _client_factory(
            headers: Any = None,
            timeout: Any = None,
            auth: Any = None,
        ) -> httpx.AsyncClient:
            kw: dict[str, Any] = {"follow_redirects": True, "verify": ssl_ctx}
            if headers is not None:
                kw["headers"] = headers
            if timeout is not None:
                kw["timeout"] = timeout
            if auth is not None:
                kw["auth"] = auth
            return httpx.AsyncClient(**kw)
        return _client_factory

    @classmethod
    def _build_mcp_server_entry(cls, srv: Any) -> dict[str, Any]:
        cfg: dict[str, Any] = {
            "url": srv.transport.mcp_url,
            "transport": srv.transport.type,
        }

        merged_headers: dict[str, Any] = dict(srv.headers or {})
        token = srv.resolve_token()
        if token:
            merged_headers["Authorization"] = f"Bearer {token}"
        if merged_headers:
            cfg["headers"] = merged_headers

        cert = srv.resolve_cert()
        if cert:
            cert_path, key_path, ca_bundle = cert
            ssl_ctx = build_ssl_context(
                ca_bundle=ca_bundle,
                cert_path=cert_path,
                key_path=key_path,
            )
            cfg["httpx_client_factory"] = cls._make_httpx_client(ssl_ctx)

        return cfg

    @classmethod
    def _mcp_server_config(cls, config: AgentConfig) -> dict[str, Any]:
        return {srv.name: cls._build_mcp_server_entry(srv) for srv in config.mcp.servers}

    @staticmethod
    def _compile_graph(
        llm_with_tools: Any,
        tools: list[Any],
        instructions: str,
    ):

        async def llm_call(state: AgentState) -> dict[str, Any]:
            msgs: list[BaseMessage] = list(state["messages"])
            if not msgs or not isinstance(msgs[0], SystemMessage):
                msgs = [SystemMessage(content=instructions)] + msgs
            response: AIMessage = await llm_with_tools.ainvoke(msgs)

            if response.tool_calls:
                tool_names = [tc.get("name", "?") for tc in response.tool_calls]
                logger.info("LLM solicitou ferramentas: %s", tool_names)

            return {"messages": [response]}

        builder = StateGraph(AgentState)
        builder.add_node("llm_call", llm_call)
        builder.add_edge(START, "llm_call")

        if tools:
            builder.add_node("tools", ToolNode(tools))
            builder.add_conditional_edges("llm_call", tools_condition)
            builder.add_edge("tools", "llm_call")
        else:
            builder.add_edge("llm_call", END)

        return builder.compile()

    @classmethod
    async def create(
        cls,
        config: AgentConfig | None = None,
        *,
        rag_tools: list[str] | None = None,
    ):
        """Busca ferramentas MCP, instancia o LLM e compila o grafo."""
        if config is None:
            config = get_config()

        tools: list[Any] = []
        for srv_name, srv_cfg in cls._mcp_server_config(config).items():
            try:
                client = MultiServerMCPClient({srv_name: srv_cfg})
                srv_tools = await client.get_tools()
                if srv_name == MCP_RAG_SERVER:
                    srv_tools = [tool for tool in srv_tools if tool.name in MCP_RAG_TOOLS]
                    if rag_tools is not None:
                        rag_tools.extend(tool.name for tool in srv_tools)
                tool_names = [t.name for t in srv_tools]
                logger.info("MCP '%s': %d ferramenta(s) carregada(s): %s", srv_name, len(srv_tools), tool_names)
                tools.extend(srv_tools)
            except Exception as exc:
                cause = exc
                if hasattr(exc, 'exceptions'):
                    cause = exc.exceptions[0] if exc.exceptions else exc
                logger.warning("MCP '%s' indisponível, ignorando: %s", srv_name, cause)

        if config.rag.enabled:
            rag_tool = build_rag_tool(
                tool_name=config.rag.tool_name,
                tool_description=config.rag.tool_description,
            )
            rag_tool_name = getattr(rag_tool, "name", None)
            if rag_tool_name and rag_tool_name not in {getattr(t, "name", None) for t in tools}:
                tools.append(rag_tool)
                logger.info("Ferramenta RAG '%s' adicionada", rag_tool_name)

        llm = LLMFactory.create(config.llm.provider, config.temperature, config.top_p)
        llm_with_tools = llm.bind_tools(tools) if tools else llm
        logger.info("Agente compilado com %d ferramenta(s)", len(tools))

        return cls._compile_graph(llm_with_tools, tools, config.instructions)


class AgentGraph:
    """Fachada pública leve; delega a construção do grafo ao AgentFactory."""

    def __init__(self) -> None:
        self._compiled: Any = None
        self._lock: asyncio.Lock = asyncio.Lock()
        self.ferramentas_rag_disponiveis: tuple[str, ...] = ()

    @property
    def is_ready(self) -> bool:
        """Retorna True quando o grafo foi compilado com sucesso."""
        return self._compiled is not None

    async def compile(self) -> None:
        """Pré-compila o grafo antecipadamente (usado no startup do FastAPI)."""
        if not self.is_ready:
            async with self._lock:
                if not self.is_ready:
                    rag_tools: list[str] = []
                    self._compiled = await AgentFactory.create(rag_tools=rag_tools)
                    self.ferramentas_rag_disponiveis = tuple(rag_tools)

    async def ainvoke(
        self,
        state: dict[str, Any],
        *,
        execution_messages: list[BaseMessage] | None = None,
    ) -> dict[str, Any]:
        await self.compile()
        callbacks = [_azure_tracer] if _azure_tracer else []

        from opentelemetry.propagate import inject

        headers: dict[str, str] = {}
        inject(headers)
        metadata = {"traceparent": headers["traceparent"]} if headers.get("traceparent") else {}

        if execution_messages is not None:
            # Captura local à requisição, inclusive o último estado antes de uma falha.
            result: dict[str, Any] = state
            async for result in self._compiled.astream(
                state, config={"callbacks": callbacks, "metadata": metadata}, stream_mode="values"
            ):
                execution_messages[:] = result.get("messages", [])
            return result

        return await self._compiled.ainvoke(
            state, config={"callbacks": callbacks, "metadata": metadata}
        )

    def invoke(self, state: dict[str, Any]) -> dict[str, Any]:
        return asyncio.run(self.ainvoke(state))


graph = AgentGraph()
