"""__main__.py - Entrypoint do microsserviço de agente."""

import argparse
import logging
import sys
from pathlib import Path

from dotenv import load_dotenv
import uvicorn

from iaa_agent_minhas_financas.utils.tracing import silence_noisy_loggers

_PKG_DIR = str(Path(__file__).parent)
if _PKG_DIR not in sys.path:
    sys.path.insert(0, _PKG_DIR)

_LOG_FORMAT = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"
_LOG_DATE_FMT = "%Y-%m-%dT%H:%M:%S"


class HealthCheckFilter(logging.Filter):
    """Filtra logs de health checks e métricas do K8s."""

    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        return not any(
            p in message
            for p in ["GET /health/live", "GET /health/ready", "GET /metrics"]
        )


def main():
    load_dotenv(Path(__file__).parent.parent / ".env")

    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--log-level", default="info")
    args = parser.parse_args()

    logging.basicConfig(
        level=args.log_level.upper(),
        format=_LOG_FORMAT,
        datefmt=_LOG_DATE_FMT,
        force=True,
    )

    silence_noisy_loggers()

    logging.getLogger("uvicorn.access").addFilter(HealthCheckFilter())

    uvicorn.run(
        "iaa_agent_minhas_financas.app:app",
        host=args.host,
        port=args.port,
        workers=args.workers,
        log_level=args.log_level,
        access_log=True,
    )


if __name__ == "__main__":
    main()
