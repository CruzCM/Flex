# Guia de configuração Agente → MCP Minhas Finanças — HML

Este guia permite preparar a configuração e testar a integração pelo Insomnia.
O código está preparado localmente; a comprovação corporativa depende da imagem
implantada, das credenciais autorizadas e dos testes em homologação.

Não é necessário executar comandos `oc` ou Kubernetes. As ações de OpenShift
abaixo são feitas no navegador, por você, dentro do ambiente corporativo.
Os certificados e a requisição do Insomnia que já funcionam devem ser mantidos.

## Parte A — O que foi implementado

O fluxo é: **Insomnia → Agente → gateway MCP HML → MCP → GeneraBB → resposta**.

| Sua pergunta | Ferramenta que o agente deve escolher |
| --- | --- |
| Uso, telas, funcionalidades e navegação do aplicativo | `consultar_faq_minhas_financas` |
| Orçamento, poupança, dívidas e planejamento financeiro | `consultar_educacao_financeira` |
| Saudação, como “Olá!” | Nenhuma dessas duas ferramentas |

O agente envia a pergunta à ferramenta e usa os trechos devolvidos para responder.
As credenciais e a lógica de consulta ao GeneraBB continuam no MCP.
As demais ferramentas legítimas e funcionalidades do agente permanecem disponíveis.
As ferramentas de exemplo do nosso MCP não são oferecidas ao modelo.
A entrada `local-mcp` está fora da configuração ativa de HML; seus componentes
não foram apagados. O RAG legado mantém sua configuração anterior.

O diagnóstico opcional mostra resultados das mensagens de ferramenta do LangGraph.
Uma frase como “consultei a base” na resposta do modelo não é evidência suficiente.
O agente correlaciona a chamada e seu resultado pelo `tool_call_id`, internamente.
Não expõe credenciais nem os contextos integrais no diagnóstico.

**Limite da validação local:** os testes simulam a rede e a escolha da LLM.
A seleção correta da ferramenta pelo modelo real deve ser verificada em HML.
Nenhuma chamada corporativa foi feita a partir desta cópia.

### Termos usados neste guia

| Termo | Significado |
| --- | --- |
| Agente | Aplicação que recebe sua pergunta e produz a resposta |
| MCP | Servidor que disponibiliza as duas ferramentas de consulta |
| Contexto | Trecho de documento recuperado para fundamentar a resposta |
| Secret | Recurso do OpenShift que armazena configurações sensíveis |
| Key / Value | Nome exato da variável / valor autorizado a preencher |
| Deployment / Pod | Configuração da aplicação / instância em execução |
| Rollout | Substituição controlada dos pods para carregar imagem/configuração |

## Parte B — O que configurar em HML

### 1. Confira os valores e o projeto correto

As configurações do **agente** pertencem ao projeto
`iaa-agent-minhas-financas`, na Secret existente **`env`**.
Isso foi observado no snapshot `OPENSHIFT_TEMPLATE_INICIAL.txt`, mantido na raiz
do workspace de revisão, e na referência `envFrom.secretRef.name: env` do chart
no repositório de deploy do agente para homologação. Confirme a mesma referência
no Deployment efetivamente implantado; a cópia local não comprova o estado do cluster.

| Configuração | Onde fica | O que fazer |
| --- | --- | --- |
| `MCP_APP_KEY` | Secret `env` do agente | Preencher com AppKey autorizada para consumir o gateway do MCP |
| `MCP_CTL_ENDPOINT` | Secret `env` do agente, se houver sobrescrita | Conferir o endereço HML abaixo; pode ser cadastrado explicitamente |
| `GATEWAY_OUTBOUND_GW_APP_KEY` | Secret `env` do agente | Preservar o valor existente, usado pelo gateway da LLM |
| Certificados do agente | Secret e volumes existentes de `idh-mtls` | Preservar; conferir caminhos e montagem no pod |
| Credenciais GeneraBB | Secret `iaa-mcp-mf-rag-credentials` no projeto `iaa-mcp-mf` | Configurar no MCP conforme o guia próprio |

Endereço preparado como padrão no código:

```text
https://iaa-mcp-mf.ai-interno.api.hm.bb.com.br/v1/mcp
```

`MCP_APP_KEY` alimenta o header existente **`gw-dev-app-key`** na conexão
**Agente → MCP**. Não é um campo do JSON enviado pelo Insomnia.
Não presuma que a chave da LLM tem autorização para o MCP: confirme isso com
o responsável pelo gateway. Não acrescente `Bearer` ao valor da AppKey.

Uma variável `MCP_CTL_ENDPOINT` não vazia tem prioridade sobre o padrão do YAML.
Assim, um valor antigo pode encaminhar a aplicação a outro servidor mesmo com
o código atualizado. O loader também usa o padrão se essa variável estiver vazia.

### 2. Preencha a Secret pela interface gráfica

Os nomes de controles abaixo são documentados para o console padrão OpenShift
4.x. A versão e a tradução da instalação corporativa não foram acessadas.
Se algum controle não estiver disponível, confira suas permissões e a versão
com o administrador, sem criar recursos alternativos.

1. Abra o console HML conhecido e faça login.
2. Na visão **Administrator**, selecione em **Project** o projeto
   **`iaa-agent-minhas-financas`**.
3. Abra **Workloads → Secrets** e localize **`env`**.
4. No menu de opções da Secret, selecione **Edit Secret**.
5. Use **Add Key/Value** para acrescentar `MCP_APP_KEY`. Em **Value**, preencha
   a chave autorizada. Se a chave já existir, atualize a entrada existente.
6. Confira `MCP_CTL_ENDPOINT`. Cadastre ou ajuste o valor para o endereço HML
   indicado acima, se quiser explicitá-lo na Secret.
7. Preserve as outras entradas, especialmente `GATEWAY_OUTBOUND_GW_APP_KEY`.
8. Clique em **Save**. Não compartilhe imagens com valores revelados.

Esses controles são descritos na
[documentação Red Hat para Secrets](https://docs.redhat.com/en-us/documentation/openshift_container_platform/4.13/pdf/support/OpenShift_Container_Platform-4.13-Support-en-US.pdf).
Se a Secret `env` estiver ausente, primeiro confirme o projeto e a referência do
Deployment com o responsável. Não substitua uma Secret existente por uma vazia.

### 3. Confira como as variáveis chegam ao agente

1. No mesmo projeto, abra **Workloads → Deployments**.
2. Abra o Deployment que executa o agente. O nome efetivo deve ser conferido
   na lista; o nome do projeto não garante o nome do Deployment.
3. Na visualização **YAML**, apenas leia `spec.template.spec.containers`.
4. No container da aplicação, confira a presença de:

   ```yaml
   envFrom:
     - secretRef:
         name: env
   ```

5. Confira também `env`. Uma entrada explícita com o mesmo nome tem prioridade
   sobre a variável importada de `envFrom`. Se houver duplicidade, peça ao
   responsável pela configuração corporativa que a resolva na fonte oficial.
6. Confira os caminhos abaixo e a montagem correspondente dos certificados.
   São os valores observados no chart local, a confirmar no pod real:

| Variável | Caminho previsto |
| --- | --- |
| `KEY_STORE_CERT_PATH` | `/app/certs/tls.crt` |
| `KEY_STORE_KEY_PATH` | `/app/certs/tls.key` |
| `TRUST_STORE_CA_PATH` | `/app/certs/ca.crt` |
| `REQUESTS_CA_BUNDLE` e `SSL_CERT_FILE` | `/etc/pki/tls/certs/ca-bundle.crt` |

A presença das abas YAML, Pods e Environment foi conferida no
[código oficial do console OpenShift para Deployments](https://github.com/openshift/console/blob/master/frontend/public/components/deployment.tsx).
Esta etapa é uma conferência visual: não pede edição do Deployment, Helm ou GitOps.
Não copie valores de Secrets para arquivos de código.

### 4. Confira o MCP antes de iniciar o agente atualizado

No projeto **`iaa-mcp-mf`**, o MCP precisa estar implantado com as duas ferramentas
e a Secret **`iaa-mcp-mf-rag-credentials`** carregada no container.
Use o documento `GUIA-CONFIGURACAO-RAG-HML.md`, disponível na raiz do repositório
do MCP (pasta local `iaa-mcp-mf-main`), como referência para as seis credenciais
autorizadas de FAQ e Educação.

Confirme com o responsável os índices, permissões e conteúdo das duas bases.
Os nomes presentes no código do MCP são referências; não comprovam que as bases
reais estejam alimentadas ou homologadas. Não transfira os JWTs, UORs ou
identidades técnicas do GeneraBB para o agente.

A descoberta ocorre na inicialização do agente. Se o MCP estiver indisponível,
o agente continua iniciando, mas seu catálogo RAG fica vazio ou incompleto.
O health check do agente estar pronto não comprova acesso ao MCP.

### 5. Carregue as configurações nos novos pods

Prepare a Secret e deixe o MCP disponível **antes** do rollout da imagem nova
do agente. Uma alteração na Secret não atualiza as variáveis de pods já em execução.

Se precisar reiniciar o agente após corrigir a configuração ou disponibilizar o MCP:

1. Em **Workloads → Deployments**, selecione o Deployment correto do agente.
2. No menu de ações, use **Restart Rollout**, conforme suas permissões.
3. Aguarde a conclusão e confira os pods prontos antes do teste.

O caminho e a ação são documentados pela
[Red Hat para reinício de Deployment](https://docs.redhat.com/en/documentation/red_hat_openshift_ai_self-managed/2.13/html/installing_and_uninstalling_openshift_ai_self-managed_in_a_disconnected_environment/enabling-nvidia-gpus_install).
O reinício carrega a imagem configurada; ele não garante que a imagem contenha
este código. Confira o digest efetivo após a esteira.

### 6. O que já ficou preparado localmente

O arquivo `.env`, na raiz deste repositório, foi criado a partir de
[.env.example](.env.example), que permanece intacto. Ele contém o endpoint MCP HML,
`MCP_APP_KEY=` vazia, o gateway LLM HML e campos sensíveis sem valores reais.
O entrypoint existente carrega esse arquivo; testes não iniciam conexões reais.

O `.env` já é excluído pelo `.gitignore` e pelo `.dockerignore` existentes.
**Não envie o `.env` ao repositório nem à imagem.** Em HML, as variáveis vêm
da Secret e da configuração do container. Não é necessário copiar o `.env`
para o OpenShift ou inserir valores reais nesta entrega.

## Parte C — Como testar no Insomnia

### 1. Use a requisição que já funciona

1. Abra sua requisição existente do agente.
2. Confira o método **POST**.
3. Mantenha a URL real já configurada, no formato:

   ```text
   https://***-interno.api.hm.bb.com.br/v1/chat
   ```

4. Não substitua o hostname pelos asteriscos nem pelo endereço do MCP.
5. Em **Body**, selecione o formato **JSON** e cole um dos exemplos abaixo.
6. Mantenha certificados, autenticação e headers existentes. Confira que o corpo
   está sendo enviado como `application/json`.
7. Clique em **Send** e observe o status HTTP e o JSON da resposta.

Os controles são descritos na
[documentação oficial do Insomnia](https://developer.konghq.com/insomnia/requests/).
A rota interna permanece `/chat`; o caminho externo `/v1/chat` é o já utilizado
pelo gateway. Não foi criado outro endpoint.

### 2. Entenda o contrato

| Campo da requisição | Como usar |
| --- | --- |
| `message` | Texto obrigatório da pergunta |
| `session_id` | Texto opcional; pode ser omitido |
| `incluir_diagnostico_mcp` | `true` para ativar; omitido ou `false` mantém resposta original |

O `session_id` continua sendo devolvido e usado pela telemetria. O template
atual não usa esse campo para persistir histórico entre requisições.

| Campo da resposta | Como interpretar |
| --- | --- |
| `reply` | Resposta normal do agente, passando pelos guardrails existentes |
| `session_id` | Valor enviado; `null` quando omitido |
| `tool_calls_made` | Quantidade de `ToolMessage`, incluindo ferramentas não RAG |
| `diagnostico_mcp` | Só aparece quando solicitado |
| `ferramentas_rag_disponiveis` | Ferramentas descobertas na inicialização, não um teste de conexão contínuo |
| `execucoes` | Resultados RAG correlacionados às chamadas deste turno |
| `ferramenta_executada` | Ferramenta do último resultado RAG correlacionado |
| `status_ferramenta` | Status do último resultado, ou classificação local explicitada abaixo |
| `total_contextos` | Contagem recebida da ferramenta; `null` se desconhecida |

Os exemplos a seguir são **ilustrativos**, com texto e contagens sintéticos.
Não são respostas obtidas no ambiente corporativo. O texto da LLM e as contagens
reais variam conforme a pergunta e a base consultada.

### 3. Cenário A — FAQ do aplicativo

Envie:

```json
{
  "message": "Como faço para visualizar meus gastos no Minhas Finanças?",
  "session_id": "hml-faq",
  "incluir_diagnostico_mcp": true
}
```

Exemplo de estrutura com sucesso:

```json
{
  "reply": "Resposta sobre o aplicativo, fundamentada nos trechos recuperados.",
  "session_id": "hml-faq",
  "tool_calls_made": 1,
  "diagnostico_mcp": {
    "ferramentas_rag_disponiveis": [
      "consultar_faq_minhas_financas",
      "consultar_educacao_financeira"
    ],
    "ferramenta_executada": "consultar_faq_minhas_financas",
    "status_ferramenta": "sucesso",
    "total_contextos": 2,
    "execucoes": [
      {
        "ferramenta": "consultar_faq_minhas_financas",
        "status": "sucesso",
        "total_contextos": 2
      }
    ]
  }
}
```

Confira o nome em `execucoes`, o status, a contagem e a qualidade do `reply`.
O número `2` não é requisito: avalie a quantidade real devolvida.

### 4. Cenário B — Educação Financeira

Envie:

```json
{
  "message": "Como posso organizar meu orçamento mensal?",
  "session_id": "hml-educacao",
  "incluir_diagnostico_mcp": true
}
```

Exemplo de resposta:

```json
{
  "reply": "Orientação de educação financeira baseada nos contextos recuperados.",
  "session_id": "hml-educacao",
  "tool_calls_made": 1,
  "diagnostico_mcp": {
    "ferramentas_rag_disponiveis": [
      "consultar_faq_minhas_financas",
      "consultar_educacao_financeira"
    ],
    "ferramenta_executada": "consultar_educacao_financeira",
    "status_ferramenta": "sucesso",
    "total_contextos": 3,
    "execucoes": [
      {
        "ferramenta": "consultar_educacao_financeira",
        "status": "sucesso",
        "total_contextos": 3
      }
    ]
  }
}
```

Se a resposta disser que pesquisou, mas `execucoes` estiver vazio, não houve
resultado RAG correlacionado. Não aceite a frase da LLM como comprovação.

### 5. Cenário C — Saudação sem consulta

Envie:

```json
{"message": "Olá, bom dia!", "incluir_diagnostico_mcp": true}
```

Exemplo esperado, com ambas as ferramentas descobertas:

```json
{
  "reply": "Olá! Como posso ajudar?",
  "session_id": null,
  "tool_calls_made": 0,
  "diagnostico_mcp": {
    "ferramentas_rag_disponiveis": [
      "consultar_faq_minhas_financas",
      "consultar_educacao_financeira"
    ],
    "ferramenta_executada": null,
    "status_ferramenta": null,
    "total_contextos": 0,
    "execucoes": []
  }
}
```

A lista de disponíveis pode estar preenchida sem haver execução.
Repita a saudação com `session_id: "hml-faq"`: o diagnóstico não deve repetir
a consulta do teste anterior.

### 6. Cenário D — Sem resultados ou erro

Combine com o responsável pela base uma pergunta sem conteúdo correspondente.
Não existe uma frase universal que garanta `sem_resultados`, pois a busca pode
devolver trechos aproximados. Não provoque falhas no cluster para testar.

Exemplo de retorno sem resultados:

```json
{
  "reply": "Não encontrei conteúdo suficiente na base para responder.",
  "session_id": null,
  "tool_calls_made": 1,
  "diagnostico_mcp": {
    "ferramentas_rag_disponiveis": [
      "consultar_faq_minhas_financas",
      "consultar_educacao_financeira"
    ],
    "ferramenta_executada": "consultar_faq_minhas_financas",
    "status_ferramenta": "sem_resultados",
    "total_contextos": 0,
    "execucoes": [
      {
        "ferramenta": "consultar_faq_minhas_financas",
        "status": "sem_resultados",
        "total_contextos": 0
      }
    ]
  }
}
```

Se o MCP devolver `timeout`, `erro_http`, `erro_tls`, `erro_conexao`,
`credencial_ausente`, `credencial_invalida`, `acesso_negado`, `nao_configurado`,
`configuracao_invalida`, `entrada_invalida`, `resposta_inesperada` ou
`erro_interno`, esse status aparece no diagnóstico com sua contagem recebida.
A resposta HTTP pode continuar `200`, pois o MCP retornou um resultado de erro
e a LLM conseguiu responder que a consulta não foi concluída.

Há duas classificações locais, que **não são status inventados do MCP**:

| Classificação | Significado |
| --- | --- |
| `erro_execucao` | O adaptador/ToolNode produziu uma mensagem de ferramenta com status `error` |
| `retorno_nao_interpretavel` | O resultado não tem status e contagem reconhecíveis |

Nesses dois casos, `total_contextos` é `null`: a quantidade é desconhecida,
não zero comprovado. Um status futuro ainda não reconhecido também produz
`retorno_nao_interpretavel`, evitando copiar texto arbitrário para o diagnóstico.

Se a execução do grafo for interrompida por falha de transporte, preservam-se
os códigos HTTP anteriores (como `502` ou `504`). Com diagnóstico solicitado,
o erro inclui o que foi observado até a interrupção. Exemplo HTTP `504`:

```json
{
  "detail": "Tempo limite excedido ao processar a requisição.",
  "diagnostico_mcp": {
    "ferramentas_rag_disponiveis": [
      "consultar_faq_minhas_financas",
      "consultar_educacao_financeira"
    ],
    "ferramenta_executada": null,
    "status_ferramenta": null,
    "total_contextos": 0,
    "execucoes": [],
    "chamadas_sem_resultado": [
      {"ferramenta": "consultar_faq_minhas_financas", "status": "sem_retorno"}
    ]
  }
}
```

`chamadas_sem_resultado` só aparece quando há chamada emitida sem resultado
correspondente observado. Isso não confirma se o servidor chegou a executar
a consulta. Em erros HTTP, o contrato continua usando `detail`, sem inventar
um `reply`. Erros anteriores à invocação (validação ou bloqueio de guardrail)
mantêm suas respostas existentes e podem não ter diagnóstico.

### 7. Cenário E — Compatibilidade sem diagnóstico

Envie sem a flag:

```json
{"message": "Olá, bom dia!"}
```

Exemplo:

```json
{"reply": "Olá! Como posso ajudar?", "session_id": null, "tool_calls_made": 0}
```

Repita com `"incluir_diagnostico_mcp": false`. Em ambos os casos,
`diagnostico_mcp` deve estar **ausente**, não apenas preenchido com `null`.

### 8. Como guardar evidência útil

Registre pergunta, horário, status HTTP, resposta e imagem/digest em execução.
Compare o conteúdo do `reply` com o retorno esperado da base e confira
`execucoes`. Se houver múltiplas consultas, a lista contém todas as mensagens
RAG correlacionadas, na ordem do estado retornado pelo grafo; os campos simples
resumem a última da lista. Essa ordem não é uma medição de tempo de conclusão
de ferramentas paralelas. `tool_calls_made` pode incluir ferramentas não RAG.

Guarde somente evidências sem credenciais, certificados ou dados pessoais.

## Parte D — Resolução de problemas

| Sintoma | Significado provável | O que conferir | Onde conferir |
| --- | --- | --- | --- |
| `ferramentas_rag_disponiveis: []` | Descoberta falhou ou servidor sem RAGs | Endpoint, AppKey, certificados e disponibilidade no startup | Secret `env`, Deployment e logs do pod do agente |
| Só uma ferramenta disponível | Catálogo parcial ou imagem antiga do MCP | Implantação das duas ferramentas e reinício posterior do agente | Projeto `iaa-mcp-mf` e depois projeto do agente |
| AppKey ausente/incorreta | Gateway pode recusar a descoberta | `MCP_APP_KEY` e sua autorização de consumo | Secret `env` e responsável pelo gateway |
| Disponíveis preenchidas, `execucoes: []` | Nenhuma consulta RAG correlacionada | Pergunta, decisão do modelo e eventual `chamadas_sem_resultado` | JSON do Insomnia e logs do agente |
| Saudação sem execução | Comportamento esperado | Resposta normal | Insomnia |
| `sem_resultados`, contagem zero | Ferramenta consultada sem conteúdo recuperado | Pergunta, índice e alimentação da base | Responsável pelo MCP/GeneraBB |
| `credencial_ausente`/`nao_configurado` no resultado | Configuração interna do RAG ausente | Credenciais do GeneraBB carregadas no MCP | Secret `iaa-mcp-mf-rag-credentials` e pod MCP |
| `timeout` no diagnóstico com HTTP 200 | MCP devolveu falha da consulta | Serviço GeneraBB e prazo configurado | Logs do MCP, sem compartilhar segredos |
| HTTP 502/504 e `sem_retorno` | Grafo interrompido sem resultado correspondente | Rede/gateway MCP, disponibilidade e logs | Pods do agente/MCP e equipe responsável |
| `erro_execucao` ou retorno não interpretável | Erro do protocolo/ferramenta ou formato inesperado | Versão do MCP e payload público | Logs autorizados e código do MCP |
| Flag `true`, sem diagnóstico em resposta 200 | Imagem antiga, rota diferente ou resposta intermediária | Corpo enviado, endpoint e digest implantado | Insomnia e Deployment |
| Alterei Secret, mas nada mudou | Pod antigo ou variável explícita sobrescrevendo Secret | Referência `envFrom`, `env` e novo rollout | Deployment do agente |
| Erro da LLM antes da ferramenta | Problema no fluxo preexistente do modelo | Chave da LLM, deployment, profile e parâmetros aceitos | Secret `env` e gateway LLM; não atribuir automaticamente ao MCP |

## Parte E — Checklist de merge e teste em HML

### Pronto nesta entrega local

- [x] Gateway HML como padrão e precedência de ENV preservada.
- [x] Duas ferramentas RAG filtradas somente no servidor `mcp-corporativo`.
- [x] Outras ferramentas, arquitetura, versão `0.1.0` e template preservados.
- [x] Diagnóstico opcional com resultados reais do grafo e isolamento por chamada.
- [x] `.env` local sem credenciais reais e `.env.example` intacto.
- [x] Testes locais e Flake8 dos arquivos alterados aprovados.
- [x] Comparação verificável e changelog entregues.
- [x] MCP, Helm, GitOps, pipelines e `publicarPacoteEImagem: false` intactos.

### Ações suas, em ordem

1. Obter a AppKey autorizada para o gateway MCP e confirmar o endpoint HML.
2. Confirmar que o MCP atualizado, suas credenciais e ambas as bases funcionam.
3. No projeto do agente, preencher/conferir `MCP_APP_KEY` e
   `MCP_CTL_ENDPOINT` na Secret `env`, preservando as demais chaves.
4. Conferir no Deployment real a referência à Secret, possíveis sobrescritas
   em `env`, certificados e montagem de volumes.
5. Levar ao repositório corporativo somente os seis arquivos desta entrega:
   `agent_config.yaml`, `iaa_agent_minhas_financas/graph.py`,
   `iaa_agent_minhas_financas/app.py`, `tests/unit/test_mcp_hml.py`,
   `CHANGELOG.md` e este `GUIA-CONFIGURACAO-AGENTE-MCP-HML.md`.
   Não levar `.env`, ambientes virtuais, originais arquivados ou certificados
   de testes.
6. Revisar a comparação, realizar o merge autorizado e acompanhar a esteira.
7. Confirmar como a esteira disponibilizou a nova imagem/digest. O chart local
   ainda contém a tag histórica `0.1.0.dev0`, e a publicação permanece `false`.
   Esses valores não foram alterados: a equipe responsável deve confirmar o
   mecanismo de entrega efetivo. Não basta assumir que merge atualizou o pod.
8. Com o MCP acessível, concluir o rollout do agente e conferir os pods prontos.
   Se o agente iniciou antes do MCP, executar o reinício controlado descrito acima.
9. Executar os cenários A, B, C, D e E no Insomnia. Não induzir falhas reais
   para obter o cenário D; usar condição autorizada ou registrar sua pendência.
10. Conferir resposta fundamentada, ferramenta apropriada, status e contagem
    reais; guardar evidências sem segredos e registrar a homologação.

O aceite local está detalhado no documento `RELATORIO-ENTREGA-ETAPA5-MCP-HML.md`,
mantido fora deste repositório, na raiz do workspace de revisão da entrega.
Os testes locais não substituem o aceite corporativo no Insomnia.
