"""conftest.py - fixtures pytest compartilhados e configuração de sys.path."""

import os
import sys
from pathlib import Path

# Adiciona a raiz do repositório ao sys.path para que `from iaa_agent_minhas_financas.xxx import ...`
# resolva da mesma forma que em tempo de execução (espelha o PYTHONPATH=/app
# definido no Dockerfile).
_ROOT_DIR = str(Path(__file__).parent.parent)
if _ROOT_DIR not in sys.path:
    sys.path.insert(0, _ROOT_DIR)

# Desabilita exporters OTel durante os testes para evitar threads de exportação
# em background e erros de rede não relacionados aos testes.
for _otel_var in (
    "APPLICATIONINSIGHTS_CONNECTION_STRING",
    "OTEL_EXPORTER_OTLP_ENDPOINT",
):
    os.environ.pop(_otel_var, None)
