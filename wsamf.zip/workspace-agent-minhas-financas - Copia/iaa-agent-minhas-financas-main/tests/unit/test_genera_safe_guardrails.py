"""Testes unitários para iaa_agent_minhas_financas/utils/genera_safe_guardrails.py."""

from contextlib import contextmanager
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

import iaa_agent_minhas_financas.utils.genera_safe_guardrails as gsg_module
from iaa_agent_minhas_financas.utils.genera_safe_guardrails import check_external_guardrail


def _make_gsg_cfg(enabled=True, client_id="client-id-test"):
    cfg = MagicMock()
    cfg.guardrails.enabled = enabled
    cfg.guardrails.uor = "uor-test"
    cfg.guardrails.user_id = "user-test"
    cfg.guardrails.agent_id = "agente-curador-iagen"
    cfg.guardrails.url = "https://fake-gateway/agent"
    cfg.guardrails.timeout = 5.0
    return cfg, client_id


@contextmanager
def _patch_gsg(**overrides):
    """Patcha get_config e GUARDRAIL_EXTERNAL_CLIENT_ID, e reseta o cliente HTTP."""
    enabled = overrides.get("ENABLED", True)
    client_id = overrides.get("CLIENT_ID", "client-id-test")
    cfg, cid = _make_gsg_cfg(enabled=enabled, client_id=client_id)
    gsg_module._http_client = None  # força recriação do cliente
    with patch("iaa_agent_minhas_financas.utils.genera_safe_guardrails.get_config", return_value=cfg):
        env_patch = {"GUARDRAIL_EXTERNAL_CLIENT_ID": cid} if cid else {}
        with patch.dict("os.environ", env_patch, clear=False):
            if not cid:
                import os
                os.environ.pop("GUARDRAIL_EXTERNAL_CLIENT_ID", None)
            yield


def _mock_http_client(post_return=None, post_side_effect=None):
    """Cria um mock de AsyncClient e injeta no módulo."""
    mock_client = MagicMock(spec=httpx.AsyncClient)
    if post_side_effect:
        mock_client.post = AsyncMock(side_effect=post_side_effect)
    else:
        mock_client.post = AsyncMock(return_value=post_return)
    gsg_module._http_client = mock_client
    return mock_client


# Construção do cliente HTTP


def _make_self_signed_cert(tmp_path) -> Path:
    cert = tmp_path / "ca.pem"
    import subprocess
    subprocess.run(
        [
            "openssl", "req", "-x509", "-newkey", "rsa:2048",
            "-keyout", str(tmp_path / "key.pem"),
            "-out", str(cert), "-days", "1", "-nodes",
            "-subj", "/CN=test-ca",
        ],
        check=True,
        capture_output=True,
    )
    return cert


def test_get_http_client(monkeypatch, tmp_path, caplog):
    """Consolida construção do cliente HTTP com CA válido, sem CA e CA ausente."""
    # com CA bundle válido
    gsg_module._http_client = None
    cert = _make_self_signed_cert(tmp_path)
    monkeypatch.setenv("REQUESTS_CA_BUNDLE", str(cert))
    client = gsg_module._get_http_client()
    assert isinstance(client, httpx.AsyncClient)
    assert client is gsg_module._get_http_client()  # singleton

    # CA bundle inexistente deve logar warning mas ainda criar cliente
    gsg_module._http_client = None
    monkeypatch.setenv("REQUESTS_CA_BUNDLE", "/caminho/que/nao/existe.pem")
    with caplog.at_level("WARNING"):
        client = gsg_module._get_http_client()
    assert "CA bundle" in caplog.text
    assert isinstance(client, httpx.AsyncClient)


def _mock_http_response(body: dict, status_code: int = 200):
    """Cria um mock de resposta httpx."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = body
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    else:
        resp.raise_for_status.return_value = None
    return resp


# Verificações de curto-circuito (sem chamada HTTP)


@pytest.mark.asyncio
async def test_disabled_returns_none():
    with _patch_gsg(ENABLED=False):
        result = await check_external_guardrail("qualquer mensagem")
    assert result is None


@pytest.mark.asyncio
async def test_empty_client_id_returns_none():
    with _patch_gsg(CLIENT_ID=""):
        result = await check_external_guardrail("qualquer mensagem")
    assert result is None


# Resposta allow (None esperado)


@pytest.mark.asyncio
async def test_guardrail_response_parsing():
    """Consolida interpretação das respostas permitidas e bloqueadas."""
    # permitidas
    with _patch_gsg():
        _mock_http_client(post_return=_mock_http_response({"allowed": True}))
        assert await check_external_guardrail("ok") is None

    with _patch_gsg():
        _mock_http_client(post_return=_mock_http_response({"status": "ok"}))
        assert await check_external_guardrail("sem allowed") is None

    # bloqueadas
    with _patch_gsg():
        _mock_http_client(
            post_return=_mock_http_response(
                {"allowed": False, "reason": "conteudo_inapropriado"}
            )
        )
        assert await check_external_guardrail("ruim") == "conteudo_inapropriado"

    with _patch_gsg():
        _mock_http_client(post_return=_mock_http_response({"allowed": False}))
        assert await check_external_guardrail("ruim sem motivo") == "external_guardrail_rejection"

    with _patch_gsg():
        _mock_http_client(
            post_return=_mock_http_response({"status": "blocked", "reason": "violacao_politica"})
        )
        assert await check_external_guardrail("bloqueada") == "violacao_politica"

    with _patch_gsg():
        _mock_http_client(post_return=_mock_http_response({"status": "rejected"}))
        assert await check_external_guardrail("rejeitada") == "external_guardrail_rejection"


# Erros de rede são ignorados (retornam None)


@pytest.mark.asyncio
async def test_timeout_ignores_failure():
    with _patch_gsg():
        _mock_http_client(post_side_effect=httpx.TimeoutException("timeout"))
        result = await check_external_guardrail("mensagem")
    assert result is None


@pytest.mark.asyncio
async def test_http_status_error_ignores_failure():
    bad_resp = MagicMock(spec=httpx.Response)
    bad_resp.status_code = 503
    bad_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
        "server error", request=MagicMock(), response=bad_resp
    )
    with _patch_gsg():
        _mock_http_client(post_return=bad_resp)
        result = await check_external_guardrail("mensagem")
    assert result is None


@pytest.mark.asyncio
async def test_generic_exception_ignores_failure():
    with _patch_gsg():
        _mock_http_client(post_side_effect=ConnectionError("unreachable"))
        result = await check_external_guardrail("mensagem")
    assert result is None


# Passagem do histórico de mensagens


@pytest.mark.asyncio
async def test_messages_list_forwarded_in_payload():
    """O parâmetro messages deve ser incluído no payload enviado ao gateway."""
    resp = _mock_http_response({"allowed": True})
    history = [{"role": "user", "content": "oi"}, {"role": "assistant", "content": "olá"}]
    captured_payload = {}

    async def _fake_post(url, json, headers, timeout):  # noqa: ARG001
        captured_payload.update(json)
        return resp

    with _patch_gsg():
        _mock_http_client()
        gsg_module._http_client.post = AsyncMock(side_effect=_fake_post)
        await check_external_guardrail("mensagem", messages=history)

    assert captured_payload["body"]["data"]["context"]["messages"] == history
