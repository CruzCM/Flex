"""Testes unitários para iaa_agent_minhas_financas/utils/tracing.py."""

from __future__ import annotations

import logging
from contextlib import ExitStack
from unittest.mock import MagicMock, patch

import pytest

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider

from iaa_agent_minhas_financas.utils import tracing


@pytest.fixture(autouse=True)
def _reset_globals(monkeypatch):
    """Reseta estado singleton entre testes."""
    monkeypatch.setattr(tracing, "_BOOTSTRAP_DONE", False)
    tracing.get_telemetry_attributes.cache_clear()
    # Provider limpo para evitar interferência entre testes de telemetria.
    trace.set_tracer_provider(TracerProvider())


# Leitores de variáveis de ambiente


def test_env_readers(monkeypatch):
    """Consolida leitura de variáveis de ambiente OTel com valores e defaults."""
    monkeypatch.setenv("APPLICATIONINSIGHTS_CONNECTION_STRING", "conn-123")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://otel:4317/")
    monkeypatch.setenv("OTEL_SERVICE_NAME", "otel-name")
    monkeypatch.setenv("SERVICE_NAME", "legacy-name")
    monkeypatch.setenv("DEPLOY_ENV", "prod")

    assert tracing.get_appinsights_connection_string() == "conn-123"
    assert tracing.get_otlp_endpoint() == "http://otel:4317"
    assert tracing.get_service_name() == "otel-name"
    assert tracing.get_deploy_env() == "prod"
    assert set(tracing.get_export_targets()) == {"azure", "otlp"}

    # fallback de service name
    monkeypatch.delenv("OTEL_SERVICE_NAME", raising=False)
    assert tracing.get_service_name() == "legacy-name"

    # defaults quando ausentes
    for var in (
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "OTEL_EXPORTER_OTLP_ENDPOINT",
        "OTEL_SERVICE_NAME",
        "SERVICE_NAME",
        "DEPLOY_ENV",
    ):
        monkeypatch.delenv(var, raising=False)

    assert tracing.get_appinsights_connection_string() == ""
    assert tracing.get_otlp_endpoint() == ""
    assert tracing.get_service_name() == "agent"
    assert tracing.get_deploy_env() == ""
    assert tracing.get_export_targets() == []


# configure_telemetry


def test_configure_telemetry(caplog, monkeypatch):
    """Consolida aviso sem exporter e idempotência."""
    monkeypatch.delenv("APPLICATIONINSIGHTS_CONNECTION_STRING", raising=False)
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)
    with caplog.at_level(logging.WARNING):
        tracing.configure_telemetry()
    assert "Nenhum exporter OTel configurado" in caplog.text

    # idempotente
    monkeypatch.setattr(tracing, "_BOOTSTRAP_DONE", True)
    with patch.object(tracing, "_configure_tracing") as mock_trace:
        tracing.configure_telemetry()
    mock_trace.assert_not_called()


def test_get_telemetry_attributes(monkeypatch):
    monkeypatch.setenv("OTEL_SERVICE_NAME", "my-agent")
    monkeypatch.setenv("DEPLOY_ENV", "homol")
    attrs = tracing.get_telemetry_attributes()
    assert attrs["service.name"] == "my-agent"
    assert attrs["deploy.environment"] == "homol"


# instrument_fastapi


def test_instrument_fastapi_import_error_is_silent(caplog):
    app = object()
    with patch.dict("sys.modules", {"opentelemetry.instrumentation.fastapi": None}):
        with caplog.at_level(logging.INFO):
            tracing.instrument_fastapi(app)
    # ImportError silenciado - sem log
    assert "FastAPI" not in caplog.text


def test_get_tracer_and_meter():
    assert tracing.get_tracer("foo") is not None
    assert tracing.get_meter("bar") is not None


# Bootstrap OTel com exporters


@pytest.fixture()
def patch_all_exporters():
    """Evita que qualquer exporter tente enviar dados pela rede durante os testes."""
    def _make_mock(name: str):
        instance = MagicMock()
        instance.__class__.__name__ = name
        return instance

    patches = {
        # Azure
        "azure_trace": patch(
            "azure.monitor.opentelemetry.exporter.AzureMonitorTraceExporter",
            autospec=True,
        ),
        "azure_metric": patch(
            "azure.monitor.opentelemetry.exporter.AzureMonitorMetricExporter",
            autospec=True,
        ),
        "azure_log": patch(
            "azure.monitor.opentelemetry.exporter.AzureMonitorLogExporter",
            autospec=True,
        ),
        # OTLP
        "otlp_trace": patch(
            "opentelemetry.exporter.otlp.proto.grpc.trace_exporter.OTLPSpanExporter",
            autospec=True,
        ),
        "otlp_metric": patch(
            "opentelemetry.exporter.otlp.proto.grpc.metric_exporter.OTLPMetricExporter",
            autospec=True,
        ),
        "otlp_log": patch(
            "opentelemetry.exporter.otlp.proto.grpc._log_exporter.OTLPLogExporter",
            autospec=True,
        ),
    }

    with ExitStack() as stack:
        mocks = {name: stack.enter_context(p) for name, p in patches.items()}
        mocks["azure_trace"].return_value = _make_mock("AzureMonitorTraceExporter")
        mocks["azure_metric"].return_value = _make_mock("AzureMonitorMetricExporter")
        mocks["azure_log"].return_value = _make_mock("AzureMonitorLogExporter")
        mocks["otlp_trace"].return_value = _make_mock("OTLPSpanExporter")
        mocks["otlp_metric"].return_value = _make_mock("OTLPMetricExporter")
        mocks["otlp_log"].return_value = _make_mock("OTLPLogExporter")
        yield mocks


def _exporter_names(provider: TracerProvider) -> list[str]:
    return [
        type(processor.span_exporter).__name__
        for processor in provider._active_span_processor._span_processors
    ]


def test_configure_telemetry_adds_both_exporters(monkeypatch, patch_all_exporters):
    monkeypatch.setenv(
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://fake.example.com",
    )
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")

    tracing.configure_telemetry()

    exporters = _exporter_names(trace.get_tracer_provider())
    assert "AzureMonitorTraceExporter" in exporters
    assert "OTLPSpanExporter" in exporters


def test_configure_telemetry_is_idempotent(monkeypatch, patch_all_exporters):
    monkeypatch.setenv(
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://fake.example.com",
    )
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")

    tracing.configure_telemetry()
    tracing.configure_telemetry()

    exporters = _exporter_names(trace.get_tracer_provider())
    assert exporters.count("AzureMonitorTraceExporter") == 1
    assert exporters.count("OTLPSpanExporter") == 1


def test_configure_telemetry_does_not_duplicate_exporters_on_partial_config(
    monkeypatch, patch_all_exporters
):
    """Se o provider já possui um exporter, o bootstrap não deve adicionar outro igual."""
    monkeypatch.setenv(
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://fake.example.com",
    )

    tracing.configure_telemetry()
    first_run_exporters = _exporter_names(trace.get_tracer_provider())
    assert first_run_exporters.count("AzureMonitorTraceExporter") == 1

    # Simula uma segunda chamada que encontraria o exporter já presente.
    monkeypatch.setattr(tracing, "_BOOTSTRAP_DONE", False)
    tracing.configure_telemetry()
    second_run_exporters = _exporter_names(trace.get_tracer_provider())
    assert second_run_exporters.count("AzureMonitorTraceExporter") == 1


# instrument_fastapi


def test_instrument_fastapi_does_not_exclude_send_receive():
    """A supressão de spans ``send``/``receive`` foi removida.

    A duplicação que motivava o filtro já foi corrigida no middleware de
    guardrails, que reconstrói a resposta ao invés de re-iterar o body iterator.
    """
    app = MagicMock()

    with patch(
        "opentelemetry.instrumentation.fastapi.FastAPIInstrumentor.instrument_app"
    ) as mock_instrument:
        tracing.instrument_fastapi(app)

    mock_instrument.assert_called_once()
    _, kwargs = mock_instrument.call_args
    assert "exclude_spans" not in kwargs
    assert kwargs.get("excluded_urls") == ""


# Idempotência de metrics e logs


def test_configure_telemetry_skips_metrics_when_provider_exists(
    monkeypatch, patch_all_exporters, caplog
):
    """MeterProvider não suporta adicionar readers depois de criado."""
    from opentelemetry.sdk.metrics import MeterProvider as SdkMeterProvider
    from opentelemetry import metrics as metrics_api

    monkeypatch.setenv(
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://fake.example.com",
    )
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")

    existing_provider = MagicMock(spec=SdkMeterProvider)
    with patch.object(
        tracing, "_get_meter_provider", return_value=existing_provider
    ), patch.object(metrics_api, "set_meter_provider") as mock_set:
        tracing.configure_telemetry()

    mock_set.assert_not_called()


def test_log_exporter_names_detects_existing_processor():
    """Verifica que a detecção de log exporters usa o atributo correto do SDK."""
    from opentelemetry.sdk._logs import LoggerProvider
    from opentelemetry.sdk._logs.export import BatchLogRecordProcessor

    class AzureMonitorLogExporter:
        def shutdown(self, *args, **kwargs):
            return True

    provider = LoggerProvider()
    try:
        provider.add_log_record_processor(
            BatchLogRecordProcessor(AzureMonitorLogExporter())
        )

        assert "AzureMonitorLogExporter" in tracing._log_exporter_names(provider)
        assert "OTLPLogExporter" not in tracing._log_exporter_names(provider)
    finally:
        provider.shutdown()


def test_get_langchain_tracer_does_not_add_exporters(monkeypatch, patch_all_exporters):
    """Criar o callback do LangChain não deve adicionar novos exporters."""
    from opentelemetry import trace

    monkeypatch.setenv(
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://fake.example.com",
    )
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")
    monkeypatch.setenv("OTEL_AUTO_CONFIGURE_AZURE_MONITOR", "false")
    monkeypatch.setenv("OTEL_LANGCHAIN_CALLBACK_ENABLED", "true")

    tracing.configure_telemetry()
    exporters_before = _exporter_names(trace.get_tracer_provider())

    tracer = tracing.get_langchain_tracer()
    assert tracer is not None

    exporters_after = _exporter_names(trace.get_tracer_provider())
    assert exporters_after == exporters_before
    assert exporters_after.count("AzureMonitorTraceExporter") == 1
    assert exporters_after.count("OTLPSpanExporter") == 1


def test_metric_reader_exporters_extracts_exporter_names():
    """_metric_reader_exporters deve extrair nomes de exporters dos readers."""
    reader = MagicMock()
    reader._exporter = MagicMock()
    reader._exporter.__class__.__name__ = "OTLPMetricExporter"
    provider = MagicMock()
    provider._metric_readers = [reader]

    assert tracing._metric_reader_exporters(provider) == {"OTLPMetricExporter"}


def test_get_tracer_provider_creates_new_provider_when_missing(monkeypatch):
    """_get_tracer_provider deve criar um TracerProvider quando nenhum SDK provider está ativo."""
    from opentelemetry import trace as trace_api
    from opentelemetry.sdk.trace import TracerProvider

    fake_current = MagicMock()
    fake_current.__class__ = object

    with patch.object(trace_api, "get_tracer_provider", return_value=fake_current):
        with patch.object(trace_api, "set_tracer_provider") as mock_set:
            provider = tracing._get_tracer_provider(MagicMock())

    assert isinstance(provider, TracerProvider)
    mock_set.assert_called_once_with(provider)


def test_instrument_httpx_logs_warning_on_failure(caplog):
    """Falha ao instrumentar httpx deve ser registrada como warning."""
    with patch(
        "opentelemetry.instrumentation.httpx.HTTPXClientInstrumentor"
    ) as mock_cls:
        instance = MagicMock()
        instance.is_instrumented_by_opentelemetry = False
        instance.instrument.side_effect = RuntimeError("instrument failure")
        mock_cls.return_value = instance

        with caplog.at_level(logging.WARNING):
            tracing._instrument_httpx()

    assert "httpx" in caplog.text.lower()


def test_instrument_fastapi_logs_warning_on_generic_exception(caplog):
    """Exceção genérica em instrument_fastapi deve ser registrada como warning."""
    app = MagicMock()
    with patch(
        "opentelemetry.instrumentation.fastapi.FastAPIInstrumentor.instrument_app"
    ) as mock_instrument:
        mock_instrument.side_effect = RuntimeError("fastapi instrument failure")
        with caplog.at_level(logging.WARNING):
            tracing.instrument_fastapi(app)

    assert "FastAPI" in caplog.text


def test_configure_telemetry_handles_import_error(monkeypatch, patch_all_exporters, caplog):
    """ImportError durante configuração deve ser registrada como warning."""
    monkeypatch.setenv(
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://fake.example.com",
    )
    with patch.object(tracing, "_configure_tracing", side_effect=ImportError("missing dep")):
        with caplog.at_level(logging.WARNING):
            tracing.configure_telemetry()
    assert "Dependência de telemetria indisponível" in caplog.text


def test_configure_telemetry_handles_generic_exception(monkeypatch, patch_all_exporters, caplog):
    """Exceção genérica durante configuração deve ser registrada como erro."""
    monkeypatch.setenv(
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "InstrumentationKey=00000000-0000-0000-0000-000000000000;IngestionEndpoint=https://fake.example.com",
    )
    with patch.object(tracing, "_configure_tracing", side_effect=RuntimeError("boom")):
        with caplog.at_level(logging.ERROR):
            tracing.configure_telemetry()
    assert "Falha ao configurar telemetria" in caplog.text


def test_get_langchain_tracer_returns_none_when_disabled(monkeypatch):
    """OTEL_LANGCHAIN_CALLBACK_ENABLED=false deve desabilitar o tracer."""
    monkeypatch.setenv("OTEL_LANGCHAIN_CALLBACK_ENABLED", "false")
    assert tracing.get_langchain_tracer() is None


def test_get_langchain_tracer_returns_none_when_dependency_missing(monkeypatch):
    """Ausência do langchain-azure-ai deve fazer o tracer retornar None."""
    monkeypatch.setenv("OTEL_LANGCHAIN_CALLBACK_ENABLED", "true")
    with patch.dict("sys.modules", {"langchain_azure_ai.callbacks.tracers": None}):
        assert tracing.get_langchain_tracer() is None
