"""Testes unitários para iaa_agent_minhas_financas/config.py."""

import textwrap
from pathlib import Path

import pytest

from unittest.mock import patch

from iaa_agent_minhas_financas.config import (
    AgentConfig,
    LLMConfig,
    MCPAuthentication,
    MCPServer,
    MCPTransport,
    _expand_string,
    get_config,
    load_agent_config,
    validate_config,
)


# Auxiliares

MINIMAL_YAML = textwrap.dedent("""\
    instructions: "Be helpful."
    agent_description: "A test agent."
    temperature: 0.5
    top_p: 0.9
    llm:
      provider: "gateway_outbound"
      gateway_url: "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"
      profile: "gpt-5-mini"
      api_version: "2024-12-01-preview"
      max_tokens: 4096
    guardrails:
      enabled: false
      url: "https://fake-guardrail/gateway/agent"
      user_id: "test-user"
      uor: "12345"
      agent_id: "agente-curador-iagen"
      timeout: 3.0
    rag:
      enabled: false
      url: "https://fake-rag/gateway/agent"
      uor: "12345"
      user_id: "test-user"
      agent_id: "test-rag-agent"
      total_context: 3
      timeout: 15.0
    mcp:
      servers:
        - name: "srv1"
          description: "Test MCP server"
          transport:
            type: "http"
            endpoint: "http://localhost:9000/mcp"
          authentication:
            type: "none"
    metadata:
      owner: "test-team"
      version: "1.2.3"
      created_at: "2026-01-01"
""")


@pytest.fixture()
def config_file(tmp_path: Path) -> Path:
    """Escreve um agent_config.yaml mínimo em um diretório temporário."""
    p = tmp_path / "agent_config.yaml"
    p.write_text(MINIMAL_YAML)
    return p


# load_agent_config


def test_load_minimal_yaml(config_file):
    """Consolida verificações básicas de carga do YAML mínimo."""
    cfg = load_agent_config(config_file)
    assert isinstance(cfg, AgentConfig)
    assert cfg.temperature == pytest.approx(0.5)
    assert cfg.top_p == pytest.approx(0.9)
    assert cfg.metadata.version == "1.2.3"
    assert cfg.metadata.owner == "test-team"
    assert isinstance(cfg.llm, LLMConfig)
    assert cfg.llm.provider == "gateway_outbound"
    assert len(cfg.mcp.servers) == 1
    srv = cfg.mcp.servers[0]
    assert srv.name == "srv1"
    assert srv.transport.endpoint == "http://localhost:9000/mcp"
    assert srv.transport.mcp_url == "http://localhost:9000/mcp"


def test_load_raises_when_file_missing(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_agent_config(tmp_path / "nonexistent.yaml")


# MCPServer.resolve_token


def _make_server(
    auth_type: str,
    token_env_var: str | None = None,
    auth: MCPAuthentication | None = None,
) -> MCPServer:
    return MCPServer(
        name="test",
        description="",
        transport=MCPTransport(type="http", endpoint="http://localhost/mcp"),
        authentication=auth or MCPAuthentication(type=auth_type, token_env_var=token_env_var),
    )


@pytest.mark.parametrize(
    "server, env_setup, expected",
    [
        (_make_server("none"), lambda _: None, None),
        (_make_server("bearer", token_env_var="TEST_TOKEN"), lambda m: m.setenv("TEST_TOKEN", "secret-token"), "secret-token"),
        (_make_server("bearer", token_env_var="TEST_TOKEN"), lambda m: m.delenv("TEST_TOKEN", raising=False), None),
        (_make_server("bearer", token_env_var=None), lambda _: None, None),
        (
            MCPServer(
                name="bare",
                description="",
                transport=MCPTransport(type="http", endpoint="http://localhost/mcp"),
                authentication=None,
            ),
            lambda _: None,
            None,
        ),
    ],
)
def test_resolve_token_scenarios(monkeypatch, server, env_setup, expected):
    """Consolida cenários de resolução de token MCP."""
    env_setup(monkeypatch)
    assert server.resolve_token() == expected


def test_load_raises_when_no_candidates_found(tmp_path, monkeypatch):
    """load_agent_config(path=None) deve lançar FileNotFoundError quando nenhum
    candidato padrão existe."""
    monkeypatch.chdir(tmp_path)
    from pathlib import Path as _Path

    def _never_exists(self):
        return False

    monkeypatch.setattr(_Path, "is_file", _never_exists)
    with pytest.raises(FileNotFoundError, match="agent_config.yaml"):
        load_agent_config(path=None)


def test_load_auto_discovers_config_in_cwd(tmp_path, monkeypatch):
    """load_agent_config(path=None) deve encontrar o arquivo no cwd quando o
    primeiro candidato (raiz do repo) não existir."""
    cfg_file = tmp_path / "agent_config.yaml"
    cfg_file.write_text(MINIMAL_YAML)
    monkeypatch.chdir(tmp_path)

    from pathlib import Path as _Path

    def _only_cwd(self):
        return str(self) == str(tmp_path / "agent_config.yaml")

    monkeypatch.setattr(_Path, "is_file", _only_cwd)
    cfg = load_agent_config(path=None)
    assert isinstance(cfg, AgentConfig)
    assert cfg.instructions == "Be helpful."


def test_get_config_returns_agent_config(config_file, monkeypatch):
    """Cobre o corpo de get_config() na primeira chamada."""
    import iaa_agent_minhas_financas.config as _cm

    monkeypatch.setattr(_cm, "_config", None)
    with patch("iaa_agent_minhas_financas.config.load_agent_config", return_value=load_agent_config(config_file)):
        result = get_config()
    assert isinstance(result, AgentConfig)


def test_get_config_returns_cached_on_second_call(config_file, monkeypatch):
    """get_config() deve retornar o mesmo objeto em chamadas sucessivas."""
    import iaa_agent_minhas_financas.config as _cm

    real_cfg = load_agent_config(config_file)
    monkeypatch.setattr(_cm, "_config", None)
    with patch.object(_cm, "load_agent_config", return_value=real_cfg):
        first = _cm.get_config()
        second = _cm.get_config()

    assert first is second


def test_load_expands_env_vars_with_default(tmp_path: Path):
    """Placeholders ${VAR:default} devem usar o default quando a variável não está definida."""
    cfg_file = tmp_path / "agent_config.yaml"
    cfg_file.write_text(
        textwrap.dedent("""\
            instructions: "Be helpful."
            agent_description: "A test agent."
            temperature: 0.5
            top_p: 0.9
            llm:
              provider: "gateway_outbound"
              gateway_url: "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"
              profile: "gpt-5-mini"
              api_version: "2024-12-01-preview"
              max_tokens: ${CUSTOM_TOKENS:4096}
            guardrails:
              enabled: ${GUARDRAILS_ENABLED:true}
              url: "https://fake-guardrail/gateway/agent"
              user_id: "test-user"
              uor: "12345"
              agent_id: "agente-curador-iagen"
              timeout: 3.0
            rag:
              enabled: false
              url: "https://fake-rag/gateway/agent"
              uor: "12345"
              user_id: "test-user"
              agent_id: "test-rag-agent"
              total_context: 3
              timeout: 15.0
            mcp:
              servers: []
            metadata:
              owner: "test-team"
              version: "1.2.3"
              created_at: "2026-01-01"
        """)
    )
    cfg = load_agent_config(cfg_file)
    assert cfg.llm.gateway_outbound.max_tokens == 4096
    assert cfg.guardrails.enabled is True


def test_load_expands_env_vars_from_environment(tmp_path: Path, monkeypatch):
    """Placeholders $VAR e ${VAR} devem usar o valor real da variável de ambiente."""
    monkeypatch.setenv("CUSTOM_AGENT_DESCRIPTION", "Env Agent")
    monkeypatch.setenv("CUSTOM_ENABLED", "false")
    monkeypatch.setenv("CUSTOM_TIMEOUT", "7.5")
    monkeypatch.setenv("CUSTOM_TOKENS", "2048")
    cfg_file = tmp_path / "agent_config.yaml"
    cfg_file.write_text(
        textwrap.dedent("""\
            instructions: "Be helpful."
            agent_description: "$CUSTOM_AGENT_DESCRIPTION"
            temperature: 0.5
            top_p: 0.9
            llm:
              provider: "gateway_outbound"
              gateway_url: "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"
              profile: "gpt-5-mini"
              api_version: "2024-12-01-preview"
              max_tokens: ${CUSTOM_TOKENS}
            guardrails:
              enabled: ${CUSTOM_ENABLED}
              url: "https://fake-guardrail/gateway/agent"
              user_id: "test-user"
              uor: "12345"
              agent_id: "agente-curador-iagen"
              timeout: ${CUSTOM_TIMEOUT}
            rag:
              enabled: false
              url: "https://fake-rag/gateway/agent"
              uor: "12345"
              user_id: "test-user"
              agent_id: "test-rag-agent"
              total_context: 3
              timeout: 15.0
            mcp:
              servers: []
            metadata:
              owner: "test-team"
              version: "1.2.3"
              created_at: "2026-01-01"
        """)
    )
    cfg = load_agent_config(cfg_file)
    assert cfg.agent_description == "Env Agent"
    assert cfg.guardrails.enabled is False
    assert cfg.guardrails.timeout == pytest.approx(7.5)
    assert cfg.llm.gateway_outbound.max_tokens == 2048


def test_load_respects_agent_config_path_env(tmp_path: Path, monkeypatch):
    """AGENT_CONFIG_PATH deve ser usado quando definido."""
    cfg_file = tmp_path / "custom_agent_config.yaml"
    cfg_file.write_text(MINIMAL_YAML)
    monkeypatch.setenv("AGENT_CONFIG_PATH", str(cfg_file))
    cfg = load_agent_config()
    assert cfg.instructions == "Be helpful."


def test_load_keeps_unresolved_placeholder_when_no_default(tmp_path: Path, monkeypatch):
    """Placeholders sem variável definida e sem default permanecem literais."""
    monkeypatch.delenv("MISSING_PLACEHOLDER", raising=False)
    cfg_file = tmp_path / "agent_config.yaml"
    cfg_file.write_text(
        textwrap.dedent("""\
            instructions: "${MISSING_PLACEHOLDER}"
            agent_description: "A test agent."
            temperature: 0.5
            top_p: 0.9
            llm:
              provider: "gateway_outbound"
              gateway_url: "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1"
              profile: "gpt-5-mini"
              api_version: "2024-12-01-preview"
              max_tokens: 4096
            guardrails:
              enabled: false
              url: "https://fake-guardrail/gateway/agent"
              user_id: "test-user"
              uor: "12345"
              agent_id: "agente-curador-iagen"
              timeout: 3.0
            rag:
              enabled: false
              url: "https://fake-rag/gateway/agent"
              uor: "12345"
              user_id: "test-user"
              agent_id: "test-rag-agent"
              total_context: 3
              timeout: 15.0
            mcp:
              servers: []
            metadata:
              owner: "test-team"
              version: "1.2.3"
              created_at: "2026-01-01"
        """)
    )
    cfg = load_agent_config(cfg_file)
    assert cfg.instructions == "${MISSING_PLACEHOLDER}"


# validate_config


def test_validate_config_detects_multiple_errors(config_file):
    """Consolida validação de campos obrigatórios em um único teste."""
    cfg = load_agent_config(config_file)
    cfg.instructions = ""
    cfg.llm.gateway_outbound.base_url = ""
    cfg.llm.gateway_outbound.model = ""
    cfg.guardrails.enabled = True
    cfg.guardrails.agent_id = ""
    cfg.rag.enabled = True
    cfg.rag.agent_id = ""
    cfg.mcp.servers[0].transport.endpoint = ""

    valid, errors = validate_config(cfg)
    assert valid is False
    joined = "; ".join(errors)
    assert "instructions" in joined
    assert "base_url" in joined
    assert "model" in joined
    assert "guardrails" in joined
    assert "RAG" in joined
    assert "endpoint" in joined


@pytest.mark.parametrize(
    "setup, expected_valid, expected_substring",
    [
        (lambda c: None, True, ""),
        (
            lambda c: setattr(
                c.mcp.servers[0],
                "authentication",
                MCPAuthentication(type="bearer", token_env_var="MISSING_TEST_TOKEN"),
            )
            or None,
            False,
            "MISSING_TEST_TOKEN",
        ),
        (
            lambda c: setattr(c.mcp.servers[0].transport, "endpoint", "$UNRESOLVED_ENDPOINT")
            or None,
            True,
            "",
        ),
        (
            lambda c: setattr(c.mcp.servers[0].transport, "endpoint", "") or None,
            False,
            "endpoint",
        ),
        (lambda c: setattr(c.llm, "provider", "") or None, False, "llm.provider"),
    ],
    ids=["valid", "missing_bearer_token", "placeholder_endpoint", "empty_endpoint", "empty_provider"],
)
def test_validate_config_scenarios(config_file, monkeypatch, setup, expected_valid, expected_substring):
    """Consolida cenários simples de validação em teste parametrizado."""
    monkeypatch.delenv("MISSING_TEST_TOKEN", raising=False)
    cfg = load_agent_config(config_file)
    setup(cfg)
    valid, errors = validate_config(cfg)
    assert valid is expected_valid
    if expected_substring:
        assert any(expected_substring in err for err in errors)


@pytest.mark.parametrize(
    "original, value, expected",
    [
        (42, "not_a_number", "not_a_number"),
        (3.14, "not_a_float", "not_a_float"),
        (True, "not_a_bool", False),
    ],
)
def test_expand_string_coerce_returns_string_on_failure(original, value, expected):
    """_expand_string deve manter string quando conversão para tipo original falha."""
    assert _expand_string(value, original) == expected


@pytest.mark.parametrize(
    "auth, expected",
    [
        (MCPAuthentication(type="bearer", token_env_var="TOKEN"), None),
        (MCPAuthentication(type="cert"), None),
        (
            MCPAuthentication(
                type="cert",
                cert_path="/app/certs/tls.crt",
                key_path="/app/certs/tls.key",
                ca_bundle="$UNRESOLVED_CA",
            ),
            ("/app/certs/tls.crt", "/app/certs/tls.key", None),
        ),
        (
            MCPAuthentication(
                type="cert",
                cert_path="/app/certs/tls.crt",
                key_path="/app/certs/tls.key",
                ca_bundle="/app/certs/ca.pem",
            ),
            ("/app/certs/tls.crt", "/app/certs/tls.key", "/app/certs/ca.pem"),
        ),
    ],
)
def test_resolve_cert_scenarios(monkeypatch, auth, expected):
    """Consolida cenários de resolução de certificado mTLS."""
    monkeypatch.delenv("UNRESOLVED_CA", raising=False)
    srv = MCPServer(
        name="test",
        description="",
        transport=MCPTransport(type="http", endpoint="http://localhost/mcp"),
        authentication=auth,
    )
    result = srv.resolve_cert()
    assert result == expected
