"""Testes unitários para iaa_agent_minhas_financas/graph.py - AgentFactory e AgentGraph."""

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from langchain_core.messages import AIMessage, HumanMessage

from iaa_agent_minhas_financas.graph import AgentFactory, AgentGraph


# Auxiliares


def _make_config(provider: str = "gateway_outbound"):
    """Retorna um objeto AgentConfig mínimo sem acessar o disco."""
    from iaa_agent_minhas_financas.config import (
        AgentConfig,
        GuardrailsConfig,
        LLMConfig,
        MCPAuthentication,
        MCPConfig,
        MCPServer,
        MCPTransport,
        Metadata,
        RAGConfig,
    )

    return AgentConfig(
        instructions="Be helpful.",
        agent_description="desc",
        temperature=0.7,
        top_p=0.95,
        mcp=MCPConfig(
            servers=[
                MCPServer(
                    name="local",
                    description="",
                    transport=MCPTransport(type="http", endpoint="http://localhost:9000/mcp"),
                    authentication=MCPAuthentication(type="none"),
                )
            ]
        ),
        metadata=Metadata(owner="team", version="0.1.0", created_at="2026-01-01"),
        llm=LLMConfig(provider=provider),
        guardrails=GuardrailsConfig(),
        rag=RAGConfig(),
    )


# AgentFactory._mcp_server_config


@pytest.mark.parametrize(
    "auth_type, env, expected_headers",
    [
        ("none", {}, None),
        ("bearer", {"MY_TOKEN": "tok123"}, {"Authorization": "Bearer tok123"}),
    ],
)
def test_mcp_server_config_scenarios(monkeypatch, auth_type, env, expected_headers):
    """Consolida configuração de servidor MCP com e sem token."""
    from iaa_agent_minhas_financas.config import MCPAuthentication

    for k, v in env.items():
        monkeypatch.setenv(k, v)
    cfg = _make_config()
    if auth_type == "bearer":
        cfg.mcp.servers[0].authentication = MCPAuthentication(
            type="bearer", token_env_var="MY_TOKEN"
        )
    result = AgentFactory._mcp_server_config(cfg)
    assert "local" in result
    assert result["local"]["url"] == "http://localhost:9000/mcp"
    if expected_headers:
        assert result["local"]["headers"] == expected_headers
    else:
        assert "headers" not in result["local"]


# AgentFactory.create - falha de MCP degrada graciosamente


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "side_effect",
    [
        ConnectionRefusedError("MCP down"),
        "exception_group",
    ],
    ids=["connection_refused", "exception_group"],
)
async def test_create_degrades_when_mcp_fails(side_effect):
    """Quando o MCP falha e o RAG está desativado, AgentFactory.create() deve
    retornar um grafo compilado sem ferramentas."""
    cfg = _make_config()

    mock_llm = MagicMock()
    mock_llm.ainvoke = AsyncMock(return_value=AIMessage(content="ok"))

    if side_effect == "exception_group":
        class FakeExceptionGroup(Exception):
            exceptions = [RuntimeError("primary failure")]
        side_effect = FakeExceptionGroup("group")

    with (
        patch("iaa_agent_minhas_financas.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_minhas_financas.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(side_effect=side_effect)
        mock_factory.create.return_value = mock_llm

        compiled = await AgentFactory.create(cfg)

    assert hasattr(compiled, "ainvoke")
    mock_llm.bind_tools.assert_not_called()


@pytest.mark.asyncio
async def test_create_no_tools_graph_invokes_llm_directly():
    """Grafo sem ferramentas deve ir START → llm_call → END sem roteamento."""
    cfg = _make_config()
    ai_reply = AIMessage(content="hello")

    mock_llm = MagicMock()
    mock_llm.ainvoke = AsyncMock(return_value=ai_reply)

    with (
        patch("iaa_agent_minhas_financas.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_minhas_financas.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[])
        mock_factory.create.return_value = mock_llm

        compiled = await AgentFactory.create(cfg)
        result = await compiled.ainvoke({"messages": [HumanMessage(content="hi")]})

    assert "messages" in result
    assert result["messages"][-1].content == "hello"


# AgentGraph.ainvoke - delega para AgentFactory


@pytest.mark.asyncio
async def test_agent_graph_ainvoke():
    cfg = _make_config()
    ai_reply = AIMessage(content="The answer is 4.")

    mock_llm = MagicMock()
    mock_llm.ainvoke = AsyncMock(return_value=ai_reply)

    with (
        patch("iaa_agent_minhas_financas.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_minhas_financas.graph.LLMFactory") as mock_factory,
        patch("iaa_agent_minhas_financas.graph.get_config", return_value=cfg),
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[])
        mock_factory.create.return_value = mock_llm

        graph = AgentGraph()
        result = await graph.ainvoke({"messages": [HumanMessage(content="2+2?")]})

    assert "messages" in result
    last = result["messages"][-1]
    assert isinstance(last, AIMessage)
    assert "4" in last.content


def test_agent_graph_invoke_sync():
    """AgentGraph.invoke() deve delegar para ainvoke via asyncio.run().

    Precisa ser um teste síncrono: asyncio.run() não pode ser chamado
    de dentro de um event loop já em execução (como o do pytest-asyncio).
    """
    from unittest.mock import AsyncMock
    from langchain_core.messages import AIMessage

    ai_reply = AIMessage(content="sync reply")
    fake_result = {"messages": [ai_reply]}

    with patch("iaa_agent_minhas_financas.graph.AgentGraph.ainvoke", new=AsyncMock(return_value=fake_result)):
        g = AgentGraph()
        result = g.invoke({"messages": [HumanMessage(content="oi")]})

    assert result["messages"][-1].content == "sync reply"


# AgentFactory.create - caminho com RAG habilitado


@pytest.mark.asyncio
async def test_create_adds_rag_tool_when_enabled():
    """Quando RAG está habilitado e a ferramenta não está presente, deve ser adicionada."""
    cfg = _make_config()
    cfg.rag.enabled = True  # habilita RAG na config
    mock_llm = MagicMock()
    mock_llm.bind_tools = MagicMock(return_value=mock_llm)
    mock_llm.ainvoke = AsyncMock(return_value=AIMessage(content="ok"))

    with (
        patch("iaa_agent_minhas_financas.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_minhas_financas.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[])
        mock_factory.create.return_value = mock_llm

        await AgentFactory.create(cfg)

    # Com RAG, bind_tools deve ter sido chamado com a ferramenta RAG
    mock_llm.bind_tools.assert_called_once()
    tools_passed = mock_llm.bind_tools.call_args[0][0]
    assert len(tools_passed) == 1
    assert tools_passed[0].name == "retrieve_context"


@pytest.mark.asyncio
async def test_create_system_message_prepended():
    """Quando o estado não começa com SystemMessage, instruções devem ser adicionadas."""
    cfg = _make_config()
    ai_reply = AIMessage(content="resposta")

    mock_llm = MagicMock()
    # Captura as mensagens enviadas ao LLM
    captured_messages: list = []

    async def _fake_ainvoke(messages):
        captured_messages.extend(messages)
        return ai_reply

    mock_llm.ainvoke = _fake_ainvoke

    with (
        patch("iaa_agent_minhas_financas.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_minhas_financas.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[])
        mock_factory.create.return_value = mock_llm

        compiled = await AgentFactory.create(cfg)
        await compiled.ainvoke({"messages": [HumanMessage(content="oi")]})

    from langchain_core.messages import SystemMessage
    assert isinstance(captured_messages[0], SystemMessage)
    assert cfg.instructions in captured_messages[0].content


# AgentGraph.ainvoke - callback OTel do LangChain


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "callback, expected_len",
    [
        (MagicMock(), 1),
        (None, 0),
    ],
    ids=["enabled", "disabled"],
)
async def test_agent_graph_ainvoke_callback_scenarios(callback, expected_len):
    """Consolida cenários de callback OTel do LangChain (habilitado/desabilitado)."""
    compiled = MagicMock()
    compiled.ainvoke = AsyncMock(return_value={"messages": [AIMessage(content="ok")]})

    graph = AgentGraph()
    graph._compiled = compiled

    with patch("iaa_agent_minhas_financas.graph._azure_tracer", callback):
        await graph.ainvoke({"messages": [HumanMessage(content="oi")]})

    _, kwargs = compiled.ainvoke.call_args
    callbacks = kwargs["config"]["callbacks"]
    assert len(callbacks) == expected_len


@pytest.mark.asyncio
async def test_agent_graph_ainvoke_propagates_otel_traceparent():
    """O contexto OTel atual é injetado nos metadados do grafo.

    Isso garante que o callback AzureAIOpenTelemetryTracer aninhe seus spans
    sob o span raiz da requisição, mesmo quando o callback perde o contexto
    entre tarefas async/threads.
    """
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider

    trace.set_tracer_provider(TracerProvider())
    tracer = trace.get_tracer("test")

    compiled = MagicMock()
    compiled.ainvoke = AsyncMock(return_value={"messages": [AIMessage(content="ok")]})

    graph = AgentGraph()
    graph._compiled = compiled

    with tracer.start_as_current_span("agent.chat"):
        await graph.ainvoke({"messages": [HumanMessage(content="oi")]})

    _, kwargs = compiled.ainvoke.call_args
    metadata = kwargs["config"].get("metadata", {})
    assert "traceparent" in metadata
    assert metadata["traceparent"].startswith("00-")


# AgentFactory._make_httpx_client


def test_make_httpx_client_passes_headers_timeout_auth():
    """A factory de clientes HTTP deve propagar headers, timeout e auth."""
    import ssl

    ssl_ctx = ssl.create_default_context()
    factory = AgentFactory._make_httpx_client(ssl_ctx)
    client = factory(
        headers={"X-Custom": "value"},
        timeout=30.0,
        auth=("user", "pass"),
    )
    assert isinstance(client, httpx.AsyncClient)
    assert client.headers["X-Custom"] == "value"
    assert client.timeout == httpx.Timeout(30.0)
    assert client._auth is not None


def test_build_mcp_server_entry_with_mtls():
    """Servidor MCP com auth cert deve incluir httpx_client_factory configurado."""
    from iaa_agent_minhas_financas.config import MCPAuthentication

    cfg = _make_config()
    cfg.mcp.servers[0].authentication = MCPAuthentication(
        type="cert",
        cert_path="/app/certs/tls.crt",
        key_path="/app/certs/tls.key",
    )
    entry = AgentFactory._build_mcp_server_entry(cfg.mcp.servers[0])
    assert "httpx_client_factory" in entry
    client = entry["httpx_client_factory"]()
    assert isinstance(client, httpx.AsyncClient)


@pytest.mark.asyncio
async def test_create_logs_tool_calls():
    """Quando o LLM solicita ferramentas, o nome delas deve ser logado."""
    cfg = _make_config()
    ai_reply = AIMessage(
        content="",
        tool_calls=[{"name": "fake_tool", "id": "tc-1", "args": {}}],
    )

    mock_llm = MagicMock()
    mock_llm.ainvoke = AsyncMock(return_value=ai_reply)

    with (
        patch("iaa_agent_minhas_financas.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_minhas_financas.graph.LLMFactory") as mock_factory,
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[])
        mock_factory.create.return_value = mock_llm

        compiled = await AgentFactory.create(cfg)
        result = await compiled.ainvoke({"messages": [HumanMessage(content="use tool")]})

    assert "messages" in result
    last = result["messages"][-1]
    assert isinstance(last, AIMessage)
    assert last.tool_calls


@pytest.mark.asyncio
async def test_create_skips_rag_when_tool_already_exists():
    """Quando uma ferramenta MCP já tem o nome do RAG, não deve haver duplicação."""
    cfg = _make_config()
    cfg.rag.enabled = True

    existing_tool = MagicMock()
    existing_tool.name = "retrieve_context"

    mock_llm = MagicMock()
    mock_llm.bind_tools = MagicMock(return_value=mock_llm)

    mock_rag_tool = MagicMock()
    mock_rag_tool.name = "retrieve_context"

    with (
        patch("iaa_agent_minhas_financas.graph.MultiServerMCPClient") as mock_mcp_cls,
        patch("iaa_agent_minhas_financas.graph.LLMFactory") as mock_factory,
        patch("iaa_agent_minhas_financas.graph.build_rag_tool", return_value=mock_rag_tool) as mock_build_rag,
        patch.object(AgentFactory, "_compile_graph", return_value=MagicMock()),
    ):
        mock_mcp_cls.return_value.get_tools = AsyncMock(return_value=[existing_tool])
        mock_factory.create.return_value = mock_llm

        await AgentFactory.create(cfg)

    mock_build_rag.assert_called_once()
    tools_passed = mock_llm.bind_tools.call_args[0][0]
    assert len(tools_passed) == 1
    assert tools_passed[0].name == "retrieve_context"
