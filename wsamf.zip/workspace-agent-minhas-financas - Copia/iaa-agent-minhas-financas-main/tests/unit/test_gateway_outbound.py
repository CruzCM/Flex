"""Testes unitários para llm/gateway_outbound.py - GatewayOutboundProvider."""

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from iaa_agent_minhas_financas.config import GatewayOutboundConfig, LLMConfig
from iaa_agent_minhas_financas.llm.gateway_outbound import GatewayOutboundProvider, _GatewayTransport


@pytest.fixture(autouse=True)
def _gateway_outbound_env(monkeypatch):
    """Define variável de ambiente obrigatória do gateway Outbound."""
    monkeypatch.setenv("GATEWAY_OUTBOUND_GW_APP_KEY", "test-gw-key-123")
    monkeypatch.delenv("TRUST_STORE_CA_PATH", raising=False)
    monkeypatch.delenv("REQUESTS_CA_BUNDLE", raising=False)
    monkeypatch.delenv("KEY_STORE_CERT_PATH", raising=False)
    monkeypatch.delenv("KEY_STORE_KEY_PATH", raising=False)


@pytest.fixture(autouse=True)
def _mock_config():
    """Injeta config com valores de teste para gateway_outbound."""
    cfg = MagicMock()
    cfg.llm = LLMConfig(
        provider="gateway_outbound",
        gateway_outbound=GatewayOutboundConfig(
            base_url="https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1/openai/deployments/gpt-5-mini",
            model="gpt-5-mini",
            max_tokens=4096,
        ),
    )
    with patch("iaa_agent_minhas_financas.llm.gateway_outbound.get_config", return_value=cfg):
        yield


def test_build_returns_chat_openai():
    """build() deve instanciar ChatOpenAI com os parâmetros corretos."""
    mock_model = MagicMock()

    with patch("langchain_openai.ChatOpenAI", return_value=mock_model) as mock_cls:
        provider = GatewayOutboundProvider()
        result = provider.build(temperature=1.0, top_p=1.0)

    mock_cls.assert_called_once()
    _, kwargs = mock_cls.call_args
    assert kwargs["base_url"] == "https://llms-agentes-ia.outbound.api.hm.bb.com.br/v1/openai/deployments/gpt-5-mini"
    assert kwargs["model"] == "gpt-5-mini"
    assert kwargs["temperature"] == 1.0
    assert kwargs["top_p"] == 1.0
    assert kwargs["max_tokens"] == 4096
    assert result is mock_model


def test_build_raises_when_api_key_missing(monkeypatch):
    """build() deve lançar RuntimeError se GATEWAY_OUTBOUND_GW_APP_KEY não estiver definido."""
    monkeypatch.delenv("GATEWAY_OUTBOUND_GW_APP_KEY", raising=False)
    with pytest.raises(RuntimeError, match="GATEWAY_OUTBOUND_GW_APP_KEY"):
        GatewayOutboundProvider().build(temperature=1.0, top_p=1.0)


def test_build_uses_custom_client():
    """build() deve passar um http_async_client com o transport customizado."""
    mock_model = MagicMock()

    with patch("langchain_openai.ChatOpenAI", return_value=mock_model) as mock_cls:
        GatewayOutboundProvider().build(temperature=0.5, top_p=0.9)

    _, kwargs = mock_cls.call_args
    async_client = kwargs.get("http_async_client")
    assert async_client is not None
    assert isinstance(async_client, httpx.AsyncClient)


def test_build_ssl_from_env(monkeypatch):
    """build() deve usar build_ssl_context com os caminhos de certificado."""
    import ssl

    monkeypatch.setenv("KEY_STORE_CERT_PATH", "/app/certs/tls.crt")
    monkeypatch.setenv("KEY_STORE_KEY_PATH", "/app/certs/tls.key")

    mock_ssl_context = MagicMock(spec=ssl.SSLContext)

    with patch(
        "iaa_agent_minhas_financas.llm.gateway_outbound.build_ssl_context",
        return_value=mock_ssl_context,
    ) as mock_build:
        with patch("iaa_agent_minhas_financas.llm.gateway_outbound._GatewayTransport") as mock_transport:
            with patch("httpx.AsyncClient"):
                with patch("langchain_openai.ChatOpenAI"):
                    GatewayOutboundProvider().build(temperature=1.0, top_p=1.0)

    mock_build.assert_called_once()
    call_kwargs = mock_build.call_args[1]
    assert call_kwargs["cert_path"] == "/app/certs/tls.crt"
    assert call_kwargs["key_path"] == "/app/certs/tls.key"
    _, kwargs = mock_transport.call_args
    assert kwargs["verify"] is mock_ssl_context


def test_build_ssl_defaults_without_env():
    """Sem envvars SSL, build_ssl_context deve ser chamado sem cert/key."""
    import ssl

    mock_ssl_context = MagicMock(spec=ssl.SSLContext)

    with patch(
        "iaa_agent_minhas_financas.llm.gateway_outbound.build_ssl_context",
        return_value=mock_ssl_context,
    ) as mock_build:
        with patch("iaa_agent_minhas_financas.llm.gateway_outbound._GatewayTransport") as mock_transport:
            with patch("httpx.AsyncClient"):
                with patch("langchain_openai.ChatOpenAI"):
                    GatewayOutboundProvider().build(temperature=1.0, top_p=1.0)

    mock_build.assert_called_once()
    call_kwargs = mock_build.call_args[1]
    assert call_kwargs["cert_path"] is None
    assert call_kwargs["key_path"] is None
    _, kwargs = mock_transport.call_args
    assert kwargs["verify"] is mock_ssl_context


class TestGatewayTransport:
    """Testes para o transport customizado _GatewayTransport."""

    def _make_request(self, path: str, params: dict | None = None) -> "httpx.Request":
        import httpx

        url = httpx.URL(f"https://llms-agentes-ia.outbound.api.hm.bb.com.br{path}")
        if params:
            url = url.copy_with(params=params)
        return httpx.Request("POST", url)

    @pytest.mark.asyncio
    async def test_path_rewrite(self):
        """Deve reescrever /chat/completions para o path customizado quando configurado."""
        transport = _GatewayTransport(
            gw_app_key="my-key",
            path_rewrite="/chat/completions:/custom-chat-completion",
        )
        request = self._make_request("/v1/chat/completions")

        captured = {}

        async def _fake_handle(req):
            captured["path"] = req.url.path
            captured["params"] = dict(req.url.params)
            return httpx.Response(200)

        with patch.object(
            type(transport).__bases__[0],
            "handle_async_request",
            new=AsyncMock(side_effect=_fake_handle),
        ):
            await transport.handle_async_request(request)

        assert captured["path"] == "/v1/custom-chat-completion"

    @pytest.mark.asyncio
    async def test_no_path_rewrite_when_empty(self):
        """Sem path_rewrite, o path deve permanecer inalterado (OpenAI-compatível)."""
        transport = _GatewayTransport(gw_app_key="my-key", path_rewrite="")
        request = self._make_request("/v1/openai/deployments/gpt-5/chat/completions")

        captured = {}

        async def _fake_handle(req):
            captured["path"] = req.url.path
            return httpx.Response(200)

        with patch.object(
            type(transport).__bases__[0],
            "handle_async_request",
            new=AsyncMock(side_effect=_fake_handle),
        ):
            await transport.handle_async_request(request)

        assert captured["path"] == "/v1/openai/deployments/gpt-5/chat/completions"

    @pytest.mark.asyncio
    async def test_query_param_injected(self):
        """Deve injetar api-version na query string."""
        transport = _GatewayTransport(gw_app_key="secret-key", api_version="2024-12-01-preview")
        request = self._make_request("/v1/chat/completions")

        captured = {}

        async def _fake_handle(req):
            captured["params"] = dict(req.url.params)
            return httpx.Response(200)

        with patch.object(
            type(transport).__bases__[0],
            "handle_async_request",
            new=AsyncMock(side_effect=_fake_handle),
        ):
            await transport.handle_async_request(request)

        assert captured["params"]["api-version"] == "2024-12-01-preview"

    @pytest.mark.asyncio
    async def test_auth_header_injected(self):
        """Deve injetar X-Application-Key e remover Authorization do header."""
        transport = _GatewayTransport(gw_app_key="secret-key")
        request = self._make_request("/v1/chat/completions")
        # Simulate what the OpenAI SDK adds
        request.headers["authorization"] = "Bearer dummy"

        captured = {}

        async def _fake_handle(req):
            captured["headers"] = dict(req.headers)
            return httpx.Response(200)

        with patch.object(
            type(transport).__bases__[0],
            "handle_async_request",
            new=AsyncMock(side_effect=_fake_handle),
        ):
            await transport.handle_async_request(request)

        assert captured["headers"]["x-application-key"] == "secret-key"
        assert "authorization" not in captured["headers"]


def test_build_raises_when_gateway_config_incomplete():
    """build() deve lançar RuntimeError quando base_url ou model estão vazios."""
    cfg = MagicMock()
    cfg.llm = LLMConfig(
        provider="gateway_outbound",
        gateway_outbound=GatewayOutboundConfig(
            base_url="",
            model="",
            max_tokens=4096,
        ),
    )
    with patch("iaa_agent_minhas_financas.llm.gateway_outbound.get_config", return_value=cfg):
        with pytest.raises(RuntimeError, match="base_url.*model"):
            GatewayOutboundProvider().build(temperature=1.0, top_p=1.0)


def test_build_uses_completion_tokens_when_enabled():
    """Com use_completion_tokens=True, max_completion_tokens deve ser usado no lugar de max_tokens/top_p."""
    cfg = MagicMock()
    cfg.llm = LLMConfig(
        provider="gateway_outbound",
        gateway_outbound=GatewayOutboundConfig(
            base_url="https://fake.example.com/v1",
            model="gpt-test",
            max_tokens=2048,
            use_completion_tokens=True,
        ),
    )
    mock_model = MagicMock()
    with patch("iaa_agent_minhas_financas.llm.gateway_outbound.get_config", return_value=cfg):
        with patch("langchain_openai.ChatOpenAI", return_value=mock_model) as mock_cls:
            GatewayOutboundProvider().build(temperature=0.5, top_p=0.9)

    _, kwargs = mock_cls.call_args
    assert kwargs["max_completion_tokens"] == 2048
    assert "top_p" not in kwargs
    assert "max_tokens" not in kwargs
