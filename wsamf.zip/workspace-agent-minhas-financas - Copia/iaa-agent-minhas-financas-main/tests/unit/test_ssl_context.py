"""Testes unitários para iaa_agent_minhas_financas/utils/ssl_context.py."""

from __future__ import annotations

import ssl
from pathlib import Path

from iaa_agent_minhas_financas.utils.ssl_context import build_ssl_context


def test_build_ssl_context_uses_defaults():
    ctx = build_ssl_context()
    assert isinstance(ctx, ssl.SSLContext)
    assert ctx.minimum_version == ssl.TLSVersion.TLSv1_2


def test_build_ssl_context_loads_ca_bundle(tmp_path: Path):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "test-ca")])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(__import__("datetime").datetime.now(__import__("datetime").timezone.utc))
        .not_valid_after(
            __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
            + __import__("datetime").timedelta(days=1)
        )
        .add_extension(
            x509.BasicConstraints(ca=True, path_length=None),
            critical=True,
        )
        .sign(key, hashes.SHA256())
    )

    ca_file = tmp_path / "ca.pem"
    ca_file.write_bytes(cert.public_bytes(serialization.Encoding.PEM))

    ctx = build_ssl_context(ca_bundle=str(ca_file))
    assert isinstance(ctx, ssl.SSLContext)


def test_build_ssl_context_warns_when_ca_bundle_missing(caplog):
    with caplog.at_level("WARNING"):
        ctx = build_ssl_context(ca_bundle="/nonexistent/ca.pem")
    assert isinstance(ctx, ssl.SSLContext)
    assert "não encontrado" in caplog.text


def test_build_ssl_context_loads_client_cert(tmp_path: Path):
    # Gera um certificado autoassinado em memória para o teste.
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "test")])
    now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + __import__("datetime").timedelta(days=1))
        .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost")]), critical=False)
        .sign(key, hashes.SHA256())
    )

    cert_path = tmp_path / "cert.pem"
    key_path = tmp_path / "key.pem"
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(
        key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )

    ctx = build_ssl_context(cert_path=str(cert_path), key_path=str(key_path))
    assert isinstance(ctx, ssl.SSLContext)


def test_build_ssl_context_warns_when_cert_files_missing(caplog):
    with caplog.at_level("WARNING"):
        ctx = build_ssl_context(
            cert_path="/nonexistent/cert.pem",
            key_path="/nonexistent/key.pem",
        )
    assert isinstance(ctx, ssl.SSLContext)
    assert "Certificado cliente não encontrado" in caplog.text
