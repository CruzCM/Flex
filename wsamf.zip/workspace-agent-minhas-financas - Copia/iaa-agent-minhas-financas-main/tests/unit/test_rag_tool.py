"""Testes unitários para iaa_agent_minhas_financas/rag/rag_tool.py."""

from contextlib import contextmanager
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

import iaa_agent_minhas_financas.rag.rag_tool as rag_module
from iaa_agent_minhas_financas.rag.rag_tool import _call_gateway, build_rag_tool


# Auxiliares

def _make_rag_cfg(enabled=True, client_id="cid", agent_id="aid"):
    cfg = MagicMock()
    cfg.rag.enabled = enabled
    cfg.rag.agent_id = agent_id
    cfg.rag.uor = "uor"
    cfg.rag.user_id = "uid"
    cfg.rag.url = "https://fake-gateway/agent"
    cfg.rag.total_context = 5
    cfg.rag.timeout = 5.0
    cfg.rag.tool_name = "retrieve_context"
    cfg.rag.tool_description = "Recupera contexto relevante."
    return cfg, client_id


@contextmanager
def _patch_rag(enabled=True, client_id="cid", agent_id="aid"):
    """Patcha get_config e RAG_CLIENT_ID, e reseta o cliente HTTP entre testes."""
    cfg, cid = _make_rag_cfg(enabled=enabled, client_id=client_id, agent_id=agent_id)
    rag_module._http_client = None  # força recriação do cliente
    with patch("iaa_agent_minhas_financas.rag.rag_tool.get_config", return_value=cfg):
        with patch.dict("os.environ", {"RAG_CLIENT_ID": cid} if cid else {}, clear=False):
            if not cid:
                import os
                os.environ.pop("RAG_CLIENT_ID", None)
            yield


def _mock_response(body: dict, status_code: int = 200):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = body
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    else:
        resp.raise_for_status.return_value = None
    return resp


def _mock_http_client(post_return=None, post_side_effect=None):
    """Cria um mock de AsyncClient e injeta no módulo."""
    mock_client = MagicMock(spec=httpx.AsyncClient)
    if post_side_effect:
        mock_client.post = AsyncMock(side_effect=post_side_effect)
    else:
        mock_client.post = AsyncMock(return_value=post_return)
    rag_module._http_client = mock_client
    return mock_client


# Construção do cliente HTTP


def _make_self_signed_cert(tmp_path: Path) -> Path:
    cert = tmp_path / "ca.pem"
    import subprocess
    subprocess.run(
        [
            "openssl", "req", "-x509", "-newkey", "rsa:2048",
            "-keyout", str(tmp_path / "key.pem"),
            "-out", str(cert), "-days", "1", "-nodes",
            "-subj", "/CN=test-ca",
        ],
        check=True,
        capture_output=True,
    )
    return cert


def test_get_http_client(monkeypatch, tmp_path):
    """Consolida construção do cliente HTTP com e sem CA bundle."""
    # com CA bundle válido
    rag_module._http_client = None
    cert = _make_self_signed_cert(tmp_path)
    monkeypatch.setenv("REQUESTS_CA_BUNDLE", str(cert))
    client = rag_module._get_http_client()
    assert isinstance(client, httpx.AsyncClient)
    assert client is rag_module._get_http_client()  # singleton

    # sem CA bundle
    rag_module._http_client = None
    monkeypatch.delenv("REQUESTS_CA_BUNDLE", raising=False)
    client = rag_module._get_http_client()
    assert isinstance(client, httpx.AsyncClient)


# _call_gateway - desativado / não configurado


@pytest.mark.asyncio
async def test_disabled_returns_empty():
    with _patch_rag(enabled=False):
        result = await _call_gateway("test query")
    assert result == []


@pytest.mark.asyncio
async def test_missing_client_id_returns_empty():
    with _patch_rag(client_id=""):
        result = await _call_gateway("test query")
    assert result == []


@pytest.mark.asyncio
async def test_missing_agent_id_returns_empty():
    with _patch_rag(agent_id=""):
        result = await _call_gateway("test query")
    assert result == []


# _call_gateway - respostas bem-sucedidas (formatos variados)


@pytest.mark.asyncio
async def test_successful_context_retrieval():
    """Consolida formatos de resposta bem-sucedidos do RAG."""
    items = [{"chunk": "doc1"}, {"chunk": "doc2"}]
    resp = _mock_response({"data": {"output": {"text": [{"retrieved_contexts": items}]}}})

    with _patch_rag():
        _mock_http_client(post_return=resp)
        result = await _call_gateway("what is X?")

    assert result == items


@pytest.mark.asyncio
async def test_success_custom_total_context():
    """O parâmetro total_context é repassado no payload."""
    items = [{"chunk": "x"}]
    resp = _mock_response({"data": {"output": {"text": [{"retrieved_contexts": items}]}}})

    with _patch_rag():
        mock_client = _mock_http_client(post_return=resp)
        result = await _call_gateway("query", total_context=3)

    assert result == items
    call_kwargs = mock_client.post.call_args
    payload = call_kwargs.kwargs.get("json") or call_kwargs.args[1]
    assert payload["body"]["data"]["context"]["total_context"] == 3


@pytest.mark.asyncio
async def test_unexpected_context_shape_returns_empty():
    """Quando o contexto não é uma lista, retorna []."""
    resp = _mock_response({"body": {"data": {"context": "not-a-list"}}})

    with _patch_rag():
        _mock_http_client(post_return=resp)
        result = await _call_gateway("query")

    assert result == []


# _call_gateway - tratamento de erros


@pytest.mark.asyncio
async def test_timeout_returns_empty():
    with _patch_rag():
        _mock_http_client(post_side_effect=httpx.TimeoutException("timed out"))
        result = await _call_gateway("query")

    assert result == []


@pytest.mark.asyncio
async def test_http_4xx_returns_empty():
    resp = _mock_response({}, status_code=404)

    with _patch_rag():
        _mock_http_client(post_return=resp)
        result = await _call_gateway("query")

    assert result == []


@pytest.mark.asyncio
async def test_generic_exception_returns_empty():
    with _patch_rag():
        _mock_http_client(post_side_effect=RuntimeError("unexpected"))
        result = await _call_gateway("query")

    assert result == []


# build_rag_tool / retrieve_context - ferramenta LangChain


@pytest.mark.asyncio
async def test_retrieve_context_tool_delegates_to_call_gateway():
    expected = [{"chunk": "hello"}]

    with _patch_rag():
        tool = build_rag_tool()
        with patch("iaa_agent_minhas_financas.rag.rag_tool._call_gateway", new=AsyncMock(return_value=expected)) as mock_gw:
            result = await tool.ainvoke({"query": "hello", "total_context": 3})

    mock_gw.assert_awaited_once_with("hello", messages=None, total_context=3)
    assert result == expected


@pytest.mark.asyncio
async def test_retrieve_context_tool_default_total_context():
    with _patch_rag():
        tool = build_rag_tool()
        with patch("iaa_agent_minhas_financas.rag.rag_tool._call_gateway", new=AsyncMock(return_value=[])) as mock_gw:
            await tool.ainvoke({"query": "test"})

    mock_gw.assert_awaited_once_with("test", messages=None, total_context=5)


def test_retrieve_context_tool_has_name():
    with _patch_rag():
        tool = build_rag_tool()
    assert tool.name == "retrieve_context"


def test_retrieve_context_tool_has_description():
    with _patch_rag():
        tool = build_rag_tool()
    assert "context" in tool.description.lower()
