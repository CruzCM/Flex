"""Testes unitários para iaa_agent_minhas_financas/__main__.py."""

from __future__ import annotations

import logging
import runpy
from pathlib import Path
from unittest.mock import patch

import pytest

import iaa_agent_minhas_financas.__main__ as main_module
from iaa_agent_minhas_financas.__main__ import (
    HealthCheckFilter,
    main,
)


# Filtros de log


@pytest.fixture()
def log_record():
    """Factory para criar registros de log simples."""
    def _make(message: str) -> logging.LogRecord:
        return logging.LogRecord(
            name="uvicorn.access",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg=message,
            args=(),
            exc_info=None,
        )
    return _make


def test_health_check_filter(log_record):
    filt = HealthCheckFilter()
    # bloqueia health checks e metrics
    assert filt.filter(log_record("GET /health/live HTTP/1.1")) is False
    assert filt.filter(log_record("GET /health/ready HTTP/1.1")) is False
    assert filt.filter(log_record("GET /metrics HTTP/1.1")) is False
    # permite outras rotas
    assert filt.filter(log_record("POST /chat HTTP/1.1")) is True
    assert filt.filter(log_record("GET /docs HTTP/1.1")) is True


# main()


def test_main_runs_uvicorn_with_defaults():
    with patch("sys.argv", ["__main__.py"]):
        with patch("iaa_agent_minhas_financas.__main__.uvicorn.run") as mock_run:
            main()
    mock_run.assert_called_once()
    _, kwargs = mock_run.call_args
    assert kwargs["host"] == "0.0.0.0"
    assert kwargs["port"] == 8080
    assert kwargs["workers"] == 1
    assert kwargs["log_level"] == "info"


def test_main_uses_cli_arguments():
    with patch("sys.argv", ["__main__.py", "--host", "127.0.0.1", "--port", "9000", "--log-level", "debug"]):
        with patch("iaa_agent_minhas_financas.__main__.uvicorn.run") as mock_run:
            main()
    _, kwargs = mock_run.call_args
    assert kwargs["host"] == "127.0.0.1"
    assert kwargs["port"] == 9000
    assert kwargs["log_level"] == "debug"


def test_main_module_entrypoint():
    """Cobre o bloco `if __name__ == "__main__"` executando o módulo via runpy."""
    entrypoint = str(Path(main_module.__file__))
    with patch("sys.argv", ["__main__.py"]):
        with patch("uvicorn.run") as mock_run:
            runpy.run_path(entrypoint, run_name="__main__")
    mock_run.assert_called_once()
