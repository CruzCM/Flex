"""Testes unitários para iaa_agent_minhas_financas/app.py.

Usa httpx.AsyncClient com ASGITransport para testar todos os endpoints sem
depender de rede real. O LLM e o grafo são totalmente mockados.
"""

from __future__ import annotations

import sys
import textwrap
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
import pytest_asyncio
from fastapi import HTTPException
from httpx import ASGITransport, AsyncClient
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

# Fixtures

_YAML = textwrap.dedent("""\
    instructions: "Be helpful."
    agent_description: "A test agent."
    temperature: 0.5
    top_p: 0.9
    llm:
      provider: "gateway_outbound"
    mcp:
      servers: []
    metadata:
      owner: "team"
      version: "0.1.0"
      created_at: "2026-01-01"
""")


@pytest.fixture(autouse=True)
def _setup(tmp_path, monkeypatch):
    """Configura YAML mínimo e credenciais Azure antes de cada teste."""
    cfg = tmp_path / "agent_config.yaml"
    cfg.write_text(_YAML)
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://test.openai.azure.com/")
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "test-key")

    from iaa_agent_minhas_financas.config import load_agent_config as _real
    with patch("iaa_agent_minhas_financas.config.load_agent_config", return_value=_real(cfg)):
        yield


@pytest.fixture()
def mock_graph():
    """Grafo mockado que devolve uma resposta AI pré-definida."""
    ai_msg = AIMessage(content="Resposta de teste.")
    g = MagicMock()
    g.ainvoke = AsyncMock(
        return_value={"messages": [HumanMessage(content="olá"), ai_msg]}
    )
    return g


@pytest_asyncio.fixture()
async def client(mock_graph):
    """AsyncClient apontando para a app FastAPI com LLM totalmente mockado."""
    saved = {k: v for k, v in sys.modules.items() if k.startswith("iaa_agent_minhas_financas.")}
    for mod in list(sys.modules):
        if mod.startswith("iaa_agent_minhas_financas."):
            del sys.modules[mod]
    try:
        with patch("iaa_agent_minhas_financas.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
            from iaa_agent_minhas_financas.app import app  # noqa: PLC0415
            async with AsyncClient(
                transport=ASGITransport(app=app), base_url="http://test"
            ) as ac:
                yield ac
    finally:
        for mod in list(sys.modules):
            if mod.startswith("iaa_agent_minhas_financas."):
                del sys.modules[mod]
        sys.modules.update(saved)


@pytest.fixture()
def trace_exporter():
    """TracerProvider com InMemorySpanExporter para validar spans criados em /chat."""
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    yield exporter
    exporter.clear()


@pytest_asyncio.fixture()
async def client_with_tracing(mock_graph, trace_exporter):
    """AsyncClient com TracerProvider real ativo para capturar spans."""
    saved = {k: v for k, v in sys.modules.items() if k.startswith("iaa_agent_minhas_financas.")}
    for mod in list(sys.modules):
        if mod.startswith("iaa_agent_minhas_financas."):
            del sys.modules[mod]
    try:
        with patch("iaa_agent_minhas_financas.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
            from iaa_agent_minhas_financas.app import app  # noqa: PLC0415
            async with AsyncClient(
                transport=ASGITransport(app=app), base_url="http://test"
            ) as ac:
                yield ac
    finally:
        for mod in list(sys.modules):
            if mod.startswith("iaa_agent_minhas_financas."):
                del sys.modules[mod]
        sys.modules.update(saved)


# Health probes


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "path, expected_status, expected_key",
    [
        ("/health/live", 200, "alive"),
    ],
)
async def test_health_endpoints(client, path, expected_status, expected_key):
    """Consolida verificações básicas de health."""
    resp = await client.get(path)
    assert resp.status_code == expected_status
    assert resp.json()["status"] == expected_key


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "compiled, expected_status, expected_status_text, detail_substring",
    [
        (object(), 200, "ready", None),
        (None, 503, "not ready", "Grafo"),
    ],
)
async def test_health_ready_states(client, compiled, expected_status, expected_status_text, detail_substring):
    """Consolida estados do health ready (compilado vs não compilado)."""
    import iaa_agent_minhas_financas.app as app_module

    app_module.graph._compiled = compiled
    resp = await client.get("/health/ready")
    assert resp.status_code == expected_status
    body = resp.json()
    assert body["status"] == expected_status_text
    if detail_substring:
        assert detail_substring in body["detail"]


@pytest.mark.asyncio
async def test_health_ready_returns_503_when_config_raises(client):
    with patch("iaa_agent_minhas_financas.app.get_config", side_effect=RuntimeError("config indisponível")):
        resp = await client.get("/health/ready")
    assert resp.status_code == 503
    body = resp.json()
    assert body["status"] == "not ready"
    assert "detail" in body


# Métricas


@pytest.mark.asyncio
async def test_metrics_returns_expected_structure(client):
    resp = await client.get("/metrics")
    assert resp.status_code == 200
    body = resp.json()
    assert "uptime_seconds" in body
    assert "total_requests" in body
    assert "service_name" in body
    assert isinstance(body["uptime_seconds"], float)
    assert isinstance(body["total_requests"], int)


# /chat - fluxo principal


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "payload, expected_session_id",
    [
        ({"message": "Olá"}, None),
        ({"message": "Olá", "session_id": "sessao-99"}, "sessao-99"),
    ],
)
async def test_chat_returns_reply_and_session_id(client, payload, expected_session_id):
    """Consolida fluxo principal de /chat: reply, session_id presente/ausente."""
    resp = await client.post("/chat", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert body["reply"] == "Resposta de teste."
    assert body["session_id"] == expected_session_id


@pytest.mark.asyncio
async def test_chat_422_on_missing_message(client):
    resp = await client.post("/chat", json={})
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_chat_error_handling(client, mock_graph):
    """Consolida testes de mapeamento de exceções para status HTTP."""
    scenarios = [
        (RuntimeError("LLM indisponível"), 500, "Erro interno do servidor."),
        (ValueError("entrada inválida"), 400, "inválida"),
        (TimeoutError("demorou demais"), 504, "limite"),
        (httpx.ConnectError("falha de conexão"), 502, "comunicação"),
    ]

    for exc, expected_status, expected_detail in scenarios:
        mock_graph.ainvoke.side_effect = exc
        with patch("iaa_agent_minhas_financas.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
            resp = await client.post("/chat", json={"message": "mensagem"})
        assert resp.status_code == expected_status, f"falhou para {type(exc).__name__}"
        assert expected_detail in resp.json()["detail"], f"falhou para {type(exc).__name__}"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "content, expected_in_reply",
    [
        ([{"type": "text", "text": "parte A"}, {"type": "text", "text": "parte B"}], ["parte A", "parte B"]),
        ([{"type": "text", "text": "texto"}, "string direta"], ["texto"]),
    ],
)
async def test_chat_list_content_blocks(client, mock_graph, content, expected_in_reply):
    """Consolida processamento de respostas com lista de blocos de conteúdo."""
    ai_msg = AIMessage(content=content)
    mock_graph.ainvoke = AsyncMock(
        return_value={"messages": [HumanMessage(content="q"), ai_msg]}
    )
    with patch("iaa_agent_minhas_financas.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "q"})
    assert resp.status_code == 200
    reply = resp.json()["reply"]
    for expected in expected_in_reply:
        assert expected in reply


@pytest.mark.asyncio
async def test_chat_counts_tool_calls(client, mock_graph):
    """tool_calls_made deve contar ToolMessages na lista de messages."""
    tool_msg = ToolMessage(content="resultado", tool_call_id="tc-1")
    ai_msg = AIMessage(content="resposta final")
    mock_graph.ainvoke = AsyncMock(
        return_value={"messages": [HumanMessage(content="q"), tool_msg, ai_msg]}
    )
    with patch("iaa_agent_minhas_financas.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "q"})
    assert resp.status_code == 200
    assert resp.json()["tool_calls_made"] == 1


@pytest.mark.asyncio
async def test_chat_empty_messages_returns_empty_reply(client, mock_graph):
    """Quando o grafo retorna messages=[], reply deve ser string vazia."""
    mock_graph.ainvoke = AsyncMock(return_value={"messages": []})
    with patch("iaa_agent_minhas_financas.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "q"})
    assert resp.status_code == 200
    assert resp.json()["reply"] == ""


@pytest.mark.asyncio
async def test_chat_creates_agent_root_span(client_with_tracing, trace_exporter):
    """/chat deve criar o span 'agent.chat' como ponto de agrupamento dos callbacks."""
    resp = await client_with_tracing.post(
        "/chat", json={"message": "oi", "session_id": "sessao-trace"}
    )
    assert resp.status_code == 200

    spans = trace_exporter.get_finished_spans()
    span_names = [s.name for s in spans]
    assert "agent.chat" in span_names

    agent_span = next(s for s in spans if s.name == "agent.chat")
    assert agent_span.attributes.get("session_id") == "sessao-trace"
    assert agent_span.attributes.get("message.length") == 2


# Lifespan


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "valid, expected_compile_calls",
    [
        (True, 1),
        (False, 0),
    ],
)
async def test_lifespan_behavior(valid, expected_compile_calls):
    """Consolida cenários de lifespan: sucesso compila grafo; falha levanta RuntimeError."""
    from iaa_agent_minhas_financas.app import lifespan

    app_mock = MagicMock()
    with patch("iaa_agent_minhas_financas.app.validate_config", return_value=(valid, [] if valid else ["erro fake"])):
        with patch("iaa_agent_minhas_financas.app.graph.compile", new=AsyncMock()) as mock_compile:
            if valid:
                async with lifespan(app_mock):
                    pass
                assert mock_compile.await_count == expected_compile_calls
            else:
                with pytest.raises(RuntimeError, match="erro fake"):
                    async with lifespan(app_mock):
                        pass


@pytest.mark.asyncio
async def test_chat_reraises_http_exception_from_graph(client, mock_graph):
    """HTTPException vinda do grafo deve ser re-lançada sem alteração de status."""
    mock_graph.ainvoke = AsyncMock(side_effect=HTTPException(status_code=418, detail="sou um bule"))
    with patch("iaa_agent_minhas_financas.graph.AgentGraph.ainvoke", mock_graph.ainvoke):
        resp = await client.post("/chat", json={"message": "oi"})
    assert resp.status_code == 418
    assert resp.json()["detail"] == "sou um bule"
