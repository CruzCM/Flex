"""Integração HML: protocolo MCP e grafo reais, serviços externos simulados."""

import asyncio
import json
from copy import deepcopy
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
import pytest_asyncio
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_mcp_adapters.tools import load_mcp_tools
from mcp.types import CallToolResult, ListToolsResult, TextContent, Tool

FAQ = "consultar_faq_minhas_financas"
EDU = "consultar_educacao_financeira"
RAGS = (FAQ, EDU)


def _payload(status="sucesso", total=2):
    return {"status": status, "mensagem": "Consulta simulada", "total_contextos": total, "contextos": ["Trecho"] * total}


def _turn(name=FAQ, payload=None, call_id="call-1"):
    return [
        HumanMessage(content="pergunta"),
        AIMessage(content="", tool_calls=[{"name": name, "id": call_id, "args": {"pergunta": "pergunta"}}]),
        ToolMessage(content=json.dumps(payload or _payload()), name=name, tool_call_id=call_id),
        AIMessage(content="Resposta fundamentada nos trechos simulados."),
    ]


@pytest_asyncio.fixture
async def api(monkeypatch):
    import iaa_agent_minhas_financas.app as app_module

    monkeypatch.setattr(app_module.graph, "ferramentas_rag_disponiveis", RAGS)
    invoke = AsyncMock(return_value={"messages": _turn()})
    monkeypatch.setattr(app_module.graph, "ainvoke", invoke)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app_module.app), base_url="http://test") as client:
        yield client, invoke, app_module


@pytest.mark.asyncio
@pytest.mark.parametrize("flag", [None, False])
async def test_original_response_contract(api, flag):
    client, _, _ = api
    body = {"message": "Como organizar os gastos?"}
    if flag is not None:
        body["incluir_diagnostico_mcp"] = flag
    response = await client.post("/chat", json=body)
    assert response.status_code == 200
    assert response.json() == {
        "reply": "Resposta fundamentada nos trechos simulados.", "session_id": None, "tool_calls_made": 1,
    }


@pytest.mark.asyncio
@pytest.mark.parametrize("name", RAGS)
@pytest.mark.parametrize("status,total", [
    ("sucesso", 2), ("sem_resultados", 0), ("timeout", 0), ("erro_http", 0), ("erro_tls", 0),
    ("erro_conexao", 0), ("credencial_ausente", 0), ("nao_configurado", 0), ("erro_interno", 0),
    ("credencial_invalida", 0), ("acesso_negado", 0), ("configuracao_invalida", 0),
    ("entrada_invalida", 0), ("resposta_inesperada", 0),
])
async def test_api_reports_received_payload(api, name, status, total):
    client, invoke, _ = api
    invoke.return_value = {"messages": _turn(name, _payload(status, total))}
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": True})
    assert response.status_code == 200
    diag = response.json()["diagnostico_mcp"]
    assert diag == {
        "ferramentas_rag_disponiveis": list(RAGS), "ferramenta_executada": name,
        "status_ferramenta": status, "total_contextos": total,
        "execucoes": [{"ferramenta": name, "status": status, "total_contextos": total}],
    }


@pytest.mark.asyncio
@pytest.mark.parametrize("variant", ["json", "blocks", "artifact", "artifact_only"])
async def test_adapter_content_formats(api, variant):
    client, invoke, _ = api
    messages = _turn()
    if variant == "blocks":
        messages[2].content = [{"type": "text", "text": json.dumps(_payload())}]
    elif variant in ("artifact", "artifact_only"):
        messages[2].artifact = {"structured_content": _payload()}
        messages[2].content = [] if variant == "artifact_only" else "Não contém JSON."
    invoke.return_value = {"messages": messages}
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": True})
    diag = response.json()["diagnostico_mcp"]
    assert (diag["status_ferramenta"], diag["total_contextos"]) == ("sucesso", 2)


@pytest.mark.asyncio
@pytest.mark.parametrize("content", [
    "invalid", "[]", "{}", '{"status":"sucesso"}', '{"total_contextos":2}',
    '{"status":"sucesso","total_contextos":true}', '{"status":"sucesso","total_contextos":-1}',
    '{"status":"sucesso","total_contextos":"2"}', '{"status":[],"total_contextos":0}',
    '{"status":"segredo-sintetico","total_contextos":0}',
    [{"type": "text", "text": "invalid"}],
])
async def test_unreadable_result_never_invents_success(api, content):
    client, invoke, _ = api
    messages = _turn()
    messages[2].content = content
    invoke.return_value = {"messages": messages}
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": True})
    diag = response.json()["diagnostico_mcp"]
    assert diag["status_ferramenta"] == "retorno_nao_interpretavel"
    assert diag["total_contextos"] is None
    assert "segredo-sintetico" not in json.dumps(diag)


@pytest.mark.asyncio
@pytest.mark.parametrize("evidence", ["claim", "orphan", "wrong_id", "wrong_name", "old_turn"])
async def test_false_evidence_is_not_execution(api, evidence):
    client, invoke, _ = api
    messages = _turn()
    if evidence == "claim":
        messages = [HumanMessage(content="oi"), AIMessage(content=f"Executei {FAQ} com sucesso: 99 contextos.")]
    elif evidence == "orphan":
        del messages[1]
    elif evidence == "wrong_id":
        messages[2].tool_call_id = "another-call"
    elif evidence == "wrong_name":
        messages[2].name = EDU
    elif evidence == "old_turn":
        messages += [HumanMessage(content="oi"), AIMessage(content="Olá!")]
    invoke.return_value = {"messages": messages}
    response = await client.post("/chat", json={"message": "oi", "incluir_diagnostico_mcp": True})
    diag = response.json()["diagnostico_mcp"]
    assert diag["execucoes"] == []
    assert diag["ferramenta_executada"] is None
    assert diag["status_ferramenta"] is None
    assert diag["total_contextos"] == 0


@pytest.mark.asyncio
async def test_multiple_calls_keep_non_rag_counter_and_hide_secrets(api):
    client, invoke, _ = api
    payload = _payload()
    payload.update(mensagem="segredo-sintetico", contextos=["segredo-sintetico"], headers={"AppKey": "segredo-sintetico"})
    messages = _turn(FAQ, payload)
    messages += _turn(EDU, _payload("sem_resultados", 0), "call-2")[1:]
    messages += _turn("ferramenta_legitima", call_id="call-3")[1:]
    invoke.return_value = {"messages": messages}
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": True})
    body = response.json()
    diag = body["diagnostico_mcp"]
    assert body["tool_calls_made"] == 3
    assert [item["ferramenta"] for item in diag["execucoes"]] == list(RAGS)
    assert (diag["ferramenta_executada"], diag["status_ferramenta"], diag["total_contextos"]) == (EDU, "sem_resultados", 0)
    assert "segredo-sintetico" not in json.dumps(diag)


@pytest.mark.asyncio
async def test_tool_error_is_not_mcp_success(api):
    client, invoke, _ = api
    messages = _turn()
    messages[2].status = "error"
    invoke.return_value = {"messages": messages}
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": True})
    diag = response.json()["diagnostico_mcp"]
    assert (diag["status_ferramenta"], diag["total_contextos"]) == ("erro_execucao", None)


async def _real_graph(monkeypatch, llm, *, result=None, failure=None, unavailable=False):
    import iaa_agent_minhas_financas.graph as graph_module
    from iaa_agent_minhas_financas.config import MCPAuthentication, MCPServer, MCPTransport, load_agent_config

    names = (*RAGS, "ping", "somar_numeros", "ola_mundo")
    schema = {"type": "object", "properties": {"pergunta": {"type": "string"}}, "required": ["pergunta"]}
    session = AsyncMock()
    session.list_tools.return_value = ListToolsResult(tools=[Tool(name=name, inputSchema=schema) for name in names])
    session.call_tool.return_value = result or CallToolResult(
        content=[TextContent(type="text", text=json.dumps(_payload()))], structuredContent=_payload(),
    )
    session.call_tool.side_effect = failure
    rag_tools = await load_mcp_tools(session)
    other_session = AsyncMock()
    other_session.list_tools.return_value = ListToolsResult(tools=[Tool(name="ping", inputSchema=schema)])
    other_session.call_tool.return_value = CallToolResult(content=[TextContent(type="text", text="pong")])
    other_tools = await load_mcp_tools(other_session)

    def client_factory(connections):
        client = MagicMock()
        is_rag = "mcp-corporativo" in connections
        client.get_tools = AsyncMock(return_value=rag_tools if is_rag else other_tools)
        if is_rag and unavailable:
            client.get_tools.side_effect = ConnectionError("indisponível")
        return client

    cfg = deepcopy(load_agent_config())
    cfg.mcp.servers = [
        MCPServer(name, "test", MCPTransport("streamable_http", "https://mcp.invalid/mcp"), MCPAuthentication("none"))
        for name in ("mcp-corporativo", "outro-servidor")
    ]
    cfg.rag.enabled = False
    monkeypatch.setattr(graph_module, "MultiServerMCPClient", client_factory)
    monkeypatch.setattr(graph_module, "get_config", lambda: cfg)
    monkeypatch.setattr(graph_module.LLMFactory, "create", lambda *args: llm)
    graph = graph_module.AgentGraph()
    await graph.compile()
    return graph, session, other_session


@pytest.mark.asyncio
@pytest.mark.parametrize("name", [FAQ, EDU, "ping"])
@pytest.mark.parametrize("diagnostic", [True, False])
async def test_http_to_real_graph_and_adapter(api, monkeypatch, name, diagnostic):
    client, _, app_module = api
    llm = MagicMock()
    llm.bind_tools.return_value = llm
    llm.ainvoke = AsyncMock(side_effect=[
        AIMessage(content="", tool_calls=[{"name": name, "id": "real-1", "args": {"pergunta": "pergunta"}}]),
        AIMessage(content="Resposta com os trechos recuperados."),
    ])
    graph, session, other = await _real_graph(monkeypatch, llm)
    monkeypatch.setattr(app_module, "graph", graph)
    bound = llm.bind_tools.call_args.args[0]
    assert [tool.name for tool in bound] == [*RAGS, "ping"]
    assert graph.ferramentas_rag_disponiveis == RAGS
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": diagnostic})
    assert response.status_code == 200
    body = response.json()
    assert body["tool_calls_made"] == 1
    assert body["reply"] == "Resposta com os trechos recuperados."
    called = other if name == "ping" else session
    called.call_tool.assert_awaited_once()
    assert called.call_tool.call_args.args[:2] == (name, {"pergunta": "pergunta"})
    if diagnostic:
        diag = body["diagnostico_mcp"]
        assert diag["ferramenta_executada"] == (None if name == "ping" else name)
        assert diag["total_contextos"] == (0 if name == "ping" else 2)
    else:
        assert "diagnostico_mcp" not in body


@pytest.mark.asyncio
async def test_unavailable_startup_preserves_other_tools(api, monkeypatch):
    client, _, app_module = api
    llm = MagicMock()
    llm.bind_tools.return_value = llm
    llm.ainvoke = AsyncMock(return_value=AIMessage(content="Olá!"))
    graph, _, _ = await _real_graph(monkeypatch, llm, unavailable=True)
    monkeypatch.setattr(app_module, "graph", graph)
    assert graph.is_ready
    assert [tool.name for tool in llm.bind_tools.call_args.args[0]] == ["ping"]
    response = await client.post("/chat", json={"message": "Olá!", "incluir_diagnostico_mcp": True})
    diag = response.json()["diagnostico_mcp"]
    assert diag["ferramentas_rag_disponiveis"] == []
    assert diag["execucoes"] == []


@pytest.mark.asyncio
@pytest.mark.parametrize("failure,http_status", [(TimeoutError("timeout"), 504), (httpx.ConnectError("offline"), 502)])
@pytest.mark.parametrize("diagnostic", [True, False])
async def test_transport_failure_has_no_fabricated_execution(api, monkeypatch, failure, http_status, diagnostic):
    client, _, app_module = api
    llm = MagicMock()
    llm.bind_tools.return_value = llm
    llm.ainvoke = AsyncMock(return_value=AIMessage(
        content="", tool_calls=[{"name": FAQ, "id": "failed", "args": {"pergunta": "pergunta"}}],
    ))
    graph, _, _ = await _real_graph(monkeypatch, llm, failure=failure)
    monkeypatch.setattr(app_module, "graph", graph)
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": diagnostic})
    assert response.status_code == http_status
    if not diagnostic:
        assert set(response.json()) == {"detail"}
        return
    diag = response.json()["diagnostico_mcp"]
    assert diag["execucoes"] == []
    assert diag["ferramenta_executada"] is None
    assert diag["chamadas_sem_resultado"] == [{"ferramenta": FAQ, "status": "sem_retorno"}]


@pytest.mark.asyncio
@pytest.mark.parametrize("status,total", [("sem_resultados", 0), ("timeout", 0), ("erro_http", 0), ("sucesso", 3)])
async def test_real_mcp_payload_reaches_llm_and_diagnostic(api, monkeypatch, status, total):
    client, _, app_module = api
    payload = _payload(status, total)
    result = CallToolResult(content=[TextContent(type="text", text=json.dumps(payload))], structuredContent=payload)
    llm = MagicMock()
    llm.bind_tools.return_value = llm
    llm.ainvoke = AsyncMock(side_effect=[
        AIMessage(content="", tool_calls=[{"name": EDU, "id": "result", "args": {"pergunta": "pergunta"}}]),
        AIMessage(content="Resposta baseada no retorno da ferramenta."),
    ])
    graph, _, _ = await _real_graph(monkeypatch, llm, result=result)
    monkeypatch.setattr(app_module, "graph", graph)
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": True})
    assert response.status_code == 200
    diag = response.json()["diagnostico_mcp"]
    assert (diag["status_ferramenta"], diag["total_contextos"]) == (status, total)
    tool_message = llm.ainvoke.await_args_list[-1].args[0][-1]
    assert isinstance(tool_message, ToolMessage)
    assert tool_message.artifact["structured_content"] == payload
    assert json.loads(tool_message.content[0]["text"]) == payload


@pytest.mark.asyncio
async def test_real_mcp_protocol_error_is_safe(api, monkeypatch):
    client, _, app_module = api
    result = CallToolResult(isError=True, content=[TextContent(type="text", text="segredo-sintetico")])
    llm = MagicMock()
    llm.bind_tools.return_value = llm
    llm.ainvoke = AsyncMock(side_effect=[
        AIMessage(content="", tool_calls=[{"name": FAQ, "id": "error", "args": {"pergunta": "pergunta"}}]),
        AIMessage(content="Não foi possível concluir a consulta."),
    ])
    graph, _, _ = await _real_graph(monkeypatch, llm, result=result)
    monkeypatch.setattr(app_module, "graph", graph)
    response = await client.post("/chat", json={"message": "pergunta", "incluir_diagnostico_mcp": True})
    assert response.status_code == 200
    diag = response.json()["diagnostico_mcp"]
    assert diag["status_ferramenta"] == "erro_execucao"
    assert diag["total_contextos"] is None
    assert "segredo-sintetico" not in json.dumps(diag)


@pytest.mark.asyncio
async def test_diagnostic_stream_preserves_telemetry(monkeypatch):
    import iaa_agent_minhas_financas.graph as graph_module
    import opentelemetry.propagate

    tracer = MagicMock()
    monkeypatch.setattr(graph_module, "_azure_tracer", tracer)
    monkeypatch.setattr(opentelemetry.propagate, "inject", lambda headers: headers.update(traceparent="trace-sintetico"))
    observed = {}
    messages = _turn()

    async def stream(state, **kwargs):
        observed.update(kwargs)
        yield state
        yield {"messages": messages}

    graph = graph_module.AgentGraph()
    graph._compiled = MagicMock(astream=stream)
    captured = []
    result = await graph.ainvoke({"messages": messages[:1]}, execution_messages=captured)
    assert result["messages"] == captured == messages
    assert observed == {
        "stream_mode": "values", "config": {"callbacks": [tracer], "metadata": {"traceparent": "trace-sintetico"}},
    }


@pytest.mark.asyncio
async def test_concurrent_requests_and_repeated_session_do_not_share_state(api, monkeypatch):
    client, _, app_module = api

    async def answer(messages):
        await asyncio.sleep(0)
        if isinstance(messages[-1], ToolMessage):
            return AIMessage(content="Resposta da consulta.")
        question = messages[-1].content
        if question == "Olá!":
            return AIMessage(content="Olá!")
        name = FAQ if question == "Como usar o app?" else EDU
        return AIMessage(content="", tool_calls=[{"name": name, "id": "same-id", "args": {"pergunta": question}}])

    llm = MagicMock()
    llm.bind_tools.return_value = llm
    llm.ainvoke = answer
    graph, session, _ = await _real_graph(monkeypatch, llm)
    monkeypatch.setattr(app_module, "graph", graph)
    results = await asyncio.gather(*[
        client.post("/chat", json={"message": question, "session_id": "same-session", "incluir_diagnostico_mcp": True})
        for question in ("Como usar o app?", "Como poupar?")
    ])
    assert [response.json()["diagnostico_mcp"]["ferramenta_executada"] for response in results] == list(RAGS)
    response = await client.post("/chat", json={"message": "Olá!", "session_id": "same-session", "incluir_diagnostico_mcp": True})
    assert response.json()["diagnostico_mcp"]["execucoes"] == []
    assert response.json()["tool_calls_made"] == 0
    assert session.call_tool.await_count == 2


def test_hml_config_env_precedence_and_existing_header(monkeypatch):
    from iaa_agent_minhas_financas.config import load_agent_config
    from iaa_agent_minhas_financas.graph import AgentFactory

    monkeypatch.delenv("MCP_CTL_ENDPOINT", raising=False)
    monkeypatch.setenv("MCP_APP_KEY", "chave-sintetica")
    config = load_agent_config()
    assert [server.name for server in config.mcp.servers] == ["mcp-corporativo"]
    server = config.mcp.servers[0]
    assert server.transport.endpoint == "https://iaa-mcp-mf.ai-interno.api.hm.bb.com.br/v1/mcp"
    server.authentication = None
    entry = AgentFactory._build_mcp_server_entry(server)
    assert entry["headers"] == {"gw-dev-app-key": "chave-sintetica"}
    assert entry["transport"] == "streamable_http"
    monkeypatch.setenv("MCP_CTL_ENDPOINT", "https://override.invalid/mcp")
    assert load_agent_config().mcp.servers[0].transport.endpoint == "https://override.invalid/mcp"


def test_version_and_publication_preserved():
    from iaa_agent_minhas_financas import __version__

    assert __version__ == "0.1.0"
    config = json.loads((Path(__file__).parents[2] / "aic.json").read_text(encoding="utf-8"))
    assert '"publicarPacoteEImagem": false' in json.dumps(config)
