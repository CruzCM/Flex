# -*- encoding: utf-8 -*-
# Referência: https://packaging.python.org/guides/distributing-packages-using-setuptools/

import io
import re

from setuptools import find_packages, setup

common_requirements = [
    'httpx==0.28.1',
    'pytest==9.1.1',
    'pytest-asyncio==1.4.0',
]

dev_requirements = [
    'bandit',
    'flake8',
    'isort',
] + common_requirements

unit_test_requirements = common_requirements

integration_test_requirements = common_requirements

run_requirements = [
    'fastapi==0.141.1',
    'uvicorn[standard]==0.52.4',
    'pydantic==2.13.4',
    'langgraph==1.2.11',
    'langchain-core==1.6.0',
    'langchain-openai==1.6.0',
    'tiktoken==0.7.0',
    'langchain==1.3.17',
    'langchain-azure-ai==1.2.3',
    'langchain-mcp-adapters==0.3.2',
    'azure-identity==1.25.3',
    'openai==3.3.1',
    'pyyaml==6.0.3',
    'httpx==0.28.1',
    'typing-extensions==4.16.0',
    'azure-monitor-opentelemetry==1.8.8',
    'azure-monitor-opentelemetry-exporter==1.0.0b52',
    'opentelemetry-api==1.40.0',
    'opentelemetry-sdk==1.40.0',
    'opentelemetry-distro==0.61b0',
    'opentelemetry-exporter-otlp==1.40.0',
    'opentelemetry-instrumentation-fastapi==0.61b0',
    'opentelemetry-instrumentation-httpx==0.61b0',
    'rapidfuzz==3.14.5',
]

with io.open('./iaa_agent_minhas_financas/__init__.py', encoding='utf8') as version_f:
    version_match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]",
                              version_f.read(), re.M)
    if version_match:
        version = version_match.group(1)
    else:
        raise RuntimeError("Não foi possível encontrar a string de versão.")

with io.open('README.md', encoding='utf8') as readme:
    long_description = readme.read()

setup(
    name="iaa_agent_minhas_financas",
    version=version,
    author="Banco do Brasil S.A.",
    author_email="ditec@bb.com.br",
    packages=find_packages(exclude=['tests', 'tests.*']),
    include_package_data=True,
    url="https://canais.fontes.intranet.bb.com.br/iaa/iaa-agent-minhas-financas/iaa-agent-minhas-financas",
    license="COPYRIGHT",
    description="Microsserviço de agente de IA baseado em LangGraph com FastAPI, ferramentas MCP, RAG e guardrails.",
    long_description=long_description,
    zip_safe=False,
    install_requires=run_requirements,
    extras_require={
         'dev': dev_requirements,
         'unit': unit_test_requirements,
         'integration': integration_test_requirements,
    },
    python_requires='>=3.11',
    classifiers=[
        'Intended Audience :: Information Technology',
        'Natural Language :: Portuguese (Brazilian)',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3.11'
    ],
    keywords=[],
    entry_points={
        'console_scripts': [
            'iaa_agent_minhas_financas = iaa_agent_minhas_financas.__main__:main'
        ],
    },
)
