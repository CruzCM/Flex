# Changelog

Todas as mudanças notáveis serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](http://keepachangelog.com/pt-BR/1.0.0/) e este projeto adere ao padrão [Semantic Versioning](http://semver.org/lang/pt-BR/spec/v2.0.0.html).

## [Não liberado]

### Adicionado

- Integração HML com as ferramentas FAQ e Educação Financeira do MCP, mantendo
  ferramentas legítimas dos outros servidores e a versão do agente `0.1.0`.
- Diagnóstico opcional no `/chat`, correlacionado às mensagens reais de ferramenta,
  omitido quando não solicitado; falhas e retornos desconhecidos não viram sucesso.
- Testes locais de catálogo, protocolo MCP, LangGraph, API, erros e concorrência.
  Evidências e configuração estão no diário e no guia da Etapa 5 no workspace.

## [0.1.0.dev0] - aaaa-mm-dd

### Adicionado
- Primeira versão
