# Plano de execução — Integração Agente Minhas Finanças → MCP Minhas Finanças (HML)

**Finalidade:** documento autossuficiente para o desenvolvedor sênior implementar, testar localmente e entregar o **Agente Minhas Finanças pronto para merge**, com o mínimo de alterações possível. Não são necessárias instruções adicionais de conversas anteriores.

**Situação:** plano para execução; **não** significa que a integração já foi codificada, testada ou validada na rede corporativa.

## 1. Decisões obrigatórias e resultado final

### Preservação

- Manter a versão original do agente **`0.1.0`** e a arquitetura atual FastAPI + LangGraph (`llm_call`, `ToolNode`, `AgentFactory` e `MultiServerMCPClient`).
- **Menor diff possível.** Não refatorar código alheio à tarefa, adicionar nós, criar outro cliente MCP, remover funcionalidades legítimas ou apagar componentes de template.
- Preservar autenticação existente, certificados, mTLS, telemetria, guardrails, health checks e tolerância a falhas.
- As ferramentas `ping`, `somar_numeros` e `ola_mundo` continuam no servidor MCP; somente não devem ser ofertadas ao modelo **a partir do MCP Minhas Finanças**. Não afetar ferramentas de outros servidores MCP.
- Não alterar o repositório do MCP, o Helm, GitOps, pipelines ou configurações de publicação. Manter **`publicarPacoteEImagem: false`** em todo o trabalho.
- Trabalhar somente para **homologação (HML)**. Nada de push, merge ou deploy durante o trabalho local.

### Resultado funcional exigido

**Usuário → Agente Minhas Finanças → Gateway corporativo MCP HML → MCP Minhas Finanças → GeneraBB → MCP → Agente → Usuário.**

- Perguntas sobre **uso do aplicativo**, telas, navegação e funcionalidades: ferramenta `consultar_faq_minhas_financas`.
- Perguntas sobre **educação financeira**, orçamento, poupança, dívidas e planejamento: `consultar_educacao_financeira`.
- Saudações, conversa geral ou perguntas cobertas por outras funções do agente: preservar o comportamento existente; não chamar RAG sem motivo.
- O agente utiliza somente as interfaces públicas das ferramentas (`pergunta`, `top_k` opcional). JWT, UOR, User ID e índices do GeneraBB permanecem no MCP.
- `sem_resultados` e erros geram respostas seguras, sem inventar conteúdos documentais ou expor infraestrutura.

### Principal critério de aceite: Insomnia

O usuário já possui o Insomnia com certificados e endpoint HTTP configurados. **Não alterar a configuração do Insomnia.**

Após implantação autorizada em HML, o usuário chamará o endpoint **já existente e funcional** do agente, no formato externo `POST https://***-interno.api.hm.bb.com.br/v1/chat`. A rota interna FastAPI pode ser `/chat`, conforme o roteamento do gateway; **não criar outra rota nem inventar um hostname**.

A mesma resposta HTTP deve conter:

1. **A resposta normal do agente**, preservando os campos atuais da API.
2. Quando solicitado, **diagnóstico MCP derivado da execução real**, mostrando ferramentas RAG descobertas, ferramenta(s) realmente executada(s), status e quantidade de contextos.

Não usar texto produzido pela LLM como prova de execução de ferramenta.

## 2. Antes de editar: verificar o código real

Reabrir e conferir os seguintes arquivos no repositório `iaa-agent-minhas-financas-main`:

| Arquivo | O que conferir |
|---|---|
| `agent_config.yaml` | Identificador do servidor MCP, interpolação de `MCP_CTL_ENDPOINT`, endpoint atual, `local-mcp`, `instructions`, `rag.enabled` e demais configurações que não devem mudar |
| `iaa_agent_minhas_financas/graph.py` | `AgentFactory.create()`, `MultiServerMCPClient.get_tools()`, proveniência das tools, `llm.bind_tools()`, `ToolNode`, `AgentGraph` e forma de retorno das mensagens |
| `iaa_agent_minhas_financas/app.py` | Modelos reais `ChatRequest`/`ChatResponse`, rota `/chat`, `_invoke_agent()`, formato efetivo do resultado, `response_model` e serialização |
| `iaa_agent_minhas_financas/config.py` e utilitários existentes | Headers/AppKey, contexto SSL/mTLS, timeouts, precedência de ENV e configuração do cliente MCP — **somente leitura**, salvo necessidade técnica justificada |
| `tests/` e dependências | Convenção real de testes, versões instaladas e como o projeto executa pytest |
| `iaa-mcp-mf-main/iaa_mcp_mf/services/service_rag.py` | Nomes, descrições, parâmetros e respostas reais das duas ferramentas — **somente leitura** |

**Não presumir** que `_invoke_agent()` devolve `result["messages"]`, que `ToolMessage.content` é sempre uma string JSON, ou que `ChatResponse` já possui `reply`, `session_id` e `tool_calls_made`. Adequar os trechos ilustrativos abaixo aos schemas verdadeiros preservando os campos atuais.

Se o código contradisser um detalhe deste plano, corrigir a suposição com o menor diff e registrar a divergência; não reestruturar o projeto para encaixá-lo no exemplo.

## 3. Implementação mínima e arquivos envolvidos

### 3.1. `agent_config.yaml` — conexão e orientação da LLM

- Na configuração existente do **servidor MCP corporativo**, estabelecer o endpoint HML como fallback de `MCP_CTL_ENDPOINT`:

  `https://iaa-mcp-mf.ai-interno.api.hm.bb.com.br/v1/mcp`

- Preservar o transporte **Streamable HTTP** e os mecanismos existentes de headers, SSL/mTLS e timeout.
- Conferir a **precedência real de `MCP_CTL_ENDPOINT`**: uma ENV já configurada pode substituir o fallback e apontar para outro servidor. Não sobrescrever silenciosamente a ENV; registrar o que deve ser conferido em HML.
- Desabilitar a entrada de teste `local-mcp` **apenas na configuração alvo de HML**, com a menor edição possível. Preservar componentes do template que não precisem ser apagados.
- Ajustar `instructions`: regras claras de seleção FAQ × Educação Financeira, não chamar RAG em saudações, respeitar demais ferramentas existentes, utilizar apenas contextos retornados e tratar `sem_resultados`/falhas sem alucinar.
- Não desligar `rag.enabled` ou qualquer função preexistente automaticamente: conferir o estado efetivo. Se houver necessidade de desativar RAG legado por duplicidade, justificar separadamente antes de fazê-lo.

### 3.2. `iaa_agent_minhas_financas/graph.py` — catálogo e diagnóstico

- Reaproveitar **`MultiServerMCPClient`** e o `ToolNode` existentes. Não alterar a topologia do grafo.
- Ao descobrir ferramentas no servidor **MCP Minhas Finanças**, aceitar para o modelo apenas:
  - `consultar_faq_minhas_financas`
  - `consultar_educacao_financeira`
- **Atenção ao escopo:** não colocar um `if t.name in ALLOWED_MCP_TOOLS` global sobre a lista combinada de todos os servidores; isso removeria outras ferramentas legítimas. Fazer a seleção por servidor configurado, ou solução equivalente que preserve integralmente as ferramentas dos outros servidores. Se a versão instalada do adaptador não expuser a origem, examinar o fluxo de descoberta e escolher o menor mecanismo seguro; não inventar metadados de proveniência.
- Garantir que a **mesma lista filtrada** seja fornecida ao `llm.bind_tools()` e ao `ToolNode`.
- Expor ao `app.py`, com o menor ajuste possível, a lista das ferramentas RAG **descobertas com sucesso no startup**. Esse dado prova disponibilidade no momento da descoberta; **não prova conectividade permanente**.
- Preservar a degradação existente: se o MCP falhar no startup, o agente continua operando. Como as ferramentas normalmente são descobertas na inicialização, documentar que poderá ser necessário novo rollout/reinício do agente depois que o MCP estiver disponível.

### 3.3. `iaa_agent_minhas_financas/app.py` — diagnóstico opcional no `/chat`

A API existente deve continuar funcionando **sem mudanças para clientes antigos**.

- Entrada: adicionar, somente se compatível com o `ChatRequest` real, o campo opcional `incluir_diagnostico_mcp: bool = False`.
- Saída: adicionar um bloco **opcional** `diagnostico_mcp` ao `ChatResponse` ou mecanismo equivalente de serialização.
- **Quando o parâmetro estiver ausente ou `false`, o campo adicional deve ser omitido do JSON**. Não basta devolver `"diagnostico_mcp": null` se o contrato anterior não tinha esse campo. Verificar `response_model`, aliases e regras reais de serialização antes da mudança.
- Não alterar os nomes nem retirar campos já existentes na resposta.
- O diagnóstico opt-in deve ser restrito aos dados necessários e nunca devolver JWT, AppKey, UOR, User ID, certificados, headers, stack traces, conteúdo integral dos contextos ou detalhes internos da rede.

#### Estrutura de diagnóstico proposta

Para uma chamada única ao FAQ, acrescentar ao **JSON original da resposta** o objeto abaixo, sem substituir os campos anteriores:

```json
{
  "diagnostico_mcp": {
    "ferramentas_rag_disponiveis": [
      "consultar_faq_minhas_financas",
      "consultar_educacao_financeira"
    ],
    "ferramenta_executada": "consultar_faq_minhas_financas",
    "status_ferramenta": "sucesso",
    "total_contextos": 4,
    "execucoes": [
      {
        "ferramenta": "consultar_faq_minhas_financas",
        "status": "sucesso",
        "total_contextos": 4
      }
    ]
  }
}
```

- Manter os campos simples `ferramenta_executada`, `status_ferramenta` e `total_contextos` para facilitar o uso pelo Insomnia. Eles representam a **última execução RAG desta requisição**, quando houver.
- `execucoes` registra **todas** as ferramentas RAG efetivamente executadas **nesta requisição** e evita esconder múltiplas chamadas. Se não houver chamadas: `execucoes: []`, `ferramenta_executada: null`, `status_ferramenta: null`, `total_contextos: 0`.
- `ferramentas_rag_disponiveis` representa as ferramentas descobertas **no startup**, mesmo que nenhuma tenha sido chamada nesta pergunta. Se não houve descoberta: `[]`.
- Não alterar o campo existente `tool_calls_made` arbitrariamente; preservar seu significado real, que pode incluir ferramentas não RAG.

#### Fonte obrigatória dos dados: execução real

1. Obter da invocação **corrente** do LangGraph as mensagens/chamadas geradas no turno, de acordo com a API existente. Não misturar `ToolMessage` de turnos anteriores da mesma sessão.
2. Identificar as chamadas emitidas pelo modelo (`AIMessage.tool_calls`) e correlacioná-las aos resultados `ToolMessage` pelo **`tool_call_id`** quando disponível. Identificar a ferramenta pela associação real, não pelo conteúdo textual de uma mensagem do modelo.
3. Considerar como **execução concluída** somente a chamada com resultado de ferramenta correspondente. Se houver tentativa sem resultado por exceção, não classificá-la como `sucesso`; registrar falha de execução de modo seguro ou ausência de resultado, respeitando os mecanismos reais do grafo.
4. Analisar `ToolMessage.content` conforme o formato concreto do adaptador instalado: JSON em texto, lista de blocos de conteúdo ou estrutura equivalente. Não presumir `json.loads(content)` incondicionalmente. Testar parsing inválido e ausência de campos.
5. Extrair `status` e `total_contextos` **do payload efetivamente recebido**, quando legível. Nunca inferir `sucesso` só porque uma ferramenta foi invocada. Se o retorno não puder ser interpretado, sinalizar diagnóstico indisponível/retorno não interpretável, sem inventar status do MCP.
6. Evitar guardar estado por requisição em atributos globais ou compartilhados do `AgentGraph`: duas chamadas HTTP simultâneas e duas sessões não podem misturar diagnósticos.
7. Manter a resposta textual do agente produzida pelo fluxo atual, sem utilizar campos de diagnóstico como instruções para a LLM.

**Observação:** nomes e schemas exibidos nos exemplos deste plano devem ser confrontados com `app.py` antes de editar. Os exemplos ilustram os novos campos, não substituem o JSON preexistente.

## 4. Contrato das ferramentas e comportamento esperado

Ferramentas públicas no MCP:

- `consultar_faq_minhas_financas(pergunta: str, top_k: int | None = None)`
- `consultar_educacao_financeira(pergunta: str, top_k: int | None = None)`

Resultados esperados possuem `status`, `mensagem`, `total_contextos` e `contextos`. Confirmar a forma serializada real no `service_rag.py` e no adaptador MCP. O status pode incluir `sucesso`, `sem_resultados`, `credencial_ausente`, `nao_configurado`, `timeout`, `erro_http`, `erro_tls`, `erro_conexao` e outros erros previstos no código.

- **`sucesso` e contextos presentes:** sintetizar resposta fundamentada nesses trechos; não inventar telas, recursos ou fatos.
- **`sem_resultados` ou zero contextos:** informar que não foi localizado conteúdo suficiente na base, sem fingir recuperação bem-sucedida.
- **Erro operacional/configuração:** explicar de forma simples que a consulta não pôde ser concluída, sem expor infraestrutura ou segredos.
- **Sem chamada RAG:** responder conforme fluxo normal do agente; diagnóstico deve registrar a ausência real de chamada.

A decisão semântica é do modelo e de suas instruções. **Mocks demonstram o encadeamento técnico; não comprovam que a LLM real sempre escolherá a ferramenta correta.** Essa verificação ocorrerá depois em HML pelo Insomnia.

## 5. Arquivos previstos e limites do diff

| Tipo | Arquivo | Propósito |
|---|---|---|
| Código/configuração | `agent_config.yaml` | Endpoint corporativo HML e instruções mínimas |
| Código | `iaa_agent_minhas_financas/graph.py` | Filtragem por servidor e disponibilização do catálogo RAG |
| Código/API | `iaa_agent_minhas_financas/app.py` | Campo opcional de requisição, diagnóstico real e resposta compatível |
| Testes | `tests/unit/test_graph.py`, testes API existentes ou novo teste pontual | Cobertura da filtragem, mensagens e rota `/chat` |
| Registro | Changelog do agente já existente e diário de evolução aplicável | Diff, testes, limites e pendências |

**Objetivo:** modificar no máximo os três arquivos funcionais previstos, **além** dos testes e registros. Outros arquivos só mediante justificativa técnica concreta e apresentação do motivo antes de ampliar o escopo. Nenhuma alteração no servidor MCP.

## 6. Execução local — ordem para o sênior

1. **Inspecionar** os arquivos reais do agente e do MCP; confirmar schema HTTP, ferramentas, configuração do cliente e convenções de testes. Anotar divergências do plano.
2. **Implementar a conexão** no `agent_config.yaml`, mantendo o fallback HML e o mecanismo de autenticação existente.
3. **Aplicar filtro somente às ferramentas do nosso MCP** em `graph.py`; preservar ferramentas de outros servidores e o mesmo catálogo no modelo e no `ToolNode`.
4. **Refinar o prompt existente** para FAQ, Educação Financeira, conversas gerais e tratamento de resultados vazios/erros; preservar instruções anteriores não conflitantes.
5. **Implementar o diagnóstico opcional** em `app.py`, extraindo dados somente das ferramentas realmente executadas no turno HTTP corrente.
6. **Criar/ajustar testes locais com mocks** usando a infraestrutura atual do projeto; não chamar endpoints corporativos.
7. **Executar a suíte relevante e regressões disponíveis.** Registrar comandos, versões, resultados, falhas e correções. Não declarar testes que não executou.
8. **Inspecionar o diff** para confirmar que nenhum componente/template, funcionalidade ou versão foi removido indevidamente.
9. **Atualizar changelog do agente** e fornecer o checklist de homologação do item 8.

Se alguma premissa impedir a implementação mínima com segurança, registrar a incompatibilidade concreta e apresentar o menor ajuste necessário; não criar uma nova arquitetura por iniciativa própria.

## 7. Testes locais obrigatórios

Usar pytest e mocks nas convenções reais do repositório. Incluir, no mínimo:

- **Catálogo por servidor:** MCP Minhas Finanças retorna os dois RAGs e `ping`, `somar_numeros`, `ola_mundo`; apenas os dois RAGs são vinculados. Outro servidor retorna uma ferramenta legítima e **ela permanece** disponível no modelo e no `ToolNode`.
- **MCP indisponível no startup:** agente continua iniciando e o catálogo RAG fica vazio; não reportar execução inventada.
- **Insomnia/API com flag ausente ou `false`:** resposta JSON não ganha `diagnostico_mcp` e preserva o contrato original.
- **Insomnia/API com flag `true`:** simular sucesso FAQ e Educação Financeira, `sem_resultados`, `timeout`/erro, nenhuma chamada e chamada múltipla; validar nome, status e total de contextos.
- **Correlação da chamada:** rejeitar falsa evidência baseada só em texto da LLM; associar resultado à chamada real.
- **Turnos e sessões:** chamadas antigas da mesma sessão **não** aparecem no diagnóstico atual; duas requisições concorrentes não trocam resultados.
- **Formato de mensagem:** testar as variantes reais de `ToolMessage.content` observadas na biblioteca instalada e o retorno inválido/incompleto.
- **Roteamento simulado:** chamadas mockadas representam FAQ/educação; não declarar comprovada a seleção semântica real pelo modelo.
- **Regressão:** preservar funções antigas, erros existentes, health checks, versão, telemetria e autenticação; não vazar segredos no diagnóstico.

**Entrega:** informar comando executado, quantidade aprovada/reprovada, warnings e limitações. Nenhuma chamada real ao gateway ou ao GeneraBB fora da rede corporativa.

## 8. Procedimento de validação pelo Insomnia após merge HML

**Pré-requisitos (fora do trabalho local):** o MCP atualizado precisa estar implantado, com a Secret `iaa-mcp-mf-rag-credentials` no namespace `iaa-mcp-mf`, as ferramentas acessíveis pelo gateway e os valores técnicos autorizados. Confirmar o funcionamento do MCP antes de iniciar o pod do agente: se a descoberta de ferramentas do agente falhar no startup, poderá ser necessário reiniciá-lo depois que o MCP estiver acessível.

Conferir em HML se o `MCP_CTL_ENDPOINT` efetivo aponta para `https://iaa-mcp-mf.ai-interno.api.hm.bb.com.br/v1/mcp` e se as configurações existentes de acesso pelo gateway funcionam. Não trocar pelo Service interno e não presumir headers de autenticação novos.

**No Insomnia:** usar a requisição `POST https://***-interno.api.hm.bb.com.br/v1/chat` **já configurada pelo usuário**, mantendo certificados, autenticação e headers existentes. Não alterar sua configuração. O corpo abaixo pressupõe os campos `message` e `incluir_diagnostico_mcp`; o sênior deve confirmar com o schema real do agente antes do merge. `session_id` só deve ser fornecido se fizer parte do contrato real.

**Cenário A — FAQ:**

```json
{"message":"Como faço para visualizar meus gastos no Minhas Finanças?","incluir_diagnostico_mcp":true}
```

Resultado esperado: resposta fundamentada, `ferramenta_executada = "consultar_faq_minhas_financas"`, status real e `total_contextos` conforme o retorno, idealmente pelo menos um contexto quando a base estiver corretamente alimentada. Não inventar número fixo.

**Cenário B — Educação Financeira:**

```json
{"message":"Como posso organizar meu orçamento mensal?","incluir_diagnostico_mcp":true}
```

Resultado esperado: resposta de educação financeira, `ferramenta_executada = "consultar_educacao_financeira"`, status e contextos reais.

**Cenário C — Conversa geral:**

```json
{"message":"Olá, bom dia!","incluir_diagnostico_mcp":true}
```

Resultado esperado: resposta normal, `ferramenta_executada = null`, `execucoes = []`, sem consultas RAG. `tool_calls_made` existente deve manter seu significado original.

**Cenário D — Ausência de resultados/erro:**

Usar uma condição real de retorno sem resultados, ou um cenário controlado de erro autorizado. Não provocar falhas no cluster apenas para o teste. Verificar resposta segura e diagnóstico fiel (`sem_resultados`, `timeout` ou o status real observado); não declarar um status sem evidência.

**Cenário E — Retrocompatibilidade:**

Repetir uma requisição omitindo `incluir_diagnostico_mcp`; comparar a estrutura do JSON aos consumidores atuais e confirmar que `diagnostico_mcp` está ausente.

**Evidências aceitáveis:** resposta textual correta; identificação da execução real pelo nome e `tool_call_id`; status/contagem provenientes da ferramenta; comportamento preservado nos testes sem RAG. Não usar declaração da LLM como prova de ferramenta executada.

## 9. Checklist de conclusão e pendências

### Aceite local (responsabilidade do sênior)

- [ ] Código do agente atualizado com **menor diff** e versão `0.1.0` preservada.
- [ ] Template, funcionalidades existentes, autenticação, certificados e telemetria preservados.
- [ ] Gateway HML configurado como fallback, com precedência ENV confirmada.
- [ ] Duas ferramentas RAG selecionadas **sem perder ferramentas legítimas de outros servidores**.
- [ ] Prompt atualizado sem remover diretrizes importantes do agente.
- [ ] `/chat` mantém contrato original por padrão e fornece diagnóstico **opt-in**, verdadeiro e seguro.
- [ ] Diagnóstico considera apenas a requisição atual, suporta múltiplas chamadas e não presume sucesso quando o retorno é inválido.
- [ ] Testes locais executados, resultados registrados e falhas corrigidas.
- [ ] Diff revisado, changelog atualizado e ausência de segredos confirmada.
- [ ] Nenhum push, merge ou deploy executado; nenhum pipeline, GitOps ou MCP alterado.

### Dependências a verificar somente em HML

- [ ] MCP com código atualizado, Secret válida e chart renderizado/sincronizado corretamente.
- [ ] Ferramentas RAG acessíveis no gateway corporativo pelo pod do agente.
- [ ] Configuração efetiva do gateway, AppKey e mTLS existente verificada (sem presumir valores).
- [ ] Agente iniciado/reiniciado **depois** da disponibilidade do MCP caso a descoberta inicial tenha falhado.
- [ ] Verificar resposta correta e diagnóstico real nos cenários do Insomnia.
- [ ] Confirmar imagem/digest novos e mecanismos efetivos de entrega conforme esteira corporativa; **não** mudar `publicarPacoteEImagem: false`.

### Entrega final do sênior

Apresentar **(1)** arquivos alterados e diff, **(2)** resumo funcional, **(3)** comandos e resultados dos testes, **(4)** JSON de exemplo **compatível com o schema real**, **(5)** lista de pendências corporativas e **(6)** checklist de Insomnia com o endereço já usado pelo usuário.

**Critério final:** uma chamada real ao `/v1/chat` no Insomnia deve mostrar, na mesma resposta HTTP, o texto correto do agente e evidência verificável da(s) ferramenta(s) RAG efetivamente executada(s), **sem alterar o comportamento anterior quando o diagnóstico não for solicitado**.
