# Documentação Negocial e Técnica

## 1. Visão executiva

Este projeto é um motor de criação de mensagens persuasivas com controle de intenção, fonte, tom e rastreabilidade. Ele transforma insumos estruturados de negócio em variações de comunicação geradas por LLM, passando por etapas especializadas de revisão, copywriting, aplicação de tendência cognitiva, voz institucional, tagline, headline e CTA.

O ponto central do projeto não é "pedir um texto para uma IA". O projeto cria uma esteira controlada onde a LLM atua como transformador textual em etapas delimitadas. O código escolhe os insumos, monta os templates, controla a ordem, injeta os outputs anteriores nas próximas etapas, aplica variações e registra o que foi enviado e recebido.

Em termos negociais, o sistema existe para reduzir improviso criativo em mensagens comerciais e institucionais. Ele permite gerar alternativas de comunicação a partir de regras explícitas, catálogos editáveis e prompts auditáveis, preservando limites de promessa e consistência de voz.

Em termos técnicos, o sistema é propositalmente simples: Python, arquivos YAML, preenchimento de placeholders, chamadas HTTP diretas para provedores LLM e objetos de resultado em memória. Essa rusticidade torna o fluxo fácil de inspecionar, ajustar e explicar.

## 2. Problema negocial

Comunicação persuasiva em escala costuma sofrer com quatro problemas:

- Inconsistência: cada pessoa ou prompt pode criar uma mensagem com lógica diferente.
- Perda de fidelidade: a IA pode inventar benefícios, condições, números, urgências ou promessas.
- Falta de rastreabilidade: depois da geração, nem sempre é claro qual insumo, prompt, parâmetro ou etapa gerou determinado texto.
- Dificuldade de variação controlada: gerar muitas alternativas normalmente aumenta o risco de desvio semântico.

O projeto responde a esses problemas criando uma cadeia de geração em que cada transformação textual tem uma função delimitada. O sistema separa o que é dado de negócio, o que é estratégia criativa, o que é viés cognitivo, o que é voz institucional e o que é formato final.

## 3. Objetivo do projeto

O objetivo é gerar variações de comunicação persuasiva que sejam:

- orientadas por insumos reais de produto e público;
- alinhadas a uma estrutura de apresentação definida;
- desenvolvidas por um cenário de copywriting explícito;
- adaptadas por tendências cognitivas controladas;
- normalizadas para Voz Institucional BB;
- convertidas em texto, título e chamada para ação;
- rastreáveis do começo ao fim.

O resultado esperado não é uma única "resposta criativa", mas um conjunto de alternativas comparáveis, cada uma com caminho técnico identificável: produto, público, apresentação, cenário, tendência, prompts, parâmetros e outputs.

## 4. Tese do método

A tese do projeto é que criatividade pode ser guiada por estrutura.

O sistema não tenta substituir direção criativa por uma chamada genérica à LLM. Ele decompõe a criação em camadas:

- Fonte de negócio: produto e público.
- Arquitetura da proposta: apresentação.
- Estrutura persuasiva: cenário.
- Tendência cognitiva: forma de organizar atenção, contraste, pertencimento, curiosidade ou outro efeito.
- Voz institucional: adequação ao tom e aos limites da marca.
- Formatos finais: tagline, headline e CTA.

Essa separação cria um método. Cada camada tem um papel claro e reduz a chance de que a LLM misture funções, invente informações ou reescreva a estratégia inteira sem controle.

## 5. Como o projeto chega ao resultado

O fluxo começa com a seleção de quatro elementos de negócio:

- Produto: o que está sendo comunicado.
- Público: para quem a comunicação será criada.
- Apresentação: qual estrutura inicial organiza a proposta de valor.
- Cenário: qual lógica de copywriting desenvolve a mensagem.

Depois disso, o sistema monta uma apresentação-base preenchendo placeholders com dados do produto e do público. Essa apresentação passa por duas etapas iniciais:

1. Revisor textual: revisa e estabiliza a apresentação.
2. Copywriter: transforma a apresentação revisada em texto-base, usando o cenário escolhido.

Depois dessas duas etapas, o sistema inicia a geração automática de variações por tendência cognitiva:

1. Tendência cognitiva: aplica uma tendência ao texto-base sem viés.
2. Voz BB: reescreve o texto para Voz Institucional BB.
3. Tagline: produz um texto curto.
4. Headline: produz o título.
5. CTA: produz a chamada para ação.

Cada tendência gera um caminho próprio. Se houver mais de um prompt em alguma etapa automática, o fluxo se ramifica também por prompt. Com o acervo atual, há 10 tendências cognitivas, 1 prompt de tendência, 2 prompts de Voz BB, 1 prompt de tagline, 1 prompt de headline e 1 prompt de CTA. Portanto, se todas as chamadas forem válidas, o fluxo automático pode produzir até 20 conjuntos finais.

## 6. Arquitetura conceitual

O projeto usa seis conceitos principais.

| Conceito | Papel negocial | Papel técnico |
| --- | --- | --- |
| Produto | Define oferta, benefícios racionais e benefícios emocionais | Arquivo YAML em `produtos/` carregado como `Produto` |
| Público | Define segmento, necessidade racional e necessidade emocional | Arquivo YAML em `publicos/` carregado como `Publico` |
| Apresentação | Define a primeira arquitetura da proposta de valor | Arquivo YAML em `apresentacoes/` carregado como `Apresentacao` |
| Cenário | Define estrutura de copywriting, como AIDA, BAB, FAB ou direto | Arquivo YAML em `cenarios/` carregado como `Cenario` |
| Tendência | Define uma lente cognitiva para gerar variações | Arquivo YAML em `tendencias/` carregado como `Tendencia` |
| Prompt | Define a instrução técnica enviada à LLM em cada etapa | Arquivo YAML em `prompts/<grupo>/` carregado como `Prompt` |

Essa arquitetura faz dos YAMLs a camada editável de conhecimento. Alterar o negócio, o método ou os prompts não exige alterar o motor, desde que os contratos de campos e placeholders sejam preservados.

## 7. Estrutura do projeto

Estrutura principal:

```text
.
├── apresentacoes/
├── cenarios/
├── produtos/
├── prompts/
├── publicos/
├── tendencias/
├── src/
├── config.env
├── exportar_projeto_zip.py
├── requirements.txt
└── rotina-principal.ipynb
```

Módulos centrais:

| Arquivo | Responsabilidade |
| --- | --- |
| `src/modelos.py` | Dataclasses de domínio, estruturas de resultado e provedores `Genera` e `OllamaLocal` |
| `src/motor.py` | Orquestração do pipeline, carregamento dos catálogos, execução das etapas e ramificações |
| `src/yaml_utils.py` | Leitura de YAML, validação e preenchimento de placeholders |
| `src/app.py` | Experiência guiada no notebook, UI em cards, seleção de opções e exibição de resultados |
| `src/configuracao.py` | Parâmetros editáveis de geração por etapa |
| `src/ollama_local.py` | Provedor local compatível com a interface do `Genera` |
| `src/test_ux_cards.py` | Testes automatizados da experiência, cards, placeholders e comportamento de exibição |

## 8. Catálogos YAML como camada de conhecimento

O projeto usa YAML porque o conhecimento do negócio precisa ser editável, legível e versionável. Cada pasta representa uma dimensão do método.

Estado atual do acervo:

| Catálogo | Quantidade atual | Pasta |
| --- | ---: | --- |
| Produtos | 2 | `produtos/` |
| Públicos | 2 | `publicos/` |
| Apresentações | 6 | `apresentacoes/` |
| Cenários | 4 | `cenarios/` |
| Tendências | 10 | `tendencias/` |
| Grupos de prompts | 7 | `prompts/` |

Quantidade atual de prompts por grupo:

| Grupo | Quantidade | Função |
| --- | ---: | --- |
| `1_revisor_textual` | 2 | Revisar a apresentação inicial |
| `2_copywriter` | 1 | Desenvolver texto-base pelo cenário |
| `3_tendencia_cognitiva` | 1 | Aplicar tendência cognitiva |
| `4_voz_BB` | 2 | Normalizar para Voz BB |
| `5_tagline` | 1 | Gerar texto curto |
| `6_headline` | 1 | Gerar título |
| `7_cta` | 1 | Gerar chamada para ação |

### 8.1 Produtos

Arquivos em `produtos/` descrevem a oferta. O formato atual usa placeholders de produto:

```yaml
PH_SGT_DCR: |
  Descrição do produto.

PH_SGT_RCNL: |
  Benefício racional do produto.

PH_SGT_EMOC: |
  Benefício emocional do produto.
```

Esses campos alimentam as apresentações. O motor também aceita chaves alternativas antigas, como `descricao`, `beneficio_racional` e `beneficio_emocional`, mas o formato `PH_*` é o contrato principal para a montagem.

### 8.2 Públicos

Arquivos em `publicos/` descrevem para quem a mensagem é criada:

```yaml
PH_PBCO_DCR: |
  Descrição do público.

PH_PBCO_RCNL: |
  Necessidade racional do público.

PH_PBCO_EMOC: |
  Necessidade emocional do público.
```

Esses campos são combinados com os dados do produto para formar a proposta inicial.

### 8.3 Apresentações

Arquivos em `apresentacoes/` definem a arquitetura inicial da proposta:

```yaml
template: |
  Para {PH_PBCO_DCR}, que enfrenta {PH_PBCO_RCNL}, {PH_SGT_DCR} entrega {PH_SGT_RCNL}.

descricao: |
  Explicação do propósito, benefícios e momento de uso.
```

A apresentação é o primeiro molde semântico do projeto. Ela define o ponto de entrada da mensagem antes da LLM atuar.

### 8.4 Cenários

Arquivos em `cenarios/` definem a estrutura persuasiva:

```yaml
texto_prompt: |
  Estrutura que a etapa de copywriting deve seguir.

funcao_prompt: |
  Intenção e função persuasiva do cenário.

exibir_usuario: |
  Texto opcional para exibição.
```

Exemplos atuais: `AIDA`, `BAB`, `FAB` e `Copywriting_Direto`.

### 8.5 Tendências

Arquivos em `tendencias/` definem lentes cognitivas usadas para variar a mensagem:

```yaml
texto_prompt: |
  Como a tendência deve alterar a organização do texto.

funcao_prompt: |
  Intenção e função cognitiva.

not_prompt_descricao: |
  Descrição opcional para documentação e exibição.
```

A tendência não deve criar fatos novos. Ela altera o modo de organizar atenção, sequência, contraste, curiosidade ou identificação.

### 8.6 Prompts

Arquivos em `prompts/<grupo>/` definem o que será enviado à LLM:

```yaml
template: |
  Template com placeholders.

system: |
  Instruções de papel, tarefa, regras e saída.

versao: |
  Campo opcional.
```

Cada prompt pertence a um grupo que corresponde a uma etapa do pipeline.

## 9. Placeholders como contrato semântico

Os placeholders `PH_*` são o contrato entre negócio, prompt e motor.

Eles garantem que cada template declare explicitamente quais valores precisa receber. O motor valida e preenche esses valores antes de chamar a LLM.

Formatos aceitos:

```text
{PH_NOME}
{{PH_NOME}}
```

Regras principais:

- O nome deve começar com `PH_`.
- O nome deve usar letras maiúsculas, números e underscore.
- Placeholder solto, sem chaves, é erro.
- Chaves incompletas ou aninhadas de forma inválida são erro.
- Placeholder sem valor disponível é erro.

A validação acontece em `src/yaml_utils.py`, principalmente por `placeholders()`, `preencher()` e `partes_preenchidas()`.

Esse desenho é simples, mas importante: ele impede que uma chamada à LLM seja feita com template malformado ou com dado ausente.

## 10. Pipeline técnico

As etapas estão definidas em `ETAPAS`, dentro de `src/motor.py`. Cada etapa possui identificador, título, grupo de prompt, placeholder de entrada, placeholder de saída e parâmetros padrão.

| Ordem | Etapa | Grupo de prompt | Entrada | Saída | Temperatura | Max tokens |
| ---: | --- | --- | --- | --- | ---: | ---: |
| 1 | `revisor_textual` | `1_revisor_textual` | `PH_APRESENTACAO` | `PH_APRESENTACAO_REVISADA` | 0.5 | 512 |
| 2 | `copywriter` | `2_copywriter` | `PH_APRESENTACAO_REVISADA` | `PH_BASE_SEM_VIES` | 0.7 | 700 |
| 3 | `tendencia_cognitiva` | `3_tendencia_cognitiva` | `PH_BASE_SEM_VIES` | `PH_BASE_COM_VIES` | 0.7 | 700 |
| 4 | `voz_bb` | `4_voz_BB` | `PH_BASE_COM_VIES` | `PH_BASE_BB` | 0.5 | 700 |
| 5 | `tagline` | `5_tagline` | `PH_BASE_BB` | `PH_TEXTO` | 0.7 | 180 |
| 6 | `headline` | `6_headline` | `PH_TEXTO` | `PH_TITULO` | 0.7 | 120 |
| 7 | `cta` | `7_cta` | `PH_TITULO` | `PH_TEXTO_CTA` | 0.6 | 80 |

Os parâmetros ficam centralizados em `src/configuracao.py` e são aplicados sobre as etapas no carregamento do motor.

## 11. Fluxo de dados

O fluxo começa com uma `Selecao`:

```python
Selecao(
    produto="cartao_ouro",
    publico="familia_estabelecida",
    apresentacao="encaixe_de_valor",
    cenario="AIDA",
    limite_tagline=100,
    limite_headline=25,
)
```

O motor carrega os objetos de catálogo e monta o contexto inicial:

```python
{
    "PH_APRESENTACAO": "...",
    "PH_LIMITE_CARACTER_TEXTO": "100",
    "PH_LIMITE_CARACTER_TITULO": "25",
}
```

Cada etapa lê valores desse contexto, preenche o template do prompt e grava o output em um novo placeholder. Exemplo:

```text
PH_APRESENTACAO
  -> revisor_textual
PH_APRESENTACAO_REVISADA
  -> copywriter
PH_BASE_SEM_VIES
  -> tendencia_cognitiva
PH_BASE_COM_VIES
  -> voz_bb
PH_BASE_BB
  -> tagline
PH_TEXTO
  -> headline
PH_TITULO
  -> cta
PH_TEXTO_CTA
```

A LLM não decide esse fluxo. O fluxo é código Python.

## 12. Uso técnico da LLM

Esta é a parte mais importante tecnicamente: a LLM é usada como um transformador textual especializado por etapa.

Para cada chamada, o motor faz o seguinte:

1. Identifica a etapa atual.
2. Carrega o prompt YAML correspondente.
3. Monta o dicionário de valores da etapa.
4. Preenche o `template` com `preencher()`.
5. Define parâmetros como `temperature` e `max_tokens`.
6. Cria um `ResultadoPrompt` para rastrear a chamada.
7. Instancia o provedor LLM.
8. Chama `instancia.call(...)`.
9. Valida se a resposta tem `output` textual.
10. Salva o output no resultado e no contexto da próxima etapa.

A chamada central acontece em `executar_prompt()`, em `src/motor.py`.

Formato conceitual da chamada:

```python
instancia.call(
    prompt=entrada,
    system=prompt.system,
    template=template_preenchido,
    prompt_params=None,
    temperature=parametros["temperature"],
    max_tokens=parametros["max_tokens"],
    top_p=parametros["top_p"],
    frequency_penalty=parametros["frequency_penalty"],
    presence_penalty=parametros["presence_penalty"],
    best_of=parametros["best_of"],
    exibir=False,
    exibir_detalhado=False,
)
```

Há três elementos textuais relevantes:

| Elemento | Origem | Função |
| --- | --- | --- |
| `system` | Campo `system` do prompt YAML | Define papel, regras, limites e formato de saída |
| `template` | Campo `template` preenchido | Leva instruções específicas e dados estruturados para a etapa |
| `prompt` ou `entrada` | Valor do placeholder de entrada da etapa | Conteúdo principal que será transformado |

Na prática, `template` e `prompt` podem parecer redundantes em algumas etapas, mas cumprem papéis diferentes no desenho atual. O `template` organiza a tarefa e os dados delimitados. O `prompt` é o texto de entrada principal que o provedor recebe também como `input`.

## 13. A LLM não controla o sistema

O controle do sistema fica no Python.

A LLM não escolhe:

- produto;
- público;
- apresentação;
- cenário;
- tendência;
- prompt;
- próxima etapa;
- quantidade de variações;
- parâmetros de geração;
- atualização do contexto;
- regra de ramificação;
- critério técnico de validade.

Essas decisões pertencem ao motor. A LLM recebe uma tarefa já delimitada, executa uma transformação textual e devolve texto.

Essa separação é uma das principais forças do projeto. O modelo gera linguagem, mas não governa o processo.

## 14. Como a LLM não é usada

O projeto não usa:

- fine-tuning;
- RAG;
- embeddings;
- banco vetorial;
- agentes autônomos;
- function calling;
- tools chamadas pela LLM;
- busca externa;
- navegação na internet;
- memória persistente;
- avaliação factual automática;
- verificador automático de compliance;
- classificador de qualidade;
- schema rígido de saída;
- parser estruturado de resposta;
- fila de execução;
- retry automático;
- cache de chamadas;
- paralelização de chamadas.

Isso significa que o projeto é tecnicamente direto. Ele não tenta construir uma plataforma de agentes. Ele constrói uma esteira de transformação textual controlada por código e alimentada por YAML.

## 15. Memória conversacional

As classes de provedor possuem atributo `messages`, `conversation_id`, `historico()` e métodos de reset. Porém, no fluxo principal, o motor cria uma nova instância do provedor dentro de cada chamada de prompt.

Consequência prática: não há memória conversacional real entre etapas no fluxo normal.

O encadeamento entre etapas acontece porque o código pega o `output` de uma etapa e grava esse texto no contexto, em um placeholder usado pela etapa seguinte.

Exemplo:

```text
Output da etapa copywriter
  -> contexto["PH_BASE_SEM_VIES"]
  -> usado no template da etapa tendencia_cognitiva
```

Isso é mais rústico do que manter uma conversa contínua com o modelo, mas é mais auditável. Cada etapa pode ser inspecionada separadamente.

## 16. Contrato de retorno da LLM

O provedor deve retornar um dicionário com a chave `output`.

O motor valida a resposta com `validar_chamada()`:

- se a resposta não for dicionário, falha;
- se não houver `output`, falha;
- se `output` for `None`, falha;
- se `output` não for texto, falha;
- se `output` estiver vazio, falha.

Quando uma chamada falha, o erro é guardado no `ResultadoPrompt`. Se todos os prompts de uma etapa falharem, a etapa é interrompida com erro e o contexto da próxima etapa não é atualizado.

Essa validação não garante qualidade criativa, factual ou institucional. Ela garante apenas que existe uma saída textual mínima para continuar o fluxo.

## 17. Provedor Genera oficial

O provedor oficial está em `src/modelos.py`, na classe `Genera`.

Endpoint:

```text
https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent
```

O `agent_id` usado é:

```text
mf-insights
```

As credenciais e identificadores são carregados de `config.env`:

```text
CHAVE
CLIENT_ID
UOR
```

O documento não deve registrar valores reais dessas variáveis. Elas são citadas apenas pelo nome.

Headers enviados:

```python
{
    "Accept": "application/json",
    "X-Client-Id": os.getenv("CLIENT_ID"),
    "UOR": os.getenv("UOR"),
    "userIdentification": os.getenv("CHAVE"),
    "Content-Type": "application/json",
}
```

Payload conceitual:

```python
{
    "action": "conversar",
    "agent_id": "mf-insights",
    "body": {
        "data": {
            "input": prompt,
            "context": {
                "conversation_id": conversation_id,
                "messages": mensagens_envio,
            },
            "prompt_params": {},
            "config": {
                "temperature": temperature,
                "max_tokens": max_tokens,
                "top_p": top_p,
                "frequency_penalty": frequency_penalty,
                "presence_penalty": presence_penalty,
                "best_of": best_of,
            },
        }
    },
}
```

A resposta esperada é extraída de:

```python
response_body["data"]["output"]["text"][0]
```

O resultado completo preserva snapshots de request, payload, headers, status, response e output. Isso sustenta a rastreabilidade técnica.

Observação técnica importante: a chamada usa `verify=False` e desativa warnings de certificado. Isso pode ser aceitável em contexto interno específico, mas deve ser tratado como ponto de atenção técnico e de segurança se o projeto for endurecido para produção.

## 18. Provedor Ollama local

O provedor local está em `src/ollama_local.py` e expõe `ollama = OllamaLocal`.

Ele é usado quando o notebook chama:

```python
fluxo_geracao("ollama")
```

Configurações:

```text
OLLAMA_URL
OLLAMA_MODEL
```

Se `OLLAMA_URL` não for definido, o padrão é:

```text
http://localhost:11434
```

Antes de rodar, o provedor pode verificar modelos disponíveis em:

```text
/api/tags
```

A geração usa:

```text
/api/chat
```

Payload conceitual:

```python
{
    "model": modelo,
    "messages": mensagens_envio,
    "stream": False,
    "options": {
        "temperature": temperature,
        "top_p": top_p,
        "num_predict": max_tokens,
        "frequency_penalty": frequency_penalty,
        "presence_penalty": presence_penalty,
        "best_of": best_of,
    },
}
```

O output é lido preferencialmente de:

```python
response_body["message"]["content"]
```

Há fallback para:

```python
response_body["response"]
```

O objetivo do Ollama local é permitir teste e desenvolvimento sem depender do gateway oficial.

## 19. Forma rústica da implementação

A implementação é rústica no melhor sentido: poucas camadas, pouco acoplamento externo e comportamento visível.

Características:

- Templates YAML são preenchidos por substituição de placeholders.
- O estado do fluxo fica em um dicionário chamado `contexto`.
- Cada etapa lê um conjunto de chaves e escreve uma nova chave.
- As chamadas LLM são HTTP diretas.
- Os provedores têm uma interface compatível por convenção: método `call(...)` que retorna dicionário.
- A ramificação automática é feita por loops e recursão em Python.
- A rastreabilidade é guardada em dataclasses de resultado.
- A experiência visual é montada no notebook por HTML gerado em `app.py`.

Essa rusticidade traz vantagens:

- fácil leitura;
- fácil depuração;
- baixa dependência de framework;
- boa auditabilidade;
- facilidade para explicar o fluxo para negócio e engenharia.

Também traz limitações:

- pouca abstração formal de provedores;
- ausência de retry;
- ausência de execução paralela;
- ausência de persistência estruturada;
- ausência de schemas rígidos para outputs;
- dependência da disciplina dos prompts para qualidade semântica.

## 20. Orquestração e ramificação

A função principal do motor é `rodar_fluxo()`.

Ela executa duas fases:

1. Fase inicial com escolha de resultado:
   - `revisor_textual`;
   - `copywriter`.

2. Fase automática por tendência:
   - `tendencia_cognitiva`;
   - `voz_bb`;
   - `tagline`;
   - `headline`;
   - `cta`.

Na fase inicial, se houver mais de um resultado válido, o sistema pede escolha. Na fase automática, todo resultado válido cria um novo caminho.

A função `executar_fluxo_automatico_por_tendencia()` é o núcleo da ramificação. Ela percorre todas as tendências e todos os prompts das etapas automáticas. Cada caminho válido gera um `ConjuntoGerado`.

Um `ConjuntoGerado` preserva:

- `id`;
- `contexto`;
- `resultados`;
- `tendencia`;
- `prompts`.

Ele também expõe propriedades úteis:

- `texto_institucional`;
- `tagline`;
- `headline`;
- `cta`.

## 21. Rastreabilidade

O projeto registra informações suficientes para auditar cada geração.

Em `ResultadoPrompt`:

- prompt usado;
- system prompt;
- template original;
- template preenchido;
- entrada;
- opção/tendência;
- parâmetros;
- output;
- resposta bruta;
- erro;
- marcador de escolhido.

Em `ResultadoEtapa`:

- id da etapa;
- título;
- entrada comum;
- todos os resultados de prompt;
- prompt selecionado;
- opção selecionada;
- saída selecionada;
- erro.

Em `Resultado`:

- seleção inicial;
- apresentação visual;
- apresentação em texto;
- placeholders preenchidos;
- contexto final;
- etapas;
- conjuntos finais.

A propriedade `historico_tecnico` consolida uma lista de chamadas, incluindo etapa, prompt, opção, parâmetros, escolha, erro e chamada bruta.

Na experiência guiada, os cards mostram:

- resultado;
- template preenchido;
- system;
- payload.

Isso permite responder perguntas como:

- Qual prompt gerou esta headline?
- Qual tendência estava aplicada?
- Qual system prompt foi enviado?
- Qual template preenchido chegou ao modelo?
- Quais parâmetros foram usados?
- A chamada falhou ou retornou output válido?

## 22. Governança textual

A governança do projeto está principalmente nos prompts.

As instruções atuais reforçam:

- usar apenas informações presentes no texto-base;
- não criar fatos, condições, números, valores, prazos ou garantias;
- preservar nível de promessa;
- não transformar possibilidade em certeza;
- não criar urgência artificial;
- não criar CTA antes da etapa correta;
- considerar conteúdo delimitado como dado, não como instrução;
- preservar estrutura cognitiva quando ela define a mensagem;
- adequar a Voz Institucional BB sem neutralizar a intenção.

Essa governança é textual e prompt-driven. Ela reduz risco, mas não equivale a um verificador formal. O sistema ainda depende da qualidade dos prompts e da revisão humana para usos sensíveis.

## 23. Voz Institucional BB

A etapa `voz_bb` é uma camada de normalização.

Ela não deve reinventar a mensagem. Sua função é ajustar expressão, clareza, tom, proximidade e institucionalidade, preservando:

- conteúdo;
- direção argumentativa;
- nível de promessa;
- função comunicativa;
- assinatura cognitiva.

A Voz BB atual é descrita como:

- inteligentemente simples;
- relevante;
- humana;
- encorajadora.

Essa etapa é importante porque separa persuasão de tom institucional. O texto pode nascer em uma estrutura de copywriting e depois ser ajustado para soar compatível com a marca.

## 24. Interface de uso

O uso principal acontece no notebook `rotina-principal.ipynb`.

Exemplo para Ollama local:

```python
from src.app import fluxo_geracao

resultado = fluxo_geracao("ollama")
```

Exemplo para Genera oficial:

```python
from src.app import fluxo_geracao

resultado = fluxo_geracao()
```

A função `fluxo_geracao()`:

1. normaliza o provedor;
2. localiza a raiz do projeto;
3. verifica dependências;
4. resolve o provedor;
5. importa o motor;
6. inicia a experiência guiada.

A UI em notebook exibe cards para escolhas, parâmetros, etapas, resultados e detalhes técnicos. Fora de notebook, o projeto usa saída textual no terminal.

## 25. Configuração de ambiente

Dependências em `requirements.txt`:

```text
python-dotenv
PyYAML
requests
urllib3
```

Variáveis para Genera oficial em `config.env`:

```text
CHAVE=<valor>
CLIENT_ID=<valor>
UOR=<valor>
```

Variáveis opcionais para Ollama:

```text
OLLAMA_URL=<valor>
OLLAMA_MODEL=<valor>
```

Valores reais de credenciais não devem ser documentados, copiados para exemplos ou versionados em materiais externos.

## 26. Validações existentes

O projeto possui validações em três camadas.

### 26.1 Validação de catálogo

`motor.validar_catalogos()` percorre produtos, públicos, apresentações, cenários, tendências e prompts, tentando carregar cada arquivo e validando campos obrigatórios.

Comando:

```bash
python -c "from src import motor; erros = motor.validar_catalogos(); print(erros)"
```

Estado atual observado:

```text
erros=0
```

### 26.2 Validação de placeholders

`yaml_utils.py` impede placeholders malformados ou sem valor. Isso evita chamadas com templates tecnicamente inválidos.

### 26.3 Validação de resposta LLM

`validar_chamada()` garante que a resposta da LLM possua `output` textual não vazio.

## 27. Testes automatizados

A suíte atual está em `src/test_ux_cards.py`.

Comando:

```bash
python -m unittest src.test_ux_cards
```

Estado atual observado:

```text
Ran 32 tests
OK
```

Os testes cobrem principalmente:

- cards e subcards da UI;
- renderização de resultados;
- seleção por índice;
- placeholders preenchidos;
- avisos de placeholders extras;
- bloqueio por placeholder ausente;
- ordem oficial de seções;
- comportamento da etapa de tendência;
- nomes exibidos de YAML;
- ausência de blocos extras em certas telas.

Ainda há espaço para testes mais profundos no motor, especialmente para falhas de provedor, ramificação, limites de parâmetros e compatibilidade dos provedores.

## 28. Checklist para novos YAMLs

Antes de adicionar ou alterar um YAML:

- Confirmar que o arquivo está em UTF-8.
- Confirmar que os campos obrigatórios existem.
- Usar somente placeholders no formato `{PH_NOME}` ou `{{PH_NOME}}`.
- Garantir que todo placeholder usado tem valor no contexto da etapa.
- Evitar chaves soltas, placeholders minúsculos ou nomes incompletos.
- Não inserir segredos ou dados sensíveis no YAML.
- Rodar `motor.validar_catalogos()`.
- Executar os testes automatizados.

## 29. Checklist para novos prompts

Ao criar um novo prompt:

- Colocar o arquivo no grupo correto dentro de `prompts/`.
- Definir `template` e `system`.
- Declarar claramente papel, tarefa, fontes, regras e formato de saída.
- Delimitar dados de entrada quando possível.
- Reforçar que o modelo deve usar somente a fonte recebida.
- Proibir criação de fatos, números, condições, garantias e urgências não sustentadas.
- Evitar pedir explicações se a etapa espera texto final.
- Testar com pelo menos um produto, um público, uma apresentação e um cenário.

## 30. Checklist para novas etapas

Adicionar uma nova etapa exige alteração técnica maior:

- Criar novo item em `ETAPAS`.
- Definir `id`, `titulo`, `grupo_prompt`, `entrada` e `saida`.
- Criar pasta correspondente em `prompts/`.
- Criar função de valores em `valores_etapa()` ou fluxo especial equivalente.
- Definir onde a etapa entra na ordem.
- Atualizar exibição em `app.py`, se necessário.
- Atualizar testes.
- Verificar se a etapa participa da escolha manual ou da ramificação automática.

## 31. Limitações atuais

Limitações importantes:

- Não há avaliação automática de qualidade criativa.
- Não há verificação factual automática.
- Não há verificação formal de compliance.
- Não há saída estruturada obrigatória.
- Não há parser para separar campos dentro do output da LLM.
- Não há retry automático para falhas temporárias.
- Não há persistência em banco.
- Não há cache de chamadas.
- Não há paralelização.
- Não há versionamento formal dos catálogos além do controle de arquivos.
- A qualidade final depende fortemente da disciplina dos prompts.
- A validação técnica garante texto não vazio, mas não garante que o texto seja bom.

Essas limitações não invalidam o projeto. Elas definem o estágio atual da solução: uma esteira auditável e editável, ainda sem camadas avançadas de avaliação, persistência e robustez operacional.

## 32. Riscos

Riscos negociais:

- A LLM pode obedecer parcialmente às regras de fidelidade.
- Uma variação pode soar correta, mas alterar sutilmente promessa ou escopo.
- O excesso de alternativas pode dificultar escolha sem um critério de avaliação.
- Novos prompts podem degradar a governança se forem menos restritivos.

Riscos técnicos:

- Mudanças em APIs dos provedores podem quebrar extração de output.
- Falhas de rede interrompem etapas.
- `verify=False` no provedor oficial é ponto de atenção de segurança.
- Ausência de retry torna o fluxo sensível a falhas transitórias.
- Ausência de schema rígido dificulta validação automática do conteúdo.
- Problemas de encoding no terminal podem exibir caracteres acentuados incorretamente, mesmo quando os arquivos estão em UTF-8.

## 33. Roadmap técnico-negocial

Melhorias recomendadas:

- Criar documentação de referência para cada catálogo YAML.
- Adicionar testes unitários específicos para `motor.py`.
- Adicionar testes para provedores com mocks de resposta.
- Criar modo dry-run que monta payloads sem chamar LLM.
- Persistir resultados em JSON ou SQLite.
- Adicionar retry com backoff para chamadas LLM.
- Adicionar cache por hash de payload.
- Adicionar avaliador automático de fidelidade e promessa.
- Definir schema estruturado opcional para etapas finais.
- Criar relatório comparativo entre variações geradas.
- Separar configuração de provedores em camada própria.
- Proteger melhor segredos e certificados no fluxo oficial.
- Criar guia de decisão para escolher a melhor variação.

## 34. Leitura técnica curta do projeto

Em uma frase técnica:

> O projeto é um orquestrador Python de prompts YAML que preenche placeholders, chama uma LLM etapa a etapa, grava outputs em um contexto e ramifica variações por tendências cognitivas até gerar conjuntos finais de comunicação.

Em uma frase negocial:

> O projeto transforma conhecimento estruturado de produto, público e estratégia persuasiva em alternativas de mensagem com controle de voz, promessa e rastreabilidade.

Em uma frase sobre a LLM:

> A LLM escreve e reescreve texto dentro de limites dados pelo sistema, mas não decide o fluxo, não escolhe a estratégia e não controla a execução.

## 35. Glossário

| Termo | Definição |
| --- | --- |
| Apresentação | Template inicial que combina produto e público em uma proposta-base |
| Cenário | Estrutura de copywriting que orienta desenvolvimento do texto |
| Conjunto gerado | Caminho final com tendência, prompts usados, contexto e outputs |
| Contexto | Dicionário Python que guarda placeholders e outputs intermediários |
| CTA | Chamada para ação gerada na etapa final |
| Genera | Provedor oficial usado pelo projeto |
| Headline | Título gerado a partir do texto curto e da base institucional |
| LLM | Modelo de linguagem chamado como transformador textual |
| Ollama | Provedor local usado para teste e desenvolvimento |
| Placeholder | Marcador `PH_*` preenchido antes da chamada à LLM |
| Prompt | Arquivo YAML com `system` e `template` de uma etapa |
| Tagline | Texto curto gerado a partir da base em Voz BB |
| Tendência cognitiva | Lente de variação que reorganiza a mensagem sem criar fatos novos |
| Voz BB | Camada de reescrita para adequação institucional |

## 36. Conclusão

O projeto combina uma visão negocial forte com uma implementação técnica simples. Sua força está na separação entre conhecimento editável, método criativo, orquestração em código e uso delimitado da LLM.

Ele não é um sistema autônomo de IA. Ele é uma esteira de geração controlada. A LLM é uma peça importante, mas subordinada ao fluxo: recebe contexto, segue prompts, transforma texto e devolve output. O motor decide o caminho.

Essa escolha torna o projeto mais fácil de auditar, explicar e evoluir. Ao mesmo tempo, deixa claro o próximo passo de maturidade: adicionar avaliação automática, persistência, retry, schemas de saída e governança mais formal para uso em escala.
