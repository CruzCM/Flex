"""Modelos do dominio, resultados e integracao oficial Genera."""

from __future__ import annotations

import copy
import json
import os
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from .yaml_utils import partes_preenchidas, placeholders, preencher, rotulo


def _compactar(texto: Any) -> str:
    return " ".join(str(texto or "").split())


def _valores_placeholder(dados: dict[str, Any]) -> dict[str, str]:
    return {
        str(chave): _compactar(valor)
        for chave, valor in dados.items()
        if str(chave).startswith("PH_")
    }


@dataclass
class Produto:
    nome: str
    descricao: str
    beneficio_racional: str
    beneficio_emocional: str
    origem: str = ""
    dados: dict[str, Any] = field(default_factory=dict, repr=False)

    @property
    def rotulo(self) -> str:
        return rotulo(self.nome)


@dataclass
class Publico:
    nome: str
    descricao: str
    necessidade_racional: str
    necessidade_emocional: str
    origem: str = ""
    dados: dict[str, Any] = field(default_factory=dict, repr=False)

    @property
    def rotulo(self) -> str:
        return rotulo(self.nome)


@dataclass
class Apresentacao:
    nome: str
    template: str
    descricao: str
    origem: str = ""
    dados: dict[str, Any] = field(default_factory=dict, repr=False)

    @property
    def rotulo(self) -> str:
        return rotulo(self.nome)

    def montar(self, produto: Produto, publico: Publico) -> dict[str, Any]:
        placeholders_necessarios = placeholders(
            self.template,
            origem=self.origem,
            campo="template",
            etapa="Apresentacao",
        )
        placeholders_disponiveis = {
            **_valores_placeholder(produto.dados),
            **_valores_placeholder(publico.dados),
        }
        placeholders_ausentes = [
            nome
            for nome in placeholders_necessarios
            if (
                nome not in placeholders_disponiveis
                or not str(placeholders_disponiveis[nome]).strip()
            )
        ]
        placeholders_nao_utilizados = [
            nome
            for nome in sorted(placeholders_disponiveis)
            if nome not in placeholders_necessarios
        ]
        avisos = []

        if placeholders_nao_utilizados:
            avisos.append(
                "Placeholders disponiveis nao utilizados nesta apresentacao: "
                + ", ".join(placeholders_nao_utilizados)
            )

        if placeholders_ausentes:
            raise ValueError(
                "Apresentacao sem valores para placeholders obrigatorios: "
                + ", ".join(placeholders_ausentes)
                + "\n\nAdicione esses campos PH_ ao Produto ou Publico selecionado."
            )

        valores = {
            nome: placeholders_disponiveis[nome]
            for nome in placeholders_necessarios
        }
        texto = preencher(
            self.template,
            valores,
            origem=self.origem,
            campo="template",
            etapa="Apresentacao",
        )
        texto_final = " ".join(texto.split())
        partes = partes_preenchidas(
            self.template,
            valores,
            origem=self.origem,
            campo="template",
            etapa="Apresentacao",
        )

        return {
            "texto": texto_final,
            "visual": "".join(parte["texto"] for parte in partes),
            "partes": partes,
            "placeholders": valores,
            "placeholders_necessarios": placeholders_necessarios,
            "placeholders_disponiveis": placeholders_disponiveis,
            "placeholders_usados": sorted(valores),
            "placeholders_ausentes": placeholders_ausentes,
            "placeholders_nao_utilizados": placeholders_nao_utilizados,
            "avisos": avisos,
        }


@dataclass
class Cenario:
    nome: str
    texto_prompt: str
    funcao_prompt: str
    exibir_usuario: str = ""
    origem: str = ""
    dados: dict[str, Any] = field(default_factory=dict, repr=False)

    @property
    def rotulo(self) -> str:
        return rotulo(self.nome)

    def campo(self, nome: str, padrao: Any = "") -> Any:
        return self.dados.get(nome, padrao)


@dataclass
class Tendencia:
    nome: str
    texto_prompt: str
    funcao_prompt: str
    not_prompt_descricao: str = ""
    origem: str = ""
    dados: dict[str, Any] = field(default_factory=dict, repr=False)

    @property
    def rotulo(self) -> str:
        return rotulo(self.nome)

    def campo(self, nome: str, padrao: Any = "") -> Any:
        return self.dados.get(nome, padrao)


@dataclass
class Prompt:
    grupo: str
    nome: str
    system: str
    template: str
    origem: str
    versao: str = ""
    dados: dict[str, Any] = field(default_factory=dict, repr=False)

    @property
    def identificador(self) -> str:
        return f"{self.grupo}/{self.nome}"


@dataclass
class Selecao:
    produto: str
    publico: str
    apresentacao: str
    cenario: str
    tendencia: str = ""
    limite_tagline: int = 100
    limite_headline: int = 25


@dataclass
class Etapa:
    id: str
    titulo: str
    grupo_prompt: str
    saida: str
    entrada: str
    temperature: float = 0.7
    max_tokens: int = 512
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    best_of: int = 1


@dataclass
class ResultadoPrompt:
    prompt: Prompt
    system: str
    template_original: str
    template_preenchido: str
    entrada: str
    opcao: str = ""
    parametros: dict[str, Any] = field(default_factory=dict)
    output: Optional[str] = None
    bruto: Optional[dict[str, Any]] = None
    erro: Optional[str] = None
    escolhido: bool = False

    @property
    def valido(self) -> bool:
        return self.erro is None and bool(str(self.output or "").strip())

    @property
    def identificador(self) -> str:
        if self.opcao:
            return f"{self.prompt.identificador} - {self.opcao}"

        return self.prompt.identificador


@dataclass
class ResultadoEtapa:
    id: str
    titulo: str
    entrada_comum: str
    resultados_prompt: list[ResultadoPrompt] = field(default_factory=list)
    prompt_selecionado: Optional[str] = None
    opcao_selecionada: Optional[str] = None
    saida_selecionada: Optional[str] = None
    erro: Optional[str] = None

    @property
    def prompt(self) -> str:
        return self.prompt_selecionado or ""

    @property
    def template(self) -> str:
        resultado = self.resultado_selecionado()
        return resultado.template_preenchido if resultado else ""

    @property
    def output(self) -> str:
        return self.saida_selecionada or ""

    @property
    def bruto(self) -> dict[str, Any]:
        resultado = self.resultado_selecionado()
        return resultado.bruto or {} if resultado else {}

    def validos(self) -> list[ResultadoPrompt]:
        return [resultado for resultado in self.resultados_prompt if resultado.valido]

    def resultado_selecionado(self) -> Optional[ResultadoPrompt]:
        for resultado in self.resultados_prompt:
            if resultado.escolhido:
                return resultado
        return None


@dataclass
class ConjuntoGerado:
    id: str
    contexto: dict[str, Any]
    resultados: list[ResultadoPrompt] = field(default_factory=list)
    tendencia: str = ""
    prompts: dict[str, str] = field(default_factory=dict)

    @property
    def texto_institucional(self) -> str:
        return str(self.contexto.get("PH_BASE_BB", ""))

    @property
    def tagline(self) -> str:
        return str(self.contexto.get("PH_TEXTO", ""))

    @property
    def headline(self) -> str:
        return str(self.contexto.get("PH_TITULO", ""))

    @property
    def cta(self) -> str:
        return str(self.contexto.get("PH_TEXTO_CTA", ""))


@dataclass
class Resultado:
    selecao: Selecao
    apresentacao_visual: str
    apresentacao_texto: str
    placeholders: dict[str, str]
    contexto: dict[str, Any]
    etapas: list[ResultadoEtapa] = field(default_factory=list)
    conjuntos: list[ConjuntoGerado] = field(default_factory=list)

    @property
    def headline(self) -> str:
        if self.conjuntos:
            return self.conjuntos[0].headline

        return str(self.contexto.get("PH_TITULO", ""))

    @property
    def tagline(self) -> str:
        if self.conjuntos:
            return self.conjuntos[0].tagline

        return str(self.contexto.get("PH_TEXTO", ""))

    @property
    def cta(self) -> str:
        if self.conjuntos:
            return self.conjuntos[0].cta

        return str(self.contexto.get("PH_TEXTO_CTA", ""))

    @property
    def resumo_institucional(self) -> str:
        if self.conjuntos:
            return self.conjuntos[0].texto_institucional

        return str(self.contexto.get("PH_BASE_BB", ""))

    @property
    def historico_tecnico(self) -> list[dict[str, Any]]:
        historico = []
        for etapa in self.etapas:
            for resultado in etapa.resultados_prompt:
                historico.append(
                    {
                        "etapa": etapa.titulo,
                        "prompt": resultado.prompt.identificador,
                        "opcao": resultado.opcao,
                        "parametros": resultado.parametros,
                        "escolhido": resultado.escolhido,
                        "erro": resultado.erro,
                        "chamada": resultado.bruto,
                    }
                )
        return historico


URL_GATEWAY = "https://generabb-acs.gbb.servicos.bb.com.br/gateway/agent"


class Genera:
    def __init__(self):
        import requests
        import urllib3
        from dotenv import load_dotenv

        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        load_dotenv("config.env")

        self.requests = requests
        self.agent_id = "mf-insights"
        self.conversation_id = str(uuid.uuid4())
        self.messages = []
        self.last_result = None
        self.last_output = None

    def call(
        self,
        prompt,
        system,
        template,
        prompt_params=None,
        temperature=0.7,
        max_tokens=512,
        top_p=1.0,
        frequency_penalty=0.0,
        presence_penalty=0.0,
        best_of=1,
        exibir=False,
        exibir_detalhado=False,
    ):
        headers = {
            "Accept": "application/json",
            "X-Client-Id": os.getenv("CLIENT_ID"),
            "UOR": os.getenv("UOR"),
            "userIdentification": os.getenv("CHAVE"),
            "Content-Type": "application/json",
        }

        mensagens_envio = [
            {"role": "system", "content": system},
            {"role": "user", "content": template},
        ]

        mensagens_envio.extend(copy.deepcopy(self.messages))
        mensagens_envio.append({"role": "user", "content": prompt})

        payload = {
            "action": "conversar",
            "agent_id": self.agent_id,
            "body": {
                "data": {
                    "input": prompt,
                    "context": {
                        "conversation_id": self.conversation_id,
                        "messages": mensagens_envio,
                    },
                    "prompt_params": prompt_params or {},
                    "config": {
                        "temperature": temperature,
                        "max_tokens": max_tokens,
                        "top_p": top_p,
                        "frequency_penalty": frequency_penalty,
                        "presence_penalty": presence_penalty,
                        "best_of": best_of,
                    },
                }
            },
        }

        request_headers_snapshot = copy.deepcopy(headers)
        request_payload_snapshot = copy.deepcopy(payload)

        try:
            response = self.requests.post(
                URL_GATEWAY,
                headers=headers,
                json=payload,
                verify=False,
                timeout=30,
            )
            response_status = response.status_code
            response_headers = dict(response.headers)

            try:
                response_body = response.json()
            except Exception:
                response_body = response.text

        except Exception as erro:
            response_status = None
            response_headers = {}
            response_body = {"erro": str(erro)}

        output = None

        try:
            output = response_body["data"]["output"]["text"][0]
        except Exception:
            output = None

        if output is not None:
            self.messages.append({"role": "user", "content": prompt})
            self.messages.append({"role": "assistant", "content": output})

        resultado = {
            "output": output,
            "request_headers": request_headers_snapshot,
            "request_payload": request_payload_snapshot,
            "response_status": response_status,
            "response_headers": response_headers,
            "response_body": response_body,
        }

        self.last_result = resultado
        self.last_output = output

        if exibir:
            print(output)

        if exibir_detalhado:
            print(json.dumps(resultado, indent=4, ensure_ascii=False))

        return resultado

    def reset(self):
        self.conversation_id = str(uuid.uuid4())
        self.messages = []
        self.last_result = None
        self.last_output = None

    def historico(self):
        return self.messages

    def exibir_historico(self):
        print(json.dumps(self.messages, indent=4, ensure_ascii=False))

    def ultima_resposta(self):
        return self.last_output

    def ultimo_resultado(self):
        return self.last_result

    def __repr__(self):
        return (
            "Genera("
            f"agent_id='{self.agent_id}', "
            f"conversation_id='{self.conversation_id}', "
            f"mensagens={len(self.messages)}"
            ")"
        )
